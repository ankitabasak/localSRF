import { expect } from 'chai';
import * as UniversalReducers from '../../Redux_Reducers/UniversalSelectorReducers';

import { GET_INITIAL_SCHOOL_OBJECT, GET_INITIAL_SCHOOL_OBJECT_SUCCESS, RETURN_TO_PREVIOUS_REPORT_UNIVERSAL, STUDENT_DATA_ACTION, STUDENT_DATA_ACTION_FAIL, STUDENT_DATA_ACTION_SUCCESS } from '../../Reducer_Action_Types/UniversalSelectorActionTypes';

jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});

const res, getTestsAfterStd_Data;
let field="beforeApi";
let sampleToken = "eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MzM3MTU4MzgsImlzcyI6ImF0bGFudGlzIiwiaWQiOjY3NDQ4MzMuMCwiZmlyc3RfbmFtZSI6IkJyYW5kb24iLCJsYXN0X25hbWUiOiJNY0NveSIsInJlYWxtX2lkIjoxOTQzLjAsImVtYWlsIjoibWNjb3licmFuZG9uQGR1YmxpbnVzZC5vcmciLCJyb2xlcyI6eyJESVNUUklDVF9BRE1JTiI6WzU0ODY0MS4wXX0sImFzc2VtYmx5X2NvZGVzX2hhc2giOiI5N0QxNzBFMTU1MEVFRTRBRkMwQUYwNjVCNzhDREEzMDJBOTc2NzRDIiwicmVhbG0iOiJkdWJsaW4iLCJ1c2VybmFtZSI6Im1jY295YnJhbmRvbkBkdWJsaW51c2Qub3JnIiwiYXBwVHlwZSI6IndlYl9idSIsInNlY19oYXNoIjoiMzNjMjE4MmI2MjEwY2M1Mjc0MmVhMjgyNDE0ZDZkNDUifQ.BaIN-1ZSYmcOUTfw5Kqyva4r5iL3TKaiFOkWHFLSH0w"

  describe("summary report actions actions", () =>{
    afterEach(() => {
      jest.clearAllMocks();
    });
  it("call student data action for beforeApi field", ()=>{
    const dispatch = jest.fn();
    UniversalReducers.GetStudent_Data_Action(field, res, getTestsAfterStd_Data)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: STUDENT_DATA_ACTION});
  });

  it("call student data action for success field", ()=>{
    field = "success"
    const dispatch = jest.fn();
    UniversalReducers.GetStudent_Data_Action(field, res, getTestsAfterStd_Data)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: STUDENT_DATA_ACTION_SUCCESS});
  });


  it("call student data action for fail field", ()=>{
    field = "fail"
    const dispatch = jest.fn();
    UniversalReducers.GetStudent_Data_Action(field, res, getTestsAfterStd_Data)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: STUDENT_DATA_ACTION_FAIL});
  });

  it("call getInitialSchoolObjService", ()=>{
    const dispatch = jest.fn();
    let requestObj = {
                      currentTermId: "5096",
                      districtId: 548641,
                      districtName: "Sulphur Springs Union Elementary School District",
                      endDate: "2021-10-01 23:59:59",
                      isPastDistrictTerm: false,
                      rosterGrade: "grade_5",
                      startDate: "2019-08-08 00:00:00",
                      termId: "5096"
    };
    UniversalReducers.getInitialSchoolObjService( sampleToken,requestObj )(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: GET_INITIAL_SCHOOL_OBJECT});
    expect(dispatch.mock.calls[0][1]).to.eql({  type: GET_INITIAL_SCHOOL_OBJECT_SUCCESS});
  });

  it("set data on Return_to_previous_report_Universal", ()=>{
    const dispatch = jest.fn();
   const  NavToStrands  =  false;
    const  SameReportData  =  true;
    const Last_Active_Reports = {};
    const Date_Last_Active_repo ={};
    UniversalReducers.Return_to_previous_report_Universal( NavToStrands,SameReportData,Last_Active_Reports,Date_Last_Active_repo )(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: RETURN_TO_PREVIOUS_REPORT_UNIVERSAL});
  });

}); 