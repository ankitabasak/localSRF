import { expect } from 'chai';
import * as RosterActions from '../../Redux_Actions/UniversalRosterActions';
import { GET_CLASS_OBJECT_WHICH_HAS_REPORTS, GET_CLASS_OBJECT_WHICH_HAS_REPORTS_SUCCESS, GET_INITIAL_SCHOOL_OBJECT, GET_INITIAL_SCHOOL_OBJECT_SUCCESS } from '../../Reducer_Action_Types/UniversalSelectorActionTypes';

jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});


  describe("summary report actions actions", () =>{
    afterEach(() => {
      jest.clearAllMocks();
    });
  it("call getInitialSchoolObjService", ()=>{
    const dispatch = jest.fn();
    const getState = jest.fn();
    let requestObj = {
        districtId: 548641,
        rosterGrade: "grade_5",
        schoolId: 555269,
        termId: "5096"
    };
    RosterActions.Get_ClassObject_WhichHas_Reports(requestObj )(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: GET_CLASS_OBJECT_WHICH_HAS_REPORTS});
    expect(dispatch.mock.calls[0][1]).to.eql({  type: GET_CLASS_OBJECT_WHICH_HAS_REPORTS_SUCCESS});
  });

}); 