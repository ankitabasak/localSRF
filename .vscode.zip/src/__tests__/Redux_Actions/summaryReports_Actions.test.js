import { expect } from 'chai';
import * as SRActions from '../../Redux_Actions/summaryReports_Actions';
import {GET_SUMMARY_SP_PDF_DATA,GET_SUMMARY_SP_PDF_DATA_SUCCESS} from '../../Reducer_Action_Types/summaryReports_Action_Types';

jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});

let AccessToken = "eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MzI1NTE1OTMsImlzcyI6ImF0bGFudGlzIiwiaWQiOjY3NDQ4MzMuMCwiZmlyc3RfbmFtZSI6IkJyYW5kb24iLCJsYXN0X25hbWUiOiJNY0NveSIsInJlYWxtX2lkIjoxOTQzLjAsImVtYWlsIjoibWNjb3licmFuZG9uQGR1YmxpbnVzZC5vcmciLCJyb2xlcyI6eyJESVNUUklDVF9BRE1JTiI6WzU0ODY0MS4wXX0sImFzc2VtYmx5X2NvZGVzX2hhc2giOiI5N0QxNzBFMTU1MEVFRTRBRkMwQUYwNjVCNzhDREEzMDJBOTc2NzRDIiwicmVhbG0iOiJkdWJsaW4iLCJ1c2VybmFtZSI6Im1jY295YnJhbmRvbkBkdWJsaW51c2Qub3JnIiwiYXBwVHlwZSI6InVua25vd24iLCJzZWNfaGFzaCI6ImI2YjA2NGI1NTgwNzA4MTA3ZGVjZjdiZmI3ZDhlNDY2In0.ESffmYtC0JrG1XDkqEJQR0ymAPfRrLEC0Op9vzdVEic",
ReqPayload= {"requesterName":"Dublin Unified School District","requesterId":"6744833","type":"PDF","domainUrl":"https://phanes-qa.benchmarkuniverse.com","fetchData":{"applicationId":1111,"endPoint":"https://buapi-qa.benchmarkuniverse.com/agp/v1/class/standardperformanceSummaryPDF","methodType":"POST","requestVO":{"jwtToken":"eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MzI2NjY5MDUsImlzcyI6ImF0bGFudGlzIiwiaWQiOjYwNTc5NzEuMCwiZmlyc3RfbmFtZSI6IkFkcmlhbm5hIiwibGFzdF9uYW1lIjoiUm9jaGEiLCJyZWFsbV9pZCI6MTk0My4wLCJlbWFpbCI6InJvY2hhYWRyaWFubmFAZHVibGludXNkLm9yZyIsInJvbGVzIjp7IlRFQUNIRVIiOls1NTUyNzAuMCwxNjg0MjMwLjBdfSwiYXNzZW1ibHlfY29kZXNfaGFzaCI6Ijk3RDE3MEUxNTUwRUVFNEFGQzBBRjA2NUI3OENEQTMwMkE5NzY3NEMiLCJyZWFsbSI6ImR1YmxpbiIsInVzZXJuYW1lIjoicm9jaGFhZHJpYW5uYUBkdWJsaW51c2Qub3JnIiwiYXBwVHlwZSI6InVua25vd24iLCJzZWNfaGFzaCI6IjUxZGE3ZmI5MWJhMzU0OTNiNmUyZDg1NDdjZjM1YjhmIn0.8tn0nt_6HOLaYrF6EzpB8Wna-CC4yxTCS71qb5a28_E","districtId":548641,"schoolId":555270,"rosterGrade":"grade_1","grade":"grade_1","classId":"1684230","districtName":"Dublin Unified School District","teacherName":"Adrianna Rocha","schoolName":"Dublin Elementary School","className":"01 Homeroom - Rocha - 1","termId":"5096","currentTermId":"5096","startDate":"2019-08-08 00:00:00","endDate":"2021-10-01 18:29:59","createdBy":"Adrianna Rocha","createdDate":"9/25/2021","dates":"2019-08-08 00:00:00-2021-10-01 18:29:59","isPastDistrictTerm":false,"classIds":["1684230"]}},"fileName":"StandardsPerformanceSummary","contextType":"class","contextName":"Dublin Unified School District","isMultipleTemplates":true},
fromContext = "district",
Nav = {
    Assessement: true,
    ORR: false,
    O_R_R: "display_and_not_selected",
    Overview: false,
    S_performance: false,
    Summary_Reports: false,
    Summary_Tab: false,
    T_scores: false,
    class: false,
    comparison: false,
    district: true,
    errorAnalysis: false,
    fluencyAnalysis: false,
    grouping: false,
    open_comparison_modal: false,
    readingBehaviors: false,
    readingHistory: false,
    rlp: true,
    school: false,
    st_analysis: false,
    student: false,
    summary: false,
    test_status: true,
    usageReport: false
};

  describe("summary report actions actions", () =>{
    afterEach(() => {
      jest.clearAllMocks();
    });
  it("call immediate summary sp pdf", ()=>{
    const dispatch = jest.fn();
    SRActions.Get_PDF_Details(AccessToken, ReqPayload, Nav)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: GET_SUMMARY_SP_PDF_DATA, payload: { Nav
    }});
  });

  it("call immediate summary sp pdf success", ()=>{
    const dispatch = jest.fn();
    let ResPayload={}
    SRActions.Get_PDF_Details(AccessToken, ReqPayload, Nav)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][1]).to.eql({  type: GET_SUMMARY_SP_PDF_DATA_SUCCESS, payload: {
        ResPayload,
         Nav
    }});
  });

  it("call getGradeList for class context", ()=>{
    const dispatch = jest.fn();
    let ReqPayload={},
     fromContext = "class"
    SRActions.getGradeList(AccessToken, ReqPayload, fromContext)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SUMMARY_TESTGRADES, payload: {
      fromContext
    }});
    expect(dispatch.mock.calls[0][1]).to.eql({  type: SUMMARY_TESTGRADES_SUCCESS, payload: {
      fromContext
    }});
  });

  it("call getGradeList for school context", ()=>{
    const dispatch = jest.fn();
    let ReqObject={},
     fromContext = "school"
    SRActions.getGradeList(AccessToken, ReqObject, fromContext)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SUMMARY_TESTGRADES, payload: {
      fromContext
    }});
    expect(dispatch.mock.calls[0][1]).to.eql({  type: SUMMARY_TESTGRADES_SUCCESS, payload: {
      fromContext
    }});
  });

  it("call getGradeList for class context", ()=>{
    const dispatch = jest.fn();
    let ReqPayload={},
     fromContext = "class"
    SRActions.getGradeList(AccessToken, ReqPayload, fromContext)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SUMMARY_TESTGRADES, payload: {
      fromContext
    }});
    expect(dispatch.mock.calls[0][1]).to.eql({  type: SUMMARY_TESTGRADES_SUCCESS, payload: {
      fromContext
    }});
  });

  it("call getGradeList for school context", ()=>{
    const dispatch = jest.fn();
    let ReqObject={},
     fromContext = "school"
    SRActions.getGradeList(AccessToken, ReqObject, fromContext)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SUMMARY_TESTGRADES, payload: {
      fromContext
    }});
    expect(dispatch.mock.calls[0][1]).to.eql({  type: SUMMARY_TESTGRADES_SUCCESS, payload: {
      fromContext
    }});
  });

}); 