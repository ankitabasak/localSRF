import React from 'react';
import { expect } from 'chai';
import {getFromContext} from '../../../Utils/SummaryBlock/reusableSummaryReports';

test('call getFromContext function for district', () => {
  const Navigation = {
    district: true,
    school:false,
    class:false,
    student:false
  };
  const activeProp = getFromContext(Navigation)
  expect(activeProp).to.equal('district');
});
test('call getFromContext function for school', () => {
    const Navigation = {
        district: false,
        school:true,
        class:false,
        student:false,
      };
  const activeProp = getFromContext(Navigation)
  expect(activeProp).to.equal('school');
});
test('call getFromContext function for class', () => {
    const Navigation = {
        district: false,
        school:false,
        class:true,
        student:false
      };
  const activeProp = getFromContext(Navigation)
  expect(activeProp).to.equal('class');
});

test('call getFromContext function for student', () => {
    const Navigation = {
        district: false,
        school:false,
        class:false,
        student:true
      };
  const activeProp = getFromContext(Navigation)
  expect(activeProp).to.equal('student');
});
