import React from 'react';
import { expect } from 'chai';
import { shallow, mount } from 'enzyme';
import summaryScreen from '../../../../Components/District/summaryScreen/summaryScreen';

function setup(overrides = {}) {
 
    const ApiCalls = {
        CallDefaultOn_District_Change: false,
    Call_defaultClasses: false,
    Call_defaultStudents: false,
    Call_defaultTeachers: false,
    DefaultApiSuccess: true,
    DefaultSummaryApiSuccess: true,
    Done_RosterTab_Details_Setup: true,
    Get_Class_SP_Grade: false,
    Get_Class_Strands: false,
    Get_Class_TestScores: false,
    Get_Class_Ts_Comparison: false,
    Get_District_assessed_que: true,
    Get_District_sp_grades: false,
    Get_District_strands: false,
    Get_Selected_School_Info: false,
    Get_Student_SP_Grade: false,
    Get_Student_Strands: false,
    Get_Student_TestScores: false,
    Get_Updated_SingleTestData: false,
    Get_school_sp_grades: false,
    Get_school_strands: false,
    LeftViewNotSelectedInClass: false,
    LeftViewNotSelectedInDistrict: false,
    LeftViewNotSelectedInSchool: false,
    LeftViewNotSelectedInStudent: false,
    No_Strands_On_DefaultLoad_Call_Ts: false,
    RosterTabApiSuccess: true,
    STUDENT_OBJ_API: false,
    SeparateRosterDetails: false,
    compareContextSelection: false,
    getChartData: false,
    getClass: false,
    getDateTabFromServer_success: true,
    getInitialSchoolObj: false,
    getRoster_Classes: false,
    getRoster_Grades_Schools: false,
    getRoster_Student_Teachers: false,
    getStudentData_cls: false,
    getTests: false,
    getTestsAfterStd_Data: false,
    getTests_success: false,
    get_C_Grades_Alias: false,
    get_C_TS_Compare_Alias: false,
    get_C_TS_Graph_Alias: false,
    get_D_Grades_Alias: false,
    get_D_TS_Graph_Alias: false,
    get_District_TS_graph: false,
    get_Roster_Grades_TS: false,
    get_SC_Grades_Alias: false,
    get_SC_TS_Graph_Alias: false,
    get_S_Grades_Alias: false,
    get_S_TS_Graph_Alias: false,
    get_school_TS_Graph: false,
    load_only_strands_inclass: false,
    loaderForRosterClassList: false,
    loaderGetRosterCompleteData: false,
    loader_On_Sts_Grades: false,
    loadingFor: "",
    loadingOn_C_Sp_Grades: false,
    loadingOn_D_Sp_Grades: false,
    loadingOn_SC_Sp_Grades: false,
    }
    
    const SummaryReports ={
        ModelProps:{
            standards: true,
    student_username: false,
    test_scores: false,
        },
        callOrrAndUsageWidgets: true,
        school:{
            assessments:{
                apiCalls:{
                    Nodata: false,
    isTestStatusEnable: false,
    loadingOnStrands: false,
    loadingOnTestStatus: false,
    showNoDataPopUp: false,
    strandsApi: false,
    testStatusAPI: false,
    testStatusNoData: false,
    testsAPI: true
                },
                banner: true,
                standardperformance:{
                    CSVPopup: false,
                    HeaderStrands:{
                        "College and Career Readiness Anchor Standards": 100,
    "Language": 61,
    "Reading: Foundational Skills": 56,
    "Reading: Informational Text": 62,
    "Reading: Literature": 57,
    "Writing": 69
                    },
                    data:{
                        "CCSS English Language Arts":{
                            "averageScoresByStrand":{
                                "Language": 61,
    "Reading: Foundational Skills": 56,
    "Reading: Informational Text": 62,
    "Reading: Literature": 57
                            },
                            "gradeDetails":{
                                "grade_1":[
                                    {strandName: 'Reading: Foundational Skills', score: 30, maxScore: 44, strandAvg: 68},
     {strandName: 'Language', score: 5, maxScore: 14, strandAvg: 36},
     {strandName: 'Reading: Literature', score: 2, maxScore: 22, strandAvg: 9},
     {strandName: 'Reading: Informational Text', score: 20, maxScore: 69, strandAvg: 29}
                                ],
                                "grade_2":[
                                     {strandName: 'Reading: Foundational Skills', score: 79, maxScore: 159, strandAvg: 50},
     {strandName: 'Language', score: 217, maxScore: 315, strandAvg: 69},
     {strandName: 'Reading: Literature', score: 213, maxScore: 334, strandAvg: 64},
     {strandName: 'Reading: Informational Text', score: 255, maxScore: 379, strandAvg: 67}
                                ],
                                "grade_3":[
    {strandName: 'Reading: Foundational Skills', score: 276, maxScore: 424, strandAvg: 65},
     {strandName: 'Language', score: 851, maxScore: 1264, strandAvg: 67},
     {strandName: 'Reading: Literature', score: 575, maxScore: 876, strandAvg: 66},
     {strandName: 'Reading: Informational Text', score: 1365, maxScore: 1937, strandAvg: 70}
                                ],
                                "grade_4": [
     {strandName: 'Reading: Foundational Skills', score: 43, maxScore: 71, strandAvg: 61},
     {strandName: 'Language', score: 63, maxScore: 176, strandAvg: 36},
     {strandName: 'Reading: Literature', score: 69, maxScore: 178, strandAvg: 39},
     {strandName: 'Reading: Informational Text', score: 125, maxScore: 226, strandAvg: 55},
                                ],
                                "grade_5": [
     {strandName: 'Reading: Foundational Skills', score: 42, maxScore: 117, strandAvg: 36},
     {strandName: 'Language', score: 106, maxScore: 201, strandAvg: 53},
     {strandName: 'Reading: Literature', score: 83, maxScore: 185, strandAvg: 45},
     {strandName: 'Reading: Informational Text', score: 136, maxScore: 331, strandAvg: 41}
                                ],
                                "grade_6": [
     {strandName: 'Reading: Foundational Skills', score: 2, maxScore: 6, strandAvg: 33},
     {strandName: 'Language', score: 8, maxScore: 21, strandAvg: 38},
     {strandName: 'Reading: Literature', score: 0, maxScore: 0, strandAvg: 0},
     {strandName: 'Reading: Informational Text', score: 14, maxScore: 54, strandAvg: 26}
                                ],
                                "grade_k": [
     {strandName: 'Reading: Foundational Skills', score: 50, maxScore: 108, strandAvg: 46},
     {strandName: 'Language', score: 63, maxScore: 169, strandAvg: 37},
     {strandName: 'Reading: Literature', score: 63, maxScore: 161, strandAvg: 39},
     {strandName: 'Reading: Informational Text', score: 138, maxScore: 327, strandAvg: 42}
                                ]
                            }
                        }
                    },
    
                    gradeDetails:{
                        "grade_1": [
                         {strandName: 'College and Career Readiness Anchor Standards', score: 0, maxScore: 0, strandAvg: 0},
                     {strandName: 'Language', score: 5, maxScore: 14, strandAvg: 36},
                         {strandName: 'Reading: Foundational Skills', score: 30, maxScore: 44, strandAvg: 68},
                        {strandName: 'Reading: Informational Text', score: 20, maxScore: 69, strandAvg: 29},
                         {strandName: 'Reading: Literature', score: 2, maxScore: 22, strandAvg: 9},
                         {strandName: 'Writing', score: 0, maxScore: 0, strandAvg: 0}
                        ],
                        "grade_2":[
     {strandName: 'College and Career Readiness Anchor Standards', score: 3, maxScore: 3, strandAvg: 100},
     {strandName: 'Language', score: 217, maxScore: 315, strandAvg: 69},
     {strandName: 'Reading: Foundational Skills', score: 79, maxScore: 159, strandAvg: 50},
     {strandName: 'Reading: Informational Text', score: 255, maxScore: 379, strandAvg: 67},
     {strandName: 'Reading: Literature', score: 213, maxScore: 334, strandAvg: 64},
     {strandName: 'Writing', score: 59, maxScore: 75, strandAvg: 79}
                        ],
                        "grade_3": [
     {strandName: 'College and Career Readiness Anchor Standards', score: 0, maxScore: 0, strandAvg: 0},
     {strandName: 'Language', score: 851, maxScore: 1264, strandAvg: 67},
     {strandName: 'Reading: Foundational Skills', score: 276, maxScore: 424, strandAvg: 65},
     {strandName: 'Reading: Informational Text', score: 1365, maxScore: 1937, strandAvg: 70},
     {strandName: 'Reading: Literature', score: 575, maxScore: 876, strandAvg: 66},
     {strandName: 'Writing', score: 345, maxScore: 499, strandAvg: 69},
                        ],
                        "grade_4": [
     {strandName: 'College and Career Readiness Anchor Standards', score: 0, maxScore: 0, strandAvg: 0},
     {strandName: 'Language', score: 63, maxScore: 176, strandAvg: 36},
     {strandName: 'Reading: Foundational Skills', score: 43, maxScore: 71, strandAvg: 61},
     {strandName: 'Reading: Informational Text', score: 125, maxScore: 226, strandAvg: 55},
     {strandName: 'Reading: Literature', score: 69, maxScore: 178, strandAvg: 39},
     {strandName: 'Writing', score: 9, maxScore: 30, strandAvg: 30},
                    ]
                    },
                    headerNavEnd: 4,
                    headerNavStart: 0,
                    loader_pdfDownload: false,
                    selectedTaxonomy: "CaCCSS English Language Arts",
                    setIdByViewName: undefined,
                    studentList: undefined,
                    taxonomyDropDown: false,
                    taxonomyList:[
                        "CaCCSS English Language Arts",
                        "CCSS English Language Arts",
                        "CaCCSS Spanish Language Arts"
                    ]
                }
            }
        }
    }
    
    const Authentication={
        Auth_Apis:{
            DatesApi: false,
    Loading_Report_Access: false,
    RosterApi: false,
    SchoolApiForORR: true,
    defaultApi: false,
    getSummaryDefault: false,
    lazyLoad_eAR_Default_Api: true,
        },
        LoginDetails:{
            DateTimeOf_DefaultApi: "Thu Sep 30 2021 09:46:51 GMT+0530 (India Standard Time)",
            DisplayNodata: false,
    DisplayTechnicalError: false,
    JWTToken: "eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MzI5ODI4NzEsImlzcyI6ImF0bGFudGlzIiwiaWQiOjI0Nzg4MzMuMCwiZmlyc3RfbmFtZSI6IkJFQyIsImxhc3RfbmFtZSI6IkFkbWluIiwicmVhbG1faWQiOjExNDYuMCwicm9sZXMiOnsiU0NIT09MX0FETUlOIjpbMTc0NDQ2LjBdfSwiYXNzZW1ibHlfY29kZXNfaGFzaCI6Ijk3RDE3MEUxNTUwRUVFNEFGQzBBRjA2NUI3OENEQTMwMkE5NzY3NEMiLCJyZWFsbSI6ImJhLWJlYyIsInVzZXJuYW1lIjoiYmVjX2FkbWluIiwiYXBwVHlwZSI6IndlYl9idSIsInNlY19oYXNoIjoiMzQ0ZmQ2YTNlODE1MWNmOTA5MzQ1ZTNkMDQ0ZGJlNDQifQ.617Xvaksr-UpkPENmO2JpU_HcXam1DCSugYkFgjYlP4",
    ReportingAccessParam: ['eAR', 'ORR'],
    UserRole: "SCHOOL_ADMIN",
    disableLogIn: true,
    errorCode: "",
    getInitalData: false,
    loginFails: false,
    loginSuccess: false,
    password: "",
    realm: "",
    schoolId: "",
    userName: "",
    
        },
        NoaccessToReports: false,
    retryApis: 0
    }
    
    const NavigationByHeaderSelection= {
        
    Assessement: false,
    ORR: false,
    O_R_R: "display_and_not_selected",
    Overview: true,
    S_performance: true,
    Summary_Reports: true,
    Summary_Tab: false,
    T_scores: false,
    class: false,
    comparison: false,
    district: false,
    errorAnalysis: false,
    fluencyAnalysis: false,
    grouping: false,
    open_comparison_modal: false,
    readingBehaviors: false,
    readingHistory: false,
    rlp: true,
    school: true,
    st_analysis: false,
    student: false,
    summary: false,
    test_status: false,
    usageReport: false
    }
    
    const ContextHeader ={
        Default_Roster_gradeID: undefined,
    Default_UserId: "2478833",
    Default_classID: null,
    Default_districtID: 169960,
    Default_schoolID: 174446,
    Default_teacherId: null,
    DistrictId: 169960,
    EnableMoreOptions: false,
    FERPA_COPPA_ENABLED: undefined,
    LoggedInUserName: "BEC Admin",
    PdDatesInfoIcon: false,
    PdTestsInfoIcon: false,
    Date_Tab:{
        CustomEndDate: "",
    CustomStartDate: "",
    ReportEnd_MonthName: "",
    ReportStart_MonthName: "",
    Report_termEndDate: "2022-07-30 18:29:59",
    Report_termStartDate: "2015-07-01 00:00:00",
    },
    DistrictTerms_New:{
        currentGrade: null,
    currentTermId: null,
    dataAvailable: false,
    districtEnabled: true,
    isDistrictEnabled: true,
    schoolId: null,
    termDates: null,
    termEndDate: "2022-07-30 23:59:59",
    termId: "1705",
    termName: "2015 - 2016 FY",
    termRange: "2015-2022",
    termStartDate: "2015-07-01 00:00:00"
    },
    selectedterm_Obj: {
    termDates: undefined,
    termEndDate: "2022-07-30 23:59:59",
    termId: "1705",
    termName: "2015 - 2016 FY",
    termRange: "2015-2022",
    termStartDate: "2015-07-01 00:00:00",
    },
    Summary_Roster_Data:{
        ClassIds: [
     "1451813",
     "174482",
     "2192114",
    ],
    ClassList:[
        {id: '1451813', name: 'A-Riano Class', schoolId: '174446', districtId: '169960', gradeLevel: 'null', },
       {id: '174482', name: 'VBradley Class', schoolId: '174446', districtId: '169960', gradeLevel: 'null', },
      {id: '2192114', name: 'Cortez, Adam Class', schoolId: '174446', districtId: '169960', gradeLevel: 'grade_6', },
    ],
    GradesList:[
        {grade: 'grade_6', teachers: Array(1)},
     {grade: 'grade_5', teachers: Array(10)},
     {grade: 'grade_4', teachers: Array(17)}
    ],
    SchoolIds: ['174446'],
    SelectedClass: "All",
    SelectedDistrict: {id: '169960', name: 'Benchmark School District - Advance/Adelante'},
    SelectedSchool: {name: 'BEC Employees', id: '174446', districtId: '169960', districtName: 'Benchmark School District - Advance/Adelante', check: true},
    SelectedStudent: "All",
    SelectedStudentData: {},
    SelectedTeacher: "All",
    StudentData_cls: [],
    StudentData_cls_ids: [],
    StudentIds:['5585329', '1490126', '2216249', '3039035', '3039041', '5119861', '2429743', '2275269', '2275265', '2275267', '2275275', '676088'],
    selectedRosterGrade: "All",
    summaryReportsGrade: "All"
    }
    }

  const props = {
    Authentication,
    SummaryReports,
    ApiCalls,
    NavigationByHeaderSelection,
    ContextHeader,
    UniversalFilter: "",
    isPastDistrictTerm: false,
isTermIdsEqualAndNull: false,
loadingScreenInUniversal: false,
popUp: false,
staticContext: undefined,
    UserScreenWidth: 1440,
    
     
    }

  const finalProps = Object.assign(props, overrides);
  const comp = shallow(<summaryScreen {...finalProps} />);

  return { props: finalProps, comp };
}


describe('rendering correctly summary screen ', () => {
  describe('#render()', () => {
    it('ar summary widget title ', () => {
      const { comp } = setup();
      expect(comp.find('.arSummaryWidgetTitle').length).equal(1);
    });

    it('ar summary widget css ', () => {
        const { comp } = setup();
        expect(comp.find('.csv_icon_alignment').length).equal(1);
      });
  });
});




