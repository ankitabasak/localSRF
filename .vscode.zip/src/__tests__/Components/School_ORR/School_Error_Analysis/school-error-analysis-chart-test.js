import React from 'react';
import { shallow } from 'enzyme';
import SchoolErrorAnalysisChart from '../../../../../src/Components/School_ORR/School_Error_Analysis/school-error-analysis-chart';


describe("SchoolErrorAnalysisChart", () => {
    it("should render the side panel component", () => {
        // const mockCallBack = jest.fn();
        
      const wrapper = shallow(<SchoolErrorAnalysisChart />);
      expect(wrapper.exists()).toBeTruthy();
    //   wrapper.find('.student-column-list-rhs-sec').simulate('click');

    //   expect(mockCallBack.mock.calls.length).toEqual(1);

        // expect(wrapper.find('')).toHaveLength(1);

        const title = wrapper.findWhere(node => {
            return (
              node.type() &&
              node.name() &&
              node.text() === "No. of MSV    "
            );
          });

        expect(title).toHaveLength(1);
    });
  });