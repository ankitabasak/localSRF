import React from 'react';
import { expect } from 'chai';
import { GetBrowserName} from '../../../Components/ReusableComponents/AllReusableFunctions';



test('call GetBrowserName function for safari browser', () => {
  const Navigation = {
    appName: "Netscape",
    userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Safari/605.1.15"
    };
const browserName = GetBrowserName(Navigation)
expect(browserName).to.equal("safari");
});

test('call GetBrowserName function for chrome', () => {
    const Navigation = {
      appName: "Netscape",
      userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36"
      };
  const browserName = GetBrowserName(Navigation)
  expect(browserName).to.equal("chrome");
});