import React from 'react';
import { shallow } from 'enzyme';
import SummaryCRlpChart from '../../../../../src/Components/Chart_Summary/Summary_CRLP/RLP_Chart';
import configureMockStore from "redux-mock-store";
import { Provider } from "react-redux";

describe("SummaryCRlpChart", () => {
    const mockStore = configureMockStore();
    const store = mockStore({});
    it("should render the Filters component", () => {
      const wrapper = shallow(<Provider store={store}><SummaryCRlpChart /></Provider>);
      expect(wrapper.exists()).toBeTruthy();
    });
  });
