import React from 'react';
import { shallow } from 'enzyme';
import ClassErrorAnalysisChart from '../../../../../src/Components/Class_ORR/Class_Error_Analysis/class-error-analysis-chart';


describe("ClassErrorAnalysisChart", () => {
    it("should render the side panel component", () => {
        // const mockCallBack = jest.fn();
        
      const wrapper = shallow(<ClassErrorAnalysisChart />);
      expect(wrapper.exists()).toBeTruthy();
    //   wrapper.find('.student-column-list-rhs-sec').simulate('click');

    //   expect(mockCallBack.mock.calls.length).toEqual(1);

        // expect(wrapper.find('')).toHaveLength(1);

        const title = wrapper.findWhere(node => {
            return (
              node.type() &&
              node.name() &&
              node.text() === "No. of MSV    "
            );
          });

        expect(title).toHaveLength(1);
    });
  });