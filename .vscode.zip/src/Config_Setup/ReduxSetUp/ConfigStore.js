import { createStore, applyMiddleware } from 'redux'
import {
    createMigrate,
    persistStore, persistReducer, persistCombineReducers, REHYDRATE, PURGE, autoRehydrate
} from 'redux-persist'
import storage from 'redux-persist/lib/storage' // defaults to localStorage ;
import hardSet from 'redux-persist/lib/stateReconciler/hardSet'

import rootReducer from './allreducers';

import ReduxThunk from 'redux-thunk';
import logger from 'redux-logger'

// const persistConfig = {
//     key: 'root',
//     storage,
//     version: 0,
//     stateReconciler: hardSet,
//     migrate: createMigrate(migrations, { debug: true }),
//     // blacklist: ['Universal']
// }
// const persistedReducer = persistReducer(persistConfig, rootReducer)

/**
 * @returns { Object} -- MiddlewareAPI
 */
function MiddleWare() {

    if (process.env.NODE_ENV == 'development') {
        return applyMiddleware(ReduxThunk, logger)
    } else return applyMiddleware(ReduxThunk)

}

export default () => {

    //let store = createStore(persistedReducer)
    let store = createStore(rootReducer, window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__({
        name: `Reporting: ${document.title}`
    }), MiddleWare());

    /**
     * For Redux-Persist Store
     */
    let persistor = persistStore(store)
    return { store, persistor }

    // return { store }
}

export const migrations = {
    0: (state) => {
        return { ...state }
    }
}
