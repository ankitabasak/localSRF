import { combineReducers } from "redux";
import UniversalSelectorReducer from "../../Redux_Reducers/UniversalSelectorReducer";
import DateTabReducer from "../../Redux_Reducers/DateTabReducer";
import ReportsReducer from "../../Redux_Reducers/ReportsReducer";
import AuthenticationReducer from "../../Redux_Reducers/AuthenticationReducer";
import StudentReportReducer from "../../Redux_Reducers/StudentReportReducer";
import FilterDataReducer from "../../Redux_Reducers/FilterReducer";
import StudentRlpReducer from "../../Redux_Reducers/S_ReadingLevelReducer.jsx";
import ReadingHistoryReducer from "../../Redux_Reducers/ReadingHistoryReducer";

import schoolReducer from "../../Redux_Reducers/SchoolReportReducer";
import DistrictReducer from "../../Redux_Reducers/DistrictReducer";
import TestStatusReducer from '../../Redux_Reducers/TestStatus.Reducer';
import TestStatusPrintReducer from '../../Redux_Reducers/TestStatusPrintReducer'
import ClassGroupingReducer from "../../Redux_Reducers/ClassGroupingReducer";
import ErrorAnalysisReducer from "../../Redux_Reducers/ErrorAnalysisReducer.jsx";
import classReadingHistoryReducer from "../../Redux_Reducers/C_ReadingHistoryReducer.jsx";
import ClassFluencyReducer from "../../Redux_Reducers/C_FluencyReducer.jsx";
import CommonFilterReducer from "../../Redux_Reducers/CommonFilterReducer.jsx";
import ClassGridRlpReducer from "../../Redux_Reducers/C_ReadingLevelReducer.jsx";
import SchoolRlpReducer from "../../Redux_Reducers/School_RlpReducer.jsx";
import SchoolErrorAnalysisReducer from "../../Redux_Reducers/School_ErrorAnalysisReducer.jsx";
import schoolReadingHistoryReducer from "../../Redux_Reducers/School_ReadingHistoryReducer.jsx";
import DistrictRlpReducer from "../../Redux_Reducers/District_RLP_Reducer.jsx";
import DistrictReadingHistoryReducer from "../../Redux_Reducers/District_ReadingHistoryReducer.jsx";
import ClassErrorAnalysisReducer from "../../Redux_Reducers/C_ErrorAnalysisReducer.jsx";
import StudentFluencyReducer from "../../Redux_Reducers/S_FluencyReducer.jsx";
import C_GroupingReducer from "../../Redux_Reducers/C_GroupingReducer.jsx";
import StudentReadingBehaviorReducer from "../../Redux_Reducers/S_ReadingBehaviorReducer.jsx";
import ClassReadingBehaviourState from "../../Redux_Reducers/ClassReadingBehaviourReducer.jsx";
import School_RB_Reducer from "../../Redux_Reducers/School_RB_Reducer.jsx";
import SchoolFAReducer from "../../Redux_Reducers/School_FA_Reducer.jsx";
import DistrictFAReducer from "../../Redux_Reducers/District_FA_Reducer.jsx";
import SummaryTabReducer from '../../Redux_Reducers/SummaryTabReducer.jsx';
import SummaryFilterReducer from "../../Redux_Reducers/SummaryFilterReducer.jsx";
import PersistanceReducer from '../../Redux_Reducers/PersistanceReducer';
import hardSet from "redux-persist/lib/stateReconciler/hardSet";

import ComparisonReducer from "../../Redux_Reducers/ComparisonReducer";
import ST_AnalysisReducer from "../../Redux_Reducers/ST_AnalysisReducer";
import SummaryReducer from '../../Redux_Reducers/SummaryReducer';
import BatchPrintReducer from '../../Redux_Reducers/BatchPrintReducer';
import SpotPrintReducer from '../../Redux_Reducers/SpotPrintReducer';
import { persistReducer, createMigrate } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import { migrations } from './ConfigStore';
import SummaryReports from '../../Redux_Reducers/SummaryReportsReducer';
import LastActiveReportsUniversalProps from '../../Redux_Reducers/LastActiveReportsUniversalProps.js'

const UniversalPersistConfig = {
  key: "Universal",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
  // blacklist: ['isFirstLoad', 'FooterOpen', 'ContextHeader']
};

const ReportsReducer_Persist_Config = {
  key: "Report",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const StudentReport_Persist_Config = {
  key: "Student",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const school_Persist_Config = {
  key: "School",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const District_Persist_Config = {
  key: "District",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const TestStatus_Persist_Config = {
  key: 'TestStatus',
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true }),
}

const TestStatusPrint_Persist_Config = {
  key: 'TestStatusPrint',
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true }),
}

const Authe_Persist_Config = {
  key: "Auth",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const Compare_Persist_Config = {
  key: "Compare",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const SingleTest_Persist_config = {
  key: "SingleTest",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const Date_Reducer_Persist_Config = {
  key: "Date",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const ClassGrouping_Persist_Config = {
  key: "ClassGrouping",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};
const Summary_Persist_Config = {
  key: "summary",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};
const summaryReports_Config = {
  key: "summaryReports",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
}
const SpotPrintReducer_Config = {
  key: "SpotPrintReducer",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};

const BatchPrintReducer_Config = {
  key: "BatchPrintReducer",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
};
const ReportsPersistConfig = {
  key: "Reports",
  storage: storage,
  blacklist: ["callByLazyLoad"]
};

const LastActiveUniversalPropsPersistConfig = {
  key: " LastActiveUniversalProps",
  storage: storage,
  version: 0,
  stateReconciler: hardSet,
  migrate: createMigrate(migrations, { debug: true })
}

export default combineReducers({
  // ClassReducer: ClassReducerStore,
  Universal: persistReducer(UniversalPersistConfig, UniversalSelectorReducer),
  DateTabReducer: persistReducer(Date_Reducer_Persist_Config, DateTabReducer),
  Reports: persistReducer(ReportsReducer_Persist_Config, ReportsReducer),
  Authentication: persistReducer(Authe_Persist_Config, AuthenticationReducer),
  StudentReports: persistReducer(
    StudentReport_Persist_Config,
    StudentReportReducer
  ),
  ComparisonReducer: persistReducer(Compare_Persist_Config, ComparisonReducer),
  schoolReducer: persistReducer(school_Persist_Config, schoolReducer),
  DistrictReducer: persistReducer(District_Persist_Config, DistrictReducer),
  TestStatusReducer: persistReducer(TestStatus_Persist_Config, TestStatusReducer),
  TestStatusPrintReducer: TestStatusPrintReducer, // persistReducer(TestStatusPrint_Persist_Config, TestStatusPrintReducer),
  Summary: persistReducer(Summary_Persist_Config, SummaryReducer),
  SummaryReports: persistReducer(summaryReports_Config, SummaryReports),
  SingleTestAnalysis: ST_AnalysisReducer,//persistReducer(SingleTest_Persist_config,ST_AnalysisReducer),
  //BatchPrintReducer: BatchPrintReducer,
  //SpotPrintReducer: SpotPrintReducer,
  SpotPrintReducer: persistReducer(SpotPrintReducer_Config, SpotPrintReducer),
  BatchPrintReducer: persistReducer(BatchPrintReducer_Config, BatchPrintReducer),
  ComparisonReducer: persistReducer(Compare_Persist_Config, ComparisonReducer),
  ClassGroupingReducer: persistReducer(ClassGrouping_Persist_Config, ClassGroupingReducer),
  LastActiveUniversalProps: persistReducer(LastActiveUniversalPropsPersistConfig, LastActiveReportsUniversalProps),
  // Universal: UniversalSelectorReducer,
  // DateTabReducer: DateTabReducer,
  // Reports: ReportsReducer,
  // Authentication: AuthenticationReducer,
  // StudentReports: StudentReportReducer,
  // ComparisonReducer: ComparisonReducer,
  // schoolReducer: schoolReducer,

  FilterData: FilterDataReducer,
  ReadingHistory: ReadingHistoryReducer,
  ErrorAnalysis: ErrorAnalysisReducer,
  classReadingHistory: classReadingHistoryReducer,
  classFluency: ClassFluencyReducer,
  CommonFilterDetails: CommonFilterReducer,
  ClassGridRlpData: ClassGridRlpReducer,
  SchoolRlpData: SchoolRlpReducer,
  DistrictRlpData1: DistrictRlpReducer,
  districtReadingHistory: DistrictReadingHistoryReducer,
  ClassEaData: ClassErrorAnalysisReducer,
  StudentFluencyData: StudentFluencyReducer,
  StudentRlpData: StudentRlpReducer,
  C_GroupingReducer: C_GroupingReducer,
  SchoolErrorAnalysisData: SchoolErrorAnalysisReducer,
  schoolReadingHistory: schoolReadingHistoryReducer,
  StudentRbData: StudentReadingBehaviorReducer,
  CRB_State: ClassReadingBehaviourState,
  School_FA_Reducer: SchoolFAReducer,
  District_FA_Reducer: DistrictFAReducer,
  School_RB_State: School_RB_Reducer,
  SummaryTabReducer: SummaryTabReducer,
  PersistanceReducer: PersistanceReducer,
  SummaryFilterDetails: SummaryFilterReducer,
});
