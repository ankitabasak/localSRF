import {
  ComparisonTypes,
  STD_PERF_COMPARISONPOPUP_CANCLE_OR_APPLY,
  CLICK_ON_COMPARISON_ITEM,
  CLICK_ON_STD_TEST_IN_COMPARISON,
  GET_CS_COMPARISIONTAB_DATA_SUCCESS,
  GET_ORIGINAL_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS,
  GET_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS,
  COMPARE_POPUP_APPLY_ACTION_SUCCESS,
  GET_ASSESSMENT_COUNT_IN_COMPARISON,
  GET_GRADES_FOR_COMPARISON_SUCCESS,
  GET_STRADS_IN_COMPARISON_SUCCESS,
  GET_STRADS_IN_COMPARISON,
  COMPARE_POPUP_APPLY_ACTION_FAIL,
} from "../Reducer_Action_Types/ComparisonTypes";
import {
  COMPARE_CONTEXT_SELECTION,
  GET_TEST_TAB_RESULTS_SUCCESS,
  GET_INITIAL_APPLICATION_DATA_SUCCESS,
  APPLY_FILTERS_IN_ROSTER_TAB,
  RETURN_TO_PREVIOUS_REPORT_UNIVERSAL,
  SAVE_CONTEXT_SELECTION,
  APPLY_FILTERS_IN_TEST_TAB,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import {
  Student_ReportActionTypes,
  GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD,
} from "../Reducer_Action_Types/Student_ReportTypes";
import {
  Report_Action_Types,
  GET_STANDARDPERFORMANCE_DETAIL_SUCCESS,
  TEST_GRADE_LIST_OF_CLASS_SUCCESS,
} from "../Reducer_Action_Types/ReportsActionTypes";
import {
  School_Action_Types,
  GET_SCHOOL_STRAND_DETAILS_SUCCESS,
  GET_SCHOOL_STRANDS_GRADES_SUCCESS,
} from "../Reducer_Action_Types/School_Report_Types";
import {
  SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT,
  GET_DISTRICT_STRAND_DETAILS_SUCCESS,
  GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS,
} from "../Reducer_Action_Types/District_Report_Types";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { Mathceil } from "./UniversalSelectorReducer";
import { COUNT_PER_PAGE_IN_COMPARE_REPORTS } from "../Utils/globalVars";
import { ComparisionPopUp_Apply_Or_Cancle_Action } from "./Return_Compare_Reducer_State_Methods";
import {
  Sort_ApiResponse_Payload_Array,
  GetPrevItemToPersistIn_Compare,
  sortTaxonomyDataBasedOnUserPrefferences,
  calculate_And_Round_Avg,
  verifyGradeInCompare,
} from "../Components/ReusableComponents/AllReusableFunctions";

export const Nav_strands_Count_perPage_ = 8;

const INITIAL_STATE = {
  CompareDeepLink_Enabled: false,
  Orig_Ass_Count_Success: false,
  lastActiveContext: "",
  studentComparison: {
    Std_Comparison: {
      DeepLinking: false,
      C_ApiCalls: {
        loadingComparison: false,
      },
      PopupFilter: {
        C_SP_ApiCalls: {
          getGrades: true,
          getassessed_Ques: true,
          getreal_q_filter: false,
          getStrands: false,
          call_q_api: false,
          loader_on_grade: false,
          loader_on_assessed_que: true,
          loader_on_strads: false,
        },
        TaxonomyParams: {
          OpenDropDown: false,
          selectedTaxonomy_temp: "",
          selectedTaxonomy: "",
          TaxonomyList: [],
          TaxonomyList_temp: [],
        },
        SetValues: [],
        GradeParams: {
          OpenDropDown: false,
          selectedGrade_temp: "",
          selectedGrade: "",
          gradetoPersist: "",
          GradeList: [],
          GradeList_temp: [],
        },
        QuestionParams: {
          OpenDropDown: false,
          selectedTestAssessment_temp: 1,
          selectedTestAssessment: 1,
          questionToPersist: 1,
          QuestionList: [],
          QuestionList_temp: [],
        },
        Strands_And_Standards: {
          OpenDropDown: false,
          Original_List: [],
          Original_List_temp: [],
          strands: {
            selected_Strands_Standardards: [],
            selectedStrands_temp: [],
            selectedStrands_temp_beta: [],
            showDescription: false,
          },
        },
        enableDoneBtn: false,
        openPopup: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        classAvg: 0,
        schoolAvg: 0,
        districtAvg: 0,
        navigation: {
          navigationLeft: 0,
          navigationRight: Nav_strands_Count_perPage_,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
    Ts_Comparison: {
      ApiCalls: {
        loadingComparison_Data: true,
        getTestscore: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        navigation: {
          navigationLeft: 0,
          navigationRight: 5,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
  },
  classComparison: {
    Std_Comparison: {
      DeepLinking: false,
      C_ApiCalls: {
        loadingComparison: true,
      },
      PopupFilter: {
        C_SP_ApiCalls: {
          getGrades: true,
          getassessed_Ques: true,
          getreal_q_filter: true,
          getStrands: false,
          call_q_api: false,
          loader_on_grade: false,
          loader_on_assessed_que: true,
          loader_on_strads: false,
        },
        TaxonomyParams: {
          OpenDropDown: false,
          selectedTaxonomy_temp: "",
          selectedTaxonomy: "",
          TaxonomyList: [],
          TaxonomyList_temp: [],
        },
        GradeParams: {
          OpenDropDown: false,
          selectedGrade_temp: "",
          selectedGrade: "",
          gradetoPersist: "",
          GradeList: [],
          GradeList_temp: [],
        },
        SetValues: [],
        QuestionParams: {
          OpenDropDown: false,
          selectedTestAssessment_temp: 1,
          selectedTestAssessment: 1,
          questionToPersist: 1,
          QuestionList: [],
          QuestionList_temp: [],
        },
        Strands_And_Standards: {
          OpenDropDown: false,
          Original_List: [],
          Original_List_temp: [],
          strands: {
            selected_Strands_Standardards: [],
            selectedStrands_temp: [],
            selectedStrands_temp_beta: [],
            showDescription: false,
          },
        },

        enableDoneBtn: false,

        openPopup: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        classAvg: 0,
        schoolAvg: 0,
        districtAvg: 0,
        navigation: {
          navigationLeft: 0,
          navigationRight: Nav_strands_Count_perPage_,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
    Ts_Comparison: {
      ApiCalls: {
        getTestscore: true,
        loadingComparison_Data: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        navigation: {
          navigationLeft: 0,
          navigationRight: 5,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
  },
  schoolComparison: {
    gradesChangeStatus: false,
    Std_Comparison: {
      DeepLinking: false,
      C_ApiCalls: {
        loadingComparison: false,
      },
      PopupFilter: {
        C_SP_ApiCalls: {
          getGrades: true,
          getassessed_Ques: true,
          getreal_q_filter: true,
          getStrands: false,
          call_q_api: false,
          loader_on_grade: false,
          loader_on_assessed_que: true,
          loader_on_strads: false,
        },
        TaxonomyParams: {
          OpenDropDown: false,
          selectedTaxonomy_temp: "",
          selectedTaxonomy: "",
          TaxonomyList: [],
          TaxonomyList_temp: [],
        },
        SetValues: [],
        GradeParams: {
          OpenDropDown: false,
          selectedGrade_temp: "",
          selectedGrade: "",
          gradetoPersist: "",
          GradeList: [],
          GradeList_temp: [],
        },
        QuestionParams: {
          OpenDropDown: false,
          selectedTestAssessment_temp: 1,
          selectedTestAssessment: 1,
          questionToPersist: 1,
          QuestionList: [],
          QuestionList_temp: [],
        },
        Strands_And_Standards: {
          OpenDropDown: false,
          Original_List: [],
          Original_List_temp: [],
          strands: {
            selected_Strands_Standardards: [],
            selectedStrands_temp: [],
            selectedStrands_temp_beta: [],
            showDescription: false,
          },
        },

        enableDoneBtn: false,

        openPopup: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        classAvg: 0,
        schoolAvg: 0,
        districtAvg: 0,
        navigation: {
          navigationLeft: 0,
          navigationRight: Nav_strands_Count_perPage_,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
    Ts_Comparison: {
      ApiCalls: {
        loadingComparison_Data: true,
        getTestscore: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        navigation: {
          navigationLeft: 0,
          navigationRight: 5,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
  },
  districtComparison: {
    Std_Comparison: {
      C_ApiCalls: {
        loadingComparison: false,
      },
      PopupFilter: {
        C_SP_ApiCalls: {
          getGrades: true,
          getassessed_Ques: true,
          getreal_q_filter: false,
          getStrands: false,
          call_q_api: false,
          loader_on_grade: false,
          loader_on_assessed_que: true,
          loader_on_strads: false,
        },
        TaxonomyParams: {
          OpenDropDown: false,
          selectedTaxonomy_temp: "",
          selectedTaxonomy: "",
          TaxonomyList: [],
          TaxonomyList_temp: [],
        },
        SetValues: [],
        GradeParams: {
          OpenDropDown: false,
          selectedGrade_temp: "",
          selectedGrade: "",
          gradetoPersist: "",
          GradeList: [],
          GradeList_temp: [],
        },
        QuestionParams: {
          OpenDropDown: false,
          selectedTestAssessment_temp: 1,
          selectedTestAssessment: 1,
          questionToPersist: 1,
          QuestionList: [],
          QuestionList_temp: [],
        },
        Strands_And_Standards: {
          OpenDropDown: false,
          Original_List: [],
          Original_List_temp: [],
          strands: {
            selected_Strands_Standardards: [],
            selectedStrands_temp: [],
            selectedStrands_temp_beta: [],
            showDescription: false,
          },
        },
        enableDoneBtn: false,

        openPopup: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        classAvg: 0,
        schoolAvg: 0,
        districtAvg: 0,
        navigation: {
          navigationLeft: 0,
          navigationRight: Nav_strands_Count_perPage_,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
    Ts_Comparison: {
      ApiCalls: {
        loadingComparison_Data: true,
        getTestscore: true,
      },
      ComparisonData: {
        OrginalData: [],
        Operational_Data: [],
        navigation: {
          navigationLeft: 0,
          navigationRight: 5,
        },
        sortingOptions: {
          sortType: "",
          sortOn: "studentList",
          sortBy: "lastName",
          SortOrder: "ASC",
        },
        pagination: {
          currentPageNumber: 1,
          countPerPage: 10,
          totalPageCount: 1,
        },
        compareOptions: {
          checkDistrict: false,
          checkSchool: false,
          checkClass: false,
        },
      },
    },
  },
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case AuthActionTypes.POST_CREATE_JWT_TOKEN:
      return INITIAL_STATE;

    case ComparisonTypes.OPEN_COMPARISON_POPUP:
      return openComparisonPopUp(state, action);

    case ComparisonTypes.EDIT_COMPARISON_POPUP:
      return editComparisonPopUp(state, action);

    case CLICK_ON_COMPARISON_ITEM:
      return CompareDrillDown_Redux_Fun(state, action);

    case SAVE_CONTEXT_SELECTION:
      let lastActiveContext = state.lastActiveContext;
      const { persist_compare_checkboxes, Modified_State, selectionoption } =
        action.payload;
      let Modified_Nav = Modified_State.NavigationByHeaderSelection;
      let From_Different_Context =
        selectionoption === "school" ||
        selectionoption === "class" ||
        selectionoption === "student" ||
        selectionoption === "district";
      if (!From_Different_Context && selectionoption === "comparison") {
        let CurrentFilter = Modified_Nav.student
          ? state.studentComparison.Std_Comparison.PopupFilter
          : Modified_Nav.class
          ? state.classComparison.Std_Comparison.PopupFilter
          : Modified_Nav.school
          ? state.schoolComparison.Std_Comparison.PopupFilter
          : state.districtComparison.Std_Comparison.PopupFilter;

        From_Different_Context =
          CurrentFilter.TaxonomyParams.selectedTaxonomy !==
            CurrentFilter.TaxonomyParams.selectedTaxonomy_temp ||
          CurrentFilter.QuestionParams.selectedTestAssessment !==
            CurrentFilter.QuestionParams.selectedTestAssessment_temp ||
          (CurrentFilter.GradeParams.selectedGrade &&
            CurrentFilter.GradeParams.selectedGrade_temp &&
            CurrentFilter.GradeParams.selectedGrade.grade !==
              CurrentFilter.GradeParams.selectedGrade_temp.grade);
      } else {
        let testsorStdApi =
          Modified_State.ApiCalls.getTests ||
          (Modified_Nav.student && Modified_State.ApiCalls.getStudentData_cls);
        let CompareApis =
          selectionoption === "district"
            ? state.districtComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
            : selectionoption === "school"
            ? state.schoolComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
            : selectionoption === "class"
            ? state.classComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
            : selectionoption === "student"
            ? state.studentComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
            : false;
        if (!testsorStdApi && CompareApis) {
          let Apiis_Active =
            CompareApis.getGrades ||
            CompareApis.getStrands ||
            CompareApis.getassessed_Ques;
          lastActiveContext = Apiis_Active
            ? lastActiveContext
            : selectionoption;
        }
      }

      if (
        action.payload.Nav.comparison &&
        (Modified_State.ApiCalls.getTests ||
          (Modified_Nav.student && Modified_State.ApiCalls.getStudentData_cls))
      ) {
        let compareDeepLink =
          (Modified_State.ApiCalls.getTests ||
            (Modified_Nav.student &&
              Modified_State.ApiCalls.getStudentData_cls)) &&
          From_Different_Context;

        /**
         * To enable PopUp In Compare Screen
         */
        return CompareDrillDown_Redux_Fun(
          state,
          action,
          compareDeepLink,
          Modified_Nav,
          Modified_State.ApiCalls,
          lastActiveContext
        );
      } else if (action.payload.Nav.T_scores) {
        return updatePeristRelatedCheckBoxes(state, action);
      } else {
        let persistedQno = action.payload.Nav.district
          ? state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
              .selectedTestAssessment_temp
          : action.payload.Nav.school
          ? state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
              .selectedTestAssessment_temp
          : action.payload.Nav.class
          ? state.classComparison.Std_Comparison.PopupFilter.QuestionParams
              .selectedTestAssessment_temp
          : state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
              .selectedTestAssessment_temp;
        let CompareDeepLink_Enabled = state.CompareDeepLink_Enabled;
        if (Modified_Nav.comparison) {
          let stdApis =
            state.studentComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls;
          CompareDeepLink_Enabled =
            CompareDeepLink_Enabled ||
            (Modified_Nav.student
              ? stdApis.getGrades ||
                stdApis.getassessed_Ques ||
                stdApis.getStrands
              : Modified_Nav.class
              ? state.classComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
                  .getGrades ||
                state.classComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
                  .getStrands
              : Modified_Nav.school
              ? state.schoolComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
                  .getGrades ||
                state.schoolComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
                  .getStrands
              : state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls.getGrades ||
                state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls.getStrands);
        }

        return {
          ...state,
          CompareDeepLink_Enabled:
            CompareDeepLink_Enabled && From_Different_Context,
          lastActiveContext: lastActiveContext,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              DeepLinking:
                Modified_Nav.student && Modified_Nav.comparison
                  ? true
                  : state.studentComparison.Std_Comparison.DeepLinking,
              ComparisonData: {
                ...state.studentComparison.Std_Comparison.ComparisonData,
                compareOptions: {
                  ...state.studentComparison.Std_Comparison.ComparisonData
                    .compareOptions,
                  checkDistrict: persist_compare_checkboxes.checkDistrict,
                  checkSchool: persist_compare_checkboxes.checkSchool,
                  checkClass: persist_compare_checkboxes.checkClass,
                },
              },
            },
          },
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              DeepLinking:
                Modified_Nav.class && Modified_Nav.comparison
                  ? true
                  : state.classComparison.Std_Comparison.DeepLinking,
              ComparisonData: {
                ...state.classComparison.Std_Comparison.ComparisonData,
                compareOptions: {
                  ...state.classComparison.Std_Comparison.ComparisonData
                    .compareOptions,
                  checkDistrict: persist_compare_checkboxes.checkDistrict,
                  checkSchool: persist_compare_checkboxes.checkSchool,
                  checkClass: persist_compare_checkboxes.checkClass,
                },
              },
            },
          },
          schoolComparison: {
            ...state.schoolComparison,

            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              DeepLinking:
                Modified_Nav.school && Modified_Nav.comparison
                  ? true
                  : state.schoolComparison.Std_Comparison.DeepLinking,
              ComparisonData: {
                ...state.schoolComparison.Std_Comparison.ComparisonData,
                compareOptions: {
                  ...state.schoolComparison.Std_Comparison.ComparisonData
                    .compareOptions,
                  checkDistrict: persist_compare_checkboxes.checkDistrict,
                  checkSchool: persist_compare_checkboxes.checkSchool,
                  checkClass: persist_compare_checkboxes.checkClass,
                },
              },
            },
          },
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              ComparisonData: {
                ...state.districtComparison.Std_Comparison.ComparisonData,
                compareOptions: {
                  ...state.districtComparison.Std_Comparison.ComparisonData
                    .compareOptions,
                  checkDistrict: persist_compare_checkboxes.checkDistrict,
                  checkSchool: persist_compare_checkboxes.checkSchool,
                  checkClass: persist_compare_checkboxes.checkClass,
                },
              },
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                openPopup:
                  CompareDeepLink_Enabled && From_Different_Context
                    ? false
                    : state.districtComparison.Std_Comparison.PopupFilter
                        .openPopup,
              },
            },
          },
        };
      }

    case RETURN_TO_PREVIOUS_REPORT_UNIVERSAL:
      return {
        ...state,
        CompareDeepLink_Enabled: false,
        Orig_Ass_Count_Success: true,
      };

    case CLICK_ON_STD_TEST_IN_COMPARISON:
      let ApiCall = action.payload.SameStudent
        ? state.studentComparison.Ts_Comparison.ApiCalls.getTestscore
        : true;

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Ts_Comparison: {
            ...state.studentComparison.Ts_Comparison,
            ApiCalls: {
              ...state.studentComparison.Ts_Comparison.ApiCalls,
              loadingComparison_Data: ApiCall,
              getTestscore: ApiCall,
            },
          },
        },
      };
    case COMPARE_CONTEXT_SELECTION:
      return {
        ...state,
      };

    case ComparisonTypes.COMPARISON_DROPDOWN_TOGGLE:
      return returnResultDropDownStatus(state, action);

    case GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD:
      return {
        ...state,
        // ,
        // studentComparison: {
        //     ...state.studentComparison,
        //     Std_Comparison: INITIAL_STATE.studentComparison.Std_Comparison
        // }
      };
    case Student_ReportActionTypes.GET_STUDENTS_TESTSCORES_SUCCESS:
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Ts_Comparison: INITIAL_STATE.studentComparison.Ts_Comparison,
        },
      };
    case Report_Action_Types.GET_CLASS_TESTSCORES_DETAIL_SUCCESS:
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Ts_Comparison: INITIAL_STATE.classComparison.Ts_Comparison,
        },
      };

    case GET_SCHOOL_STRANDS_GRADES_SUCCESS:
      let PreviousNav = action.payload.PreviousRepo_Nav;
      let Currentnav = action.payload.CurrentNav;

      if (action.payload.PayloadData.length !== 0 && Currentnav.comparison) {
        let { LastGrade, LastQuestion } = Get_GradeAndQuestionOfLAtReprorts(
          state,
          PreviousNav,
          Currentnav
        );
        let find = action.payload.PayloadData.find(
          (item) => item.grade == LastGrade.grade
        );

        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                C_SP_ApiCalls: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter,
                  getassessed_Ques: true,
                },
                GradeParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  gradetoPersist: LastGrade,
                  selectedGrade_temp: find
                    ? LastGrade
                    : state.schoolComparison.Std_Comparison.PopupFilter
                        .GradeParams.selectedGrade_temp,
                },
                QuestionParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  questionToPersist: LastQuestion,
                },
              },
            },
          },
        };
      } else {
        return {
          ...state,
        };
      }

    case TEST_GRADE_LIST_OF_CLASS_SUCCESS:
      if (action.payload.PayloadData.length !== 0) {
        let { LastGrade, LastQuestion } = Get_GradeAndQuestionOfLAtReprorts(
          state,
          action.payload.PreviousRepo_Nav,
          action.payload.CurrentNav
        );
        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                GradeParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  gradetoPersist: LastGrade,
                },
                QuestionParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  questionToPersist: LastQuestion,
                },
              },
            },
          },
        };
      } else {
        return {
          ...state,
        };
      }

    case GET_SCHOOL_STRAND_DETAILS_SUCCESS:
      if (action.payload.Data !== null) {
        return {
          ...state,
        };
      } else {
        return {
          ...state,
        };
      }

    case GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS:
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Ts_Comparison: INITIAL_STATE.districtComparison.Ts_Comparison,
        },
      };

    case GET_STANDARDPERFORMANCE_DETAIL_SUCCESS:
      return { ...state };

    case GET_DISTRICT_STRAND_DETAILS_SUCCESS:
      return {
        ...state,
        // ,
        // districtComparison: {
        //     ...state.districtComparison,
        //     Std_Comparison: INITIAL_STATE.districtComparison.Std_Comparison
        // }
      };

    case Student_ReportActionTypes.SELECTED_TEST_TAXONOMY_DROPDOWN_STUDENT:
      return {
        ...state,
        // ,
        // studentComparison: {
        //     ...state.studentComparison,
        //     Ts_Comparison: INITIAL_STATE.studentComparison.Ts_Comparison
        // }
      };

    case Report_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_CLASS:
      return {
        ...state,
        // ,
        // classComparison: {
        //     ...state.classComparison,
        //     Std_Comparison: INITIAL_STATE.classComparison.Std_Comparison
        // }
      };
    // return {
    //     ...state,
    //     classComparison: {
    //         ...state.classComparison,
    //         Std_Comparison: {
    //             ...state.classComparison.Std_Comparison,
    //             PopupFilter: {
    //                 ...state.classComparison.Std_Comparison.PopupFilter,
    //                 TaxonomyParams: {
    //                     ...state.classComparison.Std_Comparison.PopupFilter.TaxonomyParams,
    //                     selectedTaxonomy_temp: action.payload
    //                 },
    //             }
    //         }
    //     }
    // }

    case School_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_SCHOOL:
      return {
        ...state,
        // ,
        // schoolComparison: {
        //     ...state.schoolComparison,
        //     Std_Comparison: INITIAL_STATE.schoolComparison.Std_Comparison
        // }
      };

    case SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT:
      return {
        ...state,
        // ,
        // districtComparison: {
        //     ...state.districtComparison,
        //     Std_Comparison: INITIAL_STATE.districtComparison.Std_Comparison
        // }
      };

    case ComparisonTypes.COMPARE_POPUP_SELECT_STRAND:
      return returnSelectedStrandsStatus(state, action);

    case ComparisonTypes.COMPARE_DONE_IN_STRANDS:
      return returnDone_in_strands_selection(state, action);

    case ComparisonTypes.COMPARE_REMOVE_STRAND_BY_CLICK_ON_SPAN:
      return RemovestrandOnSpanClick(state, action);

    case ComparisonTypes.COMPARE_POPUP_SELECT_STANDARDS:
      return SelectStrands_selection(state, action);
    case ComparisonTypes.COMPARE_POPUP_STRANDS_CHECK_ALL:
      return compare_strands_check_all(state, action);

    case ComparisonTypes.COMPARE_POPUP_APPLY_ACTION:
      return apply_action_comparison(state, action);

    case COMPARE_POPUP_APPLY_ACTION_FAIL:
      return comparison_Apply_API_fail(state, action);
    case COMPARE_POPUP_APPLY_ACTION_SUCCESS:
      return apply_action_comparison_success(state, action);

    case ComparisonTypes.COMPARE_CHECK_COMPARE_OPTION:
      return checkedCheckBoxOptions(state, action);

    case ComparisonTypes.SORT_COMPARE_BASED_ON_PARAM:
      return sortCompareBasedOnParam(state, action);
    case ComparisonTypes.GET_CS_COMPARISIONTAB_DATA:
      return get_ts_comparison_API_trigger(state, action);

    case GET_CS_COMPARISIONTAB_DATA_SUCCESS:
      return get_ts_comparison_API_trigger_success(state, action);

    case ComparisonTypes.COMPARE_PAGE_STANDARDS_NAV:
      return navigationStandardStrandsArrows(state, action);
    case ComparisonTypes.COMPARISON_SELECTED_PAGE_DISPLAY:
      return selectedPagetoMove(state, action);
    case ComparisonTypes.COMPARISON_SELECTED_GRADE:
      return selectedGrade(state, action);
    case ComparisonTypes.COMPARISON_SELECTED_QNUMBER:
      return selectedQuestion(state, action);

    case GET_ASSESSMENT_COUNT_IN_COMPARISON:
      return Get_AssessmentCountComparison(state, action);
    case GET_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS:
      return Get_AssessmentCountComparisonSuccess(state, action);

    case ComparisonTypes.GET_ORIGINAL_ASSESSMENT_COUNT_IN_COMPARISON:
      return Get_Original_AssessmentCountComparison(state, action);
    case GET_ORIGINAL_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS:
      return Get_Original_AssessmentCountComparisonSuccess(state, action);

    case GET_STRADS_IN_COMPARISON:
      return GetStrands_In_Comparison(state, action);
    case GET_STRADS_IN_COMPARISON_SUCCESS:
      return GetStrands_In_Comparison_Success(state, action);
    case ComparisonTypes.COMPARISON_SELECTED_TAXONOMY:
      return selectedTaxonomy(state, action);

    case GET_TEST_TAB_RESULTS_SUCCESS:
      let testPayload = action.payload.Response;
      let Nav = action.payload.Nav;

      if (testPayload != null && !action.payload.Nav.test_status) {
        let Modified_State = action.payload.UniversalSelector;
        let { updatedLastActivePropsState } = action.payload;

        let DistrictcontextChanged = true;
        let SchoolcontextChanged = true;
        let classcontextChanged = true;
        let studentcontextChanged = true;

        if (state.schoolComparison.gradesChangeStatus) {
          SchoolcontextChanged = true;
        }

        let DistrictState = INITIAL_STATE.districtComparison;
        let SchoolState = INITIAL_STATE.schoolComparison;
        let ClassState = INITIAL_STATE.classComparison;
        let StudentState = INITIAL_STATE.studentComparison;

        if (Nav.district && DistrictcontextChanged) {
          if (Nav.S_performance) {
            DistrictState.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp =
              state.districtComparison.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp;
            DistrictState.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp =
              state.districtComparison.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp;
            DistrictState.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp =
              state.districtComparison.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp;

            return {
              ...state,
              districtComparison: DistrictState,
            };
          } else {
            return {
              ...state,
              districtComparison: {
                ...state.districtComparison,
                Ts_Comparison: DistrictState.Ts_Comparison,
              },
            };
          }
        } else if (Nav.school && SchoolcontextChanged) {
          let ClaaData_OfSameSChool =
            Modified_State.ContextHeader.Roster_Tab.SelectedSchool.id ==
            updatedLastActivePropsState.Class_Report.selectedSchool.id;
          let DeepLinking = state.CompareDeepLink_Enabled
            ? true
            : state.schoolComparison.Std_Comparison.DeepLinking;

          if (Nav.S_performance) {
            SchoolState.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp =
              state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp;
            SchoolState.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp =
              state.schoolComparison.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp;
            SchoolState.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp =
              state.schoolComparison.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp;
            return {
              ...state,
              CompareDeepLink_Enabled: DeepLinking,
              schoolComparison: SchoolState,
              classComparison: ClaaData_OfSameSChool
                ? state.classComparison
                : ClassState,
            };
          } else {
            return {
              ...state,
              schoolComparison: {
                ...state.schoolComparison,
                Ts_Comparison: {
                  ...state.schoolComparison.Ts_Comparison,
                  ApiCalls: {
                    ...state.schoolComparison.Ts_Comparison.ApiCalls,
                    getTestscore: true,
                    loadingComparison_Data: true,
                  },
                },
              },
            };
          }
        } else if (Nav.class && classcontextChanged) {
          let StdData_OfSameClass =
            Modified_State.ContextHeader.Roster_Tab.SelectedClass.id ==
            updatedLastActivePropsState.Student_Report.selectedClass.id;

          let DeepLinking = state.CompareDeepLink_Enabled
            ? true
            : state.classComparison.Std_Comparison.DeepLinking;
          if (Nav.S_performance) {
            ClassState.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp =
              state.classComparison.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp;
            ClassState.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp =
              state.classComparison.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp;
            ClassState.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp =
              state.classComparison.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp;
            return {
              ...state,
              CompareDeepLink_Enabled: DeepLinking,
              classComparison: ClassState,
              studentComparison: StdData_OfSameClass
                ? state.studentComparison
                : StudentState,
            };
          } else {
            return {
              ...state,
              classComparison: {
                ...state.classComparison,
                Ts_Comparison: {
                  ...state.classComparison.Ts_Comparison,
                  ApiCalls: {
                    ...state.classComparison.Ts_Comparison.ApiCalls,
                    getTestscore: true,
                    loadingComparison_Data: true,
                  },
                },
              },
            };
          }
        } else if (Nav.student && studentcontextChanged) {
          // student
          let DeepLinking = state.CompareDeepLink_Enabled
            ? true
            : state.studentComparison.Std_Comparison.DeepLinking;
          if (Nav.S_performance) {
            StudentState.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp =
              state.studentComparison.Std_Comparison.PopupFilter.QuestionParams.selectedTestAssessment_temp;
            StudentState.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp =
              state.studentComparison.Std_Comparison.PopupFilter.GradeParams.selectedGrade_temp;
            StudentState.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp =
              state.studentComparison.Std_Comparison.PopupFilter.TaxonomyParams.selectedTaxonomy_temp;
            return {
              ...state,
              CompareDeepLink_Enabled: DeepLinking,
              studentComparison: StudentState,
            };
          } else {
            return {
              ...state,
              studentComparison: {
                ...state.studentComparison,
                Ts_Comparison: {
                  ...state.studentComparison.Ts_Comparison,
                  ApiCalls: {
                    ...state.studentComparison.Ts_Comparison.ApiCalls,
                    getTestscore: true,
                    loadingComparison_Data: true,
                  },
                },
              },
            };
          }
        } else {
          return {
            ...state,
          };
        }
      } else {
        return {
          ...state,
        };
      }

    case ComparisonTypes.GET_GRADES_IN_COMPARISON:
      return getGradesOnTrigger(state, action);

    case ComparisonTypes.GET_GRADES_FOR_COMPARISON:
      return getGradesForComparison(state, action);

    case GET_GRADES_FOR_COMPARISON_SUCCESS:
      return getGradesForComparisonSuccess(state, action);

    case STD_PERF_COMPARISONPOPUP_CANCLE_OR_APPLY:
      return ComparisionPopUp_Apply_Or_Cancle_Action(state, action);

    case ComparisonTypes.COMPARE_CANCEL_IN_STRANDS:
      return ComparisonCancel_In_Strands(state, action);

    case APPLY_FILTERS_IN_ROSTER_TAB:
      if (
        action.payload.StateToSet.NavigationByHeaderSelection.Summary_Reports
      ) {
        return {
          ...state,
        };
      }
      let U_selector = action.payload.U_selector;

      const SelectedGrade =
        U_selector.UniversalSelecter.Roster_Data.SelectedGrade;
      const selectedRosterGrade =
        U_selector.ContextHeader.Roster_Tab.selectedRosterGrade;
      if (selectedRosterGrade == SelectedGrade) {
        return {
          ...state,
        };
      } else {
        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            gradesChangeStatus: true,
          },
        };
      }

    case APPLY_FILTERS_IN_TEST_TAB:
      let On_TestTabApply = true;
      return getGradesOnTrigger(state, action, On_TestTabApply);
    case GET_INITIAL_APPLICATION_DATA_SUCCESS:
      return {
        ...state,
        districtComparison: INITIAL_STATE.districtComparison,
        schoolComparison: INITIAL_STATE.schoolComparison,
        classComparison: INITIAL_STATE.classComparison,
        studentComparison: INITIAL_STATE.studentComparison,
      };

    default:
      return {
        ...state,
      };
  }
};

function ComparisonCancel_In_Strands(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp_beta:
                    state.districtComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands.selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp_beta:
                    state.schoolComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands.selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp_beta:
                    state.classComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands.selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    // In Student Context Fix
    return {
      ...state,
      studentComparison: {
        ...state.studentComparison,
        Std_Comparison: {
          ...state.studentComparison.Std_Comparison,
          PopupFilter: {
            ...state.studentComparison.Std_Comparison.PopupFilter,
            Strands_And_Standards: {
              ...state.studentComparison.Std_Comparison.PopupFilter
                .Strands_And_Standards,
              OpenDropDown: false,
              strands: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards.strands,
                selectedStrands_temp_beta:
                  state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands.selectedStrands_temp,
              },
            },
          },
        },
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

export function updatePeristRelatedCheckBoxes(state, action) {
  const { ts_compare_checkboxes } = action.payload;
  return {
    ...state,
    studentComparison: {
      ...state.studentComparison,
      Ts_Comparison: {
        ...state.studentComparison.Ts_Comparison,
        ApiCalls: {
          ...state.studentComparison.Ts_Comparison.ApiCalls,
          getTestscore:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.studentComparison.Ts_Comparison.ApiCalls.getTestscore,

          loadingComparison_Data:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.studentComparison.Ts_Comparison.ApiCalls
                  .loadingComparison_Data,
        },
        ComparisonData: {
          ...state.studentComparison.Ts_Comparison.ComparisonData,
          compareOptions: {
            ...state.studentComparison.Ts_Comparison.ComparisonData
              .compareOptions,
            checkDistrict: ts_compare_checkboxes.checkDistrict,
            checkSchool: ts_compare_checkboxes.checkSchool,
            checkClass: ts_compare_checkboxes.checkClass,
          },
        },
      },
    },
    classComparison: {
      ...state.classComparison,
      Ts_Comparison: {
        ...state.classComparison.Ts_Comparison,
        ApiCalls: {
          ...state.classComparison.Ts_Comparison.ApiCalls,
          getTestscore:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.classComparison.Ts_Comparison.ApiCalls.getTestscore,

          loadingComparison_Data:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.classComparison.Ts_Comparison.ApiCalls
                  .loadingComparison_Data,
        },
        ComparisonData: {
          ...state.classComparison.Ts_Comparison.ComparisonData,
          compareOptions: {
            ...state.classComparison.Ts_Comparison.ComparisonData
              .compareOptions,
            checkDistrict: ts_compare_checkboxes.checkDistrict,
            checkSchool: ts_compare_checkboxes.checkSchool,
            checkClass: ts_compare_checkboxes.checkClass,
          },
        },
      },
    },
    schoolComparison: {
      ...state.schoolComparison,
      Ts_Comparison: {
        ...state.schoolComparison.Ts_Comparison,

        ApiCalls: {
          ...state.schoolComparison.Ts_Comparison.ApiCalls,
          getTestscore:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.schoolComparison.Ts_Comparison.ApiCalls.getTestscore,

          loadingComparison_Data:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.schoolComparison.Ts_Comparison.ApiCalls
                  .loadingComparison_Data,
        },

        ComparisonData: {
          ...state.schoolComparison.Ts_Comparison.ComparisonData,
          compareOptions: {
            ...state.schoolComparison.Ts_Comparison.ComparisonData
              .compareOptions,
            checkDistrict: ts_compare_checkboxes.checkDistrict,
            checkSchool: ts_compare_checkboxes.checkSchool,
            checkClass: ts_compare_checkboxes.checkClass,
          },
        },
      },
    },
    districtComparison: {
      ...state.districtComparison,
      Ts_Comparison: {
        ...state.districtComparison.Ts_Comparison,
        ApiCalls: {
          ...state.districtComparison.Ts_Comparison.ApiCalls,
          getTestscore:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.districtComparison.Ts_Comparison.ApiCalls.getTestscore,

          loadingComparison_Data:
            action.payload.TestsModified == true
              ? action.payload.TestsModified
              : state.districtComparison.Ts_Comparison.ApiCalls
                  .loadingComparison_Data,
        },
        ComparisonData: {
          ...state.districtComparison.Ts_Comparison.ComparisonData,
          compareOptions: {
            ...state.districtComparison.Ts_Comparison.ComparisonData
              .compareOptions,
            checkDistrict: ts_compare_checkboxes.checkDistrict,
            checkSchool: ts_compare_checkboxes.checkSchool,
            checkClass: ts_compare_checkboxes.checkClass,
          },
        },
      },
    },
  };
}

function getGradesForComparisonSuccess(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let GradeList = action.payload.PayloadData;
  const { sp_persistance } = action.payload;
  const { sp_comparison_persistance } = sp_persistance;
  const { persisted_grade } = sp_comparison_persistance;
  if (GradeList.length == 0) {
    return {
      ...state,
    };
  }

  GradeList.sort();

  let SelectedGrade = GetPrevItemToPersistIn_Compare(
    state,
    action.payload.PrevNav,
    action.payload.CurrentNav,
    "grade",
    GradeList,
    "",
    persisted_grade
  );

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      // grades

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                // getStrands: true,
                getassessed_Ques: true,
                loader_on_assessed_que: true,
                loader_on_grade: false,
                loader_on_strads: false,
              },
              GradeParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade_temp: SelectedGrade,
                selectedGrade: SelectedGrade,
                GradeList: GradeList,
                GradeList_temp: GradeList,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      // grades

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                getassessed_Ques: true,
                loader_on_assessed_que: true,
                loader_on_grade: false,
                loader_on_strads: false,
              },
              GradeParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade_temp: SelectedGrade,
                selectedGrade: SelectedGrade,
                GradeList: GradeList,
                GradeList_temp: GradeList,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      // grades

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                // getStrands: true,
                getassessed_Ques: true,
                loader_on_assessed_que: true,
                loader_on_grade: false,
                loader_on_strads: false,
              },
              GradeParams: {
                ...state.classComparison.Std_Comparison.PopupFilter.GradeParams,
                selectedGrade_temp: SelectedGrade,
                selectedGrade: SelectedGrade,
                GradeList: GradeList,
                GradeList_temp: GradeList,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                // getStrands: true,
                getassessed_Ques: true,
                loader_on_assessed_que: true,
                loader_on_grade: false,
                loader_on_strads: false,
              },
              GradeParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade_temp: SelectedGrade,
                selectedGrade: SelectedGrade,
                GradeList: GradeList,
                GradeList_temp: GradeList,
              },
            },
          },
        },
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function getGradesForComparison(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                getStrands: false,
                getassessed_Ques: false,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                getStrands: false,
                getassessed_Ques: false,
                loadingComparison: true,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                getStrands: false,
                getassessed_Ques: false,
                loadingComparison: true,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: false,
                getStrands: false,
                getassessed_Ques: false,
                loadingComparison: true,
              },
            },
          },
        },
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function getGradesOnTrigger(state, action, On_TestTabApply) {
  let Nav = action.payload.Nav;

  if (Nav.district) {
    if (Nav.T_scores || On_TestTabApply) {
      return {
        ...state,
        districtComparison: INITIAL_STATE.districtComparison,
      };
    } else if (Nav.S_performance && Nav.comparison) {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              openPopup: true,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: true,
                loader_on_grade: true,
              },
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: [],
              },
            },
            ComparisonData:
              INITIAL_STATE.districtComparison.Std_Comparison.ComparisonData,
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (Nav.school) {
    if (Nav.T_scores || On_TestTabApply) {
      return {
        ...state,
        schoolComparison: INITIAL_STATE.schoolComparison,
      };
    } else if (Nav.S_performance && Nav.comparison) {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              openPopup: true,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: true,
                loader_on_grade: true,
              },
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: [],
              },
            },
            ComparisonData:
              INITIAL_STATE.schoolComparison.Std_Comparison.ComparisonData,
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (Nav.class) {
    if (Nav.T_scores || On_TestTabApply) {
      return {
        ...state,
        classComparison: INITIAL_STATE.classComparison,
      };
    } else if (Nav.S_performance && Nav.comparison) {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              openPopup: true,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: true,
                loader_on_grade: true,
              },
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: [],
              },
            },
            ComparisonData:
              INITIAL_STATE.classComparison.Std_Comparison.ComparisonData,
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (Nav.student) {
    if (Nav.T_scores || On_TestTabApply) {
      return {
        ...state,
        studentComparison: INITIAL_STATE.studentComparison,
      };
    } else if (Nav.S_performance && Nav.comparison) {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              openPopup: true,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: true,
                loader_on_grade: true,
              },
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: [],
              },
            },
            ComparisonData:
              INITIAL_STATE.studentComparison.Std_Comparison.ComparisonData,
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function get_ts_comparison_API_trigger_success(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let compareOptions = action.payload.compareOptions;
  let TotalPages = 0;
  let ListObje =
    action.payload.PayloadData == null ? {} : action.payload.PayloadData;
  if (ListObje.students !== undefined && ListObje.students !== null) {
    TotalPages = Mathceil(
      ListObje.students.length,
      COUNT_PER_PAGE_IN_COMPARE_REPORTS
    );
  }
  if (ListObje.classes !== undefined && ListObje.classes !== null) {
    TotalPages = Mathceil(
      ListObje.classes.length,
      COUNT_PER_PAGE_IN_COMPARE_REPORTS
    );
  }
  if (ListObje.schools !== undefined && ListObje.schools !== null) {
    TotalPages = Mathceil(
      ListObje.schools.length,
      COUNT_PER_PAGE_IN_COMPARE_REPORTS
    );
  }

  if (fromContext == "district") {
    ListObje.schools = Sort_ApiResponse_Payload_Array(
      ListObje.schools,
      "school_listOnTS"
    );

    return {
      ...state,
      districtComparison: {
        ...state.districtComparison,
        Ts_Comparison: {
          ...state.districtComparison.Ts_Comparison,
          ApiCalls: {
            ...state.districtComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: false,
          },
          ComparisonData: {
            ...state.districtComparison.Ts_Comparison.ComparisonData,
            OrginalData: { ...ListObje },
            Operational_Data: { ...ListObje },
            pagination: {
              ...state.districtComparison.Ts_Comparison.ComparisonData
                .pagination,
              currentPageNumber: 1,
              countPerPage: 10,
              totalPageCount: TotalPages,
            },
            compareOptions: {
              ...state.districtComparison.Ts_Comparison.ComparisonData
                .compareOptions,
              checkDistrict: compareOptions.checkDistrict,
              checkSchool: compareOptions.checkSchool,
              checkClass: compareOptions.checkClass,
            },
          },
        },
      },
    };
  } else if (fromContext == "school") {
    ListObje.classes = Sort_ApiResponse_Payload_Array(
      ListObje.classes,
      "classlistOnTS"
    );

    return {
      ...state,
      schoolComparison: {
        ...state.schoolComparison,
        Ts_Comparison: {
          ...state.schoolComparison.Ts_Comparison,
          ApiCalls: {
            ...state.schoolComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: false,
          },
          ComparisonData: {
            ...state.schoolComparison.Ts_Comparison.ComparisonData,
            OrginalData: { ...ListObje },
            Operational_Data: { ...ListObje },
            pagination: {
              ...state.schoolComparison.Ts_Comparison.ComparisonData.pagination,
              currentPageNumber: 1,
              countPerPage: 10,
              totalPageCount: TotalPages,
            },
            compareOptions: {
              ...state.schoolComparison.Ts_Comparison.ComparisonData
                .compareOptions,
              checkDistrict: compareOptions.checkDistrict,
              checkSchool: compareOptions.checkSchool,
              checkClass: compareOptions.checkClass,
            },
          },
        },
      },
    };
  } else if (fromContext == "class") {
    ListObje.students = Sort_ApiResponse_Payload_Array(
      ListObje.students,
      "studentslist"
    );

    return {
      ...state,
      classComparison: {
        ...state.classComparison,
        Ts_Comparison: {
          ...state.classComparison.Ts_Comparison,
          ApiCalls: {
            ...state.classComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: false,
          },
          ComparisonData: {
            ...state.classComparison.Ts_Comparison.ComparisonData,
            OrginalData: { ...ListObje },
            Operational_Data: { ...ListObje },
            pagination: {
              ...state.classComparison.Ts_Comparison.ComparisonData.pagination,
              currentPageNumber: 1,
              countPerPage: 10,
              totalPageCount: TotalPages,
            },
            compareOptions: {
              ...state.classComparison.Ts_Comparison.ComparisonData
                .compareOptions,
              checkDistrict: compareOptions.checkDistrict,
              checkSchool: compareOptions.checkSchool,
              checkClass: compareOptions.checkClass,
            },
          },
        },
      },
    };
  } else if (fromContext == "student") {
    return {
      ...state,
      studentComparison: {
        ...state.studentComparison,
        Ts_Comparison: {
          ...state.studentComparison.Ts_Comparison,
          ApiCalls: {
            ...state.studentComparison.Ts_Comparison.ApiCalls,
            loadingComparison_Data: false,
          },
          ComparisonData: {
            ...state.studentComparison.Ts_Comparison.ComparisonData,
            OrginalData: { ...ListObje },
            Operational_Data: { ...ListObje },
            pagination: {
              ...state.studentComparison.Ts_Comparison.ComparisonData
                .pagination,
              currentPageNumber: 1,
              countPerPage: 10,
              totalPageCount: TotalPages,
            },
            compareOptions: {
              ...state.studentComparison.Ts_Comparison.ComparisonData
                .compareOptions,
              checkDistrict: compareOptions.checkDistrict,
              checkSchool: compareOptions.checkSchool,
              checkClass: compareOptions.checkClass,
            },
          },
        },
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

function get_ts_comparison_API_trigger(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    return {
      ...state,
      districtComparison: {
        ...state.districtComparison,
        Ts_Comparison: {
          ...state.districtComparison.Ts_Comparison,
          ApiCalls: {
            ...state.districtComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: true,
          },
        },
      },
    };
  } else if (fromContext == "school") {
    return {
      ...state,
      schoolComparison: {
        ...state.schoolComparison,
        Ts_Comparison: {
          ...state.schoolComparison.Ts_Comparison,
          ApiCalls: {
            ...state.schoolComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: true,
          },
        },
      },
    };
  } else if (fromContext == "class") {
    return {
      ...state,
      classComparison: {
        ...state.classComparison,
        Ts_Comparison: {
          ...state.classComparison.Ts_Comparison,
          ApiCalls: {
            ...state.classComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: true,
          },
        },
      },
    };
  } else if (fromContext == "student") {
    return {
      ...state,
      studentComparison: {
        ...state.studentComparison,
        Ts_Comparison: {
          ...state.studentComparison.Ts_Comparison,
          ApiCalls: {
            ...state.studentComparison.Ts_Comparison.ApiCalls,
            getTestscore: false,
            loadingComparison_Data: true,
          },
        },
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

function selectedTaxonomy(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let taxonomy = action.payload.taxonomy;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let taxonomyRelatedStrands = Get_taxonomy_relatedStrands(
        taxonomy,
        state.districtComparison.Std_Comparison.PopupFilter
          .Strands_And_Standards.Original_List_temp
      );

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              TaxonomyParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: taxonomy,
              },
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let taxonomyRelatedStrands = Get_taxonomy_relatedStrands(
        taxonomy,
        state.schoolComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .Original_List_temp
      );

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              TaxonomyParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: taxonomy,
              },
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let taxonomyRelatedStrands = Get_taxonomy_relatedStrands(
        taxonomy,
        state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .Original_List_temp
      );

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              TaxonomyParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: taxonomy,
              },
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let taxonomyRelatedStrands = Get_taxonomy_relatedStrands(
        taxonomy,
        state.studentComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .Original_List_temp
      );

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              TaxonomyParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: taxonomy,
              },
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function editComparisonPopUp(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let currentStatus = action.payload.currentStatus;

  if (fromContext == "district") {
    return {
      ...state,
      districtComparison: {
        ...state.districtComparison,
        Std_Comparison: {
          ...state.districtComparison.Std_Comparison,
          PopupFilter: {
            ...state.districtComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
            C_SP_ApiCalls: {
              ...state.districtComparison.Std_Comparison.PopupFilter
                .C_SP_ApiCalls,
              getreal_q_filter: false,
            },
          },
        },
      },
    };
  } else if (fromContext == "school") {
    return {
      ...state,
      schoolComparison: {
        ...state.schoolComparison,
        Std_Comparison: {
          ...state.schoolComparison.Std_Comparison,
          PopupFilter: {
            ...state.schoolComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
            C_SP_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.PopupFilter
                .C_SP_ApiCalls,
              getreal_q_filter: false,
            },
          },
        },
      },
    };
  } else if (fromContext == "class") {
    return {
      ...state,
      classComparison: {
        ...state.classComparison,
        Std_Comparison: {
          ...state.classComparison.Std_Comparison,
          PopupFilter: {
            ...state.classComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
            C_SP_ApiCalls: {
              ...state.classComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls,
              getreal_q_filter: false,
              //                             loader_on_grade: false,
              // loader_on_assessed_que: false,
              // loader_on_strads: false
            },
          },
        },
      },
    };
  } else if (fromContext == "student") {
    return {
      ...state,
      studentComparison: {
        ...state.studentComparison,
        Std_Comparison: {
          ...state.studentComparison.Std_Comparison,
          PopupFilter: {
            ...state.studentComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
            C_SP_ApiCalls: {
              ...state.studentComparison.Std_Comparison.PopupFilter
                .C_SP_ApiCalls,
              getreal_q_filter: false,
            },
          },
        },
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

function openComparisonPopUp(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let currentStatus = action.payload.currentStatus;

  if (fromContext == "district") {
    return {
      ...state,
      districtComparison: {
        ...state.districtComparison,
        Std_Comparison: {
          ...state.districtComparison.Std_Comparison,
          PopupFilter: {
            ...state.districtComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
          },
        },
      },
    };
  } else if (fromContext == "school") {
    return {
      ...state,
      schoolComparison: {
        ...state.schoolComparison,
        Std_Comparison: {
          ...state.schoolComparison.Std_Comparison,
          PopupFilter: {
            ...state.schoolComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
          },
        },
      },
    };
  } else if (fromContext == "class") {
    return {
      ...state,
      classComparison: {
        ...state.classComparison,
        Std_Comparison: {
          ...state.classComparison.Std_Comparison,
          PopupFilter: {
            ...state.classComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
          },
        },
      },
    };
  } else if (fromContext == "student") {
    return {
      ...state,
      studentComparison: {
        ...state.studentComparison,
        Std_Comparison: {
          ...state.studentComparison.Std_Comparison,
          PopupFilter: {
            ...state.studentComparison.Std_Comparison.PopupFilter,
            openPopup: currentStatus,
          },
        },
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

function GetStrands_In_Comparison(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              // loadingComparison: true
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: false,
                loader_on_strads: true,
                loader_on_assessed_que: true,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              // loadingComparison: true
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: false,
                loader_on_strads: true,
              },
            },
          },
        },
      };
    } else {
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              // loadingComparison: true
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: false,
                loader_on_strads: true,
              },
            },
          },
        },
      };
    } else {
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              // loadingComparison: true
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: false,
                loader_on_strads: true,
              },
            },
          },
        },
      };
    } else {
    }
  } else {
    return {
      ...state,
    };
  }
}

function Get_all_taxonomiesOfStrands(strandsList) {
  let taxonomyList = [];

  strandsList.map((strand) => {
    strand.standards.map((single_standard) => {
      taxonomyList.push(single_standard.taxonomy);
    });
  });

  let TotalTaxonomyList = [...new Set(taxonomyList)];

  TotalTaxonomyList.sort();

  return TotalTaxonomyList;
}

function Get_all_SetValues(strandsList) {
  let SetValues = [];

  strandsList.map((strand) => {
    strand.standards.map((single_standard) => {
      SetValues.push({
        setId: single_standard.setId,
        taxonomy: single_standard.taxonomy,
      });
    });
  });

  let TotalSetValues = multiDimensionalUnique(SetValues);

  return TotalSetValues;
}

function Get_taxonomy_relatedStrands(taxonomy, strandsList) {
  let returnedStrandList = "";

  returnedStrandList = strandsList
    .map((strand) => {
      return {
        ...strand,
        standards: [
          ...strand.standards.filter(
            (single_taxonomy_standard) =>
              single_taxonomy_standard.taxonomy == taxonomy
          ),
        ],
      };
    })
    .filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

  returnedStrandList = calculateStrandAvgOnTaxonimy_Filter(returnedStrandList);

  return returnedStrandList;
}

function GetStrands_In_Comparison_Success(state, action) {
  let { sp_persistance } = action.payload;
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let PayloadData =
    action.payload.PayloadData != null ? action.payload.PayloadData : [];
  let UserPreferences = action.payload.UserPreferences;
  if (PayloadData.length == 1) {
    PayloadData.map((singleStrand, index) => {
      singleStrand.check = true;
      return singleStrand.standards.map((singleStandards) => {
        singleStandards.check =
          state.CompareDeepLink_Enabled && state.Orig_Ass_Count_Success; //   false
      });
    });
  } else {
    PayloadData.map((singleStrand, index) => {
      singleStrand.check = true;
      return singleStrand.standards.map((singleStandards) => {
        singleStandards.check = true;
      });
    });
  }

  let taxonomyList = Get_all_taxonomiesOfStrands(PayloadData);
  let SetValues = Get_all_SetValues(PayloadData);

  if (
    UserPreferences !== null &&
    UserPreferences != undefined &&
    UserPreferences.standardsetorders.length > 0
  ) {
    taxonomyList = sortTaxonomyDataBasedOnUserPrefferences(
      UserPreferences,
      SetValues
    );
  }
  let CurrentNav = action.payload.CurrentNav;
  let PopupFilter = CurrentNav.district
    ? state.districtComparison.Std_Comparison.PopupFilter
    : CurrentNav.school
    ? state.schoolComparison.Std_Comparison.PopupFilter
    : CurrentNav.class
    ? state.classComparison.Std_Comparison.PopupFilter
    : state.studentComparison.Std_Comparison.PopupFilter;
  let Prev_Context = state.lastActiveContext;
  let Prev_ContextPopupFilter =
    Prev_Context === "student"
      ? state.studentComparison.Std_Comparison.PopupFilter
      : Prev_Context === "school"
      ? state.schoolComparison.Std_Comparison.PopupFilter
      : Prev_Context === "class"
      ? state.classComparison.Std_Comparison.PopupFilter
      : state.districtComparison.Std_Comparison.PopupFilter;

  let Tax_To_Persist =
    sp_persistance.sp_comparison_persistance.persisted_view != null
      ? sp_persistance.sp_comparison_persistance.persisted_view
      : PopupFilter.TaxonomyParams.selectedTaxonomy_temp;
  let SelectedTaxonomy = GetPrevItemToPersistIn_Compare(
    state,
    action.payload.PrevNav,
    CurrentNav,
    "taxonomy",
    taxonomyList,
    Tax_To_Persist
  );

  let taxonomyRelatedStrands = Get_taxonomy_relatedStrands(
    SelectedTaxonomy,
    PayloadData
  );

  let openpopUP =
    state.CompareDeepLink_Enabled && state.Orig_Ass_Count_Success
      ? false
      : undefined;

  let Prev_SS_Standardards =
    Prev_ContextPopupFilter.Strands_And_Standards.strands
      .selected_Strands_Standardards;
  taxonomyRelatedStrands &&
    taxonomyRelatedStrands.length > 1 &&
    Prev_SS_Standardards &&
    taxonomyRelatedStrands.map((item) => {
      let find = Prev_SS_Standardards.find(
        (item1) => item1.strandName === item.strandName
      );
      if (find && find.check !== undefined) {
        item.check = find.check;
      }
    });

  if (taxonomyRelatedStrands.length > 0 && Prev_SS_Standardards.length > 0) {
    Prev_SS_Standardards = Prev_SS_Standardards.filter((item) => item.check);

    taxonomyRelatedStrands.map((item, index) => {
      let currentStandards = item.standards;
      let prevStrand =
        Prev_SS_Standardards &&
        Prev_SS_Standardards.find(
          (item1) => item1.strandName === item.strandName
        );
      if (prevStrand === undefined) {
        //  item.check = false;
      }
      let prevStandards = prevStrand && prevStrand.standards;
      prevStandards &&
        currentStandards &&
        currentStandards.map((item1, indx) => {
          let findPrev = prevStandards.find(
            (item) => item.standardId == item1.standardId
          );
          if (findPrev && findPrev.check !== undefined) {
            item1.check = findPrev.check;
          } else if (findPrev === undefined) {
            let STrandsCurrent =
              PopupFilter.Strands_And_Standards.strands
                .selected_Strands_Standardards;
            let exist =
              STrandsCurrent &&
              STrandsCurrent.length == 1 &&
              STrandsCurrent[0].standards &&
              STrandsCurrent[0].standards.find(
                (item) => item.standardId == item1.standardId
              );
            if (exist && exist.check !== undefined) {
              item1.check = exist.check;
            }
          }
        });
    });
  }
  let selectedTestAssessment_temp =
    sp_persistance.sp_comparison_persistance.persisted_qno;
  let gradeFromPersist =
    sp_persistance.sp_comparison_persistance.persisted_grade != null
      ? sp_persistance.sp_comparison_persistance.persisted_grade
      : PopupFilter.GradeParams.selectedGrade_temp;
  let persisted_grade = verifyGradeInCompare(
    state,
    fromContext,
    gradeFromPersist
  );
  let Orig_Ass_Count_Success = state.CompareDeepLink_Enabled
    ? true
    : state.Orig_Ass_Count_Success;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: Orig_Ass_Count_Success,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_strads: false,
                loader_on_assessed_que: false,
              },
              TaxonomyParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: SelectedTaxonomy,
                TaxonomyList_temp: taxonomyList,
              },
              QuestionParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment_temp: selectedTestAssessment_temp,
                questionToPersist: selectedTestAssessment_temp,
              },
              GradeParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade_temp: persisted_grade,
              },
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List_temp: PayloadData,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                  selected_Strands_Standardards: state.CompareDeepLink_Enabled
                    ? taxonomyRelatedStrands
                    : state.districtComparison.Std_Comparison.PopupFilter
                        .Strands_And_Standards.strands
                        .selected_Strands_Standardards,
                  showDescription: state.CompareDeepLink_Enabled
                    ? Prev_ContextPopupFilter.Strands_And_Standards.strands
                        .showDescription
                    : false,
                },
              },
              SetValues: SetValues,
              openPopup:
                openpopUP == undefined
                  ? state.districtComparison.Std_Comparison.PopupFilter
                      .openPopup
                  : openpopUP,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: Orig_Ass_Count_Success,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_strads: false,
                loader_on_assessed_que: false,
              },
              TaxonomyParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: SelectedTaxonomy,
                TaxonomyList_temp: taxonomyList,
              },
              QuestionParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment_temp: selectedTestAssessment_temp,
                questionToPersist: selectedTestAssessment_temp,
              },
              GradeParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade_temp: persisted_grade,
              },
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List_temp: PayloadData,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,

                  selected_Strands_Standardards: state.CompareDeepLink_Enabled
                    ? taxonomyRelatedStrands
                    : state.schoolComparison.Std_Comparison.PopupFilter
                        .Strands_And_Standards.strands
                        .selected_Strands_Standardards,
                  showDescription: state.CompareDeepLink_Enabled
                    ? Prev_ContextPopupFilter.Strands_And_Standards.strands
                        .showDescription
                    : false,
                },
              },
              SetValues: SetValues,
              openPopup:
                openpopUP == undefined
                  ? state.schoolComparison.Std_Comparison.PopupFilter.openPopup
                  : openpopUP,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: Orig_Ass_Count_Success,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_strads: false,
                loader_on_assessed_que: false,
              },
              TaxonomyParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: SelectedTaxonomy,
                TaxonomyList_temp: taxonomyList,
              },
              QuestionParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment_temp: selectedTestAssessment_temp,
                questionToPersist: selectedTestAssessment_temp,
              },
              GradeParams: {
                ...state.classComparison.Std_Comparison.PopupFilter.GradeParams,
                selectedGrade_temp: persisted_grade,
              },
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List_temp: PayloadData,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                  selected_Strands_Standardards: state.CompareDeepLink_Enabled
                    ? taxonomyRelatedStrands
                    : state.classComparison.Std_Comparison.PopupFilter
                        .Strands_And_Standards.strands
                        .selected_Strands_Standardards,

                  showDescription: state.CompareDeepLink_Enabled
                    ? Prev_ContextPopupFilter.Strands_And_Standards.strands
                        .showDescription
                    : false,
                },
              },
              SetValues: SetValues,
              openPopup:
                openpopUP == undefined
                  ? state.classComparison.Std_Comparison.PopupFilter.openPopup
                  : openpopUP,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: Orig_Ass_Count_Success,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_strads: false,
                loader_on_assessed_que: false,
              },
              TaxonomyParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                OpenDropDown: false,
                selectedTaxonomy_temp: SelectedTaxonomy,
                TaxonomyList_temp: taxonomyList,
              },
              QuestionParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment_temp: selectedTestAssessment_temp,
                questionToPersist: selectedTestAssessment_temp,
              },
              GradeParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade_temp: persisted_grade,
              },
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List_temp: PayloadData,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: taxonomyRelatedStrands,
                  selectedStrands_temp_beta: taxonomyRelatedStrands,
                  selected_Strands_Standardards: state.CompareDeepLink_Enabled
                    ? taxonomyRelatedStrands
                    : state.studentComparison.Std_Comparison.PopupFilter
                        .Strands_And_Standards.strands
                        .selected_Strands_Standardards,

                  showDescription: state.CompareDeepLink_Enabled
                    ? Prev_ContextPopupFilter.Strands_And_Standards.strands
                        .showDescription
                    : false,
                },
              },
              SetValues: SetValues,
              openPopup:
                openpopUP == undefined
                  ? state.studentComparison.Std_Comparison.PopupFilter.openPopup
                  : openpopUP,
            },
          },
        },
      };
    } else {
      // Testscore
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function Get_AssessmentCountComparison(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getassessed_Ques: false,
                getreal_q_filter: false,

                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getassessed_Ques: false,
                getreal_q_filter: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getassessed_Ques: false,
                getreal_q_filter: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getassessed_Ques: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function Get_AssessmentCountComparisonSuccess(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let PayloadData = returnListFromMaxCount(action.payload.PayloadData);
  let PrevNav = action.payload.PrevNav;
  let QesToPersist;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      QesToPersist =
        state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment_temp;
      if (!(QesToPersist && PayloadData.length > QesToPersist)) {
        QesToPersist = 1;
      }
      return {
        ...state,
        Orig_Ass_Count_Success: true,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
                getStrands: true,
                loader_on_strads: false,
              },
              QuestionParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: QesToPersist,
                questionToPersist: QesToPersist,
                selectedTestAssessment: QesToPersist,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      QesToPersist =
        state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment_temp;
      if (!(QesToPersist && PayloadData.length > QesToPersist)) {
        QesToPersist = 1;
      }
      return {
        ...state,
        Orig_Ass_Count_Success: true,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
                getStrands: true,
                loader_on_strads: false,
              },
              QuestionParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: QesToPersist,
                questionToPersist: QesToPersist,
                selectedTestAssessment: QesToPersist,

                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      QesToPersist =
        state.classComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment_temp;
      if (!(QesToPersist && PayloadData.length > QesToPersist)) {
        QesToPersist = 1;
      }

      return {
        ...state,
        Orig_Ass_Count_Success: true,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
                getStrands: true,
                loader_on_strads: false,
              },
              QuestionParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: QesToPersist,
                questionToPersist: QesToPersist,
                selectedTestAssessment: QesToPersist,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      QesToPersist =
        state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment_temp;
      if (!(QesToPersist && PayloadData.length > QesToPersist)) {
        QesToPersist = 1;
      }
      return {
        ...state,
        Orig_Ass_Count_Success: true,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
                getStrands: true,
                loader_on_strads: false,
              },
              QuestionParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: QesToPersist,
                questionToPersist: QesToPersist,
                selectedTestAssessment: QesToPersist,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function Get_Original_AssessmentCountComparison(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: false,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getreal_q_filter: false,
                getassessed_Ques: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: false,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getreal_q_filter: false,
                getassessed_Ques: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: false,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getreal_q_filter: false,
                getassessed_Ques: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        Orig_Ass_Count_Success: false,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getreal_q_filter: false,
                getassessed_Ques: false,
                loader_on_assessed_que: true,
                loader_on_strads: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function Get_Original_AssessmentCountComparisonSuccess(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let PayloadData = returnListFromMaxCount(action.payload.PayloadData);

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      ActiveQues_ =
        PayloadData.length >
        state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
          .questionToPersist
          ? state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
              .questionToPersist
          : 1;

      return {
        ...state,
        Orig_Ass_Count_Success: true,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
              },
              QuestionParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,

                QuestionList: PayloadData,
                selectedTestAssessment_temp: ActiveQues_,
                questionToPersist: ActiveQues_,
                selectedTestAssessment: ActiveQues_,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      ActiveQues_ =
        PayloadData.length >
        state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
          .questionToPersist
          ? state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
              .questionToPersist
          : 1;

      return {
        ...state,
        Orig_Ass_Count_Success: true,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
              },
              QuestionParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: ActiveQues_,
                questionToPersist: ActiveQues_,
                selectedTestAssessment: ActiveQues_,

                QuestionList: PayloadData,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      ActiveQues_ =
        PayloadData.length >
        state.classComparison.Std_Comparison.PopupFilter.QuestionParams
          .questionToPersist
          ? state.classComparison.Std_Comparison.PopupFilter.QuestionParams
              .questionToPersist
          : 1;

      return {
        ...state,
        Orig_Ass_Count_Success: true,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
              },
              QuestionParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: ActiveQues_,
                questionToPersist: ActiveQues_,
                selectedTestAssessment: ActiveQues_,
                QuestionList: PayloadData,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      ActiveQues_ =
        PayloadData.length >
        state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
          .questionToPersist
          ? state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
              .questionToPersist
          : 1;

      return {
        ...state,
        Orig_Ass_Count_Success: true,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: false,
              },
              QuestionParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: ActiveQues_,
                questionToPersist: ActiveQues_,
                selectedTestAssessment: ActiveQues_,
                QuestionList: PayloadData,
                QuestionList_temp: PayloadData,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function selectedQuestion(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let selectedQuestion = action.payload.selectedQuestion;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              QuestionParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: selectedQuestion,
              },
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: true,
                call_q_api: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              QuestionParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: selectedQuestion,
              },
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: true,
                call_q_api: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              QuestionParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: selectedQuestion,
              },
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: true,
                call_q_api: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              QuestionParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: selectedQuestion,
              },
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getStrands: true,
                call_q_api: false,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function selectedGrade(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let selectedGrade = action.payload.selectedGrade;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              GradeParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                OpenDropDown: false,
                selectedGrade_temp: selectedGrade,
              },
              QuestionParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: 1,
              },
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: true,
                getassessed_Ques: true,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              GradeParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                OpenDropDown: false,
                selectedGrade_temp: selectedGrade,
              },
              QuestionParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: 1,
              },
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: true,
                // getStrands: true,
                // call_q_api: true,
                getassessed_Ques: true,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              GradeParams: {
                ...state.classComparison.Std_Comparison.PopupFilter.GradeParams,
                OpenDropDown: false,
                selectedGrade_temp: selectedGrade,
              },
              QuestionParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: 1,
              },
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: true,
                getassessed_Ques: true,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              GradeParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                OpenDropDown: false,
                selectedGrade_temp: selectedGrade,
              },
              QuestionParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                OpenDropDown: false,
                selectedTestAssessment_temp: 1,
              },
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                loader_on_assessed_que: true,
                getassessed_Ques: true,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function selectedPagetoMove(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let pageNumber = action.payload.pageNumber;
  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            ComparisonData: {
              ...state.districtComparison.Std_Comparison.ComparisonData,
              pagination: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Ts_Comparison: {
            ...state.districtComparison.Ts_Comparison,
            ComparisonData: {
              ...state.districtComparison.Ts_Comparison.ComparisonData,
              pagination: {
                ...state.districtComparison.Ts_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Std_Comparison.ComparisonData,
              pagination: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Ts_Comparison: {
            ...state.schoolComparison.Ts_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Ts_Comparison.ComparisonData,
              pagination: {
                ...state.schoolComparison.Ts_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            ComparisonData: {
              ...state.classComparison.Std_Comparison.ComparisonData,
              pagination: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Ts_Comparison: {
            ...state.classComparison.Ts_Comparison,
            ComparisonData: {
              ...state.classComparison.Ts_Comparison.ComparisonData,
              pagination: {
                ...state.classComparison.Ts_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            ComparisonData: {
              ...state.studentComparison.Std_Comparison.ComparisonData,
              pagination: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .pagination,
                currentPageNumber: pageNumber,
              },
            },
          },
        },
      };
    } else {
    }
  } else {
    return {
      ...state,
    };
  }
}

function navigationStandardStrandsArrows(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let NavigationCounters = action.payload.NavigationCounters;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      // Standardperformance context
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            ComparisonData: {
              ...state.districtComparison.Std_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    } else {
      // Testscore Context
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Ts_Comparison: {
            ...state.districtComparison.Ts_Comparison,
            ComparisonData: {
              ...state.districtComparison.Ts_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Std_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    } else {
      // Testscore Context
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Ts_Comparison: {
            ...state.schoolComparison.Ts_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Ts_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            ComparisonData: {
              ...state.classComparison.Std_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    } else {
      // Testscore Context
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Ts_Comparison: {
            ...state.classComparison.Ts_Comparison,
            ComparisonData: {
              ...state.classComparison.Ts_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            ComparisonData: {
              ...state.studentComparison.Std_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Ts_Comparison: {
            ...state.studentComparison.Ts_Comparison,
            ComparisonData: {
              ...state.studentComparison.Ts_Comparison.ComparisonData,
              navigation: {
                navigationLeft: NavigationCounters.NavigationLeftCount,
                navigationRight: NavigationCounters.NavigationRightCount,
              },
            },
          },
        },
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function sortCompareBasedOnParam(state, action) {
  let fromContext = JSON.parse(JSON.stringify(action.payload.fromContext))
    let fromtab = JSON.parse(JSON.stringify(action.payload.fromtab))
    let ParamOnwhichScore = JSON.parse(JSON.stringify(action.payload.ParamOnwhichScore))
    let Strand_Standard_type = JSON.parse(JSON.stringify(action.payload.Strand_Standard_type))
    let Strand_Standard = JSON.parse(JSON.stringify(action.payload.Strand_Standard))
    let orderOfSort = JSON.parse(JSON.stringify(action.payload.orderOfSort))

    function Get_FirstAndLastTotalsFor_Calculate_Avg(Dataobject) {
      let first = 0;
      let Last = 0;
      let DataTocalculate = JSON.parse(JSON.stringify(Dataobject))
      Dataobject && Object.keys(DataTocalculate).map(function (key, index) {
          first += DataTocalculate[key][0];
          Last += DataTocalculate[key][1];
          DataTocalculate[key] = calculate_And_Round_Avg(DataTocalculate[key][0], DataTocalculate[key][1]);
      });
      let AvgIs = calculate_And_Round_Avg(first, Last);
      return { AvgIs, DataTocalculate }
  }
  function ReturnScores(compareData, OrginalData) {
      let Item = compareData && compareData.length > 0 && compareData[0];
      let Forcls, ForSchool, ForDistrict, clsAvg, schoolAvg, DistrictAvg;
      if (Item) {

          Forcls = Get_FirstAndLastTotalsFor_Calculate_Avg(JSON.parse(JSON.stringify(Item.stdScoresForClass)))
          ForSchool = Get_FirstAndLastTotalsFor_Calculate_Avg(JSON.parse(JSON.stringify(Item.stdScoresForSchool)))
          ForDistrict = Get_FirstAndLastTotalsFor_Calculate_Avg(JSON.parse(JSON.stringify(Item.stdScoresForDistrict)))

          clsAvg = Forcls.AvgIs;
          schoolAvg = ForSchool.AvgIs;
          DistrictAvg = ForDistrict.AvgIs;
      }

      return { Forcls, ForSchool, ForDistrict, clsAvg, schoolAvg, DistrictAvg }
  }

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let Operational_Data =
      JSON.parse(JSON.stringify(state.districtComparison.Std_Comparison.ComparisonData.Operational_Data));

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.schoolName < b.schoolName) {
              return -1;
            }
            if (a.schoolName > b.schoolName) {
              return 1;
            }
          } else {
            if (a.schoolName < b.schoolName) {
              return 1;
            }
            if (a.schoolName > b.schoolName) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "studentPercentage") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.schoolPercentage < b.schoolPercentage) {
              return -1;
            }
            if (a.schoolPercentage > b.schoolPercentage) {
              return 1;
            }
          } else {
            if (a.schoolPercentage < b.schoolPercentage) {
              return 1;
            }
            if (a.schoolPercentage > b.schoolPercentage) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "standardAndStrandAvg") {
        Operational_Data.sort(function (a, b) {
          let sort_a = a.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          let sort_b = b.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            if (sort_a > sort_b) {
              return 1;
            }
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            if (sort_a > sort_b) {
              return -1;
            }
          }
          return 0;
        });
      }

      let distScoresRes = ReturnScores(Operational_Data, JSON.parse(JSON.stringify(state.districtComparison.Std_Comparison.ComparisonData.OrginalData)));
            for (let i = 0; Array.isArray(Operational_Data) && i < Operational_Data.length && distScoresRes; i++) {
                Operational_Data[i].stdAvgForClass = distScoresRes.Forcls && distScoresRes.Forcls.DataTocalculate;
                Operational_Data[i].stdAvgForSchool = distScoresRes.ForSchool && distScoresRes.ForSchool.DataTocalculate;
                Operational_Data[i].stdAvgForDistrict = distScoresRes.ForDistrict && distScoresRes.ForDistrict.DataTocalculate;
            }

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            ComparisonData: {
              ...state.districtComparison.Std_Comparison.ComparisonData,
              Operational_Data: JSON.parse(JSON.stringify(Operational_Data)),
              sortingOptions: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
    } else {
      let Operational_Data =
        state.districtComparison.Ts_Comparison.ComparisonData.Operational_Data;

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.schools.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.schoolName < b.schoolName) {
              return -1;
            }
            if (a.schoolName > b.schoolName) {
              return 1;
            }
          } else {
            if (a.schoolName < b.schoolName) {
              return 1;
            }
            if (a.schoolName > b.schoolName) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "studentAvg") {
        Operational_Data.schools.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.schoolAvg < b.schoolAvg) {
              return -1;
            }
            if (a.schoolAvg > b.schoolAvg) {
              return 1;
            }
          } else {
            if (a.schoolAvg < b.schoolAvg) {
              return 1;
            }
            if (a.schoolAvg > b.schoolAvg) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "componentAvg") {
        Operational_Data.schools.sort(function (a, b) {
          let sort_a =
            a.tests.filter((test) => test.componentCode == Strand_Standard)
              .length != 0
              ? a.tests.filter(
                  (test) => test.componentCode == Strand_Standard
                )[0].componentAvg
              : null;
          let sort_b =
            b.tests.filter((test) => test.componentCode == Strand_Standard)
              .length != 0
              ? b.tests.filter(
                  (test) => test.componentCode == Strand_Standard
                )[0].componentAvg
              : null;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            if (sort_a > sort_b) {
              return 1;
            }
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            if (sort_a > sort_b) {
              return -1;
            }
          }
          return 0;
        });
      }

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Ts_Comparison: {
            ...state.districtComparison.Ts_Comparison,
            ComparisonData: {
              ...state.districtComparison.Ts_Comparison.ComparisonData,
              Operational_Data: JSON.parse(JSON.stringify(Operational_Data)),
              sortingOptions: {
                ...state.districtComparison.Ts_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      // Starts From here
      let Operational_Data =
      JSON.parse(JSON.stringify(state.schoolComparison.Std_Comparison.ComparisonData.Operational_Data));

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.className < b.className) {
              return -1;
            }
            else if (a.className > b.className) {
              return 1;
            }else return 0;
          } else {
            if (a.className < b.className) {
              return 1;
            }
            else if (a.className > b.className) {
              return -1;
            } else return 0;
          }
          
        });
      } else if (ParamOnwhichScore == "studentPercentage") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.classPercentage < b.classPercentage) {
              return -1;
            }
            else if (a.classPercentage > b.classPercentage) {
              return 1;
            }else return 0;
          } else {
            if (a.classPercentage < b.classPercentage) {
              return 1;
            }
            else if (a.classPercentage > b.classPercentage) {
              return -1;
            }else return 0;
          }
        });
      } else if (ParamOnwhichScore == "standardAndStrandAvg") {
        Operational_Data.sort(function (a, b) {
          let sort_a = a.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          let sort_b = b.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            else if (sort_a > sort_b) {
              return 1;
            }else return 0;
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            else if (sort_a > sort_b) {
              return -1;
            }else return 0;
          }
        });
      }

      let scoresRes = ReturnScores(Operational_Data, JSON.parse(JSON.stringify(state.schoolComparison.Std_Comparison.ComparisonData.OrginalData)));

            for (let i = 0; Array.isArray(Operational_Data) && i < Operational_Data.length && scoresRes; i++) {
                Operational_Data[i].stdAvgForClass = scoresRes.Forcls && scoresRes.Forcls.DataTocalculate;
                Operational_Data[i].stdAvgForSchool = scoresRes.ForSchool && scoresRes.ForSchool.DataTocalculate;
                Operational_Data[i].stdAvgForDistrict = scoresRes.ForDistrict && scoresRes.ForDistrict.DataTocalculate;
            }

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Std_Comparison.ComparisonData,
              Operational_Data: JSON.parse(JSON.stringify(Operational_Data)),
              sortingOptions: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
    } else {
      let Operational_Data =
        state.schoolComparison.Ts_Comparison.ComparisonData.Operational_Data;

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.classes.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.className < b.className) {
              return -1;
            }
            if (a.className > b.className) {
              return 1;
            }
          } else {
            if (a.className < b.className) {
              return 1;
            }
            if (a.className > b.className) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "studentAvg") {
        Operational_Data.classes.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.classAvg < b.classAvg) {
              return -1;
            }
            if (a.classAvg > b.classAvg) {
              return 1;
            }
          } else {
            if (a.classAvg < b.classAvg) {
              return 1;
            }
            if (a.classAvg > b.classAvg) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "componentAvg") {
        Operational_Data.classes.sort(function (a, b) {
          let sort_a =
            a.tests.filter((test) => test.componentCode == Strand_Standard)
              .length != 0
              ? a.tests.filter(
                  (test) => test.componentCode == Strand_Standard
                )[0].componentAvg
              : null;
          let sort_b =
            b.tests.filter((test) => test.componentCode == Strand_Standard)
              .length != 0
              ? b.tests.filter(
                  (test) => test.componentCode == Strand_Standard
                )[0].componentAvg
              : null;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            if (sort_a > sort_b) {
              return 1;
            }
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            if (sort_a > sort_b) {
              return -1;
            }
          }
          return 0;
        });
      }

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Ts_Comparison: {
            ...state.schoolComparison.Ts_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Ts_Comparison.ComparisonData,
              Operational_Data: Operational_Data,
              sortingOptions: {
                ...state.schoolComparison.Ts_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
      // End From here
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      // Starts From here
      let Operational_Data =
        state.classComparison.Std_Comparison.ComparisonData.Operational_Data;

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.lastName < b.lastName) {
              return -1;
            }
            if (a.lastName > b.lastName) {
              return 1;
            }
          } else {
            if (a.lastName < b.lastName) {
              return 1;
            }
            if (a.lastName > b.lastName) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "studentPercentage") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.studentPercentage < b.studentPercentage) {
              return -1;
            }
            if (a.studentPercentage > b.studentPercentage) {
              return 1;
            }
          } else {
            if (a.studentPercentage < b.studentPercentage) {
              return 1;
            }
            if (a.studentPercentage > b.studentPercentage) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "standardAndStrandAvg") {
        Operational_Data.sort(function (a, b) {
          let sort_a = a.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          let sort_b = b.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            else if (sort_a > sort_b) {
              return 1;
            }else return 0;
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            else if (sort_a > sort_b) {
              return -1;
            }else return 0;
          }
          
        });
      }

      let classScoresRes = ReturnScores(Operational_Data, JSON.parse(JSON.stringify(state.classComparison.Std_Comparison.ComparisonData.OrginalData)));
            for (let i = 0; Array.isArray(Operational_Data) && i < Operational_Data.length && classScoresRes; i++) {
                Operational_Data[i].stdAvgForClass = classScoresRes.Forcls && classScoresRes.Forcls.DataTocalculate;
                Operational_Data[i].stdAvgForSchool = classScoresRes.ForSchool && classScoresRes.ForSchool.DataTocalculate;
                Operational_Data[i].stdAvgForDistrict = classScoresRes.ForDistrict && classScoresRes.ForDistrict.DataTocalculate;
            }

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            ComparisonData: {
              ...state.classComparison.Std_Comparison.ComparisonData,
              Operational_Data: JSON.parse(JSON.stringify(Operational_Data)),
              sortingOptions: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
    } else {
      let Operational_Data =
        state.classComparison.Ts_Comparison.ComparisonData.Operational_Data;

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.students.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.lastName < b.lastName) {
              return -1;
            }
            if (a.lastName > b.lastName) {
              return 1;
            }
          } else {
            if (a.lastName < b.lastName) {
              return 1;
            }
            if (a.lastName > b.lastName) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "studentAvg") {
        Operational_Data.students.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.studentAvg < b.studentAvg) {
              return -1;
            }
            if (a.studentAvg > b.studentAvg) {
              return 1;
            }
          } else {
            if (a.studentAvg < b.studentAvg) {
              return 1;
            }
            if (a.studentAvg > b.studentAvg) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "componentAvg") {
        Operational_Data.students.sort(function (a, b) {
          let sort_a =
            a.tests.filter((test) => test.componentCode == Strand_Standard)
              .length != 0
              ? a.tests.filter(
                  (test) => test.componentCode == Strand_Standard
                )[0].componentAvg
              : null;
          let sort_b =
            b.tests.filter((test) => test.componentCode == Strand_Standard)
              .length != 0
              ? b.tests.filter(
                  (test) => test.componentCode == Strand_Standard
                )[0].componentAvg
              : null;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            if (sort_a > sort_b) {
              return 1;
            }
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            if (sort_a > sort_b) {
              return -1;
            }
          }
          return 0;
        });
      }

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Ts_Comparison: {
            ...state.classComparison.Ts_Comparison,
            ComparisonData: {
              ...state.classComparison.Ts_Comparison.ComparisonData,
              Operational_Data: JSON.parse(JSON.stringify( Operational_Data)),
              sortingOptions: {
                ...state.classComparison.Ts_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
      // End From here
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      // Starts From here
      let Operational_Data =
        state.studentComparison.Std_Comparison.ComparisonData.Operational_Data;

      if (ParamOnwhichScore == "lastName") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.lastName < b.lastName) {
              return -1;
            }
            if (a.lastName > b.lastName) {
              return 1;
            }
          } else {
            if (a.lastName < b.lastName) {
              return 1;
            }
            if (a.lastName > b.lastName) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "studentPercentage") {
        Operational_Data.sort(function (a, b) {
          if (orderOfSort == "ASC") {
            if (a.studentPercentage < b.studentPercentage) {
              return -1;
            }
            if (a.studentPercentage > b.studentPercentage) {
              return 1;
            }
          } else {
            if (a.studentPercentage < b.studentPercentage) {
              return 1;
            }
            if (a.studentPercentage > b.studentPercentage) {
              return -1;
            }
          }
          return 0;
        });
      } else if (ParamOnwhichScore == "standardAndStrandAvg") {
        Operational_Data.sort(function (a, b) {
          let sort_a = a.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          let sort_b = b.standardAndStrandVODetails.filter(
            (strand) => strand.standardShortValue == Strand_Standard
          )[0].standardAndStrandAvg;
          if (orderOfSort == "ASC") {
            if (sort_a < sort_b) {
              return -1;
            }
            if (sort_a > sort_b) {
              return 1;
            }
          } else {
            if (sort_a < sort_b) {
              return 1;
            }
            if (sort_a > sort_b) {
              return -1;
            }
          }
          return 0;
        });
      }

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            ComparisonData: {
              ...state.studentComparison.Std_Comparison.ComparisonData,
              Operational_Data: Operational_Data,
              sortingOptions: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .sortingOptions,
                sortType: Strand_Standard_type,
                sortOn: Strand_Standard,
                sortBy: ParamOnwhichScore,
                SortOrder: orderOfSort,
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function checkedCheckBoxOptions(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let checkFor = action.payload.checkFor;
  let checkedStatus = action.payload.checkedStatus;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let comparisonChecks =
        state.districtComparison.Std_Comparison.ComparisonData.compareOptions;

      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            ComparisonData: {
              ...state.districtComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    } else {
      let comparisonChecks =
        state.districtComparison.Ts_Comparison.ComparisonData.compareOptions;

      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Ts_Comparison: {
            ...state.districtComparison.Ts_Comparison,
            ComparisonData: {
              ...state.districtComparison.Ts_Comparison.ComparisonData,
              compareOptions: {
                ...state.districtComparison.Ts_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let comparisonChecks =
        state.schoolComparison.Std_Comparison.ComparisonData.compareOptions;
      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    } else {
      let comparisonChecks =
        state.schoolComparison.Ts_Comparison.ComparisonData.compareOptions;
      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Ts_Comparison: {
            ...state.schoolComparison.Ts_Comparison,
            ComparisonData: {
              ...state.schoolComparison.Ts_Comparison.ComparisonData,
              compareOptions: {
                ...state.schoolComparison.Ts_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let comparisonChecks =
        state.classComparison.Std_Comparison.ComparisonData.compareOptions;
      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            ComparisonData: {
              ...state.classComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    } else {
      let comparisonChecks =
        state.classComparison.Ts_Comparison.ComparisonData.compareOptions;

      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Ts_Comparison: {
            ...state.classComparison.Ts_Comparison,
            ComparisonData: {
              ...state.classComparison.Ts_Comparison.ComparisonData,
              compareOptions: {
                ...state.classComparison.Ts_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let comparisonChecks =
        state.studentComparison.Std_Comparison.ComparisonData.compareOptions;
      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            ComparisonData: {
              ...state.studentComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    } else {
      let comparisonChecks =
        state.studentComparison.Ts_Comparison.ComparisonData.compareOptions;

      let checkClass =
        checkFor == "class" ? checkedStatus : comparisonChecks.checkClass;
      let checkSchool =
        checkFor == "school" ? checkedStatus : comparisonChecks.checkSchool;
      let checkDistrict =
        checkFor == "district" ? checkedStatus : comparisonChecks.checkDistrict;

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Ts_Comparison: {
            ...state.studentComparison.Ts_Comparison,
            ComparisonData: {
              ...state.studentComparison.Ts_Comparison.ComparisonData,
              compareOptions: {
                ...state.studentComparison.Ts_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: checkDistrict,
                checkSchool: checkSchool,
                checkClass: checkClass,
              },
            },
          },
        },
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function apply_action_comparison(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp =
        state.districtComparison.Std_Comparison.PopupFilter
          .Strands_And_Standards.strands.selectedStrands_temp;
      let Original_List_temp =
        state.districtComparison.Std_Comparison.PopupFilter
          .Strands_And_Standards.Original_List_temp;

      return {
        ...state,
        CompareDeepLink_Enabled: false,
        Orig_Ass_Count_Success: false,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            ComparisonData: {
              ...state.districtComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: false,
                checkSchool: false,
                checkClass: false,
              },
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              openPopup: false,
              TaxonomyParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                selectedTaxonomy:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.selectedTaxonomy_temp,
                TaxonomyList:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.TaxonomyList_temp,
              },
              GradeParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .GradeParams.selectedGrade_temp,
                GradeList:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .GradeParams.GradeList_temp,
              },
              QuestionParams: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .QuestionParams.selectedTestAssessment_temp,
                QuestionList:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .QuestionParams.QuestionList_temp,
              },
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: Original_List_temp,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selected_Strands_Standardards: selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp =
        state.schoolComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .strands.selectedStrands_temp;
      let Original_List_temp =
        state.schoolComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .Original_List_temp;

      return {
        ...state,
        CompareDeepLink_Enabled: false,
        Orig_Ass_Count_Success: false,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            ComparisonData: {
              ...state.schoolComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: false,
                checkSchool: false,
                checkClass: false,
              },
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              openPopup: false,
              TaxonomyParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                selectedTaxonomy:
                  state.schoolComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.selectedTaxonomy_temp,
                TaxonomyList:
                  state.schoolComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.TaxonomyList_temp,
              },
              GradeParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade:
                  state.schoolComparison.Std_Comparison.PopupFilter.GradeParams
                    .selectedGrade_temp,
                GradeList:
                  state.schoolComparison.Std_Comparison.PopupFilter.GradeParams
                    .GradeList_temp,
              },
              QuestionParams: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment:
                  state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams.selectedTestAssessment_temp,
                QuestionList:
                  state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams.QuestionList_temp,
              },
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: Original_List_temp,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selected_Strands_Standardards: selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp =
        state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .strands.selectedStrands_temp;
      let Original_List_temp =
        state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .Original_List_temp;

      return {
        ...state,
        CompareDeepLink_Enabled: false,
        Orig_Ass_Count_Success: false,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            ComparisonData: {
              ...state.classComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: false,
                checkSchool: false,
                checkClass: false,
              },
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              openPopup: false,
              TaxonomyParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                selectedTaxonomy:
                  state.classComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.selectedTaxonomy_temp,
                TaxonomyList:
                  state.classComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.TaxonomyList_temp,
              },
              GradeParams: {
                ...state.classComparison.Std_Comparison.PopupFilter.GradeParams,
                selectedGrade:
                  state.classComparison.Std_Comparison.PopupFilter.GradeParams
                    .selectedGrade_temp,
                GradeList:
                  state.classComparison.Std_Comparison.PopupFilter.GradeParams
                    .GradeList_temp,
              },
              QuestionParams: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment:
                  state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams.selectedTestAssessment_temp,
                QuestionList:
                  state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams.QuestionList_temp,
              },
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: Original_List_temp,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selected_Strands_Standardards: selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp =
        state.studentComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .strands.selectedStrands_temp;
      let Original_List_temp =
        state.studentComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .Original_List_temp;

      return {
        ...state,
        CompareDeepLink_Enabled: false,
        Orig_Ass_Count_Success: false,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: true,
            },
            ComparisonData: {
              ...state.studentComparison.Std_Comparison.ComparisonData,
              compareOptions: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: false,
                checkSchool: false,
                checkClass: false,
              },
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              openPopup: false,
              TaxonomyParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .TaxonomyParams,
                selectedTaxonomy:
                  state.studentComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.selectedTaxonomy_temp,
                TaxonomyList:
                  state.studentComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams.TaxonomyList_temp,
              },
              GradeParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .GradeParams,
                selectedGrade:
                  state.studentComparison.Std_Comparison.PopupFilter.GradeParams
                    .selectedGrade_temp,
                GradeList:
                  state.studentComparison.Std_Comparison.PopupFilter.GradeParams
                    .GradeList_temp,
              },
              QuestionParams: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .QuestionParams,
                selectedTestAssessment:
                  state.studentComparison.Std_Comparison.PopupFilter
                    .QuestionParams.selectedTestAssessment_temp,
                QuestionList:
                  state.studentComparison.Std_Comparison.PopupFilter
                    .QuestionParams.QuestionList_temp,
              },
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                Original_List: Original_List_temp,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selected_Strands_Standardards: selectedStrands_temp,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function comparison_Apply_API_fail(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  if (fromContext == "district") {
    return {
      ...state,
      CompareDeepLink_Enabled: "",
      Orig_Ass_Count_Success: false,
      districtComparison: INITIAL_STATE.districtComparison,
    };
  } else if (fromContext == "school") {
    return {
      ...state,
      CompareDeepLink_Enabled: "",
      Orig_Ass_Count_Success: false,
      schoolComparison: INITIAL_STATE.schoolComparison,
    };
  } else if (fromContext == "class") {
    return {
      ...state,
      CompareDeepLink_Enabled: "",
      Orig_Ass_Count_Success: false,
      classComparison: INITIAL_STATE.classComparison,
    };
  } else if (fromContext == "student") {
    return {
      ...state,
      CompareDeepLink_Enabled: "",
      Orig_Ass_Count_Success: false,
      studentComparison: INITIAL_STATE.studentComparison,
    };
  } else {
    return {
      ...state,
    };
  }
}

function apply_action_comparison_success(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let compareData = action.payload.PayloadData;
  const { persist_compare_checkboxes } = action.payload;

  let D_View =
    state.districtComparison.Std_Comparison.PopupFilter.TaxonomyParams
      .selectedTaxonomy;
  let D_ques =
    state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
      .selectedTestAssessment;
  let D_Grade =
    state.districtComparison.Std_Comparison.PopupFilter.GradeParams
      .selectedGrade;

  let sc_View =
    state.schoolComparison.Std_Comparison.PopupFilter.TaxonomyParams
      .selectedTaxonomy;
  let sc_ques =
    state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
      .selectedTestAssessment;
  let sc_Grade =
    state.schoolComparison.Std_Comparison.PopupFilter.GradeParams.selectedGrade;

  let c_View =
    state.classComparison.Std_Comparison.PopupFilter.TaxonomyParams
      .selectedTaxonomy;
  let c_ques =
    state.classComparison.Std_Comparison.PopupFilter.QuestionParams
      .selectedTestAssessment;
  let c_Grade =
    state.classComparison.Std_Comparison.PopupFilter.GradeParams.selectedGrade;

  let St_View =
    state.studentComparison.Std_Comparison.PopupFilter.TaxonomyParams
      .selectedTaxonomy;
  let St_ques =
    state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
      .selectedTestAssessment;
  let St_Grade =
    state.studentComparison.Std_Comparison.PopupFilter.GradeParams
      .selectedGrade;

  let D_Grade_Api,
    D_Strand_Api,
    D_Ques_Api,
    Sc_Grade_Api,
    Sc_Strand_Api,
    Sc_Ques_Api,
    c_Grade_Api,
    c_Strand_Api,
    c_Ques_Api,
    St_Grade_Api,
    St_Strand_Api,
    St_Ques_Api;
  let D_TaxonomyParams =
    state.districtComparison.Std_Comparison.PopupFilter.TaxonomyParams;
  let D_QuestionParams =
    state.districtComparison.Std_Comparison.PopupFilter.QuestionParams;
  let D_GradeParams =
    state.districtComparison.Std_Comparison.PopupFilter.GradeParams;

  let SC_TaxonomyParams =
    state.schoolComparison.Std_Comparison.PopupFilter.TaxonomyParams;
  let SC_QuestionParams =
    state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams;
  let SC_GradeParams =
    state.schoolComparison.Std_Comparison.PopupFilter.GradeParams;

  let C_TaxonomyParams =
    state.classComparison.Std_Comparison.PopupFilter.TaxonomyParams;
  let C_QuestionParams =
    state.classComparison.Std_Comparison.PopupFilter.QuestionParams;
  let C_GradeParams =
    state.classComparison.Std_Comparison.PopupFilter.GradeParams;

  let ST_TaxonomyParams =
    state.studentComparison.Std_Comparison.PopupFilter.TaxonomyParams;
  let ST_QuestionParams =
    state.studentComparison.Std_Comparison.PopupFilter.QuestionParams;
  let ST_GradeParams =
    state.studentComparison.Std_Comparison.PopupFilter.GradeParams;

  let SchoolStrands =
    state.schoolComparison.Std_Comparison.PopupFilter.Strands_And_Standards
      .strands.selected_Strands_Standardards;
  let ClassStrands =
    state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
      .strands.selected_Strands_Standardards;
  let DistrictStrands =
    state.districtComparison.Std_Comparison.PopupFilter.Strands_And_Standards
      .strands.selected_Strands_Standardards;
  let StudentStrands =
    state.studentComparison.Std_Comparison.PopupFilter.Strands_And_Standards
      .strands.selected_Strands_Standardards;

  function CheckTwoStrandArrays(arr1, arr2) {
    let NotSame = false;
    for (var i = 0; i < arr1.length; i++) {
      let find = arr2.find((item) => item.strandName === arr1[i].strandName);
      if (find == undefined) {
        NotSame = true;
        break;
      } else if (find.check !== arr1[i].check) {
        NotSame = true;
        break;
      }
    }
    return NotSame;
  }

  function CheckStandardsOfAllContexts(StrandsToCompare) {
    SchoolStrands = SchoolStrands && SchoolStrands.filter((item) => item.check);
    DistrictStrands =
      DistrictStrands && DistrictStrands.filter((item) => item.check);
    ClassStrands = ClassStrands && ClassStrands.filter((item) => item.check);
    StudentStrands =
      StudentStrands && StudentStrands.filter((item) => item.check);

    if (
      StudentStrands.length === 1 &&
      StrandsToCompare.length === 1 &&
      StudentStrands[0].standards
    ) {
      StudentStrands = StudentStrands[0].standards;
      StrandsToCompare = StrandsToCompare[0].standards;
    }
    if (
      ClassStrands.length === 1 &&
      StrandsToCompare.length === 1 &&
      ClassStrands[0].standards
    ) {
      ClassStrands = ClassStrands[0].standards;
      StrandsToCompare = StrandsToCompare[0].standards;
    }

    if (
      DistrictStrands.length === 1 &&
      StrandsToCompare.length === 1 &&
      DistrictStrands[0].standard
    ) {
      DistrictStrands = DistrictStrands[0].standards;
      StrandsToCompare = StrandsToCompare[0].standards;
    }
    let student_ = CheckTwoStrandArrays(StrandsToCompare, StudentStrands);
    let class_ = CheckTwoStrandArrays(StrandsToCompare, ClassStrands);
    let school_ = CheckTwoStrandArrays(StrandsToCompare, SchoolStrands);
    let district_ = CheckTwoStrandArrays(StrandsToCompare, DistrictStrands);
    return { class_, school_, district_, student_ };
  }
  let CurrentCompareData;
  function Get_FirstAndLastTotalsFor_Calculate_Avg(Dataobject) {
    let first = 0;
    let Last = 0;
    Dataobject &&
      Object.keys(Dataobject).map(function (key, index) {
        first += Dataobject[key][0];
        Last += Dataobject[key][1];
        Dataobject[key] = calculate_And_Round_Avg(
          Dataobject[key][0],
          Dataobject[key][1]
        );
      });
    let AvgIs = calculate_And_Round_Avg(first, Last);
    return { AvgIs, Dataobject };
  }

  compareData &&
    fromtab == "std_performance" &&
    compareData.sort(function (a, b) {
      let first =
        fromContext == "district"
          ? a.schoolName
          : fromContext == "school"
          ? a.className
          : a.lastName;

      let second =
        fromContext == "district"
          ? b.schoolName
          : fromContext == "school"
          ? b.className
          : b.lastName;
      if (first < second) {
        return -1;
      }
      if (first > second) {
        return 1;
      }

      return 0;
    });

  let Item = compareData && compareData.length > 0 && compareData[0];
  let Forcls, ForSchool, ForDistrict, clsAvg, schoolAvg, DistrictAvg;

  if (Item) {
    Forcls = Get_FirstAndLastTotalsFor_Calculate_Avg(JSON.parse(JSON.stringify(Item.stdScoresForClass)));
    ForSchool = Get_FirstAndLastTotalsFor_Calculate_Avg(
      JSON.parse(JSON.stringify(Item.stdScoresForSchool))
    );
    ForDistrict = Get_FirstAndLastTotalsFor_Calculate_Avg(
      JSON.parse(JSON.stringify(Item.stdScoresForDistrict))
    );

    compareData[0].stdAvgForClass = Forcls.Dataobject;
    compareData[0].stdAvgForSchool = ForSchool.Dataobject;
    compareData[0].stdAvgForDistrict = ForDistrict.Dataobject;

    clsAvg = Forcls.AvgIs;
    schoolAvg = ForSchool.AvgIs;
    DistrictAvg = ForDistrict.AvgIs;
  }

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let totalPageCount = Math.ceil(
        compareData.length /
          state.districtComparison.Std_Comparison.ComparisonData.pagination
            .countPerPage
      );
      Sc_Strand_Api = sc_View !== D_View ? true : undefined;
      Sc_Ques_Api = sc_ques !== D_ques ? true : undefined;
      Sc_Grade_Api = sc_Grade !== D_Grade ? true : undefined;
      let DistrictStrands =
        state.districtComparison.Std_Comparison.PopupFilter
          .Strands_And_Standards.strands.selected_Strands_Standardards;
      if (DistrictStrands.length === 1) {
        Sc_Strand_Api = !Sc_Strand_Api && !Sc_Ques_Api ? true : Sc_Strand_Api;
      } else if (DistrictStrands.length > 1) {
        DistrictStrands = DistrictStrands.filter((item) => item.check);
        let { class_, school_, district_, student_ } =
          CheckStandardsOfAllContexts(DistrictStrands);

        Sc_Strand_Api = school_ ? school_ : Sc_Strand_Api;
      }

      if (action.payload.PayloadData && action.payload.PayloadData.length > 0) {
        let tax_temp =
          state.districtComparison.Std_Comparison.PopupFilter.TaxonomyParams
            .selectedTaxonomy;
        let grade_Temp =
          state.districtComparison.Std_Comparison.PopupFilter.GradeParams
            .selectedGrade_temp;
        let ques_Temp =
          state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
            .selectedTestAssessment_temp;
        SC_TaxonomyParams = {
          ...SC_TaxonomyParams,
          selectedTaxonomy_temp: tax_temp,
        };
        SC_QuestionParams = {
          ...SC_QuestionParams,
          selectedTestAssessment_temp: ques_Temp,
        };
        SC_GradeParams = {
          ...SC_GradeParams,
          selectedGrade_temp: grade_Temp,
        };
      }

      return {
        ...state,
        CompareDeepLink_Enabled: false,
        lastActiveContext: fromContext,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            DeepLinking: false,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            ComparisonData: {
              ...state.districtComparison.Std_Comparison.ComparisonData,
              OrginalData: JSON.parse(JSON.stringify(compareData)),
              Operational_Data: JSON.parse(JSON.stringify(compareData)),
              classAvg: clsAvg
                ? clsAvg
                : state.districtComparison.Std_Comparison.classAvg,
              schoolAvg: schoolAvg
                ? schoolAvg
                : state.districtComparison.Std_Comparison.schoolAvg,
              districtAvg: DistrictAvg
                ? DistrictAvg
                : state.districtComparison.Std_Comparison.DistrictAvg,
              navigation: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .navigation,
                navigationLeft: 0,
                navigationRight:
                  state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands.selected_Strands_Standardards
                    .length > 1
                    ? 5
                    : Nav_strands_Count_perPage_,
              },
              pagination: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .pagination,
                totalPageCount: totalPageCount,
                currentPageNumber: 1,
              },
              compareOptions: {
                ...state.districtComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: persist_compare_checkboxes.checkDistrict,
                checkSchool: persist_compare_checkboxes.checkSchool,
                checkClass: persist_compare_checkboxes.checkClass,
              },
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              enableDoneBtn: false,
            },
          },
        },

        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: Sc_Grade_Api
                  ? Sc_Grade_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: Sc_Ques_Api
                  ? Sc_Ques_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: Sc_Strand_Api
                  ? Sc_Strand_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },

              TaxonomyParams: SC_TaxonomyParams,
              QuestionParams: SC_QuestionParams,
              GradeParams: SC_GradeParams,
              openPopup:
                Sc_Grade_Api || Sc_Strand_Api || Sc_Ques_Api
                  ? true
                  : state.schoolComparison.Std_Comparison.PopupFilter.openPopup,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      D_Strand_Api = sc_View !== D_View ? true : undefined;
      D_Ques_Api = sc_ques !== D_ques ? true : undefined;
      D_Grade_Api =
        sc_Grade !== D_Grade || D_Strand_Api || D_Ques_Api ? true : undefined;

      c_Strand_Api = sc_View !== c_View ? true : undefined;
      c_Ques_Api = sc_ques !== c_ques ? true : undefined;
      c_Grade_Api =
        sc_Grade !== c_Grade || c_Strand_Api || c_Ques_Api ? true : undefined;
      CurrentCompareData =
        state.schoolComparison.Std_Comparison.ComparisonData.OrginalData;
      if (SchoolStrands.length === 1 && CurrentCompareData.length > 0) {
        c_Strand_Api = !c_Strand_Api && !c_Ques_Api ? true : c_Strand_Api;
        D_Strand_Api = !D_Strand_Api && !D_Ques_Api ? true : D_Strand_Api;
      } else if (SchoolStrands.length > 1 && CurrentCompareData.length > 0) {
        SchoolStrands = SchoolStrands.filter((item) => item.check);
        let { class_, school_, district_, student_ } =
          CheckStandardsOfAllContexts(SchoolStrands);
        D_Strand_Api = district_ ? district_ : D_Strand_Api;
        c_Strand_Api = class_ ? class_ : c_Strand_Api;
      }
      let totalPageCount = Math.ceil(
        compareData.length /
          state.schoolComparison.Std_Comparison.ComparisonData.pagination
            .countPerPage
      );

      if (action.payload.PayloadData && action.payload.PayloadData.length > 0) {
        let tax_temp =
          state.schoolComparison.Std_Comparison.PopupFilter.TaxonomyParams
            .selectedTaxonomy;
        let grade_Temp =
          state.schoolComparison.Std_Comparison.PopupFilter.GradeParams
            .selectedGrade_temp;
        let ques_Temp =
          state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
            .selectedTestAssessment_temp;
        D_TaxonomyParams = {
          ...D_TaxonomyParams,
          selectedTaxonomy_temp: tax_temp,
        };
        D_QuestionParams = {
          ...D_QuestionParams,
          selectedTestAssessment_temp: ques_Temp,
        };
        D_GradeParams = {
          ...D_GradeParams,
          selectedGrade_temp: grade_Temp,
        };

        C_TaxonomyParams = {
          ...C_TaxonomyParams,
          selectedTaxonomy_temp: tax_temp,
        };
        C_QuestionParams = {
          ...C_QuestionParams,
          selectedTestAssessment_temp: ques_Temp,
        };
        C_GradeParams = {
          ...C_GradeParams,
          selectedGrade_temp: grade_Temp,
        };
      }
      return {
        ...state,
        CompareDeepLink_Enabled: false,
        lastActiveContext: fromContext,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            DeepLinking: false,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            ComparisonData: {
              ...state.schoolComparison.Std_Comparison.ComparisonData,
              OrginalData: JSON.parse(JSON.stringify(compareData)),
              Operational_Data: JSON.parse(JSON.stringify(compareData)),
              navigation: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .navigation,
                navigationLeft: 0,
                navigationRight:
                  state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands.selected_Strands_Standardards
                    .length > 1
                    ? 5
                    : Nav_strands_Count_perPage_,
              },
              pagination: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .pagination,
                totalPageCount: totalPageCount,
                currentPageNumber: 1,
              },
              classAvg: clsAvg
                ? clsAvg
                : state.districtComparison.Std_Comparison.classAvg,
              schoolAvg: schoolAvg
                ? schoolAvg
                : state.districtComparison.Std_Comparison.schoolAvg,
              districtAvg: DistrictAvg
                ? DistrictAvg
                : state.districtComparison.Std_Comparison.DistrictAvg,
              compareOptions: {
                ...state.schoolComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: persist_compare_checkboxes.checkDistrict,
                checkSchool: persist_compare_checkboxes.checkSchool,
                checkClass: persist_compare_checkboxes.checkClass,
              },
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              enableDoneBtn: false,
            },
          },
        },
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: D_Grade_Api
                  ? D_Grade_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: D_Ques_Api
                  ? D_Ques_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: D_Strand_Api
                  ? D_Strand_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              TaxonomyParams: D_TaxonomyParams,
              QuestionParams: D_QuestionParams,
              GradeParams: D_GradeParams,

              openPopup:
                D_Grade_Api || D_Strand_Api || D_Ques_Api
                  ? true
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .openPopup,
            },
          },
        },
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: c_Grade_Api
                  ? c_Grade_Api
                  : state.classComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: c_Ques_Api
                  ? c_Ques_Api
                  : state.classComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: c_Strand_Api
                  ? c_Strand_Api
                  : state.classComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },

              TaxonomyParams: C_TaxonomyParams,
              QuestionParams: C_QuestionParams,
              GradeParams: C_GradeParams,
              openPopup:
                c_Grade_Api || c_Strand_Api || c_Ques_Api
                  ? true
                  : state.classComparison.Std_Comparison.PopupFilter.openPopup,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let totalPageCount = Math.ceil(
        compareData.length /
          state.classComparison.Std_Comparison.ComparisonData.pagination
            .countPerPage
      );
      D_Strand_Api = c_View !== D_View ? true : undefined;
      D_Ques_Api = c_ques !== D_ques ? true : undefined;
      D_Grade_Api = c_Grade !== D_Grade ? true : undefined;
      Sc_Strand_Api = c_View !== sc_View ? true : undefined;
      Sc_Ques_Api = c_ques !== sc_ques ? true : undefined;
      Sc_Grade_Api = c_Grade !== sc_Grade ? true : undefined;

      St_Strand_Api = c_View !== St_View ? true : undefined;
      St_Ques_Api = c_ques !== St_ques ? true : undefined;
      St_Grade_Api = c_Grade !== St_Grade ? true : undefined;

      CurrentCompareData =
        state.classComparison.Std_Comparison.ComparisonData.OrginalData;

      if (ClassStrands.length === 1 && CurrentCompareData.length > 0) {
        Sc_Strand_Api = !Sc_Strand_Api && !Sc_Ques_Api ? true : Sc_Strand_Api;
        D_Strand_Api = !D_Strand_Api && !D_Ques_Api ? true : D_Strand_Api;
        St_Strand_Api = !St_Strand_Api && !St_Ques_Api ? true : St_Strand_Api;
      } else if (ClassStrands.length > 1 && CurrentCompareData.length > 0) {
        ClassStrands = ClassStrands.filter((item) => item.check);
        let { class_, school_, district_, student_ } =
          CheckStandardsOfAllContexts(ClassStrands);
        Sc_Strand_Api = school_ ? school_ : Sc_Strand_Api;
        c_Strand_Api = class_ ? class_ : c_Strand_Api;
      }
      if (action.payload.PayloadData && action.payload.PayloadData.length > 0) {
        let tax_temp =
          state.classComparison.Std_Comparison.PopupFilter.TaxonomyParams
            .selectedTaxonomy;
        let grade_Temp =
          state.classComparison.Std_Comparison.PopupFilter.GradeParams
            .selectedGrade_temp;
        let ques_Temp =
          state.classComparison.Std_Comparison.PopupFilter.QuestionParams
            .selectedTestAssessment_temp;
        SC_TaxonomyParams = {
          ...SC_TaxonomyParams,
          selectedTaxonomy_temp: tax_temp,
        };
        SC_QuestionParams = {
          ...SC_QuestionParams,
          selectedTestAssessment_temp: ques_Temp,
        };
        SC_GradeParams = {
          ...SC_GradeParams,
          selectedGrade_temp: grade_Temp,
        };

        ST_TaxonomyParams = {
          ...ST_TaxonomyParams,
          selectedTaxonomy_temp: tax_temp,
        };
        ST_QuestionParams = {
          ...ST_QuestionParams,
          selectedTestAssessment_temp: ques_Temp,
        };
        ST_GradeParams = {
          ...ST_GradeParams,
          selectedGrade_temp: grade_Temp,
        };
      }

      return {
        ...state,
        CompareDeepLink_Enabled: false,
        lastActiveContext: fromContext,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: St_Grade_Api
                  ? St_Grade_Api
                  : state.studentComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: St_Ques_Api
                  ? St_Ques_Api
                  : state.studentComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: St_Strand_Api
                  ? St_Strand_Api
                  : state.studentComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              TaxonomyParams: ST_TaxonomyParams,
              QuestionParams: ST_QuestionParams,
              GradeParams: ST_GradeParams,
            },
          },
        },
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            DeepLinking: false,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            ComparisonData: {
              ...state.classComparison.Std_Comparison.ComparisonData,
              OrginalData: JSON.parse(JSON.stringify(compareData)),
              Operational_Data: JSON.parse(JSON.stringify(compareData)),
              classAvg: clsAvg
                ? clsAvg
                : state.districtComparison.Std_Comparison.classAvg,
              schoolAvg: schoolAvg
                ? schoolAvg
                : state.districtComparison.Std_Comparison.schoolAvg,
              districtAvg: DistrictAvg
                ? DistrictAvg
                : state.districtComparison.Std_Comparison.DistrictAvg,

              navigation: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .navigation,
                navigationLeft: 0,
                navigationRight:
                  state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands.selected_Strands_Standardards
                    .length > 1
                    ? 5
                    : Nav_strands_Count_perPage_,
              },
              pagination: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .pagination,
                totalPageCount: totalPageCount,
                currentPageNumber: 1,
              },
              compareOptions: {
                ...state.classComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: persist_compare_checkboxes.checkDistrict,
                checkSchool: persist_compare_checkboxes.checkSchool,
                checkClass: persist_compare_checkboxes.checkClass,
              },
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              enableDoneBtn: false,
            },
          },
        },
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: D_Grade_Api
                  ? D_Grade_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: D_Ques_Api
                  ? D_Ques_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: D_Strand_Api
                  ? D_Strand_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              openPopup:
                D_Grade_Api || D_Strand_Api || D_Ques_Api
                  ? true
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .openPopup,
            },
          },
        },
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: Sc_Grade_Api
                  ? Sc_Grade_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: Sc_Ques_Api
                  ? Sc_Ques_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: Sc_Strand_Api
                  ? Sc_Strand_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              TaxonomyParams: SC_TaxonomyParams,
              QuestionParams: SC_QuestionParams,
              GradeParams: SC_GradeParams,

              openPopup:
                Sc_Grade_Api || Sc_Strand_Api || Sc_Ques_Api
                  ? true
                  : state.schoolComparison.Std_Comparison.PopupFilter.openPopup,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let totalPageCount = Math.ceil(
        compareData.length /
          state.studentComparison.Std_Comparison.ComparisonData.pagination
            .countPerPage
      );
      D_Strand_Api = St_View !== D_View ? true : undefined;
      D_Ques_Api = St_ques !== D_ques ? true : undefined;
      D_Grade_Api = St_Grade !== D_Grade ? true : undefined;

      Sc_Strand_Api = St_View !== sc_View ? true : undefined;
      Sc_Ques_Api = St_ques !== sc_ques ? true : undefined;
      Sc_Grade_Api = St_Grade !== sc_Grade ? true : undefined;

      c_Strand_Api = St_View !== c_View ? true : undefined;
      c_Ques_Api = St_ques !== c_ques ? true : undefined;
      c_Grade_Api =
        St_Grade !== c_Grade || c_Strand_Api || c_Ques_Api ? true : undefined;
      if (
        state.studentComparison.Std_Comparison.PopupFilter.Strands_And_Standards
          .strands.selected_Strands_Standardards.length === 1
      ) {
        c_Strand_Api = !c_Strand_Api && !c_Ques_Api ? true : c_Strand_Api;
        Sc_Strand_Api = !Sc_Strand_Api && !Sc_Ques_Api ? true : Sc_Strand_Api;
        D_Strand_Api = !D_Strand_Api && !D_Ques_Api ? true : D_Strand_Api;
      }
      c_Grade_Api =
        St_Grade !== c_Grade || c_Strand_Api || c_Ques_Api ? true : undefined;

      St_Strand_Api = c_View !== St_View ? true : undefined;
      St_Ques_Api = c_ques !== St_ques ? true : undefined;
      St_Grade_Api = c_Grade !== St_Grade ? true : undefined;
      CurrentCompareData =
        state.studentComparison.Std_Comparison.ComparisonData.OrginalData;

      if (StudentStrands.length === 1 && CurrentCompareData.length > 0) {
        Sc_Strand_Api = !Sc_Strand_Api && !Sc_Ques_Api ? true : Sc_Strand_Api;
        D_Strand_Api = !D_Strand_Api && !D_Ques_Api ? true : D_Strand_Api;
        St_Strand_Api = !St_Strand_Api && !St_Ques_Api ? true : St_Strand_Api;
      } else if (StudentStrands.length > 1 && CurrentCompareData.length > 0) {
        StudentStrands = StudentStrands.filter((item) => item.check);
        let { class_, school_, district_, student_ } =
          CheckStandardsOfAllContexts(StudentStrands);
        D_Strand_Api = district_ ? true : district_;
        Sc_Strand_Api = school_ ? school_ : Sc_Strand_Api;
        c_Strand_Api = class_ ? class_ : c_Strand_Api;
      }

      if (action.payload.PayloadData && action.payload.PayloadData.length > 0) {
        let tax_temp =
          state.studentComparison.Std_Comparison.PopupFilter.TaxonomyParams
            .selectedTaxonomy;
        let grade_Temp =
          state.studentComparison.Std_Comparison.PopupFilter.GradeParams
            .selectedGrade_temp;
        let ques_Temp =
          state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
            .selectedTestAssessment_temp;

        C_TaxonomyParams = {
          ...C_TaxonomyParams,
          selectedTaxonomy_temp: tax_temp,
        };
        C_QuestionParams = {
          ...C_QuestionParams,
          selectedTestAssessment_temp: ques_Temp,
        };
        C_GradeParams = {
          ...C_GradeParams,
          selectedTaxonomy_temp: grade_Temp,
        };
      }
      return {
        ...state,
        CompareDeepLink_Enabled: false,
        lastActiveContext: fromContext,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            DeepLinking: false,
            C_ApiCalls: {
              ...state.studentComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            ComparisonData: {
              ...state.studentComparison.Std_Comparison.ComparisonData,
              OrginalData: JSON.parse(JSON.stringify(compareData)),
              Operational_Data: JSON.parse(JSON.stringify(compareData)),
              classAvg: clsAvg
                ? clsAvg
                : state.districtComparison.Std_Comparison.classAvg,
              schoolAvg: schoolAvg
                ? schoolAvg
                : state.districtComparison.Std_Comparison.schoolAvg,
              districtAvg: DistrictAvg
                ? DistrictAvg
                : state.districtComparison.Std_Comparison.DistrictAvg,
              navigation: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .navigation,
                navigationRight:
                  state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands.selected_Strands_Standardards
                    .length > 1
                    ? 5
                    : Nav_strands_Count_perPage_,
              },
              pagination: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .pagination,
                totalPageCount: totalPageCount,
                currentPageNumber: 1,
              },
              compareOptions: {
                ...state.studentComparison.Std_Comparison.ComparisonData
                  .compareOptions,
                checkDistrict: persist_compare_checkboxes.checkDistrict,
                checkSchool: persist_compare_checkboxes.checkSchool,
                checkClass: persist_compare_checkboxes.checkClass,
              },
            },
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              enableDoneBtn: false,
            },
          },
        },
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.districtComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: D_Grade_Api
                  ? D_Grade_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: D_Ques_Api
                  ? D_Ques_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: D_Strand_Api
                  ? D_Strand_Api
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              openPopup:
                D_Grade_Api || D_Strand_Api || D_Ques_Api
                  ? true
                  : state.districtComparison.Std_Comparison.PopupFilter
                      .openPopup,
            },
          },
        },
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.schoolComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: Sc_Grade_Api
                  ? Sc_Grade_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: Sc_Ques_Api
                  ? Sc_Ques_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: Sc_Strand_Api
                  ? Sc_Strand_Api
                  : state.schoolComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              openPopup:
                Sc_Grade_Api || Sc_Strand_Api || Sc_Ques_Api
                  ? true
                  : state.schoolComparison.Std_Comparison.PopupFilter.openPopup,
            },
          },
        },
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            C_ApiCalls: {
              ...state.classComparison.Std_Comparison.C_ApiCalls,
              loadingComparison: false,
            },
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              C_SP_ApiCalls: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .C_SP_ApiCalls,
                getGrades: c_Grade_Api
                  ? c_Grade_Api
                  : state.classComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getGrades,
                getassessed_Ques: c_Ques_Api
                  ? c_Ques_Api
                  : state.classComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getassessed_Ques,
                getStrands: c_Strand_Api
                  ? c_Strand_Api
                  : state.classComparison.Std_Comparison.PopupFilter
                      .C_SP_ApiCalls.getStrands,
              },
              TaxonomyParams: C_TaxonomyParams,
              QuestionParams: C_QuestionParams,
              GradeParams: C_GradeParams,
              openPopup:
                c_Grade_Api || c_Strand_Api || c_Ques_Api
                  ? true
                  : state.classComparison.Std_Comparison.PopupFilter.openPopup,
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function compare_strands_check_all(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let status_result = action.payload.status_result;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.districtComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );
      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          standard.check = status_result;
        });
      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
    // end
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.schoolComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          standard.check = status_result;
        });
      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
    // end
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
            .strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          standard.check = status_result;
        });
      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
    // end
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.studentComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          standard.check = status_result;
        });

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
    // end
  } else {
    return {
      ...state,
    };
  }
}

function SelectStrands_selection(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let selectedStandard = action.payload.selectedStandard;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.districtComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          if (standard.standardId == selectedStandard) {
            standard.check = !standard.check;
          }
        });

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.schoolComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          if (standard.standardId == selectedStandard) {
            standard.check = !standard.check;
          }
        });

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
            .strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          if (standard.standardId == selectedStandard) {
            standard.check = !standard.check;
          }
        });

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let currentSelectedStandards = JSON.parse(
        JSON.stringify(
          state.studentComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      currentSelectedStandards
        .filter((strand) => strand.check)[0]
        .standards.map((standard) => {
          if (standard.standardId == selectedStandard) {
            standard.check = !standard.check;
          }
        });

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: currentSelectedStandards,
                  selectedStrands_temp_beta: currentSelectedStandards,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }

    // End of  Standards
  } else {
    return {
      ...state,
    };
  }
}

function RemovestrandOnSpanClick(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let resultSelectedStrand = action.payload.strand.strandName;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.districtComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      STrands.map((strand) => {
        if (strand.strandName === resultSelectedStrand) {
          strand.check = !strand.check;
        }
      });

      let filterd_strandsList = STrands.filter((strand) => strand.check);

      if (filterd_strandsList.length == 1) {
        STrands.filter((strand) => strand.check)[0].standards.map(
          (standard) => {
            standard.check = false;
          }
        );
      }

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: STrands,
                  selectedStrands_temp_beta: STrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.schoolComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      STrands.map((strand) => {
        if (strand.strandName === resultSelectedStrand) {
          strand.check = !strand.check;
        }
      });

      let filterd_strandsList = STrands.filter((strand) => strand.check);

      if (filterd_strandsList.length == 1) {
        STrands.filter((strand) => strand.check)[0].standards.map(
          (standard) => {
            standard.check = false;
          }
        );
      }

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: STrands,
                  selectedStrands_temp_beta: STrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
            .strands.selectedStrands_temp
        )
      );

      STrands.map((strand) => {
        if (strand.strandName === resultSelectedStrand) {
          strand.check = !strand.check;
        }
      });

      let filterd_strandsList = STrands.filter((strand) => strand.check);

      if (filterd_strandsList.length == 1) {
        STrands.filter((strand) => strand.check)[0].standards.map(
          (standard) => {
            standard.check = false;
          }
        );
      }

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: STrands,
                  selectedStrands_temp_beta: STrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.studentComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp
        )
      );

      STrands.map((strand) => {
        if (strand.strandName === resultSelectedStrand) {
          strand.check = !strand.check;
        }
      });

      let filterd_strandsList = STrands.filter((strand) => strand.check);

      if (filterd_strandsList.length == 1) {
        STrands.filter((strand) => strand.check)[0].standards.map(
          (standard) => {
            standard.check = false;
          }
        );
      }

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: STrands,
                  selectedStrands_temp_beta: STrands,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function returnDone_in_strands_selection(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp_beta = JSON.parse(
        JSON.stringify(
          state.districtComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp_beta
        )
      );

      let filterd_strandsList = selectedStrands_temp_beta.filter(
        (strand) => strand.check
      );

      if (filterd_strandsList.length == 1) {
        selectedStrands_temp_beta
          .filter((strand) => strand.check)[0]
          .standards.map((standard) => {
            standard.check = false;
          });
      }

      return {
        ...state,
        districtComparison: {
          ...state.districtComparison,
          Std_Comparison: {
            ...state.districtComparison.Std_Comparison,
            PopupFilter: {
              ...state.districtComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.districtComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: selectedStrands_temp_beta,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp_beta = JSON.parse(
        JSON.stringify(
          state.schoolComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp_beta
        )
      );

      let filterd_strandsList = selectedStrands_temp_beta.filter(
        (strand) => strand.check
      );

      if (filterd_strandsList.length == 1) {
        selectedStrands_temp_beta
          .filter((strand) => strand.check)[0]
          .standards.map((standard) => {
            standard.check = false;
          });
      }

      return {
        ...state,
        schoolComparison: {
          ...state.schoolComparison,
          Std_Comparison: {
            ...state.schoolComparison.Std_Comparison,
            PopupFilter: {
              ...state.schoolComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.schoolComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: selectedStrands_temp_beta,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp_beta = JSON.parse(
        JSON.stringify(
          state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
            .strands.selectedStrands_temp_beta
        )
      );

      let filterd_strandsList = selectedStrands_temp_beta.filter(
        (strand) => strand.check
      );

      if (filterd_strandsList.length == 1) {
        selectedStrands_temp_beta
          .filter((strand) => strand.check)[0]
          .standards.map((standard) => {
            standard.check = false;
          });
      }

      return {
        ...state,
        classComparison: {
          ...state.classComparison,
          Std_Comparison: {
            ...state.classComparison.Std_Comparison,
            PopupFilter: {
              ...state.classComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.classComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: selectedStrands_temp_beta,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      let selectedStrands_temp_beta = JSON.parse(
        JSON.stringify(
          state.studentComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp_beta
        )
      );

      let filterd_strandsList = selectedStrands_temp_beta.filter(
        (strand) => strand.check
      );

      if (filterd_strandsList.length == 1) {
        selectedStrands_temp_beta
          .filter((strand) => strand.check)[0]
          .standards.map((standard) => {
            standard.check = false;
          });
      }

      return {
        ...state,
        studentComparison: {
          ...state.studentComparison,
          Std_Comparison: {
            ...state.studentComparison.Std_Comparison,
            PopupFilter: {
              ...state.studentComparison.Std_Comparison.PopupFilter,
              Strands_And_Standards: {
                ...state.studentComparison.Std_Comparison.PopupFilter
                  .Strands_And_Standards,
                OpenDropDown: false,
                strands: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards.strands,
                  selectedStrands_temp: selectedStrands_temp_beta,
                },
              },
            },
          },
        },
      };
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function returnSelectedStrandsStatus(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let resultSelectedStrand = action.payload.strand;
  let allStrandsSelected = action.payload.allStrandsSelected;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.districtComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp_beta
        )
      );

      if (resultSelectedStrand == "All") {
        STrands.map((strand) => {
          strand.check = !allStrandsSelected;
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.districtComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      } else {
        STrands.map((strand) => {
          if (strand.strandName === resultSelectedStrand) {
            strand.check = !strand.check;
          }
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.districtComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      }
    } else {
      // For Testscore
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.schoolComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp_beta
        )
      );

      if (resultSelectedStrand == "All") {
        STrands.map((strand) => {
          strand.check = !allStrandsSelected;
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.schoolComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      } else {
        STrands.map((strand) => {
          if (strand.strandName === resultSelectedStrand) {
            strand.check = !strand.check;
          }
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.schoolComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      }
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards
            .strands.selectedStrands_temp_beta
        )
      );

      if (resultSelectedStrand == "All") {
        STrands.map((strand) => {
          strand.check = !allStrandsSelected;
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.classComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      } else {
        STrands.map((strand) => {
          if (strand.strandName === resultSelectedStrand) {
            strand.check = !strand.check;
          }
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.classComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      }
    } else {
      // For Testscore
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    // student context

    if (fromtab == "std_performance") {
      let STrands = JSON.parse(
        JSON.stringify(
          state.studentComparison.Std_Comparison.PopupFilter
            .Strands_And_Standards.strands.selectedStrands_temp_beta
        )
      );

      if (resultSelectedStrand == "All") {
        STrands.map((strand) => {
          strand.check = !allStrandsSelected;
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.studentComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      } else {
        STrands.map((strand) => {
          if (strand.strandName === resultSelectedStrand) {
            strand.check = !strand.check;
          }
          strand.standards.map((standard) => {
            standard.check = true;
          });
        });

        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.studentComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    selectedStrands_temp_beta: STrands,
                  },
                },
              },
            },
          },
        };
      }
    } else {
      // For Testscore
      return {
        ...state,
      };
    }

    // end of studenr context
  } else {
    return {
      ...state,
    };
  }
}

function returnResultDropDownStatus(state, action) {
  let fromContext = action.payload.fromContext;
  let fromtab = action.payload.fromtab;
  let fromWhichDropDown = action.payload.fromWhichDropDown;
  let resultantStatus = action.payload.resultantStatus;

  if (fromContext == "district") {
    if (fromtab == "std_performance") {
      if (fromWhichDropDown == "product") {
      } else if (fromWhichDropDown == "taxonomy") {
        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: resultantStatus,
                },
                GradeParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "grade") {
        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: resultantStatus,
                },
                QuestionParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "question") {
        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: resultantStatus,
                },
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "strands") {
        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: resultantStatus,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "hide-show") {
        return {
          ...state,
          districtComparison: {
            ...state.districtComparison,
            Std_Comparison: {
              ...state.districtComparison.Std_Comparison,
              PopupFilter: {
                ...state.districtComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.districtComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.districtComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    showDescription: resultantStatus,
                  },
                },
              },
            },
          },
        };
      } else {
        return {
          ...state,
        };
      }
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "school") {
    if (fromtab == "std_performance") {
      if (fromWhichDropDown == "product") {
      } else if (fromWhichDropDown == "taxonomy") {
        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: resultantStatus,
                },
                GradeParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "grade") {
        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: resultantStatus,
                },
                QuestionParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "question") {
        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: resultantStatus,
                },
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "strands") {
        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: resultantStatus,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "hide-show") {
        return {
          ...state,
          schoolComparison: {
            ...state.schoolComparison,
            Std_Comparison: {
              ...state.schoolComparison.Std_Comparison,
              PopupFilter: {
                ...state.schoolComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.schoolComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.schoolComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    showDescription: resultantStatus,
                  },
                },
              },
            },
          },
        };
      } else {
        return {
          ...state,
        };
      }
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "class") {
    if (fromtab == "std_performance") {
      if (fromWhichDropDown == "product") {
      } else if (fromWhichDropDown == "taxonomy") {
        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: resultantStatus,
                },
                GradeParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "grade") {
        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: resultantStatus,
                },
                QuestionParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "question") {
        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: resultantStatus,
                },
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "strands") {
        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: resultantStatus,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "hide-show") {
        return {
          ...state,
          classComparison: {
            ...state.classComparison,
            Std_Comparison: {
              ...state.classComparison.Std_Comparison,
              PopupFilter: {
                ...state.classComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.classComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.classComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    showDescription: resultantStatus,
                  },
                },
              },
            },
          },
        };
      } else {
      }
    } else {
      return {
        ...state,
      };
    }
  } else if (fromContext == "student") {
    if (fromtab == "std_performance") {
      if (fromWhichDropDown == "product") {
      } else if (fromWhichDropDown == "taxonomy") {
        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: resultantStatus,
                },
                GradeParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "grade") {
        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: resultantStatus,
                },
                QuestionParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "question") {
        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: resultantStatus,
                },
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: false,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "strands") {
        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                TaxonomyParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .TaxonomyParams,
                  OpenDropDown: false,
                },
                GradeParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .GradeParams,
                  OpenDropDown: false,
                },
                QuestionParams: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .QuestionParams,
                  OpenDropDown: false,
                },
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  OpenDropDown: resultantStatus,
                },
              },
            },
          },
        };
      } else if (fromWhichDropDown == "hide-show") {
        return {
          ...state,
          studentComparison: {
            ...state.studentComparison,
            Std_Comparison: {
              ...state.studentComparison.Std_Comparison,
              PopupFilter: {
                ...state.studentComparison.Std_Comparison.PopupFilter,
                Strands_And_Standards: {
                  ...state.studentComparison.Std_Comparison.PopupFilter
                    .Strands_And_Standards,
                  strands: {
                    ...state.studentComparison.Std_Comparison.PopupFilter
                      .Strands_And_Standards.strands,
                    showDescription: resultantStatus,
                  },
                },
              },
            },
          },
        };
      } else {
      }
    } else {
      return {
        ...state,
      };
    }
  } else {
    return {
      ...state,
    };
  }
}

function returnListFromMaxCount(MaxCount) {
  let returnedArray = [];
  let MaxmCount = MaxCount > 10 ? 10 : MaxCount;

  for (var i = 0; i < MaxmCount; i++) {
    returnedArray.push(i + 1);
  }
  return returnedArray;
}
/**
 *
 * @param {array} arr
 */
/* To get unigue values in multiDimensional array*/
function multiDimensionalUnique(arr) {
  var uniques = [];
  var itemsFound = {};
  for (var i = 0, l = arr.length; i < l; i++) {
    var stringified = JSON.stringify(arr[i]);
    if (itemsFound[stringified]) {
      continue;
    }
    uniques.push(arr[i]);
    itemsFound[stringified] = true;
  }
  return uniques;
}
export function calculateStrandAvgOnTaxonimy_Filter(List) {
  List = List == null || List == undefined ? {} : List;
  let MainList = List == undefined ? [] : JSON.parse(JSON.stringify(List));

  for (var i = 0; i < MainList.length; i++) {
    let standards =
      MainList[i].standards == undefined ? [] : MainList[i].standards;
    let maxScore = 0;
    let score = 0;
    standards.map((item) => {
      maxScore += item.maxScore;
      score += item.score;
    });

    let avg = (score / maxScore) * 100;

    MainList[i].strandAvg = Math.round(avg);
  }

  List = MainList;

  return List;
}

function CompareDrillDown_Redux_Fun(
  state,
  action,
  compareDeepLink,
  Modified_Nav,
  Modified_Apis,
  lastActiveContext
) {
  compareDeepLink = compareDeepLink == undefined ? true : compareDeepLink;
  let std_strandsApi =
    Modified_Nav &&
    Modified_Nav.student &&
    Modified_Apis &&
    Modified_Apis.getStudentData_cls;
  std_strandsApi = std_strandsApi === undefined ? false : std_strandsApi;
  return {
    ...state,
    CompareDeepLink_Enabled: compareDeepLink,
    Orig_Ass_Count_Success: false,
    lastActiveContext: lastActiveContext
      ? lastActiveContext
      : state.lastActiveContext,
    studentComparison: {
      ...state.studentComparison,
      Std_Comparison: {
        ...state.studentComparison.Std_Comparison,
        PopupFilter: {
          ...state.studentComparison.Std_Comparison.PopupFilter,
          C_SP_ApiCalls: {
            ...state.studentComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls,
            getStrands: std_strandsApi
              ? false
              : state.studentComparison.Std_Comparison.PopupFilter.C_SP_ApiCalls
                  .getStrands,
          },
        },
      },
    },
  };
}

export function Get_GradeAndQuestionOfLAtReprorts(
  state,
  PreviousNav,
  Currentnav
) {
  let LastGrade, LastQuestion;

  switch (true) {
    case PreviousNav.district:
      LastGrade =
        state.districtComparison.Std_Comparison.PopupFilter.GradeParams
          .selectedGrade;
      LastQuestion =
        state.districtComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment;

      break;

    case PreviousNav.school:
      LastGrade =
        state.schoolComparison.Std_Comparison.PopupFilter.GradeParams
          .selectedGrade;
      LastQuestion =
        state.schoolComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment;

      break;

    case PreviousNav.class:
      LastGrade =
        state.classComparison.Std_Comparison.PopupFilter.GradeParams
          .selectedGrade;
      LastQuestion =
        state.classComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment;
      break;

    case PreviousNav.student:
      LastGrade =
        state.studentComparison.Std_Comparison.PopupFilter.GradeParams
          .selectedGrade;
      LastQuestion =
        state.studentComparison.Std_Comparison.PopupFilter.QuestionParams
          .selectedTestAssessment;
      break;

    default:
      break;
  }

  return { LastGrade, LastQuestion };
}