import { BatchPrintTypes } from "../Reducer_Action_Types/BatchPrintTypes"
import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';
import { U_S_Action_Types, APPLY_FILTERS_IN_ROSTER_TAB } from '../Reducer_Action_Types/UniversalSelectorActionTypes';
const INITIAL_STATE = {
    triggerStudentListApi: false,
    studentListApiSuccess:false,
    BatchStudentList: [],
    classBatchPrint: {
        popupStatus: false,
        summaryData: {
            selectedOption_temp: "single",
            selectedOption: "single",
            selectedDescr_option_temp: true,
            selectedDescr_option: true,
            triggerAPI: false,
            responseData: [],
            triggerPDF: false,
            currentPageSelected: 1
        },
        singleTestData: {
            selectedOption_temp: "single",
            selectedOption: "single",
            selectedDescr_option_temp: true,
            selectedDescr_option: true,
            triggerAPI: false,
            responseData: [],
            triggerPDF: false,
            currentPageSelected: 1
        }
    },
    studentBatchPrint: {
        popupStatus: false,
        summaryData: {
            selectedOption_temp: "single",
            selectedOption: "single",
            selectedDescr_option_temp: true,
            selectedDescr_option: true,
            triggerAPI: false,
            triggerPDF: false,
            responseData: [],
            currentPageSelected: 1
        },
        singleTestData: {
            selectedOption_temp: "single",
            selectedOption: "single",
            selectedDescr_option_temp: true,
            selectedDescr_option: true,
            triggerAPI: false,
            triggerPDF: false,
            responseData: [],
            currentPageSelected: 1
        }
    }
}

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:
            return INITIAL_STATE
        case BatchPrintTypes.BATCH_PRINTING_POPUP_STATUS:
            return BatchPrintingPopupStatus(state, action)     
        case BatchPrintTypes.BATCH_PRINT_SELECT_DESCRIPTION:
            return batchPrintingSelectDescription(state, action)

        case BatchPrintTypes.BATCH_PRINTING_CANCEL:
            return batchPrintCancel(state, action)

        case BatchPrintTypes.BATCH_PRINTING_SELECTED:
            return batchPrintSelectedOption(state, action)

        case BatchPrintTypes.DEFAULT_REPORT_SELECTED:
            return defaultReportSelectedOption(state, action)
        case BatchPrintTypes.BATCH_PRINT_API:
            return triggerAPI_basedOnSelection(state, action)

        case BatchPrintTypes.BATCH_PRINT_API_SUCCESS:
            return triggerAPI_basedOnSelection_success(state, action)

        case BatchPrintTypes.BATCH_PRINT_RESET_PDF_TRIGGER:
            return reset_pdf_trigger(state, action)

        case BatchPrintTypes.BATCH_PRINT_CURRENT_SELECTED_PAGE:
            return selectedPageForBatchPrint(state, action)
        case BatchPrintTypes.BATCH_PRINT_GET_STUDENTS_LIST:
            return batchPrintGetStudentsList(state, action)
        case BatchPrintTypes.BATCH_PRINT_GET_STUDENTS_LIST_SUCCESS:
            return batchPrintGetStudentsListSuccess(state, action)
        case APPLY_FILTERS_IN_ROSTER_TAB:
            if (action.payload.StateToSet.NavigationByHeaderSelection.Summary_Reports) {

                return {

                    ...state
                }
            }
            return resetStudentList(state, action);

        default:
            return {
                ...state
            }
    }
}

function resetStudentList(state, action) {

    const { sameClass } = action.payload

    if (sameClass) {
        return {
            ...state
        }
    } else {
        return {
            ...state,
            triggerStudentListApi: false,
            BatchStudentList: []
        }
    }

}

function batchPrintGetStudentsList(state, action) {
    return {
        ...state,
        triggerStudentListApi: false
    }
}
function batchPrintGetStudentsListSuccess(state, action) {

    const { payloadData } = action.payload

    let sortedDataList = sortStuddentsListBasedOnLastName(payloadData)

    return {
        ...state,
        triggerStudentListApi: false,
        studentListApiSuccess:true,
        BatchStudentList: sortedDataList
    }
}

function sortStuddentsListBasedOnLastName(payloadData) {

    let sortedIds = []
    let resData = payloadData;
    (resData != undefined && resData != null) ? resData.sort(function (a, b) {

        let firstData = a.lastName == null ? "" : a.lastName;
        let secondData = b.lastName == null ? "" : b.lastName;

        if (firstData < secondData) { return -1; }
        if (firstData > secondData) { return 1; }
        return 0;
    }) : null;

    (resData != undefined && resData != null) ? resData.map(student => {
        sortedIds.push(student.studentId)
    }) : null;
    return sortedIds

}

function selectedPageForBatchPrint(state, action) {
    const { from, fromtab, selectedPage } = action.payload

    if (from == "class") {
        if (fromtab == "summary") {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        currentPageSelected: selectedPage
                    }
                }
            }
        } else {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        currentPageSelected: selectedPage
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        currentPageSelected: selectedPage
                    }
                }
            }
        } else {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        currentPageSelected: selectedPage
                    }
                }
            }
        }
    }

}

function reset_pdf_trigger(state, action) {
    return {
        ...state,
        studentListApiSuccess: false,
        classBatchPrint: {
            ...state.classBatchPrint,
            summaryData: {
                ...state.classBatchPrint.summaryData,
                triggerPDF: false
            },
            singleTestData: {
                ...state.classBatchPrint.singleTestData,
                triggerPDF: false
            }
        },
        studentBatchPrint: {
            ...state.studentBatchPrint,
            summaryData: {
                ...state.studentBatchPrint.summaryData,
                triggerPDF: false
            },
            singleTestData: {
                ...state.studentBatchPrint.singleTestData,
                triggerPDF: false
            }
        }
    }
}

function modifyDataStructure(payloadData) {
    let returnObject = payloadData
    returnObject.summaryList = calculatePercentageOfStudent(payloadData.summaryList)
    returnObject.scoreAndMaxScoreForClass = Object.keys(returnObject.scoreAndMaxScoreForClass).map(function (key) {
        return returnObject.scoreAndMaxScoreForClass[key];
    });
    returnObject.scoreAndMaxScoreForSchool = Object.keys(returnObject.scoreAndMaxScoreForSchool).map(function (key) {
        return returnObject.scoreAndMaxScoreForSchool[key];
    });
    returnObject.scoreAndMaxScoreForDistrict = Object.keys(returnObject.scoreAndMaxScoreForDistrict).map(function (key) {
        return returnObject.scoreAndMaxScoreForDistrict[key];
    });

    return returnObject
}

export function calculatePercentageOfStudent(summaryList) {
    let updatedObject = summaryList
    let upperCount;
    let lowerCount;

    updatedObject = sortAPIDataBasedonLastname(summaryList)

    updatedObject.map((student, index) => {
        lowerCount = null
        upperCount = null
        student.standardAndStrandVODetails.map((singleStrand, strandIndex) => {
            if (singleStrand.maxScore != null) {
                upperCount = upperCount + singleStrand.score
                lowerCount = lowerCount + singleStrand.maxScore
            }
        })
        if (lowerCount == null) {
            student.studentPercentage = null
        } else if (upperCount == 0 && lowerCount == 0) {
            student.studentPercentage = 0
        } else if (lowerCount == 0) {
            student.studentPercentage = 0
        } 
    })

    return updatedObject
}


function triggerAPI_basedOnSelection_success(state, action) {
    const { from, fromtab, payloadData, selectedTaxonomyList } = action.payload

    let selectedTaxonomies = selectedTaxonomyList.length > 0 ? arrayListOfSelectedTaxonomies(selectedTaxonomyList) : []
    let ObjectReStructure = (fromtab == "summary") ? modifyDataStructure(payloadData) : getStructuredObjectOfView(payloadData, selectedTaxonomies);
    if (from == "class") {
        if (fromtab == "summary") {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        triggerAPI: false,
                        triggerPDF: true,
                        responseData: ObjectReStructure
                    }
                }
            }
        } else {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        triggerAPI: false,
                        triggerPDF: true,
                        responseData: ObjectReStructure
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        triggerAPI: false,
                        triggerPDF: true,
                        responseData: ObjectReStructure
                    }
                }
            }
        } else {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        triggerAPI: false,
                        triggerPDF: true,
                        responseData: ObjectReStructure
                    }
                }
            }
        }
    }
}

function triggerAPI_basedOnSelection(state, action) {
    const { from, fromtab, popUpStatus } = action.payload

    if (from == "class") {
        if (fromtab == "summary") {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    popupStatus: popUpStatus,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        selectedDescr_option: state.classBatchPrint.summaryData.selectedDescr_option_temp,
                        selectedOption: state.classBatchPrint.summaryData.selectedOption_temp,
                        triggerAPI: true,
                    }
                }
            }
        } else {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    popupStatus: popUpStatus,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        selectedOption: state.classBatchPrint.singleTestData.selectedOption_temp,
                        triggerAPI: true,
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    popupStatus: popUpStatus,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        selectedDescr_option: state.studentBatchPrint.summaryData.selectedDescr_option_temp,
                        selectedOption: state.studentBatchPrint.summaryData.selectedOption_temp,
                        triggerAPI: true,
                    }
                }
            }
        } else {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    popupStatus: popUpStatus,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        selectedOption: state.studentBatchPrint.singleTestData.selectedOption_temp,
                        triggerAPI: true,
                    }
                }
            }
        }
    }
}

function defaultReportSelectedOption(state, action) {
    const { from, fromtab, popUpStatus } = action.payload

    if (from == "class") {
        if (fromtab == "summary") {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    popupStatus: popUpStatus,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        selectedOption: state.classBatchPrint.summaryData.selectedOption_temp,
                        triggerPDF: true
                    }
                }
            }
        } else {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    popupStatus: popUpStatus,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        selectedOption: state.classBatchPrint.singleTestData.selectedOption_temp,
                        triggerPDF: true
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    popupStatus: popUpStatus,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        selectedOption: state.studentBatchPrint.summaryData.selectedOption_temp,
                        triggerPDF: true
                    }
                }
            }
        } else {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    popupStatus: popUpStatus,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        selectedOption: state.studentBatchPrint.singleTestData.selectedOption_temp,
                        triggerPDF: true
                    }
                }
            }
        }
    }
}

function batchPrintSelectedOption(state, action) {

    const { from, fromtab, selectedOption } = action.payload

    if (from == "class") {
        if (fromtab == "summary") {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        selectedOption_temp: selectedOption
                    }
                }
            }
        } else {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        selectedOption_temp: selectedOption
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        selectedOption_temp: selectedOption
                    }
                }
            }
        } else {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        selectedOption_temp: selectedOption
                    }
                }
            }
        }
    }

}

function batchPrintCancel(state, action) {
    const { from, fromtab } = action.payload

    if (from == "class") {

        if (fromtab == "summary") {
            return {
                ...state,
                studentListApiSuccess:false,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    popupStatus: false,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        triggerPDF: false,
                        selectedDescr_option_temp: state.classBatchPrint.summaryData.selectedDescr_option,
                        selectedOption_temp: state.classBatchPrint.summaryData.selectedOption
                    }
                }
            }
        } else {
            return {
                ...state,
                studentListApiSuccess:false,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    popupStatus: false,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        triggerPDF: false,
                        selectedOption_temp: state.classBatchPrint.singleTestData.selectedOption
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentListApiSuccess:false,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    popupStatus: false,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        triggerPDF: false,
                        selectedDescr_option_temp: state.studentBatchPrint.summaryData.selectedDescr_option,
                        selectedOption_temp: state.studentBatchPrint.summaryData.selectedOption
                    }
                }
            }
        } else {
            return {
                ...state,
                studentListApiSuccess:false,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    popupStatus: false,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        triggerPDF: false,
                        selectedOption_temp: state.studentBatchPrint.singleTestData.selectedOption
                    }
                }
            }
        }
    }
}

function batchPrintingSelectDescription(state, action) {
    const { from, fromtab, selectedOption } = action.payload

    let updatedStatus = !selectedOption

    if (from == "class") {

        if (fromtab == "summary") {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    summaryData: {
                        ...state.classBatchPrint.summaryData,
                        selectedDescr_option_temp: updatedStatus
                    }
                }
            }
        } else {
            return {
                ...state,
                classBatchPrint: {
                    ...state.classBatchPrint,
                    singleTestData: {
                        ...state.classBatchPrint.singleTestData,
                        selectedDescr_option_temp: updatedStatus
                    }
                }
            }
        }

    } else {
        if (fromtab == "summary") {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    summaryData: {
                        ...state.studentBatchPrint.summaryData,
                        selectedDescr_option_temp: updatedStatus
                    }
                }
            }
        } else {
            return {
                ...state,
                studentBatchPrint: {
                    ...state.studentBatchPrint,
                    singleTestData: {
                        ...state.studentBatchPrint.singleTestData,
                        selectedDescr_option_temp: updatedStatus
                    }
                }
            }
        }
    }
}

function BatchPrintingPopupStatus(state, action) {

    const { from } = action.payload

    let resetToDefaultClass_summaryData = INITIAL_STATE.classBatchPrint.summaryData
    let resetToDefaultClass_singleTestData = INITIAL_STATE.classBatchPrint.singleTestData

    let resetToDefaultStudent_summaryData = INITIAL_STATE.studentBatchPrint.summaryData
    let resetToDefaultStudent_singleTestData = INITIAL_STATE.studentBatchPrint.singleTestData
    
    resetToDefaultClass_summaryData.selectedOption_temp = action.payload.batch_options.selectedOption
    resetToDefaultClass_summaryData.selectedDescr_option_temp = action.payload.batch_options.defination

    resetToDefaultStudent_summaryData.selectedOption_temp = action.payload.batch_options.selectedOption
    resetToDefaultStudent_summaryData.selectedDescr_option_temp = action.payload.batch_options.defination

    resetToDefaultClass_singleTestData.selectedOption_temp = action.payload.batch_options.selectedOption
    resetToDefaultClass_singleTestData.selectedDescr_option_temp = action.payload.batch_options.defination

    resetToDefaultStudent_singleTestData.selectedOption_temp = action.payload.batch_options.selectedOption
    resetToDefaultStudent_singleTestData.selectedDescr_option_temp = action.payload.batch_options.defination
    if (from == "class") {
        return {
            ...state,
            triggerStudentListApi: true,
            classBatchPrint: {
                ...state.classBatchPrint,
                popupStatus: true,
                summaryData: resetToDefaultClass_summaryData,
                singleTestData: resetToDefaultClass_singleTestData
            }
        }
    } else {
        return {
            ...state,
            triggerStudentListApi: true,
            studentBatchPrint: {
                ...state.studentBatchPrint,
                popupStatus: true,
                summaryData: resetToDefaultStudent_summaryData,
                singleTestData: resetToDefaultStudent_singleTestData
            }
        }
    }
}

export function getStructuredObjectOfView(AnalysisData, selectedtaxonomies) {

    let selectedTaxonomyArray = selectedtaxonomies.length > 0 ? arrayListOfSelectedTaxonomies(selectedtaxonomies) : []

    const AnalysisData_constant = AnalysisData
    let AnalysisData_updated = {}
    let singleView = ''
    let singleStudent = ''
    AnalysisData_updated.testScore = AnalysisData_constant.testScore
    AnalysisData_updated.testMaxScore = AnalysisData_constant.testMaxScore
    AnalysisData_updated.testAvg = AnalysisData_constant.testAvg
    AnalysisData_updated.testClassScore = AnalysisData_constant.testClassScore
    AnalysisData_updated.testClassMaxScore = AnalysisData_constant.testClassMaxScore
    AnalysisData_updated.testClassAvg = AnalysisData_constant.testClassAvg
    AnalysisData_updated.testSchoolScore = AnalysisData_constant.testSchoolScore
    AnalysisData_updated.testSchoolMaxScore = AnalysisData_constant.testSchoolMaxScore
    AnalysisData_updated.testSchoolAvg = AnalysisData_constant.testSchoolAvg
    AnalysisData_updated.testDistrictScore = AnalysisData_constant.testDistrictScore
    AnalysisData_updated.testDistrictMaxScore = AnalysisData_constant.testDistrictMaxScore
    AnalysisData_updated.testDistrictAvg = AnalysisData_constant.testDistrictAvg

    AnalysisData_updated.testDistrictResultNo = AnalysisData_constant.testDistrictResultNo
    AnalysisData_updated.testClassResultNo = AnalysisData_constant.testClassResultNo
    AnalysisData_updated.testSchoolResultNo = AnalysisData_constant.testSchoolResultNo
    AnalysisData_updated.testResultNo = AnalysisData_constant.testResultNo
    AnalysisData_updated.testByViewForStudentsList = []

    let testScore_aggregated = 0
    let testClassScore_aggregated = 0
    let testSchoolScore_aggregated = 0
    let testDistrictScore_aggregated = 0

    AnalysisData_constant.testByViewForStudentsList.map(studentData => {
        singleStudent = {}
        singleStudent.studentId = studentData.studentId,
            singleStudent.firstName = studentData.firstName,
            singleStudent.lastName = studentData.lastName,
            singleStudent.studentScore = studentData.studentScore,
            singleStudent.studentMaxScore = studentData.studentMaxScore,
            singleStudent.studentAvg = studentData.studentAvg,
            singleStudent.studentClassScore = studentData.studentClassScore,
            singleStudent.studentClassMaxScore = studentData.studentClassMaxScore,
            singleStudent.studentClassAvg = studentData.studentClassAvg,
            singleStudent.studentSchoolScore = studentData.studentSchoolScore,
            singleStudent.studentSchoolMaxScore = studentData.studentSchoolMaxScore,
            singleStudent.studentSchoolAvg = studentData.studentSchoolAvg,
            singleStudent.studentDistScore = studentData.studentDistScore,
            singleStudent.studentDistMaxScore = studentData.studentDistMaxScore,
            singleStudent.studentDistAvg = studentData.studentDistAvg,
            singleStudent.viewDetails = []
        studentData.views != null ? studentData.views.map((singleViewData) => {
            singleView = {}

            if (selectedTaxonomyArray.includes(singleViewData.view) || (selectedTaxonomyArray.length == 0)) {
                singleView.view = singleViewData.view
                singleView.setId = singleViewData.setId
                let viewDetailsList = []

                singleViewData.viewDetails.map((singleRowData) => {
                    singleRowData.standardsList.map((singleStandardsList) => {
                        singleStandardsList.strandName = singleRowData.strandName
                        singleStandardsList.questions = sortQuestionNumbers(singleStandardsList.questions)
                        viewDetailsList.push(singleStandardsList)
                    })
                })
                singleView.viewDetailsList = viewDetailsList
                // AnalysisData_updated.testByViewList.push(singleView)
                singleStudent.viewDetails.push(singleView)
            }
        }) : null
        AnalysisData_updated.testByViewForStudentsList.push(singleStudent)
    })

    AnalysisData_updated.testByQuestionForStudentsList = AnalysisData_constant.testByQuestionForStudentsList
    // sort students list based on last name
    AnalysisData_updated.testByViewForStudentsList.sort(function (a, b) {
        let firstData = a.lastName == null ? "" : a.lastName;
        let secondData = b.lastName == null ? "" : b.lastName;
        if (firstData < secondData) { return -1; }
        if (firstData > secondData) { return 1; }
        return 0;
    })
    AnalysisData_updated.testByQuestionForStudentsList.sort(function (a, b) {
        let firstData = a.lastName == null ? "" : a.lastName;
        let secondData = b.lastName == null ? "" : b.lastName;
        if (firstData < secondData) { return -1; }
        if (firstData > secondData) { return 1; }
        return 0;
    })

    // sort student list based on student last name
    AnalysisData_updated.testByViewForStudentsList.map(studentData => {
        studentData.viewDetails.map(viewData => {
            viewData.viewDetailsList.sort((a, b) => (a.standardShortValue > b.standardShortValue) ? 1 : -1)
        })
    })
    AnalysisData_updated.testByQuestionForStudentsList.map(studentData => {
        studentData.questions != null ? studentData.questions.sort(function (a, b) {
            if (a.questionNo < b.questionNo) { return -1; }
            if (a.questionNo > b.questionNo) { return 1; }
            return 0;
        }) : null
    })

    AnalysisData_updated.testByQuestionForStudentsList.map(studentData => {
        studentData.questions != null ? studentData.questions.map(viewData => {
            // testScore_aggregated += (viewData.questionScore != null) ? truncateSingleValue(viewData.questionScore) : 0
            // testClassScore_aggregated += (viewData.questionClassScore != null) ? truncateSingleValue(viewData.questionClassScore) : 0
            // testSchoolScore_aggregated += (viewData.questionSchoolScore != null) ? truncateSingleValue(viewData.questionSchoolScore) : 0
            // testDistrictScore_aggregated += (viewData.questionDistrictScore != null) ? truncateSingleValue(viewData.questionDistrictScore) : 0

            viewData.views.map(viewSingle => {
                viewSingle.viewDetails.sort(function (a, b) {
                    if (a.standardShortValue < b.standardShortValue) { return -1; }
                    if (a.standardShortValue > b.standardShortValue) { return 1; }
                    return 0;
                })
            })
        }) : null
    })

    // AnalysisData_updated.testScore = testScore_aggregated
    // AnalysisData_updated.testClassScore = testClassScore_aggregated
    // AnalysisData_updated.testSchoolScore = testSchoolScore_aggregated
    // AnalysisData_updated.testDistrictScore = testDistrictScore_aggregated
    AnalysisData_updated.concernedData = AnalysisData_constant.concernedData

    return AnalysisData_updated
}
export function sortQuestionNumbers(questionsList) {

    let updatedList = questionsList

    updatedList.sort(function (a, b) {
        if (a.questionNo < b.questionNo) { return -1; }
        if (a.questionNo > b.questionNo) { return 1; }
        return 0;
    })

    return updatedList
}
export function arrayListOfSelectedTaxonomies(selectedTaxonomyList) {

    let selectedTaxArray = []

    let selectedTaxonomyList_test = selectedTaxonomyList.filter(taxonomy => taxonomy.check == true)

    selectedTaxonomyList_test.map(item => selectedTaxArray.push(item.taxonomy_Name))

    return selectedTaxArray

}
export function truncateSingleValue(value) {
    return value;
    //return Math.floor(value * Math.pow(10, 2)) / (Math.pow(10, 2));
}
function sortAPIDataBasedonLastname(payloadData) {

    let resData = payloadData
    resData.sort(function (a, b) {

        let firstData = a.lastName == null ? "" : a.lastName;
        let secondData = b.lastName == null ? "" : b.lastName;

        if (firstData < secondData) { return -1; }
        if (firstData > secondData) { return 1; }
        return 0;
    })

    resData.map(studentData => {
        studentData.standardAndStrandVODetails != null ? studentData.standardAndStrandVODetails.sort(function (a, b) {

            let firstData = a.standardShortValue == null ? "" : a.standardShortValue;
            let secondData = b.standardShortValue == null ? "" : b.standardShortValue;

            if (firstData < secondData) { return -1; }
            if (firstData > secondData) { return 1; }
            return 0;
        }) : null
    })

    return resData

}