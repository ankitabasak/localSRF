const INITIAL_STATE = {
  CommonFilterData: {
    proficiency: {
      independent: true,
      instructional: true,
      frustrational: true
    },
    language: { english: true, spanish: true },
    category: { fiction: true, nonfiction: true },
    type: { unseen: true, seen: true }
  },
  showPopup: false,
  constructedData: '',
  filerDataSaved:{}
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case 'proficiency':
      switch (action.key) {
        case 'independent':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
        case 'instructional':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
        case 'frustrational':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
      }
    case 'language':
      switch (action.key) {
        case 'english':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
        case 'spanish':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
      }
    case 'category':
      switch (action.key) {
        case 'fiction':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
        case 'nonfiction':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
      }
    case 'type':
      switch (action.key) {
        case 'unseen':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
        case 'seen':
          return {
            ...state,
            CommonFilterData: updateClass(action, state),
            showPopup: false,
            constructedData: filterData(state.CommonFilterData)
          };
      }
    case 'summaryFlagStatus':
      return {
        ...state,
        showPopup: action.payload
      }
    case 'update_filter':
      return {
        ...state,
        CommonFilterData: returnFilterData(state.CommonFilterData,
          action.payLoad, action.key),
        constructedData: filterData(returnFilterData(state.CommonFilterData,
          action.payLoad, action.key))
      }
      case 'save_selected_filter':
        return {
        ...state,
        filerDataSaved: action.payLoad,
        constructedData: filterData(action.payLoad)
      }
      case 'reset_filter':
        return {
        ...state,
        CommonFilterData: action.payLoad,
        constructedData: filterData(action.payLoad)
        }
    default:
      return {
        ...state,
        constructedData: filterData(state.CommonFilterData),
        filerDataSaved: state.CommonFilterData
      };
  }
};

//update class initial state

function updateClass(action, state) {
  state.CommonFilterData[action.type][action.key] = action.value;
  return state.CommonFilterData;
}

function filterData(data) {
  let summaryFilter = {
    Independent: data.proficiency.independent,
    Instructional: data.proficiency.instructional,
    Frustrational: data.proficiency.frustrational,
    English: data.language.english,
    Spanish: data.language.spanish,
    Fiction: data.category.fiction,
    Nonfiction: data.category.nonfiction,
    Unseen: data.type.unseen,
    Seen: data.type.seen
  }

  let selFilter = Object.keys(summaryFilter).filter((obj) => {
    return summaryFilter[obj]
  })

  return selFilter
}


function returnFilterData(state, payLoad, key) {
  let count = 0;
  let defFilter = {};
  payLoad[key] && Object.values(payLoad[key]).map(
    data => {
      if (data == false) {
        count = ++count;
      }
    })

  if (count === Object.values(payLoad[key]).length) {
    if (key === 'proficiency') {
      defFilter = {
        proficiency: {
          independent: true,
          instructional: true,
          frustrational: true
        }
      }
    }
    if (key === 'language') {
      defFilter = {
        language: { english: true, spanish: true },

      }
    }
    if (key === 'category') {
      defFilter = {
        category: { fiction: true, nonfiction: true },
      }
    }
    if (key === 'type') {
      defFilter = {
        type: { unseen: true, seen: true }
      }
    }
    return {
      ...state,
      ...defFilter
    }
  } else {
    return {
      ...state,
      ...payLoad
    }
  }
}