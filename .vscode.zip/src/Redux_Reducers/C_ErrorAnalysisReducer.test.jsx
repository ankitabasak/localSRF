import cErrorAnalysisReducer from './C_ErrorAnalysisReducer'

describe('cErrorAnalysisReducer', () => {
    it('default matches', () => {
      expect(cErrorAnalysisReducer(undefined, {})).toMatchSnapshot();
    });

    it('test CLASS_EA_DATA_SUCCESS', () => {
      expect(cErrorAnalysisReducer(undefined, {
        type: 'CLASS_EA_DATA_SUCCESS',
      })).toMatchSnapshot();
    });
});
