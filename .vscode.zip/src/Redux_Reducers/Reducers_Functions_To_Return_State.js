import { PaginationFor_Remaining, STRANS_LINECHART_COUNT_PER_PAGE } from "../Utils/globalVars";
import { Mathceil, findMinAndMaxTestTabDates } from "./UniversalSelectorReducer";
import {
    Sort_ApiResponse_Payload_Array, Return_TeacherOf_A_Class, Return_ClassOf_A_Student,
    RemoveDuplicateObjectsFromArray, SortArrayBaseOnTrueOrFalse, Get_Ids_Of_Student_List, Sort_By_Date ,formatDate, check_Selected_item_Of_Array, getTimeStampofUTCIfweHaveCurrentDate
} from "../Components/ReusableComponents/AllReusableFunctions";
import { Save_Roster_Details_On_Clicking_School_In_Compare_Reports } from "./U_reducer_functions_to_returnSate";


/**
 * 
 * @param {Object} state 
 * @param {JS Object} action 
 */
export function TS_Overview_Persist_On_Test_Selection_In_School(state, action) {

    let ClassTestScores = state.Test_Scores_OverTime.LineChartList;

    let Function_Response = CheckIsTestIsExistIn_Current_TestScoreList(ClassTestScores, state.Test_Scores_OverTime.SelectedTestData, action.payload.test)

    return {
        ...state, ApiCalls_Reports: {
            ...state.ApiCalls_Reports,
            get_TS_Details: ClassTestScores.length == 0 ? true : Function_Response.Enable_Api_Class
        }, Test_Scores_OverTime: {
            ...state.Test_Scores_OverTime,
            SelectedTestData: ClassTestScores.length == 0 ? action.payload.test : Function_Response.Selectedtest
        },
        ToolTipData: {
            ...state.ToolTipData,
            activatedTickLabelIndex: undefined,
            tooltipData: ClassTestScores.length == 0 ? action.payload.test : Function_Response.Selectedtest
        },
    }

}

/**
 * 
 * @param {Object} state 
 * @param {JS Object} action 
 * 
 * when user selectes any test in class contest then we will persist that test in school report if that test is
 */
export function TS_Persist_InSchoolReport_(state, action) {

    let SchoolTS = state.Sc_Test_Scores_OverTime.ActualLineChartList;

    let Function_Response = CheckIsTestIsExistIn_Current_TestScoreList(SchoolTS, state.Sc_Test_Scores_OverTime.SelectedTestData, action.payload.test)

    return {
        ...state, Sc_ApiCalls: {
            ...state.Sc_ApiCalls,
            get_TS_Details: Function_Response.Enable_Api_Class,
        }, Sc_Test_Scores_OverTime: {
            ...state.Sc_Test_Scores_OverTime,
            SelectedTestData: Function_Response.Selectedtest
        }, Sc_ToolTipData: {
            ...state.Sc_ToolTipData,
            activatedTickLabelIndex: undefined,
            tooltipData: Function_Response.Selectedtest
        }

    }
}

/**
 * 
 * @param {Array} List 
 * @param {Object} presentTest 
 * @param {JS Object} action 
 * 
 * @returns {Object}
 * 
 * will check and return if the selected test is there in TestScore Overview List.
 */
export function CheckIsTestIsExistIn_Current_TestScoreList(List, presentTest, S_Test) {
    let Selectedtest = presentTest == undefined || presentTest == null ? {} : presentTest;

    let Enable_Api_Class = false;

    let Index = -1;

    if (List.length > 0) {
        Index = List.findIndex(T => T.componentCode == S_Test.componentCode);

        if (Index > -1) {
            Enable_Api_Class = true;
            Selectedtest = List[Index];
        }
    } else {
        Enable_Api_Class = true;
        Selectedtest = S_Test
    }

    /**
     * if present test of school/class and selected test is same. than no api call. 
     */
    if (presentTest.componentCode == S_Test.componentCode) {
        Enable_Api_Class = false;
    }

    return { Selectedtest, Enable_Api_Class, Index }

}


/**
 * 
 * @param {Object} state 
 * @param {JS Object} action 
 * 
 * when Sorting  Class list of Strands From School ==> StrandsAssessment ==> Overview  by using Header.
 */

export function saveSorted_Class_List_Using_Header(state, action) {

    let SortedTotalPages = 0;
    if (action.payload.Navigation.S_performance) {

        if (action.payload.SortedArray !== null) {
            SortedTotalPages = action.payload.SortedArray.length > 0 ? Mathceil(action.payload.SortedArray.length, PaginationFor_Remaining.CountPerPage) : 0
        }

        return {
            ...state,
            Sc_StandardPerformance_Overview: {
                ...state.Sc_StandardPerformance_Overview,
                SP_StudentsList: action.payload.SortedArray,
                SortedArray_SP_StudentsList: action.payload.SortedArray,
                MinValue: action.payload.minValue,
                MaxValue: action.payload.maxValue,
                Sorting_Column: action.payload.maxValue == 100 ? '' : state.Sc_StandardPerformance_Overview.Sorting_Column,
                Sorting_Type: action.payload.maxValue == 100 ? '' : state.Sc_StandardPerformance_Overview.Sorting_Type,
                ActiveHeaderColumn: action.payload.ActiveColumn,
                StdList_Pagination: {
                    ...state.Sc_StandardPerformance_Overview.StdList_Pagination,
                    totalPagesCount: SortedTotalPages,
                    pageAt: 1,
                    countStart: 0,
                    Bubble_Start: 1,
                    countEnd: PaginationFor_Remaining.CountPerPage,
                }
            }
        }

    } else {


        if (action.payload !== null) {
            SortedTotalPages = action.payload.SortedArray.length > 0 ? Mathceil(action.payload.SortedArray.length, PaginationFor_Remaining.CountPerPage) : 0
        }

        return {
            ...state,
            Sc_TS_Class_ListTable: {
                ...state.Sc_TS_Class_ListTable,
                List: action.payload.SortedArray,
                SortedArray: action.payload.SortedArray,
                MinValue: action.payload.minValue,
                MaxValue: action.payload.maxValue,
                Sorting_Column: action.payload.maxValue == 100 ? '' : state.Sc_TS_Class_ListTable.Sorting_Column,
                Sorting_Type: action.payload.maxValue == 100 ? '' : state.Sc_TS_Class_ListTable.Sorting_Type,
                ActiveHeaderColumn: action.payload.ActiveColumn,
            }, Sc_Pagination_For_Remaining: {
                ...state.Sc_Pagination_For_Remaining,
                totalPagesCount: SortedTotalPages,
                pageAt: 1,
                countStart: 0,
                Bubble_Start: 1,
                countEnd: PaginationFor_Remaining.CountPerPage,
            }
        }
    }
}


/**
 * 
 * @param {Object} state 
 * @param {JS Object} action 
 * when select any pagination bubble in school report will return this state changes.
 */
export function ChangeBubbleFor_RemainingPagination_In(state, action, from) {

    let fromSC_Overview = action.payload.Nav.S_performance && (action.payload.Nav.school || action.payload.Nav.district);

    let Page_At_RP = action.payload.positionfrom_BubbleStart + action.payload.BubbleStart;
    let start_RP;
    let end_RP;

    if (action.payload.Nav.school && from == "school_reducer") {

        let Page_Count_RP = fromSC_Overview ? state.Sc_StandardPerformance_Overview.StdList_Pagination.Countof_Page_StudentsList : state.Sc_Pagination_For_Remaining.Countof_Page_StudentsList;

        start_RP = (Page_At_RP * Page_Count_RP) - Page_Count_RP;
        end_RP = Page_At_RP * Page_Count_RP;

        if (fromSC_Overview) {
            return {
                ...state, Sc_StandardPerformance_Overview: {
                    ...state.Sc_StandardPerformance_Overview,
                    StdList_Pagination: {
                        ...state.Sc_StandardPerformance_Overview.StdList_Pagination,
                        pageAt: Page_At_RP,
                        countStart: start_RP,
                        countEnd: end_RP,
                    }
                }
            }
        } else {
            return {
                ...state, Sc_Pagination_For_Remaining: {
                    ...state.Sc_Pagination_For_Remaining,
                    pageAt: Page_At_RP,
                    countStart: start_RP,
                    countEnd: end_RP,
                }
            }
        }
    } else if (action.payload.Nav.district && from == "District_reducer") {

        let Page_Count_RP = fromSC_Overview ? state.D_StandardPerformance_Overview.StdList_Pagination.Countof_Page_StudentsList : state.D_Pagination_For_Remaining.Countof_Page_StudentsList;

        start_RP = (Page_At_RP * Page_Count_RP) - Page_Count_RP;
        end_RP = Page_At_RP * Page_Count_RP;


        if (fromSC_Overview) {
            return {
                ...state, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StdList_Pagination: {
                        ...state.D_StandardPerformance_Overview.StdList_Pagination,
                        pageAt: Page_At_RP,
                        countStart: start_RP,
                        countEnd: end_RP,
                    }
                }
            }
        } else {
            return {
                ...state, D_Pagination_For_Remaining: {
                    ...state.D_Pagination_For_Remaining,
                    pageAt: Page_At_RP,
                    countStart: start_RP,
                    countEnd: end_RP,
                }
            }
        }
    }
    else {

        return {
            ...state
        }

    }
}

/**
 * 
 * @param {Object} state 
 * @param {JS Object} action
 * 
 * is for all reports (class,school,district). to show info icon  
 */
export function Open_Or_Close_Info_POPUP_in_Strands_Compos(state, action) {

    if (action.payload.Nav.class) {
        return {
            ...state, StandardPerformance_Overview: {
                ...state.StandardPerformance_Overview,
                openInfoPopUp_in_P_OT_header: action.payload.OpenOrClose
            }
        }
    } else if (action.payload.Nav.school) {
        return {
            ...state, Sc_StandardPerformance_Overview: {
                ...state.Sc_StandardPerformance_Overview,
                openInfoPopUp_in_P_OT_header: action.payload.OpenOrClose
            }
        }
    } else if (action.payload.Nav.district) {

        return {
            ...state, D_StandardPerformance_Overview: {
                ...state.D_StandardPerformance_Overview,
                openInfoPopUp_in_P_OT_header: action.payload.OpenOrClose
            }
        }
    } else {
        return {
            ...state
        }
    }

}

/**
 * 
 * @param {Object} state 
 * @param {JS Object} action
 * 
 * save line chart data of selected standard or strand in school report.
 *  
 */
export function LineChartDataOf_School_Strands(state, action) {
    const { persist_compare_checkboxes } = action.payload;
    if (action.payload.PayloadData == null || action.payload.PayloadData == undefined) {
        return {
            ...state, Sc_ApiCalls: {
                ...state.Sc_ApiCalls,
                loading_on_strands_Lc: false,
            }, Sc_StandardPerformance_Overview: {
                ...state.Sc_StandardPerformance_Overview,
                LineChartData: [],
                ActualLineChartData: [],
                checkSchool: persist_compare_checkboxes.checkSchool,
                checkDistrict: persist_compare_checkboxes.checkDistrict
            }
        }
    }
    else {
        let LineChart_Data = Sort_ApiResponse_Payload_Array(action.payload.PayloadData, 'linechartlist');

        let PagesgCount = 0;
        if (LineChart_Data !== null) {
            PagesgCount = Mathceil(LineChart_Data.length, STRANS_LINECHART_COUNT_PER_PAGE);
        }

        let PageStartAt_L = PagesgCount > 3 ? PagesgCount - 2 : 1;
        let PageCountEnd_L = PagesgCount * STRANS_LINECHART_COUNT_PER_PAGE;
        let pageCountStart_L = PageCountEnd_L - STRANS_LINECHART_COUNT_PER_PAGE;
        return {
            ...state, Sc_ApiCalls: {
                ...state.Sc_ApiCalls,
                loading_on_strands_Lc: false,
            }, Sc_StandardPerformance_Overview: {
                ...state.Sc_StandardPerformance_Overview,
                LineChartData: LineChart_Data,
                ActualLineChartData: LineChart_Data,
                CompareDataisThere: true,
                checkSchool: persist_compare_checkboxes.checkSchool,
                checkDistrict: persist_compare_checkboxes.checkDistrict,
                lastSelectedCheckBox: '',
                LineChart_Pagination: {
                    ...state.Sc_StandardPerformance_Overview.LineChart_Pagination,
                    Chart_Bubble_Start: PageStartAt_L,
                    Chart_Page_Count_Start: pageCountStart_L,
                    Chart_pageAt: PagesgCount,
                    Chart_Page_Count_End: PageCountEnd_L,
                    Chart_TotalBubbles: PagesgCount
                }
            }, Sc_ToolTipData: {
                xpoint: 0,
                x_coords: 0,
                y_coords: 0,
                tooltipData: action.payload.PayloadData[action.payload.PayloadData.length - 1],
                activatedTickLabelIndex: null,
            },
        }
    }
}

export function Compare_Class_And_Student_Tests(arr1, arr2) {
    arr1 = arr1 != undefined ? JSON.parse(JSON.stringify(arr1)) : [];
    let TestList = arr2 && JSON.parse(JSON.stringify(arr2));
    let _Call_Apis = false;

    for (var i = 0; i < TestList.length; i++) {

        let TestInClass_Context = arr1.find(function (element) {
            return element.componentCode == TestList[i].componentCode;
        });
        if (TestInClass_Context !== undefined) {
            if (TestInClass_Context.check == TestList[i].check) {
            } else {
                TestList[i].check = TestInClass_Context.check;
                _Call_Apis = true;
            }
        }
    }
    return { TestList, _Call_Apis }
}


export function TestStatus_Context_Selection(state, action, assessmentLinkData,updatedLastActivePropsState) {

    let Previous_Data = state.NavigationByHeaderSelection.class ?
        JSON.parse(JSON.stringify(updatedLastActivePropsState.Class_TestStaus)) :
        state.NavigationByHeaderSelection.student ?
            JSON.parse(JSON.stringify(updatedLastActivePropsState.Student_TestStaus)) :
            state.NavigationByHeaderSelection.school ? { ...updatedLastActivePropsState.School_TestStaus } :
                { ...updatedLastActivePropsState.District_TestStaus };

    let Response = GetContext_Universal_RosterData_Of_PreviousReports(state, Previous_Data, action.payload.TeststatusDataisThere,undefined,undefined, updatedLastActivePropsState);

    let SelectedtsList = Response.UniversTest.SelectedTestList

    let MinAndMax_Dates_SP = findMinAndMaxTestTabDates(SelectedtsList, false);


    let CallGrades = state.NavigationByHeaderSelection.district && Previous_Data.RosterGradeList.length == 0 ?
        true : state.ApiCalls.get_Roster_Grades_TS;

    let StateToSet = {
        ...state, assessmentLinkData: assessmentLinkData ? assessmentLinkData : state.assessmentLinkData,
        ApiCalls: {
            ...state.ApiCalls,
        }, ContextHeader: {
            ...state.ContextHeader,
            Roster_Tab: Response.ContextRoster,
            TestTab: Response.ContextTest,
            tests: Response.Cntx_Test,
            minTestDate: MinAndMax_Dates_SP.min_Date,
            maxTestDate: MinAndMax_Dates_SP.max_Date,
            minDateTime: MinAndMax_Dates_SP.min_Time,
            maxDateTime: MinAndMax_Dates_SP.max_Time,
        }, UniversalSelecter: {
            ...state.UniversalSelecter,
            Roster_Data: Response.Univers_Roster,
            TestTab: Response.UniversTest
        },

        NavigationByHeaderSelection: {
            ...state.NavigationByHeaderSelection,
            S_performance: false,
            T_scores: false,
            st_analysis: false,
            test_status: true,
            Summary_Reports: false,
            usageReport:false,
            Assessement:true
        }
    }
    let TestModified = false;

    return {
        StateToSet,
        TestModified,
        updatedLastActivePropsState
    }
}


export function GetContext_Universal_RosterData_Of_PreviousReports(state, Previous_Data, TeststatusDataisThere, From_tsor_SP, SelectedOpt,updatedLastActivePropsState) {
    
    From_tsor_SP = From_tsor_SP == undefined ? false : From_tsor_SP;

    let call_SchoolApi = state.ApiCalls.Get_Selected_School_Info;

    let Test_List_Normal = Previous_Data.TestList;
    let Test_Types_Normal = Previous_Data.TestTypes;
    let SelectedTest_List = Test_List_Normal.filter(item => item.check);
    let SelectedTypes = Test_Types_Normal.filter(item => item.check);
    let Cntx_Test = ""

    if (Test_List_Normal.length == SelectedTest_List.length && Test_List_Normal.length !== 1) {
        Cntx_Test = "All (" + SelectedTest_List.length + ")"
    } else if (SelectedTest_List.length == 1) {
        Cntx_Test = SelectedTest_List[0].testName
    } else if (SelectedTypes.length == 1) {
        Cntx_Test = SelectedTypes[0].testTypeName + " (" + SelectedTest_List.length + ")";
    } else {
        Cntx_Test = "Custom (" + SelectedTest_List.length + ")";
    }

    let MinAndMax_Dates_TS = findMinAndMaxTestTabDates(SelectedTest_List, false);
    Test_List_Normal = SortArrayBaseOnTrueOrFalse(Test_List_Normal);
    Test_Types_Normal = SortArrayBaseOnTrueOrFalse(Test_Types_Normal);

    let Prev_dataisThere = TeststatusDataisThere == undefined ? false : TeststatusDataisThere;
    let Nav = state.NavigationByHeaderSelection;


    if (Nav.student && Nav.test_status && SelectedOpt == "st_analysis") {
        Previous_Data.selectedStudent = state.ContextHeader.Roster_Tab.SelectedStudent
    }



    let NoData_for_StudentOn_ST_Nav_Click = false;
    if ((Nav.student || Nav.class || Nav.school) && (SelectedOpt == "S_performance" || SelectedOpt == "T_scores")) {

        if (Prev_dataisThere || (!Prev_dataisThere && From_tsor_SP) || (!Prev_dataisThere && state.NavigationByHeaderSelection.test_status)) {


            let LastSelected = Nav.student ? Previous_Data.selectedStudent :
                Nav.class ? Previous_Data.selectedClass :
                    Nav.school ? Previous_Data.selectedSchool : {};
            LastSelected = LastSelected == undefined ? {} : LastSelected;

            if (LastSelected.id == undefined) {


                let stdList = []

                switch (true) {

                    case Nav.student:
                        let PreviousClassData = JSON.parse(JSON.stringify(updatedLastActivePropsState.Class_Report));

                        if (PreviousClassData.selectedClass.id == undefined) {
                            NoData_for_StudentOn_ST_Nav_Click = true;

                            break;

                        }

                        stdList = PreviousClassData.StudentList;

                        Previous_Data.SchoolList = PreviousClassData.SchoolList;
                        Previous_Data.selectedSchool = PreviousClassData.selectedSchool,
                            SchoolIds = [PreviousClassData.selectedSchool.id],
                            Previous_Data.RosterGradeList = PreviousClassData.RosterGradeList,
                            Previous_Data.selectedRosterGrade = PreviousClassData.selectedRosterGrade,
                            Previous_Data.TeachersList = PreviousClassData.TeachersList,
                            Previous_Data.selectedTeacher = PreviousClassData.selectedTeacher,
                            TeacherId = Get_Ids_Of_Student_List(Previous_Data.TeachersList.filter(item => item.check)),
                            Previous_Data.classList = PreviousClassData.classList,
                            Previous_Data.selectedClass = PreviousClassData.selectedClass

                        stdList = Sort_ApiResponse_Payload_Array(stdList, 'studentslist');
                        Previous_Data.selectedStudent = stdList[0]
                        stdList = check_Selected_item_Of_Array(stdList, Previous_Data.selectedStudent)
                        Previous_Data.StudentList = stdList
                        stdids = [Previous_Data.selectedStudent.id];

                        ClasIds = [Previous_Data.selectedClass.id];

                        break;

                    case Nav.class:

                        let PreviousSchoolData =
                            Nav.test_status ?
                                { ...updatedLastActivePropsState.School_TestStaus }
                                : JSON.parse(JSON.stringify(updatedLastActivePropsState.School_Report));
                        if (PreviousSchoolData.classList.length == 0) {

                            PreviousSchoolData =
                                Nav.test_status ?
                                    { ...updatedLastActivePropsState.Class_TestStaus }
                                    : JSON.parse(JSON.stringify(updatedLastActivePropsState.Class_Report));
                        }

                        let clasList = [...Sort_ApiResponse_Payload_Array(PreviousSchoolData.classList, 'classlist')];
                        let TeachersList = [...Sort_ApiResponse_Payload_Array(PreviousSchoolData.TeachersList, 'teacherlist')];
                        let SelectedTeacher = {}
                        let SelectedClass = clasList[0];
                        clasList = check_Selected_item_Of_Array(clasList, SelectedClass);

                        TeachersList.map(item => {
                            let clasList = item.classes;

                            if (SelectedTeacher.id == undefined) {
                                let Find = clasList.find(item => item.id == SelectedClass.id);

                                if (Find !== undefined && Find !== null) {
                                    item.check == true;
                                    SelectedTeacher = item;
                                } else {
                                    item.check == false;
                                }
                            } else {
                                item.check == false;
                            }
                        });

                        stdList = Sort_ApiResponse_Payload_Array(SelectedClass.students, 'studentslist');

                        stdList.map(item => item.check = true);

                        stdids = Get_Ids_Of_Student_List(stdList);

                        Previous_Data.SchoolList = PreviousSchoolData.SchoolList;
                        Previous_Data.selectedSchool = PreviousSchoolData.selectedSchool,
                            SchoolIds = [PreviousSchoolData.selectedSchool.id],
                            Previous_Data.RosterGradeList = PreviousSchoolData.RosterGradeList,
                            Previous_Data.selectedRosterGrade = PreviousSchoolData.selectedRosterGrade,
                            Previous_Data.TeachersList = TeachersList,
                            Previous_Data.selectedTeacher = SelectedTeacher,
                            TeacherId = [SelectedTeacher.id],
                            Previous_Data.classList = clasList;
                        Previous_Data.selectedClass = SelectedClass
                        Previous_Data.selectedStudent = "All";
                        Previous_Data.StudentList = stdList
                        ClasIds = [Previous_Data.selectedClass.id];

                        break;

                    case Nav.school:

                        let LastDistrictData = { ...updatedLastActivePropsState.District_Report };

                        let Selected_School = Sort_ApiResponse_Payload_Array(LastDistrictData.SchoolList, 'schoolslist')[0];

                        Previous_Data.SchoolList = LastDistrictData.SchoolList;
                        Previous_Data.SchoolList.map(item => {

                            if (item.id == Selected_School.id) {
                                item.check = true;
                            } else {
                                item.check = false;
                            }
                        })

                        Previous_Data.selectedSchool = Selected_School;

                        call_SchoolApi = true;

                        break;

                    default:

                        break;


                }


            }

        }

    }



    if (Previous_Data.selectedSchool.id == undefined && Nav.school && Nav.test_status) {    

        let SchoolsList = [...updatedLastActivePropsState.District_Report.SchoolList];

        SchoolsList = Sort_ApiResponse_Payload_Array(SchoolsList, 'schoolslist');

        Previous_Data.selectedSchool = SchoolsList[0];

        Previous_Data.SchoolList = SchoolsList;
    }

    if (Nav.school && Previous_Data.classList.length == 0) {
        call_SchoolApi = true;
    }
    let stdids = NoData_for_StudentOn_ST_Nav_Click ? [] : Get_Ids_Of_Student_List(Previous_Data.StudentList.filter(item => item.check));
    let ClasIds = NoData_for_StudentOn_ST_Nav_Click ? [] : Get_Ids_Of_Student_List(Previous_Data.classList.filter(item => item.check));
    let TeacherId = NoData_for_StudentOn_ST_Nav_Click ? [] : Get_Ids_Of_Student_List(Previous_Data.TeachersList.filter(item => item.check));
    let SchoolIds = NoData_for_StudentOn_ST_Nav_Click ? [] : Get_Ids_Of_Student_List(Previous_Data.SchoolList.filter(item => item.check));

    // if(!SchoolIds|| SchoolIds.length==0  ) {
    //     SchoolIds = Get_Ids_Of_Student_List()
    // }

    let ContextRoster = (Prev_dataisThere || (!Prev_dataisThere && From_tsor_SP) || (!Prev_dataisThere && state.NavigationByHeaderSelection.test_status)) && !NoData_for_StudentOn_ST_Nav_Click ? {
        ...state.ContextHeader.Roster_Tab,
        schoolsList: Previous_Data.SchoolList,
        SelectedSchool: Previous_Data.selectedSchool,
        SchoolIds: SchoolIds,
        GradesList: Previous_Data.RosterGradeList,
        selectedRosterGrade: Previous_Data.selectedRosterGrade,
        TeachersList: Previous_Data.TeachersList,
        SelectedTeacher: Previous_Data.selectedTeacher,
        TeacherIds: TeacherId,
        ClassList: Previous_Data.classList,
        SelectedClass: Previous_Data.selectedClass,
        ClassIds: ClasIds,
        StudentsList: Previous_Data.StudentList,
        SelectedStudent: Previous_Data.selectedStudent,
        StudentIds: stdids,
    } : state.ContextHeader.Roster_Tab;


    let Univers_Roster = (Prev_dataisThere || (!Prev_dataisThere && From_tsor_SP)) && !NoData_for_StudentOn_ST_Nav_Click ? {
        ...state.UniversalSelecter.Roster_Data,
        ActualSchools: JSON.parse(JSON.stringify(Previous_Data.SchoolList)),
        ActualGrades: Previous_Data.RosterGradeList,
        ActualTeachers: JSON.parse(JSON.stringify(Previous_Data.TeachersList)),
        ActualClasses: JSON.parse(JSON.stringify(Previous_Data.classList)),
        ActualStudents: JSON.parse(JSON.stringify(Previous_Data.StudentList)),
        schoolsList: JSON.parse(JSON.stringify(Previous_Data.SchoolList)),
        SelectedSchool: Previous_Data.selectedSchool,
        SchoolIds: SchoolIds,
        GradesList: Previous_Data.RosterGradeList,
        SelectedGrade: Previous_Data.selectedRosterGrade,
        TeachersList: JSON.parse(JSON.stringify(Previous_Data.TeachersList)),
        SelectedTeacher: Previous_Data.selectedTeacher,
        TeacherIds: TeacherId,
        ClassList: JSON.parse(JSON.stringify(Previous_Data.classList)),
        SelectedClass: Previous_Data.selectedClass,
        ClassIds: ClasIds,
        StudentsList: JSON.parse(JSON.stringify(Previous_Data.StudentList)),
        SelectedStudent: Previous_Data.selectedStudent,
        StudentIds: stdids,
    } : state.UniversalSelecter.Roster_Data;


    let ContextTest = {
        ...state.ContextHeader.TestTab,
        TestList: JSON.parse(JSON.stringify(Test_List_Normal)),
        testtypes: JSON.parse(JSON.stringify(Test_Types_Normal)),
        alltestsChecked: Test_List_Normal.length == SelectedTest_List.length,
    }

    let UniversTest = {
        ...state.UniversalSelecter.TestTab,
        ActualTestList: JSON.parse(JSON.stringify(Test_List_Normal)),
        TestList: JSON.parse(JSON.stringify(Test_List_Normal)),
        LastAppliedTestList: JSON.parse(JSON.stringify(Test_List_Normal)),
        SelectedTestList: JSON.parse(JSON.stringify(SelectedTest_List)),
        selectAllTests: Test_List_Normal.length == SelectedTest_List.length,
        selectAllTests_Final: Test_List_Normal.length == SelectedTest_List.length,
        TestTypes: {
            ...state.UniversalSelecter.TestTab.TestTypes,
            TestTypesList: JSON.parse(JSON.stringify(Test_Types_Normal)),
            LastInstanceTestTypes: JSON.parse(JSON.stringify(Test_Types_Normal)),
            selectedTestTypes: JSON.parse(JSON.stringify(SelectedTypes)),
            LastInstanceSelectedTestTypes: JSON.parse(JSON.stringify(SelectedTypes)),
            selectAllTestTypes: SelectedTypes.length == Test_Types_Normal.length
        }
    }

    if (Nav.district && ContextRoster.SchoolIds.length == 0) {
        let sc_ids = Get_Ids_Of_Student_List(ContextRoster.schoolsList.filter(item => item.check));
        ContextRoster.SchoolIds = sc_ids;
        Univers_Roster.SchoolIds = sc_ids;
    }


    return {
        Univers_Roster, ContextRoster, UniversTest, ContextTest,
        Cntx_Test, call_SchoolApi

    }
}




export function DrillDownTo_Class_TestStatus(state, selected_cls,LastActiveUniversalProps) {

    let PreviousClsData = LastActiveUniversalProps.Class_TestStaus;
    let Prevclas = PreviousClsData.selectedClass;
    Prevclas = Prevclas == undefined || Prevclas == null ? {} : Prevclas;

    let ClasList = state.UniversalSelecter.Roster_Data.ClassList;

    let SelectedClass = ClasList.find(item => item.id == selected_cls.classId);

    let SelectedGrade = state.ContextHeader.Roster_Tab.selectedRosterGrade;

    let ClassList = state.ContextHeader.Roster_Tab.ClassList;
    let TeachersList = state.ContextHeader.Roster_Tab.TeachersList;
    let StdsList = [];
    let SelectedStudent = "All";
    let SelectedTeacher = {}

    if (SelectedClass == undefined) {

        let Grades = state.ContextHeader.Roster_Tab.schoolsList.find((item) => item.id == state.ContextHeader.Roster_Tab.SelectedSchool.id).grades;

        Grades = [...Grades];

        for (var i = 0; i < Grades.length; i++) {
            let teachers = Grades[i].teachers;
            teachers = teachers == null ? [] : teachers;

            for (var j = 0; j < teachers.length; j++) {

                let classes = teachers[j].classes;
                classes.map(item => {
                    if (item.id == selected_cls.classId) {
                        item.check = true;
                        SelectedClass = item;
                        SelectedTeacher = teachers[j];
                        SelectedGrade = Grades[i].grade;
                        ClassList = [...classes];
                        TeachersList = [...teachers];
                        StdsList = [...item.students]
                    } else {
                        item.check = false;
                    }
                });

                if (SelectedClass !== undefined) {
                    break;
                }

            }

            if (SelectedClass !== undefined) {
                break;
            }

        }

    }

    let CallTests = state.ApiCalls.getTests;


    let TestTab_Response = ReturnTestList_OfPreviousData(PreviousClsData)

    if (SelectedClass.id == Prevclas.id && SelectedGrade == PreviousClsData.selectedRosterGrade) {
        CallTests = false;

        ClassList = PreviousClsData.classList;
        TeachersList = PreviousClsData.TeachersList;
        StdsList = PreviousClsData.StudentList;
        SelectedStudent = PreviousClsData.selectedStudent;
        SelectedTeacher = PreviousClsData.selectedTeacher;

    } else {

        StdsList = [...SelectedClass.students];
        CallTests = true;
        ClassList = SortArrayBaseOnTrueOrFalse(Sort_ApiResponse_Payload_Array(ClassList, 'classlist'))
        TeachersList = check_Selected_item_Of_Array(TeachersList, SelectedTeacher);
        TeachersList = SortArrayBaseOnTrueOrFalse(Sort_ApiResponse_Payload_Array(TeachersList, 'teacherlist'))
        StdsList.map(item => item.check = true);
        StdsList = Sort_ApiResponse_Payload_Array(StdsList, 'studentslist')
    };



    let clasIds = [SelectedClass.id];
    let TeacherIds = [SelectedTeacher.id];
    let StdIds = Get_Ids_Of_Student_List(StdsList);


    if (SelectedTeacher.id == undefined) {
        TeachersList.map(item => {
            let classes = item.classes;
            classes = classes == undefined || classes == null ? [] : classes;
            let find = classes.find(element => element.id == SelectedClass.id)
            if (find) {
                item.check = true;
                SelectedTeacher = item

            } else {
                item.check = false;
            }
        })
    }


    return {
        ...state, ApiCalls: {
            ...state.ApiCalls,
            getTests: CallTests
        }, ContextHeader: {
            ...state.ContextHeader,
            tests: TestTab_Response.Cntx_Test,
            Roster_Tab: {
                ...state.ContextHeader.Roster_Tab,

                selectedRosterGrade: SelectedGrade,
                TeachersList: [...TeachersList],
                TeacherIds: TeacherIds,
                SelectedTeacher: SelectedTeacher,

                ClassList: [...ClassList],
                ClassIds: clasIds,
                SelectedClass: SelectedClass,

                StudentsList: [...StdsList],
                StudentIds: StdIds,
                SelectedStudent: SelectedStudent
            },
            TestTab: {
                ...state.ContextHeader.TestTab,
                TestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                testtypes: JSON.parse(JSON.stringify(TestTab_Response.Test_Types_Normal)),
                alltestsChecked: TestTab_Response.Test_List_Normal.length == TestTab_Response.SelectedTest_List.length,
            }
        }, UniversalSelecter: {
            ...state.UniversalSelecter,
            Roster_Data: {
                ...state.UniversalSelecter.Roster_Data,
                SelectedGrade: SelectedGrade,
                ActualTeachers: [...TeachersList],
                ActualClasses: [...ClassList],
                ActualStudents: [...StdsList],

                TeachersList: TeachersList,
                TeacherIds: TeacherIds,
                SelectedTeacher: SelectedTeacher,

                ClassList: ClassList,
                ClassIds: clasIds,
                SelectedClass: SelectedClass,

                StudentsList: StdsList,
                StudentIds: StdIds,
                SelectedStudent: SelectedStudent,

            },
            TestTab: {
                ...state.UniversalSelecter.TestTab,
                ActualTestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                TestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                LastAppliedTestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                SelectedTestList: JSON.parse(JSON.stringify(TestTab_Response.SelectedTest_List)),
                selectAllTests: TestTab_Response.Test_List_Normal.length == TestTab_Response.SelectedTest_List.length,
                selectAllTests_Final: TestTab_Response.Test_List_Normal.length == TestTab_Response.SelectedTest_List.length,
                TestTypes: {
                    ...state.UniversalSelecter.TestTab.TestTypes,
                    TestTypesList: JSON.parse(JSON.stringify(TestTab_Response.Test_Types_Normal)),
                    LastInstanceTestTypes: JSON.parse(JSON.stringify(TestTab_Response.Test_Types_Normal)),
                    selectedTestTypes: JSON.parse(JSON.stringify(TestTab_Response.SelectedTypes)),
                    LastInstanceSelectedTestTypes: JSON.parse(JSON.stringify(TestTab_Response.SelectedTypes)),
                    selectAllTestTypes: TestTab_Response.SelectedTypes.length == TestTab_Response.Test_Types_Normal.length
                }
            }
        }, NavigationByHeaderSelection: {
            ...state.NavigationByHeaderSelection,
            class: true,
            school: false
        }
    }
}


export function DrillDownTo_School_TestStatus(state, selected_School,LastActiveUniversalProps) {

    let SchoolList_For_Dist = [...state.ContextHeader.Roster_Tab.schoolsList]
    let SchoolIs = {};

    SchoolList_For_Dist.map(item => {
        if (item.id == selected_School.schoolId) {
            item.check = true;
            SchoolIs = item;
        } else {
            item.check = false
        }
    })
    let sc_ids = []
    let Grades = [];
    let TeachersLIst = [];
    let ClassList = [];
    let StdList = [];
    let Selected_Grade = "";
    let Selec_Teach = "All";
    let Selected_Clas = "All";
    let Sele_Std = "All";
    let teac_ids = [];
    let cls_ids = [];
    let std_ids = [];



    let LastTestStatusDetails = { ...LastActiveUniversalProps.School_TestStaus };

    if (LastTestStatusDetails.selectedSchool.id !== SchoolIs.id) {
        return {
            ...state, ApiCalls: {
                ...state.ApiCalls,
                Get_Selected_School_Info: true,
                Get_school_sp_grades: false,
                get_SC_Grades_Alias: true,
                get_school_TS_Graph: false,
                get_SC_TS_Graph_Alias: true
            },
            NavigationByHeaderSelection: {
                ...state.NavigationByHeaderSelection,
                class: false,
                school: true,
                district: false,
            },
            ContextHeader: {
                ...state.ContextHeader,
                ActiveGrade_of_District_To_Persist_In_School: state.ContextHeader.Roster_Tab.selectedRosterGrade,
                Roster_Tab: {
                    ...state.ContextHeader.Roster_Tab,
                    SelectedSchool: SchoolIs,
                    schoolsList: JSON.parse(JSON.stringify(SchoolList_For_Dist)),
                    SchoolIds: []
                },
            },
            UniversalSelecter: {
                ...state.UniversalSelecter,
                Roster_Data: {
                    ...state.UniversalSelecter.Roster_Data,
                    ActualSchools: JSON.parse(JSON.stringify(SchoolList_For_Dist)),
                    SchoolIds: [SchoolIs.id],
                    schoolsList: SchoolList_For_Dist,
                    SelectedSchool: SchoolIs
                },
            }
        }

    } else {

        SchoolList_For_Dist = LastTestStatusDetails.SchoolList;
        SchoolIs = LastTestStatusDetails.selectedSchool
        sc_ids = [SchoolIs.id]

        SchoolList_For_Dist = LastTestStatusDetails.SchoolList;
        SchoolIs = LastTestStatusDetails.selectedSchool
        sc_ids = [SchoolIs.id]


        Grades = LastTestStatusDetails.RosterGradeList;
        Selected_Grade = LastTestStatusDetails.selectedRosterGrade;

        TeachersLIst = LastTestStatusDetails.TeachersList;
        Selec_Teach = LastTestStatusDetails.selectedTeacher;
        teac_ids = Get_Ids_Of_Student_List(TeachersLIst.filter(item => item.check));

        ClassList = LastTestStatusDetails.classList;
        Selected_Clas = LastTestStatusDetails.selectedClass;
        cls_ids = Get_Ids_Of_Student_List(ClassList.filter(item => item.check));


        StdList = LastTestStatusDetails.StudentList;
        Sele_Std = LastTestStatusDetails.selectedStudent;
        std_ids = Get_Ids_Of_Student_List(StdList.filter(item => item.check));


        let TestTab_Response = ReturnTestList_OfPreviousData(LastTestStatusDetails)




        return {
            ...state, ContextHeader: {
                ...state.ContextHeader,
                tests: TestTab_Response.Cntx_Test,
                Roster_Tab: {
                    ...state.ContextHeader.Roster_Tab,
                    schoolsList: [...SchoolList_For_Dist],
                    SelectedSchool: SchoolIs,
                    SchoolIds: sc_ids,
                    GradesList: [...Grades],
                    selectedRosterGrade: Selected_Grade,

                    TeachersList: [...TeachersLIst],
                    TeacherIds: teac_ids,
                    SelectedTeacher: Selec_Teach,

                    ClassList: [...ClassList],
                    ClassIds: cls_ids,
                    SelectedClass: Selected_Clas,

                    StudentsList: [...StdList],
                    StudentIds: std_ids,
                    SelectedStudent: Sele_Std
                },
                TestTab: {
                    ...state.ContextHeader.TestTab,
                    TestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                    testtypes: JSON.parse(JSON.stringify(TestTab_Response.Test_Types_Normal)),
                    alltestsChecked: TestTab_Response.Test_List_Normal.length == TestTab_Response.SelectedTest_List.length,
                }
            }, UniversalSelecter: {
                ...state.UniversalSelecter,
                Roster_Data: {
                    ...state.UniversalSelecter.Roster_Data,

                    ActualSchools: [...SchoolList_For_Dist],
                    schoolsList: [SchoolList_For_Dist],
                    SchoolIds: sc_ids,
                    SelectedSchool: SchoolIs,

                    ActualGrades: [...Grades],
                    GradesList: Grades,
                    SelectedGrade: Selected_Grade,

                    ActualTeachers: [...TeachersLIst],
                    ActualClasses: [...ClassList],
                    ActualStudents: [...StdList],

                    TeachersList: TeachersLIst,
                    TeacherIds: teac_ids,
                    SelectedTeacher: Selec_Teach,

                    ClassList: ClassList,
                    ClassIds: cls_ids,
                    SelectedClass: Selected_Clas,

                    StudentsList: StdList,
                    StudentIds: std_ids,
                    SelectedStudent: Sele_Std,

                },
                TestTab: {
                    ...state.UniversalSelecter.TestTab,
                    ActualTestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                    TestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                    LastAppliedTestList: JSON.parse(JSON.stringify(TestTab_Response.Test_List_Normal)),
                    SelectedTestList: JSON.parse(JSON.stringify(TestTab_Response.SelectedTest_List)),
                    selectAllTests: TestTab_Response.Test_List_Normal.length == TestTab_Response.SelectedTest_List.length,
                    selectAllTests_Final: TestTab_Response.Test_List_Normal.length == TestTab_Response.SelectedTest_List.length,
                    TestTypes: {
                        ...state.UniversalSelecter.TestTab.TestTypes,
                        TestTypesList: JSON.parse(JSON.stringify(TestTab_Response.Test_Types_Normal)),
                        LastInstanceTestTypes: JSON.parse(JSON.stringify(TestTab_Response.Test_Types_Normal)),
                        selectedTestTypes: JSON.parse(JSON.stringify(TestTab_Response.SelectedTypes)),
                        LastInstanceSelectedTestTypes: JSON.parse(JSON.stringify(TestTab_Response.SelectedTypes)),
                        selectAllTestTypes: TestTab_Response.SelectedTypes.length == TestTab_Response.Test_Types_Normal.length
                    }
                }
            }, NavigationByHeaderSelection: {
                ...state.NavigationByHeaderSelection,
                district: false,
                school: true
            }
        }

    }

}



function ReturnTestList_OfPreviousData(PreviousData) {

    let Test_List_Normal = PreviousData.TestList;
    let Test_Types_Normal = PreviousData.TestTypes;
    let SelectedTest_List = Test_List_Normal.filter(item => item.check);
    let SelectedTypes = Test_Types_Normal.filter(item => item.check);
    let Cntx_Test = ""

    if (Test_List_Normal.length == SelectedTest_List.length && Test_List_Normal.length !== 1) {
        Cntx_Test = "All (" + SelectedTest_List.length + ")"
    } else if (SelectedTest_List.length == 1) {
        Cntx_Test = SelectedTest_List[0].testName
    } else if (SelectedTypes.length == 1) {
        Cntx_Test = SelectedTypes[0].testTypeName + " (" + SelectedTest_List.length + ")";
    } else {
        Cntx_Test = "Custom (" + SelectedTest_List.length + ")";
    }
    Test_List_Normal = SortArrayBaseOnTrueOrFalse(Test_List_Normal);
    Test_Types_Normal = SortArrayBaseOnTrueOrFalse(Test_Types_Normal);

    return { Cntx_Test, Test_List_Normal, Test_Types_Normal, SelectedTest_List, SelectedTypes }


}


export function MoveToSingleTest_TestStatus(Universal, option, singleGroup,LastActiveUniversalProps) {

    let previousData = { ...LastActiveUniversalProps.Class_Report };

    return {
        ...Universal
    }

}



export function GET_TS_ROSTER_GRADES_SUCCESS_U_Red_Func(state, action) {


    let Grades = action.payload.PayloadData;
    Grades = Grades == undefined || Grades == null ? [] : Grades;

    let NoGrades = false;
    if (Grades.length > 0) {

        Grades.map((item, i) => {
            Grades[i] = { "grade": item, "gradeTestCount": 0 }
        })

    } else {
        NoGrades = Grades.length == 0;
    }

    Grades = Sort_ApiResponse_Payload_Array(Grades, 'grades');

    if (NoGrades) {
        return {
            ...state, ApiCalls: {
                ...state.ApiCalls,
                get_Roster_Grades_TS: false,
                NoGrades_For_TS: NoGrades,
                loadingFor: ""
            }
        }
    } else {
        let SelectedGrade = Grades[0].grade;


        let RosterOpen = state.UniversalFilter == "roster";

        return {
            ...state, ApiCalls: {
                ...state.ApiCalls,
                get_Roster_Grades_TS: false,
                NoGrades_For_TS: NoGrades,
                loadingFor: ""
            }, ContextHeader: {
                ...state.ContextHeader,
                Roster_Tab: {
                    ...state.ContextHeader.Roster_Tab,
                    GradesList: RosterOpen ? state.ContextHeader.Roster_Tab.GradesList : Grades,
                    selectedRosterGrade: RosterOpen ? state.ContextHeader.Roster_Tab.selectedRosterGrade : SelectedGrade,
                }
            }, UniversalSelecter: {
                ...state.UniversalSelecter,
                Roster_Data: {
                    ...state.UniversalSelecter.Roster_Data,
                    GradesList: Grades,
                    SelectedGrade: SelectedGrade
                }
            }

        }

    }



}
