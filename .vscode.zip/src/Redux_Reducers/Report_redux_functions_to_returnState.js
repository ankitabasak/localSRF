import {
  Get_Ids_Of_Student_List,
  Check_Previous_Report_List_Modified_Or_Not,
  ReturnStrandsList_On_Taxonomy,
  Sort_ApiResponse_Payload_Array,
  RemoveDuplicateObjectsFromArray,
  CheckOrUncheckAllValuesOfTestArray,
  getGradeOfClassFromRoaster,
} from "../Components/ReusableComponents/AllReusableFunctions";
import {
  GradesList_From_Roster_Details,
  TeachersList_From_Roster_Details,
} from "./U_reducer_functions_to_returnSate";
import { Compare_Class_And_Student_Tests } from "./Reducers_Functions_To_Return_State";
import { DISTRICT_ROSTER_ENABLED } from "../Utils/globalVars";

/**
 *
 * @param {Store} state
 * @param {Object} action
 */
export function SetClassToolTipDataOnStudent_Linechart_Selection(
  state,
  action
) {
  if (action.payload.updateinclass && action.payload.tooltip_data !== null) {
    return {
      ...state,
      ApiCalls_Reports: {
        ...state.ApiCalls_Reports,
        get_TS_Details: true,
      },
      ToolTipData: {
        ...state.ToolTipData,
        activatedTickLabelIndex: undefined,
        tooltipData: action.payload.tooltip_data,
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

/**
 *
 * @param {Object} state
 * @param {JS Object} action
 *
 * when users selects any strand or standard in school report.
 */
export function PersistOn_Strand_Or_STandard_Selection_inClass_Reducer(
  state,
  action
) {
  let Class_Strands = JSON.parse(
    JSON.stringify(state.StandardPerformance_Overview.originalStrandsList)
  );
  let StrandName =
    state.StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let Avarage = state.StandardPerformance_Overview.selectedStandarAvg;
  let standardId = state.StandardPerformance_Overview.selectedStandardId;
  let StandardsObj = state.StandardPerformance_Overview.selectedstandardObject;
  let index = -1;

  let Sel_Txnm = action.payload.selectedTaxonomy;

  let Txn_Obj =
    state.StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy;
  let Sel_Ques = action.payload.Sel_Ass_Ques;

  let Ques_Obj =
    state.StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment;

  let Strand_Fn_Response = CheckIs_Selected_Strand_exist_in_the_List_Or_Not(
    Class_Strands,
    action.payload.strandName,
    action.payload.standardId,
    action.payload.standard,
    Sel_Txnm,
    Txn_Obj,
    Sel_Ques,
    Ques_Obj
  );

  let ReplaceValues = Strand_Fn_Response.ReplaceValues;

  if (ReplaceValues) {
    StrandName = action.payload.strandName;
    Avarage =
      Strand_Fn_Response.selectedStandarAvg == ""
        ? action.payload.standardAvg
        : Strand_Fn_Response.selectedStandarAvg;
    standardId =
      Strand_Fn_Response.StandardsObj.standardId == undefined
        ? ""
        : Strand_Fn_Response.StandardsObj.standardId;
    StandardsObj = Strand_Fn_Response.StandardsObj;
  } else if (Class_Strands.length == 0) {
    StrandName = action.payload.strandName;
    Strand_Fn_Response.Sel_Txnm = action.payload.selectedTaxonomy;
    Strand_Fn_Response.Sel_Ques = action.payload.Sel_Ass_Ques;
    standardId = action.payload.standardId;
    Avarage = action.payload.standardAvg;
    StandardsObj = {};
  }

  let Right_Side_View_API_Call =
    state.StandardPerformance_Overview.StrandNameOfSelectedStandard == ""
      ? true
      : !(
          StrandName ==
          state.StandardPerformance_Overview.StrandNameOfSelectedStandard
        ) ||
        !(standardId == state.StandardPerformance_Overview.selectedStandardId);

  let TaxonomyRelatedStandardsList =
    Class_Strands.length == 0
      ? []
      : ReturnStrandsList_On_Taxonomy(
          Class_Strands,
          Strand_Fn_Response.Sel_Txnm
        );

  return {
    ...state,
    StandardPerformance_Overview: {
      ...state.StandardPerformance_Overview,
      ActualList: TaxonomyRelatedStandardsList,
      selectedStandardId: standardId,
      selectedStandarAvg: Avarage,
      selectedstandardObject: StandardsObj,
      StrandNameOfSelectedStandard: StrandName,
      strandSelectedFromCompare: true,
      selected_Taxonomy_From_Compare: Strand_Fn_Response.Sel_Txnm,
      selectedStrand_From_Compare: StrandName,
      selectedStandard_From_Compare: standardId,
      StandardPerformanceFilter: {
        ...state.StandardPerformance_Overview.StandardPerformanceFilter,
        Taxonomy: {
          ...state.StandardPerformance_Overview.StandardPerformanceFilter
            .Taxonomy,
          selectedTaxonomy: Strand_Fn_Response.Sel_Txnm,
        },
        TestAssessment: {
          ...state.StandardPerformance_Overview.StandardPerformanceFilter
            .TestAssessment,
          selectedTestAssessment: Strand_Fn_Response.Sel_Ques,
        },
      },
    },
    ApiCalls_Reports: {
      ...state.ApiCalls_Reports,
      Get_OnlyGraphOnCompareInStrandsComp: false,
      get_students_and_Graph_ofClassStrand: Right_Side_View_API_Call,
    },
  };
}

/**
 *
 * @param {Object} state
 * @param {JS Object} action
 *
 * when users selects any strand or standard in school report.
 */
export function InSchoolReducer_On_StrandsSelection_Of_District(state, action) {
  let School_Strands = JSON.parse(
    JSON.stringify(state.Sc_StandardPerformance_Overview.originalList)
  );

  let StrandName =
    state.Sc_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let Avarage = state.Sc_StandardPerformance_Overview.selectedStandarAvg;
  let standardId = state.Sc_StandardPerformance_Overview.selectedStandardId;
  let StandardsObj =
    state.Sc_StandardPerformance_Overview.selectedstandardObject;

  let Txn_Obj =
    state.Sc_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy;

  let Taxonomy = Txn_Obj.selectedTaxonomy;
  let Ass_Ques =
    state.Sc_StandardPerformance_Overview.StandardPerformanceFilter
      .TestAssessment.selectedTestAssessment;
  let index = -1;

  let FindTax =
    state.Sc_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy.TaxonomyList.find(
      (item) => item == action.payload.selectedTaxonomy
    );

  let Sel_Txnm =
    FindTax !== undefined
      ? action.payload.selectedTaxonomy
      : state.Sc_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;

  let Sel_Ques = action.payload.Sel_Ass_Ques;
  let strandSelectedFromCompare = false;

  let Ques_Obj =
    state.Sc_StandardPerformance_Overview.StandardPerformanceFilter
      .TestAssessment;

  let Strand_Fn_Response = CheckIs_Selected_Strand_exist_in_the_List_Or_Not(
    School_Strands,
    action.payload.strandName,
    action.payload.standardId,
    action.payload.standard,
    Sel_Txnm,
    Txn_Obj,
    Sel_Ques,
    Ques_Obj
  );

  let Right_Side_View_API_Call =
    !(
      StrandName ==
      state.Sc_StandardPerformance_Overview.StrandNameOfSelectedStandard
    ) ||
    !(standardId == state.Sc_StandardPerformance_Overview.selectedStandardId);

  standardId =
    FindTax !== undefined
      ? action.payload.standardId
      : state.Sc_StandardPerformance_Overview.selectedStandardId;
  Avarage =
    FindTax !== undefined
      ? action.payload.standardAvg
      : state.Sc_StandardPerformance_Overview.selectedStandarAvg;
  StrandName =
    FindTax !== undefined
      ? action.payload.strandName
      : state.Sc_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  Strand_Fn_Response.Sel_Txnm = Sel_Txnm;
  Strand_Fn_Response.Sel_Ques = Sel_Ques;
  StandardsObj = Strand_Fn_Response.StandardsObj;
  (Right_Side_View_API_Call = true), (strandSelectedFromCompare = true);
  // }

  let TaxonomyRelatedStandardsList = Array.isArray(School_Strands)
    ? []
    : ReturnStrandsList_On_Taxonomy(
        School_Strands,
        Strand_Fn_Response.Sel_Txnm
      );

  TaxonomyRelatedStandardsList =
    TaxonomyRelatedStandardsList == null ? [] : TaxonomyRelatedStandardsList;

  let HeaderStart = state.Sc_StandardPerformance_Overview.headerStart;
  let HeaderEnd = state.Sc_StandardPerformance_Overview.headerEnd;
  if (TaxonomyRelatedStandardsList.strands !== undefined) {
    let strands = JSON.parse(
      JSON.stringify(TaxonomyRelatedStandardsList.strands)
    );

    let IndexofCurrentSTrand = strands.findIndex(
      (item) => item.strandName == StrandName
    );

    let Diff = window.screen.width < 1281 ? 4 : 6;

    if (IndexofCurrentSTrand + 1 > HeaderEnd) {
      HeaderEnd = IndexofCurrentSTrand + 1;
      HeaderStart = HeaderEnd - Diff;
    } else {
      HeaderStart = 0;
      HeaderEnd = Diff;
    }
  }

  return {
    ...state,
    Sc_StandardPerformance_Overview: {
      ...state.Sc_StandardPerformance_Overview,
      ActualList: TaxonomyRelatedStandardsList,
      selectedStandardId: standardId,
      selectedStandarAvg: Avarage,
      selectedstandardObject: StandardsObj,
      StrandNameOfSelectedStandard: StrandName,
      strandSelectedFromCompare: strandSelectedFromCompare
        ? strandSelectedFromCompare
        : "",
      selectedStandard_From_Compare: strandSelectedFromCompare
        ? standardId
        : "",
      selectedStrand_From_Compare: strandSelectedFromCompare ? StrandName : "",
      selected_Taxonomy_From_Compare: strandSelectedFromCompare
        ? action.payload.selectedTaxonomy
        : "",
      headerStart: HeaderStart,
      headerEnd: HeaderEnd,

      StandardPerformanceFilter: {
        ...state.Sc_StandardPerformance_Overview.StandardPerformanceFilter,
        Taxonomy: {
          ...state.Sc_StandardPerformance_Overview.StandardPerformanceFilter
            .Taxonomy,
          selectedTaxonomy: Strand_Fn_Response.Sel_Txnm,
        },
        TestAssessment: {
          ...state.Sc_StandardPerformance_Overview.StandardPerformanceFilter
            .TestAssessment,
          selectedTestAssessment: Strand_Fn_Response.Sel_Ques,
        },
      },
    },
    Sc_ApiCalls: {
      ...state.Sc_ApiCalls,
      Get_OnlyGraphOnCompareInStrandsComp: false,
      get_classList_and_Graph_ofClassStrand: Right_Side_View_API_Call,
    },
  };
}

export function InDistrictReducer_On_StrandsSelection(state, action) {
  let Dist_Strands = JSON.parse(
    JSON.stringify(state.D_StandardPerformance_Overview.originalList)
  );
  let StrandName =
    state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let Avarage = state.D_StandardPerformance_Overview.selectedStandarAvg;
  let standardId = state.D_StandardPerformance_Overview.selectedStandardId;
  let StandardsObj =
    state.D_StandardPerformance_Overview.selectedstandardObject;
  let index = -1;

  if (
    StrandName == action.payload.strandName &&
    standardId == action.payload.standardId
  ) {
    return {
      ...state,
    };
  }

  let Sel_Txnm = action.payload.selectedTaxonomy;

  let Txn_Obj =
    state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy;
  let Sel_Ques = action.payload.Sel_Ass_Ques;

  let Ques_Obj =
    state.D_StandardPerformance_Overview.StandardPerformanceFilter
      .TestAssessment;

  let Strand_Fn_Response = CheckIs_Selected_Strand_exist_in_the_List_Or_Not(
    Dist_Strands,
    action.payload.strandName,
    action.payload.standardId,
    action.payload.standard,
    Sel_Txnm,
    Txn_Obj,
    Sel_Ques,
    Ques_Obj
  );

  let ReplaceValues = Strand_Fn_Response.ReplaceValues;

  if (ReplaceValues) {
    StrandName = action.payload.strandName;
    Avarage =
      Strand_Fn_Response.selectedStandarAvg == ""
        ? action.payload.standardAvg
        : Strand_Fn_Response.selectedStandarAvg;
    standardId =
      Strand_Fn_Response.StandardsObj.standardId == undefined
        ? ""
        : Strand_Fn_Response.StandardsObj.standardId;
    StandardsObj = Strand_Fn_Response.StandardsObj;
  }

  let Right_Side_View_API_Call =
    !(
      StrandName ==
      state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard
    ) ||
    !(standardId == state.D_StandardPerformance_Overview.selectedStandardId);

  let TaxonomyRelatedStandardsList =
    Dist_Strands.length == 0
      ? []
      : ReturnStrandsList_On_Taxonomy(
          Dist_Strands,
          Strand_Fn_Response.Sel_Txnm
        );

  let HeaderStart = state.D_StandardPerformance_Overview.headerStart;
  let HeaderEnd = state.D_StandardPerformance_Overview.headerEnd;
  if (
    TaxonomyRelatedStandardsList.strands !== undefined &&
    TaxonomyRelatedStandardsList.strands !== null
  ) {
    let strands = JSON.parse(
      JSON.stringify(TaxonomyRelatedStandardsList.strands)
    );
    let IndexofCurrentSTrand = strands.findIndex(
      (item) => item.strandName == StrandName
    );
    let Diff = window.screen.width < 1281 ? 4 : 6;
    if (IndexofCurrentSTrand + 1 > HeaderEnd) {
      HeaderEnd = IndexofCurrentSTrand + 1;
      HeaderStart = HeaderEnd - Diff;
    } else {
      HeaderStart = 0;
      HeaderEnd = Diff;
    }
  }
  return {
    ...state,
    D_StandardPerformance_Overview: {
      ...state.D_StandardPerformance_Overview,
      ActualList: TaxonomyRelatedStandardsList,
      selectedStandardId: standardId,
      selectedStandarAvg: Avarage,
      selectedstandardObject: StandardsObj,
      StrandNameOfSelectedStandard: StrandName,
      headerStart: HeaderStart,
      headerEnd: HeaderEnd,
      StandardPerformanceFilter: {
        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
        Taxonomy: {
          ...state.D_StandardPerformance_Overview.StandardPerformanceFilter
            .Taxonomy,
          selectedTaxonomy: Strand_Fn_Response.Sel_Txnm,
        },
        TestAssessment: {
          ...state.D_StandardPerformance_Overview.StandardPerformanceFilter
            .TestAssessment,
          selectedTestAssessment: Strand_Fn_Response.Sel_Ques,
        },
      },
    },
    D_ApiCalls: {
      ...state.D_ApiCalls,
      Get_OnlyGraphOnCompareInStrandsComp: false,
      get_SchoolList_and_Graph_ofStrand: Right_Side_View_API_Call,
    },
  };
}

/**
 *
 * @param {Array} StrandsList
 * @param {String} strandName
 * @param {String} StandardId
 *
 * @returns {Object}
 *
 */
export function CheckIs_Selected_Strand_exist_in_the_List_Or_Not(
  StrandsList,
  strandName,
  StandardId,
  standardObj,
  Sel_Txnm,
  Txn_Obj,
  Sel_Ques,
  Ques_Obj
) {
  let StandardsObj = standardObj == undefined ? {} : standardObj;
  let ReplaceValues = false;
  let selectedStandarAvg = "";

  let index = -1;

  if (Txn_Obj !== undefined) {
  }

  if (
    Txn_Obj !== undefined
      ? Txn_Obj.TaxonomyList.find((txn) => txn == Sel_Txnm) &&
        (Ques_Obj.MaxTestAssessmentCount > Sel_Ques ||
          Ques_Obj.MaxTestAssessmentCount == Sel_Ques)
      : true
  ) {
    if (StrandsList.length > 0 || StrandsList.length == undefined) {
      index = StrandsList.strands.findIndex((p) => p.strandName == strandName);

      if (StandardId !== "" && index > -1) {
        let selectedStrand = StrandsList.strands[index];
        let Standard_Idx = selectedStrand.standards.findIndex(
          (S) => S.standardId == StandardId
        );

        if (Standard_Idx > -1) {
          ReplaceValues = true;
          StandardsObj = selectedStrand.standards[Standard_Idx];
          selectedStandarAvg =
            selectedStrand.standards[Standard_Idx].standardAvg;
        }
      } else if (index > -1) {
        ReplaceValues = true;
        selectedStandarAvg = StrandsList.strands[index].strandAvg;
      }
    } else {
      ReplaceValues = true;
    }
  } else {
    Sel_Txnm = Txn_Obj.selectedTaxonomy;
    Sel_Ques = Ques_Obj.selectedTestAssessment;
  }

  return {
    ReplaceValues,
    StandardsObj,
    selectedStandarAvg,
    Sel_Txnm,
    Sel_Ques,
  };
}

/**
 *
 * @param {Object} state
 * @param {JS Object} action
 */
export function From_SC_Report_On_Strand_Selection_Of_Class(state, action) {
  let School_Strands = state.Sc_StandardPerformance_Overview.ActualList;
  let StrandName =
    state.Sc_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let Avarage = state.Sc_StandardPerformance_Overview.selectedStandarAvg;
  let standardId = state.Sc_StandardPerformance_Overview.selectedStandardId;
  let StandardsObj =
    state.Sc_StandardPerformance_Overview.selectedstandardObject;
  let index = -1;

  let Strand_Fn_Response = CheckIs_Selected_Strand_exist_in_the_List_Or_Not(
    School_Strands,
    action.payload.strandName,
    action.payload.standardId,
    action.payload.standard
  );

  let ReplaceValues = Strand_Fn_Response.ReplaceValues;

  if (ReplaceValues) {
    StrandName = action.payload.strandName;
    Avarage =
      Strand_Fn_Response.selectedStandarAvg == ""
        ? action.payload.standardAvg
        : Strand_Fn_Response.selectedStandarAvg;
    standardId =
      Strand_Fn_Response.StandardsObj.standardId == undefined
        ? ""
        : Strand_Fn_Response.StandardsObj.standardId;
    StandardsObj = Strand_Fn_Response.StandardsObj;
  }

  let Right_Side_View_API_Call = !(
    StrandName ==
      state.Sc_StandardPerformance_Overview.StrandNameOfSelectedStandard &&
    standardId == state.Sc_StandardPerformance_Overview.selectedStandardId
  );

  let Right_Std_list =
    state.Sc_StandardPerformance_Overview.List_Includes_NullScores.length !== 0;

  let CurrentListIsThere =
    state.Sc_StandardPerformance_Overview.SP_ActualStudentsList.length == 0;

  let CallClass_LinechartData =
    (Right_Side_View_API_Call && Right_Std_list) || CurrentListIsThere;

  return {
    ...state,
    Sc_StandardPerformance_Overview: {
      ...state.Sc_StandardPerformance_Overview,
      selectedStandardId: standardId,
      selectedStandarAvg: Avarage,
      selectedstandardObject: StandardsObj,
      StrandNameOfSelectedStandard: StrandName,
    },
    Sc_ApiCalls: {
      ...state.Sc_ApiCalls,
      get_classList_and_Graph_ofClassStrand: CallClass_LinechartData,
    },
  };
}

/**
 *
 * @param {Object} state
 * @param {JS Object} action
 */
export function Set_PropsToGetCompleteClassReport(state, action) {
  let { LastActiveUniversalProps } = action.payload;
  let TeachersList = state.UniversalSelecter.Roster_Data.ActualTeachers;
  let Cs_List = JSON.parse(
    JSON.stringify(state.UniversalSelecter.Roster_Data.ActualClasses)
  );
  let Std_List = [];
  let getTests = false;

  let StradGrade_Alias = state.ApiCalls.get_C_Grades_Alias;
  let StradGrade_Main = state.ApiCalls.Get_Class_SP_Grade;

  let Ts_Alias = state.ApiCalls.get_C_TS_Graph_Alias;
  let Ts_Main = state.ApiCalls.Get_Class_TestScores;

  let T_ids = [];
  let Cs_ids = [];
  let Std_ids = [];

  let selected_school = {};
  let Selected_Teacher = {};

  let TestList = [];
  let TestTypes = [];
  let Selected_Tests = [];
  let selectedTestTypes = [];

  let CompleteRosterData = JSON.parse(
    JSON.stringify(LastActiveUniversalProps.RosterTabFullDetails)
  );

  let CurrentGrades = state.UniversalSelecter.Roster_Data.GradesList;

  let SelectedClass = state.UniversalSelecter.Roster_Data.ActualClasses.filter(
    (cls) => cls.id == action.payload.selectedClass.id
  )[0];

  let Last_Call_Reports = LastActiveUniversalProps.Class_Report;

  let Get_Class_Strands = state.ApiCalls.Get_Class_Strands;

  if (SelectedClass.id !== Last_Call_Reports.selectedClass.id) {
    getTests = true;

    selected_school = state.UniversalSelecter.Roster_Data.ActualSchools.filter(
      (Sc) => Sc.id == action.payload.selectedClass.schoolId
    )[0];

    for (var i = 0; i < TeachersList.length; i++) {
      let C_list =
        TeachersList[i].classes == null ? [] : TeachersList[i].classes;
      if (C_list.length > 0) {
        let ClassExist = C_list.some(
          (item) => item.id == action.payload.selectedClass.id
        );

        if (ClassExist) {
          Selected_Teacher = JSON.parse(JSON.stringify(TeachersList[i]));
          delete Selected_Teacher.classes;
          break;
        }
      }
    }

    TeachersList = Check_MathcedItem_And_Uncheck_Remainig_Objects_In_Array(
      TeachersList,
      Selected_Teacher
    );
    Cs_List = Check_MathcedItem_And_Uncheck_Remainig_Objects_In_Array(
      Cs_List,
      SelectedClass
    );

    SelectedClass.students.map((item) => {
      if (item.termId == SelectedClass.termId) {
        item.check = true;
        Std_List.push(item);
        Std_ids.push(item.id);
      }
    });
  } else {
    Cs_List = Last_Call_Reports.classList;
    Std_List = Last_Call_Reports.StudentList;
    TeachersList = Last_Call_Reports.TeachersList;
    selected_school = Last_Call_Reports.selectedSchool;
    Selected_Teacher = Last_Call_Reports.selectedTeacher;
    Std_ids = Get_Ids_Of_Student_List(Std_List.filter((item) => item.check));

    TestList = Last_Call_Reports.TestList;
    TestTypes = Last_Call_Reports.TestTypes;
    Selected_Tests = Last_Call_Reports.TestList.filter((item) => item.check);
    selectedTestTypes = TestTypes.filter((item) => item.check);

    let ClassGrade = action.payload.Current_Class_SP_Grade;
    ClassGrade =
      ClassGrade == null || ClassGrade == undefined ? "" : ClassGrade.grade;
    let School_Grade =
      action.payload.School_Sp_Object.StandardPerformanceFilter.TestGrade
        .selectedTestgrade;
    School_Grade =
      School_Grade == null || School_Grade == undefined
        ? ""
        : School_Grade.grade;
    if (ClassGrade !== School_Grade) {
      Get_Class_Strands = true;
    }
  }

  /**
   * start Test display in context
   */
  let cont_Test = "Custom (" + Selected_Tests.length + ")";
  if (TestTypes.length == 1) {
    cont_Test = TestTypes[0].testTypeName + "( " + Selected_Tests.length + ")";
  } else if (TestList.length == Selected_Tests.length) {
    cont_Test = "All (" + Selected_Tests.length + ")";
  }

  Std_List = Sort_ApiResponse_Payload_Array(Std_List, "studentslist");
  return {
    ...state,
    ApiCalls: {
      ...state.ApiCalls,
      getTests: getTests,
      Get_Class_SP_Grade: StradGrade_Main && !getTests,
      get_C_Grades_Alias: StradGrade_Alias || getTests,
      Get_Class_TestScores: Ts_Main && !getTests,
      get_C_TS_Graph_Alias: Ts_Alias || getTests,
      Get_Class_Strands: Get_Class_Strands,
    },
    NavigationByHeaderSelection: {
      ...state.NavigationByHeaderSelection,
      class: true,
      school: false,
    },
    ContextHeader: {
      ...state.ContextHeader,
      Roster_Tab: {
        ...state.ContextHeader.Roster_Tab,
        ClassIds: [SelectedClass.id],
        SelectedClass: SelectedClass,
        SchoolIds: [selected_school.id],
        SelectedSchool: selected_school,
        TeacherIds: [Selected_Teacher.id],
        SelectedTeacher: Selected_Teacher,
        ClassList: Cs_List,
        TeachersList: TeachersList,
        StudentsList: Std_List,
        StudentIds: Std_ids,
      },
      TestTab: {
        ...state.ContextHeader.TestTab,
        TestList: JSON.parse(JSON.stringify(TestList)),
        testtypes: JSON.parse(JSON.stringify(TestTypes)),
        selectedTestTypes: JSON.parse(JSON.stringify(selectedTestTypes)),
        TestList: JSON.parse(JSON.stringify(TestList)),
      },
      tests: cont_Test,
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      Roster_Data: {
        ...state.UniversalSelecter.Roster_Data,
        ActualClasses: JSON.parse(JSON.stringify(Cs_List)),
        ActualStudents: JSON.parse(JSON.stringify(Std_List)),
        ActualTeachers: JSON.parse(JSON.stringify(TeachersList)),
        ClassIds: [SelectedClass.id],
        ClassList: JSON.parse(JSON.stringify(Cs_List)),
        SchoolIds: [selected_school.id],
        SelectedClass: SelectedClass,
        SelectedSchool: selected_school,
        SelectedStudent: "All",
        SelectedTeacher: Selected_Teacher,
        StudentIds: Std_ids,
        StudentsList: JSON.parse(JSON.stringify(Std_List)),
        TeacherIds: [Selected_Teacher.id],
        TeachersList: JSON.parse(JSON.stringify(TeachersList)),
      },
      TestTab: {
        ...state.UniversalSelecter.TestTab,
        ActualTestList: JSON.parse(JSON.stringify(TestList)),
        LastAppliedTestList: JSON.parse(JSON.stringify(TestList)),
        SelectedTestList: JSON.parse(JSON.stringify(Selected_Tests)),

        TestList: JSON.parse(JSON.stringify(TestList)),
        selectAllTests: TestList.length == Selected_Tests.length,
        selectAllTests_Final: TestList.length == Selected_Tests.length,
        TestTypes: {
          ...state.UniversalSelecter.TestTab.TestTypes,
          LastInstanceSelectedTestTypes: JSON.parse(
            JSON.stringify(selectedTestTypes)
          ),
          LastInstanceTestTypes: JSON.parse(JSON.stringify(TestTypes)),
          TestTypesList: JSON.parse(JSON.stringify(TestTypes)),
          selectedTestTypes: JSON.parse(JSON.stringify(selectedTestTypes)),
          selectAllTestTypes: TestTypes.length == selectedTestTypes.length,
        },
      },
    },
  };
}

export function Set_PropsToGetCompleteSchoolReport(state, action) {
  let Last_School_Report =
    action.payload.LastActiveUniversalProps.School_Report;

  let SelectedSchool = {};
  let SelectedGrade = "";
  let SelectedTeacher = "All";
  let SelectedClass = "All";

  let SchoolList = [];
  let GradesList = [];
  let Teachers_List = [];
  let ClassList = [];
  let StdList = [];

  let Teacher_Ids = [];
  let Class_Ids = [];
  let Std_Ids = [];

  let SC_TestList = [];
  let SC_TestType = [];

  let C_Header = state.ContextHeader;
  let PresentTermId = C_Header.Date_Tab.selectedTermId;

  let Call_TestDetails = false;

  let Get_Sc_Grades =
    state.ApiCalls.Get_school_sp_grades || state.ApiCalls.get_SC_Grades_Alias;
  let Get_TS_Grades =
    state.ApiCalls.get_school_TS_Graph || state.ApiCalls.get_SC_TS_Graph_Alias;

  let SchoolDataOfSelected =
    state.UniversalSelecter.Roster_Data.ActualSchools.find(
      (item) => item.id == action.payload.SelectedSchool.id
    );

  let LastActioveSchool =
    Last_School_Report.selectedSchool == undefined
      ? {}
      : Last_School_Report.selectedSchool;
  let ActiveGrade = state.ContextHeader.Roster_Tab.selectedRosterGrade;

  if (LastActioveSchool.id == action.payload.SelectedSchool.id) {
    SelectedSchool = Last_School_Report.selectedSchool;

    SelectedTeacher = "All";
    SelectedClass = "All";

    SchoolList = Last_School_Report.SchoolList;
    GradesList = Last_School_Report.RosterGradeList;

    if (Last_School_Report.selectedRosterGrade == ActiveGrade) {
      SelectedGrade = {
        grade: Last_School_Report.selectedRosterGrade,
      };
      Teachers_List = Last_School_Report.TeachersList;
      ClassList = Last_School_Report.classList;
      StdList = Last_School_Report.StudentList;
    } else {
      SelectedGrade = {
        grade: ActiveGrade,
      };
      // let GradesList=

      let Lists_of_Grades = Return_All_Lists_For_Selected_Grade_Of_School(
        Last_School_Report.RosterGradeList,
        ActiveGrade
      );
      Teachers_List = Lists_of_Grades.Teach_List;
      ClassList = Lists_of_Grades.Class_List;
      StdList = Lists_of_Grades.StudentsList;
      Call_TestDetails = true;
      Get_Sc_Grades = true;
      Get_TS_Grades = true;
    }

    SC_TestList = Last_School_Report.TestList;
    SC_TestType = Last_School_Report.TestTypes;

    let Class_List_Of_Current_School =
      state.ContextHeader.Roster_Tab.ClassList.filter(
        (item) => item.schoolId == SelectedSchool.id
      );
    let stud_List_Of_Current_School =
      state.ContextHeader.Roster_Tab.StudentsList.filter(
        (item) => item.schoolId == SelectedSchool.id
      );

    let Cs_Selection_Res = Check_Previous_Report_List_Modified_Or_Not(
      ClassList,
      Class_List_Of_Current_School
    );

    let Class_Selection_Modified = Cs_Selection_Res.Modified;
    ClassList = Cs_Selection_Res.Modified ? Cs_Selection_Res.Arr1 : ClassList;
    let Std_Selection_Res = Check_Previous_Report_List_Modified_Or_Not(
      stud_List_Of_Current_School,
      StdList
    );

    let Student_Selection_Modified = Std_Selection_Res.Modified;
    StdList = Std_Selection_Res.Modified ? Std_Selection_Res.Arr1 : StdList;

    Teacher_Ids = Get_Ids_Of_Student_List(
      Teachers_List.filter((item) => item.check)
    );
    Class_Ids = Get_Ids_Of_Student_List(ClassList.filter((item) => item.check));
    Std_Ids = Get_Ids_Of_Student_List(StdList.filter((item) => item.check));

    if (Class_Selection_Modified || Student_Selection_Modified) {
      Call_TestDetails = true;
      Get_Sc_Grades = true;
      Get_TS_Grades = true;
    } else {
      let CurrentTests = state.ContextHeader.TestTab.TestList;
      let LastReportTests = Last_School_Report.TestList;

      let SC_Tst_Response = Compare_Class_And_Student_Tests(
        CurrentTests,
        LastReportTests
      );

      SC_TestList = SC_Tst_Response.TestList;

      Get_Sc_Grades = SC_Tst_Response._Call_Apis ? true : Get_Sc_Grades;
      Get_TS_Grades = SC_Tst_Response._Call_Apis ? true : Get_TS_Grades;
    }
  } else if (
    (SchoolDataOfSelected.grades == null || DISTRICT_ROSTER_ENABLED) &&
    state.NavigationByHeaderSelection.district
  ) {
    let SchoolList_For_Dist = JSON.parse(
      JSON.stringify(state.ContextHeader.Roster_Tab.schoolsList)
    );

    SchoolList_For_Dist.map((item) => {
      if (item.id == SchoolDataOfSelected.id) {
        item.check = true;
      } else {
        item.check = false;
      }
    });

    return {
      ...state,
      ApiCalls: {
        ...state.ApiCalls,
        Get_Selected_School_Info: true,
        Get_school_sp_grades: false,
        get_SC_Grades_Alias: true,
        get_school_TS_Graph: false,
        get_SC_TS_Graph_Alias: true,
      },
      NavigationByHeaderSelection: {
        ...state.NavigationByHeaderSelection,
        class: false,
        school: true,
        district: false,
      },
      ContextHeader: {
        ...state.ContextHeader,
        ActiveGrade_of_District_To_Persist_In_School: ActiveGrade,
        Roster_Tab: {
          ...state.ContextHeader.Roster_Tab,
          SelectedSchool: SchoolDataOfSelected,
          schoolsList: JSON.parse(JSON.stringify(SchoolList_For_Dist)),
          SchoolIds: [],
        },
      },
      UniversalSelecter: {
        ...state.UniversalSelecter,
        Roster_Data: {
          ...state.UniversalSelecter.Roster_Data,
          ActualSchools: JSON.parse(JSON.stringify(SchoolList_For_Dist)),
          SchoolIds: [],
          schoolsList: SchoolList_For_Dist,
          SelectedSchool: SchoolDataOfSelected,
        },
      },
    };
  } else {
    Call_TestDetails = true;
    let RosterFullDetails =
      action.payload.LastActiveUniversalProps.RosterTabFullDetails;

    SC_TestList = state.ContextHeader.TestTab.TestList;
    SC_TestType = state.ContextHeader.TestTab.testtypes;

    state.ContextHeader.Roster_Tab.schoolsList.map((item) => {
      if (item.id == action.payload.SelectedSchool.id) {
        item.check = true;
        SelectedSchool = item;
        // item
        let Grades;
      } else {
        item.check = false;
      }

      SchoolList.push(item);
    });

    GradesList = GradesList_From_Roster_Details(
      RosterFullDetails,
      SelectedSchool.id
    );

    for (var i = 0; i < GradesList.length; i++) {
      Teachers_List =
        GradesList[i].teachers == null ? [] : GradesList[i].teachers;
      // Teachers_List=[];

      if (Teachers_List.length > 0) {
        Teachers_List.map((item_t) => {
          let cs_list = item_t.classes == null ? [] : item_t.classes;
          if (cs_list.length > 0) {
            cs_list.map((item) => {
              if (item.termId == PresentTermId) {
                item.check = true;
                Class_Ids.push(item.id);
                ClassList.push(item);

                item_t.check = true;

                let S_List = item.students == null ? [] : item.students;

                if (S_List.length > 0) {
                  S_List.map((item_std) => {
                    item_std.check = true;
                    Std_Ids.push(item_std.id);
                    StdList.push(item_std);
                  });
                }
              }
            });
          }
        });
      }

      if (ClassList.length > 0) {
        SelectedGrade = JSON.parse(JSON.stringify(GradesList[i]));
        break;
      }
    }

    Teacher_Ids = Get_Ids_Of_Student_List(
      Teachers_List.filter((item) => item.check)
    );
  }

  let SC_SelectedTestList = SC_TestList.filter((item) => item.check);

  let COntexttests;
  if (SC_SelectedTestList.length == 1) {
    COntexttests = SC_SelectedTestList[0].testName;
  } else if (SC_TestType.length == 1) {
    COntexttests =
      SC_TestType[0].testTypeName + " (" + SC_TestList.length + ")";
  } else if (SC_TestList.length == SC_SelectedTestList.length) {
    COntexttests = "All (" + SC_TestList.length + ")";
  } else {
    COntexttests = "Custom (" + SC_SelectedTestList.length + ")";
  }

  let SelectedTstTypes = SC_TestType.filter((item) => item.check);

  return {
    ...state,
    ApiCalls: {
      ...state.ApiCalls,
      getTests: Call_TestDetails,
      Get_school_sp_grades: !Call_TestDetails && Get_Sc_Grades,
      get_SC_Grades_Alias: Call_TestDetails ? true : Get_Sc_Grades,
      get_school_TS_Graph: !Call_TestDetails && Get_TS_Grades,
      get_SC_TS_Graph_Alias: Call_TestDetails ? true : Get_TS_Grades,
    },
    NavigationByHeaderSelection: {
      ...state.NavigationByHeaderSelection,
      // student: true,
      class: false,
      school: true,
      district: false,
    },
    ContextHeader: {
      ...state.ContextHeader,
      Roster_Tab: {
        ...state.ContextHeader.Roster_Tab,
        selectedRosterGrade: SelectedGrade.grade,
        ClassIds: Class_Ids,
        GradesList: JSON.parse(JSON.stringify(GradesList)),
        SelectedClass: SelectedClass,
        SchoolIds: [SelectedSchool.id],
        SelectedSchool: SelectedSchool,
        TeacherIds: Teacher_Ids,
        SelectedTeacher: SelectedTeacher,
        ClassList: ClassList,
        TeachersList: Teachers_List,
        StudentsList: StdList,
        StudentIds: Std_Ids,
        schoolsList: SchoolList,
      },
      TestTab: {
        ...state.ContextHeader.TestTab,
        TestList: SC_TestList,
        testtypes: SC_TestType,
      },
      tests: COntexttests,
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      Roster_Data: {
        ...state.UniversalSelecter.Roster_Data,
        ActualClasses: JSON.parse(JSON.stringify(ClassList)),

        ActualSchools: JSON.parse(JSON.stringify(SchoolList)),
        ActualStudents: JSON.parse(JSON.stringify(StdList)),
        ActualTeachers: JSON.parse(JSON.stringify(Teachers_List)),
        ClassIds: Class_Ids,
        ClassList: JSON.parse(JSON.stringify(ClassList)),
        SchoolIds: [SelectedSchool.id],
        SelectedClass: SelectedClass,
        SelectedGrade: SelectedGrade.grade,
        SelectedSchool: SelectedSchool,
        SelectedStudent: "All",
        SelectedTeacher: SelectedTeacher,
        StudentIds: Std_Ids,
        StudentsList: JSON.parse(JSON.stringify(StdList)),
        TeacherIds: Teacher_Ids,
        TeachersList: JSON.parse(JSON.stringify(Teachers_List)),
        schoolsList: JSON.parse(JSON.stringify(SchoolList)),
      },
      TestTab: {
        ...state.UniversalSelecter.TestTab,
        ActualTestList: JSON.parse(JSON.stringify(SC_TestList)),
        LastAppliedTestList: JSON.parse(JSON.stringify(SC_TestList)),
        SelectedTestList: JSON.parse(JSON.stringify(SC_SelectedTestList)),
        TestList: SC_TestList,
        TestTypes: {
          ...state.UniversalSelecter.TestTab.TestTypes,
          TestTypesList: JSON.parse(JSON.stringify(SC_TestType)),
          LastInstanceTestTypes: SC_TestType,
          LastInstanceSelectedTestTypes: JSON.parse(
            JSON.stringify(SelectedTstTypes)
          ),
          selectedTestTypes: SelectedTstTypes,
          selectAllTestTypes:
            SelectedTstTypes.length == 1 && SC_TestType.length > 1,
        },
      },
    },
  };
}

/**
 *
 * @param {Array} ARRAY
 * @param {Object} object
 */
export function Check_MathcedItem_And_Uncheck_Remainig_Objects_In_Array(
  ARRAY,
  object
) {
  ARRAY.map((item) => {
    if (item.id == object.id) {
      item.check = true;
    } else {
      item.check = false;
    }
  });
  return ARRAY;
}

/**
 *
 * @param {Object} state
 * @param {JS Object} action
 *
 * change NodataInStrands prop to disable coming soon modal in standard performance view.
 *
 */
export function Change_NodataInStrands_Prop_In_ReportsReducer(state, action) {
  return {
    ...state,
    ApiCalls_Reports: {
      ...state.ApiCalls_Reports,
    },
    StandardPerformance_Overview: {
      ...state.StandardPerformance_Overview,
      // ActiveToggelIn_SP_Overview: "student",
      StandardPerformanceFilter: {
        ...state.StandardPerformance_Overview.StandardPerformanceFilter,
        DontCall_standardGradeApi: false,
        NodataInStrands: false,
      },
    },
  };
}

export function Change_NodataInStrands_Prop_In_SchoolReportsReducer(
  state,
  action
) {
  return {
    ...state,
    Sc_StandardPerformance_Overview: {
      ...state.Sc_StandardPerformance_Overview,
      StandardPerformanceFilter: {
        ...state.Sc_StandardPerformance_Overview.StandardPerformanceFilter,
        DontCall_standardGradeApi: false,
        NodataInStrands: false,
      },
    },
  };
}

export function on_Student_ANd_Class_NAv_Selection_From_DistrictReports(
  state,
  action,
  from
) {
  let ScholList = JSON.parse(
    JSON.stringify(state.ContextHeader.Roster_Tab.schoolsList)
  );

  let SchoolDataOfSelected = action.payload.SelectedSchool;

  ScholList.map((item) => {
    if (item.id == SchoolDataOfSelected.id) {
      item.check = true;
    } else {
      item.check = false;
    }
  });

  return {
    ...state,
    ApiCalls: {
      ...state.ApiCalls,
      Get_Selected_School_Info: true,
      Get_Student_SP_Grade: false,
      get_S_Grades_Alias: true,
      Get_Student_TestScores: false,
      get_S_TS_Graph_Alias: true,

      Get_Class_SP_Grade: false,
      Get_Class_TestScores: false,
      get_C_Grades_Alias: true,
      get_C_TS_Graph_Alias: true,
    },
    NavigationByHeaderSelection: {
      ...state.NavigationByHeaderSelection,
      class: from == "class" ? true : false,
      school: false,
      district: false,
      student: from == "student" ? true : false,
    },
    ContextHeader: {
      ...state.ContextHeader,
      Roster_Tab: {
        ...state.ContextHeader.Roster_Tab,
        SelectedSchool: SchoolDataOfSelected,
        schoolsList: JSON.parse(JSON.stringify(ScholList)),
        SchoolIds: [],
      },
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      Roster_Data: {
        ...state.UniversalSelecter.Roster_Data,
        ActualSchools: JSON.parse(JSON.stringify(ScholList)),
        SchoolIds: [],
        schoolsList: ScholList,
        SelectedSchool: SchoolDataOfSelected,
      },
    },
  };
}

export function ON_Success_Of_SingleTestData(state, action) {
  if (
    action.payload.checkSTData != null
      ? action.payload.checkSTData.length != 0
      : false
  ) {
    let fromContext = action.payload.fromContext;
    let pickedDataFromSTA =
      action.payload.ResPayload.concernedData != undefined
        ? action.payload.ResPayload.concernedData
        : null;
    if (pickedDataFromSTA != null && fromContext != "district") {
      pickedDataFromSTA.grade = getGradeOfClassFromRoaster(
        state.ContextHeader.Roster_Tab.GradesList,
        pickedDataFromSTA.studentId
      );
    }

    return SetPreviousReport_Props(state, fromContext, pickedDataFromSTA);
  } else {
    return {
      ...state,
    };
  }
}

export function get_summary_reportssuccess(state, action) {
  if (action.payload.ResPayload.summaryList == null) {
    return action.payload.updatedUniversalState;
    return {
      ...state,
    };
  } else {
    let RosterData = state.ContextHeader.Roster_Tab;
    let fromContext = action.payload.Nav.student
      ? "student"
      : action.payload.Nav.class
      ? "class"
      : action.payload.Nav.school
      ? "school"
      : "district";

    return SetPreviousReport_Props(state, fromContext);
  }
}

function Return_All_Lists_For_Selected_Grade_Of_School(Grades, Selec_Grade) {
  let Teach_List = [];
  let Class_List = [];
  let StudentsList = [];

  Teach_List = JSON.parse(
    JSON.stringify(
      Grades.filter((item) => item.grade == Selec_Grade)[0].teachers
    )
  );
  Teach_List.map((item) => {
    if (item.classes !== null) {
      item.check = true;
      Class_List = Class_List.concat(item.classes);
      // Class_List.push(item.classes);
    }
  });

  Class_List = Sort_ApiResponse_Payload_Array(
    RemoveDuplicateObjectsFromArray(Class_List, "id"),
    "classlist"
  );

  Class_List.map((cls) => {
    if (cls.students !== null) {
      cls.check = true;
      StudentsList = StudentsList.concat(cls.students);
    }
  });

  StudentsList = Sort_ApiResponse_Payload_Array(
    RemoveDuplicateObjectsFromArray(StudentsList, "id"),
    "studentslist"
  );
  StudentsList = CheckOrUncheckAllValuesOfTestArray(StudentsList, true);

  return {
    Teach_List,
    Class_List,
    StudentsList,
  };
}

export function on_Student_ANd_Class_NAv_Selection_From_DistrictReports_In_SingleTest(
  state,
  action,
  from
) {
  let ScholList = JSON.parse(
    JSON.stringify(state.ContextHeader.Roster_Tab.schoolsList)
  );

  let SchoolDataOfSelected = action.payload.SelectedSchool;

  ScholList.map((item) => {
    if (item.id == SchoolDataOfSelected.id) {
      item.check = true;
    } else {
      item.check = false;
    }
  });

  return {
    ...state,
    ApiCalls: {
      ...state.ApiCalls,
      // getTests: Call_TestDetails,
      Get_Selected_School_Info: true,
      Get_Student_SP_Grade: false,
      get_S_Grades_Alias: true,
      Get_Student_TestScores: false,
      get_S_TS_Graph_Alias: true,

      Get_Class_SP_Grade: false,
      Get_Class_TestScores: false,
      get_C_Grades_Alias: true,
      get_C_TS_Graph_Alias: true,
    },
    NavigationByHeaderSelection: {
      ...state.NavigationByHeaderSelection,
      // student: true,
      class: from == "class" ? true : false,
      school: false,
      district: false,
      student: from == "student" ? true : false,
    },
    ContextHeader: {
      ...state.ContextHeader,
      PickDataFromSingleTestAnalysis:
        action.payload.PickDataFromSingleTestAnalysis,
      Roster_Tab: {
        ...state.ContextHeader.Roster_Tab,
        SelectedSchool: SchoolDataOfSelected,
        schoolsList: JSON.parse(JSON.stringify(ScholList)),
        SchoolIds: [],
      },
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      // Selected_class_data: action.payload.selectedClass,
      // Selected_teacher_data: TeacherIs,
      Roster_Data: {
        ...state.UniversalSelecter.Roster_Data,
        ActualSchools: JSON.parse(JSON.stringify(ScholList)),
        SchoolIds: [],
        schoolsList: ScholList,
        SelectedSchool: SchoolDataOfSelected,
      },
    },
  };
}

export const checkIfStandardExistInSelectedListOrNot = (
  standardId,
  strandsList
) => {
  let checkExist = false;

  strandsList.map((strand) => {
    strand.standards.map((standard) => {
      if (standard.standardId == standardId) {
        checkExist = true;
      }
    });
  });

  return checkExist;
};
