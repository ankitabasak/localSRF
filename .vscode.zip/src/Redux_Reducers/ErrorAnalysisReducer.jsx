import { ErrorAnalysisActionTypes } from '../Reducer_Action_Types/ErrorAnalysisActionTypes.jsx';
import { func } from 'prop-types';
import { constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

const INITIAL_STATE = {
  S_ErrorAnalysisDetails: {
    data: null,
    isApiLoading: true,
    isDataNotAvailable: false,
    chartLoadFail: false,
    timeOut: false
  },
  StudentData: null,
  isMobileView: 5,
  IconUpdate: {
    previousIcon: '',
    firstIcon: '',
    lastIcon: '',
    nextIcon: ''
  },
  PieChartUpdate: {
    errorObj: {
      toggleChart: true,
      showMsvDiv: false,
      errorDiv: true,
      hideMsvDiv: ''
    },
    msvObj: {
      hideErrDonut: ''
    }
  },
  dataLength: '',
  SEACSVDownload: { csvData: null, downloadInProgress: false }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ErrorAnalysisActionTypes.ERROR_ANALYSIS_STUDENT_DATA_SUCCESS:
      let scrollLen = getMobileView();
      return {
        ...state,
        isMobileView: scrollLen,
        S_ErrorAnalysisDetails: {
          data: action.payload.responseData,
          isApiLoading: false,
          timeOut: false,
          chartLoadFail: false,
          isDataNotAvailable:
            action.payload.responseData.dateRangeReadingLevelAxis.length > 0
              ? false
              : true
        },
        Response: action.payload.SUCCESSFULL,
        dataLength:
          action.payload.responseData.dateRangeReadingLevelAxis.length - scrollLen,
        StudentData: modifiedObject(
          action.payload.responseData.errorAnalysisData,
          action.payload.responseData.dateRangeReadingLevelAxis,
          action.payload.responseData.dateRangeReadingLevelAxis.length > scrollLen
            ? action.payload.responseData.dateRangeReadingLevelAxis.length - scrollLen
            : 0,
          action.payload.responseData.dateRangeReadingLevelAxis.length
        ),

        IconUpdate: iconStatus(
          action.payload.responseData.dateRangeReadingLevelAxis, scrollLen
        ),
        PieChartUpdate: updateState(action.payload.responseData),
        SEACSVDownload: { csvData: null, downloadInProgress: false }
      };

    case ErrorAnalysisActionTypes.SEA_ERROR_HANDLING:
      return {
        ...state,
        S_ErrorAnalysisDetails: {
          ...state.S_ErrorAnalysisDetails,
          data: null,
          ...action.payload
        }
      };
    case ErrorAnalysisActionTypes.SEA_LOADER:
      return {
        ...state,
        S_ErrorAnalysisDetails: {
          data: null,
          isApiLoading: true,
          isDataNotAvailable: false,
          chartLoadFail: false,
          timeOut: false
        },
        StudentData: null,
        dataLength: ''
      }
    case ErrorAnalysisActionTypes.ERROR_ANALYSIS_STUDENT_DATA_FAIL:
      return {
        ...state,
        Response: action.payload,
        S_ErrorAnalysisDetails: {
          data: null,
          isApiLoading: false,
          isDataNotAvailable: false,
          chartLoadFail: true,
          timeOut: false
        },
        StudentData: null,
        dataLength: ''
      };

    case ErrorAnalysisActionTypes.SCROLL_DATA:
      return {
        ...state,
        S_ErrorAnalysisDetails: {
          ...state.S_ErrorAnalysisDetails
        },
        StudentData: modifiedObject(
          action.payload.data,
          action.payload.date,
          action.payload.firstIndex,
          action.payload.lastIndex
        ),
        dataLength: action.payload.firstIndex
      };
    case ErrorAnalysisActionTypes.ICON_UPDATE: {
      return {
        ...state,
        IconUpdate: {
          firstIcon: action.payload.firstIcon,
          lastIcon: action.payload.lastIcon,
          nextIcon: action.payload.nextIcon,
          previousIcon: action.payload.previousIcon
        }
      };
    }
    case ErrorAnalysisActionTypes.PIE_CHART_STATE_UPDATE: {
      return {
        ...state,
        PieChartUpdate: {
          ...state.PieChartUpdate,
          ['errorObj']: { ...state.PieChartUpdate.errorObj, ...action.payLoad }
        }
      };
    };
    case ErrorAnalysisActionTypes.SEA_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // SEACSVDownload: action.payLoad
        SEACSVDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case ErrorAnalysisActionTypes.SEA_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        SEACSVDownload: action.payLoad
      };
    default:
      return { ...state };
  }
};

function iconStatus(data, scrollLen) {
  if (data.length <= scrollLen) {
    return { previousIcon: '', firstIcon: '', lastIcon: '', nextIcon: '' };
  } else {
    return {
      previousIcon: true,
      firstIcon: true,
      lastIcon: '',
      nextIcon: ''
    };
  }
}

function getMobileView() {
  let mobileView = ((window.innerWidth <= 1024))
  return mobileView ? 3 : 5;
}
function modifiedObject(data, date, fIndx, lIndx) {
  return {
    date: date.slice(fIndx, lIndx),
    insertion: data.insertion.slice(fIndx, lIndx),
    meaningCues: data.meaningCues.slice(fIndx, lIndx),
    omission: data.omission.slice(fIndx, lIndx),
    omissionTolds: data.omissionTolds.slice(fIndx, lIndx),
    repetation: data.repetation.slice(fIndx, lIndx),
    selfCorrection: data.selfCorrection.slice(fIndx, lIndx),
    structuralCues: data.structuralCues.slice(fIndx, lIndx),
    substitution: data.substitution.slice(fIndx, lIndx),
    told: data.told.slice(fIndx, lIndx),
    visualCues: data.visualCues.slice(fIndx, lIndx)
  };
}

function updateState(data) {
  let msvVal = data ? data.msvAnalysisDonutData : '';
  let errorObj = {};
  let msvObj = {};
  let errVal = data ? data.errorAnalysisDonutData : '';
  if (
    !msvVal.meaningCues &&
    !msvVal.structuralCues &&
    !msvVal.visualCues &&
    !msvVal.ommissionAndTolds
  ) {
    errorObj = {
      showMsvDiv: false,
      errorDiv: true,
      toggleChart: true,
      hideMsvDiv: 'hide-msv'
    };
    // this.setState({ showMsvDiv: false });
    // this.setState({ errorDiv: true });
    // this.setState({ toggleChart: true });
    // this.setState({ hideMsvDiv: 'hide-msv' });
  } else {
    errorObj = {
      showMsvDiv: false,
      errorDiv: true,
      toggleChart: true,
      hideMsvDiv: ''
    };
    // this.setState({ showMsvDiv: false });
    // this.setState({ errorDiv: true });
    // this.setState({ toggleChart: true });
    // this.setState({ hideMsvDiv: '' });
  }

  if (
    !errVal.insertion &&
    !errVal.ommission &&
    !errVal.repetation &&
    !errVal.selfCorrection &&
    !errVal.substitution &&
    !errVal.told
  ) {
    msvObj = { hideErrDonut: true };
  } else {
    msvObj = { hideErrDonut: false };
  }

  return { errorObj: errorObj, msvObj: msvObj };
}
