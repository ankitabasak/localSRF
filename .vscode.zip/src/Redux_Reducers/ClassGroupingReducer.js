import { ClassGroupingTypes, HANDLE_PAGINATION_CLICK_NAVIGATION } from '../Reducer_Action_Types/ClassGroupingTypes';
import { GET_TEST_TAB_RESULTS_SUCCESS, GET_INITIAL_APPLICATION_DATA_SUCCESS, APPLY_FILTERS_IN_ROSTER_TAB, SAVE_CONTEXT_SELECTION, APPLY_FILTERS_IN_TEST_TAB } from '../Reducer_Action_Types/UniversalSelectorActionTypes';
import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';
import { Report_Action_Types, GET_STUDENTS_OF_A_CLASS_STRAND_SUCCESS } from '../Reducer_Action_Types/ReportsActionTypes';
import { Sort_ApiResponse_Payload_Array, sortTaxonomyDataBasedOnUserPrefferences } from '../Components/ReusableComponents/AllReusableFunctions';
import { Nav_strands_Count_perPage_ } from './ComparisonReducer';

const INITIAL_STATE = {
  //############ Group popup Props ########//
  Universal_Selector_Is_Changed: false,
  persistTaxonomy: false,
  G_ApiCalls: {
    getGrades: false,
    getGradesAlias: false,
    getassessed_Ques: false,
    getStrands: false,
    loader_on_grade: false,
    loader_on_assessed_que: false,
    loader_on_strads: false,
    loader_on_apply_group_page: false,
  },
  AppliedChanges: {
    StrandsList_Final: [],
    selectedStrands_Final: [],
    StrandSelection_Final: 'All',
    SelectedStandardIds: [],
    ProductId: '',
    Grade: '',
    Taxonomy: '',
    AssessedQuestion: '',
    NoOfGroups: 3,
    GroupBy: "CLUSTERING",
    SelectedStandards: [],
    assesedQuestionsList: []
  },
  groupData_Students: [],
  groupData_Class: {},
  groupData_School: {},
  GroupProductTab: {
    OpenGroupProductDropDown: false,
    ProductsList: [
      { productId: 1, productName: 'Product 1' },
      { productId: 2, productName: 'Product 2' },
      { productId: 3, productName: 'Product 3' },
    ],
    SelectedProductId: null,
  },
  GroupTaxonomyTab: {
    OpenGroupTaxonomyDropDown: false,
    TaxonomiesList: [],
    SelectedTaxonomy: null,
  },
  SetValues: [],
  GroupGradeTab: {
    OpenGradeDropDown: false,
    GradeList: [],
    SelectedGrade: {},
  },
  GroupAssesmentTab: {
    OpenGroupAssessmentDropDown: false,
    QuestionList: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],// default
    SelectedAssessedQuestion: 1,// default
  },
  GroupStrandsTab: {
    GroupingDataForStudent: [],
    GroupingDataForClass: '',
    GroupingDataForSchool: '',
    StandardsView: {
      SelectedAllStandards: false,
    },
    OpenGroupStrandsDropDown: false,
    StrandsList: [],
    StrandsList_Original: [],
    OrginalGroupStrandsList: [],
    Strands_After_Done: [],
    Selected_Strands_After_Done: [],

    // Need to populate the StrandsList from the API it self.
    TotalStrands: [],
    SelectedStrands: [],

    SelectedStandards: [],
    ShowStandardDescription: false,
    SelectAllStandards: true,
    SelectAllStrands: true,
    StrandSelection: "All"
  },
  SelectedNumberOfGroups: 3,
  selectedGroupByParam: 'CLUSTERING',
  SavedNumberOfGroups: 2,
  MaxStudentsCountForGroups: 3,

  firstTimePageDisplay: false,
  openGroupPopUp: false,
  openEditedGroupPopUp: false,
  ShowGroupLoading: false,
  ShowGroupApiCallLoading: false,
  GroupTriggeringApiCalls: false,

  //####### Group Page Props ########//

  GroupPage: {
    TotalNumberOfStudents: '',
    GroupingList: [],
    GroupingPages: [],
    LengthStrandAndStandards: 0,
    GroupingStrandOrStandard: {
      StrandsOrStandardsList: [],
      NavLeftCount: 0,
      NavRightCount: Nav_strands_Count_perPage_,
    },
    MoveStudent: {
      MoveStudentGroupPopup: false, // Popup enable
      StudentMovedFlag: false,
      MovedStudentFromGroupDetails: {
        GroupIndex: null, //
        StudentIndex: null, //
        StudentName: '', //
        MovedGroupIndex: null,
        StudentId: null,
        Student: {}
      }
    },
    sortOptions: {
      ParamOnwhichScore: "lastName",
      Strand_Standard: "nomatter",
      Strand_Standard_type: "nomatter",
      orderOfSort: "ASC"
    },
    pagination: {
      currentPageNumber: 1,
      countPerPage: 10,
      totalPageCount: 1,
      bubbleLeft: 0,
      bubbleRight: 3
    },
    Pages_And_Count: [],
    selctedBubble: 0
  },
  GroupingCSVDownload: {
    enableCSVDownload: false
  }
}
// end of group page...
export default (state = INITIAL_STATE, action) => {
  switch (action.type) {

    case AuthActionTypes.POST_CREATE_JWT_TOKEN:
      return INITIAL_STATE;

    /**
     * will reset the reducer state once we get the data in initial load api call.
     */
    case GET_INITIAL_APPLICATION_DATA_SUCCESS:
      if (action.payload.Data.rosterTestVO == null) {
        return {
          ...state
        }
      } else {
        return INITIAL_STATE
      }

    case ClassGroupingTypes.EDIT_CLASS_GROUPING_POPUP:
      return {
        ...state,
        openGroupPopUp: true,
        openEditedGroupPopUp: true,
        G_ApiCalls: {
          ...state.G_ApiCalls,
          getStrands: false,
          getGrades: false,
          getassessed_Ques: false
        }
      };

    case SAVE_CONTEXT_SELECTION:

      if (action.payload.selectionoption == 'grouping') {
        let Grade = state.GroupPage.GroupingList.length == 0 ?
          action.payload.Class_SP_Filter.TestGrade.selectedTestgrade :
          state.GroupGradeTab.SelectedGrade;

        let Gradelist = state.GroupPage.GroupingList.length == 0 ?
          action.payload.Class_SP_Filter.TestGrade.TestGradeList :
          state.GroupGradeTab.GradeList

        let QuestionsList = [];
        if (state.GroupPage.GroupingList.length == 0) {
          let Q_Max_Count = parseInt(action.payload.Class_SP_Filter.TestAssessment.MaxTestAssessmentCount);
          for (var i = 0; i < Q_Max_Count; i++) {
            QuestionsList.push(i + 1);
          }
        } else {
          QuestionsList = state.GroupAssesmentTab.QuestionList;
        }
        let AssesQuestion = state.GroupPage.GroupingList.length == 0 ?
          action.payload.Class_SP_Filter.TestAssessment.selectedTestAssessment :
          state.GroupAssesmentTab.SelectedAssessedQuestion

        return {
          ...state,
          GroupAssesmentTab: {
            ...state.GroupAssesmentTab,
            SelectedAssessedQuestion: AssesQuestion,
            QuestionList: QuestionsList
          },
          GroupGradeTab: {
            ...state.GroupGradeTab,
            SelectedGrade: Grade,
            GroupGradeTab: action.payload.Class_SP_Filter.TestGrade.TestGradeList,
            GradeList: Gradelist
          },
          openGroupPopUp: state.GroupPage.GroupingList.length == 0 ? true : false,
          openEditedGroupPopUp: state.GroupPage.GroupingList.length == 0 ? true : false,

          GroupProductTab: {
            ...state.GroupProductTab,
            SelectedProductId: action.payload.productListForGroupPopUp[0].productId,
            ProductsList: action.payload.productListForGroupPopUp,
          },
          G_ApiCalls: {
            ...state.G_ApiCalls,
            getGrades: false,
            getStrands: true
          }
        };
      } else {
        return {
          ...state
        };
      }

    case ClassGroupingTypes.CLASS_GROUP_BY_SELECTED:
      return {
        ...state,
        selectedGroupByParam: action.payload,
      };

    /**
     * closing grouping pop up modal of class reports
     */
    case ClassGroupingTypes.CANCEL_GROUP_POPUP:
      let StrandSelection = state.AppliedChanges.StrandsList_Final.length == state.AppliedChanges.selectedStrands_Final ?
        "All" : "Custom (" + state.AppliedChanges.selectedStrands_Final + ")";
      return {
        ...state,
        openGroupPopUp: false,
        openEditedGroupPopUp: false,

        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          SelectedStrands: state.AppliedChanges.selectedStrands_Final,
          SelectedStandards: state.AppliedChanges.SelectedStandards,
          StrandsList: state.AppliedChanges.StrandsList_Final,
          StrandsList_Original: state.AppliedChanges.StrandsList_Final,
          Strands_After_Done: state.AppliedChanges.StrandsList_Final,
          OpenGroupStrandsDropDown: false,
          StrandSelection: state.AppliedChanges.StrandSelection_Final,
          SelectAllStrands: state.AppliedChanges.SelectedStandards.length == state.AppliedChanges.StrandsList_Final.length,
          StandardsView: {
            ...state.GroupStrandsTab.StandardsView,
            SelectedAllStandards: state.AppliedChanges.selectedStrands_Final.length == 1 ?
              state.AppliedChanges.selectedStrands_Final[0].standards.length == state.AppliedChanges.selectedStrands_Final[0].standards.filter(item => item.check).length : false,
          },
        },
        SelectedNumberOfGroups: state.AppliedChanges.NoOfGroups == '' ? 3 : state.AppliedChanges.NoOfGroups,
        selectedGroupByParam: state.AppliedChanges.GroupBy == "" ? "CLUSTERING" : state.AppliedChanges.GroupBy,
        GroupGradeTab: {
          ...state.GroupGradeTab,
          SelectedGrade: state.AppliedChanges.Grade,
          OpenGradeDropDown: false
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          SelectedAssessedQuestion: state.AppliedChanges.AssessedQuestion,
          QuestionList: state.AppliedChanges.assesedQuestionsList,
          OpenGroupAssessmentDropDown: false
        }, GroupTaxonomyTab: {
          ...state.GroupTaxonomyTab,
          OpenGroupTaxonomyDropDown: false,
          SelectedTaxonomy: state.AppliedChanges.Taxonomy
        }
      };

    case ClassGroupingTypes.CLASS_GROUP_POPUP_PRODUCT_DROPDOWN_TOGGLE:

      return {
        ...state,
        GroupProductTab: {
          ...state.GroupProductTab,
          OpenGroupProductDropDown: action.payload
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          OpenGradeDropDown: false
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          OpenGroupAssessmentDropDown: false
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OpenGroupStrandsDropDown: false
        }
      };

    case ClassGroupingTypes.CLASS_GROUP_POPUP_TAXONOMY_DROPDOWN_TOGGLE:

      return {
        ...state,
        GroupTaxonomyTab: {
          ...state.GroupTaxonomyTab,
          OpenGroupTaxonomyDropDown: action.payload
        },
        GroupProductTab: {
          ...state.GroupProductTab,
          OpenGroupProductDropDown: false
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          OpenGradeDropDown: false
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          OpenGroupAssessmentDropDown: false
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OpenGroupStrandsDropDown: false
        }
      };
    case ClassGroupingTypes.CLASS_GROUP_POPUP_GRADE_DROPDOWN_TOGGLE:
      return {
        ...state,
        GroupProductTab: {
          ...state.GroupProductTab,
          OpenGroupProductDropDown: false
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          OpenGradeDropDown: action.payload
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          OpenGroupAssessmentDropDown: false
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OpenGroupStrandsDropDown: false
        }
      };
    case ClassGroupingTypes.CLASS_GROUP_POPUP_QUESTION_DROPDOWN_TOGGLE:
      return {
        ...state,
        GroupProductTab: {
          ...state.GroupProductTab,
          OpenGroupProductDropDown: false
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          OpenGradeDropDown: false
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          OpenGroupAssessmentDropDown: action.payload
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OpenGroupStrandsDropDown: false
        }
      };
    case ClassGroupingTypes.CLASS_GROUP_POPUP_STRANDS_DROPDOWN_TOGGLE:

      return {
        ...state,
        GroupProductTab: {
          ...state.GroupProductTab,
          OpenGroupProductDropDown: false
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          OpenGradeDropDown: false
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          OpenGroupAssessmentDropDown: false
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OpenGroupStrandsDropDown: action.payload,
          StrandsList: !action.payload ? JSON.parse(JSON.stringify(state.GroupStrandsTab.Strands_After_Done)) :
            state.GroupStrandsTab.StrandsList,
          SelectAllStrands: !action.payload ? state.GroupStrandsTab.Strands_After_Done.length ==
            state.GroupStrandsTab.Strands_After_Done.filter(item => item.check).length :
            state.GroupStrandsTab.SelectAllStrands
        }
      };
    case ClassGroupingTypes.CLASS_GROUP_POPUP_STRANDS_SHOW_HIDE:
      return {
        ...state,
        GroupProductTab: {
          ...state.GroupProductTab,
          OpenGroupProductDropDown: false
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          OpenGradeDropDown: false
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          OpenGroupAssessmentDropDown: false
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          ShowStandardDescription: action.payload,
          OpenGroupStrandsDropDown: false
        }
      };
    case ClassGroupingTypes.CLASS_GROUP_POPUP_STRANDS_CHECK_ALL:

      let SelectedStrands = JSON.parse(JSON.stringify(state.GroupStrandsTab.SelectedStrands));

      SelectedStrands[0].standards.map(item => item.check = action.payload);

      return {
        ...state,
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OpenGroupStrandsDropDown: false,
          SelectAllStandards: action.payload,
          SelectedStrands: SelectedStrands,
          StandardsView: {
            ...state.GroupStrandsTab.StandardsView,
            SelectedAllStandards: action.payload
          }
        }
      }

    case ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_STANDARDS:
      let SelectedStrandsList = JSON.parse(JSON.stringify(state.GroupStrandsTab.SelectedStrands));
      SelectedStrandsList[0].standards = SelectedStrandsList[0].standards.map(item => {
        if (item.standardId == action.payload) {
          return { ...item, check: !item.check }
        } else return { ...item }
      })

      let ActualStandards = SelectedStrandsList[0].standards;
      let SelectedStandards = ActualStandards.filter(item => item.check);
      let MacStudentsCount = GetMaxStudentsCount(SelectedStandards);
      return {
        ...state,
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          SelectedStrands: SelectedStrandsList,
          StandardsView: {
            ...state.GroupStrandsTab.StandardsView,
            SelectedAllStandards: ActualStandards.length == SelectedStandards.length,
          },
        },
        MaxStudentsCountForGroups: MacStudentsCount,
      }
    case ClassGroupingTypes.SHOW_GROUP_PAGE:
      return {
        ...state,

      }
    case ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_PRODUCT:
      return {
        ...state,
        GroupProductTab: {
          ...state.GroupProductTab,
          SelectedProductId: action.payload,
          OpenGroupProductDropDown: false,
        },
      }
    case ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_TAXONOMY:

      // xdvdv
      let Selected_Taxonomy_Grouping_Strands_StandardsList = { ...state.GroupStrandsTab.OrginalGroupStrandsList };
      Selected_Taxonomy_Grouping_Strands_StandardsList.strands = Selected_Taxonomy_Grouping_Strands_StandardsList.strands.map((strand, strand_index) => {
        return {
          ...strand,
          standards: [
            ...strand.standards.filter((single_taxonomy_standard) => (single_taxonomy_standard.taxonomy == action.payload))
          ]
        }
      }).filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

      let SelectedTaxonomyStradsList = GetStrands_WhichHas_StandardsMoreThan2(Selected_Taxonomy_Grouping_Strands_StandardsList);
      let SelectedTaxonomy_STrandSelection_Final = Selected_Taxonomy_Grouping_Strands_StandardsList.strands.length == 1 ?
        Selected_Taxonomy_Grouping_Strands_StandardsList.strands[0].strandName : "All";

      let selectAllStandards_ontax = SelectedTaxonomyStradsList.length == 1;
      if (selectAllStandards_ontax) {
        SelectedTaxonomyStradsList[0].standards.map(item => item.check = true)
      }


      return {
        ...state,
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          loader_on_strads: false,
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          StrandsList: SelectedTaxonomyStradsList,
          SelectedStrands: SelectedTaxonomyStradsList,
          SelectAllStrands: true,
          StrandsList_Original: JSON.parse(JSON.stringify(SelectedTaxonomyStradsList)),
          StrandSelection: SelectedTaxonomy_STrandSelection_Final,
          Strands_After_Done: JSON.parse(JSON.stringify(SelectedTaxonomyStradsList)),
          StandardsView: {
            ...state.GroupStrandsTab.StandardsView,
            SelectedAllStandards: selectAllStandards_ontax
          }
        },
        GroupTaxonomyTab: {
          ...state.GroupTaxonomyTab,
          SelectedTaxonomy: action.payload,
          OpenGroupTaxonomyDropDown: false,
        },
      }
    /**
     * WIll Save Selected Grade And Initiate Api call to get Assessed Questions. 
     */
    case ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_GRADE:
      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          getassessed_Ques: true,
          getStrands: true
        },
        GroupGradeTab: {
          ...state.GroupGradeTab,
          SelectedGrade: action.payload,
          OpenGradeDropDown: false,
        }, GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          SelectedAssessedQuestion: ''
        }
      }
    /**
     * Save selected Assessed QUestion And initiate strands api call 
     */
    case ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_QUESTION:

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          getStrands: true,
        },
        GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          SelectedAssessedQuestion: action.payload,
          OpenGroupAssessmentDropDown: false,
        },
      }
    case ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_STRAND:

      let SelectAllStandards = '';

      let STrands = JSON.parse(JSON.stringify(state.GroupStrandsTab.StrandsList));

      if (action.payload == 'All') {

        let SelectAllStrands = !(state.GroupStrandsTab.SelectAllStrands)
        STrands.map(strand => strand.check = SelectAllStrands);
        let SelectedStrands = STrands.filter(item => item.check);

        return {
          ...state,
          GroupStrandsTab: {
            ...state.GroupStrandsTab,
            SelectAllStrands: SelectAllStrands,
            SelectAllStandards: true,
            SelectedStandards: SelectAllStandards,
            StrandsList: STrands
          }
        }

      } else {

        STrands.map(strand => {

          if (strand.strandName === action.payload.strandName) {
            strand.check = !strand.check
          }
        });

        let SelectedStrands = STrands.filter(item => item.check);
        let StrandsList_Original = state.GroupStrandsTab.StrandsList_Original.filter(strands => strands.check);
        let allstrandsSelected_ = SelectedStrands.length == StrandsList_Original.length ? true : false;
        return {
          ...state,
          GroupStrandsTab: {
            ...state.GroupStrandsTab,
            SelectAllStrands: allstrandsSelected_,
            SelectAllStandards: allstrandsSelected_,
            SelectedStandards: SelectAllStandards,
            StrandsList: STrands
          }
        }
      }


    case ClassGroupingTypes.DONE_IN_SELECT_STRAND_POPUP:

      let SelectedStrands_ = state.GroupStrandsTab.StrandsList.filter(item => item.check);
      let allstrandsSelected = SelectedStrands_.length == state.GroupStrandsTab.StrandsList.length;



      let StrandSelectionIs = allstrandsSelected ? "All" :
        SelectedStrands_.length == 1 ? SelectedStrands_[0].strandName : "Custom (" + SelectedStrands_.length + ")";

      let MaxStudentsCount = SelectedStrands_.length > 1 ? GetMaxStudentsCount(SelectedStrands_, "strands") : null;


      if (SelectedStrands_.length == 1) {
        SelectedStrands_[0].standards.map(item => item.check = true);
      }

      return {
        ...state,
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          SelectedStrands: SelectedStrands_,
          StrandSelection: StrandSelectionIs,
          OpenGroupStrandsDropDown: false,
          Strands_After_Done: state.GroupStrandsTab.StrandsList,
          StandardsView: {
            ...state.GroupStrandsTab.StandardsView,
            SelectedAllStandards: SelectedStrands_.length == 1
          }
        },
        MaxStudentsCountForGroups: SelectedStrands_.length > 1 ? MaxStudentsCount : state.MaxStudentsCountForGroups,
      }

    /**
        * Remove strands From Slecction listr.
        */
    case ClassGroupingTypes.REMOVE_STRAND_BY_CLICK_ON_SPAN:

      return RemovestrandOnSpanClick(state, action);



    /**
  * Enable Loader Before Initiate Get Grades  api call
  */
    case ClassGroupingTypes.GET_GRADES_FOR_GROUPING:

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          getGrades: false,
          loader_on_grade: true
        },
      }

    /**
     * After Success Response On Get Grades Api Call
     */

    case ClassGroupingTypes.GET_GRADES_FOR_GROUPING_SUCCESS:

      let GradesList = action.payload.PayloadData != null ? action.payload.PayloadData : [];

      let SelectedGrade = GradesList[0];

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          loader_on_grade: false,
          getassessed_Ques: GradesList.length > 0 ? true : false,
          getStrands: GradesList.length > 0 ? true : false
        }, GroupGradeTab: {
          ...state.GroupGradeTab,
          GradeList: GradesList,
          SelectedGrade: SelectedGrade
        }, AppliedChanges: {
          ...state.AppliedChanges,
          AssessedQuestion: '',
          Grade: "",
          GroupBy: "",
          NoOfGroups: '',
          ProductId: '',
          SelectedStandardIds: [],
          StrandSelection_Final: "",
          StrandsList_Final: [],
          selectedStrands_Final: []
        }
      }

    /**
  * Enable Loader Before Initiate Assessed Questions api call
  */
    case ClassGroupingTypes.GET_ASSESSMENT_COUNT_IN_GROUPING:

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          getassessed_Ques: false,
          loader_on_assessed_que: true
        },
      }
    /**
     * After Success Response On Assessed Question Api Call
     */
    case ClassGroupingTypes.GET_ASSESSMENT_COUNT_IN_GROUPING_SUCCESS:

      let Assessed = [];
      const realValueOfMaxAssessedCount = action.payload.PayloadData > 10 ? 10 : action.payload.PayloadData;
      for (var i = 1; i < realValueOfMaxAssessedCount + 1; i++) {

        Assessed[i - 1] = i;

      }

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          loader_on_assessed_que: false,
        }, GroupAssesmentTab: {
          ...state.GroupAssesmentTab,
          QuestionList: Assessed,
          SelectedAssessedQuestion: state.GroupAssesmentTab.SelectedAssessedQuestion == '' ?
            Assessed[0] : state.GroupAssesmentTab.SelectedAssessedQuestion
        }

      }

    /**
     * Enable Loader Before Initiate strads api call
     */
    case ClassGroupingTypes.GET_STRADS_IN_GROUPING_COMP:

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          getStrands: false,
          loader_on_strads: true
        },
      }

    /**
     * After Success Response On Strands Api Call
     */
    case ClassGroupingTypes.GET_STRADS_IN_GROUPING_COMP_SUCCESS:


      let Taxonomy_Grouping_Strands_StandardsList = action.payload == null ? [] : { ...action.payload };
      let UserPreferences = action.UserPreferences
      let Taxonomy_Grouping_List = [];
      let SetValues = []
      action.payload == null ? null : Taxonomy_Grouping_Strands_StandardsList.strands.map((strand) => {
        strand.standards.map((single_standard) => {
          Taxonomy_Grouping_List.push(single_standard.taxonomy)
          SetValues.push({
            setId: single_standard.setId,
            taxonomy: single_standard.taxonomy
          });
        })
      })
      Taxonomy_Grouping_List = [...new Set(Taxonomy_Grouping_List)];
      Taxonomy_Grouping_List = Taxonomy_Grouping_List.sort();
      SetValues = multiDimensionalUnique(SetValues);

      if (UserPreferences !== null && UserPreferences != undefined && UserPreferences.standardsetorders.length >0) {
        Taxonomy_Grouping_List = sortTaxonomyDataBasedOnUserPrefferences(UserPreferences, SetValues)
      }

      let selectedTaxonomy = state.persistTaxonomy ? Taxonomy_Grouping_List.find(item => item == state.GroupTaxonomyTab.SelectedTaxonomy) :
        Taxonomy_Grouping_List[0];

      selectedTaxonomy = selectedTaxonomy == undefined ? Taxonomy_Grouping_List[0] : selectedTaxonomy

      if (action.payload !== null) {

        Taxonomy_Grouping_Strands_StandardsList.strands = Taxonomy_Grouping_Strands_StandardsList.strands.map((strand, strand_index) => {
          return {
            ...strand,
            standards: [
              ...strand.standards.filter((single_taxonomy_standard) => (single_taxonomy_standard.taxonomy == selectedTaxonomy))
            ]
          }
        }).filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);


      }
      // end of taxonomy Part

      let StradsList = Taxonomy_Grouping_Strands_StandardsList.length == 0 ? [] : GetStrands_WhichHas_StandardsMoreThan2(Taxonomy_Grouping_Strands_StandardsList);
      let STrandSelection_Final = action.payload == null ? "" : Taxonomy_Grouping_Strands_StandardsList.strands.length == 1 ?
        Taxonomy_Grouping_Strands_StandardsList.strands[0].strandName : "All";
      let MaxStudentsCountNumber = action.payload == null ? 0 : GetMaxStudentsCount(Taxonomy_Grouping_Strands_StandardsList.strands, "strands")



      let selectAllStandards = StradsList.length == 1;
      if (selectAllStandards) {
        StradsList[0].standards.map(item => item.check = true)
      }

      return {
        ...state, G_ApiCalls: {
          ...state.G_ApiCalls,
          loader_on_strads: false,
        },
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          OrginalGroupStrandsList: action.payload,
          StrandsList: StradsList,
          SelectedStrands: StradsList,
          SelectAllStrands: true,
          StrandsList_Original: JSON.parse(JSON.stringify(StradsList)),
          // SelectedStrands_Original: JSON.parse(JSON.stringify(StradsList)),
          StrandSelection: STrandSelection_Final,
          Strands_After_Done: JSON.parse(JSON.stringify(StradsList)),
          StandardsView: {
            ...state.GroupStrandsTab.StandardsView,
            SelectedAllStandards: selectAllStandards
          }
        },
        MaxStudentsCountForGroups: MaxStudentsCountNumber,
        GroupTaxonomyTab: {
          ...state.GroupTaxonomyTab,
          TaxonomiesList: Taxonomy_Grouping_List,
          SelectedTaxonomy: selectedTaxonomy,
          OpenGroupTaxonomyDropDown: false
        },
        SetValues: SetValues,
      }

    case ClassGroupingTypes.GROUP_PAGE_SS_NAV:
      return {
        ...state,
        GroupPage: {
          ...state.GroupPage,
          GroupingStrandOrStandard: {
            ...state.GroupPage.GroupingStrandOrStandard,
            NavLeftCount: action.payload.NavigationLeftCount,
            NavRightCount: action.payload.NavigationRightCount
          }
        }
      }
    case ClassGroupingTypes.GROUP_PAGE_MOVE_STUDENT:
      return {
        ...state,
        GroupPage: {
          ...state.GroupPage,
          MoveStudent: {
            ...state.GroupPage.MoveStudent,
            MoveStudentGroupPopup: true,
            MovedStudentFromGroupDetails: {
              ...state.GroupPage.MoveStudent.MovedStudentFromGroupDetails,
              GroupIndex: action.payload.GroupIndex,
              StudentIndex: action.payload.StudentIndex,
              StudentName: action.payload.StudentName,
              StudentId: action.payload.StudentId,
              Student: action.payload.Student
            }
          }
        }
      }

    /**
     * save selected grouping count
     */
    case ClassGroupingTypes.CHANGE_NUMBER_OF_GROUPS:
      let GroupCount = action.payload == 'add' ? parseInt(state.SelectedNumberOfGroups) + 1 : parseInt(state.SelectedNumberOfGroups) - 1
      return {
        ...state, SelectedNumberOfGroups: GroupCount
      }

    case ClassGroupingTypes.CLOSE_GROUP_MODAL:
      return {
        ...state,
        GroupPage: {
          ...state.GroupPage,
          MoveStudent: {
            ...state.GroupPage.MoveStudent,
            MoveStudentGroupPopup: false,
            MovedStudentFromGroupDetails: {
              ...state.GroupPage.MoveStudent.MovedStudentFromGroupDetails,
              GroupIndex: null,
              StudentIndex: null,
              StudentName: null,
              MovedGroupIndex: null,
              Student: {}
            }
          }
        }
      }
    case ClassGroupingTypes.MOVE_GROUP_CLICKED:

      return MoveToGroupClicked_StateChange(state, action);

    /**
     * Storing Selected standard Ids.
     */

    case ClassGroupingTypes.GROUP_POPUP_APPLY_ACTION:
      return {
        ...state, selectedGroupByParam: action.payload.groupingType,
        GroupStrandsTab: {
          ...state.GroupStrandsTab,
          SelectedStandards: action.payload.selectedStandardsList,
        },
        G_ApiCalls: {
          ...state.G_ApiCalls,
          loader_on_apply_group_page: true,
        },
        openGroupPopUp: false,
        AppliedChanges: {
          ...state.AppliedChanges,
          GroupBy: action.payload.groupingType,
          SelectedStandards: action.payload.selectedStandardsList
        }
      }

    /**
     * After Getting Success Response On Grouping Modification.
     */
    case ClassGroupingTypes.GROUP_POPUP_APPLY_ACTION_SUCCESS:

      let groupPageData = action.payload; // Here we will get the API data as a .value block
      groupPageData = groupPageData.filter(e => e.length);

      let StrandsorStrandardsList = [];
      let Total_students_array = [];
      let countPerPage_Updated = 50
      groupPageData = groupPageData.map((GroupArray, i) => (

        GroupArray = Sort_ApiResponse_Payload_Array(GroupArray, "studentslist"),
        GroupArray.map((StudentObject, j) => (
          { ...StudentObject, parentGroup: i, previousGroup: i, presentGroup: i, moveStudentFlag: false }
        ))
      ));
      groupPageData.map((FirstArray, i) => (
        FirstArray.map((SecondArray, j) => (
          SecondArray.standardAndStrandVODetails.map((ThirdArray, k) => (
            StrandsorStrandardsList.push(ThirdArray.standardName)
          ))
        ))
      ));
      StrandsorStrandardsList = [...new Set(StrandsorStrandardsList)]

      let SelectedStrands__ = state.GroupStrandsTab.SelectedStrands;

      let FinalSelectedStrands = JSON.parse(JSON.stringify(SelectedStrands__));

      groupPageData.map((val, g) => { val.map((x, i) => { Total_students_array.push(x) }) });

      Total_students_array = OperationalDataSorting(Total_students_array)

      let GroupDataRes = StudentsGrouping_Logic(groupPageData)

      let { totalPageCount, PagesAndStds, TotalNUmberOfStudents } = GroupDataRes;

      groupPageData = GroupDataRes.groupPageData;
      // let totalPageCount = Math.ceil(TotalNUmberOfStudents / 10)


      let NoOfSTrandsSelected = groupPageData[0][0].standardAndStrandVODetails;
      NoOfSTrandsSelected = NoOfSTrandsSelected == undefined ? 0 : FinalSelectedStrands.length > 1 ? FinalSelectedStrands.length : FinalSelectedStrands[0].standards.length;
      return {
        ...state, openGroupPopUp: false, persistTaxonomy: false,
        openEditedGroupPopUp: false,
        GroupPage: {
          ...state.GroupPage,
          GroupingList: groupPageData,
          GroupingPages: Total_students_array,
          TotalNumberOfStudents: TotalNUmberOfStudents,
          LengthStrandAndStandards: NoOfSTrandsSelected,
          GroupingStrandOrStandard: {
            ...state.GroupPage.GroupingStrandOrStandard,
            StrandsOrStandardsList: StrandsorStrandardsList,
            NavLeftCount: 0,
            NavRightCount: FinalSelectedStrands.length > 1 ? 5 : Nav_strands_Count_perPage_
          },
          sortOptions: {
            ...state.GroupPage.sortOptions,
            ParamOnwhichScore: "lastName",
            Strand_Standard: "nomatter",
            Strand_Standard_type: "nomatter",
            orderOfSort: "ASC"
          },
          pagination: {
            ...state.GroupPage.pagination,
            currentPageNumber: 1,
            countPerPage: countPerPage_Updated,
            totalPageCount: totalPageCount,
            bubbleLeft: 0,
            bubbleRight: 3
          },
          Pages_And_Count: PagesAndStds,
          selctedBubble: 0,

        }, AppliedChanges: {
          ...state.AppliedChanges,
          ProductId: state.GroupProductTab.SelectedProductId,
          Grade: state.GroupGradeTab.SelectedGrade,
          Taxonomy: state.GroupTaxonomyTab.SelectedTaxonomy,
          AssessedQuestion: state.GroupAssesmentTab.SelectedAssessedQuestion,
          NoOfGroups: state.SelectedNumberOfGroups,
          GroupBy: state.selectedGroupByParam,
          StrandsList_Final: JSON.parse(JSON.stringify(state.GroupStrandsTab.StrandsList)),
          selectedStrands_Final: JSON.parse(JSON.stringify(FinalSelectedStrands)),
          StrandSelection_Final: JSON.parse(JSON.stringify(state.GroupStrandsTab.StrandSelection)),
          assesedQuestionsList: JSON.parse(JSON.stringify(state.GroupAssesmentTab.QuestionList))

        },
        G_ApiCalls: {
          ...state.G_ApiCalls,
          loader_on_apply_group_page: false,
        },
      }

    /**
     * On Click Bubble Change Groups 
     */
    case ClassGroupingTypes.SELECTED_BUBBLE_IN_GROUPING:
      let OperationalSortData = OperationalDataSorting(state.GroupPage.GroupingPages)
      return {
        ...state,
        GroupPage: {
          ...state.GroupPage,
          GroupingPages: OperationalSortData,
          selctedBubble: action.payload,
        }
      }
    /**
     * 
     * Pagination Action
     */
    case ClassGroupingTypes.GROUPING_PAGE_DISPLAY:
      return {
        ...state,
        GroupPage: {
          ...state.GroupPage,
          pagination: {
            ...state.GroupPage.pagination,
            currentPageNumber: action.payload,

          }
        }
      }
    /**
     * If user Changes Universal Test  Tab Data 
     */
    case APPLY_FILTERS_IN_TEST_TAB:
      return {
        ...state, Universal_Selector_Is_Changed: false,
        openGroupPopUp: true, GroupPage: {
          ...state.GroupPage,
          GroupingList: [],
        }, G_ApiCalls: {
          ...state.G_ApiCalls,
          getGrades: true
        }, AppliedChanges: {
          ...state.AppliedChanges,
          selectedStrands_Final: [],
          SelectedStandards: []
        }
      }

    /**
     * when we get test tab data from the server when user make changes to universal selector.
     */
    case GET_TEST_TAB_RESULTS_SUCCESS:
      return TestTabDataFromServer(state, action);

    case ClassGroupingTypes.SORT_GROUPS_BASED_ON_PARAM:
      return SortingGroupsBasedOnMultipleWays(state, action)

    case ClassGroupingTypes.MOVE_STUDENT_CONFIRM_PARAM:
      let operationalDataSort = OperationalDataSorting(state.GroupPage.GroupingPages)

      return {
        ...state,
        GroupPage: {
          ...state.GroupPage,
          GroupingPages: operationalDataSort,
          MoveStudent: {
            ...state.GroupPage.MoveStudent,
            StudentMovedFlag: !state.GroupPage.MoveStudent.StudentMovedFlag
          }
        }
      }

    case ClassGroupingTypes.TRIGGER_GROUPING_DOWNLOAD_CSV:
      return {
        ...state,
        GroupingCSVDownload: {
          enableCSVDownload: true
        }
      }
    case ClassGroupingTypes.RESET_GROUPING_DOWNLOAD_CSV:
      return {
        ...state,
        GroupingCSVDownload: {
          enableCSVDownload: false
        }
      }

    case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:
      return INITIAL_STATE

    case GET_STUDENTS_OF_A_CLASS_STRAND_SUCCESS:
      return PersistTaxonomyInGrouping(state, action);

    case Report_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_CLASS:
      return PersistTaxonomyInGrouping(state, action, true);

    case HANDLE_PAGINATION_CLICK_NAVIGATION:
      let bubbleRight = state.GroupPage.pagination.bubbleRight - 1;
      let bubbleLeft = state.GroupPage.pagination.bubbleLeft - 1

      if (action.payload == "right") {

        bubbleRight = state.GroupPage.pagination.bubbleRight + 1,
          bubbleLeft = state.GroupPage.pagination.bubbleLeft + 1

      }

      return {
        ...state, GroupPage: {
          ...state.GroupPage,
          pagination: {
            ...state.GroupPage.pagination,
            bubbleRight,
            bubbleLeft
          }
        }

      }


    default:
      return {
        ...state
      };
  }
}


function PersistTaxonomyInGrouping(state, action, onlyTaxonomyPersist) {

  let selectedTaxonomy = onlyTaxonomyPersist ? action.payload : state.G_ApiCalls.getStrands ? action.payload.selectedTaxonomy : state.GroupTaxonomyTab.SelectedTaxonomy;
  let Sel_Ass_Ques = state.G_ApiCalls.getStrands ? action.payload.Sel_Ass_Ques : state.GroupAssesmentTab.SelectedAssessedQuestion;

  let TaxList = state.GroupTaxonomyTab.TaxonomiesList;
  let QuesList = state.GroupAssesmentTab.QuestionList
  if (TaxList.length !== 0 && state.G_ApiCalls.getStrands) {
    let find = TaxList.find(item => item == selectedTaxonomy);
    let find_qus = QuesList.find(item => item == Sel_Ass_Ques);
    selectedTaxonomy = find == undefined ? state.GroupTaxonomyTab.SelectedTaxonomy : selectedTaxonomy;
    Sel_Ass_Ques = find_qus == undefined ? state.GroupAssesmentTab.SelectedAssessedQuestion : Sel_Ass_Ques;
  };

  if (TaxList.length !== 0 && onlyTaxonomyPersist) {
    let Selected_Taxonomy_Grouping_Strands_StandardsList = { ...state.GroupStrandsTab.OrginalGroupStrandsList };
    Selected_Taxonomy_Grouping_Strands_StandardsList.strands = Selected_Taxonomy_Grouping_Strands_StandardsList.strands.map((strand, strand_index) => {
      return {
        ...strand,
        standards: [
          ...strand.standards.filter((single_taxonomy_standard) => (single_taxonomy_standard.taxonomy == action.payload))
        ]
      }
    }).filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

    let SelectedTaxonomyStradsList = GetStrands_WhichHas_StandardsMoreThan2(Selected_Taxonomy_Grouping_Strands_StandardsList);
    let SelectedTaxonomy_STrandSelection_Final = Selected_Taxonomy_Grouping_Strands_StandardsList.strands.length == 1 ?
      Selected_Taxonomy_Grouping_Strands_StandardsList.strands[0].strandName : "All";


    return {
      ...state, AppliedChanges: INITIAL_STATE.AppliedChanges,
      G_ApiCalls: {
        ...state.G_ApiCalls,
        loader_on_strads: false,
      }, GroupPage: {
        ...state.GroupPage,
        GroupingList: []
      },
      GroupStrandsTab: {
        ...state.GroupStrandsTab,
        StrandsList: SelectedTaxonomyStradsList,
        SelectedStrands: SelectedTaxonomyStradsList,
        SelectAllStrands: true,
        StrandsList_Original: JSON.parse(JSON.stringify(SelectedTaxonomyStradsList)),
        StrandSelection: SelectedTaxonomy_STrandSelection_Final,
        Strands_After_Done: JSON.parse(JSON.stringify(SelectedTaxonomyStradsList))
      },
      GroupTaxonomyTab: {
        ...state.GroupTaxonomyTab,
        SelectedTaxonomy: action.payload,
        OpenGroupTaxonomyDropDown: false,
      },
    }
  }

  return {
    ...state, GroupAssesmentTab: {
      ...state.GroupAssesmentTab,
      SelectedAssessedQuestion: TaxList.length == 0 ? Sel_Ass_Ques : state.GroupAssesmentTab.SelectedAssessedQuestion,
    }, GroupTaxonomyTab: {
      ...state.GroupTaxonomyTab,
      SelectedTaxonomy: TaxList.length == 0 || onlyTaxonomyPersist ? selectedTaxonomy : state.GroupTaxonomyTab.SelectedTaxonomy,
    }, persistTaxonomy: true,
    AppliedChanges: {
      ...state.AppliedChanges,
      Taxonomy: onlyTaxonomyPersist ? selectedTaxonomy : state.AppliedChanges.Taxonomy
    }
  }
}
/**
 * 
 * @param {Object} Payload 
 */
function GetStrands_WhichHas_StandardsMoreThan2(Payload) {

  let Strands = Payload.strands;

  let NewStrandsList = [];

  Strands.map(strand => {
    if (strand.standards.length > 0) {
      strand.check = true;
      NewStrandsList.push(strand);
    } else {
      let standard = strand.standards[0];
      if (standard.studentCount > 1) {
        strand.check = true;
        NewStrandsList.push(strand)
      }

    }
  })

  return NewStrandsList;
}

/**
 * 
 * *Here we are sorting the studentCounts to get highest number to make groups. 
 *
 */

export function GetMaxStudentsCount(List, StrandOrStandard) {
  let FinalValue = 0;
  let newValue;

  if (StrandOrStandard == "strands") {
    List.map((StrandIn, i) => (
      StrandIn.standards.map((StandardIn, j) => (
        newValue = StandardIn.studentCount,
        FinalValue = newValue > FinalValue ? newValue : FinalValue
      ))
    ))

  } else {
    List.map((StandardIn, j) => (
      newValue = StandardIn.studentCount,
      FinalValue = newValue > FinalValue ? newValue : FinalValue
    ))
  }

  return FinalValue
}

function TestTabDataFromServer(state, action) {

  if (action.payload.Nav.class && action.payload.Response !== null && !action.payload.Nav.test_status) {
    return {
      ...state, Universal_Selector_Is_Changed: false,
      openGroupPopUp: action.payload.Nav.class ? true : false, GroupPage: {
        ...state.GroupPage,
        GroupingList: [],
      }, G_ApiCalls: {
        ...state.G_ApiCalls,
        getGrades: true
      }, AppliedChanges: {
        ...state.AppliedChanges,
        selectedStrands_Final: [],
        SelectedStandards: []
      }
    }
  } else {
    return {
      ...state
    }
  }
}

function SortingGroupsBasedOnMultipleWays(state, action) {

  const { ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort } = action.payload;

  let groupPageData = state.GroupPage.GroupingList;

  if (ParamOnwhichScore == "lastName") {

    groupPageData.map((singleGroupBlock) => {
      singleGroupBlock.sort(function (a, b) {

        if (orderOfSort == "ASC") {
          if (a.lastName < b.lastName) { return -1; }
          if (a.lastName > b.lastName) { return 1; }
        } else {
          if (a.lastName < b.lastName) { return 1; }
          if (a.lastName > b.lastName) { return -1; }
        }
        return 0;
      })
    });

  } else if (ParamOnwhichScore == "studentPercentage") {

    groupPageData.map((singleGroupBlock) => {
      singleGroupBlock.sort(function (a, b) {

        if (orderOfSort == "ASC") {
          if (a.studentPercentage < b.studentPercentage) { return -1; }
          if (a.studentPercentage > b.studentPercentage) { return 1; }
        } else {
          if (a.studentPercentage < b.studentPercentage) { return 1; }
          if (a.studentPercentage > b.studentPercentage) { return -1; }
        }
        return 0;
      })
    });

  } else if (ParamOnwhichScore == "standardAndStrandAvg") {

    groupPageData.map((singleGroupBlock) => {
      singleGroupBlock.sort(function (a, b) {

        if (orderOfSort == "ASC") {
          if (a.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg < b.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg) { return -1; }
          if (a.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg > b.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg) { return 1; }
        } else {
          if (a.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg < b.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg) { return 1; }
          if (a.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg > b.standardAndStrandVODetails.filter(strand => strand.standardAndStrandName == Strand_Standard)[0].standardAndStrandAvg) { return -1; }
        }
        return 0;
      })
    });

  }

  return {
    ...state,
    GroupPage: {
      ...state.GroupPage,
      GroupingList: groupPageData,
      sortOptions: {
        ...state.GroupPage.sortOptions,
        ParamOnwhichScore: ParamOnwhichScore,
        Strand_Standard: Strand_Standard,
        Strand_Standard_type: Strand_Standard_type,
        orderOfSort: orderOfSort
      },
    }
  }
}


/**
 * 
 * @param {state} state 
 * @param {Object} action
 * @returns {state} 
 */
function RemovestrandOnSpanClick(state, action) {

  let StrandsList = JSON.parse(JSON.stringify(state.GroupStrandsTab.StrandsList));

  StrandsList.map(strand => {
    if (strand.strandName == action.payload.strandName) {
      strand.check = false
    }
  })


  let SelectedStrands_ = StrandsList.filter(item => item.check);
  let allstrandsSelected = SelectedStrands_.length == StrandsList.length;

  if (SelectedStrands_.length == 1) {
    SelectedStrands_[0].standards.map(item => item.check = false);
  }

  let StrandSelectionIs = allstrandsSelected ? "All" :
    SelectedStrands_.length == 1 ? SelectedStrands_[0].strandName : "Custom (" + SelectedStrands_.length + ")";

  let MaxStudentsCount = SelectedStrands_.length > 1 ? GetMaxStudentsCount(SelectedStrands_, "strands") : null;

  return {
    ...state,
    GroupStrandsTab: {
      ...state.GroupStrandsTab,
      StrandsList: StrandsList,
      SelectedStrands: SelectedStrands_,
      StrandSelection: StrandSelectionIs,
      OpenGroupStrandsDropDown: false,
      Strands_After_Done: StrandsList,
      SelectAllStrands: false,
      StandardsView: {
        ...state.GroupStrandsTab.StandardsView,
        SelectedAllStandards: false
      }

    },
    MaxStudentsCountForGroups: SelectedStrands_.length > 1 ? MaxStudentsCount : state.MaxStudentsCountForGroups,

  }
}
/**
 * 
 * @param {array} arr 
 */
/* To get unigue values in multiDimensional array*/
function multiDimensionalUnique(arr) {
  var uniques = [];
  var itemsFound = {};
  for (var i = 0, l = arr.length; i < l; i++) {
    var stringified = JSON.stringify(arr[i]);
    if (itemsFound[stringified]) { continue; }
    uniques.push(arr[i]);
    itemsFound[stringified] = true;
  }
  return uniques;
}

function OperationalDataSorting(GroupingPages) {
  let operationalData = GroupingPages

  operationalData.sort(function (a, b) {

    if (a.presentGroup < b.presentGroup) { return -1; }
    if (a.presentGroup > b.presentGroup) { return 1; }

    return 0;
  })

  return operationalData
}


function MoveToGroupClicked_StateChange(state, action) {

  let allValues = state.GroupPage.GroupingList
  const { GroupIndex, StudentIndex, Student } = state.GroupPage.MoveStudent.MovedStudentFromGroupDetails

  Student.GroupIndex = GroupIndex;
  Student.StudentIndex = StudentIndex;
  Student.MovedGroupIndex = action.payload;
  Student.previousGroup = GroupIndex;
  Student.presentGroup = action.payload;
  allValues.map((item, i) => {
    if (i === GroupIndex) {
      item.splice(StudentIndex, 1)
    } else if (i === action.payload) {
      item.push(Student);
    }
  })


  let SortedMovedData = OperationalDataSorting(state.GroupPage.GroupingPages);


  let GroupingDataRes = StudentsGrouping_Logic(allValues);

  let { totalPageCount, PagesAndStds, groupPageData } = GroupingDataRes

  return {
    ...state,
    GroupPage: {
      ...state.GroupPage, GroupingList: groupPageData,
      GroupingPages: SortedMovedData,
      MoveStudent: {
        ...state.GroupPage.MoveStudent,
        MoveStudentGroupPopup: false,
        StudentMovedFlag: true,
        MovedStudentFromGroupDetails: {
          ...state.GroupPage.MoveStudent.MovedStudentFromGroupDetails,
          MovedGroupIndex: action.payload,
        }
      }, pagination: {
        ...state.GroupPage.pagination,
        currentPageNumber: state.GroupPage.pagination.currentPageNumber > totalPageCount ? totalPageCount : state.GroupPage.pagination.currentPageNumber,
        totalPageCount
      },

      Pages_And_Count: PagesAndStds
    }
  }
}




function StudentsGrouping_Logic(Arr) {

  let groupPageData = JSON.parse(JSON.stringify(Arr));

  let StdCount = 0;
  let totalPageCount = 1;
  let PagesAndStds = []
  let Group_indx_Start = 0;
  let Group_indx_End = 0;
  let TotalNUmberOfStudents = 0;


  if (groupPageData.length == 1) {
    TotalNUmberOfStudents = groupPageData[0].length;
    let Pages_stds = {
      stds: TotalNUmberOfStudents, page: 1, start: 0, end: TotalNUmberOfStudents,
      Group_indx_Start: 0, Group_indx_End: 1
    }

    PagesAndStds.push(Pages_stds);
  } else {

    groupPageData.map((item, i) => {
      TotalNUmberOfStudents = TotalNUmberOfStudents + item.length;
      StdCount = StdCount + item.length;

      item = Sort_ApiResponse_Payload_Array(item, "studentslist");

      if (StdCount > 50) {
        let prevCount_ = PagesAndStds[PagesAndStds.length - 1];
        let start = prevCount_ == undefined ? 0 : prevCount_.end + 1;

        let stdCount = StdCount - item.length;
        let end = prevCount_ == undefined ? stdCount : prevCount_.end + stdCount;
        let FirstPagesAndStds = PagesAndStds[0];

        Group_indx_Start = prevCount_ == undefined ? 0 : prevCount_.Group_indx_End;
        Group_indx_End = i;

        Group_indx_End = Group_indx_End == Group_indx_Start ? Group_indx_End + 1 : Group_indx_End;

        totalPageCount = PagesAndStds.length + 1;
        let Pages_stds = {
          stds: stdCount, page: totalPageCount, start, end,
          Group_indx_Start, Group_indx_End
        }

        if (Pages_stds.stds > 0) {
          PagesAndStds.push(Pages_stds);
        }

        if (groupPageData.length === i + 1 && StdCount > 50) {

          let StartInner = end + 1;
          let endInner = end + item.length;

          totalPageCount = PagesAndStds.length + 1;

          let Pages_stds_Inner = {
            stds: item.length, page: totalPageCount, start: StartInner, end: endInner,
            Group_indx_Start: Group_indx_End, Group_indx_End: Group_indx_End + 1
          }
          PagesAndStds.push(Pages_stds_Inner);

        } else {

        }
        StdCount = item.length;
        Group_indx_Start = 0;
        Group_indx_End = 0;
      } else if (groupPageData.length === i + 1) {
        let prevCount_ = PagesAndStds[PagesAndStds.length - 1];
        let start = prevCount_ == undefined ? 0 : prevCount_.end + 1;
        let end = prevCount_ == undefined ? StdCount : prevCount_.end + StdCount;

        let FirstPagesAndStds = PagesAndStds[0];

        Group_indx_Start = prevCount_ == undefined ? 0 : prevCount_.Group_indx_End;
        Group_indx_End = prevCount_ == undefined ? i : i - FirstPagesAndStds.Group_indx_Start + 1;

        Group_indx_End = Group_indx_End == Group_indx_Start ? Group_indx_End + 1 : Group_indx_End;
        totalPageCount = PagesAndStds.length + 1;
        let Pages_stds = { stds: StdCount, page: totalPageCount, start, end, Group_indx_Start, Group_indx_End }
        PagesAndStds.push(Pages_stds);
      }
      groupPageData[i] = item
    })

  }
  return { groupPageData, totalPageCount, PagesAndStds, TotalNUmberOfStudents }

}
