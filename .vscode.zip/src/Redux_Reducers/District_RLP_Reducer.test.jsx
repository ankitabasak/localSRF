import districtRLPReducer from './District_RLP_Reducer'

describe('districtRLPReducer', () => {
    it('default matches', () => {
      expect(districtRLPReducer(undefined, {})).toMatchSnapshot();
    });

    it('test DISTRICT_RLP_CHART_API_SUCCESS', () => {
      expect(districtRLPReducer(undefined, {
        type: 'DISTRICT_RLP_CHART_API_SUCCESS',
      })).toMatchSnapshot();
    });

    it('test SUM_DST_RLP_CHART_API_SUCCESS', () => {
        expect(districtRLPReducer(undefined, {
          type: 'SUM_DST_RLP_CHART_API_SUCCESS',
        })).toMatchSnapshot();
    });
    it('test DISTRICT_RLP_CLASS_LEVEL_CHART_API_SUCCESS', () => {
        expect(districtRLPReducer(undefined, {
            type: 'DISTRICT_RLP_CLASS_LEVEL_CHART_API_SUCCESS',
        })).toMatchSnapshot();
    });
});
