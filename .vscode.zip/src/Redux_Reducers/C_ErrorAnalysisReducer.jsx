import { C_EaTypes } from "../Reducer_Action_Types/C_ErrorAnalysisTypes.jsx";
import { dataSorting, constructCsvData } from "../Components/ReusableComponents/OrrReusableComponents";

const INITIAL_STATE = {
  firstRecordObj: null,
  recentRecordObj: null,
  allRecordObj: null,
  isApiLoading: true,
  isDataAvailable: false,
  timeOut: false,
  sideTableData: null,
  errorRange: [],
  msvErrorRange: [],
  showHideRecentRecord: "",
  SortData: {
    sortColumn: "assignmentDate",
    sortType: "desc"
  },
  SelectedErr: {},
  ErrorCode: null,
  apiLoadFail: false,
  isDataAvailable: false,
  showRecord: "rec",
  disableDiv: true,
  showSpinner: false,
  noDataAvail: false,
  hideCreateGroup: false,
  isAllThreeMsvValuesNull: {
    allRecordsAverageMsvNull: false,
    firstRecordMsvNull: false,
    recentRecordMsvNull: false
  },
  ClassCsvDownload: { csvData: null, downloadInProgress: false }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case C_EaTypes.CLASS_EA_DATA_SUCCESS:
      return {
        ...state,
        firstRecordObj:
          returnConstRecord(
            action.payload.responseData.firstRecord,
            "firstRecord"
          ),
        allRecordObj: action.payload.responseData.errorRecordType.allRecords
          ? returnConstRecord(
            action.payload.responseData.allRecordsAverage,
            "allRecordsAverage"
          )
          : null,
        recentRecordObj: action.payload.responseData.errorRecordType
          .recentRecord
          ? returnConstRecord(
            action.payload.responseData.recentRecord,
            "recentRecord"
          )
          : null,
        errorRange: action.payload.responseData.errorCountRangeList.reverse(),
        msvErrorRange: action.payload.responseData.msvCountRangeList,
        showHideRecentRecord: action.payload.responseData.recentRecordNull,
        SelectedErr: {},
        isAllThreeMsvValuesNull: action.payload.responseData.isAllThreeMsvValuesNull,
        apiLoadFail: false,
        showRecord: action.payload.responseData.errorRecordType.recentRecord
          ? "rec"
          : action.payload.responseData.errorRecordType.allRecords
            ? "all"
            : "",
        ErrorCode: null,
        disableDiv: true,
        isApiLoading: false,
        timeOut: false,
        noDataAvail: false,
        hideCreateGroup: true,
        ClassCsvDownload: { csvData: null, downloadInProgress: false }
      };
    case C_EaTypes.CLASS_EA_NO_DATA:
      return {
        ...state,
        sideTableData: null,
        firstRecordObj: null,
        recentRecordObj: null,
        allRecordObj: null,
        apiLoadFail: false,
        ErrorCode: null,
        disableDiv: false,
        timeOut: false,
        noDataAvail: true,
        // isAllThreeMsvValuesNull: null
      }
    case C_EaTypes.CLASS_EA_DATA_FAIL:
      return {
        ...state,
        sideTableData: null,
        firstRecordObj: null,
        recentRecordObj: null,
        allRecordObj: null,
        apiLoadFail: false,
        ErrorCode: action.payload,
        disableDiv: false,
        timeOut: false,
        noDataAvail: false,
        hideCreateGroup: true,
        // isAllThreeMsvValuesNull: null
      };
    case C_EaTypes.CLASS_EA_GRID_TABLE_SUCCESS:
      return {
        ...state,
        sideTableData: {
          ...state.sideTableData,
          ["tableData"]: dataSorting(
            action.payload.classEASidePanelGridData,
            "assignmentDate",
            "desc"
          ),
          ["selectedRecordDetails"]: action.payload.selectedRecordTypeDetails
        },
        SortData: {
          sortColumn: "assignmentDate",
          sortType: "desc"
        },
        ErrorCode: null,
        apiLoadFail: false,
        disableDiv: false,
        showSpinner: false,
        hideCreateGroup: false
      };
    case C_EaTypes.CLASS_EA_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        },
        disableDiv: false
      };
    case C_EaTypes.CEA_SORTED_DATA:
      return {
        ...state,
        sideTableData: {
          ...state.sideTableData,
          ["tableData"]: action.payload.SortedArray
        },
        disableDiv: false,

      };
    case C_EaTypes.UPDATE_SELECTED_ERRORS:
      return {
        ...state,
        sideTableData: null,
        SelectedErr: action.payload.selectedErrors,
        disableDiv: true,
        ErrorCode: null,
        hideCreateGroup: true,
        showSpinner: false
      };
    case C_EaTypes.CLASS_EA_GRID_TABLE_FAIL:
      return {
        ...state,
        sideTableData: null,
        ErrorCode: action.payload,
        disableDiv: false,
        showSpinner: false,
        hideCreateGroup: true
      };
    case C_EaTypes.STATUS_LOAD_ICON:
      return {
        ...state,
        sideTableData: null,
        firstRecordObj: null,
        recentRecordObj: null,
        allRecordObj: null,
        ErrorCode: null,
        apiLoadFail: action.payload,
        disableDiv: false,
        isApiLoading: true,
        timeOut: false,
        showSpinner: false,
        noDataAvail: false,
        hideCreateGroup: false
      };
    case C_EaTypes.LOAD_ICON:
      return {
        ...state,
        showSpinner: true,
        sideTableData: null,
        disableDiv: false,
        isApiLoading: true,
        timeOut: false,
        ErrorCode: null,
        hideCreateGroup: false
      };
    case C_EaTypes.UPDATE_RECORD_TYPE:
      return {
        ...state,
        showRecord: action.payload,
        disableDiv: false
      };
    case C_EaTypes.API_ERROR_HANDLER:
      return {
        ...state,
        sideTableData: null,
        firstRecordObj: null,
        recentRecordObj: null,
        allRecordObj: null,
        ErrorCode: null,
        noDataAvail: false,
        hideCreateGroup: false,
        ...action.payload
      };
    case C_EaTypes.CEA_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // ClassCsvDownload: action.payLoad
        ClassCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case C_EaTypes.CEA_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        ClassCsvDownload: action.payLoad
      };
    default:
      return { ...state };
  }
};

function returnConstRecord(data, recordKey) {
  let tempObject = {
    [recordKey]: {}
  };
  Object.keys(data).forEach(function (key) {
    tempObject[recordKey][key] = returnConstructedObj(data[key], key);
  });
  return tempObject;
}

function returnConstructedObj(list, key) {
  let arrObj = {};
  list.forEach(function (obj) {
    arrObj[`${obj.fromRange}-${obj.toRange}`] = obj.value;
  });
  return arrObj;
}
