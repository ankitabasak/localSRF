import { ST_AnalysisTypes, GET_SINGLE_TEST_ANALYSIS_DATA_SUCCESS } from "../Reducer_Action_Types/ST_AnalysisTypes";
import { Report_Action_Types, SELECTED_TEST_GRADE_DROPDOWN_CLASS } from "../Reducer_Action_Types/ReportsActionTypes";
import { Student_ReportActionTypes, SELECTED_TEST_GRADE_DROPDOWN_STUDENT } from "../Reducer_Action_Types/Student_ReportTypes";
import { School_Action_Types, SELECTED_TEST_GRADE_DROPDOWN_IN_SCHOOL, SELECTED_TEST_ASSESSED_DROPDOWN_IN_SCHOOL } from "../Reducer_Action_Types/School_Report_Types";
import { ComparisonTypes } from "../Reducer_Action_Types/ComparisonTypes";
import { U_S_Action_Types, APPLY_FILTERS_IN_TEST_TAB } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT, SELECTED_TEST_ASSESSED_DROPDOWN_IN_DISTRICT, SELECTED_TEST_GRADE_DROPDOWN_IN_DISTRICT } from '../Reducer_Action_Types/District_Report_Types'
import { COMPARE_CHECKBOXES_IN_SUMMARY, TAXONOMY_SELECTED_IN_SUMMARY } from "../Reducer_Action_Types/SummaryActionsTypes";
import { BatchPrintTypes } from "../Reducer_Action_Types/BatchPrintTypes"
import { SpotPrintTypes } from "../Reducer_Action_Types/SpotPrintTypes"
import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';


const INITIAL_STATE = {
  compareOptions: {
    checkDistrict: false,
    checkSchool: false,
    checkClass: false
  },
  BatachOptions: {
    selectedOption: "single",
    defination: true,
    OverallAvg: true,
    viewsList_temp: [],
    Currentpage: 1,
    selectedView_temp: 'strand',
  },
  SingleTest_Persistance: {
    selected_test: null,
    Filter: {
      sortByParams: {
        selectedSortByParam: "question"
      },
      TaxonomyParams: {
        selectedTaxonomyList: []
      },
      AverageScoreParams: {
        selectedAverageScore: 'percentage'
      }
    },
    sortOptions: {
      fromContext: "",
      fromSortOn: "",
      fromSortType: "view",
      orderOfSort: "ASC"
    },
  },
  SP_Persistance: {
    sp_overview_persistance: {
      persisted_view: null,
      persisted_grade: null,
      persisted_qno: 1,
    },
    sp_comparison_persistance: {
      persisted_view: null,
      persisted_grade: null,
      persisted_qno: 1,
    },
    sp_grouping_persistance: {
      persisted_view: null,
      persisted_grade: null,
      persisted_qno: 1,
      NumberOfGroups: null,
      groupBy: null
    },
    sp_summary_persistance: {
      persisted_view: null,
    }
  }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {

    case ST_AnalysisTypes.COMPARE_CHECKBOXES_IN_SINGLE_TEST:

      const { checkFor, checkedStatus } = action.payload

      let checkClass_updated = checkFor == "class" ? checkedStatus : state.compareOptions.checkClass
      let checkSchool_updated = checkFor == "school" ? checkedStatus : state.compareOptions.checkSchool
      let checkDistrict_updated = checkFor == "district" ? checkedStatus : state.compareOptions.checkDistrict

      return {
        ...state,
        compareOptions: {
          ...state.compareOptions,
          checkDistrict: checkDistrict_updated,
          checkSchool: checkSchool_updated,
          checkClass: checkClass_updated
        }
      }
    case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:
      return {
        ...state,
        BatachOptions:INITIAL_STATE.BatachOptions
      }
    case BatchPrintTypes.BATCH_PRINTING_SELECTED:
      const { selectedOption } = action.payload
      return {
        ...state,
        BatachOptions: {
          ...state.BatachOptions,
          selectedOption: selectedOption
        }
      }
    case BatchPrintTypes.BATCH_PRINT_SELECT_DESCRIPTION:
      let defination = action.payload.selectedOption
      return {
        ...state,
        BatachOptions: {
          ...state.BatachOptions,
          defination: !defination
        }
      }
    case SpotPrintTypes.SPOT_PRINTING_SELECTED:
      let spotdefination = action.payload.selectedOption
      return {
        ...state,
        BatachOptions: {
          ...state.BatachOptions,
          selectedOption: spotdefination
        }
      }
    case SpotPrintTypes.SPOT_PRINT_SELECT_SHOW:
      const { option, updatedStatus } = action.payload;
      if (option === "def") {
        return {
          ...state,
          BatachOptions: {
            ...state.BatachOptions,
            defination: updatedStatus
          }
        }
      } else {
        return {
          ...state,
          BatachOptions: {
            ...state.BatachOptions,
            OverallAvg: updatedStatus
          }
        }
      }


    case SpotPrintTypes.SPOT_PRINT_SELECT_VIEW:
      let selectedtype = action.payload.selectedOption
      return {
        ...state,
        BatachOptions: {
          ...state.BatachOptions,
          selectedView_temp: selectedtype
        }
      }

    case SpotPrintTypes.SPOT_PRINTING_POPUP_STATUS:
      const { taxoList, selectedStrandStandard, isStrand, batch_options } = action.payload
      let taxonomyList = modifyTaxonomyStructure(taxoList)
      if (state.BatachOptions.viewsList_temp.length > 0) {
        return {
          ...state,
        }
      } else {
        return {
          ...state,
          BatachOptions: {
            ...state.BatachOptions,
            viewsList_temp: taxonomyList
          }
        }
      }

    case SpotPrintTypes.SPOT_PRINT_SELECTED_TAXONOMY:
      const { taxoName } = action.payload
      let currentTaxoList = state.BatachOptions.viewsList_temp;
      let updatedTaxoList = updatedTaxonomiesList(currentTaxoList, taxoName, action.payload.updatedStatus)

      return {
        ...state,
        BatachOptions: {
          ...state.BatachOptions,
          viewsList_temp: updatedTaxoList
        }
      }
    case SpotPrintTypes.SPOT_PRINT_CURRENT_SELECTED_PAGE:
      const { selectedPage } = action.payload
      return {
        ...state,
        BatachOptions: {
          ...state.BatachOptions,
          Currentpage: selectedPage
        }
      }

    case ST_AnalysisTypes.SINGLE_TEST_APPLY_FILTER:


      return updatePersistSingleTestApplyFilter(state, action)

    case Report_Action_Types.CHECK_COMPARE_TABS_IN_CLASS:

      return updatePersistOverviewCompare(state, action)

    case Student_ReportActionTypes.COMPARE_CHECK_BOXES_OF_S_TS_OVERVIEW:

      return updatePersistOverviewCompare_student(state, action)

    case School_Action_Types.COMPARE_CHECKBOX_OPTION_FOR_SCHOOL_LC:

      return updatePersistOverviewCompare_school(state, action)

    case ComparisonTypes.COMPARE_CHECK_COMPARE_OPTION:

      return updatePersistTestScoreCompare(state, action)

    case APPLY_FILTERS_IN_TEST_TAB:

      return applyFilterInTestTab(state, action)

    case COMPARE_CHECKBOXES_IN_SUMMARY:

      return update_compare_checkboxes_summary(state, action)

    case Report_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_CLASS:

      return update_view_sp_overview(state, action)

    case School_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_SCHOOL:

      return update_view_sp_overview(state, action)

    case SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT:

      return update_view_sp_overview(state, action)

    case Student_ReportActionTypes.SELECTED_TEST_TAXONOMY_DROPDOWN_STUDENT:

      return update_view_sp_overview(state, action)

    case ComparisonTypes.COMPARISON_SELECTED_TAXONOMY:

      return update_view_COMPARISON_SELECTED_TAXONOMY(state, action)

    case Report_Action_Types.SELECTED_TEST_ASSESSED_DROPDOWN_CLASS:

      return update_qno_sp_overview(state, action)

    case SELECTED_TEST_ASSESSED_DROPDOWN_IN_SCHOOL:

      return update_qno_sp_overview(state, action)

    case SELECTED_TEST_ASSESSED_DROPDOWN_IN_DISTRICT:

      return update_qno_sp_overview(state, action)

    case Student_ReportActionTypes.SELECTED_TEST_ASSESSED_DROPDOWN_STUDENT:

      return update_qno_sp_overview(state, action)

    case SELECTED_TEST_GRADE_DROPDOWN_CLASS:

      return update_grade_sp_overview(state, action)

    case SELECTED_TEST_GRADE_DROPDOWN_IN_SCHOOL:

      return update_grade_sp_overview(state, action)

    case SELECTED_TEST_GRADE_DROPDOWN_IN_DISTRICT:

      return update_grade_sp_overview(state, action)

    case SELECTED_TEST_GRADE_DROPDOWN_STUDENT:

      return update_grade_sp_overview(state, action)

    case Report_Action_Types.COMPARE_CHECKBOX_OPTION_FOR_STRANDS_LC:

      return update_sp_compare_checkboxes_class(state, action)

    case Student_ReportActionTypes.COMPARE_CHECKBOX_OPTION_IN_STUDENT:

      return update_sp_compare_checkboxes_student(state, action)
    case School_Action_Types.COMPARE_CHECKBOX_OPTION_FOR_SCHOOL_LC:

      return update_sp_compare_checkboxes_school(state, action)

    case TAXONOMY_SELECTED_IN_SUMMARY:
      return update_summary_taxonomy(state, action);

    case GET_SINGLE_TEST_ANALYSIS_DATA_SUCCESS:
      return update_testdata_ifNull(state, action);

    case ComparisonTypes.COMPARISON_SELECTED_QNUMBER:
      return update_qno_COMPARISON_SELECTED_QNUMBER(state, action);

    case ComparisonTypes.COMPARISON_SELECTED_GRADE:
      return update_grade_COMPARISON_SELECTED_GRADE(state,action);
    default:
      return {
        ...state
      };
  }

}

export function update_testdata_ifNull(state, action) {

  const { selectedTest } = action.payload
  if (state.SingleTest_Persistance.selected_test == null && selectedTest.length > 0) {
    return {
      ...state,
      SingleTest_Persistance: {
        ...state.SingleTest_Persistance,
        selected_test: selectedTest[0].componentCode,
      }
    }
  } else {
    return {
      ...state
    }
  }

}

export function update_summary_taxonomy(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_summary_persistance: {
        ...state.SP_Persistance.sp_summary_persistance,
        persisted_view: action.payload.selected
      }
    }
  }
}
export function update_grade_sp_overview(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_overview_persistance: {
        ...state.SP_Persistance.sp_overview_persistance,
        persisted_grade: action.payload
      },
      sp_comparison_persistance: {
        ...state.SP_Persistance.sp_comparison_persistance,
        persisted_grade: action.payload
      },
    }
  }
}

export function update_qno_sp_overview(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_overview_persistance: {
        ...state.SP_Persistance.sp_overview_persistance,
        persisted_qno: action.payload
      },
      sp_comparison_persistance: {
        ...state.SP_Persistance.sp_comparison_persistance,
        persisted_qno: action.payload
      },
    }
  }
}

export function update_view_sp_overview(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_overview_persistance: {
        ...state.SP_Persistance.sp_overview_persistance,
        persisted_view: action.payload
      },
      sp_comparison_persistance: {
        ...state.SP_Persistance.sp_comparison_persistance,
        persisted_view: action.payload
      },
    }
  }
}
export function update_view_COMPARISON_SELECTED_TAXONOMY(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_comparison_persistance: {
        ...state.SP_Persistance.sp_comparison_persistance,
        persisted_view: action.payload.taxonomy
      },
    }
  }
}

export function update_compare_checkboxes_summary(state, action) {
  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkClass: action.payload.fromCheckBox == "class" ? !state.compareOptions.checkClass : state.compareOptions.checkClass,
      checkSchool: action.payload.fromCheckBox == "school" ? !state.compareOptions.checkSchool : state.compareOptions.checkSchool,
      checkDistrict: action.payload.fromCheckBox == "district" ? !state.compareOptions.checkDistrict : state.compareOptions.checkDistrict,
    }

  }
}

export function applyFilterInTestTab(state, action) {

  const { selectedTest, Nav } = action.payload;

  if (Nav.st_analysis) {
    return {
      ...state,
      SingleTest_Persistance: {
        ...state.SingleTest_Persistance,
        selected_test: selectedTest[0].componentCode,
      }
    }
  } else {
    return {
      ...state
    }
  }
}

export function updatePersistTestScoreCompare(state, action) {

  const { checkFor, checkedStatus, fromContext, fromtab } = action.payload

  let checkClass_updated = checkFor == "class" ? checkedStatus : state.compareOptions.checkClass
  let checkSchool_updated = checkFor == "school" ? checkedStatus : state.compareOptions.checkSchool
  let checkDistrict_updated = checkFor == "district" ? checkedStatus : state.compareOptions.checkDistrict

  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated,
      checkSchool: checkSchool_updated,
      checkClass: checkClass_updated
    }
  }

}

export function updatePersistOverviewCompare_school(state, action) {

  const { selectedfiield, check, IN_TS_Overview } = action.payload

  let checkDistrict_updated = selectedfiield == "District" ? check : state.compareOptions.checkDistrict
  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated,

    }
  }
}

export function updatePersistOverviewCompare_student(state, action) {

  const { Checked, selectedCheckBox } = action.payload

  let checkClass_updated = selectedCheckBox == "Class" ? Checked : state.compareOptions.checkClass
  let checkSchool_updated = selectedCheckBox == "School" ? Checked : state.compareOptions.checkSchool
  let checkDistrict_updated = selectedCheckBox == "District" ? Checked : state.compareOptions.checkDistrict

  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated,
      checkSchool: checkSchool_updated,
      checkClass: checkClass_updated
    }
  }
}

export function updatePersistOverviewCompare(state, action) {

  const { CheckOrUncheck, selectedOption } = action.payload

  let checkClass_updated = selectedOption == "Class" ? CheckOrUncheck : state.compareOptions.checkClass
  let checkSchool_updated = selectedOption == "School" ? CheckOrUncheck : state.compareOptions.checkSchool
  let checkDistrict_updated = selectedOption == "District" ? CheckOrUncheck : state.compareOptions.checkDistrict

  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated,
      checkSchool: checkSchool_updated,
      checkClass: checkClass_updated
    }
  }
}

export function updatePersistSingleTestApplyFilter(state, action) {
  let fromContext = action.payload.fromContext;
  let SingleTestAnalysis = action.payload.SingleTestAnalysis;

  let selectedTaxonomyList = (fromContext == "student") ? SingleTestAnalysis.student_TestAnalysis.Filter.TaxonomyParams.selectedTaxonomyList_temp : ((fromContext == "class") ? SingleTestAnalysis.class_TestAnalysis.Filter.TaxonomyParams.selectedTaxonomyList_temp : ((fromContext == "school") ? SingleTestAnalysis.school_TestAnalysis.Filter.TaxonomyParams.selectedTaxonomyList_temp : SingleTestAnalysis.district_TestAnalysis.Filter.TaxonomyParams.selectedTaxonomyList_temp));
  let selectedSortByParam = (fromContext == "student") ? SingleTestAnalysis.student_TestAnalysis.Filter.sortByParams.selectedSortByParam_temp : ((fromContext == "class") ? SingleTestAnalysis.class_TestAnalysis.Filter.sortByParams.selectedSortByParam_temp : ((fromContext == "school") ? SingleTestAnalysis.school_TestAnalysis.Filter.sortByParams.selectedSortByParam_temp : SingleTestAnalysis.district_TestAnalysis.Filter.sortByParams.selectedSortByParam_temp));
  let selectedAverageScore = (fromContext == "student") ? SingleTestAnalysis.student_TestAnalysis.Filter.AverageScoreParams.selectedAverageScore_temp : ((fromContext == "class") ? SingleTestAnalysis.class_TestAnalysis.Filter.AverageScoreParams.selectedAverageScore_temp : ((fromContext == "school") ? SingleTestAnalysis.school_TestAnalysis.Filter.AverageScoreParams.selectedAverageScore_temp : SingleTestAnalysis.district_TestAnalysis.Filter.AverageScoreParams.selectedAverageScore_temp));

  return {
    ...state,
    SingleTest_Persistance: {
      ...state.SingleTest_Persistance,
      Filter: {
        ...state.SingleTest_Persistance.Filter,
        sortByParams: {
          ...state.SingleTest_Persistance.Filter.sortByParams,
          selectedSortByParam: selectedSortByParam
        },
        TaxonomyParams: {
          ...state.SingleTest_Persistance.Filter.TaxonomyParams,
          selectedTaxonomyList: selectedTaxonomyList
        },
        AverageScoreParams: {
          ...state.SingleTest_Persistance.Filter.AverageScoreParams,
          selectedAverageScore: selectedAverageScore
        },
      }
    }
  }
}
export function update_sp_compare_checkboxes_class(state, action) {

  const { selectedfiield, check } = action.payload

  let checkSchool_updated = selectedfiield == "School" ? check : state.compareOptions.checkSchool
  let checkDistrict_updated = selectedfiield == "District" ? check : state.compareOptions.checkDistrict

  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated,
      checkSchool: checkSchool_updated
    }
  }

}
export function update_sp_compare_checkboxes_student(state, action) {

  const { SelectedOption, check } = action.payload

  let checkClass_updated = SelectedOption == "Class" ? check : state.compareOptions.checkClass
  let checkSchool_updated = SelectedOption == "School" ? check : state.compareOptions.checkSchool
  let checkDistrict_updated = SelectedOption == "District" ? check : state.compareOptions.checkDistrict

  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated,
      checkSchool: checkSchool_updated,
      checkClass: checkClass_updated
    }
  }

}
export function update_sp_compare_checkboxes_school(state, action) {

  const { selectedfiield, check } = action.payload

  let checkDistrict_updated = selectedfiield == "District" ? check : state.compareOptions.checkDistrict

  return {
    ...state,
    compareOptions: {
      ...state.compareOptions,
      checkDistrict: checkDistrict_updated
    }
  }

}
export function modifyTaxonomyStructure(taxoList) {

  let resultantObject = []

  taxoList.map(singleTaxo => {
    resultantObject.push({
      taxonomy: singleTaxo,
      check: true
    })
  })

  return resultantObject

}
function updatedTaxonomiesList(currentTaxoList, taxoName, updatedStatus) {
  let updatedListOfTaxo = currentTaxoList
  updatedListOfTaxo.map(singleTaxonomy => {
    if (singleTaxonomy.taxonomy == taxoName) {
      singleTaxonomy.check = updatedStatus
    }
  })
  return updatedListOfTaxo
}

export function update_qno_COMPARISON_SELECTED_QNUMBER(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_comparison_persistance: {
        ...state.SP_Persistance.sp_comparison_persistance,
        persisted_qno: action.payload.selectedQuestion
      },
    }
  }
}
export function update_grade_COMPARISON_SELECTED_GRADE(state, action) {
  return {
    ...state,
    SP_Persistance: {
      ...state.SP_Persistance,
      sp_comparison_persistance: {
        ...state.SP_Persistance.sp_comparison_persistance,
        persisted_grade: action.payload.selectedGrade
      },
    }
  }
}