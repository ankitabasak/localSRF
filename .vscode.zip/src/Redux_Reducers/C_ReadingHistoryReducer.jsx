import { C_ReadingHistoryTypes } from '../Reducer_Action_Types/C_ReadingHistoryTypes.jsx';
import { dataSorting, constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

const INITIAL_STATE = {
  ClassReadingHistoryDetails: {
    data: null,
    isApiLoading: true,
    isDataNotAvailable: false,
    chartLoadFail: false,
    timeOut: false
  },
  Response: '',
  SortData: {
    sortColumn: 'assignmentDate',
    sortType: 'desc'
  },
  ClassCsvDownload: { csvData: null, downloadInProgress: false }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case C_ReadingHistoryTypes.CLASS_READING_HISTORY_DATA_SUCCESS:
      return {
        ...state,
        ClassReadingHistoryDetails: {
          data: action.payload.classReadingHistoryData,
          isApiLoading: false,
          timeOut: false,
          chartLoadFail: false,
          isDataNotAvailable:
            action.payload.classReadingHistoryData.length > 0 ? false : true
        },
        Response: action.payload.SUCCESSFULL,
        SortData: {
          sortColumn: 'assignmentDate',
          sortType: 'desc'
        },
        ClassCsvDownload: { csvData: null, downloadInProgress: false }
      };
    case C_ReadingHistoryTypes.CLASS_READING_HISTORY_DATA_FAIL:
      return {
        ...state,
        ClassReadingHistoryDetails: {
          data: null,
          isApiLoading: false,
          isDataNotAvailable: false,
          chartLoadFail: true,
          timeOut: false
        },
        Response: action.payload
      };
    case C_ReadingHistoryTypes.CRH_ERROR_HANDLING:
      return {
        ...state,
        ClassReadingHistoryDetails: {
          ...state.ClassReadingHistoryDetails,
          data: null,
          ...action.payload
        }
      };
    case C_ReadingHistoryTypes.CLASS_READING_HISTORY_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case C_ReadingHistoryTypes.CLASS_SAVE_SORTED_CLASS_READING_HISTORY_DATA:
      return {
        ...state,
        ClassReadingHistoryDetails: {
          data: action.payload.SortedArray
        }
      };
    case C_ReadingHistoryTypes.CRH_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // ClassCsvDownload: action.payLoad
        ClassCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case C_ReadingHistoryTypes.CRH_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        ClassCsvDownload: action.payLoad
      };
    default:
      return { ...state };
  }
};
