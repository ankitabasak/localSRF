import { DistrictRLPTypes } from '../Reducer_Action_Types/District_RlpActionTypes.jsx';
import { dataSorting, constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

export const INITIAL_STATE = {
  DistrictRLPState: {
    districtLevelGrade: null,
    responseData: null,
    districtsSelected: {},
    isMobileView: 5,
    constructedData: null,
    sumDistData: null,
    yAxisData: null,
    yAxisDataRange: null,
    yScrollIndex: 0,
    xScrollIndex: 0,
    xAxisGradeRange: null,
    ClassLevelApiData: null,
    DistrictLevelConstructedData: null,
    ClassLevelContsructedData: null,
    isApiLoading: true,
    timeout: false,
    apiLoadFail: false,
    noChartData: false,
    currentChartInDisplay: 'SLRLP'
  },
  sidePanelApiFailed: false,
  RlpGridData: null,
  DistrictRlpGridData: null,
  SortData: {
    sortColumn: 'name',
    sortType: 'asc'
  },
  modifiedArray: {},
  isApiLoading: true,
  apiLoadFail: false,
  dstCsvDownload: { csvData: null, downloadInProgress: false },
  toggleData: false
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case DistrictRLPTypes.CHART_API_LOADER:
      return {
        ...state,
        isApiLoading: true,
        toggleData: false,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          isApiLoading: true,
          noChartData: false,
          apiLoadFail: false,
          ['sumDistData']: null,
          ['constructedData']: null
        }
      };
    case DistrictRLPTypes.CHART_LOADING_FAILED:
      return {
        ...state,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          isApiLoading: false,
          apiLoadFail: true,
          ...action.payload,
          ['sumDistData']: null,
          ['constructedData']: null
        },
        sidePanelApiFailed: false
      };
    case DistrictRLPTypes.DISTRICT_RLP_GRID_DATA:
      return {
        ...state,
        DistrictRlpGridData: {
          ['firstRecDR']: action.payload.firstRecordDateRange,
          ['recentRecDR']: action.payload.firstRecordDateRange,
          ['districtSidePanelData']: sortDataFn(
            'name',
            'asc',
            action.payload.recordData
          ),
          ['studentRoster']: action.payload.noOfStudentsRostered,
          ['grade']: action.payload['grade']
            ? action.payload.grade.join(', ')
            : '',
          ['classes']:
            action.payload['schoolName'] && action.payload.schoolName.length > 0
              ? action.payload.schoolName.join(', ')
              : null,
          ['showAccordion']: toShowFirstAccordion(action.payload.recordData)
        },
        SortData: {
          sortColumn: 'name',
          sortType: 'asc'
        },
        sidePanelApiFailed: false
      };
    case DistrictRLPTypes.DISTRICT_RLP_CHART_API_SUCCESS:
      let scrollLen = getMobileView();
      let temVar = getConstructedData(action.payload.responseData, 13, scrollLen);

      return {
        ...state,

        isApiLoading: false,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['responseData']: action.payload.responseData,
          ['constructedData']: temVar,
          ['dstRlpChartData']: temVar,
          isMobileView: scrollLen,
          isApiLoading: false,
          apiLoadFail: false,
          noChartData: false,
          ['currentChartInDisplay']: 'SLRLP',
          ['districtsSelected']: []
        },
        monthRangeObj: monthDataConstruction(action.payload.responseData),
        selAll: true,
        dstCsvDownload: { csvData: null, downloadInProgress: false },
        toggleData: false
      };

    case DistrictRLPTypes.SUM_DST_RLP_CHART_API_SUCCESS:
      let sumDistVar = getConstructedData(action.payload.responseData, 7, 3);
      return {
        ...state,

        isApiLoading: false,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['responseData']: action.payload.responseData,
          isApiLoading: false,
          apiLoadFail: false,
          noChartData: false,
          ['currentChartInDisplay']: 'SLRLP',
          ['districtsSelected']: [],
          ['sumDistData']: sumDistVar
        },
        sidePanelApiFailed: false
      };
    case DistrictRLPTypes.DISTRICT_RLP_CHART_API_FAIL:
      return {
        ...state,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          isApiLoading: false,
          noChartData: false,
          apiLoadFail: true,

          ['constructedData']: null,
          ['sumDistData']: null
        }
      };
    case DistrictRLPTypes.DISTRICT_RLP_CLASS_LEVEL_CHART_API_SUCCESS:
      let tempVar = getConstructedData(action.payload.responseData, 13, state['DistrictRLPState']['isMobileView']);

      return {
        ...state,
        sidePanelApiFailed: false,
        isApiLoading: false,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['responseData']: action.payload.responseData,
          ['constructedData']: tempVar,
          ['dstRlpChartData']: tempVar,
          isApiLoading: false,
          noChartData: false,
          apiLoadFail: false,
          ['currentChartInDisplay']: 'CLRLP',
          ['districtLevelGrade']: action.payload.districtLevelGrade,
          ['districtsSelected']: []
        },
        monthRangeObj: ScrlpClassDataConstruction(action.payload.responseData),
        selAll: true,
        dstCsvDownload: { csvData: null, downloadInProgress: false },
        toggleData: false
      };
    case DistrictRLPTypes.DISTRICT_RLP_CLASS_LEVEL_CHART_API_FAIL:
      return {
        ...state
      };
    case DistrictRLPTypes.DISTRICT_RLP_CHART_SCROLL_DATA:
      return {
        ...state,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['constructedData']: {
            ...state.DistrictRLPState.constructedData,
            ...action.payload
          }
        }
      };
    case DistrictRLPTypes.DISTRICT_SUM_RLP_SCROLL_DATA:
      return {
        ...state,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['sumDistData']: {
            ...state.DistrictRLPState.sumDistData,
            ...action.payload
          }
        }
      };
    case DistrictRLPTypes.UPDATE_SELECTED_LEVELS:
      return {
        ...state,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['districtsSelected']: action.payload.selectedLevels
        },
        DistrictRlpGridData: null
      };
    case DistrictRLPTypes.DISTRICT_RLP_GRID_API_CALL_FAIL:
      return {
        ...state,
        DistrictRlpGridData: null,
        sidePanelApiFailed: true
      };
    case DistrictRLPTypes.DISTRICT_RLP_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case DistrictRLPTypes.DISTRICT_RLP_SAVE_SORT_ARRAY:
      return {
        ...state,
        modifiedArray: action.payload.SortedArray
      };
    case DistrictRLPTypes.DISTRICT_RLP_CLASS_LEVEL_GRID_API_SUCCESS:
      return {
        ...state,
        sidePanelApiFailed: false,
        DistrictRlpGridData: {
          ['firstRecDR']: action.payload.firstRecordDateRange,
          ['recentRecDR']: action.payload.firstRecordDateRange,
          ['districtSidePanelData']: sortDataFn(
            'name',
            'asc',
            action.payload.districtRLPGradeWiseGridDataResponseList
          ),
          ['studentRoster']: action.payload.noOfStudentsRostered,
          ['grade']: action.payload.class
        },
        SortData: {
          sortColumn: 'name',
          sortType: 'asc'
        }
      };
    case DistrictRLPTypes.DISTRICT_CLASS_NAME:
      return {
        ...state,
        DistrictRlpGridData: {
          ...state.DistrictRlpGridData,
          ['showAccordion']: action.payload
        }
      };
    case DistrictRLPTypes.DSTRLP_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        dstCsvDownload: action.payLoad
      };
    case DistrictRLPTypes.DSTRLP_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // dstCsvDownload: action.payLoad
        dstCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case DistrictRLPTypes.DSTRLP2_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // dstCsvDownload: action.payLoad
        dstCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case DistrictRLPTypes.DSTRLP2_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        dstCsvDownload: action.payLoad
      }
    case DistrictRLPTypes.DSTRLP_UPDATE_DROP_DOWN_DATA:
      return {
        ...state,
        ...getSelectedGrade(action.payLoad, state.monthRangeObj)
      };
    case DistrictRLPTypes.DSTRLP_UPDATE_ALL_DATA:
      return {
        ...state,
        ...updateSelAll(action.payLoad.selAll, state.monthRangeObj)
      };
    case DistrictRLPTypes.DSTRLP_UPDATE_TOGGLE:
      return {
        ...state,
        toggleData: action.payLoad.toggleData,
        ...updateAll(state.selAll, state.monthRangeObj)
      };
    case DistrictRLPTypes.DSTRLP_UPDATE_CHART_DATA:
      // scrollLen = getMobileView();
      return {
        ...state,
        ['DistrictRLPState']: {
          ...state.DistrictRLPState,
          ['constructedData']: modifiedData(action.payLoad,
            5,
            state.DistrictRLPState.dstRlpChartData,
            state.DistrictRLPState.currentChartInDisplay),

        }
      };
    default:
      return {
        ...state
      };
  }
};
function getConstructedData(responseData, yLen, xLen) {
  let gradeData = [];
  let axisDataRange;
  responseData.gradeWiseResultList.forEach(obj => {
    if (responseData.grade) {
      axisDataRange = xAxisRange(responseData.grade);
    } else {
      axisDataRange = xAxisRange(obj.grade);
    }
    let tempObj = obj;
    tempObj['gradeWiseReadingLevelRange'] = axisDataRange;
    tempObj['recordDataList'] = {
      firstRecord: rePhraseColumndata(obj['recordDataList']['firstRecord']),
      recentRecord: rePhraseColumndata(obj['recordDataList']['recentRecord'])
    };
    gradeData.push(tempObj);
  });

  return {
    xAxisData: gradeData,
    yAxisData: responseData.readingLevelAxis,
    yScrollIndex: 0,
    xScrollIndex: 0,
    yAxisDataRange: getAxisRangeData(responseData.readingLevelAxis, 0, yLen),
    xAxisGradeRange: getGradeArray(gradeData, 0, xLen)
  };
}
function rePhraseColumndata(dataList) {
  let resultSet = {};
  if (dataList && dataList.length > 0) {
    dataList.forEach(item => {
      resultSet[item['readingLevel']] = {
        percentage: item['percentage'],
        orrAssignmentId: item['orrAssignmentId']
      };
    });
  }

  return resultSet;
}
function getGradeArray(listItems, index, xLen) {
  return listItems.slice(index, xLen);
}

function getAxisRangeData(dataList, index, yLen) {
  let rl = dataList.slice(index, yLen);
  return rl.reverse();
}

//to show  the first accordion open
function toShowFirstAccordion(sideTableData) {
  let tempObj = {};
  sortDistrictData('schoolName', sideTableData);

  sideTableData &&
    sideTableData.forEach((obj, index) => {
      if (index === 0) {
        tempObj[obj.schoolName] = true;
      } else {
        tempObj[obj.schoolName] = false;
      }
    });

  return tempObj;
}

//to sort table data by District name
function sortDistrictData(column, sideTableData) {
  if (sideTableData !== null) {
    let sortedData = sideTableData.sort(function (a, b) {
      let firstElement =
        column !== 'districtName'
          ? a[column]
          : a[column].toString().toUpperCase();
      let secondElement =
        column !== 'districtName'
          ? b[column]
          : b[column].toString().toUpperCase();

      let com = 0;
      if (firstElement > secondElement) {
        com = 1;
      } else if (firstElement < secondElement) {
        com = -1;
      }

      return com;
    });
    return sortedData;
  }
}

//function to sort array of data
function sortDataFn(column, sortType, stdArray) {
  let sortedArray = [];
  stdArray.map((actualArray, value) => {
    if (actualArray.length != 0) {
      sortedArray = dataSorting(actualArray.classData, column, sortType);
    }
  });
  return stdArray;
}

//function to get array data for grade
function xAxisRange(grade) {
  let gradeLevel = {
    K: ['AA', 'A', 'B', 'C', 'D'],
    '1': ['E', 'F', 'G', 'H', 'I', 'J'],
    '2': ['K', 'L', 'M'],
    '3': ['N', 'O', 'P'],
    '4': ['Q', 'R', 'S'],
    '5': ['T', 'U', 'V'],
    '6': ['W', 'X', 'Y'],
    '7': ['Z'],
    '8': ['Z']
  };
  return (gradeLevel[grade] || ['Z']);
}
function getSelectedGrade(monthObj, monthRange) {
  let monthCount = 0;
  let selAll;
  monthRange[monthObj['index']] = monthObj;
  monthRange.forEach((item, index) => {
    if (item.checked) {
      monthCount++;
    }
  })
  if (monthCount === 0) {
    monthRange.forEach((item, index) => {
      if (!item.checked) {
        monthRange[index].checked = !monthRange[index].checked
      }
    })
  }
  if (monthCount === monthRange.length || monthCount === 0) {
    selAll = true;
  } else {
    selAll = false;
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function updateSelAll(selAll, monthRange) {
  if (selAll) {
    monthRange.forEach((item, index) => {
      monthRange[index].checked = true
    })
  } else {
    monthRange.forEach((item, index) => {
      monthRange[index].checked = false
    })
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function updateAll(selAll, monthRange) {
  let monthCount = 0;

  if (!selAll) {
    monthRange.forEach((item, index) => {
      if (item.checked) {
        monthCount++;
      }
    })
    if (monthCount === 0) {
      monthRange.forEach((item, index) => {
        if (!item.checked) {
          monthRange[index].checked = !monthRange[index].checked;
          selAll = true
        }
      })
    }
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}


function modifiedData(monthRange, xAxisLen, scRlpObj, currentChartInDisplay) {
  let monthCount = 0;
  let newObj = [];
  let xGradeObj = [];
  currentChartInDisplay === 'SLRLP' && monthRange.forEach((item, index) => {
    if (item.checked) {
      monthCount++;
      newObj.push(scRlpObj.xAxisData[index]);
      if (item.monthName === scRlpObj.xAxisData[index]['grade'])
        xGradeObj.push(scRlpObj.xAxisData[index])
    }
  })

  currentChartInDisplay === 'CLRLP' && monthRange.forEach((item, index) => {
    if (item.checked) {
      monthCount++;
      newObj.push(scRlpObj.xAxisData[index]);
      if (item.monthName === scRlpObj.xAxisData[index]['schoolName'])
        xGradeObj.push(scRlpObj.xAxisData[index])
    }
  })

  if (monthCount === scRlpObj.xAxisData.length) {
    xGradeObj = [];
    xGradeObj = getGradeArray(scRlpObj.xAxisData, 0, xAxisLen);
  }

  if (monthCount > 4) {
    xGradeObj = getGradeArray(xGradeObj, 0, xAxisLen);
  }
  return {
    ...scRlpObj,
    xAxisData: newObj,
    xAxisGradeRange: xGradeObj
  };
}

function monthDataConstruction(responseData) {
  let monthObj = responseData.gradeWiseResultList.map((obj, idx) => {
    return { monthName: obj.grade, index: idx, checked: true }
  })
  return monthObj
}
function getMobileView() {
  let userAgent = window.navigator.userAgent.toLowerCase();
  let ios = /iphone|ipod|ipad/.test(userAgent)
  let mobileView = ((ios || window.innerWidth < 1050));
  return mobileView ? 3 : 5;
}

function ScrlpClassDataConstruction(responseData) {
  let monthObj = responseData.gradeWiseResultList.map((obj, idx) => {
    return { monthName: obj.schoolName, index: idx, checked: true }
  })
  return monthObj
}
