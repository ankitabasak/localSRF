import cReadingLevelReducer from './C_ReadingLevelReducer'

describe('cReadingLevelReducer', () => {
    it('default matches', () => {
      expect(cReadingLevelReducer(undefined, {})).toMatchSnapshot();
    });

    it('test CLASS_READING_LEVEL_GRID_DATA_SUCCESS', () => {
      expect(cReadingLevelReducer(undefined, {
        type: 'CLASS_READING_LEVEL_GRID_DATA_SUCCESS',
      })).toMatchSnapshot();
    });
});
