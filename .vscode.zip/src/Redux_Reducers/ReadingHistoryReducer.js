import { ReadingHistoryTypes } from '../Reducer_Action_Types/ReadingHistoryTypes';
import { constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

const INITIAL_STATE = {
  ReadingHistoryDetails: {
    data: null,
    isApiLoading: true,
    isDataNotAvailable: false,
    chartLoadFail: false,
    timeOut: false
  },
  Response: '',
  SortData: {
    sortColumn: 'assignmentDate',
    sortType: 'desc'
  },
  ReadingLevel: {
    startingLevel: '',
    readingTarget: ''
  },
  SRHCSVDownload: { csvData: null, downloadInProgress: false }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ReadingHistoryTypes.READING_HISTORY_DATA_SUCCESS:
      return {
        ...state,
        ReadingHistoryDetails: {
          data: action.payload.studentReadingHistoryData,
          isApiLoading: false,
          timeOut: false,
          chartLoadFail: false,
          isDataNotAvailable:
            action.payload.studentReadingHistoryData.length > 0 ? false : true
        },
        Response: action.payload.SUCCESSFULL,
        SortData: {
          sortColumn: 'assignmentDate',
          sortType: 'desc'
        },
        ReadingLevel: {
          startingLevel: action.payload.studentReadingLevel.startingLevel,
          readingTarget: action.payload.studentReadingLevel.readingTarget
        },
        SRHCSVDownload: { csvData: null, downloadInProgress: false }
      };
    case ReadingHistoryTypes.SRH_LOADER:
      return {
        ReadingHistoryDetails: {
          data: null,
          Response: action.payload,
          isApiLoading: true,
          isDataNotAvailable: false,
          chartLoadFail: false,
          timeOut: false
        }
      }
    case ReadingHistoryTypes.READING_HISTORY_DATA_FAIL:
      return {
        ...state,
        ReadingHistoryDetails: {
          data: null,
          Response: action.payload,
          isApiLoading: false,
          isDataNotAvailable: false,
          chartLoadFail: true,
          timeOut: false
        }
      };
    case ReadingHistoryTypes.READING_HISTORY_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case ReadingHistoryTypes.SAVE_SORTED_S_READING_HISTORY_DATA:
      return {
        ...state,
        ReadingHistoryDetails: {
          data: action.payload.SortedArray
        }
      };
    case ReadingHistoryTypes.SRH_ERROR_HANDLING:
      return {
        ...state,
        ReadingHistoryDetails: {
          ...state.ReadingHistoryDetails,
          data: null,
          ...action.payload
        }
      };
    case ReadingHistoryTypes.SRH_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // SRHCSVDownload: action.payLoad
        SRHCSVDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case ReadingHistoryTypes.SRH_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        SRHCSVDownload: action.payLoad
      };
    default:
      return { ...state };
  }
};
