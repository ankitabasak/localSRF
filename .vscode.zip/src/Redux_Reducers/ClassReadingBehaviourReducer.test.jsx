import classReadingBehaviourReducer from './ClassReadingBehaviourReducer'

describe('classReadingBehaviourReducer', () => {
    it('default matches', () => {
      expect(classReadingBehaviourReducer(undefined, {})).toMatchSnapshot();
    });

    it('test CRB_CHART_API_SUCCESS', () => {
      expect(classReadingBehaviourReducer(undefined, {
        type: 'CRB_CHART_API_SUCCESS',
      })).toMatchSnapshot();
    });
});
