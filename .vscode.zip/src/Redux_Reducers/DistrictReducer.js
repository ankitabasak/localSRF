import { Report_Action_Types, MOVE_BUBBLES_OF_PAGINATION_FOR_REMAINING, CHANGE_BUBBLE_OF_PAGINATION_FOR_REMAINIG, GET_STANDARDPERFORMANCE_DETAIL_SUCCESS, CHANGE_TOGGLE_IN_SP_OVERVIEW_COMPONENT } from '../Reducer_Action_Types/ReportsActionTypes';
import {
    CHART_PAGE_AT,
    CHART_TOTAL_BUBBLES,
    CHART_BUBBLE_START,
    CHART_PAGE_COUNT_START,
    CHART_PAGE_COUNT_END,
    PaginationFor_Remaining,
    CHART_COUNT_PER_PAGE_FOR_CLASS_TAB,
    STRANS_LINECHART_COUNT_PER_PAGE,
    Disable_AutoSelect_Std_Pref_LeftView,
    Disable_AutoSelect_TS_Overview_LeftView

} from '../Utils/globalVars';

const INITIAL_STATE = {
    SPSummarydrillDown: false,
    taxonomyfromSPSummary:'',
    D_ApiCalls: {
        get_TS_Details: false,
        get_Student_LineChart: false,
        getClassTestScoresAferInitialLoad: false,
        get_Graph_ofClassStrand_AferInitialLoad: false,
        get_Sp_Assessed_Ques: false,
        loading_on_strands_schools: false,
        loading_on_strands_Lc: false,
        loading_Strands_table: false,
        loading_on_TS_LC: false,
        loading_on_Sp_Assessed_Ques: false,
        loading_LC_students: false,
        get_SchoolList_and_Graph_ofStrand: false,
        Get_OnlyGraphOnCompareInStrandsComp: false,
        Get_OnlyGraphOnCompareInStrandsComp_Alias: false,
        loading_Strand_Grades:false,
    },
    Class_CSV_details: {
        CSVDataArray: [],
        downloadCSV: false,
        downloadedcsvdata: false,
    },
    D_TS_School_ListTable: {
        ActualList: [],
        List: [],
        SortedArray: [],
        MinValue: '',
        MaxValue: '',
        Sorting_Column: '',
        Sorting_Type: '',
        ActiveHeaderColumn: 'all',
        List_Includes_NullScores: []
    },
    D_Test_Scores_OverTime: {
        ActualLineChartList: [],
        LineChartList: [],
        SelectedTestData: {},
        Actual_School_LC_List: [],
        School_LC_List: [],
        Actual_District_LC_List: [],
        District_LC_List: [],
        OpenInfoNote: false,
        openInfoTooltip_in_TS: false,
        checkSchool: false,
        checkDistrict: false,
        lastSelectedCheckBox: ''
    },
    D_StandardPerformance_Overview: {
        ActiveToggelIn_SP_Overview: 'schoollist',
        openInfoPopUp_in_P_OT_header: false,
        openInfoTooltip_in_SP: false,
        headerStart: 0,     // start and end has taken As per array index calculation .
        headerEnd: window.screen.width < 1281 ? 4 : 6,
        ActualList: [],
        originalList: [],
        List: [],
        ActualLineChartData: [],
        LineChartData: [],
        SP_StudentsList: [],
        SP_ActualStudentsList: [],
        selectedStrandId: '',
        selectedStandardId: '',
        selectedStandarAvg: '',
        StrandNameOfSelectedStandard: '',
        selectedstandardObject: null,
        MinValue: '',
        MaxValue: '',
        Sorting_Column: '',
        Sorting_Type: '',
        ActiveHeaderColumn: 'all',
        SortedArray_SP_StudentsList: [],
        CompareDataisThere: false,
        checkSchool: false,
        checkDistrict: false,
        lastSelectedCheckBox: '',
        SchoolList_Includes_NullScores: [],
        StrandNameOfSelectedStandard_to_persist: '',
        LineChart_Pagination: {
            Chart_pageAt: CHART_PAGE_AT,
            Chart_TotalBubbles: CHART_TOTAL_BUBBLES,
            Chart_Bubble_Start: CHART_BUBBLE_START,
            Chart_Count_Per_Page: CHART_COUNT_PER_PAGE_FOR_CLASS_TAB,
            Chart_Page_Count_Start: CHART_PAGE_COUNT_START,
            Chart_Page_Count_End: CHART_PAGE_COUNT_END,
        },
        Strands_ToolTipData: {
            xpoint: 0,
            x_coords: 0,
            y_coords: 0,
            tooltipData: null,
            tooltipDisplay: false,
            activatedTickLabelIndex: null,
            popupVisible: false
        },
        StdList_Pagination: {
            pageAt: PaginationFor_Remaining.PageAt,
            totalPagesCount: 0,
            Bubble_Start: 1,
            Countof_Page_StudentsList: PaginationFor_Remaining.CountPerPage,
            countStart: 0,
            countEnd: PaginationFor_Remaining.CountEnd,
        },
        StandardPerformanceFilter: {
            DontCall_standardGradeApi: false,
            DontCall_standardMaxAssessmentCountApi: false,
            NodataInStrands: false,
            TestAssessment: {
                OpenCloseTestAssessment: false,
                selectedTestAssessment: 1,
                MaxTestAssessmentCount: 1
            },
            TestGrade: {
                OpenCloseTestGrade: false,
                selectedTestgrade: null,
                TestGradeList: []
            },
            Taxonomy: {
                OpenCloseTaxonomy: false,
                selectedTaxonomy: '', // null
                taxonomyToPersist: '',
                TaxonomyList: [] // 
            },
            SetValues: []
        }
    },
    D_ToolTipData: {
        xpoint: 0,
        x_coords: 0,
        y_coords: 0,
        tooltipData: null,
        tooltipDisplay: false,
        activatedTickLabelIndex: null,
        popupVisible: false
    },
    D_LineChart_Pagination: {
        Chart_pageAt: CHART_PAGE_AT,
        Chart_TotalBubbles: CHART_TOTAL_BUBBLES,
        Chart_Bubble_Start: CHART_BUBBLE_START,
        Chart_Count_Per_Page: CHART_COUNT_PER_PAGE_FOR_CLASS_TAB,
        Chart_Page_Count_Start: CHART_PAGE_COUNT_START,
        Chart_Page_Count_End: CHART_PAGE_COUNT_END,
    },
    D_Pagination_For_Remaining: {
        pageAt: PaginationFor_Remaining.PageAt,
        totalPagesCount: 0,
        Bubble_Start: 1,
        Countof_Page_StudentsList: PaginationFor_Remaining.CountPerPage,
        countStart: 0,
        countEnd: PaginationFor_Remaining.CountEnd,
    }
};

import { Mathceil } from './UniversalSelectorReducer';
import { GET_INITIAL_APPLICATION_DATA_SUCCESS, APPLY_FILTERS_IN_ROSTER_TAB, SAVE_CONTEXT_SELECTION, RETURN_TO_PREVIOUS_REPORT_UNIVERSAL } from '../Reducer_Action_Types/UniversalSelectorActionTypes';
import { GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD } from '../Reducer_Action_Types/Student_ReportTypes';
import { Sort_ApiResponse_Payload_Array, calculateStrandAvgOnTaxonimy_Filter, sortTaxonomyDataBasedOnUserPrefferences, sortDataBasedOnUserPrefferences } from '../Components/ReusableComponents/AllReusableFunctions';
import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';
import { InDistrictReducer_On_StrandsSelection } from './Report_redux_functions_to_returnState';
import { SET_TOOLTIP_AND_BAR_VALUE_, GET_SCHOOL_STRAND_DETAILS_SUCCESS, GET_CLASS_DETAILS_ON_STRAND_SELECTION_SUCCESS, GET_SELECTED_TS_CLASS_INFO_IN_SCHOOL, CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_SCHOOL_REPORT } from '../Reducer_Action_Types/School_Report_Types';
import {
    District_Action_Types, SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT,
    GET_DISTRICT_STRAND_DETAILS_SUCCESS,
    GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS, GET_DISTRICT_STRANDS_GRADES,
    GET_DISTRICT_STRANDS_GRADES_SUCCESS, SELECTED_TEST_GRADE_DROPDOWN_IN_DISTRICT,
    SELECTED_TEST_ASSESSED_DROPDOWN_IN_DISTRICT, GET_DISTRICT_TS_GRAPH_DETAILS,
    CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_DISTRICT_REPORT,
    GET_SCHOOL_DETAILS_ON_STRAND_SELECTION_SUCCESS, SAVE_SORTED_SCHOOL_DETAILS_LIST,
    OPEN_OR_CLOSE_STRANDS_GRADES_LIST_DISTRICT, MOVE_HEADER_IN_DISTRICT_STRANDS_TABLE,
    OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_DISTRICT, OPEN_OR_CLOSE_STRANDS_QUESTIONS_LIST_DISTRICT, GET_SELECTED_TS_DETAILS, GET_DISTRICT_STRAND_DETAILS, GET_DISTRICT_STRANDS_QUESTION_COUNT_SUCCESS, GET_SELECTED_TS_DETAILS_SUCCESS_IN_DISTRICT, GET_DISTRICT_STRANDS_QUESTION_COUNT
} from '../Reducer_Action_Types/District_Report_Types';
import { Open_Or_Close_Info_POPUP_in_Strands_Compos, ChangeBubbleFor_RemainingPagination_In, CheckIsTestIsExistIn_Current_TestScoreList } from './Reducers_Functions_To_Return_State';
import { Set_ToolTipAnd_BarData_In_School_Report } from './SchoolReportReducer';
import { multiDimensionalUnique_inClass } from './ReportsReducer';
import { multiDimensionalUnique } from './StudentReportReducer';
import { DRILLDOWN_FROM_SCHOOL_DISTRICT, DRILLDOWN_FROM_SUMMARYREPORTS_MODULE } from '../Reducer_Action_Types/summaryReports_Action_Types';

export default (state = INITIAL_STATE, action) => {

    switch (action.type) {

        case GET_INITIAL_APPLICATION_DATA_SUCCESS:

            if ((action.payload.Data == undefined || action.payload.Data == null) || (action.payload.Data && (action.payload.Data.rosterTestVO == null || action.payload.Data.rosterTestVO == undefined))) {
                return {
                    ...state,
                }

            } else if (action.payload.Role !== "DISTRICT_ADMIN" && action.payload.Role !== "SUPER_ADMIN") {

                return {
                    ...state,
                }
            } else if (action.payload.Data.standardPerformanceTab == null ||
                (action.payload.Data.standardPerformanceTab.performanceDetails &&
                    action.payload.Data.standardPerformanceTab.performanceDetails.strands == null)
            ) {
                return {
                    ...state, D_StandardPerformance_Overview: {
                        ...state.D_StandardPerformance_Overview,
                        StandardPerformanceFilter: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                            NodataInStrands: true,
                        }
                    }

                }

            } else {
                let maxTestQuestionCount = action.payload.Data.standardPerformanceTab.maxTestQuestionCount >= 10 ? 10 : action.payload.Data.standardPerformanceTab.maxTestQuestionCount;
                let testGradeList = action.payload.Data.standardPerformanceTab.gardeVOList;
                action.payload.Data.standardPerformanceTab.performanceDetails.strands = Sort_ApiResponse_Payload_Array(action.payload.Data.standardPerformanceTab.performanceDetails.strands, 'strands')
                let TotalBubblesfor_StdListIn_OfStrands = 0;
                let Stads_Std_List = [];
                if (!Disable_AutoSelect_Std_Pref_LeftView) {
                    Stads_Std_List = Sort_ApiResponse_Payload_Array(action.payload.Data.standardPerformanceTab.overTimeTestDetailsList, 'classlistOnStrands');
                    Stads_Std_List = [...Stads_Std_List];
                    Stads_Std_List = Stads_Std_List.filter(item => item.schoolScore !== null);

                    if (Stads_Std_List !== null) {
                        TotalBubblesfor_StdListIn_OfStrands = Mathceil(Stads_Std_List.length, state.D_StandardPerformance_Overview.StdList_Pagination.Countof_Page_StudentsList)
                    }
                }

                let InitialLoadStrandTaxonomyList = { ...action.payload.Data.standardPerformanceTab.performanceDetails };
                let InitialLoadTaxonomyList = []
                let SetValues = [];
                InitialLoadStrandTaxonomyList.strands.map((strand) => {

                    strand.standards.map((initial_single_standard) => {

                        InitialLoadTaxonomyList.push(initial_single_standard.taxonomy)

                        SetValues.push({
                            setId: initial_single_standard.setId,
                            taxonomy: initial_single_standard.taxonomy
                        });
                    })
                })

                InitialLoadTaxonomyList = [...new Set(InitialLoadTaxonomyList)]
                SetValues = multiDimensionalUnique_inClass(SetValues);

                InitialLoadTaxonomyList.sort();
                if (action.payload.Data.preferences !== null && action.payload.Data.preferences != undefined && Object.keys(action.payload.Data.preferences.standardsetorders).length > 0) {

                    InitialLoadTaxonomyList = sortTaxonomyDataBasedOnUserPrefferences(sortDataBasedOnUserPrefferences(action.payload.Data.preferences), SetValues)

                }
                InitialLoadStrandTaxonomyList.strands = InitialLoadStrandTaxonomyList.strands.map((strand) => {
                    return {
                        ...strand,
                        standards: [
                            ...strand.standards.filter((single_taxonomy_standard) => (single_taxonomy_standard.taxonomy == InitialLoadTaxonomyList[0]))
                        ]
                    }
                }).filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

                let InitialSelectedStrand = !Disable_AutoSelect_Std_Pref_LeftView ? InitialLoadStrandTaxonomyList.strands[0] : {
                    strandAvg: '',
                    strandName: '',
                    strandId: ''
                };
                let OrderedGradeList = Sort_ApiResponse_Payload_Array(testGradeList, "grades")
                return {
                    ...state, D_StandardPerformance_Overview: {
                        ...state.D_StandardPerformance_Overview,
                        // ActiveToggelIn_SP_Overview: 'schoollist',
                        SchoolList_Includes_NullScores: [], // [...action.payload.Data.standardPerformanceTab.overTimeTestDetailsList],
                        originalList: action.payload.Data.standardPerformanceTab.performanceDetails,
                        ActualList: InitialLoadStrandTaxonomyList,

                        List: action.payload.Data.standardPerformanceTab.performanceDetails,
                        SP_StudentsList: Stads_Std_List,
                        SP_ActualStudentsList: Stads_Std_List,
                        selectedStandarAvg: InitialSelectedStrand.strandAvg,
                        StrandNameOfSelectedStandard: InitialSelectedStrand.strandName,
                        selectedStrandId: InitialSelectedStrand.strandId,
                        selectedStandardId: "",
                        selectedstandardObject: null,

                        StdList_Pagination: {
                            ...state.D_StandardPerformance_Overview.StdList_Pagination,
                            totalPagesCount: TotalBubblesfor_StdListIn_OfStrands,
                            pageAt: PaginationFor_Remaining.PageAt,
                            Bubble_Start: 1,
                            countStart: 0,
                            countEnd: PaginationFor_Remaining.CountEnd,
                        },

                        StandardPerformanceFilter: {

                            TestAssessment: {
                                ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment,
                                MaxTestAssessmentCount: maxTestQuestionCount
                            },
                            TestGrade: {
                                ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade,
                                TestGradeList: OrderedGradeList,
                                selectedTestgrade: testGradeList[0]
                            }, Taxonomy: {
                                ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy,
                                selectedTaxonomy: InitialLoadTaxonomyList[0],
                                TaxonomyList: InitialLoadTaxonomyList,
                                OpenCloseTaxonomy: false
                            },
                            SetValues: SetValues,
                        }
                    },
                    D_ApiCalls: {
                        ...state.D_ApiCalls,
                        Get_OnlyGraphOnCompareInStrandsComp_Alias: true,
                        loading_on_strands_schools: false,

                        loading_Strands_table: false,
                    },
                }

            }


        case GET_DISTRICT_STRANDS_GRADES:

            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    loading_Strands_table: true,
                    loading_Strand_Grades:true,
                }
            }
        case DRILLDOWN_FROM_SCHOOL_DISTRICT:
        return DRILLDOWN_FROM_SCHOOL_DISTRICT_function(state, action);

        case SAVE_CONTEXT_SELECTION:

            return {
                ...state, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    // ActiveToggelIn_SP_Overview: "schoollist"
                }
            }

        case APPLY_FILTERS_IN_ROSTER_TAB:
            if (action.payload.StateToSet.NavigationByHeaderSelection.Summary_Reports) {
                return {
                    ...state
                }
            }
            return {
                ...state, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    // ActiveToggelIn_SP_Overview: "schoollist"
                }
            }

        /**
         * on success response of grades of strands in school context
         */
        case GET_DISTRICT_STRANDS_GRADES_SUCCESS:

            return {
                ...state,
                D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_Sp_Assessed_Ques: true,
                    loading_Strand_Grades:false,
                },
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        TestGrade: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade,
                            TestGradeList: action.payload.PayloadData,
                            selectedTestgrade: action.payload.ActiveGrade
                        }
                    }
                }
            }

    case GET_DISTRICT_STRANDS_QUESTION_COUNT :
    return {
        ...state,
        D_ApiCalls:{
            ...state.D_ApiCalls,
            get_Sp_Assessed_Ques:false,
            loading_on_Sp_Assessed_Ques:true
        }
    }

        /**
    * on success response of question Count of strands in school context
    */
        case GET_DISTRICT_STRANDS_QUESTION_COUNT_SUCCESS:

            let testAssessmentMaxCount = action.payload.PayloadData > 10 ? 10 : action.payload.PayloadData;

            let QuestionToPersist = action.payload.QuestionToPersist == undefined || testAssessmentMaxCount > (action.payload.QuestionToPersist + 1) ? state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment.selectedTestAssessment :
                action.payload.QuestionToPersist
            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_Sp_Assessed_Ques: false,
                    loading_on_Sp_Assessed_Ques:false
                },
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        TestAssessment: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment,
                            MaxTestAssessmentCount: testAssessmentMaxCount,
                            selectedTestAssessment: QuestionToPersist
                        }
                    }
                }
            }

        /**
         * change state to enable loader before make get strands api call.  
         */
        case GET_DISTRICT_STRAND_DETAILS:

            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    loading_Strands_table: action.payload,
                }, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    // ActiveToggelIn_SP_Overview: "schoollist"
                }
            }


        /**
         * save response of strands list of school 
         */
        case GET_DISTRICT_STRAND_DETAILS_SUCCESS:
            const strandOrignalList = action.payload.Data;
            const UserPreferences = action.payload.UserPreferences
            let StandsList = action.payload.Data;
            let StrandTaxonomyList = [];
            let SetValues = [];
            let { LastNav } = action.payload;

            let { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist } = action.payload.last_active_Taxonomy_And_StrandDetails
            if(!StrandNameToPersist || StrandNameToPersist == "") {
                StrandNameToPersist = state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard_to_persist;
            }
            StandsList.strands.map((strand) => {
                strand.standards.map((single_standard) => {
                    StrandTaxonomyList.push(single_standard.taxonomy);
                    SetValues.push({
                        setId: single_standard.setId,
                        taxonomy: single_standard.taxonomy
                    });
                })
            })
            StrandTaxonomyList = [...new Set(StrandTaxonomyList)]
            SetValues = multiDimensionalUnique(SetValues);
            StrandTaxonomyList.sort();

            if (UserPreferences !== null && UserPreferences != undefined && UserPreferences.standardsetorders.length > 0) {
                StrandTaxonomyList = sortTaxonomyDataBasedOnUserPrefferences(UserPreferences, SetValues)
            }

            StandsList.strands = Sort_ApiResponse_Payload_Array(StandsList.strands, 'strands')
            let TaxonomyExist = last_active_Taxonomy ? StrandTaxonomyList.includes(last_active_Taxonomy) :
                undefined;
            let SelectedTaxonomy = TaxonomyExist ? last_active_Taxonomy : StrandTaxonomyList[0];
            const { DistrictReducer } = action.payload;
            let taxonomyfromSPSummary = DistrictReducer.taxonomyfromSPSummary;
            if(DistrictReducer.SPSummarydrillDown && taxonomyfromSPSummary !="" &&  StrandTaxonomyList.includes(taxonomyfromSPSummary)){
                SelectedTaxonomy = taxonomyfromSPSummary;
            }
            let SelectionBasedTaxonomyList = { ...StandsList };

            SelectionBasedTaxonomyList.strands = SelectionBasedTaxonomyList.strands.map((strand) => {
                return {
                    ...strand,
                    standards: [
                        ...strand.standards.filter((single_taxonomy_standard) => (single_taxonomy_standard.taxonomy == SelectedTaxonomy))
                    ]
                }
            }).filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

            SelectionBasedTaxonomyList = calculateStrandAvgOnTaxonimy_Filter(SelectionBasedTaxonomyList);
            let SummartStrandtoPersist = state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard_to_persist;
            if (SummartStrandtoPersist !== null && SummartStrandtoPersist !== '') {
                SelectedStrand =
                    SelectionBasedTaxonomyList.strands !== undefined || SelectionBasedTaxonomyList.strands !== null ?
                        SelectionBasedTaxonomyList.strands.find(item => item.strandName === SummartStrandtoPersist) : ''
            }

            let SelectedStrand = !Disable_AutoSelect_Std_Pref_LeftView &&
                (SelectionBasedTaxonomyList.strands !== undefined && SelectionBasedTaxonomyList.strands !== null) ?
                SelectionBasedTaxonomyList.strands[0]
                : {
                    strandName: LastNav.district ? state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard : '',
                    strandAvg: LastNav.district ? state.D_StandardPerformance_Overview.selectedStandarAvg : '',
                    strandId: LastNav.district ? state.D_StandardPerformance_Overview.selectedStandardId : ''
                };

            let StrandName = SelectedStrand ? SelectedStrand.strandName : '';
            let StandardId = SelectedStrand ? SelectedStrand.strandId : '';
            let StandardAvg = SelectedStrand ? SelectedStrand.strandAvg : '';
            let StandardsObj = {};
            let GetRightSIdeList = false;


            if (StrandNameToPersist !== '' && StrandNameToPersist !== undefined) {

                let Strand_List = action.payload.Data == null ? [] : StandsList.strands;

                StandardId = StandardIdToPersist;
                StrandName = StrandNameToPersist;
                let StandardIdIsNot_Exist = false;
                let STrandIsNotExist = false;

                if (StandardId !== "") {
                    let selectedstrand = Strand_List.filter(item => item.strandName == StrandName);
                    if (selectedstrand[0] !== undefined) {
                        StandardsObj = selectedstrand[0].standards.find(function (element) {
                            return element.standardId == StandardId;
                        });
                        if (StandardsObj == undefined) {
                            // StandardsObj = {};
                            // StandardAvg = "";
                            // StandardId = "";
                            StandardIdIsNot_Exist = true
                        } else {
                            StandardAvg = StandardsObj.standardAvg;
                        }
                    } else {
                        // StandardsObj = {};
                        // StandardAvg = "";
                        // StandardId = "";
                        STrandIsNotExist = true
                    }
                } else {
                    StandardsObj = {};
                    StandardAvg = "";
                }

                /**
                 *  start , if strand or standard is not there in payload data
                 */

                if (STrandIsNotExist) {
                    StrandName = Strand_List[0].strandName;
                    StandardsObj = {};
                    StandardAvg = "";
                    StandardId = "";
                } else if (StandardIdIsNot_Exist) {
                    StandardsObj = {};
                    StandardAvg = "";
                    StandardId = "";
                }

                /**
                 *  End , if strand or standard is not there in payload data
                 */

            }
      
            return {
                ...state,
                SPSummarydrillDown: false,
                taxonomyfromSPSummary: '',
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    originalList: strandOrignalList,
                    ActualList: SelectionBasedTaxonomyList === null ? [] : SelectionBasedTaxonomyList,
                    List: StandsList === null ? [] : StandsList,
                    // selectedStrandId: StandardId,
                    selectedStandarAvg: StandardAvg,
                    selectedStandardId: StandardId,
                    StrandNameOfSelectedStandard: StrandName,
                    selectedstandardObject: StandardsObj,
                    StrandNameOfSelectedStandard_to_persist: '',
                    headerStart: 0,
                    headerEnd: window.screen.width < 1281 ? 4 : 6,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        NodataInStrands: false,
                        TestGrade: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade,
                            gradefor_last_Active_report: state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade.selectedTestgrade,
                        },
                        Taxonomy: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy,
                            selectedTaxonomy: SelectedTaxonomy,
                            TaxonomyList: StrandTaxonomyList,
                            OpenCloseTaxonomy: false,
                            taxonomyToPersist: '',
                        }
                    }
                }, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_SchoolList_and_Graph_ofStrand: GetRightSIdeList || (StrandName !== '' && StrandName !== null && StrandName !== undefined),
                    loading_Strands_table: false
                },
            }

        /**
 * Action on taxonamy selection : 
 */
        case SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT:

            let TaxonomyRelatedStandardsList = { ...state.D_StandardPerformance_Overview.originalList };

            TaxonomyRelatedStandardsList.strands = TaxonomyRelatedStandardsList.strands.map((strand, strand_index) => {
                return {
                    ...strand,
                    standards: [
                        ...strand.standards.filter((single_taxonomy_standard) => (single_taxonomy_standard.taxonomy == action.payload))
                    ]
                }
                // return strand;
            }).filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

            TaxonomyRelatedStandardsList = calculateStrandAvgOnTaxonimy_Filter(TaxonomyRelatedStandardsList);
            let SelectedStrandBasedTaxonomy = TaxonomyRelatedStandardsList.strands !== undefined && TaxonomyRelatedStandardsList.strands !== null &&
                state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard !== '' && state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard !== null &&
                state.D_StandardPerformance_Overview.StrandNameOfSelectedStandard !== undefined ?
                TaxonomyRelatedStandardsList.strands[0] :
                {
                    strandId: '',
                    strandAvg: '',
                    strandName: ''
                }
            // : ''
            return {
                ...state,
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    ActualList: TaxonomyRelatedStandardsList === null ? [] : TaxonomyRelatedStandardsList,
                    selectedStrandId: '', //SelectedStrandBasedTaxonomy.strandId,
                    selectedStandarAvg: '', // SelectedStrandBasedTaxonomy.strandAvg,
                    selectedStandardId: '',
                    StrandNameOfSelectedStandard: '',  //SelectedStrandBasedTaxonomy.strandName,
                    headerStart: 0,
                    headerEnd: window.screen.width < 1281 ? 4 : 6,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        Taxonomy: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy,
                            selectedTaxonomy: action.payload,
                            OpenCloseTaxonomy: false
                        }
                    }
                }, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_SchoolList_and_Graph_ofStrand: state.D_ApiCalls.get_SchoolList_and_Graph_ofStrand || (SelectedStrandBasedTaxonomy.strandName !== '' && SelectedStrandBasedTaxonomy.strandName !== undefined),
                    loading_Strands_table: false
                },
            }
        /**
         *  change state on header moving in school strands table. 
         * @return {Store} --redux store
         */
        case MOVE_HEADER_IN_DISTRICT_STRANDS_TABLE:

            let Strads_Start = state.D_StandardPerformance_Overview.headerStart;
            let Strads_End = state.D_StandardPerformance_Overview.headerEnd
            if (action.payload == 'right') {
                Strads_Start += 1,
                    Strads_End += 1
            } else if (action.payload == 'left') {
                Strads_Start -= 1,
                    Strads_End -= 1
            }

            return {
                ...state,
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    headerStart: Strads_Start,
                    headerEnd: Strads_End
                }
            }

        /**
         * open or close strands grade drop down in school report instance.
         */
        case OPEN_OR_CLOSE_STRANDS_GRADES_LIST_DISTRICT:

            return {
                ...state,
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        TestGrade: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade,
                            OpenCloseTestGrade: !action.payload
                        }
                    }
                }
            }

        /**
     * open or close TAXONOMY drop down in school report instance.
     */
        case OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_DISTRICT:
            return {
                ...state,
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        Taxonomy: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy,
                            OpenCloseTaxonomy: !action.payload
                        }
                    }
                }
            }

        /**
         * Open or close assessed questions list dropdown view in school reports instance.
         */
        case OPEN_OR_CLOSE_STRANDS_QUESTIONS_LIST_DISTRICT:

            return {
                ...state,
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        TestAssessment: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment,
                            OpenCloseTestAssessment: !action.payload
                        }
                    }
                }
            }

        /**
         * on grade selection in district SP view.
         */
        case SELECTED_TEST_GRADE_DROPDOWN_IN_DISTRICT:

            return {
                ...state,
                D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_Sp_Assessed_Ques: true,
                },
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        TestAssessment: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment,
                            selectedTestAssessment: 1,
                            OpenCloseTestAssessment: false
                        },
                        TestGrade: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade,
                            selectedTestgrade: action.payload,
                            OpenCloseTestGrade: false
                        }
                    }
                }
            }

        /**
         * ON Assesed QUestions Selection in district SP view.
         */
        case SELECTED_TEST_ASSESSED_DROPDOWN_IN_DISTRICT:

            return {
                ...state,
                D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        DontCall_standardMaxAssessmentCountApi: true,
                        TestAssessment: {
                            ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment,
                            selectedTestAssessment: action.payload,
                            OpenCloseTestAssessment: false
                        }
                    }
                }
            }

        /**
         * Disable get class details api call before initiate axios
         */
        case District_Action_Types.GET_SCHOOL_DETAILS_ON_STRAND_SELECTION:

            return {
                ...state, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    selectedStrandId: action.payload.strandId,
                    selectedStandardId: action.payload.standardId,
                    selectedStandarAvg: action.payload.standardAvg,
                    selectedstandardObject: action.payload.standard,
                    StrandNameOfSelectedStandard: action.payload.strandName,
                    // ActiveToggelIn_SP_Overview: 'schoollist',
                },
                D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_SchoolList_and_Graph_ofStrand: false,
                    loading_on_strands_schools: true
                },
            }

        /**
         * on success response of class details on strand selection In School Reporting instance.
         */
        case GET_SCHOOL_DETAILS_ON_STRAND_SELECTION_SUCCESS:
            return School_DetailsOf_aStrand_Success(state, action);

        /**
         * Before Make Api CAll for Line Chart details on strand selection In School Reporting instance.
         */
        case District_Action_Types.GET_LINECHART_DATA_OF_DISTRICT_STRANDS:

            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    loading_on_strands_Lc: action.payload,
                    get_SchoolList_and_Graph_ofStrand: false,
                    Get_OnlyGraphOnCompareInStrandsComp: false,
                    Get_OnlyGraphOnCompareInStrandsComp_Alias: false,
                    get_Graph_ofClassStrand_AferInitialLoad: false,

                }, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    Strands_ToolTipData: {
                        ...state.D_StandardPerformance_Overview.Strands_ToolTipData,
                        activatedTickLabelIndex: null,
                        popupVisible: false,
                        tooltipData: null,
                        tooltipDisplay: false,
                        x_coords: 0,
                        xpoint: 0,
                        y_coords: 0
                    }
                }
            }

        /**
    * on success response of Line Chart details on strand selection In School Reporting instance.
    */
        case District_Action_Types.GET_LINECHART_DATA_OF_DISTRICT_STRANDS_SUCCESS:

            let List = action.payload.PayloadData == null ? [] : action.payload.PayloadData;
            const { persist_compare_checkboxes } = action.payload;
            let LineChart_Data = Sort_ApiResponse_Payload_Array(List, 'linechartlist');

            let PagesgCount = 0;
            if (LineChart_Data !== null) {
                PagesgCount = Mathceil(LineChart_Data.length, STRANS_LINECHART_COUNT_PER_PAGE);
            }

            let PageStartAt_L = PagesgCount > 3 ? PagesgCount - 2 : 1;
            let PageCountEnd_L = PagesgCount * STRANS_LINECHART_COUNT_PER_PAGE;
            let pageCountStart_L = PageCountEnd_L - STRANS_LINECHART_COUNT_PER_PAGE;
            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    loading_on_strands_Lc: false,
                }, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    LineChartData: LineChart_Data,
                    ActualLineChartData: LineChart_Data,
                    CompareDataisThere: true,
                    checkSchool: persist_compare_checkboxes.checkSchool,
                    checkDistrict: persist_compare_checkboxes.checkDistrict,
                    lastSelectedCheckBox: '',
                    LineChart_Pagination: {
                        ...state.D_StandardPerformance_Overview.LineChart_Pagination,
                        Chart_Bubble_Start: PageStartAt_L,
                        Chart_Page_Count_Start: pageCountStart_L,
                        Chart_pageAt: PagesgCount,
                        Chart_Page_Count_End: PageCountEnd_L,
                        Chart_TotalBubbles: PagesgCount
                    }
                }, D_ToolTipData: {
                    xpoint: 0,
                    x_coords: 0,
                    y_coords: 0,
                    tooltipData: List[List.length - 1],
                    // tooltipDisplay: false,
                    activatedTickLabelIndex: null,
                    // popupVisible: false
                },
            }
        case SAVE_SORTED_SCHOOL_DETAILS_LIST:
            return SaveSortedSchoolList(state, action);

        /**
        * When User changes toggle in SP_OVERVIEW_ component of school report we will change the state 
        */
        case CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_DISTRICT_REPORT:
        case CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_SCHOOL_REPORT:
        case CHANGE_TOGGLE_IN_SP_OVERVIEW_COMPONENT:
            let { StrandNameOfSelectedStandard } = state.D_StandardPerformance_Overview;
            action.payload = action.payload == "classlist" || action.payload == "student" ? "schoollist" : action.payload
            return {
                ...state, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    ActiveToggelIn_SP_Overview: action.payload,
                }, D_ApiCalls: StrandNameOfSelectedStandard === "" || StrandNameOfSelectedStandard == undefined ?
                    state.D_ApiCalls
                    : {
                        ...state.D_ApiCalls,
                        Get_OnlyGraphOnCompareInStrandsComp: action.payload == "linechart" ?
                            state.D_ApiCalls.Get_OnlyGraphOnCompareInStrandsComp_Alias : state.D_ApiCalls.
                                Get_OnlyGraphOnCompareInStrandsComp
                    }
            }
        /**
        * to show or hide the tooltip in disctict component
        */
        case District_Action_Types.OPEN_OR_CLOSE_TOOLTIP_IN_D_REPORTS:
            if (action.payload.SelectedNav === "S_performance") {
                return {
                    ...state, D_StandardPerformance_Overview: {
                        ...state.D_StandardPerformance_Overview,
                        openInfoTooltip_in_SP: action.payload.openOrClose,
                    }
                }
            }
            if (action.payload.SelectedNav === "T_Scores") {
                return {
                    ...state, D_Test_Scores_OverTime: {
                        ...state.D_Test_Scores_OverTime,
                        openInfoTooltip_in_TS: action.payload.openOrClose,
                    }
                }
            }
        /**
         * Before initial api call to get testscore graph details.
         */
        case GET_DISTRICT_TS_GRAPH_DETAILS:

            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    getTestScoreGraphDetails: false,
                    loading_on_TS_LC: action.payload
                },
            }

        /**
   * @param {object} action --will save api payload in the reducer to forther use.
   * and will execute some methods to find get paginations info based on payload data count.
   */
        case GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS:
            let TotalBubbles = 0;
            let { TestToPersist } = action.payload;
            let _Arry = Sort_ApiResponse_Payload_Array(JSON.parse(JSON.stringify(action.payload.ResPayload)), 'linechartlist');
            let ListLength;

            if (_Arry !== null) {
                ListLength = _Arry.length;
                TotalBubbles = ListLength !== 0 ? Mathceil(ListLength, CHART_COUNT_PER_PAGE_FOR_CLASS_TAB) : TotalBubbles;
            }
            let PageStartAt = TotalBubbles > 3 ? TotalBubbles - 2 : 1;
            let PageCountEnd = TotalBubbles * CHART_COUNT_PER_PAGE_FOR_CLASS_TAB;
            let pageCountStart = PageCountEnd - CHART_COUNT_PER_PAGE_FOR_CLASS_TAB;
            if (!TestToPersist && !Disable_AutoSelect_TS_Overview_LeftView) {
                TestToPersist = _Arry[_Arry.length - 1]
            }
            return {
                ...state,
                D_Test_Scores_OverTime: {
                    ...state.D_Test_Scores_OverTime,
                    ActualLineChartList: _Arry,
                    LineChartList: _Arry,
                    SelectedTestData: TestToPersist ? TestToPersist : {},
                    checkDistrict: false,
                    checkSchool: false,
                    lastSelectedCheckBox: ""
                },
                D_LineChart_Pagination: {
                    ...state.D_LineChart_Pagination,
                    Chart_pageAt: TotalBubbles,
                    Chart_TotalBubbles: TotalBubbles,
                    Chart_Bubble_Start: PageStartAt,
                    Chart_Count_Per_Page: CHART_COUNT_PER_PAGE_FOR_CLASS_TAB,
                    Chart_Page_Count_Start: pageCountStart,
                    Chart_Page_Count_End: PageCountEnd,
                },
                D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_TS_Details: TestToPersist ? true : false,
                    loading_on_TS_LC: false
                }, D_ToolTipData: {
                    ...state.D_ToolTipData,
                    xpoint: 0,
                    x_coords: 0,
                    y_coords: 0,
                    tooltipData: TestToPersist ? TestToPersist : null,
                    activatedTickLabelIndex: undefined,
                }
            }

        /**
         * Before initiate api call to get class details of selected test score bubble in school
         * TS_OverView report
         */
        case GET_SELECTED_TS_DETAILS:
            return {
                ...state, D_ApiCalls: {
                    ...state.D_ApiCalls,
                    get_TS_Details: false,
                    loading_LC_students: action.payload.enableLoading
                }, D_Test_Scores_OverTime: {
                    ...state.D_Test_Scores_OverTime,
                    SelectedTestData: action.payload.test !== undefined ? action.payload.test : state.Test_Scores_OverTime.SelectedTestData,
                }
            }

        /**
         * Success Response of selected testscore bubble details 
         */
        case GET_SELECTED_TS_DETAILS_SUCCESS_IN_DISTRICT:

            return D_TestScore_DetailsSuccess(state, action);

        case GET_SELECTED_TS_CLASS_INFO_IN_SCHOOL:
            return PersistTestFronSChool_Reports(state, action);

        /**
  * @param {object }  action --will save selected chart circle data.
  */
        case SET_TOOLTIP_AND_BAR_VALUE_:

            return Set_ToolTipAnd_BarData_In_School_Report(state, action, "Dist_Reducer");

        /**
         * close tooltip pop on tooltip outside click.
         */
        case Report_Action_Types.CLOSE_TOOLTIP_VIEW:
            return Close_LC_ToolTip_POPUP(state, action)



        case District_Action_Types.MOVE_LINE_CHART_PAGINATIO_BUBBLE_IN_DIST:

            const CurrentURL_On_CS_Overview = action.payload.Nav.S_performance;

            let b_Start = CurrentURL_On_CS_Overview ? state.D_StandardPerformance_Overview.LineChart_Pagination.Chart_Bubble_Start
                : state.D_LineChart_Pagination.Chart_Bubble_Start;
            if (action.payload.motion == 'left') {
                b_Start = b_Start - 1;
            } else {
                b_Start = b_Start + 1;
            }

            if (CurrentURL_On_CS_Overview) {
                return {
                    ...state, D_StandardPerformance_Overview: {
                        ...state.D_StandardPerformance_Overview,
                        LineChart_Pagination: {
                            ...state.D_StandardPerformance_Overview.LineChart_Pagination,
                            ...state.LineChart_Pagination,
                            Chart_Bubble_Start: b_Start,
                        }
                    }
                }
            } else {
                return {
                    ...state, D_LineChart_Pagination: {
                        ...state.D_LineChart_Pagination,
                        Chart_Bubble_Start: b_Start,
                    }
                }
            }

        /**
         * Change Linechart Pagination Bubble In District Context
         */
        case District_Action_Types.CHANGE_LINE_CHART_PAGINATION_BUBBLE_DIST:

            return ChangeLineChart_PaginationBubble_DIST(state, action);

        /**
         * Store Sorted school list in District
         */
        case District_Action_Types.SAVE_SORTED_SCHOOL_DETAILS_LIST_:

            return save_Sorted_School_List(state, action);

        /**
        * case to change info popup visibility in P_OT graph header.
        */
        case Report_Action_Types.OPEN_OR_CLOSE_P_OT_INFO_POPUP:

            return Open_Or_Close_Info_POPUP_in_Strands_Compos(state, action);


        case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:

            return INITIAL_STATE


        case MOVE_BUBBLES_OF_PAGINATION_FOR_REMAINING:


            if (action.payload.Nav.district) {

                let FromCS_Overview = action.payload.Nav.district && action.payload.Nav.S_performance;

                let RP_b_Start = FromCS_Overview ? state.D_StandardPerformance_Overview.StdList_Pagination.Bubble_Start :
                    state.D_Pagination_For_Remaining.Bubble_Start;
                if (action.payload.motion == 'left') {
                    RP_b_Start = RP_b_Start - 1;
                } else {
                    RP_b_Start = RP_b_Start + 1;
                }

                if (FromCS_Overview) {
                    return {
                        ...state, D_StandardPerformance_Overview: {
                            ...state.D_StandardPerformance_Overview,
                            StdList_Pagination: {
                                ...state.D_StandardPerformance_Overview.StdList_Pagination,
                                Bubble_Start: RP_b_Start,
                            }
                        }
                    }
                } else {
                    return {
                        ...state, D_Pagination_For_Remaining: {
                            ...state.D_Pagination_For_Remaining,
                            Bubble_Start: RP_b_Start,
                        }
                    }
                }
            } else return {
                ...state
            }

        case CHANGE_BUBBLE_OF_PAGINATION_FOR_REMAINIG:

            return ChangeBubbleFor_RemainingPagination_In(state, action, "District_reducer");

        case RETURN_TO_PREVIOUS_REPORT_UNIVERSAL:

            return {
                ...state, D_StandardPerformance_Overview: {
                    ...state.D_StandardPerformance_Overview,
                    StandardPerformanceFilter: {
                        ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                        NodataInStrands: action.payload.SameReportData ? state.D_StandardPerformance_Overview.StandardPerformanceFilter.NodataInStrands : false,
                    }
                }
            }


        case GET_CLASS_DETAILS_ON_STRAND_SELECTION_SUCCESS:

            return InDistrictReducer_On_StrandsSelection(state, action);

        case GET_SCHOOL_STRAND_DETAILS_SUCCESS:

            let sc_Nodata = action.payload.SchoolReports_StateToSet.Sc_StandardPerformance_Overview.StandardPerformanceFilter.NodataInStrands;

            if (sc_Nodata) {
                return {
                    ...state
                }
            }

            return StrandsDetailsPersist_inDist_Reducer(state, action, 'school')

        case GET_STANDARDPERFORMANCE_DETAIL_SUCCESS:
            let CS_Nodata = action.payload.Class_StrandsToSet.StandardPerformance_Overview.StandardPerformanceFilter.NodataInStrands;

            if (CS_Nodata) {
                return {
                    ...state
                }
            }
            return StrandsDetailsPersist_inDist_Reducer(state, action, 'class')


        case GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD:
            let St_Nodata = action.payload.StudentStrandsToSet.S_StandardPerformance_Overview.StandardPerformanceFilter.NodataInStrands;

            if (St_Nodata) {
                return {
                    ...state
                }
            }

            return StrandsDetailsPersist_inDist_Reducer(state, action, 'student')

        case DRILLDOWN_FROM_SUMMARYREPORTS_MODULE:
            const {lazyLoadingScreenInUniversal} = action.payload.universalState;
            return {
                ...state,
                D_StandardPerformance_Overview: action.payload.Nav.district ? action.payload.Reports_State_SP_Overview :
                    state.D_StandardPerformance_Overview
            }

        default:
            return {
                ...state,
            }
    }
};

export function PersistTestFronSChool_Reports(state, action) {

    let D_TestScores = state.D_Test_Scores_OverTime.LineChartList;

    let Function_Response = CheckIsTestIsExistIn_Current_TestScoreList(D_TestScores, state.D_Test_Scores_OverTime.SelectedTestData, action.payload.test)

    let Chart_Bubble_Start = state.D_LineChart_Pagination.Chart_Bubble_Start;
    let Chart_Page_Count_End = state.D_LineChart_Pagination.Chart_Page_Count_End;
    let Chart_Page_Count_Start = state.D_LineChart_Pagination.Chart_Page_Count_Start;
    let Chart_pageAt = state.D_LineChart_Pagination.Chart_pageAt;


    if (Function_Response.Enable_Api_Class && D_TestScores.length !== 0) {


        let Indexis = D_TestScores.findIndex(item => item.componentCode == action.payload.test.componentCode && item.testName == action.payload.test.testName)

        if (Indexis !== -1) {
            Function_Response.Selectedtest = D_TestScores[Indexis]
        };

        Chart_pageAt = Math.ceil((Indexis + 1) / state.D_LineChart_Pagination.Chart_Count_Per_Page);

        Chart_Page_Count_End = Chart_pageAt * state.D_LineChart_Pagination.Chart_Count_Per_Page;

        Chart_Page_Count_Start = Chart_Page_Count_End - state.D_LineChart_Pagination.Chart_Count_Per_Page;


        let diffBetween = state.D_LineChart_Pagination.Chart_TotalBubbles - Chart_pageAt;
        if (diffBetween == 1 || diffBetween == 2) {
            Chart_Bubble_Start = state.D_LineChart_Pagination.Chart_TotalBubbles - 2;
        } else {
            Chart_Bubble_Start = Chart_pageAt;
        }
    }


    return {
        ...state, D_ApiCalls: {
            ...state.D_ApiCalls,
            get_TS_Details: Function_Response.Enable_Api_Class
        }, D_Test_Scores_OverTime: {
            ...state.D_Test_Scores_OverTime,
            SelectedTestData: Function_Response.Selectedtest
        },
        D_ToolTipData: {
            ...state.D_ToolTipData,
            activatedTickLabelIndex: undefined,
            tooltipData: Function_Response.Selectedtest
        },
        D_LineChart_Pagination: {
            ...state.D_LineChart_Pagination,
            Chart_Bubble_Start: Chart_Bubble_Start,
            Chart_Page_Count_End: Chart_Page_Count_End,
            Chart_Page_Count_Start: Chart_Page_Count_Start,
            Chart_pageAt: Chart_pageAt
        }
    }

}

/**
 * 
 * @param {stateObject} state 
 * @param {Object} action 
 * 
 * @returns {stateObject}
 */
function School_DetailsOf_aStrand_Success(state, action) {

    let TotalPages_Chart = 0;

    let Stads_Std_List = JSON.parse(JSON.stringify(action.payload.PayloadData === null ? [] : Sort_ApiResponse_Payload_Array(action.payload.PayloadData, 'school_listOnStrands')));
    Stads_Std_List = Stads_Std_List.filter(item => item.schoolScore !== null);

    if (Stads_Std_List !== null) {
        TotalPages_Chart = Stads_Std_List.length > 0 ?
            Mathceil(Stads_Std_List.length, PaginationFor_Remaining.CountPerPage) : 0
    }

    return {
        ...state, D_StandardPerformance_Overview: {
            ...state.D_StandardPerformance_Overview,
            SP_ActualStudentsList: Stads_Std_List,
            SP_StudentsList: Stads_Std_List,
            SchoolList_Includes_NullScores: action.payload.PayloadData === null ? [] : [...action.payload.PayloadData],
            ActiveHeaderColumn: 'all',
            MinValue: '',
            MaxValue: '',
            Sorting_Column: "",
            Sorting_Type: '',
            StdList_Pagination: {
                ...state.D_StandardPerformance_Overview.StdList_Pagination,
                totalPagesCount: TotalPages_Chart,
                pageAt: 1,
                Bubble_Start: 1,
                countStart: 0,
                countEnd: PaginationFor_Remaining.CountPerPage
            }
        },
        D_ApiCalls: {
            ...state.D_ApiCalls,
            get_TS_Details: false,
            loading_on_strands_schools: false
        },
    }
}

/**
 * 
 * @param {Store} state 
 * @param {Object} action 
 */
function D_TestScore_DetailsSuccess(state, action) {

    let Response = action.payload.PayloadData;

    if (Response == null) {

        return {
            ...state, D_TS_School_ListTable: {
                ...state.D_TS_School_ListTable,
                ActualList: [],
                List: [],
                ActiveHeaderColumn: 'all',
                MinValue: '',
                MaxValue: '',
                Sorting_Column: "",
                Sorting_Type: ''
            }, D_Pagination_For_Remaining: {
                ...state.D_Pagination_For_Remaining,
                totalPagesCount: 0,
                pageAt: 1,
                Bubble_Start: 1,
                countStart: 0,
            },
            D_ApiCalls: {
                ...state.D_ApiCalls,
                get_TS_Details: false,
                loading_LC_students: false
            },
        }
    } else {
        let TotalPages_Chart = 0;
        let TotalPages_stdList = 0;
        let List_Includes_NullItems = action.payload.PayloadData == null ? {} : action.payload.PayloadData;

        let DataPayload = JSON.parse(JSON.stringify(List_Includes_NullItems));

        if (DataPayload.testScoreList !== undefined) {

            DataPayload.testScoreList = DataPayload.testScoreList.filter(item => item.schoolScore !== null)

        }

        if (DataPayload.testScoreList !== null && DataPayload.testScoreList !== undefined) {
            TotalPages_Chart = DataPayload.testScoreList.length > 0 ?
                Mathceil(DataPayload.testScoreList.length, CHART_COUNT_PER_PAGE_FOR_CLASS_TAB) : 0
        }

        DataPayload.testScoreList = Sort_ApiResponse_Payload_Array(DataPayload.testScoreList, 'school_listOnTS')

        let SchoolTestScoreList = DataPayload.testScoreList;
        if (SchoolTestScoreList !== null) {
            TotalPages_stdList = SchoolTestScoreList.length > 0 ?
                Mathceil(SchoolTestScoreList.length, state.D_Pagination_For_Remaining.Countof_Page_StudentsList) : 0
        }
        return {
            ...state,
            D_TS_School_ListTable: {
                ...state.D_TS_School_ListTable,
                List_Includes_NullScores: List_Includes_NullItems,
                ActualList: DataPayload === null ? [] : DataPayload,
                List: DataPayload === null ? [] : DataPayload,
                ActiveHeaderColumn: 'all',
                MinValue: '',
                MaxValue: '',
                Sorting_Column: "",
                Sorting_Type: ''
            }, D_Pagination_For_Remaining: {
                ...state.D_Pagination_For_Remaining,
                totalPagesCount: TotalPages_stdList,
                pageAt: 1,
                Bubble_Start: 1,
                countStart: 0,
                countEnd: PaginationFor_Remaining.CountEnd
            },
            D_ApiCalls: {
                ...state.D_ApiCalls,
                get_TS_Details: false,
                loading_LC_students: false
            },
        }
    }
}

function Close_LC_ToolTip_POPUP(state, action) {
    if (action.payload.S_performance && action.payload.district) {
        return {
            ...state, D_StandardPerformance_Overview: {
                ...state.D_StandardPerformance_Overview,
                Strands_ToolTipData: {
                    ...state.D_StandardPerformance_Overview.Strands_ToolTipData,
                    xpoint: 0,
                    x_coords: 0,
                    y_coords: 0,
                    tooltipData: null,
                    tooltipDisplay: false,
                    activatedTickLabelIndex: null,
                    popupVisible: false
                },
            }
        }
    } else if (action.payload.S_performance && action.payload.district) {
        return {
            ...state, D_ToolTipData: {
                ...state.D_ToolTipData,
                tooltipDisplay: false,
            }
        }
    } else {
        return {
            ...state
        }
    }
}

function SaveSortedSchoolList(state, action) {


    let Nav_In_Sort_Std = action.payload.CurrentNav
    if (Nav_In_Sort_Std.S_performance) {
        return {
            ...state, D_StandardPerformance_Overview: {
                ...state.D_StandardPerformance_Overview,
                SP_StudentsList: action.payload.SortedArray,
                Sorting_Column: action.payload.Column,
                Sorting_Type: action.payload.SortType
            }
        }
    } else {
        let ListIs = state.D_TS_School_ListTable.List;
        if (action.payload.SortedArray.testScoreList == undefined) {
            ListIs.testScoreList = action.payload.SortedArray;
        } else {
            ListIs = action.payload.SortedArray;
        }

        return {
            ...state, D_TS_School_ListTable: {
                ...state.D_TS_School_ListTable,
                List: ListIs,
                Sorting_Column: action.payload.Column,
                Sorting_Type: action.payload.SortType
            }
        }

    }
}
/**
 * 
 * @param {Store} state 
 * @param {Object} action
 * @returns {state} 
 */
function ChangeLineChart_PaginationBubble_DIST(state, action) {


    let Page_At = action.payload.positionfrom_BubbleStart + action.payload.Chart_Bubble_Start;
    let start;
    let end;
    let Page_Count = action.payload.Nav.S_performance ?
        state.D_StandardPerformance_Overview.LineChart_Pagination.Chart_Count_Per_Page :
        state.D_LineChart_Pagination.Chart_Count_Per_Page;

    start = (Page_At * Page_Count) - Page_Count;
    end = Page_At * Page_Count;


    if (action.payload.Nav.S_performance) {
        return {
            ...state, D_StandardPerformance_Overview: {
                ...state.D_StandardPerformance_Overview,
                LineChart_Pagination: {
                    ...state.D_StandardPerformance_Overview.LineChart_Pagination,
                    Chart_pageAt: Page_At,
                    Chart_Page_Count_Start: start,
                    Chart_Page_Count_End: end,
                },
            },
            D_ToolTipData: {
                ...state.D_ToolTipData,
                activatedTickLabelIndex: undefined,
                popupVisible: false,

            }
        }
    } else {
        return {
            ...state,
            D_LineChart_Pagination: {
                ...state.D_LineChart_Pagination,
                Chart_pageAt: Page_At,
                Chart_Page_Count_Start: start,
                Chart_Page_Count_End: end,
            },
            D_ToolTipData: {
                ...state.D_ToolTipData,
                activatedTickLabelIndex: undefined,
                popupVisible: false,

            }
        }
    }
}


/**
 * 
 * @param {Store} state 
 * @param {Object} action 
 */

function save_Sorted_School_List(state, action) {

    let SortedTotalPages = 0;
    if (action.payload.Navigation.S_performance) {

        if (action.payload.SortedArray !== null) {
            SortedTotalPages = action.payload.SortedArray.length > 0 ? Mathceil(action.payload.SortedArray.length, PaginationFor_Remaining.CountPerPage) : 0
        }

        return {
            ...state,
            D_StandardPerformance_Overview: {
                ...state.D_StandardPerformance_Overview,
                SP_StudentsList: action.payload.SortedArray,
                SortedArray_SP_StudentsList: action.payload.SortedArray,
                MinValue: action.payload.minValue,
                MaxValue: action.payload.maxValue,
                Sorting_Column: action.payload.maxValue == 100 ? '' : state.D_StandardPerformance_Overview.Sorting_Column,
                Sorting_Type: action.payload.maxValue == 100 ? '' : state.D_StandardPerformance_Overview.Sorting_Type,
                ActiveHeaderColumn: action.payload.ActiveColumn,
                StdList_Pagination: {
                    ...state.D_StandardPerformance_Overview.StdList_Pagination,
                    totalPagesCount: SortedTotalPages,
                    pageAt: 1,
                    countStart: 0,
                    Bubble_Start: 1,
                    countEnd: PaginationFor_Remaining.CountPerPage,
                }
            }
        }

    } else {

        if (action.payload !== null) {
            let List = action.payload.SortedArray.testScoreList;
            SortedTotalPages = List.length > 0 ? Mathceil(List.length, PaginationFor_Remaining.CountPerPage) : 0
        }

        return {
            ...state,
            D_TS_School_ListTable: {
                ...state.D_TS_School_ListTable,
                List: action.payload.SortedArray,
                SortedArray: action.payload.SortedArray,
                MinValue: action.payload.minValue,
                MaxValue: action.payload.maxValue,
                Sorting_Column: action.payload.maxValue == 100 ? '' : state.D_TS_School_ListTable.Sorting_Column,
                Sorting_Type: action.payload.maxValue == 100 ? '' : state.D_TS_School_ListTable.Sorting_Type,
                ActiveHeaderColumn: action.payload.ActiveColumn,
            }, D_Pagination_For_Remaining: {
                ...state.D_Pagination_For_Remaining,
                totalPagesCount: SortedTotalPages,
                pageAt: 1,
                countStart: 0,
                Bubble_Start: 1,
                countEnd: PaginationFor_Remaining.CountPerPage,
            }
        }
    }
}


export function StrandsDetailsPersist_inDist_Reducer(state, action, fromContext) {

    let Strands = fromContext == 'school' ?
        action.payload.SchoolReports_StateToSet.Sc_StandardPerformance_Overview.StandardPerformanceFilter :
        fromContext == 'class' ? action.payload.Class_StrandsToSet.StandardPerformance_Overview.StandardPerformanceFilter :
            action.payload.StudentStrandsToSet.S_StandardPerformance_Overview.StandardPerformanceFilter;

    return {
        ...state, D_StandardPerformance_Overview: {
            ...state.D_StandardPerformance_Overview,
            StandardPerformanceFilter: {
                ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                Taxonomy: {
                    ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy,
                    selectedTaxonomy: Strands.Taxonomy.selectedTaxonomy

                }, TestAssessment: {
                    ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestAssessment,
                    selectedTestAssessment: Strands.TestAssessment.selectedTestAssessment
                }, TestGrade: {
                    ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.TestGrade,
                    selectedTestgrade: Strands.TestGrade.selectedTestgrade
                }
            }
        }, D_ApiCalls: {
            ...state.D_ApiCalls,
            get_Sp_Assessed_Ques: action.payload.D_Asse_Ques_Api ? true :
                state.D_ApiCalls.get_Sp_Assessed_Ques,
        }

    }

}
export function DRILLDOWN_FROM_SCHOOL_DISTRICT_function(state, action) {
    const { selectedTaxonomy,universalState,issameGrade } = action.payload;
    const findTaxonomyList = [...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy.TaxonomyList];
    const TaxonomyExist= findTaxonomyList.includes(selectedTaxonomy);
       let SPSummarydrillDown = true;
        if(issameGrade){
            SPSummarydrillDown = !issameGrade;
        }
        let isDistrictDrillDown = universalState.NavigationByHeaderSelection.district;
        if(SPSummarydrillDown && isDistrictDrillDown){
    return {
        ...state,
        SPSummarydrillDown:  SPSummarydrillDown,
        taxonomyfromSPSummary: SPSummarydrillDown?selectedTaxonomy:'',
        D_StandardPerformance_Overview: {
            ...state.D_StandardPerformance_Overview,
            StandardPerformanceFilter: {
                ...state.D_StandardPerformance_Overview.StandardPerformanceFilter,
                Taxonomy: {
                    ...state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy,
                    selectedTaxonomy: issameGrade && TaxonomyExist && selectedTaxonomy ? selectedTaxonomy : state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy.selectedTaxonomy,
                    taxonomyToPersist:  selectedTaxonomy ? selectedTaxonomy : state.D_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy.selectedTaxonomy,
                }
            }
        }
    }
}
else{
    return {
        ...state
    }
}
}