import { Class_RB_Types } from '../Reducer_Action_Types/Class_RB_Action_Types';
import { dataSorting, constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

export const INITIAL_STATE = {
  isApiLoading: true,
  timeout: false,
  apiLoadFail: false,
  noData: false,
  chartData: null,
  sidePanelData: null,
  sidePanelApiFailed: false,
  SortData: {
    sortColumn: 'date',
    sortType: 'desc'
  },
  selectedBoxes: {},
  accordionsState: {},
  hideCreateGroup: false,
  ClassCsvDownload: { csvData: null, downloadInProgress: false }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case Class_RB_Types.API_LOADER:
      return {
        ...state,
        isApiLoading: true,
        timeout: false,
        apiLoadFail: false,
        noData: false,
        hideCreateGroup: false,
      };
    case Class_RB_Types.UPDATE_SELECTED_BOXES:
      return {
        ...state,
        ['selectedBoxes']: action.payload,
        sidePanelData: null,
        sidePanelApiFailed: false,
        hideCreateGroup: true
      };
    case Class_RB_Types.SIDE_PANEL_API_FAIL:
      return {
        ...state,
        sidePanelData: null,
        sidePanelApiFailed: true,
        hideCreateGroup: true,
      };
    case Class_RB_Types.UPDATE_ACCORDION_STATE:
      return {
        ...state,
        accordionsState: action.payload
      };
    case Class_RB_Types.CRB_CHART_API_SUCCESS:
      return {
        ...state,
        ['chartData']: action.payload['responseData'],
        ['selectedBoxes']: {},
        accordionsState: getAccordionsState(action.payload['responseData']),
        isApiLoading: false,
        apiLoadFail: false,
        apiTimeOut: false,
        noChartData: false,
        rubricDataMsg: null,
        hideCreateGroup: true,
        ClassCsvDownload: { csvData: null, downloadInProgress: false }
      };
    case Class_RB_Types.C_RB_RUBRIC_FAIL:
      return {
        ...state,
        rubricDataMsg: action.payload,
        isApiLoading: false,
        apiLoadFail: false,
        apiTimeOut: false,
        noChartData: false,
        chartData: null,
        sidePanelData: null,
        hideCreateGroup: false,

      }
    case Class_RB_Types.CRB_SIDEPANEL_API_SUCCESS:
      return {
        ...state,
        ['sidePanelData']: action.payload,
        sidePanelApiFailed: false,
        hideCreateGroup: false,
      };
    case Class_RB_Types.API_ERROR_HANDLER:
      return {
        ...state,
        ['chartData']: null,
        sidePanelData: null,
        ...action.payload
      };

    case Class_RB_Types.SORTED_SIDEPANEL_DATA:
      return {
        ...state,
        ['sidePanelData']: action.paylod
      };
    case Class_RB_Types.CLASS_RB_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        },
        disableDiv: false
      };
    case Class_RB_Types.CRB_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // ClassCsvDownload: action.payLoad
        ClassCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case Class_RB_Types.CRB_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        ClassCsvDownload: action.payLoad
      };

    default:
      return {
        ...state
      };
  }
};



function getAccordionsState(data) {
  let accordState = {}
  if (data && data.length > 0) {
    data.forEach((obj, index) => {
      if (index == data.length - 1) {
        accordState[index] = true;
      } else {
        accordState[index] = false;
      }

    })
  }
  return accordState;
}
