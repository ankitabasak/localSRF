import { C_ReadingLevelTypes } from "../Reducer_Action_Types/C_ReadingLevelTypes.jsx";
import { getConstructedData, getRecentMonthData } from "../Components/Class_ORR/ChartComponents/Class_RLP_data_construction.js";
import { constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

export const INITIAL_STATE = {
  Class_RLP_Object: null,
  sum_crlp_Object: null,
  isApiLoading: true,
  apiLoadFail: false,
  sidePanelApiFail: false,
  sidePanelLoad: true,
  RlpGridData: {
    RlpData: null,
    GridFilterData: [],
    isTarget: false,
    RosterCount: ""
  },
  SortData: {
    sortColumn: 'assignmentDate',
    sortType: 'desc'
  },
  isAchieved: {},
  DonutData: [],
  selectedBubbles: {},
  DonutFlag: {
    isAchievedFlag: null,
    isNotAchievedFlag: null
  },
  hideCreateGroup: false,
  toggleData: false,
  ClassCsvDownload: { csvData: null, downloadInProgress: false }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case C_ReadingLevelTypes.CLASS_READING_LEVEL_GRID_DATA_SUCCESS:
      return {
        ...state,
        RlpGridData: {
          RlpData: action.payload.classReadingLevelProgressSidePanelData,
          GridFilterData: action.payload.sidePanelFilter.readingLevelList,
          isTarget: false,
          RosterCount: action.payload.noOfStudentsRoastered
        },
        SortData: {
          sortColumn: "assignmentDate",
          sortType: "desc"
        },
        PieChartData: {
          chartData: {
            achievedTargetValue: "",
            notAchievedValue: ""
          }
        },
        DonutFlag: {
          isAchievedFlag: null,
          isNotAchievedFlag: null
        },
        hideCreateGroup: false,
        sidePanelLoad: false
      };
    case C_ReadingLevelTypes.C_RLP_GRID_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case C_ReadingLevelTypes.CLASS_RLP_SPINNER_RESET:
      return {
        ...state,
        sidePanelLoad: true
      };
    case C_ReadingLevelTypes.CLASS_RLP_GRID_API_FAIL:
      return {
        ...state,
        sidePanelApiFail: false,
        sidePanelLoad: true,
        hideCreateGroup: true,
        RlpGridData: {
          RlpData: null,
          GridFilterData: [],
          isTarget: false,
          RosterCount: ""
        }
      };
    case C_ReadingLevelTypes.CHART_SPINNER_RESET:
      return {
        ...state,
        isApiLoading: true,
        apiLoadFail: false,
        sidePanelLoad: true,
        hideCreateGroup: false,
        RlpGridData: {
          ...state.RlpGridData,
          RlpData: null
        }
      };

    case C_ReadingLevelTypes.RETAIN_BUBBLE_COLOR:
      return {
        ...state,
        selectedBubbles: action.payload,
        hideCreateGroup: true

      };
    case C_ReadingLevelTypes.CLEAR_BUBBLE_COLOR:
      return {
        ...state,
        selectedBubbles: action.payload,
        hideCreateGroup: false
      };
    case C_ReadingLevelTypes.SAVE_SORTED_RLP_DATA:
      return {
        ...state,
        RlpGridData: {
          ...state.RlpGridData,
          RlpData: action.payload.SortedArray
        }
      };
    case C_ReadingLevelTypes.RLP_TARGET_DATA:
      return {
        ...state,
        RlpGridData: {
          ...state.RlpGridData,
          RlpData: action.payload.classRPLRtSidePanelGridData,
          isTarget: true,
          RosterCount: action.payload.noOfStudentsRoastered
        },
        SortData: {
          sortColumn: "",
          sortType: ""
        },
        PieChartData: {
          chartData: action.payload.classRPLRtSidePanelDonutChartData
        },
        isAchieved: achievedData(action.payload.classRPLRtSidePanelGridData),
        DonutData: action.payload.classRPLRtSidePanelGridData,
        hideCreateGroup: false
      };
    case C_ReadingLevelTypes.ACHIEVED_DATA:
      return {
        ...state,
        RlpGridData: {
          ...state.RlpGridData,
          ["RlpData"]: state["isAchieved"]["achievedArray"]
        },
        DonutFlag: {
          isAchievedFlag: true,
          isNotAchievedFlag: false
        },
        SortData: {
          sortColumn: "assignmentDate",
          sortType: "desc"
        }
      };
    case C_ReadingLevelTypes.NOT_ACHIEVED_DATA:
      return {
        ...state,
        RlpGridData: {
          ...state.RlpGridData,
          ["RlpData"]: state["isAchieved"]["notAchievedArray"]
        },
        DonutFlag: {
          isAchievedFlag: false,
          isNotAchievedFlag: true
        },
        SortData: {
          sortColumn: "",
          sortType: ""
        }
      };
    case C_ReadingLevelTypes.DEFAULT_DATA:
      return {
        ...state,
        RlpGridData: {
          ...state.RlpGridData,
          ["RlpData"]: state["DonutData"]
        },
        DonutFlag: {
          isAchievedFlag: null,
          isNotAchievedFlag: null
        },
        SortData: {
          sortColumn: "",
          sortType: ""
        }
      };
    case C_ReadingLevelTypes.CLASS_READING_LEVEL_PROGRESS:
      return {
        ...state,
        Response: action.payload.SUCCESSFULL,
        Class_RLP_Object: getConstructedData(action.payload.responseData, 5),
        sum_crlp_Object: getConstructedData(action.payload.responseData, 3),
        selectedBubbles: {},
        isApiLoading: false,
        apiLoadFail: false,
        hideCreateGroup: true,
        monthRangeObj: monthDataConstruction(action.payload.responseData.monthRangeAxis),
        selAll: action.payload.responseData.monthRangeAxis ? true : false,
        ClassCsvDownload: { csvData: null, downloadInProgress: false },
        toggleData: false
      };
    case C_ReadingLevelTypes.UPDATE_DROP_DOWN_DATA:
      return {
        ...state,
        ...getSelectedGrade(action.payLoad, state.monthRangeObj)
      }
    case C_ReadingLevelTypes.UPDATE_ALL_DATA:
      return {
        ...state,
        ...updateSelAll(action.payLoad.selAll, state.monthRangeObj)
      }
    case C_ReadingLevelTypes.UPDATE_TOGGLE:
      return {
        ...state,
        toggleData: action.payLoad.toggleData,
        ...updateAll(state.selAll, state.monthRangeObj)
      }
    case C_ReadingLevelTypes.UPDATE_CHART_DATA:
      ;
      return {
        ...state,
        Class_RLP_Object: getChartData(action.payLoad, state.Class_RLP_Object),
      }
    case C_ReadingLevelTypes.CLASS_RLP_DATA_FAIL:
      return {
        ...state,
        ["Class_RLP_Object"]: action.payload,
        ["sum_crlp_Object"]: action.payload,
        apiLoadFail: true,
        isApiLoading: false,
        hideCreateGroup: true
      };
    case C_ReadingLevelTypes.UPDATE_CHART_SCROLL_DATA:
      return {
        ...state,
        ["Class_RLP_Object"]: action.payload.class_rlp_object
      };
    case C_ReadingLevelTypes.SUM_CHART_SCROLL_DATA:
      return {
        ...state,
        ["sum_crlp_Object"]: action.payload.sum_crlp_Object
      };
    case C_ReadingLevelTypes.CLRLP_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // ClassCsvDownload: action.payLoad
        ClassCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case C_ReadingLevelTypes.CLRLP_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        ClassCsvDownload: action.payLoad
      };
    default:
      return {
        ...state
      };
  }
};

function achievedData(data) {
  let achievedArray = [];
  let notAchievedArray = [];
  data.map((d, value) =>
    d.isAchieved !== "N" ? achievedArray.push(d) : notAchievedArray.push(d)
  );
  return { achievedArray: achievedArray, notAchievedArray: notAchievedArray };
}

function monthDataConstruction(monthList) {
  let monthObj = monthList.map((month, idx) => {
    return { monthName: month, index: idx, checked: true }
  })
  return monthObj
}



function getSelectedGrade(monthObj, monthRange) {
  let monthCount = 0;
  let selAll;
  monthRange[monthObj['index']] = monthObj;
  monthRange.forEach((item, index) => {
    if (item.checked) {
      monthCount++;
    }
  })
  if (monthCount === 0) {
    monthRange.forEach((item, index) => {
      if (!item.checked) {
        monthRange[index].checked = !monthRange[index].checked
      }
    })
  }
  if (monthCount === monthRange.length || monthCount === 0) {
    selAll = true;
  } else {
    selAll = false;
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function updateSelAll(selAll, monthRange) {

  if (selAll) {
    monthRange.forEach((item, index) => {
      monthRange[index].checked = true
    })
  } else {
    monthRange.forEach((item, index) => {
      monthRange[index].checked = false
    })
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function updateAll(selAll, monthRange) {
  let monthCount = 0;

  if (!selAll) {
    monthRange.forEach((item, index) => {
      if (item.checked) {
        monthCount++;
      }
    })
    if (monthCount === 0) {
      monthRange.forEach((item, index) => {
        if (!item.checked) {
          monthRange[index].checked = !monthRange[index].checked;
          selAll = true
        }
      })
    }
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function getChartData(monthRange, crlpObj) {
  let newObj = [];
  monthRange.forEach((item, index) => {
    if (item.checked) {
      newObj.push(crlpObj.allRecordData[index])
    }
  })

  return {
    ...crlpObj,
    monthlyRecordData: newObj,
    xAxisScrollIndex: newObj.length - crlpObj.columnToDisp + 1,
    recentMonthlyRecords: getRecentMonthData(newObj, crlpObj.columnToDisp)
  };
}