import districtFAReducer from './District_FA_Reducer'

describe('districtFAReducer', () => {
    it('default matches', () => {
      expect(districtFAReducer(undefined, {})).toMatchSnapshot();
    });

    it('test DISTRICT_FA_CHART_API_CALL_SUCCESS', () => {
      expect(districtFAReducer(undefined, {
        type: 'DISTRICT_FA_CHART_API_CALL_SUCCESS',
        payload: {
          responseData: 'test response',
          schoolLevelGrade: 'test grade'
      },
      })).toMatchSnapshot();
    });
});
