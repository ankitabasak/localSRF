import { District_ReadingHistoryTypes } from '../Reducer_Action_Types/District_ReadingHistoryTypes.jsx';
import { dataSorting, constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';
const INITIAL_STATE = {
  districtReadingHistoryDetails: {
    data: null,
    isApiLoading: true,
    isDataNotAvailable: false,
    chartLoadFail: false,
    timeOut: false
  },
  Response: '',
  SortData: {
    sortColumn: 'lastName',
    sortType: 'asc'
  },
  modifiedArray: {},
  DstCsvDownload: { csvData: null, downloadInProgress: false }
};

let drhoData = {};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case District_ReadingHistoryTypes.DISTRICT_READING_HISTORY_DATA_SUCCESS:

      return {
        ...state,
        districtReadingHistoryDetails: {
          data: action.payload.districtReadingHistoryData !== null && sortDataFn(
            'lastName',
            'asc',
            action.payload.districtReadingHistoryData,
            'className'
          ),
          isApiLoading: false,
          timeOut: false,
          chartLoadFail: false,
          isDataNotAvailable:
            (action.payload.districtReadingHistoryData && action.payload.districtReadingHistoryData.length > 0) ||
              action.payload.districtReadingHistoryData !== null ? false : true,
          ['showAccordion']: toShowFirstAccordion(
            action.payload.districtReadingHistoryData
          )
          // ['showAccordion']: false
        },
        Response: action.payload.SUCCESSFULL,
        SortData: {
          sortColumn: 'lastName',
          sortType: 'asc'
        },
        DstCsvDownload: { csvData: null, downloadInProgress: false }
      };
    case District_ReadingHistoryTypes.DISTRICT_READING_HISTORY_DATA_FAIL:
      return {
        ...state,
        districtReadingHistoryDetails: {
          data: null,
          isApiLoading: false,
          isDataNotAvailable: false,
          chartLoadFail: true,
          timeOut: false
        },
        Response: action.payload
      };

    case District_ReadingHistoryTypes.DISTRICT_RHO_SCHOOL_NAMES_SUCCESS:

      drhoData = action.payload.districtReadingHistoryData;
      let rhoSchoolNamesData = {
        ...state,
        districtReadingHistoryDetails: {
          data: action.payload.districtReadingHistoryData !== null && sortDataFn(
            'lastName',
            'asc',
            action.payload.districtReadingHistoryData,
            'className'
          ),
          isApiLoading: false,
          timeOut: false,
          chartLoadFail: false,
          isDataNotAvailable:
            (action.payload.districtReadingHistoryData && action.payload.districtReadingHistoryData.length > 0) ||
            action.payload.districtReadingHistoryData !== null ? false : true,
          ['showAccordion']: toShowFirstAccordion(
            action.payload.districtReadingHistoryData
          )
          // ['showAccordion']: false
        },
        Response: action.payload.SUCCESSFULL,
        SortData: {
          sortColumn: 'lastName',
          sortType: 'asc'
        },
        DstCsvDownload: { csvData: null, downloadInProgress: false }
      };

      return rhoSchoolNamesData;

    case District_ReadingHistoryTypes.DISTRICT_RHO_SCHOOL_NAMES_FAIL:
      return {
        ...state,
        districtReadingHistoryDetails: {
          data: null,
          isApiLoading: false,
          isDataNotAvailable: false,
          chartLoadFail: true,
          timeOut: false
        },
        Response: action.payload
      };

    case District_ReadingHistoryTypes.DISTRICT_RHO_SINGLE_SCHOOL_SUCCESS:

      console.log("drho action= ", action);
      console.log("this state = ", state);

      let newDRHDetails = {
              ...state.districtReadingHistoryDetails,
              data: drhoData !== null && sortDataFn(
                        'lastName',
                        'asc',
                        drhoData,
                        'className'
                      ),

                      isApiLoading: false,
                      timeOut: false,
                      chartLoadFail: false,
                      isDataNotAvailable: false,
                    };

      if(newDRHDetails != null && newDRHDetails.data != null &&
          action.payload.schoolReadingHistoryData != null) {


      // find choosen class and place student details
      newDRHDetails.data.forEach(schoolDetail => {
        schoolDetail.classesDetails.forEach(classDetail => {
          action.payload.schoolReadingHistoryData.forEach(srhData => {
            if(classDetail.classId == srhData.classId) {
              classDetail.studentDetails = srhData.studentDetails;
              // need to break out of loop
            }
          });
        });
      });
      }

      console.log("newDRHDetails=", newDRHDetails);

      let drhoSingleSchoolData = {
        ...state,
        districtReadingHistoryDetails: newDRHDetails,
        Response: action.payload.SUCCESSFULL,
        SortData: {
          sortColumn: 'lastName',
          sortType: 'asc'
        },
        DstCsvDownload: { csvData: null, downloadInProgress: false }
      };

      return drhoSingleSchoolData;

    case District_ReadingHistoryTypes.DISTRICT_RHO_SINGLE_SCHOOL_FAIL:
      return {
        ...state,
        districtReadingHistoryDetails: {
          data: null,
          isApiLoading: false,
          isDataNotAvailable: false,
          chartLoadFail: true,
          timeOut: false
        },
        Response: action.payload
      };
    case District_ReadingHistoryTypes.DRH_ERROR_HANDLING:
      return {
        ...state,
        districtReadingHistoryDetails: {
          ...state.districtReadingHistoryDetails,
          data: null,
          ...action.payload
        }
      };
    case District_ReadingHistoryTypes.DISTRICT_READING_HISTORY_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case District_ReadingHistoryTypes.DISTRICT_SAVE_SORTED_DISTRICT_READING_HISTORY_DATA:
      return {
        ...state,
        districtReadingHistoryDetails: {
          data: action.payload.SortedArray
        }
      };
    case District_ReadingHistoryTypes.DISTRICT_RHO_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case District_ReadingHistoryTypes.DISTRICT_RHO_SAVE_SORT_ARRAY:
      return {
        ...state,
        modifiedArray: action.payload.SortedArray
      };
    case District_ReadingHistoryTypes.DISTRICT_CLASS_NAME:
      return {
        ...state,
        districtReadingHistoryDetails: {
          ...state.districtReadingHistoryDetails,
          ['showAccordion']: action.payload
        }
      };
    case District_ReadingHistoryTypes.DSTRHO_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // DstCsvDownload: action.payLoad
        DstCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case District_ReadingHistoryTypes.DSTRHO_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        DstCsvDownload: action.payLoad
      };
    default:
      return { ...state };
  }
};

//to show  the first accordion open
function toShowFirstAccordion(sideTableData) {
  let tempObj = {};
  sortSchoolData('schoolName', sideTableData);
  sideTableData &&
    sideTableData.forEach((obj, index) => {
      if (index === 0) {
        tempObj[obj.schoolName] = true;
      } else {
        tempObj[obj.schoolName] = false;
      }
    });
  return tempObj;
}

//to sort table data by school name
function sortSchoolData(column, sideTableData) {
  if (sideTableData !== null) {
    let sortedData = sideTableData.sort(function (a, b) {
      let firstElement =
        column !== 'schoolName' ? a[column] : a[column].toString().toUpperCase();
      let secondElement =
        column !== 'schoolName' ? b[column] : b[column].toString().toUpperCase();

      let com = 0;
      if (firstElement > secondElement) {
        com = 1;
      } else if (firstElement < secondElement) {
        com = -1;
      }

      return com;
    });
    return sortedData;
  }
}

//function to sort array of data
function sortDataFn(column, sortType, stdArray, classCol) {
  let sortedArray = [];
  let classSorted = [];
  stdArray.map((externalArray) => {
    classSorted = dataSorting(externalArray.classesDetails, classCol, sortType);
    externalArray.classesDetails.map((actualArray) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(actualArray.studentDetails, column, sortType);
      }
    });
  })
  return stdArray;
}
