import cFluencyReducer from './C_FluencyReducer'

describe('cFluencyReducer', () => {
    it('default matches', () => {
      expect(cFluencyReducer(undefined, {})).toMatchSnapshot();
    });

    it('test C_FPO_API_SUCCESS', () => {
      expect(cFluencyReducer(undefined, {
        type: 'C_FPO_API_SUCCESS',
      })).toMatchSnapshot();
    });

    it('test CF_CHART_DATA_SUCCESS', () => {
        expect(cFluencyReducer(undefined, {
            type: 'CF_CHART_DATA_SUCCESS',
        })).toMatchSnapshot();
    });
});