import { DistrictFAType } from "../Reducer_Action_Types/District_FA_Types.jsx";
import { dataSorting, constructCsvData } from "../Components/ReusableComponents/OrrReusableComponents";

export const INITIAL_STATE = {
  ScFTabSelection: {
    wcpm: false,
    fpot: true
  },
  SortData: {
    sortColumn: "name",
    sortType: "asc"
  },
  gradeList: "",
  SFA_Chart_API_Response: null,
  SFA_Chart_Constructed_Data: null,
  SFA_SidePanelData: null,
  sidePanelApiFailed: false,
  SFA_Selected_Bubbles: {},
  gradeSelected: "",
  apiLoadFail: false,
  noData: false,
  SfpotGridData: null,
  disableDiv: false,
  rubricDataMsg: null,
  DstCsvDownload: { csvData: null, downloadInProgress: false },
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case DistrictFAType.DISTRICT_FA_CHART_API_CALL_SUCCESS:
      return {
        ...state,
        SFA_Chart_API_Response: action.payload,
        SFA_Chart_Constructed_Data: dataConstructionForChart(action.payload, 0),
        SFA_Selected_Bubbles: {},
        apiLoadFail: false,
        noData: false,
        DstCsvDownload: { csvData: null, downloadInProgress: false }
      };
    case DistrictFAType.DISTRICT_FA_GRID_API_CALL_SUCCESS:
      return {
        ...state,
        sidePanelApiFailed: false,
        SFA_SidePanelData: {
          accordionList: getAccordionsState(action.payload["recordData"]),
          tableData: action.payload
        }
      };
    case DistrictFAType.UPDATE_ACCORDION_STATE:
      return {
        ...state,
        accordionsState: action.payload
      };
    case DistrictFAType.DISTRICT_FA_GRID_API_CALL_FAIL:
      return {
        ...state,
        SFA_SidePanelData: null,
        sidePanelApiFailed: true
      };

    case DistrictFAType.UPDATE_SELECTED_BUBLIST:

      return {
        ...state,
        SFA_SidePanelData: null,
        SFA_Selected_Bubbles: action.payload
      };
    case DistrictFAType.UPDATE_CHARTDATA_FOR_NEWGRADE:
      return {
        ...state,
        SFA_Chart_Constructed_Data: dataConstructionForChart(
          action.payload["apiResponse"],
          action.payload["selectedGradeIndex"]
        ),
        SFA_Selected_Bubbles: {},
        SFA_SidePanelData: null
      };
    case DistrictFAType.UPDATE_SCROLL_DATA:
      return {
        ...state,
        SFA_Chart_Constructed_Data: {
          ...state.SFA_Chart_Constructed_Data,
          ...action.payload
        }
      };
    case DistrictFAType.DISTRICT_FA_TABS:
      return selectedTab(state, action);

    case DistrictFAType.DISTRICT_FA_CHART_API_FAIL:
      let errorObj = action.payload
      return {
        ...state,
        ...errorObj,
        disableDiv: false,

      }
    case DistrictFAType.District_RECORD_TYPE:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          ["showRecord"]: action.payload
        }
      };
    case DistrictFAType.DISTRICT_GRADES:
      return {
        ...state,
        gradeList: action.payload.grades
      };
    case DistrictFAType.DISTRICT_SELECTED_GRADE:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          ["gradeSelected"]: action.payLoad
        }
      };
    case DistrictFAType.LOAD_ICON_STATUS:
      return {
        ...state,
        SFA_Chart_Constructed_Data: null
      };
    case DistrictFAType.DISTRICT_FA_FPOT_API_FAIL:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          // sideTableData: null,
          firstRecordObj: null,
          recentRecordObj: null,
          allRecordObj: null,
          apiLoadFail: false,
          ErrorCode: true,
          noData: false,
          disableDiv: false,
          isApiLoading: false,
          apiTimeOut: false,
          hideChart: true,
          rubricDataMsg: null
        }
      };
    case DistrictFAType.DISTRICT_GRID_API_SUCCESS:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          disableDiv: false,
          SfpotGridData: {
            ['accordionList']: toShowFirstAccordion(action.payload["schoolFRGridData"]),
            ['tableData']: action.payload
          },
          ['fpotSidePanelData']: sortDataFn(
            'lastName',
            'asc',
            action.payload.FRGridData
          ),
          ['fpotSidePanelResponse']: action.payload,

        },

      }
    case DistrictFAType.FPOT_SORTED_DATA:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          ['modifiedArray']: action.payload.SortedArray,
          disableDiv: false
        }
      };
    case DistrictFAType.DISTRICT_FA_SORTED_DATA:
      let currentState = { ...state }
      currentState["SFA_SidePanelData"]["tableData"]['recordData'] = action.payload.SortedArray;
      return {
        ...state,
        ...currentState
      };
    case DistrictFAType.DISTRICT_FA_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        },
        disableDiv: false
      };

    case DistrictFAType.DISTRICT_GRID_API_FAIL:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          SfpotGridData: {
            ['accordionList']: null,
            ['tableData']: null
          },
          ['fpotSidePanelData']: null,
          ['fpotSidePanelResponse']: null,
          disableDiv: false,
          ['sidePanelFail']: action.payload
        }
      }
    case DistrictFAType.UPDATE_SEL_DISTRICT_ERRORS:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          ['SelectedErr']: action.payload.selectedErrors,
          ['disableDiv']: true
        }
      };
    case DistrictFAType.DISTRICT_FPOT_CLASS_NAME:
      return {
        ...state,
        District_fpot: {
          ...state.District_fpot,
          SfpotGridData: {
            ...state.District_fpot.SfpotGridData,
            ['accordionList']: action.payload,

          },
        }
      };
    case DistrictFAType.DSTFA_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // DstCsvDownload: action.payLoad
        DstCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case DistrictFAType.DSTFA_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        DstCsvDownload: action.payLoad
      };
    default:
      return {
        ...state
      };
  }
};

function dataConstructionForChart(apiResponse, index) {
  let completeReadingLevels =
    apiResponse["readingLevelAxis"].slice().reverse() || [];
  let gradesForDropDown = apiResponse["gradesList"] || [];
  let visibleReadingLvls = completeReadingLevels.slice(0, 5).reverse();
  let xScrollIndex = index;
  let yScrollIndex = 0;
  let currentGradeData = getGradeForChartDisplay(
    apiResponse["recordDataList"][index]
  );

  return {
    currentGradeData: currentGradeData,
    xScrollIndex: xScrollIndex,
    yScrollIndex: yScrollIndex,
    completeReadingLevels: completeReadingLevels,
    gradesForDropDown: gradesForDropDown,
    visibleReadingLvls: visibleReadingLvls

  };
}

function getGradeForChartDisplay(dataObj) {
  let tempObj = {
    recentRecord: { totalStudents: {}, wcpmList: {} },
    firstRecord: { totalStudents: {}, wcpmList: {} }
  };
  // total no of students computation
  tempObj["grade"] = dataObj["grade"];
  tempObj["recentRecord"]["totalStudents"] = totalStudentData(
    dataObj["recentRecord"]["totalStudents"]
  );
  tempObj["firstRecord"]["totalStudents"] = totalStudentData(
    dataObj["firstRecord"]["totalStudents"]
  );

  // Wcpm for first and recent record

  tempObj["recentRecord"]["wcpmList"] = getRangeWiseData(
    dataObj["recentRecord"]["wcpmList"],
    "recentRecord"
  );
  tempObj["firstRecord"]["wcpmList"] = getRangeWiseData(
    dataObj["firstRecord"]["wcpmList"],
    "firstRecord"
  );

  return tempObj;
}

function totalStudentData(listItems) {
  let tempObj = {};
  if (listItems && listItems.length > 0) {
    listItems.forEach(obj => {
      tempObj[obj.readingLevel] = obj.value;
    });
    return tempObj;
  } else {
    return tempObj;
  }
}

function getRangeWiseData(listItems, key) {
  let tempObjForRange = {};

  if (listItems && listItems.length > 0) {
    listItems.forEach(obj => {
      if (tempObjForRange[obj.wcpmRange]) {
        tempObjForRange[obj.wcpmRange][obj.readingLevel] = {
          value: obj.value,
          fluencyFrom: obj.fluencyFrom,
          fluencyTo: obj.fluencyTo
        };
      } else {
        tempObjForRange[obj.wcpmRange] = {};
        tempObjForRange[obj.wcpmRange][obj.readingLevel] = {
          value: obj.value,
          fluencyFrom: obj.fluencyFrom,
          fluencyTo: obj.fluencyTo
        };
      }
    });
    return tempObjForRange;
  } else {
    return tempObjForRange;
  }
}

//to show  the first accordion open
function toShowFirstAccordion(sideTableData) {
  let tempObj = {};
  sortDistrictData("className", sideTableData);
  sideTableData &&
    sideTableData.forEach((obj, index) => {
      if (index === 0) {
        tempObj[obj.className] = true;
      } else {
        tempObj[obj.className] = false;
      }
    });
  return tempObj;
}

function getInitialbubbles(data) {

  if (data.recentRecord && data.recentRecord['wcpmList'].length > 0) {
    let tempObj = { recentRecord: [] }
    if (data.recentRecord['wcpmList'] && data.recentRecord['wcpmList'].length > 0) {
      data.recentRecord['wcpmList'].forEach((obj) => {
        tempObj['recentRecord'].push({
          fluencyFrom: obj.fluencyFrom,
          fluencyTo: obj.fluencyTo,
          grade: data['grade'],
          readingLevel: obj['readingLevel'],
          recordType: "recentRecord"
        })
      })
    }
    return tempObj
  } else {
    let tempObj = { firstRecord: [] }
    if (data.firstRecord['wcpmList'] && data.firstRecord['wcpmList'].length > 0) {
      data.firstRecord['wcpmList'].forEach((obj) => {
        tempObj['firstRecord'].push({
          fluencyFrom: obj.fluencyFrom,
          fluencyTo: obj.fluencyTo,
          grade: data['grade'],
          readingLevel: obj['readingLevel'],
          recordType: "firstRecord"
        })
      })
    }
    return tempObj
  }

}

//to sort table data by school name
function sortDistrictData(column, sideTableData) {
  if (sideTableData !== null) {
    let sortedData = sideTableData.sort(function (a, b) {
      let firstElement =
        column !== "schoolName"
          ? a[column]
          : a[column].toString().toUpperCase();
      let secondElement =
        column !== "schoolName"
          ? b[column]
          : b[column].toString().toUpperCase();

      let com = 0;
      if (firstElement > secondElement) {
        com = 1;
      } else if (firstElement < secondElement) {
        com = -1;
      }

      return com;
    });
    return sortedData;
  }
}
function selectedTab(state, action) {
  switch (action.payload) {
    case "fpot":
      return {
        ...state,
        ScFTabSelection: {
          wcpm: false,
          fpot: true
        }
      };
    case "wcpm":
      return {
        ...state,
        ScFTabSelection: {
          wcpm: true,
          fpot: false
        }
      };
  }
}

function returnRecords(data, recordKey) {
  let tempObject = {
    [recordKey]: {}
  };
  Object.keys(data).forEach(function (key) {
    if (key !== "recentRecordNull")
      tempObject[recordKey][key] = constructedObj(data[key], key);
  });
  return tempObject;
}

function constructedObj(list, key) {
  let arrObj = {};
  list !== null &&
    list.forEach(function (obj) {
      arrObj[obj.score] = { value: obj.value, criteriaId: obj.criteriaId };
    });

  return arrObj;
}

//function to sort array of data
function sortDataFn(column, sortType, stdArray) {
  let sortedArray = [];
  stdArray.map((actualArray, value) => {
    if (actualArray.length != 0) {
      sortedArray = dataSorting(
        actualArray.schoolRLPGradeWiseGridDataRecordDataList,
        column,
        sortType
      );
    }
  });
  return stdArray;
}
function getAccordionsState(data) {
  let accordState = {}
  if (data && data.length > 0) {
    data.forEach((obj, index) => {
      if (index == 0) {
        accordState[index] = true;
      } else {
        accordState[index] = false;
      }

    })
  }
  return accordState;
}
