import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  SET_GET_TESTSTATUS_SUMMARY_DETAILS,
  SET_GET_TESTSTATUS_SUMMARY_DATA,
  SET_CHECK_ASSIGNMENT_ID,
} from "../Reducer_Action_Types/TestStatus.Types";
import {
  APPLY_FILTER_IN_DATE_TAB,
  GET_ROSTER_GRADES_AND_SCHOOLS_SUCCESS,
  GET_SUMMARYREPORTS_DEFAULT,
  GET_SUMMARYREPORTS_DEFAULT_SUCCESS,
  SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD,
  SET_GET_TEST_TAB_RESULTS,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { SET_GET_SUMMARY_REPORTS } from "../Reducer_Action_Types/SummaryActionsTypes";
import { Report_Action_Types } from "../Reducer_Action_Types/ReportsActionTypes";
import { SUMMARY_REPORTS_FLAG } from "../Utils/globalVars";

const INITIAL_STATE = {
  retryApis: 0,
  LoginDetails: {
    JWTToken: "",
    userName: "",
    password: "",
    schoolId: "",
    realm: "",
    loginSuccess: false,
    DisplayNodata: false,
    DisplayTechnicalError: false,
    getInitalData: false,
    loginFails: false,
    errorCode: "",
    disableLogIn: true,
    UserRole: "",
    ReportingAccessParam: [],
  },
  Auth_Apis: {
    defaultApi: false,
    RosterApi: false,
    SchoolApiForORR: false,
    Loading_Report_Access: false,
    DatesApi: false,
    // defaultAPINotCalledYet: true,
    lazyLoad_eAR_Default_Api: false,
  },
  NoaccessToReports: false,
};
import { REHYDRATE } from "redux-persist";
import {
  GET_INITIAL_APPLICATION_DATA,
  U_S_Action_Types,
  GET_INITIAL_APPLICATION_DATA_FAIL,
  GET_INITIAL_APPLICATION_DATA_SUCCESS,
  GET_USER_ACCESSABLE_REPORTS_SUCCESS,
  GET_USER_ACCESSABLE_REPORTS,
  GET_USER_ACCESSABLE_REPORTS_FAIL,
  GET_DATE_TAB_RESULTS,
  GET_ROSTER_CLASSES_SUCCESS,
  RETURN_TO_PREVIOUS_REPORT_UNIVERSAL,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case REHYDRATE:
      if (action.payload == undefined) {
        return {
          ...state,
        };
      } else {
        return {
          ...state,
          ...action.payload.Authentication,
        };
      }

    case RETURN_TO_PREVIOUS_REPORT_UNIVERSAL:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          DisplayTechnicalError: false,
          errorCode: "",
          DisplayNodata: false,
        },
      };

    case AuthActionTypes.TECHNICAL_ISSUE_ERROR:
      let Status =
        action.payload == undefined
          ? action.payload
          : action.payload.statusCode;

      return {
        ...state,
        retryApis: 0,
        LoginDetails: {
          ...state.LoginDetails,
          DisplayTechnicalError: true,
          errorCode: Status,
          DisplayNodata: false,
        },
      };
    case SET_GET_TESTSTATUS_SUMMARY_DETAILS:
      return {
        ...state,
        retryApis: parseInt(state.retryApis) + 1,
      };
    case SET_GET_SUMMARY_REPORTS:
      return {
        ...state,
        retryApis: parseInt(state.retryApis) + 1,
      };
    case SET_GET_TESTSTATUS_SUMMARY_DATA:
      return {
        ...state,
        retryApis: parseInt(state.retryApis) + 1,
      };
    case SET_CHECK_ASSIGNMENT_ID:
      return {
        ...state,
        retryApis: parseInt(state.retryApis) + 1,
      };

    case SET_GET_TEST_TAB_RESULTS:
      return {
        ...state,
        retryApis: parseInt(state.retryApis) + 1,
      };
    case Report_Action_Types.SET_GET_CLASS_TESTSCORES_DETAIL:
      return {
        ...state,
        retryApis: parseInt(state.retryApis) + 1,
      };

    case GET_INITIAL_APPLICATION_DATA_FAIL:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          DisplayTechnicalError: action.payload.statusCode == 500,
          errorCode: action.payload.statusCode,
        },
      };

    case AuthActionTypes.SAVE_USERNAME_AND_PASSWORD:
      if (action.payload.fromfield == "password") {
        return {
          ...state,
          LoginDetails: {
            ...state.LoginDetails,
            password: action.payload.value,
            errorCode: "",
            loginFails: false,
            disableLogIn: false,
          },
        };
      } else if (action.payload.fromfield == "username") {
        return {
          ...state,
          LoginDetails: {
            ...state.LoginDetails,
            userName: action.payload.value,
            errorCode: "",
            loginFails: false,
            disableLogIn: false,
          },
        };
      } else if (action.payload.fromfield == "realm") {
        return {
          ...state,
          LoginDetails: {
            ...state.LoginDetails,
            realm: action.payload.value,
            errorCode: "",
            loginFails: false,
            disableLogIn: false,
          },
        };
      } else if (action.payload.fromfield == "schoolId") {
        return {
          ...state,
          LoginDetails: {
            ...state.LoginDetails,
            schoolId: action.payload.value,
            errorCode: "",
            loginFails: false,
            disableLogIn: false,
          },
        };
      }

    case AuthActionTypes.DISPLAY_NO_DATA_COMPO:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          DisplayNodata: true,
        },
      };
    case AuthActionTypes.POST_CREATE_JWT_TOKEN:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          loginSuccess: null,
          disableLogIn: true,
          JWTToken: "",
          errorCode: "",
        },
      };

    case AuthActionTypes.POST_CREATE_JWT_TOKEN_SUCCESS:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          JWTToken: action.payload.Response_Data.token,
          DisplayNodata: false,
          loginSuccess: true,
        },
      };

    case GET_USER_ACCESSABLE_REPORTS:
      return {
        ...state,
        NoaccessToReports: false,
        LoginDetails: {
          ...state.LoginDetails,
          JWTToken: action.payload,
          schoolId: action.selectedSchoolId,
        },
        Auth_Apis: {
          ...state.Auth_Apis,
          Loading_Report_Access: true,
        },
      };
    /**
     *  failure on get user accessable reports list API.
     */
    case GET_USER_ACCESSABLE_REPORTS_FAIL:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          ReportingAccessParam: ["eAR"],
        },
        NoaccessToReports: true,
      };

    case AuthActionTypes.TAKE_ME_BACK_IN_NODATA_COMP:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          DisplayNodata: false,
        },
      };

    case AuthActionTypes.DISPLAY_NO_DATA_COMPO:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          DisplayNodata: true,
        },
      };

    case GET_USER_ACCESSABLE_REPORTS:
      return {
        ...state,
        NoaccessToReports: false,
        Auth_Apis: {
          ...state.Auth_Apis,
          Loading_Report_Access: true,
        },
      };

    /**
     * Success response on get user accessable reports list.
     */
    case GET_USER_ACCESSABLE_REPORTS_SUCCESS:
      const { ReportingAccessParam } = action.payload;
      const onlyLicensedForORRRepoting =
        !ReportingAccessParam.includes("eAR") &&
        ReportingAccessParam.includes("ORR");
      let callDefaultAPI =
        ReportingAccessParam.includes("eAR") && !SUMMARY_REPORTS_FLAG;
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          ...action.payload,
        },
        Auth_Apis: {
          ...state.Auth_Apis,
          defaultApi: callDefaultAPI,
          getSummaryDefault: !callDefaultAPI && SUMMARY_REPORTS_FLAG,
          RosterApi: onlyLicensedForORRRepoting,
          DatesApi: true,
          Loading_Report_Access: false,
          SchoolApiForORR: onlyLicensedForORRRepoting,
          // defaultAPINotCalledYet: true
        },
        NoaccessToReports: ReportingAccessParam.length == 0,
      };

    /**
     *  failure on get user accessable reports list API.
     */
    case GET_USER_ACCESSABLE_REPORTS_FAIL:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          ReportingAccessParam: ["eAR"],
        },
        NoaccessToReports: true,
      };

    case GET_SUMMARYREPORTS_DEFAULT:
    case APPLY_FILTER_IN_DATE_TAB:
      return {
        ...state,
        Auth_Apis: {
          ...state.Auth_Apis,
          getSummaryDefault: false,
          lazyLoad_eAR_Default_Api: false,
        },
      };

    case GET_DATE_TAB_RESULTS:
      return {
        ...state,
        Auth_Apis: {
          ...state.Auth_Apis,
          DatesApi: false,
        },
      };

    /**
     * before call axios to get roster tab details.
     */
    case U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA:
      return {
        ...state,
        Auth_Apis: {
          ...state.Auth_Apis,
          RosterApi: false,
        },
      };
    case SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD:
      return {
        ...state,
        Auth_Apis: {
          ...state.Auth_Apis,
          RosterApi: false,
        },
      };

    case GET_ROSTER_CLASSES_SUCCESS:
      return {
        ...state,
        Auth_Apis: {
          ...state.Auth_Apis,
          RosterApi: false,
        },
      };

    /**
     * After Successfull response on initial load
     */
    case GET_INITIAL_APPLICATION_DATA_SUCCESS:
    case GET_SUMMARYREPORTS_DEFAULT_SUCCESS:
      const { NavigationByHeaderSelection } = action.payload.Universal;
      let isSummaryDefault =
        action.type == "GET_SUMMARYREPORTS_DEFAULT_SUCCESS";

      if (
        action.payload.Data == undefined ||
        action.payload.Data == null ||
        action.payload.Data.standardPerformance == null ||
        (action.payload.Data.rosterTestVO == null &&
          NavigationByHeaderSelection.Summary_Reports)
      ) {
        let Nodata = action.payload.DateTabChanged
          ? false
          : !action.payload.Data.rosterTestVO && !isSummaryDefault;

        if (NavigationByHeaderSelection.ORR) {
          return {
            ...state,
            Auth_Apis: {
              ...state.Auth_Apis,
              SchoolApiForORR:
                state.LoginDetails.ReportingAccessParam.includes("ORR"),
              RosterApi: action.payload.DateTabChanged,
            },
          };
        }

        return {
          ...state,
          LoginDetails: {
            ...state.LoginDetails,
            DisplayNodata: Nodata,
            DisplayTechnicalError: false,
            UserRole: action.payload.Role,
            DateTimeOf_DefaultApi:
              action.payload.CurrentDateTime ||
              state.LoginDetails.DateTimeOf_DefaultApi,
          },
          Auth_Apis: {
            ...state.Auth_Apis,
            SchoolApiForORR:
              state.LoginDetails.ReportingAccessParam.includes("ORR"),
            RosterApi:
              !action.payload.DateTabChanged &&
              !state.Auth_Apis.lazyLoad_eAR_Default_Api, // enable if no complete roster for district admin.
            lazyLoad_eAR_Default_Api: isSummaryDefault
              ? true
              : state.Auth_Apis.lazyLoad_eAR_Default_Api, // && !action.payload.lazyLoad_eAR_Default_Api,
            defaultApi: isSummaryDefault,
            // defaultAPINotCalledYet: action.type == "GET_INITIAL_APPLICATION_DATA_SUCCESS" ? false : state.Auth_Apis.defaultAPINotCalledYet
          },
        };
      } else {
        return {
          ...state,
          LoginDetails: {
            ...state.LoginDetails,
            DisplayNodata:
              !action.payload.Data.rosterTestVO &&
              NavigationByHeaderSelection.Summary_Reports,
            DisplayTechnicalError: false,
            UserRole: action.payload.Role,
          },
          Auth_Apis: {
            ...state.Auth_Apis,
            RosterApi: true && !state.Auth_Apis.lazyLoad_eAR_Default_Api, // enable if no complete roster for district admin.
            // RosterApi: !action.payload.DateTabChanged || isSummaryDefault, // enable if no complete roster for district admin.
            lazyLoad_eAR_Default_Api:
              isSummaryDefault && !action.payload.lazyLoad_eAR_Default_Api,
            defaultApi: isSummaryDefault,
          },
        };
      }
    case AuthActionTypes.POST_CREATE_JWT_TOKEN_FAIL:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          loginSuccess: null,
          disableLogIn: false,
          errorCode: action.payload,
        },
      };
    case AuthActionTypes.TAKE_ME_BACK_IN_NODATA_COMP:
      return INITIAL_STATE;

    /**
     * Before INitiate api call to get default data:
     */
    case GET_INITIAL_APPLICATION_DATA:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          getInitalData: false,
          JWTToken: action.payload.AccessToken,
        },
        Auth_Apis: {
          ...state.Auth_Apis,
          defaultApi: false,
        },
      };
    case AuthActionTypes.ERROR_LOG_SUCCESS:
      return {
        ...state,
      };
    case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:
      return {
        ...state,
        retryApis: 0,
        Auth_Apis: {
          ...state.Auth_Apis,
          defaultApi: false,
          RosterApi: false,
          SchoolApiForORR: false,
          Loading_Report_Access: false,
          DatesApi: false,
          lazyLoad_eAR_Default_Api: false,
        },
        LoginDetails: {
          ...state.LoginDetails,
          userName: "",
          password: "",
          schoolId: "",
          realm: "",
          loginSuccess: false,
          DisplayNodata: false,
          DisplayTechnicalError: false,
          getInitalData: false,
          loginFails: false,
          errorCode: "",
          disableLogIn: true,
          UserRole: "",
          ReportingAccessParam: [],
        },
        NoaccessToReports: false,
      };

    case GET_ROSTER_GRADES_AND_SCHOOLS_SUCCESS:
      return {
        ...state,
        retryApis: 0,
        Auth_Apis: {
          ...state.Auth_Apis,
          lazyLoad_eAR_Default_Api: false,
        },
        NoaccessToReports: false,
      };
    // #endregion
    default:
      return {
        ...state,
        LoginDetails: {
          ...state.LoginDetails,
          loginSuccess: false,
        },
      };
  }
};
