import { C_FluencyTypes } from '../Reducer_Action_Types/C_FluencyTypes.jsx';
import { dataSorting, constructCsvData } from '../Components/ReusableComponents/OrrReusableComponents';

export const INITIAL_STATE = {
  FluencyTabSelection: {
    wcpm: false,
    fpot: true
  },
  isApiLoading: true,
  apiLoadFail: false,
  apiTimeOut: false,
  noChartData: false,
  monthRangeObj: [],
  sidePanelApiLoader: { apiLoading: true, apiError: false },
  cfaGridData: {
    studentList: null,
    studentCount: '',
    rosterCount: '',
    firstRecord: false,
    recentRecord: false,
    gridData: null
  },
  SortData: {
    sortColumn: 'fluency',
    sortType: 'desc'
  },
  CF_Chart_Response: null,
  classFluencyChartData: null,
  classFluencySelectedBubbles: null,
  hideCreateGroup: false,
  CfaCsvDownload: { csvData: null, downloadInProgress: false },

  progressOverTime: {
    firstRecordObj: null,
    recentRecordObj: null,
    allRecordObj: null,
    sidePanelAPIFail: false,
    errorRange: [],
    showHideRecentRecord: false,
    showHideFirstRecord: false,
    showHideAllRecord: false,
    showRecord: 'rec',
    SelectedErr: {},
    SortData: {
      sortColumn: 'assignmentDate',
      sortType: 'desc'
    },
    rubricDataMsg: null,
    hideCreateGroup: false,
    CfrCsvDownload: { csvData: null, downloadInProgress: false }
  }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case C_FluencyTypes.SIDE_PANEL_API_LOADER:
      return {
        ...state,
        ['sidePanelApiLoader']: {
          apiLoading: action.payload.apiLoading,
          apiError: action.payload.apiError
        },
        hideCreateGroup: action.payload.hideCreateGroup,
      };

    case C_FluencyTypes.API_LOADER:
      return {
        ...state,
        cfaGridData: {
          ...state['cfaGridData']
        },
        ...action.payload['status'],
        hideCreateGroup: false,
      };
    case C_FluencyTypes.UPDATE_SELECTED_BOXES:
      return {
        ...state,
        cfaGridData: {
          ...state['cfaGridData']
        },
        ['classFluencySelectedBubbles']: action.payload,
        hideCreateGroup: true,
      };
    case C_FluencyTypes.CPOT_SELECTED_ERRORS:
      return {
        ...state,
        ['progressOverTime']: {
          ...state['progressOverTime'],
          ['SelectedErr']: action.payload['selectedErrors'],
          hideCreateGroup: true,
        }
      };
    case C_FluencyTypes.UPDATE_ALL_RECORDS_TYPE:
      return {
        ...state,
        ['progressOverTime']: {
          ...state['progressOverTime'],
          ['showRecord']: action.payload
        }
      };
    case C_FluencyTypes.TAB_SELECTED:
      return tabSelected(state, action);
    case C_FluencyTypes.UPDATE_TAB_DATA:
      return;
    case C_FluencyTypes.FLUENCY_GRID_DATA:
      return {
        ...state,
        cfaGridData: {
          studentList: dataSorting(
            action.payload.cfaGridResponse.cfaGridStudentList,
            'fluency',
            'desc'
          ),
          studentCount: action.payload.cfaGridResponse.noOfStudent,
          rosterCount: action.payload.cfaGridResponse.noOfStudentsRostered,
          firstRecord: action.payload.firstRecord,
          recentRecord: action.payload.recentRecord,
          gridData: action.payload.gridData,
          monthSelected: action.payload.monthYear
        },
        hideCreateGroup: false,
      };
    case C_FluencyTypes.CF_CHART_DATA_SUCCESS:
      let CFA_DATA = getConstructedData(action.payload.responseData);
      return {
        ...state,
        monthRangeObj: CFA_DATA && monthDataConstruction(CFA_DATA),
        ['CF_Chart_Response']: action.payload,
        classFluencySelectedBubbles: { default: [] },
        classFluencyChartData: CFA_DATA,
        isApiLoading: false,
        apiLoadFail: false,
        apiTimeOut: false,
        noChartData: action.payload.responseData['readingLevelAxis'].length === 0 ? true : false,
        hideCreateGroup: true,
        selAll: CFA_DATA ? true : false,
        CfaCsvDownload: { csvData: null, downloadInProgress: false },
        toggleData: false
      };
    case C_FluencyTypes.CF_CHART_DATA_FAILURE:
      return {
        ...state,
        ['CF_Chart_Response']: null,
        classFluencyChartData: null,
        apiLoadFail: action.payload['apiFail'] ? true : false,
        isApiLoading: false,
        noChartData: action.payload['noData'] ? true : false,
        apiTimeOut: false,
        hideCreateGroup: true,
        CfaCsvDownload: { csvData: null, downloadInProgress: false },
      };

    case C_FluencyTypes.C_FLUENCY_GRID_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };
    case C_FluencyTypes.SAVE_SORTED_FLUENCY_DATA:
      return {
        ...state,
        cfaGridData: {
          ...state.cfaGridData,
          studentList: action.payload.SortedArray
        }
      };
    case C_FluencyTypes.UPDATE_CHART_SCROLL_DATA:
      return {
        ...state,
        ['classFluencyChartData']: action.payload.classFluencyChartData
      };
    case C_FluencyTypes.C_FPO_API_SUCCESS:
      return {
        ...state,
        isApiLoading: false,
        apiLoadFail: false,
        apiTimeOut: false,
        noChartData: false,
        progressOverTime: {
          ...state.progressOverTime,
          firstRecordObj: returnConstRecord(
            action.payload.firstRecord,
            'firstRecord'
          ),
          allRecordObj: action.payload.dataRecordType.allRecords
            ? returnConstRecord(
              action.payload.allRecordsAverage,
              'allRecordsAverage'
            )
            : null,
          recentRecordObj: action.payload.dataRecordType.recentRecord
            ? returnConstRecord(action.payload.recentRecord, 'recentRecord')
            : null,
          errorRange: action.payload.rubricAxisData,
          showHideAllRecord: (action.payload.dataRecordType['allRecords'] && action.payload.allRecordsAverage['recentRecordNull']),
          showHideRecentRecord: (action.payload.dataRecordType['recentRecord'] && action.payload.recentRecord['recentRecordNull']),
          showHideFirstRecord: (action.payload.dataRecordType['firstRecord'] && action.payload.firstRecord['recentRecordNull']),
          SelectedErr: {},
          showRecord: action.payload.dataRecordType.recentRecord
            ? 'rec'
            : action.payload.dataRecordType.allRecords
              ? 'all'
              : '',
          rubricDataMsg: null,
          hideCreateGroup: true,
          noRecordFound: recNotAvailable(action.payload),
        },

      };

    case C_FluencyTypes.CLASS_FPO_SIDEPANEL_SPINNER:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          ['fpoGridData']: null,
          sidePanelAPIFail: false,
          rubricDataMsg: null,
          hideCreateGroup: true
        }
      };
    case C_FluencyTypes.C_FLUENCY_RUBRIC_FAIL:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          firstRecordObj: null,
          recentRecordObj: null,
          allRecordObj: null,
          sidePanelAPIFail: false,
          errorRange: [],
          showHideRecentRecord: false,
          showHideFirstRecord: false,
          showHideAllRecord: false,
          showRecord: 'rec',
          SelectedErr: {},
          SortData: {
            sortColumn: 'assignmentDate',
            sortType: 'desc'
          },
          rubricDataMsg: action.payload,
          hideCreateGroup: false
        },
        isApiLoading: false,
        apiLoadFail: false,
        apiTimeOut: false,
        noChartData: false,
      }
    case C_FluencyTypes.CLASS_FPO_SIDEPANEL_API_FAIL:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          ['fpoGridData']: null,
          sidePanelAPIFail: true,
          rubricDataMsg: null,
          hideCreateGroup: true
        }
      };
    case C_FluencyTypes.C_FPO_GRID_API_SUCCESS:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          ['fpoGridData']: action.payload.cfrSidePanelGridData,
          ['fpoGridResponse']: action.payload,
          sidePanelAPIFail: false,
          hideCreateGroup: false
        }
      };

    case C_FluencyTypes.CFA_UPDATE_DROP_DOWN_DATA:
      return {
        ...state,
        ...getSelectedGrade(action.payLoad, state.monthRangeObj)
      }
    case C_FluencyTypes.CFA_UPDATE_CHART_DATA:

      let actualState = { ...state['classFluencyChartData'], ...(dropDownSelectionData(action.payLoad, state)) }
      return {
        ...state,
        classFluencyChartData: actualState
      };

    case C_FluencyTypes.CFA_UPDATE_ALL_DATA:
      return {
        ...state,
        ...updateSelAll(action.payLoad.selAll, state.monthRangeObj)
      }
    case C_FluencyTypes.CFA_UPDATE_TOGGLE:
      return {
        ...state,
        toggleData: action.payLoad.toggleData,
        ...updateAll(state.selAll, state.monthRangeObj)
      }
    case C_FluencyTypes.CLASS_FPO_SORT_COLUMN:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          ['SortData']: {
            sortColumn: action.payload.sortColumn,
            sortType: action.payload.sortType
          }
        }
      };
    case C_FluencyTypes.CFPO_SORTED_DATA:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          ['fpoGridData']: action.payload.SortedArray
        }
      };
    case C_FluencyTypes.CFA_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        // CfaCsvDownload: action.payLoad
        CfaCsvDownload: {
          csvData: constructCsvData(action.payLoad),
          downloadInProgress: true
        }
      };
    case C_FluencyTypes.CFA_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        CfaCsvDownload: action.payLoad
      };
    case C_FluencyTypes.CFR_CSVDATA_DOWNLOAD_SUCCESS:
      return {
        ...state,
        ['progressOverTime']: {
          ...state.progressOverTime,
          // CfrCsvDownload: action.payLoad
          CfrCsvDownload: {
            csvData: constructCsvData(action.payLoad),
            downloadInProgress: true
          }
        }
      };
    case C_FluencyTypes.CFR_CSVDATA_DOWNLOAD_RESET:
      return {
        ...state,
        ['progressOverTime']: {
          ...state.progressOverTime,
          CfrCsvDownload: action.payLoad
        }
      };
    case C_FluencyTypes.CLASS_FA_TABS:
      return selectedTab(state, action);
    case C_FluencyTypes.CFA_LOADER:
      return {
        ...state,
        ['CF_Chart_Response']: null,
        classFluencyChartData: null,
        apiLoadFail: false,
        isApiLoading: true,
        noChartData: false,
        apiTimeOut: false,
        hideCreateGroup: false,
      }
    case C_FluencyTypes.CFPOT_LOADER:
      return {
        ...state,
        progressOverTime: {
          ...state.progressOverTime,
          firstRecordObj: null,
          recentRecordObj: null,
          allRecordObj: null,
          sidePanelAPIFail: false,
          errorRange: [],
          showHideRecentRecord: false,
          showHideFirstRecord: false,
          showHideAllRecord: false,
          showRecord: 'rec',
          SelectedErr: {},
          SortData: {
            sortColumn: 'assignmentDate',
            sortType: 'desc'
          },
          rubricDataMsg: null,
          hideCreateGroup: false
        },
        isApiLoading: true,
        apiLoadFail: false,
        apiTimeOut: false,
        noChartData: false,
      }
    default:
      return {
        ...state
      };
  }
};


// expand and collapse functions
function getSelectedGrade(monthObj, monthRange) {
  let monthCount = 0;
  let selAll;
  monthRange[monthObj['index']] = monthObj;
  monthRange.forEach((item, index) => {
    if (item.checked) {
      monthCount++;
    }
  })
  if (monthCount === 0) {
    monthRange.forEach((item, index) => {
      if (!item.checked) {
        monthRange[index].checked = !monthRange[index].checked
      }
    })
  }
  if (monthCount === monthRange.length || monthCount === 0) {
    selAll = true;
  } else {
    selAll = false;
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function updateSelAll(selAll, monthRange) {
  if (selAll) {
    monthRange.forEach((item, index) => {
      monthRange[index].checked = true
    })
  } else {
    monthRange.forEach((item, index) => {
      monthRange[index].checked = false
    })
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}

function updateAll(selAll, monthRange) {
  let monthCount = 0;

  if (!selAll) {
    monthRange.forEach((item, index) => {
      if (item.checked) {
        monthCount++;
      }
    })
    if (monthCount === 0) {
      monthRange.forEach((item, index) => {
        if (!item.checked) {
          monthRange[index].checked = !monthRange[index].checked;
          selAll = true
        }
      })
    }
  }
  return { monthRangeObj: monthRange, selAll: selAll }
}
function returnConstRecord(data, recordKey) {
  let tempObject = {
    [recordKey]: {}
  };
  Object.keys(data).forEach(function (key) {
    if (key != 'recentRecordNull' && data[key]) {
      tempObject[recordKey][key] = returnConstructedObj(data[key], key);
    }
  });
  return tempObject;
}

function returnConstructedObj(list, key) {
  let arrObj = {};
  list.forEach(function (obj) {
    arrObj[obj.score] = { value: obj.value, criteriaId: obj.criteriaId };
  });

  return arrObj;
}

function tabSelected(state, action) {
  switch (action.payload) {
    case 'fpot':
      return {
        ...state,
        CfaCsvDownload: { csvData: null, downloadInProgress: false },
        ['progressOverTime']: {
          ...state.progressOverTime,
          CfrCsvDownload: { csvData: null, downloadInProgress: false }
        },
        FluencyTabSelection: {
          wcpm: false,
          fpot: true
        }
      };
    case 'wcpm':
      return {
        ...state,
        CfaCsvDownload: { csvData: null, downloadInProgress: false },
        ['progressOverTime']: {
          ...state.progressOverTime,
          CfrCsvDownload: { csvData: null, downloadInProgress: false }
        },
        FluencyTabSelection: {
          wcpm: true,
          fpot: false
        }
      };
  }
}
function getMobileView() {
  let ios = /iphone|ipod|ipad/.test(window.navigator.userAgent.toLowerCase());
  return (ios || window.innerWidth < 1050);
}

function getConstructedData(data) {

  if (data && data.recordDataList !== null && data.recordDataList.length > 0) {
    let mobView = getMobileView();
    let YaxisData = data.readingLevelAxis;
    let monthlyRecordData = [];
    let scrollMonthData = [];

    data.recordDataList.map(individualData => {
      let wcpmList = combineMonthData(individualData.wcpmList);
      let totalStudents = getTotalNoOfStudent(individualData.wcpmList);

      let monthName = individualData.wcpmList[0].monthName;
      let monthYear = individualData.wcpmList[0].monthYear;
      // Push computed data
      monthlyRecordData.push({
        ...individualData,
        monthName: monthName,
        monthYear: monthYear,
        ['wcpmList']: wcpmList,
        ['totalNoOfStudents']: totalStudents,
        yAxisLevels: YaxisData
      });
    });
    // OR-1686 bug fix
    if (!mobView) {
      if (monthlyRecordData.length > 2) {
        scrollMonthData = [
          monthlyRecordData[0],
          monthlyRecordData[monthlyRecordData.length - 2],
          monthlyRecordData[monthlyRecordData.length - 1]
        ];
      } else if (monthlyRecordData.length < 3 && monthlyRecordData.length > 1) {
        scrollMonthData = [
          monthlyRecordData[0],
          monthlyRecordData[monthlyRecordData.length - 1]
        ];
      } else {
        scrollMonthData = [monthlyRecordData[0]];
      }
    } else {

      if (monthlyRecordData.length > 1) {
        scrollMonthData = [
          monthlyRecordData[0],
          monthlyRecordData[monthlyRecordData.length - 1]
        ];
      } else {
        scrollMonthData = [monthlyRecordData[0]];
      }

    }

    return {
      YaxisData: YaxisData,
      YaxisDataRange: YaxisData.slice(YaxisData.length - 5, YaxisData.length),
      scrollIndex: YaxisData.length - 5,
      xAxisScrollIndex: monthlyRecordData.length - (mobView ? 1 : 2),
      monthlyRecordData: monthlyRecordData,
      allMonthRecord: monthlyRecordData,
      recentMonthlyRecords: scrollMonthData,
      mobileViewLength: mobView ? 1 : 2
    };
  } else {
    return null;
  }
}

function dropDownSelectionData(dropDownSelection, state) {
  const allMonthData = state['classFluencyChartData']['allMonthRecord'];
  const mobLen = state['classFluencyChartData']['mobileViewLength'];
  let mobView = getMobileView();
  let dataArray = [];
  let scrollMonthData = [];
  dropDownSelection && dropDownSelection.forEach((monthData, index) => {
    if (dropDownSelection[index]['checked']) {
      dataArray.push(allMonthData[index])
    }
  })
  if (!mobView) {
    if (dataArray.length > 2) {
      scrollMonthData = [
        dataArray[0],
        dataArray[dataArray.length - 2],
        dataArray[dataArray.length - 1]
      ];
    } else if (dataArray.length < 3 && dataArray.length > 1) {
      scrollMonthData = [
        dataArray[0],
        dataArray[dataArray.length - 1]
      ];
    } else {
      scrollMonthData = [dataArray[0]];
    }
  } else {
    if (dataArray.length > 1) {
      scrollMonthData = [
        dataArray[0],
        dataArray[dataArray.length - 1]
      ];
    } else {
      scrollMonthData = [dataArray[0]];
    }
  }


  return {
    YaxisDataRange: state.classFluencyChartData['YaxisData'].slice(state.classFluencyChartData['YaxisData'].length - 5, state.classFluencyChartData['YaxisData'].length),
    scrollIndex: state.classFluencyChartData['YaxisData'].length - 5,
    xAxisScrollIndex: dataArray.length - mobLen,
    monthlyRecordData: dataArray,
    recentMonthlyRecords: scrollMonthData
  };

}

// Combine the data belongs to the same WCPM and then calculate the total no students under same RL
function combineMonthData(wcpmList) {
  let dataList = {};
  wcpmList.forEach(obj => {
    dataList[obj.wcpmRange] = dataList[obj.wcpmRange] || {};
    dataList[obj.wcpmRange][obj.readingLevel] = { value: obj.value, fluencyFrom: obj.fluencyFrom, fluencyTo: obj.fluencyTo };
  });

  return dataList;
}
// Compute the total % of students per reading level
function getTotalNoOfStudent(listItems) {
  let sumPerRL = {};
  listItems.forEach(item => {
    if (sumPerRL[item.readingLevel] > -1) {
      sumPerRL[item.readingLevel] += item.value;
    } else {
      sumPerRL[item.readingLevel] = 0;
      sumPerRL[item.readingLevel] += item.value;
    }
  });

  return sumPerRL;
}


function recNotAvailable(payLoad) {
  let recNotFound = true

  if (payLoad.firstRecord['phrasing']) {
    recNotFound = false;
  }
  if (payLoad.recentRecord !== null) {
    recNotFound = false;
  }
  if (payLoad.allRecordsAverage !== null) {
    recNotFound = false;
  }
  if (payLoad.allRecordsAverage == null) {
    if (payLoad.recentRecord['phrasing'] !== null || payLoad.firstRecord['phrasing'] !== null) {
      recNotFound = false;
    } else {
      recNotFound = true
    }
  }
  if (payLoad.recentRecord == null) {
    if (payLoad.allRecordsAverage['phrasing'] !== null || payLoad.firstRecord['phrasing'] !== null) {
      recNotFound = false;
    } else {
      recNotFound = true
    }
  }
  return recNotFound
}

function monthDataConstruction(monthList) {
  let monthObj = monthList['monthlyRecordData'].map((month, idx) => {
    return { monthName: month['monthName'], index: idx, checked: true }
  })
  return monthObj
}

function selectedTab(state, action) {
  switch (action.payload) {
    case "fpot":
      return {
        ...state,
        FluencyTabSelection: {
          wcpm: false,
          fpot: true
        }
      };
    case "wcpm":
      return {
        ...state,
        FluencyTabSelection: {
          wcpm: true,
          fpot: false
        }
      };
  }
}