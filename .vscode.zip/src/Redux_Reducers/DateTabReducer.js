import { DateTabActionTypes } from "../Reducer_Action_Types/DateTabActionTypes";
import {
  U_S_Action_Types,
  GET_INITIAL_APPLICATION_DATA_SUCCESS,
  SAVE_CONTEXT_SELECTION,
  GET_DATE_TAB_RESULTS_SUCCESS,
  APPLY_FILTER_IN_DATE_TAB,
  RETURN_TO_PREVIOUS_REPORT_UNIVERSAL,
  GET_ROSTER_CLASSES_SUCCESS,
  GET_SUMMARYREPORTS_DEFAULT_SUCCESS,
  CHANGE_TERM_ON_RLP_DATA_FAIL,
  SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD,
  SEPARATE_ROSTER_TAB_DETAILS,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import {
  Student_ReportActionTypes,
  GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD,
} from "../Reducer_Action_Types/Student_ReportTypes";
import {
  Report_Action_Types,
  GET_STANDARDPERFORMANCE_DETAIL_SUCCESS,
  GET_CLASS_TESTSCORES_OVER_TIME_SUCCESS,
} from "../Reducer_Action_Types/ReportsActionTypes";
import { getMonthName } from "../Utils/DatePicker/helpers";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  School_Action_Types,
  GET_SCHOOL_STRAND_DETAILS_SUCCESS,
  GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS,
} from "../Reducer_Action_Types/School_Report_Types";
import {
  getDateTime,
  formatDate,
  getUTCDateTime,
  getTimeStampofUTCIfweHaveCurrentDate,
  GetBrowserName,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { GET_TESTSTATUS_SUMMARY_DATA_SUCCESS, GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS } from "../Reducer_Action_Types/TestStatus.Types";
import {
  GET_DISTRICT_STRAND_DETAILS_SUCCESS,
  GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS,
} from "../Reducer_Action_Types/District_Report_Types";
import { GET_CS_COMPARISIONTAB_DATA_SUCCESS } from "../Reducer_Action_Types/ComparisonTypes";
import { GET_SUMMARY_REPORTS_SUCCESS } from "../Reducer_Action_Types/SummaryActionsTypes";
import { ReturnTermStart_End_Dates_WithOutUTCFormat } from "../Utils/DatePicker/Month";
import { getCusrrentDistrictTerm, newDateHandling } from "../Components/ReusableComponents/AllReusableFunctions_Two";

const INITIAL_STATE = {
  callApplyDateTab_InDateTab_JS: false,
  Date_last_Active_Report_Props: {
    Selected_DateRange: "",
    Selected_Term: "",
    SelectedStartDate: "",
    SelectedEndDate: "",
    CheckStartOrEndDate: "Start Date",
    DefaultTerm: {},
    EndDateInDateTab: "",
    MonthsList: [],
    SelectedDateRange: "",
    SelectedDateRangeDate: "",
    SelectedDistrictTerm: {},
    SelectedEndMonth: "",
    SelectedEndMonthIndex: 12,
    SelectedStartMonth: "",
    SelectedStartMonthIndex: 0,
    StartDateInDateTab: "",
    TotalMonthsCount: 12,
    applyButtonEnable: false,
    openDatePicker: false,
  },
  Date_last_Active_Report_Props_TestStatus: {
    openDistrictTermDropdown: false,
    SelectedDistrictTerm: {},
    openDateRangeDropDown: false,
    applyButtonEnable: false,
    SelectedDateRange: "",
    SelectedDateRangeDate: "",
    DefaultTerm: {},
    openDatePicker: false,
    StartDateInDateTab: "",
    EndDateInDateTab: "",
    CheckStartOrEndDate: "",
    MonthsList: [],
    OpenMonthDropDown: false,
    SelectedStartMonth: "",
    SelectedEndMonth: "",
    SelectedStartMonthIndex: 0,
    SelectedEndMonthIndex: 0,
    TotalMonthsCount: 0,
  },
  DateTabComponents: {
    openDistrictTermDropdown: false,
    SelectedDistrictTerm: {},
    openDateRangeDropDown: false,
    applyButtonEnable: false,
    SelectedDateRange: "",
    SelectedDateRangeDate: "",
    DefaultTerm: {},
    openDatePicker: false,
    StartDateInDateTab: "",
    EndDateInDateTab: "",
    CheckStartOrEndDate: "Start Date",
    MonthsList: [],
    OpenMonthDropDown: false,
    SelectedStartMonth: "",
    SelectedEndMonth: "",
    SelectedStartMonthIndex: 0,
    SelectedEndMonthIndex: 0,
    TotalMonthsCount: 0,
    TermsListWithOutUTCFormat: [],
  },
  Context_DateTab: {
    openDistrictTermDropdown: false,
    SelectedDistrictTerm: {},
    openDateRangeDropDown: false,
    applyButtonEnable: false,
    SelectedDateRange: "",
    SelectedDateRangeDate: "",
    DefaultTerm: {},
    openDatePicker: false,
    StartDateInDateTab: "",
    EndDateInDateTab: "",
    CheckStartOrEndDate: "Start Date",
    MonthsList: [],
    OpenMonthDropDown: false,
    SelectedStartMonth: "",
    SelectedEndMonth: "",
    SelectedStartMonthIndex: 0,
    SelectedEndMonthIndex: 0,
    TotalMonthsCount: 0,
  },
  ORR_Context_DateTab: {
    openDistrictTermDropdown: false,
    SelectedDistrictTerm: {},
    openDateRangeDropDown: false,
    applyButtonEnable: false,
    SelectedDateRange: "",
    SelectedDateRangeDate: "",
    DefaultTerm: {},
    openDatePicker: false,
    StartDateInDateTab: "",
    EndDateInDateTab: "",
    CheckStartOrEndDate: "Start Date",
    MonthsList: [],
    OpenMonthDropDown: false,
    SelectedStartMonth: "",
    SelectedEndMonth: "",
    SelectedStartMonthIndex: 0,
    SelectedEndMonthIndex: 0,
    TotalMonthsCount: 0,
  },
  Context_DateTab_TestStatus: {
    openDistrictTermDropdown: false,
    SelectedDistrictTerm: {},
    openDateRangeDropDown: false,
    applyButtonEnable: false,
    SelectedDateRange: "District Term To Date",
    SelectedDateRangeDate: "",
    DefaultTerm: {},
    openDatePicker: false,
    StartDateInDateTab: "",
    EndDateInDateTab: "",
    CheckStartOrEndDate: "Start Date",
    MonthsList: [],
    OpenMonthDropDown: false,
    SelectedStartMonth: "",
    SelectedEndMonth: "",
    SelectedStartMonthIndex: 0,
    SelectedEndMonthIndex: 0,
    TotalMonthsCount: 0,
  },
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case GET_DATE_TAB_RESULTS_SUCCESS:
      return GET_DATE_TAB_RESULTS_SUCCESS_Redux_Fun(state, action);
    case DateTabActionTypes.RESET_CALLAPPLY_DATE_TAB_IN_DATETAB_JS_PROPS:
      return {
        ...state,
        callApplyDateTab_InDateTab_JS: false,
      };
    case CHANGE_TERM_ON_RLP_DATA_FAIL:
      return action.payload.ModifiedDateTabReducer;
    case GET_INITIAL_APPLICATION_DATA_SUCCESS:
    case GET_SUMMARYREPORTS_DEFAULT_SUCCESS:
      if (action.payload.Data == undefined || action.payload.Data == null) {
        return {
          ...state,
        };
      } else if (
        action.payload.Data == undefined ||
        action.payload.Data == null ||
        (action.payload.Data &&
          (action.payload.Data.rosterTestVO == null ||
            action.payload.Data.rosterTestVO == undefined) &&
          action.type == "GET_INITIAL_APPLICATION_DATA_SUCCESS")
      ) {
        return {
          ...state,
        };
      } else {
        let firstDefaultTerm =
          action.payload.Universal.ContextHeader.Date_Tab.DistrictTerms_New[0];
        const CheckEndDate =
          action.payload.Data.endDate === null
            ? CheckEndDateIsBeyondCurrentDate(firstDefaultTerm.termEndDate)
            : CheckEndDateIsBeyondCurrentDate(action.payload.Data.endDate);
        const monthsCountIndex =
          action.payload.Data.endDate === null
            ? MonthsBetweenyears(firstDefaultTerm.termStartDate, CheckEndDate)
                .length
            : MonthsBetweenyears(action.payload.Data.startDate, CheckEndDate)
                .length;
        const { districtTerms, termName, termRange, startDate, termId } =
          action.payload.Data;
        let SelectedDistrictTerm = null;
        if (
          termName != null &&
          termRange != null &&
          startDate != null &&
          termId != null
        ) {
          SelectedDistrictTerm = {
            termDates: districtTerms,
            termEndDate: CheckEndDate,
            termName: termName,
            termRange: termRange,
            termStartDate: startDate,
            termId: termId,
          };
        } else if (
          Object(state.DateTabComponents.SelectedDistrictTerm).length > 0
        ) {
          SelectedDistrictTerm = state.DateTabComponents.SelectedDistrictTerm;
        } else {
          SelectedDistrictTerm = {
            termDates: firstDefaultTerm.termDates,
            termEndDate: CheckEndDate,
            termName: firstDefaultTerm.termName,
            termRange: firstDefaultTerm.termRange,
            termStartDate: firstDefaultTerm.termStartDate,
            termId: firstDefaultTerm.termId,
          };
        }
        return {
          ...state,
          DateTabComponents: {
            ...state.DateTabComponents,
            SelectedDistrictTerm: SelectedDistrictTerm,
            DefaultTerm: SelectedDistrictTerm,
            SelectedEndMonthIndex: monthsCountIndex - 1,
            TotalMonthsCount: monthsCountIndex - 1,
          },
        };
      }
    /**
     * Set Date Range And Date Term After Get Success Response For report.
     */
    case GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD:
      let List_STrands = action.payload.response;
      return Set_Date_last_Active_Report_Props(state, List_STrands);

    case Student_ReportActionTypes.GET_STUDENTS_TESTSCORES_SUCCESS:
      let List_Student_TS =
        action.payload.ResponseData == null ? [] : action.payload.ResponseData;
      return Set_Date_last_Active_Report_Props(state, List_Student_TS);

    case GET_CLASS_TESTSCORES_OVER_TIME_SUCCESS:
      let List_Class_TS =
        action.payload.ResPayload == null ? [] : action.payload.ResPayload;
      return Set_Date_last_Active_Report_Props(state, List_Class_TS);

    case GET_STANDARDPERFORMANCE_DETAIL_SUCCESS:
      let List_Class_STrands =
        action.payload.Data == null ? [] : action.payload.Data;
      return Set_Date_last_Active_Report_Props(state, List_Class_STrands);

    case GET_SCHOOL_STRAND_DETAILS_SUCCESS:
      let List_School_STrands =
        action.payload.Data == null
          ? []
          : action.payload.Data == null
          ? []
          : action.payload.Data;
      return Set_Date_last_Active_Report_Props(state, List_School_STrands);

    case GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS:
      let List_Clss_Ts =
        action.payload.ResPayload == null ? [] : action.payload.ResPayload;
      return Set_Date_last_Active_Report_Props(state, List_Clss_Ts);

    case GET_SUMMARY_REPORTS_SUCCESS:
      let SummaryList = action.payload.ResPayload.summaryList;
      return Set_Date_last_Active_Report_Props(state, SummaryList);

    case RETURN_TO_PREVIOUS_REPORT_UNIVERSAL:
      let Last_Report = action.payload.Last_Active_Reports;
      let LastActive_Nav = Last_Report.NaviGation;
      let LastActiveDateTabs = LastActive_Nav.test_status
        ? { ...state.Date_last_Active_Report_Props_TestStatus }
        : { ...state.Date_last_Active_Report_Props };
      return {
        ...state,
        DateTabComponents: { ...LastActiveDateTabs },
        Context_DateTab_TestStatus:
          LastActive_Nav.test_status && LastActive_Nav.Assessement
            ? {
                ...state.Context_DateTab_TestStatus,
                SelectedDistrictTerm: LastActiveDateTabs.SelectedDistrictTerm,
                EndDateInDateTab:
                  LastActiveDateTabs.SelectedDistrictTerm.termEndDate,
                StartDateInDateTab:
                  LastActiveDateTabs.SelectedDistrictTerm.termStartDate,
              }
            : state.Context_DateTab_TestStatus,
        Context_DateTab:
          LastActive_Nav.test_status && LastActive_Nav.Assessement
            ? state.Context_DateTab
            : {
                ...state.Context_DateTab,
                SelectedDistrictTerm: LastActiveDateTabs.SelectedDistrictTerm,
                EndDateInDateTab:
                  LastActiveDateTabs.SelectedDistrictTerm.termEndDate,
                StartDateInDateTab:
                  LastActiveDateTabs.SelectedDistrictTerm.termStartDate,
              },
      };

    case DateTabActionTypes.DISTRICT_TERM_DROPDOWN_OPEN:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          openDistrictTermDropdown:
            !state.DateTabComponents.openDistrictTermDropdown,
          openDateRangeDropDown: false,
        },
      };

    case DateTabActionTypes.SELECTED_DISTRICT_TERM:
      const monthsCount = MonthsBetweenyears(
        action.payload.termStartDate,
        action.payload.termEndDate
      ).length;
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          openDistrictTermDropdown:
            !state.DateTabComponents.openDistrictTermDropdown,
          SelectedDistrictTerm: action.payload,
          SelectedStartMonth: "",
          SelectedEndMonth: "",
          StartDateInDateTab: action.payload.termStartDate,
          EndDateInDateTab: action.payload.termEndDate,
          SelectedDateRange: "District Term To Date",
          SelectedEndMonthIndex: monthsCount - 1,
          TotalMonthsCount: monthsCount - 1,
        },
      };

    case DateTabActionTypes.DATE_RANGE_DROPDOWN_OPEN:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          openDateRangeDropDown: !state.DateTabComponents.openDateRangeDropDown,
          openDistrictTermDropdown: false,
        },
      };

    case DateTabActionTypes.SELECTED_DATE_RANGE:
      let datevalue = action.payload.value;
      let SelectedOption = action.payload.checkState;
      let DateTime = getDateTime(datevalue);
      let { TemStartDate, TemEndDate } =
        ReturnTermStart_End_Dates_WithOutUTCFormat(state.DateTabComponents);
      let StartDate;
      let EndDate = TemEndDate; //state.DateTabComponents.SelectedDistrictTerm.termEndDate;
      if (
        SelectedOption == "District Term To Date" ||
        SelectedOption == "Custom Date Range"
      ) {
        StartDate = TemStartDate; // state.DateTabComponents.SelectedDistrictTerm.termStartDate;
      } else {
        StartDate = formatDate(DateTime) + " " + DateTime.split(" ")[1];
        let DateTime_Current = getUTCDateTime(new Date());
        let Formated = DateTime_Current;
        EndDate = new Date() < newDateHandling(EndDate) ? Formated : EndDate;
      }
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          openDateRangeDropDown: !state.DateTabComponents.openDateRangeDropDown,
          SelectedDateRange: action.payload.checkState,
          SelectedDateRangeDate: action.payload.value,
          StartDateInDateTab: StartDate,
          EndDateInDateTab: EndDate,
        },
      };

    case DateTabActionTypes.OPEN_DATE_PICKER_DATE_TAB:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          CheckStartOrEndDate: action.payload,
          openDatePicker:
            action.payload.value == "Start Date" ||
            action.payload.value == "End Date"
              ? true
              : !state.DateTabComponents.openDatePicker,
        },
      };

    case DateTabActionTypes.OPEN_MONTH_DROPDOWN_DATETAB:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          OpenMonthDropDown: !state.DateTabComponents.OpenMonthDropDown,
        },
      };
    case DateTabActionTypes.SELECTED_MONTH_DATETAB:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          OpenMonthDropDown: !state.DateTabComponents.OpenMonthDropDown,
          SelectedStartMonth:
            state.DateTabComponents.CheckStartOrEndDate == "Start Date"
              ? action.payload.value
              : state.DateTabComponents.SelectedStartMonth,
          SelectedEndMonth:
            state.DateTabComponents.CheckStartOrEndDate == "End Date"
              ? action.payload.value
              : state.DateTabComponents.SelectedEndMonth,
          SelectedStartMonthIndex:
            state.DateTabComponents.CheckStartOrEndDate == "Start Date"
              ? action.payload.number
              : state.DateTabComponents.SelectedStartMonthIndex,
          SelectedEndMonthIndex:
            state.DateTabComponents.CheckStartOrEndDate == "End Date"
              ? action.payload.number
              : state.DateTabComponents.SelectedEndMonthIndex,
        },
      };

    case DateTabActionTypes.CLICKED_LEFT_RIGHT_ARROWS_MONTHS_DATETAB:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          OpenMonthDropDown: false,
          SelectedStartMonth:
            state.DateTabComponents.CheckStartOrEndDate == "Start Date"
              ? action.payload.value
              : state.DateTabComponents.SelectedStartMonth,
          SelectedEndMonth:
            state.DateTabComponents.CheckStartOrEndDate == "End Date"
              ? action.payload.value
              : state.DateTabComponents.SelectedEndMonth,
          SelectedStartMonthIndex:
            state.DateTabComponents.CheckStartOrEndDate == "Start Date"
              ? action.payload.number
              : state.DateTabComponents.SelectedStartMonthIndex,
          SelectedEndMonthIndex:
            state.DateTabComponents.CheckStartOrEndDate == "End Date"
              ? action.payload.number
              : state.DateTabComponents.SelectedEndMonthIndex,
        },
      };

    case DateTabActionTypes.SET_AFTER_CLICK_DATE_IN_CALENDAR:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          StartDateInDateTab:
            action.payload.checkState == "Start Date"
              ? action.payload.value
              : state.DateTabComponents.StartDateInDateTab,
          EndDateInDateTab:
            action.payload.checkState == "End Date"
              ? action.payload.value
              : state.DateTabComponents.EndDateInDateTab,
          CheckStartOrEndDate: action.payload.checkState,
        },
      };

    case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:
      return INITIAL_STATE;
    /**
     * When Universal Selector Tabs Open.
     */
    case U_S_Action_Types.OPEN_UNIVERSAL_FILTER:
      if (action.payload.selectedModule == "date") {
        return Set_DateTabComponents_Props_To_Context_DateTab(state, action);
      } else {
        return {
          ...state,
        };
      }

    case SAVE_CONTEXT_SELECTION:
      return action.payload.modified_DateTabReducer;
    //SAVE_CONTEXT_SELECTION_Red_Func(state, action)

    case U_S_Action_Types.CLOSE_UNIVERSAL_FILTER:
      if (
        action.stateOfContext.Universal.NavigationByHeaderSelection.usageReport
      ) {
        return {
          ...state,
          DateTabComponents: {
            ...state.DateTabComponents,
            openDistrictTermDropdown: false,
            openDatePicker: false,
          },
        };
      }
      if (
        (action.payload == "date" ||
          action.payload == "OutSideUniversalClickRef") &&
        action.stateOfContext.Universal.UniversalFilter == "date"
      ) {
        let { test_status, ORR } =
          action.stateOfContext.Universal.NavigationByHeaderSelection;
        let Cont_DT = ORR
          ? state.ORR_Context_DateTab
          : test_status
          ? state.Context_DateTab_TestStatus
          : state.Context_DateTab;
        return {
          ...state,
          DateTabComponents: {
            ...state.DateTabComponents,
            openDistrictTermDropdown: Cont_DT.openDistrictTermDropdown,
            SelectedDistrictTerm: Cont_DT.SelectedDistrictTerm,
            openDateRangeDropDown: Cont_DT.openDateRangeDropDown,
            applyButtonEnable: Cont_DT.applyButtonEnable,
            SelectedDateRange: Cont_DT.SelectedDateRange,
            SelectedDateRangeDate: Cont_DT.SelectedDateRangeDate,
            DefaultTerm: Cont_DT.DefaultTerm,
            openDatePicker: Cont_DT.openDatePicker,
            StartDateInDateTab: Cont_DT.StartDateInDateTab,
            EndDateInDateTab: Cont_DT.EndDateInDateTab,
            CheckStartOrEndDate: Cont_DT.CheckStartOrEndDate,
            MonthsList: Cont_DT.MonthsList,
            OpenMonthDropDown: Cont_DT.OpenMonthDropDown,
            SelectedStartMonth: Cont_DT.SelectedStartMonth,
            SelectedEndMonth: Cont_DT.SelectedEndMonth,
            SelectedStartMonthIndex: Cont_DT.SelectedStartMonthIndex,
            SelectedEndMonthIndex: Cont_DT.SelectedEndMonthIndex,
            TotalMonthsCount: Cont_DT.TotalMonthsCount,
          },
        };
      }
      return {
        ...state,
      };

    case SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD:
      return {
        ...state,
        Date_last_Active_Report_Props: {
          ...state.Date_last_Active_Report_Props,
          SelectedDistrictTerm: state.DateTabComponents.SelectedDistrictTerm,
          DefaultTerm: state.DateTabComponents.DefaultTerm,
        },
        Context_DateTab: {
          ...state.Context_DateTab,
          DefaultTerm: state.DateTabComponents.DefaultTerm,
          SelectedDistrictTerm: state.DateTabComponents.SelectedDistrictTerm,
        },
      };

    case GET_ROSTER_CLASSES_SUCCESS:
      return {
        ...state,
        Date_last_Active_Report_Props: {
          ...state.Date_last_Active_Report_Props,
          SelectedDistrictTerm: state.DateTabComponents.SelectedDistrictTerm,
          DefaultTerm: state.DateTabComponents.DefaultTerm,
        },
      };

    case APPLY_FILTER_IN_DATE_TAB:
      return Set_DateTabComponents_Props_To_Context_DateTab(state, action);
    /**
     * Store Default Term Data.
     */
    case SEPARATE_ROSTER_TAB_DETAILS:
      return {
        ...state,
        DateTabComponents: {
          ...state.DateTabComponents,
          SelectedDistrictTerm: action.payload.DefaultTermObj,
          DefaultTerm: action.payload.DefaultTermObj,
        },
        Context_DateTab: {
          ...state.Context_DateTab,
          SelectedDistrictTerm: action.payload.DefaultTermObj,
          DefaultTerm: action.payload.DefaultTermObj,
        },
        Date_last_Active_Report_Props: {
          ...state.Date_last_Active_Report_Props,
          SelectedDistrictTerm: action.payload.DefaultTermObj,
          DefaultTerm: action.payload.DefaultTermObj,
        },
        ORR_Context_DateTab: {
          ...state.ORR_Context_DateTab,
          SelectedDistrictTerm: action.payload.DefaultTermObj,
          DefaultTerm: action.payload.DefaultTermObj,
        },
      };
case GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS:
    case GET_TESTSTATUS_SUMMARY_DATA_SUCCESS:
      return GET_TESTSTATUS_SUMMARY_DATA_SUCCESS_DATE_Red_Func(state, action);

    case GET_DISTRICT_STRAND_DETAILS_SUCCESS:
      let Nodata1 =
        action.payload.Data !== null && action.payload.Data !== undefined
          ? action.payload.Data.strands == null
            ? true
            : false
          : true;
      return API_CALLS_SUCCESS_DATE_Red_Func(state, Nodata1);

    case GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS:
      let Nodata2 =
        action.payload.ResPayload == null &&
        action.payload.ResPayload == undefined
          ? true
          : false;
      return API_CALLS_SUCCESS_DATE_Red_Func(state, Nodata2);

    case GET_CS_COMPARISIONTAB_DATA_SUCCESS:
      let Nodata3 =
        action.payload &&
        action.payload.PayloadData !== null &&
        action.payload.PayloadData !== undefined
          ? false
          : true;
      return API_CALLS_SUCCESS_DATE_Red_Func(state, Nodata3);

    default:
      return {
        ...state,
      };
  }
};

function GET_TESTSTATUS_SUMMARY_DATA_SUCCESS_DATE_Red_Func(state, action) {
  let dataSetType = action.type == "GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS" ? "testDataDetails" : "tests"
  let PayloadData = action.payload.ResPayload;
  PayloadData =
    PayloadData == undefined || PayloadData == null ? {} : PayloadData;
  let tests =  PayloadData[`${dataSetType}`];
  tests = tests == undefined || tests == null ? [] : tests;
  if (tests.length > 0) {
    return {
      ...state,
      Date_last_Active_Report_Props_TestStatus: {
        ...state.Context_DateTab_TestStatus,
      },
    };
  } else {
    return {
      ...state,
    };
  }
}

function API_CALLS_SUCCESS_DATE_Red_Func(state, Nodata) {
  if (Nodata) {
    return {
      ...state,
    };
  } else {
    return {
      ...state,
      Date_last_Active_Report_Props: { ...state.Context_DateTab },
    };
  }
}

/**
 *
 * @param {Object} state
 * @param {Array} List_STrands
 */
function Set_Date_last_Active_Report_Props(state, List_STrands) {
  if (List_STrands == null) {
    return {
      ...state,
    };
  } else {
    return {
      ...state,
      Date_last_Active_Report_Props: { ...state.DateTabComponents },
    };
  }
}

function CheckEndDateIsBeyondCurrentDate(endDate) {

  const browserName = GetBrowserName(navigator);
  if(browserName == "safari") {
    let endDatesArray = endDate && endDate.split(" ");
    if(endDatesArray && endDatesArray.length >0){
      endDate = endDatesArray[0];
    }
  }
  let endDateModified = newDateHandling(endDate);
  let datevalue = newDateHandling(endDateModified);
  let res_date = getTimeStampofUTCIfweHaveCurrentDate(datevalue);
  return res_date;
}

function MonthsBetweenyears(startDate, EndDate) {
  var Name_of_monthsList = [];
  const startYear = newDateHandling(startDate).getFullYear();
  const endYear = newDateHandling(EndDate).getFullYear();
  const StartYearForMonths = newDateHandling(startDate).getMonth();
  const EndYearForMonths = newDateHandling(EndDate).getMonth() + 1;
  var MonthAndYear = "";
  for (var i = startYear; i <= endYear; i++) {
    if (i == startYear) {
      for (var j = StartYearForMonths; j < 12; j++) {
        MonthAndYear = `${GetOnlyMonthName(j)} ${i}`;
        Name_of_monthsList.push(MonthAndYear);
      }
    } else if (i <= endYear) {
      if (i == endYear) {
        for (var k = 0; k < EndYearForMonths; k++) {
          MonthAndYear = `${GetOnlyMonthName(k)} ${i}`;
          Name_of_monthsList.push(MonthAndYear);
        }
      } else {
        for (var l = 0; l < 12; l++) {
          MonthAndYear = `${GetOnlyMonthName(l)} ${i}`;
          Name_of_monthsList.push(MonthAndYear);
        }
      }
    }
  }
  return Name_of_monthsList;
}

function GetOnlyMonthName(i) {
  const monthName = getMonthName(i);
  const monthCapital = monthName.toUpperCase();
  let displayMonthname = monthCapital.slice(0, 3);
  return displayMonthname;
}

function Set_DateTabComponents_Props_To_Context_DateTab(state, action) {
  let Nav = action.payload.Nav;
  Nav = Nav == undefined || Nav == null ? {} : Nav;
  let DT_Comp = state.DateTabComponents;
  let ContextData = Nav.Assessement
    ? JSON.parse(JSON.stringify(state.Context_DateTab))
    : JSON.parse(JSON.stringify(state.ORR_Context_DateTab));
  let Non_T_StatusContext = {
    ...ContextData,
    openDistrictTermDropdown: DT_Comp.openDistrictTermDropdown,
    SelectedDistrictTerm: DT_Comp.SelectedDistrictTerm,
    openDateRangeDropDown: DT_Comp.openDateRangeDropDown,
    applyButtonEnable: DT_Comp.applyButtonEnable,
    SelectedDateRange: DT_Comp.SelectedDateRange,
    SelectedDateRangeDate: DT_Comp.SelectedDateRangeDate,
    DefaultTerm: DT_Comp.DefaultTerm,
    openDatePicker: DT_Comp.openDatePicker,
    StartDateInDateTab: DT_Comp.StartDateInDateTab,
    EndDateInDateTab: DT_Comp.EndDateInDateTab,
    CheckStartOrEndDate: DT_Comp.CheckStartOrEndDate,
    MonthsList: DT_Comp.MonthsList,
    OpenMonthDropDown: DT_Comp.OpenMonthDropDown,
    SelectedStartMonth: DT_Comp.SelectedStartMonth,
    SelectedEndMonth: DT_Comp.SelectedEndMonth,
    SelectedStartMonthIndex: DT_Comp.SelectedStartMonthIndex,
    SelectedEndMonthIndex: DT_Comp.SelectedEndMonthIndex,
    TotalMonthsCount: DT_Comp.TotalMonthsCount,
  };
  return {
    ...state,
    DateTabComponents: {
      ...state.DateTabComponents,
      openDistrictTermDropdown: false,
      openDatePicker: false,
      openDateRangeDropDown: false,
    },
    Context_DateTab:
      (Nav.test_status && !Nav.ORR) || Nav.ORR
        ? {
            ...state.Context_DateTab,
          }
        : { ...Non_T_StatusContext },
    ORR_Context_DateTab: !Nav.ORR
      ? {
          ...state.ORR_Context_DateTab,
        }
      : { ...Non_T_StatusContext },
    Context_DateTab_TestStatus:
      Nav.test_status && Nav.Assessement
        ? {
            ...state.Context_DateTab_TestStatus,
            openDistrictTermDropdown: DT_Comp.openDistrictTermDropdown,
            SelectedDistrictTerm: DT_Comp.SelectedDistrictTerm,
            openDateRangeDropDown: DT_Comp.openDateRangeDropDown,
            applyButtonEnable: DT_Comp.applyButtonEnable,
            SelectedDateRange: DT_Comp.SelectedDateRange,
            SelectedDateRangeDate: DT_Comp.SelectedDateRangeDate,
            DefaultTerm: DT_Comp.DefaultTerm,
            openDatePicker: DT_Comp.openDatePicker,
            StartDateInDateTab: DT_Comp.StartDateInDateTab,
            EndDateInDateTab: DT_Comp.EndDateInDateTab,
            CheckStartOrEndDate: DT_Comp.CheckStartOrEndDate,
            MonthsList: DT_Comp.MonthsList,
            OpenMonthDropDown: DT_Comp.OpenMonthDropDown,
            SelectedStartMonth: DT_Comp.SelectedStartMonth,
            SelectedEndMonth: DT_Comp.SelectedEndMonth,
            SelectedStartMonthIndex: DT_Comp.SelectedStartMonthIndex,
            SelectedEndMonthIndex: DT_Comp.SelectedEndMonthIndex,
            TotalMonthsCount: DT_Comp.TotalMonthsCount,
          }
        : {
            ...state.Context_DateTab_TestStatus,
          },
  };
}

function GET_DATE_TAB_RESULTS_SUCCESS_Redux_Fun(state, action) {

  let { PayloadData, TemsDetailsWithOutUTCFormat } = action.payload;
  // PayloadData &&
  //   PayloadData.map((item) => {
  //     if (SelectedDistrictTerm.termId == undefined) {
  //       SelectedDistrictTerm = item;
  //     } else if (SelectedDistrictTerm.termId < item.termId) {
  //       SelectedDistrictTerm = item;
  //     }
  //   });
  let SelectedDistrictTerm = getCusrrentDistrictTerm(PayloadData) || {}
  const CheckEndDate = CheckEndDateIsBeyondCurrentDate(
    SelectedDistrictTerm.termEndDate
  );
  const monthsCountIndex = MonthsBetweenyears(
    SelectedDistrictTerm.termStartDate,
    CheckEndDate
  ).length;
  SelectedDistrictTerm.termEndDate = CheckEndDate;
  return {
    ...state,
    Context_DateTab_TestStatus: {
      ...state.Context_DateTab_TestStatus,
      SelectedDistrictTerm: SelectedDistrictTerm,
      DefaultTerm: SelectedDistrictTerm,
      SelectedEndMonthIndex: monthsCountIndex - 1,
      TotalMonthsCount: monthsCountIndex - 1,
    },
    DateTabComponents: {
      ...state.DateTabComponents,
      TermsListWithOutUTCFormat: TemsDetailsWithOutUTCFormat,
    },
    Context_DateTab: {
      ...state.Context_DateTab,
      TermsListWithOutUTCFormat: TemsDetailsWithOutUTCFormat,
    },
    Date_last_Active_Report_Props_TestStatus: {
      ...state.Date_last_Active_Report_Props_TestStatus,
      TermsListWithOutUTCFormat: TemsDetailsWithOutUTCFormat,
    },
    Date_last_Active_Report_Props: {
      ...state.Date_last_Active_Report_Props,
      TermsListWithOutUTCFormat: TemsDetailsWithOutUTCFormat,
    },
    ORR_Context_DateTab: {
      ...state.ORR_Context_DateTab,
      TermsListWithOutUTCFormat: TemsDetailsWithOutUTCFormat,
    },
    Context_DateTab: {
      ...state.Context_DateTab,
      TermsListWithOutUTCFormat: TemsDetailsWithOutUTCFormat,
    },
  };
}

function SAVE_CONTEXT_SELECTION_Red_Func(state, action) {
  if (action.payload.selectionoption == "test_status") {
    let CurrentTermis =
      action.payload.Modified_State.last_Active_Report_Props
        .Date_TabFullDetails[0];
    state.Context_DateTab_TestStatus.DefaultTerm = CurrentTermis;
    state.Context_DateTab_TestStatus.SelectedDistrictTerm = CurrentTermis;
    return {
      ...state,
      DateTabComponents: JSON.parse(
        JSON.stringify(state.Context_DateTab_TestStatus)
      ),
    };
  } else if (
    action.payload.Nav.test_status &&
    (action.payload.selectionoption == "S_performance" ||
      action.payload.selectionoption == "T_scores")
  ) {
    return {
      ...state,
      DateTabComponents: JSON.parse(JSON.stringify(state.Context_DateTab)),
    };
  } else
    return {
      ...state,
    };
}
