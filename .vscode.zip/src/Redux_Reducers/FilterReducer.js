import { FilterActionTypes } from '../Reducer_Action_Types/FilterActionTypes';
import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';
const INITIAL_STATE = {
  Axis_chart: {
    assignmentList: [],
    dateRange: [],
    readingLevelAxis: []
  }
};

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case FilterActionTypes.POST_FILTER_DATA_SUCCESS:
      return {
        ...state,
        Response: action.payload.SUCCESSFULL,
        Axis_chart: {
          assignmentList: action.payload.responseData.assignmentDataList,
          dateRange: action.payload.responseData.dateRangeAxis,
          readingLevelAxis: action.payload.responseData.readingLevelAxis,
          accuracyAxis: action.payload.responseData.accuracyAxis,
          accuracyDataList: action.payload.responseData.accuracyDataList,
          fluencyAxis: action.payload.responseData.fluencyAxis,
          fluencyDataList: action.payload.responseData.fluencyDataList,
          studentStartingLevel:
            action.payload.responseData.studentStartingLevel,
          studentReadingTarget: action.payload.responseData.studentReadingTarget
        }
      };

    case FilterActionTypes.POST_FILTER_DATA_FAIL:
      return {
        ...state,
        Response: action.payload
      };

    case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:

      return INITIAL_STATE

    default:
      return {
        ...state
      };
  }
};
