import {
  Report_Action_Types,
  MOVE_BUBBLES_OF_PAGINATION_FOR_REMAINING,
  CHANGE_BUBBLE_OF_PAGINATION_FOR_REMAINIG,
  GET_STUDENTS_OF_A_CLASS_STRAND_SUCCESS,
  GET_STANDARDPERFORMANCE_DETAIL_SUCCESS,
  CHANGE_TOGGLE_IN_SP_OVERVIEW_COMPONENT,
  GET_CLASS_TESTSCORES_OVER_TIME_SUCCESS,
} from "../Reducer_Action_Types/ReportsActionTypes";
import { LastActive_Reports } from "./Reducers.props";

const INITIAL_STATE = {
  District_Report: LastActive_Reports,
  School_Report: LastActive_Reports,
  Class_Report: LastActive_Reports,
  Student_Report: LastActive_Reports,
  District_TestStaus: JSON.parse(JSON.stringify(LastActive_Reports)),
  School_TestStaus: JSON.parse(JSON.stringify(LastActive_Reports)),
  Class_TestStaus: JSON.parse(JSON.stringify(LastActive_Reports)),
  Student_TestStaus: JSON.parse(JSON.stringify(LastActive_Reports)),
  SummaryReports_District: JSON.parse(JSON.stringify(LastActive_Reports)),
  SummaryReports_School: JSON.parse(JSON.stringify(LastActive_Reports)),
  SummaryReports_Class: JSON.parse(JSON.stringify(LastActive_Reports)),
  NaviGation: {},
  report_startDate: "",
  report_EndDate: "",
  RosterTabFullDetails: [],
  Date_TabFullDetails: [],
};
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD,
  Student_ReportActionTypes,
} from "../Reducer_Action_Types/Student_ReportTypes";
import {
  APPLY_FILTER_IN_DATE_TAB,
  GET_DATE_TAB_RESULTS_SUCCESS,
  GET_INITIAL_APPLICATION_DATA_SUCCESS,
  GET_ROSTERTAB_COMPLETE_DATA_SUCCESS,
  GET_ROSTER_GRADES_AND_SCHOOLS_SUCCESS,
  GET_SUMMARYREPORTS_DEFAULT_SUCCESS,
  GET_TEST_TAB_RESULTS_SUCCESS,
  SAVE_CONTEXT_SELECTION,
  SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD,
  SAVE_SELECTED_SCHOOL_API_SUCCESS,
  SEPARATE_ROSTER_TAB_DETAILS,
  U_S_Action_Types,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import {
  GET_DISTRICT_STRAND_DETAILS_SUCCESS,
  GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS,
  GET_SELECTED_TS_DETAILS_SUCCESS_IN_DISTRICT,
} from "../Reducer_Action_Types/District_Report_Types";
import {
  GET_TESTSTATUS_SUMMARY_DATA,
  GET_TESTSTATUS_SUMMARY_DATA_SUCCESS,
  GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS,
} from "../Reducer_Action_Types/TestStatus.Types";
import { GET_SUMMARY_REPORTS_SUCCESS } from "../Reducer_Action_Types/SummaryActionsTypes";
import { GET_SINGLE_TEST_ANALYSIS_DATA_SUCCESS } from "../Reducer_Action_Types/ST_AnalysisTypes";
import {
  GET_SCHOOL_STRAND_DETAILS_SUCCESS,
  GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS,
} from "../Reducer_Action_Types/School_Report_Types";
import {
 SUMMARY_TESTSTATUS_API_SUCCESS
} from "../Reducer_Action_Types/summaryReports_Action_Types";
import { GET_CS_COMPARISIONTAB_DATA_SUCCESS } from "../Reducer_Action_Types/ComparisonTypes";
export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    // case U_S_Action_Types.GET_INITIAL_APPLICATION_DATA:
    //     return INITIAL_STATE;

    case AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS:
      return INITIAL_STATE;

    case GET_SUMMARYREPORTS_DEFAULT_SUCCESS:
      return action.payload.updatedLastActivePropsState;
    case SUMMARY_TESTSTATUS_API_SUCCESS:
        return action.payload.updatedLastActivePropsState;

    case GET_INITIAL_APPLICATION_DATA_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD:
      return action.payload.updatedLastActivePropsState;

    case GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD:
      return action.payload.updatedLastActivePropsState;

    case Student_ReportActionTypes.GET_STUDENTS_TESTSCORES_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS:
    case GET_SELECTED_TS_DETAILS_SUCCESS_IN_DISTRICT:
      return action.payload.updatedLastActivePropsState;

    case GET_DISTRICT_STRAND_DETAILS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_ROSTER_GRADES_AND_SCHOOLS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_STANDARDPERFORMANCE_DETAIL_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_CLASS_TESTSCORES_OVER_TIME_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_TEST_TAB_RESULTS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_ROSTERTAB_COMPLETE_DATA_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case SEPARATE_ROSTER_TAB_DETAILS:
      return action.payload.updatedLastActivePropsState;

    case GET_TESTSTATUS_SUMMARY_DATA_SUCCESS:
      return action.payload.updatedLastActivePropsState;
    case GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_DATE_TAB_RESULTS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case APPLY_FILTER_IN_DATE_TAB:
      return action.payload.updatedLastActivePropsState;

    case GET_SUMMARY_REPORTS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_SINGLE_TEST_ANALYSIS_DATA_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case SAVE_SELECTED_SCHOOL_API_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_SCHOOL_STRAND_DETAILS_SUCCESS:
      return action.payload.updatedLastActivePropsState;

    case GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS:
      return action.payload.updatedLastActivePropsState;
    case GET_CS_COMPARISIONTAB_DATA_SUCCESS:
        return action.payload.updatedLastActivePropsState;
    case SAVE_CONTEXT_SELECTION:
      return action.payload.updatedLastActivePropsState? action.payload.updatedLastActivePropsState : {...state}
    default:
      return {
        ...state,
      };
  }
};
