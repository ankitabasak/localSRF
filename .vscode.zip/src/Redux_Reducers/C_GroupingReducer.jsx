import { C_GroupingTypes } from '../Reducer_Action_Types/C_GroupingTypes.jsx';

export const INITIAL_STATE = {
  showGrouping: false,
  groupUpdateSuccess: false,
  groupUpdateFailed: false,
  showSpinner: false,
  SortData: {
    sortColumn: '',
    sortType: ''
  }
}

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case C_GroupingTypes.CLASS_GROUPING_TOGGLE:
      return {
        ...state,
        showGrouping: action.payload
      }
    case C_GroupingTypes.START_SPINNER:
      return {
        ...state,
        showSpinner: true
      }
    case C_GroupingTypes.GROUPING_GRID_SORT_COLUMN:
      return {
        ...state,
        SortData: {
          sortColumn: action.payload.sortColumn,
          sortType: action.payload.sortType
        }
      };

    case C_GroupingTypes.SAVED_GROUPING_DATA_SUCCESS:
      return {
        ...state,
        showSpinner: false,
        ...action.payload,
        groupUpdateFailed: false
      };

    case C_GroupingTypes.SAVED_GROUPING_DATA_FAILURE:
      return {
        ...state,
        showSpinner: false,
        groupUpdateFailed: true,
        groupUpdateSuccess: false
      };
    case C_GroupingTypes.SAVED_GROUPING_DATA_FAILURE_RESET:

      return {
        ...state,
        showSpinner: false,
        groupUpdateFailed: false
      };
    default:
      return {
        ...state
      };
  }

}