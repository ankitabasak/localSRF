export const C_GroupingTypes = {
  CLASS_GROUPING_TOGGLE: 'class_grouping_toggle',
  SAVED_GROUPING_DATA_SUCCESS: 'saved_grouping_data_success',
  START_SPINNER: 'start_spinner',
  SAVED_GROUPING_DATA_FAILURE: 'saved_grouping_data_failure',
  SAVED_GROUPING_DATA_FAILURE_RESET: 'saved_grouping_data_failure_reset',
  GROUPING_GRID_SORT_COLUMN: 'grouping_grid_sort_column'
};