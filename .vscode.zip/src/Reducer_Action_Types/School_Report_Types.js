export const School_Action_Types = {
  GET_SCHOOL_STRANDS_GRADES: "GET_SCHOOL_STRANDS_GRADES",

  GET_SCHOOL_STRANDS_QUESTION_COUNT_FAIL:
    "get_school_strands_question_count_fail",

  COMPARE_CHECKBOX_OPTION_FOR_SCHOOL_LC:
    "compare_checkbox_option_for_school_lc",
  OPEN_OR_CLOSE_TOOLTIP_IN_S_SP_OT: "open_or_close_tooltip_in_s_sp_ot",

  SAVE_SORTED_CLASS_DETAILS_LIST: "save_sorted_class_details_list",
  SAVE_SORTED_CLASS_DETAILS_LIST_BY_HEADER:
    "save_sorted_class_details_list_by_header",

  MOVE_HEADER_IN_SCHOOL_STRANDS_TABLE: " move_header_in_school_strands_table̥",

  OPEN_OR_CLOSE_STRANDS_GRADES_LIST: "open_or_close_strands_grades_list̥",
  OPEN_OR_CLOSE_STRANDS_QUESTIONS_LIST: "open_or_close_strands_questionslist̥",

  GET_CLASS_DETAILS_ON_STRAND_SELECTION:
    "get_class_details_on_strand_selection",
  GET_CLASS_DETAILS_ON_STRAND_SELECTION_FAIL:
    "get_class_details_on_strand_selection_fail",

  GET_LINECHART_DATA_OF_SCHOOL_STRANDS: "get_linechart_data_of_school_strands̥",
  GET_LINECHART_DATA_OF_SCHOOL_STRANDS_SUCCESS:
    "get_linechart_data_of_school_strands_success̥",
  GET_LINECHART_DATA_OF_SCHOOL_STRANDS_FAIL:
    "get_linechart_data_of_school_strands_fail",

  GET_SCHOOL_TS_GRAPH_DETAILS: "get_school_ts_graph_details",
  GET_SCHOOL_TS_GRAPH_DETAILS_FAIL: "get_school_ts_graph_details_fail",

  GET_SELECTED_TS_CLASS_INFO_FAIL_IN_SCHOOL:
    "get_selected_ts_class_info_fail̥_in_school",

  CLOSE_TOOL_TIP_POPUP_IN_SC_REPORT: "close_tool_tip_popup_in_sc_report̥",

  CHANGE_LINE_CHART_PAGINATION_BUBBLE_SCHOOL:
    "change_line_chart_pagination_bubble_school̥",

  MOVE_LINE_CHART_PAGINATIO_BUBBLE_IN_SCHOOL:
    "move_line_chart_paginatio_bubble_in_dist̥",

  OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_SCHOOL:
    "open_or_close_taxonomy_dropdown_school",
  SELECTED_TEST_TAXONOMY_DROPDOWN_SCHOOL:
    "selected_test_taxonomy_dropdown_school",
};

export const SET_TOOLTIP_AND_BAR_VALUE_ = "set_tooltip_and_bar_value_in_school̥";
export const GET_SCHOOL_STRANDS_QUESTION_COUNT =
  "GET_SCHOOL_STRANDS_QUESTION_COUNT";
export const GET_SCHOOL_STRANDS_QUESTION_COUNT_SUCCESS =
  "GET_SCHOOL_STRANDS_QUESTION_COUNT_SUCCESS";
export const SELECTED_TEST_GRADE_DROPDOWN_IN_SCHOOL =
  "SELECTED_TEST_GRADE_DROPDOWN_IN_SCHOOL";
export const GET_SCHOOL_STRAND_DETAILS = "GET_SCHOOL_STRAND_DETAILS";

export const GET_SCHOOL_STRAND_DETAILS_SUCCESS =
  "GET_SCHOOL_STRAND_DETAILS_SUCCESS";

export const GET_SCHOOL_STRANDS_GRADES_SUCCESS =
  "GET_SCHOOL_STRANDS_GRADES_SUCCESS";
export const SELECTED_TEST_ASSESSED_DROPDOWN_IN_SCHOOL =
  "SELECTED_TEST_ASSESSED_DROPDOWN_IN_SCHOOL";
export const GET_CLASS_DETAILS_ON_STRAND_SELECTION_SUCCESS =
  "GET_CLASS_DETAILS_ON_STRAND_SELECTION_SUCCESS";
export const GET_SELECTED_TS_CLASS_INFO_IN_SCHOOL =
  "get_selected_ts_class_info̥_in_school";
export const GET_SCHOOL_STRAND_DETAILS_FAIL = "GET_SCHOOL_STRAND_DETAILS_FAIL";
export const CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_SCHOOL_REPORT =
  "CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_SCHOOL_REPORT";
export const GET_SELECTED_TS_CLASS_INFO_SUCCESS_IN_SCHOOL =
  "GET_SELECTED_TS_CLASS_INFO_SUCCESS_IN_SCHOOL";
export const GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS =
  "get_school_ts_graph_details_success";
  export const SUMMARY_DRILLDOWN_TAXONAMY_PERSIST_CLEANUP =
  "SUMMARY_DRILLDOWN_TAXONAMY_PERSIST_CLEANUP";
  
