export const District_ReadingHistoryTypes = {
  DISTRICT_READING_HISTORY_DATA: 'district_reading_history_data',
  DISTRICT_READING_HISTORY_DATA_SUCCESS: 'district_reading_history_success_data',
  DISTRICT_READING_HISTORY_DATA_FAIL: 'district_reading_history_data_fail',
  DISTRICT_READING_HISTORY_COLUMN: 'district_reading_history_column',
  DISTRICT_SAVE_SORTED_DISTRICT_READING_HISTORY_DATA:
    'district_save_sorted_DISTRICT_reading_history_data',
  DRH_ERROR_HANDLING: 'drh_error_handling',
  DISTRICT_CLASS_NAME: 'district_class_name',
  DISTRICT_RHO_SORT_COLUMN: 'district_rho_sort_column',
  DISTRICT_RHO_SAVE_SORT_ARRAY: 'district_rho_save_sort_array',
  DSTRHO_CSVDATA_DOWNLOAD_APICALL: 'dstrho_csvdata_download_apicall',
  DSTRHO_CSVDATA_DOWNLOAD_SUCCESS: 'dstrho_csvdata_download_SUCCESS',
  DSTRHO_CSVDATA_DOWNLOAD_RESET: 'dstrho_csvdata_download_reset',

  DISTRICT_RHO_SCHOOL_NAMES_SUCCESS: 'district_rho_school_names_success',
  DISTRICT_RHO_SCHOOL_NAMES_FAIL: 'district_rho_school_names_fail',
  DISTRICT_RHO_SINGLE_SCHOOL_SUCCESS: 'district_rho_single_school_success',
  DISTRICT_RHO_SINGLE_SCHOOL_FAIL: 'district_rho_single_school_fail',
};
