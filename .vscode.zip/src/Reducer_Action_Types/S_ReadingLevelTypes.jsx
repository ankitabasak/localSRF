export const StudentRlpTypes = {
  S_READING_LEVEL_API_SUCCESS: 's_reading_level_api_success',
  S_READING_LEVEL_API_FAIL: 's_reading_level_api_fail',
  S_SHOW_POPUP: 's_show_popup',
  S_READING_LEVEL_CHART_YAXIS_SCROLL: 's_reading_level_chart_yaxis_scroll',
  S_READING_LEVEL_CHART_XAXIS_SCROLL: 's_reading_level_chart_xaxis_scroll',
  S_SUMRLP_CHART_YAXIS_SCROLL: 's_sumrlp_chart_yaxis_scroll',
  S_SUMRLP_CHART_XAXIS_SCROLL: 's_sumrlp_chart_xaxis_scroll',
  SRLP_CHART_ENABLED: 'srlp_chart_enabled',
  SRLP_CSVDATA_DOWNLOAD_APICALL: 'srlp_csvdata_download_apicall',
  SRLP_CSVDATA_DOWNLOAD_SUCCESS: 'srlp_csvdata_download_SUCCESS',
  SRLP_CSVDATA_DOWNLOAD_RESET: 'srlp_csvdata_download_reset',
  SRLP_UPDATE_TOOLTIP_DATA: 'srlp_update_tooltip_data',
  STUDENT_LOADING_ICON: 'student_loading_icon',
  SRLP_UPDATE_TOOLTIP_DATA_PRINT: 'srlp_update_tooltip_data_print'
};
