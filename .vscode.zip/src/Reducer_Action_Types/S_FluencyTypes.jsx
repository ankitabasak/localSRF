export const S_FluencyTypes = {
  S_FLUENCY_DATA_SUCCESS: 's_fluency_data_success',
  S_FLUENCY_DATA_FAIL: 's_fluency_data_fail',
  LOAD_ICON: 'load_icon',
  SFA_XAXIS_SCROLL: 'sfa_xaxis_scroll',
  SHOW_OVERLAY_FLAG: 'show_overlay_flag',
  SFA_UPDATE_TOOLTIP_DATA: 'sfa_update_tooltip_data',
  S_FLUENCY_RUBRIC_FAIL: 's_fluency_rubric_fail',
  SFA_LOADER: 'sfa_loader',
  SF_CSVDATA_DOWNLOAD_APICALL: 'sf_csvdata_download_apicall',
  SF_CSVDATA_DOWNLOAD_SUCCESS: 'sf_csvdata_download_SUCCESS',
  SF_CSVDATA_DOWNLOAD_RESET: 'sf_csvdata_download_reset',
};
