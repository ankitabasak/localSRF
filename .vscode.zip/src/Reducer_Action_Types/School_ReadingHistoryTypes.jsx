export const School_ReadingHistoryTypes = {
  SCHOOL_READING_HISTORY_DATA: 'school_reading_history_data',
  SCHOOL_READING_HISTORY_DATA_SUCCESS: 'school_reading_history_success_data',
  SCHOOL_READING_HISTORY_DATA_FAIL: 'school_reading_history_data_fail',
  SCHOOL_READING_HISTORY_COLUMN: 'school_reading_history_column',
  SCHOOL_SAVE_SORTED_SCHOOL_READING_HISTORY_DATA:
    'school_save_sorted_school_reading_history_data',
  SRH_ERROR_HANDLING: 'srh_error_handling',
  SCHOOL_CLASS_NAME: 'school_class_name',
  SCHOOL_RHO_SORT_COLUMN: 'school_rho_sort_column',
  SCHOOL_RHO_SAVE_SORT_ARRAY: 'school_rho_save_sort_array',
  SAVE_SORTED_SCRLP_DATA: 'save_sorted_scrlp_data',
  SCRLP_GRID_SORT_COLUMN: 'scrlp_grid_sort_column',
  SCRHO_CSVDATA_DOWNLOAD_APICALL: 'scrho_csvdata_download_apicall',
  SCRHO_CSVDATA_DOWNLOAD_SUCCESS: 'scrho_csvdata_download_SUCCESS',
  SCRHO_CSVDATA_DOWNLOAD_RESET: 'scrho_csvdata_download_reset',
};