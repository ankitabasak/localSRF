export const ErrorAnalysisActionTypes = {
  ERROR_ANALYSIS_STUDENT_DATA: 'error_analysis_student_data',
  ERROR_ANALYSIS_STUDENT_DATA_SUCCESS: 'error_analysis_student_data_success',
  ERROR_ANALYSIS_STUDENT_DATA_FAIL: 'error_analysis_student_data_fail',
  SCROLL_DATA: 'scroll_data',
  ICON_UPDATE: 'icon_update',
  TIME_OUT: 'time_out,',
  SEA_ERROR_HANDLING: 'sea_error_handling',
  PIE_CHART_STATE_UPDATE: 'pie_chart_state_update',
  SEA_LOADER: 'sea_loader',
  SEA_CSVDATA_DOWNLOAD_APICALL: 'sea_csvdata_download_apicall',
  SEA_CSVDATA_DOWNLOAD_SUCCESS: 'sea_csvdata_download_SUCCESS',
  SEA_CSVDATA_DOWNLOAD_RESET: 'sea_csvdata_download_reset',
};
