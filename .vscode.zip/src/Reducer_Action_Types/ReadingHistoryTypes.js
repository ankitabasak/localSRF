export const ReadingHistoryTypes = {
  READING_HISTORY_STUDENT_DATA: 'reading_history_student_data',
  READING_HISTORY_DATA_SUCCESS: 'reading_history_success_data',
  READING_HISTORY_DATA_FAIL: 'reading_history_data_fail',
  READING_HISTORY_COLUMN: 'reading_history_column',
  SAVE_SORTED_S_READING_HISTORY_DATA: 'save_sorted_s_reading_history_data',
  SRH_ERROR_HANDLING: 'srh_error_handling',
  SRH_LOADER: 'srh_loader',
  SRH_CSVDATA_DOWNLOAD_APICALL: 'srh_csvdata_download_apicall',
  SRH_CSVDATA_DOWNLOAD_SUCCESS: 'srh_csvdata_download_SUCCESS',
  SRH_CSVDATA_DOWNLOAD_RESET: 'srh_csvdata_download_reset',
};
