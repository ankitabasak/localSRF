export const FilterActionTypes = {
  GET_SELECTED_DATA: 'get_selected_data',
  POST_FILTER_DATA_SUCCESS: 'post_filter_data_success',
  POST_FILTER_DATA_FAIL: 'post_filter_data_fail'
};
