export const Sc_EaTypes = {
  SCHOOL_EA_DATA_SUCCESS: 'school_ea_data_success',
  SCHOOL_EA_DATA_FAIL: 'school_ea_data_fail',
  SCHOOL_EA_GRID_TABLE_SUCCESS: 'school_ea_grid_table_success',
  SCHOOL_EA_GRID_TABLE_FAIL: 'school_ea_grid_table_fail',
  SCHOOL_EA_SORT_COLUMN: 'school_ea_sort_column',
  SCEA_SORTED_DATA: 'save_sorted_data',
  UPDATE_SELECTED_ERRORS: 'update_selected_errors',
  STATUS_LOAD_ICON: 'status_load_icon',
  UPDATE_RECORD_TYPE: 'update_record_type',
  SCHOOL_EA_DROPDOWN_SUCCESS: 'school_ea_dropdown_success',
  SCHOOL_EA_DROPDOWN_FAIL: 'school_ea_dropdown_fail',
  SCHOOL_EA_CLASS_NAME: 'school_ea_class_name',
  SCHOOL_EA_SELECTED_GRADE: 'school_ea_selected_grade',
  SEA_CSVDATA_DOWNLOAD_APICALL: 'sea_csvdata_download_apicall',
  SEA_CSVDATA_DOWNLOAD_SUCCESS: 'sea_csvdata_download_SUCCESS',
  SEA_CSVDATA_DOWNLOAD_RESET: 'sea_csvdata_download_reset',
  SCL_GRADES_NOT_AVAILABLE: 'scl_grades_not_available'
};
