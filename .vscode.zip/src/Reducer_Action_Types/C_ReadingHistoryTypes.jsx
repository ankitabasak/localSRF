export const C_ReadingHistoryTypes = {
  CLASS_READING_HISTORY_DATA: 'class_reading_history_data',
  CLASS_READING_HISTORY_DATA_SUCCESS: 'class_reading_history_success_data',
  CLASS_READING_HISTORY_DATA_FAIL: 'class_reading_history_data_fail',
  CLASS_READING_HISTORY_COLUMN: 'class_reading_history_column',
  CLASS_SAVE_SORTED_CLASS_READING_HISTORY_DATA:
    'class_save_sorted_class_reading_history_data',
  CRH_ERROR_HANDLING: 'crh_error_handling',
  CRH_CSVDATA_DOWNLOAD_APICALL: 'crh_csvdata_download_apicall',
  CRH_CSVDATA_DOWNLOAD_SUCCESS: 'crh_csvdata_download_SUCCESS',
  CRH_CSVDATA_DOWNLOAD_RESET: 'crh_csvdata_download_reset',
};
