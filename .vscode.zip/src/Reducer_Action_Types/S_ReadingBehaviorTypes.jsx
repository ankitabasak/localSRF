export const S_RBTypes = {
  S_READING_BEHAVIOR_API_SUCCESS: 's_reading_behavior_api_success',
  S_READING_BEHAVIOR_API_FAIL: 's_reading_behavior_api_fail',
  SHOW_RUBRIC_DATA: 'show_rubric_data',
  SRB_EH: 'srb_eh',
  SRB_DATA_SCROLL: 'srb_data_scroll',
  SRB_RUBRIC_FAIL: 'srb_rubric_fail',
  SRB_LOADER: 'srb_loader',
  SRB_CSVDATA_DOWNLOAD_APICALL: 'srb_csvdata_download_apicall',
  SRB_CSVDATA_DOWNLOAD_SUCCESS: 'srb_csvdata_download_SUCCESS',
  SRB_CSVDATA_DOWNLOAD_RESET: 'srb_csvdata_download_reset',
};
