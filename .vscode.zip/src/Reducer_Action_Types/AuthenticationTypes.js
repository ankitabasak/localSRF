export const AuthActionTypes = {
    POST_CREATE_JWT_TOKEN: 'post_create_jwt_token',
    POST_CREATE_JWT_TOKEN_SUCCESS: 'post_create_jwt_token_success',
    POST_CREATE_JWT_TOKEN_FAIL: 'post_create_jwt_token_fail',
    TAKE_ME_BACK_IN_NODATA_COMP: 'take_me_back_in_nodata_comp̥',
    DISPLAY_NO_DATA_COMPO: 'display_no_data_compo̥',
    SAVE_USERNAME_AND_PASSWORD: 'save_username_and_password̥',
    TECHNICAL_ISSUE_ERROR: 'technical_issue_error̥',
    RESET_REDUCERS_STATE_IN_ALL_REDUCERS: 'RESET_REDUCERS_STATE_IN_ALL_REDUCERS',
    ERROR_LOG: 'ERROR_LOG',
    ERROR_LOG_SUCCESS: 'ERROR_LOG_SUCCESS',
    TRACKING_USAGE:"TRACKING_USAGE"
    
};

export const API_FAILS = "API_FAILS";

