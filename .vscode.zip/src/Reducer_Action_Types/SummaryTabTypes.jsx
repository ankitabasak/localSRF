export const SummaryTypes = {
    SHOW_SUMMARY_TAB: 'show_summary_tab',
    CLOSE_SUMMARY_TAB: 'close_summary_tab'
}