import { SpotPrintTypes } from "../Reducer_Action_Types/SpotPrintTypes";
import { U_S_Action_Types } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { api_request_headers, Base_URL, DistrictAGPCSV, DistrictCSVDownload, Get_BatchPrint_StudentList, SPOT_PDF_DOWNLOAD, student_SPOT_pdf } from "../Utils/globalVars";
import axios from "axios";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { Return_ERROR_Status_Code, getRequiredDataFromPersist } from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog, trackingUsage } from "./AuthenticationAction";
//import FileSaver from 'file-saver';
export const SpotPrintingPopupStatus = (taxoList,selectedStrandStandard,isStrand, isDefinitionSelected) => {
    return (dispatch,getState) => {
        let batch_options = getRequiredDataFromPersist("batch_options", getState());
        let Nav = getState().Universal.NavigationByHeaderSelection;
        const context = Nav.student ? "student" : Nav.class ? "class" : Nav.school ? "school" : "district";
        dispatch({
            type: SpotPrintTypes.SPOT_PRINTING_POPUP_STATUS,
            payload: { taxoList,selectedStrandStandard,isStrand,batch_options,isDefinitionSelected, context }
        })

    }
}

export const handleCancelSpotPrint = (from, fromtab) => {
    return (dispatch) => {
        dispatch({
            type: SpotPrintTypes.SPOT_PRINTING_CANCEL,
        })
    }
}

export const SpotPrintGetStudentList = (ReqPayload, AccessToken) => {

    let URL = Base_URL + Get_BatchPrint_StudentList;
    return (dispatch,getState) => {

        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_GET_STUDENTS_LIST
        })

        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        axios.post(URL, ReqPayload, {
            headers: api_request_headers,
        }).then(function (response) {
            let payloadData = response.data.value;
            let batch_options = getRequiredDataFromPersist("batch_options", getState());
            dispatch({
                type: SpotPrintTypes.SPOT_PRINT_GET_STUDENTS_LIST_SUCCESS,
                payload: { payloadData, batch_options }
            })
        }).catch(function (error) {
            dispatch(postErrorLog(AccessToken,error,seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })

            dispatch({
                type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
                payload: error.response
            })

        });
    }

}

export const SpotPrintingSelectedPage = (selectedPage) => {
    return (dispatch) => {
        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_CURRENT_SELECTED_PAGE,
            payload: { selectedPage }
        })
    }
}

export const handleSpotPrintOptionSelect = (selectedOption) => {
    return (dispatch) => {
        dispatch({
            type: SpotPrintTypes.SPOT_PRINTING_SELECTED,
            payload: { selectedOption }
        })
    }
}

export const handleSpotPrintingSelectShowOption = (option,currentStatus)=>{
    let updatedStatus = !currentStatus;
   
    return (dispatch,getState) => {
        let batch_options = getRequiredDataFromPersist("batch_options", getState());
        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_SELECT_SHOW,
            payload: { option, updatedStatus,batch_options }
        })
    }
}

export const SpotPrintingSelectView = (selectedOption,isDefinitionSelected) => {
    return (dispatch,getState) => {
        let batch_options = getRequiredDataFromPersist("batch_options", getState());
        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_SELECT_VIEW,
            payload: { selectedOption,isDefinitionSelected,batch_options }
        })
    }
}

export const SpotPrintingSelectTaxo = (taxoName,currentStatus) => {
    let updatedStatus = !currentStatus
    return (dispatch) => {
        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_SELECTED_TAXONOMY,
            payload: { taxoName,updatedStatus }
        })
    }
}

// export const handleDefaultReportPrint = (from, fromtab, popUpStatus) => {
//     return (dispatch) => {
//         dispatch({
//             type: SpotPrintTypes.DEFAULT_REPORT_SELECTED,
//             payload: { from, fromtab, popUpStatus }
//         })
//     }
// }

export const resetTriggerPDF = () => {
    return (dispatch) => {
        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_RESET_PDF_TRIGGER
        })
    }
}

export const SpotPrintingPrintClick = (ReqPayload, AccessToken, popUpStatus) => {

    let URL = Base_URL + student_SPOT_pdf;

    return (dispatch, getState) => {

        dispatch({
            type: SpotPrintTypes.SPOT_PRINT_API,
            payload: { popUpStatus }
        })
        let testList = getState().Universal.ContextHeader.TestTab.TestList
        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        axios.post(URL, ReqPayload, {
            headers: api_request_headers,
        }).then(function (response) {
            let payloadData = response.data.value;
            dispatch({
                type: SpotPrintTypes.SPOT_PRINT_API_SUCCESS,
                payload: { payloadData, popUpStatus,testList }
            })
        }).catch(function (error) {
            dispatch(postErrorLog(AccessToken,error,seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })

            dispatch({
                type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
                payload: error.response
            })
        });

    }
}
export function DownloadSPOTPDF(ReqPayload, AccessToken) {
    let headers_pdf = {
        "Access-Control-Allow-Origin": "*",
        "Authorization": 'Bearer '.concat(AccessToken),
    };
    let fileName = "Student SPOT.pdf";
    if(ReqPayload.contextType =="class"){
        fileName = "Class SPOT.pdf";
    }
    if(ReqPayload.contextType =="school"){
        fileName = "School SPOT.pdf";
    }
    if(ReqPayload.contextType =="district"){
        fileName = "District SPOT.pdf";
    }
    return (dispatch,getState) => {
        dispatch({
            type: SpotPrintTypes.DOWNLOAD_SPOT_PDF
        })
        const { Universal } = getState();
        const { NavigationByHeaderSelection } = Universal;
        let context= "district";
        if(NavigationByHeaderSelection.school && NavigationByHeaderSelection.S_performance)
        {
        context = "school";
        }  else if(NavigationByHeaderSelection.class  && NavigationByHeaderSelection.S_performance)
        {
        context = "class";
        } else if(NavigationByHeaderSelection.student  && NavigationByHeaderSelection.S_performance)
        {
        context = "student";
        }

        let seconds_Start = new Date().getTime() / 1000;
        axios.post(SPOT_PDF_DOWNLOAD,
            ReqPayload,
            {
                headers: headers_pdf,
                responseType: "blob"
            }).then((response) => {
                const url = window.URL.createObjectURL(new Blob([response.data]));
                const link = document.createElement('a');
                link.href = url;
                link.setAttribute('download', fileName);
                document.body.appendChild(link);
                link.click();
                dispatch({
                    type: SpotPrintTypes.DOWNLOAD_SPOT_PDF_SUCCESS,

                })
                dispatch(trackingUsage(`assessmentreports_spotpdf:${context}`))
            }).catch(function (error) {
                dispatch(postErrorLog(AccessToken, error, seconds_Start))
                let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

                dispatch({
                    type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                    payload: { statusCode }
                })
            });

    };

}
export function saveToAgp(ReqPayload, AccessToken, option) {
    api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
    return (dispatch,getState) => {
        dispatch({
            type: SpotPrintTypes.DOWNLOAD_SPOT_PDF
        })

        let seconds_Start = new Date().getTime() / 1000;
        axios.post(DistrictAGPCSV,
        
            ReqPayload,
            {
                headers: api_request_headers
            }).then((response) => {
                const { Universal } = getState();
                const { NavigationByHeaderSelection } = Universal;
                let context= "district";
                if(NavigationByHeaderSelection.school && NavigationByHeaderSelection.S_performance)
                {
                context = "school";
                }  else if(NavigationByHeaderSelection.class  && NavigationByHeaderSelection.S_performance)
                {
                context = "class";
                } else if(NavigationByHeaderSelection.student  && NavigationByHeaderSelection.S_performance)
                {
                context = "student";
                }

                dispatch({
                    type: SpotPrintTypes.DOWNLOAD_SPOT_PDF_SUCCESS,
                    payload: option 

                })
                dispatch(trackingUsage(`assessmentreports_spotbatchpdf:${context}`))
            }).catch(function (error) {
                dispatch(postErrorLog(AccessToken, error, seconds_Start))
                let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

                dispatch({
                    type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                    payload: { statusCode }
                })
            });

    };

}
