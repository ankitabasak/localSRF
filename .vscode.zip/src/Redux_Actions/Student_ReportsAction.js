import {
  Student_ReportActionTypes,
  GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD,
  GET_STANDARDPERFORMANCE_TABLE_STD,
  GET_STANDARDPERFORMANCE_TABLE_FAIL_STD,
  TEST_ASSESSMENT_MAX_COUNT_STUDENT_SUCCESS,
  TEST_ASSESSMENT_MAX_COUNT_STUDENT,
  TEST_GRADE_LIST_STUDENT_SUCCESS,
  STUDENT_OBJ_API_SUCCESS,
  STUDENT_OBJ_API,
} from "../Reducer_Action_Types/Student_ReportTypes";
import {
  Base_URL,
  getInitialStudentObjAPI,
  Get_Students_TestScores_OverTime_API,
  Get_Student_Strands,
  LineChart_of_student_strands,
  StudentTestGradeListUrl,
  StudentTestAssessmentUrl,
  api_request_headers,
  Disable_AutoSelect_Std_Pref_LeftView,
  getInitialStudentObjAPI_TestStatus,
} from "../Utils/globalVars";

import { rejects } from "assert";
import axios from "axios";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  GetAssessed_Ques_ToPersist,
  GetTaxonomy_ToPersist_AndStrandDetails,
  Strands_Grade_ToPersist,
  calculateStrandAvgOnTaxonimy_Filter,
  Sort_ApiResponse_Payload_Array,
  sortTaxonomyDataBasedOnUserPrefferences,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { multiDimensionalUnique_inClass } from "../Redux_Reducers/ReportsReducer";
import { postErrorLog } from "./AuthenticationAction";
import {
  student_SP_Success,
  student_TS_Success,
} from "../services/universalSelector/universalSelector_1";

/**
 *
 * @param {String} AccessToken
 * @param {object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} standardAvg
 * @param {string} strandName
 * @param {string} standard
 */
export const GetLineChartDetailsof_Student_Standards = (
  AccessToken,
  ReqPayload,
  strandId,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading,
  selectedTaxonomy,
  Sel_Ass_Ques
) => {
  let URL = Base_URL + LineChart_of_student_strands;

  return (dispatch, getState) => {
    dispatch({
      type: Student_ReportActionTypes.GET_LINECHART_DETAILS_OF_A_STRAND,
      payload: {
        strandId,
        standardId,
        standardAvg,
        strandName,
        standard,
        Enableloading,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        onUploadProgress: function (progressEvent) {},
        onDownloadProgress: function (progressEvent) {},
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        dispatch({
          type: Student_ReportActionTypes.GET_LINECHART_DETAILS_OF_A_STRAND_SUCCESS,
          payload: {
            PayloadData,
            standardId,
            standardAvg,
            strandName,
            standard,
            selectedTaxonomy,
            Sel_Ass_Ques,
            persist_compare_checkboxes,
          },
        });
      })
      .catch(function (error) {
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
export const getInitialStudentObj = (ReqPayload, AccessToken, Nav) => {
  let subEndPointUrl = getInitialStudentObjAPI;

  if (Nav.test_status) {
    subEndPointUrl = getInitialStudentObjAPI_TestStatus;
    ReqPayload.context = "student";
  }

  let URL = Base_URL + subEndPointUrl;
  return (dispatch, getState) => {
    dispatch({
      type: Student_ReportActionTypes.STUDENT_OBJ_API,
    });
    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        dispatch({
          type: Student_ReportActionTypes.STUDENT_OBJ_API_SUCCESS,
          payload: { PayloadData, Nav },
        });
      })
      .catch(function (error) {
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const chnagestudentObjAPICallFlag = () => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.STUDENT_OBJ_API_FLAG_OFF,
    });
  };
};

/**
 *
 * @param {string} MotionDirection --  Left Or right
 */

export const MoveHeaderIn_Students_Strands_Table = (MotionDirection) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.MOVE_HEADER_IN_STRANDS_PERFORMANCE_TABLE,
      payload: MotionDirection,
    });
  };
};

/**
 *
 * @param {string} motion -- Bubble Motion Left/ Right :
 * @param {object} Nav -- Navigation details
 */

export const Move_Student_ChartPaginationDisplayBubbles = (motion, Nav) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.MOVE_LINE_CHART_PAGINATIO_BUBBLE,
      payload: { motion, Nav },
    });
  };
};

/**
 *
 * @param {int} Chart_Bubble_Start  -- Chart_Bubble_Start
 * @param {int} positionfrom_BubbleStart -- ex : 1,2,
 * @param {object} Nav -- navigation details
 */

export const Change_Student_LineChart_paginationBubble = (
  Chart_Bubble_Start,
  positionfrom_BubbleStart,
  Nav
) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.CHANGE_LINE_CHART_PAGINATION_BUBBLE,
      payload: { Chart_Bubble_Start, positionfrom_BubbleStart, Nav },
    });
  };
};

/**
 *
 * @param {var} xU  -- X-axis coords
 * @param {var} yU  -- Y-axis coords
 * @param {object} tooltip_data  -- Selected tooltip data
 * @param {var} tooltipDisplay  -- true/false
 * @param {int} index            -- Index value of selected test
 * @param {boolean} ShowTollTipPopUp   -- true/false
 * @param {object} Nav        -- cuttent instance of navigation object data.
 */

export const Set_Student_ToolTipAndBarValues = (
  xU,
  yU,
  tooltip_data,
  tooltipDisplay,
  index,
  ShowTollTipPopUp,
  Nav,
  updateinclass
) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.SET_STUDENT_TOOLTIP_AND_BAR_VALUE,
      payload: {
        xU,
        yU,
        tooltip_data,
        tooltipDisplay,
        index,
        ShowTollTipPopUp,
        Nav,
        updateinclass,
      },
    });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} reqObject
 * @param {Boolean} Nav_by_Student_From_Class
 */

export const Get_Student_StandardPerformance_Table = (
  AccessToken,
  reqObject,
  Enableloading,
  Class_Strands_props
) => {
  let URL = Base_URL + Get_Student_Strands;

  return (dispatch, getState) => {
    dispatch({
      type: GET_STANDARDPERFORMANCE_TABLE_STD,
      payload: Enableloading,
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, reqObject, {
        headers: api_request_headers,
      })
      .then(function (responsedata) {
        let StudentId = reqObject.studentId;
        let response = responsedata.data.value;
        response = response == null || response == undefined ? [] : response;
        let UserPreferences = getState().Universal.UserPreferences;
        let LastNav = getState().LastActiveUniversalProps.NaviGation;
        let last_active_Taxonomy_And_StrandDetails;
        let currentNav = getState().Universal.NavigationByHeaderSelection;
        if (currentNav.S_performance && currentNav.Overview) {
          last_active_Taxonomy_And_StrandDetails =
            GetTaxonomy_ToPersist_AndStrandDetails(LastNav, getState);
        }
        let StudentReport = getState().StudentReports;
        let Action = {
          payload: {
            response,
            StudentId,
            Class_Strands_props,
            DataForGrade: reqObject.grade,
            last_active_Taxonomy_And_StrandDetails,
            currentNav,
            UserPreferences,
            LastNav,
          },
        };
        let StudentStrandsToSet = SaveStrandsOnStudentApiSuccess(
          StudentReport,
          Action
        );

        let StdReports = getState().StudentReports;
        let ClassReports = getState().Reports;
        let SchoolReports = getState().schoolReducer;
        let DistrictReports = getState().DistrictReducer;

        let Cs_strads_Api,
          Cs_Asse_ques_api,
          Sc_strads_Api,
          sc_Asse_ques_api,
          D_strandsApi,
          D_Asse_Ques_Api;

        let sc_ques =
          SchoolReports.Sc_StandardPerformance_Overview
            .StandardPerformanceFilter.TestAssessment;
        let sc_taxon =
          SchoolReports.Sc_StandardPerformance_Overview
            .StandardPerformanceFilter.Taxonomy;

        let D_ques =
          DistrictReports.D_StandardPerformance_Overview
            .StandardPerformanceFilter.TestAssessment;
        let D_taxon =
          DistrictReports.D_StandardPerformance_Overview
            .StandardPerformanceFilter.Taxonomy;

        let Cs_Ques =
          ClassReports.StandardPerformance_Overview.StandardPerformanceFilter
            .TestAssessment;

        let Cs_taxon =
          ClassReports.StandardPerformance_Overview.StandardPerformanceFilter
            .Taxonomy;

        let St_ques =
          StudentStrandsToSet.S_StandardPerformance_Overview
            .StandardPerformanceFilter.TestAssessment;
        let St_taxon =
          StudentStrandsToSet.S_StandardPerformance_Overview
            .StandardPerformanceFilter.Taxonomy;

        if (
          Cs_Ques.selectedTestAssessment !== St_ques.selectedTestAssessment &&
          responsedata.data.value !== null
        ) {
          Cs_Asse_ques_api = true;
          // sc_ques.MaxTestAssessmentCount + 1 > St_ques.selectedTestAssessment ? true : undefined
        }

        if (
          Cs_taxon.selectedTaxonomy !== St_taxon.selectedTaxonomy &&
          responsedata.data.value !== null
        ) {
          Cs_strads_Api = true;
        }
        if (
          sc_ques.selectedTestAssessment !== St_ques.selectedTestAssessment &&
          responsedata.data.value !== null
        ) {
          sc_Asse_ques_api = true;
        }

        if (
          sc_taxon.selectedTaxonomy !== St_taxon.selectedTaxonomy &&
          responsedata.data.value !== null
        ) {
          Sc_strads_Api = true;
        }

        if (
          D_ques.selectedTestAssessment !== St_ques.selectedTestAssessment &&
          responsedata.data.value !== null
        ) {
          D_Asse_Ques_Api = true;
        }

        if (
          D_taxon.selectedTaxonomy !== St_taxon.selectedTaxonomy &&
          responsedata.data.value !== null
        ) {
          D_strandsApi = true;
        }

        let { Universal, LastActiveUniversalProps } = getState();
        let action = {
          payload: {
            response,
            StudentId,
            Class_Strands_props,
            DataForGrade: reqObject.grade,
            last_active_Taxonomy_And_StrandDetails,
            currentNav,
            StudentStrandsToSet,
            St_ques,
            St_taxon,
            sc_Asse_ques_api,
            Sc_strads_Api,
            D_strandsApi,
            D_Asse_Ques_Api,
            Cs_strads_Api,
            Cs_Asse_ques_api,
            UserPreferences,
          },
        };
        let { updatedLastActivePropsState, updatedUniversalState } =
          student_SP_Success(action, Universal, LastActiveUniversalProps);

        dispatch({
          type: GET_STANDARDPERFORMANCE_TABLE_SUCCESS_STD,
          payload: {
            response,
            StudentId,
            Class_Strands_props,
            DataForGrade: reqObject.grade,
            last_active_Taxonomy_And_StrandDetails,
            currentNav,
            StudentStrandsToSet,
            St_ques,
            St_taxon,
            sc_Asse_ques_api,
            Sc_strads_Api,
            D_strandsApi,
            D_Asse_Ques_Api,
            Cs_strads_Api,
            Cs_Asse_ques_api,
            UserPreferences,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        dispatch({
          type: GET_STANDARDPERFORMANCE_TABLE_FAIL_STD,
          payload: error.response,
        });
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {Boolean} openOrClose,
 * is to open the note in student standards performance overview component.
 */
export const OpenOrCloseNoteIn_S_SP_OT = (openOrClose) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.OPEN_OR_CLOSE_NOTE_IN_S_SP_OT,
      payload: openOrClose,
    });
  };
};
/**
 * @param {Boolean} openOrClose
 * @param {String} SelectedNav
 * is to open the tooltip in school standards performance/testscores overview component.
 */
export const OpenOrCloseTooltipIn_S_SP_OT = (openOrClose, SelectedNav) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.OPEN_OR_CLOSE_TOOLTIP_IN_STU_SP_OT,
      payload: { openOrClose, SelectedNav },
    });
  };
};
/**
 *
 * @param {String} SelectedOption
 * @param {Boolean} check
 * When Select CheckBox Of Compare On Strands Table
 */

export const CompareCheckBox_Option_In_Student = (SelectedOption, check) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.COMPARE_CHECKBOX_OPTION_IN_STUDENT,
      payload: { SelectedOption, check },
    });
  };
};
/**
 *
 * @param {String} SelectedOption
 * @param {Boolean} check
 * When Select CheckBox label Of Compare On Strands Table
 */

export const EnableOrDisableLineColorIn_S_SP_LC = (SelectedOption, check) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.ENABLE_OR_DISABLE_LINE_COLOR_IN_S_SP_LC,
      payload: { SelectedOption, check },
    });
  };
};

/**
 *
 * @param {string} AccessToken --jwt token.
 * @param {object} reqObject -- API call request payload.
 * @param {string} ReqFromComp -- Api call request from component.
 * @param { Boolean} Enableloading
 */

export const Get_Student_TestScores_Details = (
  AccessToken,
  reqObject,
  ReqFromComp,
  checkOption,
  Enableloading
) => {
  let URL = Base_URL + Get_Students_TestScores_OverTime_API;

  let gotAllValuesInChart =
    reqObject.isClass || reqObject.isSchool || reqObject.isDistrict;

  return (dispatch, getState) => {
    dispatch({
      type: Student_ReportActionTypes.GET_STUDENTS_TESTSCORES,
      payload: { checkOption, Enableloading },
    });
    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    fetch(URL, {
      method: "post",
      headers: api_request_headers,
      body: JSON.stringify(reqObject),
    })
      .then((res) => res.json())
      .then((res) => {
        let ResponseData = res.value;

        let compareOptions = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );

        let { Universal, LastActiveUniversalProps } = getState();
        let action = {
          payload: {
            ResponseData,
            ReqFromComp,
            gotAllValuesInChart,
            compareOptions,
          },
        };
        let { updatedLastActivePropsState, updatedUniversalState } =
          student_TS_Success(action, Universal, LastActiveUniversalProps);

        dispatch({
          type: Student_ReportActionTypes.GET_STUDENTS_TESTSCORES_SUCCESS,
          payload: {
            ResponseData,
            ReqFromComp,
            gotAllValuesInChart,
            compareOptions,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        dispatch({
          type: Student_ReportActionTypes.GET_STUDENTS_TESTSCORES_FAIL,
          payload: error.response,
        });

        let seconds_End = new Date().getTime() / 1000;

        let diffTime = seconds_End - seconds_Start;

        let statusCode =
          error.message == "Failed to fetch" && diffTime < 90
            ? 502
            : error.response == undefined
            ? 504
            : error.response.status;

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {String} selectedCheckBox
 * @param {Boolean} Checked
 * triggers When Compare checkboxes or checked or unchecked in student testscore overview component,
 */
export const CompareCheckBoxes_Of_S_TS_Overview = (
  selectedCheckBox,
  Checked
) => {
  return (dispatch, getState) => {
    const { SingleTestAnalysis } = getState();

    dispatch({
      type: Student_ReportActionTypes.COMPARE_CHECK_BOXES_OF_S_TS_OVERVIEW,
      payload: { selectedCheckBox, Checked },
    });
  };
};
/**
 *
 * @param {String} selectedCheckBox
 * @param {Boolean} Checked
 * triggers When Compare checkboxes label click in student testscore overview component,
 */

export const EnableOrDisableLineColorIn_S_LC = (selectedCheckBox, Checked) => {
  return (dispatch) => {
    dispatch({
      type: Student_ReportActionTypes.ENABLE_OR_DISABLE_LINE_COLOR_IN_S_LC,
      payload: { selectedCheckBox, Checked },
    });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 *
 * TO get grade list of a selected student .
 */
export const getGradeListOfStudent = (AccessToken, ReqPayload) => {
  let URL = Base_URL + StudentTestGradeListUrl;

  return (dispatch, getState) => {
    dispatch({
      type: Student_ReportActionTypes.TEST_GRADE_LIST_STUDENT,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        timeout: 0,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData =
          PayloadData == null || PayloadData == undefined ? [] : PayloadData;
        let PreviousRepo_Nav = getState().LastActiveUniversalProps.NaviGation;
        let CurrentNav = getState().Universal.NavigationByHeaderSelection;
        let { persitedTestAssessGrade } = getState().SummaryReports;
        let ActiveStrandGrade = Strands_Grade_ToPersist(
          PreviousRepo_Nav,
          getState
        );

        dispatch({
          type: TEST_GRADE_LIST_STUDENT_SUCCESS,
          payload: { PayloadData, ActiveStrandGrade, CurrentNav,persitedTestAssessGrade },
        });
      })
      .catch((err) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
export const getTestAssessmentMaxCountOfStudent = (AccessToken, ReqPayload) => {
  let URL = Base_URL + StudentTestAssessmentUrl;

  return (dispatch, getState) => {
    dispatch({
      type: TEST_ASSESSMENT_MAX_COUNT_STUDENT,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;

        let LastActiveNav = getState().LastActiveUniversalProps.NaviGation;

        let QuestionToPersist;
        if (!LastActiveNav.student) {
          QuestionToPersist = GetAssessed_Ques_ToPersist(
            LastActiveNav,
            getState
          );
          // let Universal =
        }
        dispatch({
          type: TEST_ASSESSMENT_MAX_COUNT_STUDENT_SUCCESS,
          payload: { PayloadData, QuestionToPersist },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export function SaveStrandsOnStudentApiSuccess(state, action) {
  let List_STrands = action.payload.response;
  let { LastNav } = action.payload;
  if (List_STrands.length == 0) {
    return {
      ...state,
      S_StandardPerformance_Overview: {
        ...state.S_StandardPerformance_Overview,
        StandardPerformanceFilter: {
          ...state.S_StandardPerformance_Overview.StandardPerformanceFilter,
          strandsNotAvailable: true,
          NodataInStrands: true,
        },
      },
      S_ApiCalls: {
        ...state.S_ApiCalls,
        loading_on_strands_table: false,
      },
    };
  } else {
    let StandsList_Original = { ...action.payload.response };
    let StandsList = { ...action.payload.response };
    let StrandTaxonomyList = [];
    let comesfrom_compare =
      state.S_StandardPerformance_Overview.strandSelectedFromCompare;
    let { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist } =
      action.payload.last_active_Taxonomy_And_StrandDetails;
    StandsList.strands = Sort_ApiResponse_Payload_Array(
      StandsList.strands,
      "strands"
    );

    let SetValues = [];
    StandsList.strands.map((strand) => {
      strand.standards.map((single_standard) => {
        StrandTaxonomyList.push(single_standard.taxonomy);
        SetValues.push({
          setId: single_standard.setId,
          taxonomy: single_standard.taxonomy,
        });
      });
    });
    StrandTaxonomyList = [...new Set(StrandTaxonomyList)];

    SetValues = multiDimensionalUnique_inClass(SetValues);

    StrandTaxonomyList.sort();

    if (
      action.payload.UserPreferences !== null &&
      action.payload.UserPreferences != undefined &&
      action.payload.UserPreferences.standardsetorders.length > 0
    ) {
      StrandTaxonomyList = sortTaxonomyDataBasedOnUserPrefferences(
        action.payload.UserPreferences,
        SetValues
      );
    }

    let TaxonomyExist = last_active_Taxonomy
      ? StrandTaxonomyList.includes(last_active_Taxonomy)
      : StrandTaxonomyList.includes(
          state.S_StandardPerformance_Overview.selected_Taxonomy_From_Compare
        );

    let Selec_Taxonomyis =
      comesfrom_compare && TaxonomyExist
        ? state.S_StandardPerformance_Overview.selected_Taxonomy_From_Compare
        : last_active_Taxonomy && TaxonomyExist
        ? last_active_Taxonomy
        : comesfrom_compare && TaxonomyExist
        ? state.S_StandardPerformance_Overview.selected_Taxonomy_From_Compare
        : StrandTaxonomyList[0];

    // End of Taxonomy Logic Will goes here
    StandsList.strands = Sort_ApiResponse_Payload_Array(
      StandsList.strands,
      "strands"
    );

    let SelectionBasedTaxonomyList = { ...StandsList };

    SelectionBasedTaxonomyList.strands = SelectionBasedTaxonomyList.strands
      .map((strand) => {
        return {
          ...strand,
          standards: [
            ...strand.standards.filter(
              (single_taxonomy_standard) =>
                single_taxonomy_standard.taxonomy == Selec_Taxonomyis
            ),
          ],
        };
      })
      .filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

    SelectionBasedTaxonomyList = calculateStrandAvgOnTaxonimy_Filter(
      SelectionBasedTaxonomyList
    );

    let SelectedStrand =
      !Disable_AutoSelect_Std_Pref_LeftView &&
      (SelectionBasedTaxonomyList.strands !== undefined ||
        SelectionBasedTaxonomyList.strands !== null)
        ? SelectionBasedTaxonomyList.strands[0]
        : {
            strandName: LastNav.student
              ? state.S_StandardPerformance_Overview
                  .StrandNameOfSelectedStandard
              : "",
            strandAvg: LastNav.student
              ? state.S_StandardPerformance_Overview.selectedStandarAvg
              : "",
            strandId: LastNav.student
              ? state.S_StandardPerformance_Overview.selectedStandardId
              : "",
          };

    let StrandName = SelectedStrand.strandName;
    let Avarage = SelectedStrand.strandAvg;
    let standardId = "";
    let StandardsObj = {};
    StandardsObj =
      StandardsObj == undefined || StandardsObj == null ? {} : StandardsObj;

    if (comesfrom_compare && TaxonomyExist) {
      let Strand_List = action.payload == null ? [] : StandsList.strands;

      standardId =
        state.S_StandardPerformance_Overview.selectedStandard_From_Compare;
      StrandName =
        state.S_StandardPerformance_Overview.selectedStrand_From_Compare;
      let StandardIdIsNot_Exist = false;
      let STrandIsNotExist = false;

      if (standardId !== "") {
        let selectedstrand = Strand_List.filter(
          (item) => item.strandName == StrandName
        );
        if (selectedstrand[0] !== undefined) {
          StandardsObj = selectedstrand[0].standards.find(function (element) {
            return element.standardId == standardId;
          });
          if (StandardsObj == undefined) {
            StandardIdIsNot_Exist = true;
          } else {
            Avarage = StandardsObj.standardAvg;
          }
        } else {
          STrandIsNotExist = true;
        }
      } else {
        StandardsObj = {};
        Avarage = "";
      }

      /**
       *  start , if strand or standard is not there in payload data
       */

      if (STrandIsNotExist) {
        StrandName = Strand_List[0].strandName;
        StandardsObj = {};
        Avarage = "";
        standardId = "";
      } else if (StandardIdIsNot_Exist) {
        StandardsObj = {};
        Avarage = "";
        standardId = "";
      }

      /**
       *  End , if strand or standard is not there in payload data
       */
    } else {
    }

    let Curret_Taxon =
      state.S_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy
        .selectedTaxonomy;
    SelectionBasedTaxonomyList =
      SelectionBasedTaxonomyList === null ? [] : SelectionBasedTaxonomyList;

    let IndexofCurrentSTrand = SelectionBasedTaxonomyList.strands.findIndex(
      (item) => item.strandName == StrandName
    );
    let HeaderStart = state.S_StandardPerformance_Overview.headerStart;
    let HeaderEnd = state.S_StandardPerformance_Overview.headerEnd;
    let Diff = window.screen.width < 1281 ? 4 : 6;

    if (IndexofCurrentSTrand + 1 > HeaderEnd) {
      HeaderEnd = IndexofCurrentSTrand + 1;
      HeaderStart = HeaderEnd - Diff;
    }

    let GetLineChartData =
      StrandName !== "" && StrandName !== null && StrandName !== undefined;

    return {
      ...state,
      S_StandardPerformance_Overview: {
        ...state.S_StandardPerformance_Overview,
        ActualList: SelectionBasedTaxonomyList,
        originalList: StandsList_Original,
        selectedStandarAvg: Avarage,
        selectedstandardObject: StandardsObj,
        selectedStandardId: standardId,
        StrandNameOfSelectedStandard: StrandName,
        headerEnd: HeaderEnd,
        headerStart: HeaderStart,
        StandardPerformanceFilter: {
          ...state.S_StandardPerformance_Overview.StandardPerformanceFilter,
          strandsNotAvailable: false,
          NodataInStrands: false,
          Taxonomy: {
            ...state.S_StandardPerformance_Overview.StandardPerformanceFilter
              .Taxonomy,
            OpenCloseTaxonomy: false,
            TaxonomyList: StrandTaxonomyList,
            selectedTaxonomy: Selec_Taxonomyis,
          },
          SetValues: SetValues,
        },
        selectedStrand_From_Compare: "",
        selectedStrand_From_Compare: "",
        selectedStandard_From_Compare: "",
        strandSelectedFromCompare: false,
      },
      S_ApiCalls: {
        ...state.S_ApiCalls,
        getLineChartOfStrands: GetLineChartData,
        loading_on_strands_table: false,
      },
    };
  }
}
