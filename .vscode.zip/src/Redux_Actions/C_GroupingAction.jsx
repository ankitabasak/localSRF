import { C_GroupingTypes } from "../Reducer_Action_Types/C_GroupingTypes.jsx";
import axios from "axios";
import { Class_grouping_api } from "../Utils/globalVars";

//show and collapse class bar
export const SHOW_HIDE_GROUPING = data => {
  return dispatch => {
    dispatch({
      type: C_GroupingTypes.CLASS_GROUPING_TOGGLE,
      payload: data
    });
  };
};

//function to show icons and sort columns
export const SORT_GROUPING_GRID_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: C_GroupingTypes.GROUPING_GRID_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};
//function to show icons and sort columns
export const SHOW_SPINNER = (action) => {
  return dispatch => {
    dispatch({
      type: C_GroupingTypes.START_SPINNER,
      payload: true
    });
  };
};

//save grouping data
export const SAVE_GROUPING_DATA = (AccessToken, payLoadData) => {

  let AuthURL = Class_grouping_api;

  let apiRequests = [];
  if (payLoadData && payLoadData.length > 0) {
    payLoadData.forEach(individualPayLoad => {
      apiRequests.push(
        axios.post(AuthURL, individualPayLoad, {
          headers: {
            "Access-Control-Allow-Origin": "*",
            responseType: "application/json",
            Authorization: "Bearer ".concat(AccessToken)
          }
        })
      );
    });
  }
  return dispatch => {

    Promise.all(apiRequests)
      .then(response => {
        let Response_Data = response.data;
        dispatch({
          type: C_GroupingTypes.SAVED_GROUPING_DATA_SUCCESS,
          payload: { groupUpdateSuccess: true }
        });

        setTimeout(() => {
          dispatch({
            type: C_GroupingTypes.SAVED_GROUPING_DATA_SUCCESS,
            payload: { groupUpdateSuccess: false, showGrouping: false }
          });
        }, 5000)
      })
      .catch(function (error) {

        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: C_GroupingTypes.SAVED_GROUPING_DATA_FAILURE,
          payload: statusCode
        });

        setTimeout(() => {
          dispatch({
            type: C_GroupingTypes.SAVED_GROUPING_DATA_FAILURE_RESET,
            payload: false
          });
        }, 5000)
      });
  };
};
// axios
//   .post(AuthURL, payLoadData, {
//     headers: {
//       "Access-Control-Allow-Origin": "*",
//       responseType: "application/json",
//       Authorization: "Bearer ".concat(AccessToken)
//     }
//   })
//   .then(function(response) {
//     let Response_Data = response.data;

//     // dispatch({
//     //   type: C_GroupingTypes.SAVED_GROUPING_DATA_SUCCESS,
//     //   payload: Response_Data,
//     //   value: payLoadData.value
//     // });
//   })
//   .catch(function(error) {
//     // alert("Server Error Please Try Again...!");
//     let statusCode =
//       error.response == undefined ? 401 : error.response.status;
//     dispatch({
//       type: C_GroupingTypes.SAVED_GROUPING_DATA_FAILURE,
//       payload: statusCode
//     });
//   });
