import { DistrictRLPTypes } from '../Reducer_Action_Types/District_RlpActionTypes.jsx';
import {
  District_Rlp_Grid_Api,
  District_Rlp_Class_level_Grid_Api,
  District_Rlp_MainChart_Api,
  District_Rlp_ClassLevel_Api,
  ORR_URL,
  dummyToken,
  CSV_DOWNLOAD_DISTRICT
} from '../Utils/globalVars';
import axios from 'axios';
import { RLP_CHART_API_SUCCESS } from '../Reducer_Action_Types/UniversalSelectorActionTypes.js';
import { CHANGE_TERM_ON_RLP_DATA_FAIL_METHOD } from './C_ReadingLevelAction.jsx';

export const District_RLP_Grid_Chart_Table_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + District_Rlp_Grid_Api;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        if (Response_Data.SUCCESSFULL) {
          dispatch({
            type: DistrictRLPTypes.DISTRICT_RLP_GRID_DATA,
            payload: Response_Data
          });
        }
      }).catch(() => {
        dispatch({
          type: DistrictRLPTypes.DISTRICT_RLP_GRID_API_CALL_FAIL
        });
      });
  };
};

export const District_Class_Grid_Chart_Table_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + District_Rlp_Class_level_Grid_Api;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        if (Response_Data.SUCCESSFULL) {
          dispatch({
            type: DistrictRLPTypes.DISTRICT_RLP_GRID_DATA,
            payload: Response_Data
          });
        }
      }).catch(() => {
        dispatch({
          type: DistrictRLPTypes.DISTRICT_RLP_GRID_API_CALL_FAIL
        });
      });
  };
};

// for setting loading icon chart for data request
export const DRLP_loading_Icon = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.CHART_API_LOADER,
      payload: 'ShowLoader'
    });
  };
};

// chart loading failed
export const Chart_loading_Failed = data => {
  return dispatch => {
    dispatch({ type: DistrictRLPTypes.CHART_LOADING_FAILED, payload: data });
  };
};

// Districtl level 1.1 chart API
export const District_Level_RLP_Chart_API = (AccessToken, data) => {
  let AuthURL = ORR_URL + District_Rlp_MainChart_Api;
  if (data['value']) {
    delete data['value'];
  }
  let dummyToken;
  let Payload = data;
  // let Payload = {
  //   externalFilter: {
  //     endDate: '01/01/2020',
  //     districtId: 10000,
  //     startDate: '01/01/2018'
  //   },
  //   internalFilter: data,
  //   value: 'District'
  // };

  return (dispatch, getState) => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        if (
          response.data.responseData.gradeWiseResultList &&
          response.data.responseData.gradeWiseResultList.length > 0
        ) {
          let selectedLevels = getFirstReadingLevels(
            response.data.responseData.gradeWiseResultList[0],
            'SLRLP'
          );

          Promise.resolve(
            dispatch({
              type: DistrictRLPTypes.DISTRICT_RLP_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseData,
                selectedLevels: selectedLevels
              }
            }),
            dispatch({
              type: RLP_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseData
              }
            })
          );
        } else {
          let { loadedOrrReportsForTerm } = getState().Universal;
          let ModifiedDateTab = getState().DateTabReducer;
          let { SelectedDistrictTerm, TermsListWithOutUTCFormat } = ModifiedDateTab.DateTabComponents;
          TermsListWithOutUTCFormat = Array.isArray(TermsListWithOutUTCFormat) ? TermsListWithOutUTCFormat : [];
          let currentDistrictIndex = TermsListWithOutUTCFormat.findIndex(item => item.termId == SelectedDistrictTerm.termId)
          if (currentDistrictIndex > -1 && currentDistrictIndex + 1 < TermsListWithOutUTCFormat.length && !loadedOrrReportsForTerm) {
            dispatch(CHANGE_TERM_ON_RLP_DATA_FAIL_METHOD(currentDistrictIndex));
          } else {
            dispatch({
              type: DistrictRLPTypes.CHART_LOADING_FAILED,
              payload: {
                noChartData: true,
                apiLoadFail: false,
                constructedData: null,
                timeout: false
              }
            });
          }
        }
      })
      .catch(function (error) {
        dispatch({
          type: DistrictRLPTypes.CHART_LOADING_FAILED,
          payload: {
            noChartData: false,
            apiLoadFail: true,
            constructedData: null,
            timeout: false
          }
        });
      });
  };

  // update chart scroll update
};
// District level 1.2 chart API
export const District_Class_Level_RLP_Chart_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + District_Rlp_ClassLevel_Api;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        if (
          response.data.responseData.gradeWiseResultList &&
          response.data.responseData.gradeWiseResultList.length > 0
        ) {
          let selectedLevels = getFirstReadingLevels(
            {
              ...response.data.responseData.gradeWiseResultList[0],
              grade: Payload.grade
            },
            'CLRLP'
          );
          Promise.resolve(
            dispatch({
              type: DistrictRLPTypes.DISTRICT_RLP_CLASS_LEVEL_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseData,
                DistrictLevelGrade: Payload.grade,
                selectedLevels: selectedLevels
              }
            })
          ).then(() => {
            let recList = setGradeToSelectedLevels(selectedLevels);
            dispatch(
              District_Class_Grid_Chart_Table_API(AccessToken, {
                ...Payload,
                ['districtRLPChart2SidePanelRequestList']: recList.recordList,
                label: recList.key
              })
            );
          });
        } else {
          dispatch({
            type: DistrictRLPTypes.CHART_LOADING_FAILED,
            payload: {
              noChartData: true,
              apiLoadFail: false,
              constructedData: null,
              timeout: false
            }
          });
        }
      });
  };

  // update chart scroll update
};

export const Selected_Levels = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.UPDATE_SELECTED_LEVELS,
      payload: data
    });
  };
};
export const District_Level_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DISTRICT_RLP_CHART_SCROLL_DATA,
      payload: data
    });
  };
};

export const Sum_Dst_RLP_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DISTRICT_SUM_RLP_SCROLL_DATA,
      payload: data
    });
  };
};

//function to show icons and sort columns
export const SORT_SCLRLP_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DISTRICT_RLP_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SAVE_SORTED_SCLRLPDATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DISTRICT_RLP_SAVE_SORT_ARRAY,
      payload: { SortedArray }
    });
  };
};

export const DISTRICT_CLASS_LEVEL_GRID_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + District_Rlp_Class_level_Grid_Api;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        if (Response_Data.SUCCESSFULL) {
          dispatch({
            type: DistrictRLPTypes.DISTRICT_RLP_CLASS_LEVEL_GRID_API_SUCCESS,
            payload: Response_Data
          });
        }
      });
  };
};
function getFirstReadingLevels(firstGradeData, from) {
  let levels = [];
  let recordType = '';
  let gradeType = '';
  if (from == 'SLRLP') {
    gradeType = 'grade';
  } else if (from == 'CLRLP') {
    gradeType = 'schoolId';
  }
  if (
    firstGradeData.recordDataList.recentRecord &&
    firstGradeData.recordDataList.recentRecord.length > 0
  ) {
    recordType = 'recentRecord';
    firstGradeData.recordDataList.recentRecord.forEach(obj => {
      if (from == 'SLRLP') {
        levels.push({
          [gradeType]: firstGradeData[gradeType],
          readingLevel: obj.readingLevel
        });
      } else if (from == 'CLRLP') {
        levels.push({
          ['schoolName']: firstGradeData['schoolName'] || '',
          type: 'recentRecord',
          [gradeType]: firstGradeData[gradeType],
          readingLevel: obj.readingLevel
        });
      }
    });
  } else if (
    firstGradeData.recordDataList.firstRecord &&
    firstGradeData.recordDataList.firstRecord.length > 0
  ) {
    recordType = 'firstRecord';
    firstGradeData.recordDataList.firstRecord.forEach(obj => {
      if (from == 'SLRLP') {
        levels.push({
          [gradeType]: firstGradeData[gradeType],
          readingLevel: obj.readingLevel
        });
      } else if (from == 'CLRLP') {
        levels.push({
          [gradeType]: firstGradeData[gradeType],
          grade: firstGradeData.grade,
          readingLevel: obj.readingLevel
        });
      }
    });
  }

  return { [recordType]: levels };
}

function setGradeToSelectedLevels(SL_Levels) {
  if (Object.keys(SL_Levels).length > 0) {
    return {
      recordList: SL_Levels[Object.keys(SL_Levels)[0]],
      key: Object.keys(SL_Levels)[0]
    };
  }
}

//show and collapse class bar
export const SHOW_HIDE_BAR = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DISTRICT_CLASS_NAME,
      payload: data
    });
  };
};

export const Sum_Dst_RLP_Chart_API = (AccessToken, data) => {
  let AuthURL = ORR_URL + District_Rlp_MainChart_Api;
  if (data['value']) {
    delete data['value'];
  }
  let Payload = data;


  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        if (
          response.data.responseData.gradeWiseResultList &&
          response.data.responseData.gradeWiseResultList.length > 0
        ) {
          let selectedLevels = getFirstReadingLevels(
            response.data.responseData.gradeWiseResultList[0],
            'SLRLP'
          );


          dispatch({
            type: DistrictRLPTypes.SUM_DST_RLP_CHART_API_SUCCESS,
            payload: {
              responseData: response.data.responseData,
              selectedLevels: selectedLevels
            }
          })

        }
      })
      .catch(function (error) {
        dispatch({
          type: DistrictRLPTypes.CHART_LOADING_FAILED,
          payload: {
            noChartData: false,
            apiLoadFail: true,
            constructedData: null,
            timeout: false
          }
        });
      });
  };
}

export const DSTRLP_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DSTRLP_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const DSTRLP_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_DISTRICT;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: DistrictRLPTypes.DSTRLP_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: DistrictRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: false
          }
        });
      });
  };
};

export const DSTRLP2_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DSTRLP2_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const DSTRLP2_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_DISTRICT;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: DistrictRLPTypes.DSTRLP2_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: DistrictRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: false
          }
        });
      });
  };
};
export const updateDropDownData = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DSTRLP_UPDATE_DROP_DOWN_DATA,
      payLoad: data
    })
  }
}



export const updateChartDetails = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DSTRLP_UPDATE_CHART_DATA,
      payLoad: data
    })
  }
}

export const updateAllMonth = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DSTRLP_UPDATE_ALL_DATA,
      payLoad: data
    })
  }
}

export const toggleDropDown = data => {
  return dispatch => {
    dispatch({
      type: DistrictRLPTypes.DSTRLP_UPDATE_TOGGLE,
      payLoad: data
    })
  }
}
