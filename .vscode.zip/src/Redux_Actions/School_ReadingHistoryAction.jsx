import { School_ReadingHistoryTypes } from '../Reducer_Action_Types/School_ReadingHistoryTypes.jsx';
import {
  School_Reading_History_API,
  ORR_URL,
  dummyToken,
  CSV_DOWNLOAD_SCHOOL
} from '../Utils/globalVars';
import axios from 'axios';

/**
 * @param {object } readingHistoryFilterData
 * @param { string }  externalFilter
 * @param {string} internalFilter
 */
export const SCHOOL_READING_HISTORY_DATA = (AccessToken, payLoadData) => {
  let AuthURL = ORR_URL + School_Reading_History_API;
  return dispatch => {
    axios
      .post(AuthURL, payLoadData, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;


        if (Response_Data['schoolReadingHistoryData']) {
          dispatch({
            type: School_ReadingHistoryTypes.SCHOOL_READING_HISTORY_DATA_SUCCESS,
            payload: Response_Data,
            value: payLoadData.value
          });
        } else {
          dispatch({
            type: School_ReadingHistoryTypes.SRH_ERROR_HANDLING,
            payload: {
              isApiLoading: false,
              isDataNotAvailable: true,
              timeOut: false
            }
          });
        }


      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: School_ReadingHistoryTypes.SCHOOL_READING_HISTORY_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

export const SCHOOL_RH_ERRORHANDLING = obj => {
  return dispatch => {
    dispatch({
      type: School_ReadingHistoryTypes.SRH_ERROR_HANDLING,
      payload: obj
    });
  };
};
export const SORT_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: School_ReadingHistoryTypes.SCHOOL_READING_HISTORY_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SORTED_SCHOOL_READING_HISTORY_DATA = SortedArray => {
  return dispatch => {
    dispatch({
      type:
        School_ReadingHistoryTypes.SCHOOL_SAVE_SORTED_SCHOOl_READING_HISTORY_DATA,
      payload: { SortedArray }
    });
  };
};

//show and collapse class bar
export const SHOW_HIDE_BAR = data => {
  return dispatch => {
    dispatch({
      type: School_ReadingHistoryTypes.SCHOOL_CLASS_NAME,
      payload: data
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SAVE_SORTED_SCRHODATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: School_ReadingHistoryTypes.SCHOOL_RHO_SAVE_SORT_ARRAY,
      payload: { SortedArray }
    });
  };
};

//function to show icons and sort columns
export const SORT_SCRHO_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: School_ReadingHistoryTypes.SCHOOL_RHO_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

export const SCRHO_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: School_ReadingHistoryTypes.SCRHO_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SCRHO_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_SCHOOL;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: School_ReadingHistoryTypes.SCRHO_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: School_ReadingHistoryTypes.SCHOOL_READING_HISTORY_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};