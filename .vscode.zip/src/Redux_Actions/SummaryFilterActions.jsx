export const summaryShowPopUpFnt = flagStatus => {
  return {
    type: 'summaryFlagStatus',
    payload: flagStatus
  };
}
 
export const SUMMARY_UPDATE_FILTER = data => {
  return {
    type: 'summary_update_filter',
    payLoad: data[data.key],
    key: data.key
  }
}
  
export const SUMMARY_SAVE_SELECTED_FILTER =data =>{
  return {
    type:'summary_save_selected_filter',
    payLoad : data
  }
}
  
export const SUMMARY_RESET_FILTER =data =>{
  return {
      type:'summary_reset_filter',
      payLoad : data
  }
}
