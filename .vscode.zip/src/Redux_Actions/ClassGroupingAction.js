import { ClassGroupingTypes, HANDLE_PAGINATION_CLICK_NAVIGATION } from '../Reducer_Action_Types/ClassGroupingTypes';
import { ClassTestGradeListUrl, Base_URL, ClassTestAssessmentUrl, Get_Class_Strands, groupingInformation, api_request_headers } from '../Utils/globalVars';
import Axios from 'axios';
import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';
import { Return_ERROR_Status_Code } from '../Components/ReusableComponents/AllReusableFunctions';
import { postErrorLog } from './AuthenticationAction';

export const EditClassGrouping = () => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.EDIT_CLASS_GROUPING_POPUP
        })
    }
}

export const selectProduct = (productId) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_PRODUCT,
            payload: productId
        })
    }
}

export const selectTaxonomy = (taxonomy) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_TAXONOMY,
            payload: taxonomy
        })
    }
}
export const selectGrade = (grade) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_GRADE,
            payload: grade
        })
    }
}
export const selectQuestion = (question) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_QUESTION,
            payload: question
        })
    }
}

export const selectStrand = (strand) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_STRAND,
            payload: strand
        })
    }
}
/**
 * When Click ON Done Button After Make Changes in the strand View.
 */
export const DoneInStrandsSelectionView = (strand) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.DONE_IN_SELECT_STRAND_POPUP,
        })
    }
}
/**
 *
 * @param {Object} strand
 * if user removes strand from selection list by clicking on span which we are showling below the strads dropdown in
 */
export const RemoveStradsFromSelectionList_ClickONSpan = (strand) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.REMOVE_STRAND_BY_CLICK_ON_SPAN,
            payload: strand
        })
    }
}



export const ClassGroupPopUpDropDownToggle = (fromWhichDropDown, currentStatus) => {
    return (dispatch) => {
        if (fromWhichDropDown == 'product') {
            dispatch({
                type: ClassGroupingTypes.CLASS_GROUP_POPUP_PRODUCT_DROPDOWN_TOGGLE,
                payload: !currentStatus
            })
        }
        if (fromWhichDropDown == 'taxonomy') {
            dispatch({
                type: ClassGroupingTypes.CLASS_GROUP_POPUP_TAXONOMY_DROPDOWN_TOGGLE,
                payload: !currentStatus
            })
        }
        if (fromWhichDropDown == 'grade') {
            dispatch({
                type: ClassGroupingTypes.CLASS_GROUP_POPUP_GRADE_DROPDOWN_TOGGLE,
                payload: !currentStatus
            })
        }
        if (fromWhichDropDown == 'question') {
            dispatch({
                type: ClassGroupingTypes.CLASS_GROUP_POPUP_QUESTION_DROPDOWN_TOGGLE,
                payload: !currentStatus
            })
        }
        if (fromWhichDropDown == 'strands') {
            dispatch({
                type: ClassGroupingTypes.CLASS_GROUP_POPUP_STRANDS_DROPDOWN_TOGGLE,
                payload: !currentStatus
            })
        }
        if (fromWhichDropDown == 'hide-show') {
            dispatch({
                type: ClassGroupingTypes.CLASS_GROUP_POPUP_STRANDS_SHOW_HIDE,
                payload: !currentStatus
            })
        }
    }
}


export const GroupingCheckAllStrands = (currentStatus) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_STRANDS_CHECK_ALL,
            payload: !currentStatus
        })
    }
}

export const ClassGroupBy = (selectedGroupByParam) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_BY_SELECTED,
            payload: selectedGroupByParam
        })
    }
}

export const selectStandard = (selectedStandard) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLASS_GROUP_POPUP_SELECT_STANDARDS,
            payload: selectedStandard
        })
    }
}

export const CancelGroupPopUp = (GroupAppliedChanges) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CANCEL_GROUP_POPUP,
            payload: GroupAppliedChanges
        })
    }
}

/**
 * 
 * @param {String} AccessToken 
 * @param {Object} ReqPayload 
 */
export const GetGrades_InGrouping = (AccessToken, ReqPayload) => {
    let URL = Base_URL + ClassTestGradeListUrl;

    return (dispatch) => {

        dispatch({
            type: ClassGroupingTypes.GET_GRADES_FOR_GROUPING,
        })


        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        Axios.post(URL, ReqPayload, {
            headers: api_request_headers,
            timeout: 0
        }
        ).then(function (response) {
            let PayloadData = response.data.value;

            dispatch({
                type: ClassGroupingTypes.GET_GRADES_FOR_GROUPING_SUCCESS,
                payload: { PayloadData }
            })
        }).catch(error => {
            dispatch(postErrorLog(AccessToken, error, seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start)

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })
        });
    }
}

/**
 * 
 * @param {String} AccessToken 
 * @param {Object} ReqPayload 
 * will request to get assessed questions count after getting grades count.
 */

export const getTestAssessmentMaxCountInGrouping = (AccessToken, ReqPayload) => {

    let URL = Base_URL + ClassTestAssessmentUrl;

    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.GET_ASSESSMENT_COUNT_IN_GROUPING,
        })

        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        Axios.post(URL, ReqPayload, {
            headers: api_request_headers,
            timeout: 0
        }
        ).then(function (response) {
            let PayloadData = response.data.value;

            dispatch({
                type: ClassGroupingTypes.GET_ASSESSMENT_COUNT_IN_GROUPING_SUCCESS,
                payload: { PayloadData }
            })
        }).catch(error => {
            dispatch(postErrorLog(AccessToken, error, seconds_Start))

            let statusCode = Return_ERROR_Status_Code(error, seconds_Start)

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })
        });;
    }

}

/**
 * 
 * @param {String} AccessToken 
 * @param {Object} ReqPayload 
 */
export const Get_StandardPerformance_Details_In_Grouping = (AccessToken, ReqPayload) => {


    let URL = Base_URL + Get_Class_Strands;
    return (dispatch, getState) => {

        dispatch({
            type: ClassGroupingTypes.GET_STRADS_IN_GROUPING_COMP
        })

        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        Axios.post(URL, ReqPayload, {
            headers: api_request_headers,
        }
        ).then(function (response) {
            let Data = response.data.value;
            let UserPreferences = getState().Universal.UserPreferences
            dispatch({
                type: ClassGroupingTypes.GET_STRADS_IN_GROUPING_COMP_SUCCESS,
                payload: Data,
                UserPreferences: UserPreferences
            })
        }).catch(error => {
            dispatch(postErrorLog(AccessToken, error, seconds_Start))
            // let statusCode = error.response == undefined ? 504 : error.response.status
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start)

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })
        });

    }

}

export const GroupPage_SS_Nav = (NavLeftCount, NavRightCount, NavType) => {

    if (NavType == 'left') {
        NavLeftCount = NavLeftCount - 1;
        NavRightCount = NavRightCount - 1;
    } else {
        NavLeftCount = NavLeftCount + 1;
        NavRightCount = NavRightCount + 1;
    }

    const NavigationCounters =
    {
        NavigationLeftCount: NavLeftCount,
        NavigationRightCount: NavRightCount
    }

    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.GROUP_PAGE_SS_NAV,
            payload: NavigationCounters
        })
    }
}

export const GroupPageMoveStudent = (GroupIndex, StudentIndex, StudentName, StudentId, Student) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.GROUP_PAGE_MOVE_STUDENT,
            payload: {
                GroupIndex,
                StudentIndex,
                StudentName,
                StudentId,
                Student
            }
        })
    }
}

/**
 * 
 * @param {String} AddOrRemove 
 * setting grouping count 
 */
export const ChangeNumberOfGroups = (AddOrRemove) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CHANGE_NUMBER_OF_GROUPS,
            payload: AddOrRemove
        })
    }
}
export const CloseGroupModal = (from) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.CLOSE_GROUP_MODAL,
            payload: from
        })
    }
}

/**
 * 
 * @param {String} AccessToken 
 * @param {Object} ReqPayload 
 */

export const MoveToGroupClicked = (from) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.MOVE_GROUP_CLICKED,
            payload: from
        })
    }
}
export const ApplyGroupPopup = (AccessToken, ReqPayload) => {
    return (dispatch) => {

        dispatch({
            type: ClassGroupingTypes.GROUP_POPUP_APPLY_ACTION,
            payload: ReqPayload
        })

        let URL = Base_URL + groupingInformation;
        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        Axios.post(URL, ReqPayload, {
            headers: api_request_headers,
            timeout: 0
        }
        ).then(function (response) {
            let PayloadData = response.data.value;

            dispatch({
                type: ClassGroupingTypes.GROUP_POPUP_APPLY_ACTION_SUCCESS,
                payload: PayloadData
            })
        }).catch(error => {
            // let statusCode = error.response == undefined ? 504 : error.response.status

            dispatch(postErrorLog(AccessToken, error, seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start)

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })
        });


    }
}

export const onClickBubbleGrouping = (ReqPayload) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.SELECTED_BUBBLE_IN_GROUPING,
            payload: ReqPayload
        })
    }
}
export const GroupingPagedDisplay = (currentPageNumber) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.GROUPING_PAGE_DISPLAY,
            payload: currentPageNumber
        })
    }
}

export const SortGroupsBasedOnParam = (ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.SORT_GROUPS_BASED_ON_PARAM,
            payload: {
                ParamOnwhichScore,
                Strand_Standard_type,
                Strand_Standard,
                orderOfSort
            }
        })
    }
}

export const moveStudentConfirmation = () => {
    return (dispatch) => {
        dispatch({
            type: ClassGroupingTypes.MOVE_STUDENT_CONFIRM_PARAM
        })
    }
}

export const handlePaginationClick_Navigation = (direction) => {
    return (dispatch) => {
        dispatch({
            type: HANDLE_PAGINATION_CLICK_NAVIGATION,
            payload: direction
        })
    }
}
