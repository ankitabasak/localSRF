import {
  ComparisonTypes,
  STD_PERF_COMPARISONPOPUP_CANCLE_OR_APPLY,
  CLICK_ON_STD_STRAND_IN_COMPARISON,
  CLICK_ON_CLASS_STRAND_IN_COMPARISON,
  CLICK_ON_STD_TEST_IN_COMPARISON,
  CLICK_ON_CLASS_TEST_IN_COMPARISON,
  CLICK_ON_SCHOOL_STRAND_IN_COMPARISON,
  CLICK_ON_SCHOOL_TEST_IN_COMPARISON,
  CLICK_ON_COMPARISON_ITEM,
  GET_CS_COMPARISIONTAB_DATA_SUCCESS,
  GET_ORIGINAL_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS,
  GET_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS,
  COMPARE_POPUP_APPLY_ACTION_SUCCESS,
  COMPARE_POPUP_APPLY_ACTION_FAIL,
  GET_ASSESSMENT_COUNT_IN_COMPARISON,
  GET_GRADES_FOR_COMPARISON_SUCCESS,
  GET_STRADS_IN_COMPARISON_SUCCESS,
  GET_STRADS_IN_COMPARISON,
} from "../Reducer_Action_Types/ComparisonTypes";
import {
  Base_URL,
  Get_Class_Strands,
  Get_school_strands,
  ClassTestGradeListUrl,
  Get_Student_Std_Performance_Comparison,
  Get_Student_TestScore_Comparison,
  Get_Class_Std_Performance_Comparison,
  Get_Class_TestScore_Comparison,
  Get_School_Std_Performance_Comparison,
  Get_School_TestScore_Comparison,
  Get_School_gradesList,
  Get_Comaprison_Std_count,
  Get_District_sp_grades_Api,
  Get_District_strands,
  StudentTestGradeListUrl,
  Get_Student_Strands,
  Get_District_Std_Performance_Comparison,
  Get_District_TestScore_Comparison,
  api_request_headers,
} from "../Utils/globalVars";
import Axios from "axios";
import { SAVE_CONTEXT_SELECTION } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  setStudentIdsWhenMultiSelectionsInSADA,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog } from "./AuthenticationAction";
import {
  ClickOnCompareItem_service,
  Save_Roster_Details_On_Clicking_School_In_Compare_Reports,
} from "../services/universalSelector/universalSelector_2";
// import { SetPreviousReport_Props } from "../Redux_Reducers/Report_redux_functions_to_returnState";
import { SaveAppiledChangesOnSuccessResponse } from "../services/universalSelector/universalSelector_4";
import { SetPreviousReport_Props } from "../services/universalSelector/universalSelector_3";

export const Comparison_Popup = (fromContext, fromTab, status) => {
  let currentStatus = !status;
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.OPEN_COMPARISON_POPUP,
      payload: { fromContext, fromTab, currentStatus },
    });
  };
};

export const EditComparison_Popup = (fromContext, fromTab, status) => {
  let currentStatus = !status;
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.EDIT_COMPARISON_POPUP,
      payload: { fromContext, fromTab, currentStatus },
    });
  };
};

// DropdownToggles Goes here

export const ComparisonPopUpDropDownToggle = (
  fromContext,
  fromtab,
  fromWhichDropDown,
  currentStatus
) => {
  let resultantStatus = !currentStatus;

  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARISON_DROPDOWN_TOGGLE,
      payload: { fromContext, fromtab, fromWhichDropDown, resultantStatus },
    });
  };
};
/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 */

export const selectCompareStrand = (
  fromContext,
  fromtab,
  strand,
  allStrandsSelected
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_POPUP_SELECT_STRAND,
      payload: { fromContext, fromtab, strand, allStrandsSelected },
    });
  };
};

export const Compare_Done_In_Strands_selection = (fromContext, fromtab) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_DONE_IN_STRANDS,
      payload: { fromContext, fromtab },
    });
  };
};

export const RemoveStradsFromSelectionList_ClickONSpan = (
  fromContext,
  fromtab,
  strand
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_REMOVE_STRAND_BY_CLICK_ON_SPAN,
      payload: { fromContext, fromtab, strand },
    });
  };
};

export const Compare_selectStandard = (
  fromContext,
  fromtab,
  selectedStandard
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_POPUP_SELECT_STANDARDS,
      payload: { fromContext, fromtab, selectedStandard },
    });
  };
};

export const CompareCheckAllStandards = (
  fromContext,
  fromtab,
  currentStatus
) => {
  let status_result = !currentStatus;
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_POPUP_STRANDS_CHECK_ALL,
      payload: { fromContext, fromtab, status_result },
    });
  };
};

export const ApplyComparisonPopup = (
  fromContext,
  fromtab,
  AccessToken,
  ReqPayload
) => {
  let URL;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );
    ReqPayload.currentTermId =
      ReqPayload.currentTermId == undefined
        ? getState().Universal.currentTermID
        : ReqPayload.currentTermId;

    dispatch({
      type: ComparisonTypes.COMPARE_POPUP_APPLY_ACTION,
      payload: { fromContext, fromtab, AccessToken, ReqPayload },
    });

    if (fromContext == "school") {
      URL = Base_URL + Get_School_Std_Performance_Comparison;
    } else if (fromContext == "class") {
      URL = Base_URL + Get_Class_Std_Performance_Comparison;
    } else if (fromContext == "student") {
      URL = Base_URL + Get_Student_Std_Performance_Comparison;
    } else {
      URL = Base_URL + Get_District_Std_Performance_Comparison;
    }

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData =
          PayloadData == undefined || PayloadData == null ? [] : PayloadData;
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
          fromContext,
          fromtab,
          PayloadData,
          persist_compare_checkboxes,
        };
        let action = {
          payload,
        };
        let updatedLastActivePropsState = LastActiveUniversalProps,
          updatedUniversalState = Universal;
        if (action.payload.PayloadData.length !== 0) {
          let responseStates = SaveAppiledChangesOnSuccessResponse(
            JSON.parse(JSON.stringify(Universal)),
            action,
            JSON.parse(JSON.stringify(LastActiveUniversalProps))
          );

          updatedLastActivePropsState =
            responseStates.updatedLastActivePropsState;
          updatedUniversalState = responseStates.updatedUniversalState;
        }

        dispatch({
          type: COMPARE_POPUP_APPLY_ACTION_SUCCESS,
          payload: {
            fromContext,
            fromtab,
            PayloadData,
            persist_compare_checkboxes,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });

        dispatch({
          type: COMPARE_POPUP_APPLY_ACTION_FAIL,
          payload: { fromContext, fromtab },
        });
      });
  };
};

export const CheckeCompareOption = (
  fromContext,
  fromtab,
  checkFor,
  checkedStatus
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_CHECK_COMPARE_OPTION,
      payload: { fromContext, fromtab, checkFor, checkedStatus },
    });
  };
};

export const SortComparisonBasedOnParam = (
  fromContext,
  fromtab,
  ParamOnwhichScore,
  Strand_Standard_type,
  Strand_Standard,
  orderOfSort
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.SORT_COMPARE_BASED_ON_PARAM,
      payload: {
        fromContext,
        fromtab,
        ParamOnwhichScore,
        Strand_Standard_type,
        Strand_Standard,
        orderOfSort,
      },
    });
  };
};

export const Get_Cs_ComparisionTab_Data = (
  fromContext,
  fromTab,
  AccessToken,
  ReqPayload
) => {
  let URL;

  if (fromContext == "school") {
    URL = Base_URL + Get_School_TestScore_Comparison;
  } else if (fromContext == "class") {
    URL = Base_URL + Get_Class_TestScore_Comparison;
  } else if (fromContext == "student") {
    URL = Base_URL + Get_Student_TestScore_Comparison;
  } else {
    URL = Base_URL + Get_District_TestScore_Comparison;
  }

  return (dispatch, getState) => {
    dispatch({
      type: ComparisonTypes.GET_CS_COMPARISIONTAB_DATA,
      payload: { fromContext, fromTab },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let compareOptions = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
          fromContext,
          fromTab,
          PayloadData,
          compareOptions,
        };
        let action = {
          payload: payload,
        };
        let { updatedLastActivePropsState, updatedUniversalState } =
          SetPreviousReport_Props(Universal, action, LastActiveUniversalProps);

        dispatch({
          type: GET_CS_COMPARISIONTAB_DATA_SUCCESS,
          payload: {
            fromContext,
            fromTab,
            PayloadData,
            compareOptions,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const navigationArrowsStandardComparison = (
  fromContext,
  fromtab,
  NavLeftCount,
  NavRightCount,
  NavType
) => {
  if (NavType == "left") {
    NavLeftCount = NavLeftCount - 1;
    NavRightCount = NavRightCount - 1;
  } else {
    NavLeftCount = NavLeftCount + 1;
    NavRightCount = NavRightCount + 1;
  }

  const NavigationCounters = {
    NavigationLeftCount: NavLeftCount,
    NavigationRightCount: NavRightCount,
  };

  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_PAGE_STANDARDS_NAV,
      payload: {
        fromContext,
        fromtab,
        NavigationCounters,
      },
    });
  };
};

export const comparisonPopupSelectTaxonomy = (
  fromContext,
  fromtab,
  taxonomy
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARISON_SELECTED_TAXONOMY,
      payload: {
        fromContext,
        fromtab,
        taxonomy,
      },
    });
  };
};

export const comparisonPopupSelectGrade = (
  fromContext,
  fromtab,
  selectedGrade
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARISON_SELECTED_GRADE,
      payload: {
        fromContext,
        fromtab,
        selectedGrade,
      },
    });
  };
};

export const comparisonPopupSelectQuestion = (
  fromContext,
  fromtab,
  selectedQuestion
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARISON_SELECTED_QNUMBER,
      payload: {
        fromContext,
        fromtab,
        selectedQuestion,
      },
    });
  };
};

export const comparisonCurrentPageClick = (
  fromContext,
  fromtab,
  pageNumber
) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARISON_SELECTED_PAGE_DISPLAY,
      payload: { fromContext, fromtab, pageNumber },
    });
  };
};

export const GetGradesListFromComparison = (
  fromContext,
  fromtab,
  AccessToken,
  ReqPayload
) => {
  let URL;

  if (fromContext == "school") {
    URL = Base_URL + Get_School_gradesList;
  } else if (fromContext == "class") {
    URL = Base_URL + ClassTestGradeListUrl;
  } else if (fromContext == "student") {
    URL = Base_URL + StudentTestGradeListUrl;
  } else {
    URL = Base_URL + Get_District_sp_grades_Api;
  }

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: ComparisonTypes.GET_GRADES_FOR_COMPARISON,
      payload: { fromContext, fromtab },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData =
          PayloadData == null || PayloadData == undefined ? [] : PayloadData;

        let PrevNav = getState().LastActiveUniversalProps.NaviGation;
        let CurrentNav = getState().Universal.NavigationByHeaderSelection;
        let sp_persistance = getRequiredDataFromPersist(
          "sp_persistance",
          getState()
        );

        dispatch({
          type: GET_GRADES_FOR_COMPARISON_SUCCESS,
          payload: {
            fromContext,
            fromtab,
            PayloadData,
            CurrentNav,
            PrevNav,
            sp_persistance,
          },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const Get_StandardPerformance_Details_In_Comparison = (
  fromContext,
  fromtab,
  AccessToken,
  ReqPayload
) => {
  let URL;

  if (fromContext == "school") {
    URL = Base_URL + Get_school_strands;
  } else if (fromContext == "class") {
    URL = Base_URL + Get_Class_Strands;
  } else if (fromContext == "student") {
    URL = Base_URL + Get_Student_Strands;
  } else {
    URL = Base_URL + Get_District_strands;
  }

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: GET_STRADS_IN_COMPARISON,
      payload: { fromContext, fromtab },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let PayloadData = response.data.value.strands;
        let PrevNav = getState().LastActiveUniversalProps.NaviGation;
        let sp_persistance = getRequiredDataFromPersist(
          "sp_persistance",
          getState()
        );
        let CurrentNav = getState().Universal.NavigationByHeaderSelection;
        let UserPreferences = getState().Universal.UserPreferences;
        if (PayloadData == null) {
          let selectionoption = "T_scores";
          dispatch({
            type: SAVE_CONTEXT_SELECTION,
            payload: {
              selectionoption,
              productListForGroupPopUp,
              Class_SP_Filter,
              Student,
              Class,
              SlectedStudent,
              SlectedClass,
              SelectedSchool,
            },
          });
        } else {
          dispatch({
            type: GET_STRADS_IN_COMPARISON_SUCCESS,
            payload: {
              fromContext,
              fromtab,
              PayloadData,
              PrevNav,
              CurrentNav,
              UserPreferences,
              sp_persistance,
            },
          });
        }
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const getTestAssessmentMaxCountInComparison = (
  fromContext,
  fromtab,
  AccessToken,
  ReqPayload
) => {
  if (fromContext == "school") {
    ReqPayload.context = "SCHOOL";
  } else if (fromContext == "class") {
    ReqPayload.context = "CLASS";
  } else if (fromContext == "student") {
    ReqPayload.context = "STUDENT";
  } else {
    ReqPayload.context = "DISTRICT";
  }
  let URL = Base_URL + fromContext + "/standardperformance/questionCount";

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: GET_ASSESSMENT_COUNT_IN_COMPARISON,
      payload: { fromContext, fromtab },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let PrevNav = getState().LastActiveUniversalProps.NaviGation;
        if (PayloadData == null) {
          let selectionoption = "T_scores";
          dispatch({
            type: SAVE_CONTEXT_SELECTION,
            payload: { selectionoption, PrevNav },
          });
        } else {
          dispatch({
            type: GET_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS,
            payload: { fromContext, fromtab, PayloadData, PrevNav },
          });
        }
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const getOriginalTestAssessmentMaxCountInComparison = (
  fromContext,
  fromtab,
  AccessToken,
  ReqPayload
) => {
  let URL = Base_URL + Get_Comaprison_Std_count;

  if (fromContext == "school") {
    ReqPayload.context = "SCHOOL";
  } else if (fromContext == "class") {
    ReqPayload.context = "CLASS";
  } else if (fromContext == "student") {
    ReqPayload.context = "STUDENT";
  } else {
    ReqPayload.context = "DISTRICT";
  }

  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.GET_ORIGINAL_ASSESSMENT_COUNT_IN_COMPARISON,
      payload: { fromContext, fromtab },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        if (PayloadData == null) {
          let selectionoption = "T_scores";
          dispatch({
            type: SAVE_CONTEXT_SELECTION,
            payload: { selectionoption },
          });
        } else {
          dispatch({
            type: GET_ORIGINAL_ASSESSMENT_COUNT_IN_COMPARISON_SUCCESS,
            payload: { fromContext, fromtab, PayloadData },
          });
        }
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));

        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const Std_Perf_ComparisonPopUp_Cancle_Or_Apply = (
  cancle,
  Nav,
  compareDataIsThere
) => {
  return (dispatch) => {
    dispatch({
      type: STD_PERF_COMPARISONPOPUP_CANCLE_OR_APPLY,
      payload: { cancle, Nav, compareDataIsThere },
    });
  };
};

export const Compare_Cancel_In_Strands_selection = (fromContext, fromtab) => {
  return (dispatch) => {
    dispatch({
      type: ComparisonTypes.COMPARE_CANCEL_IN_STRANDS,
      payload: { fromContext, fromtab },
    });
  };
};

export const ClickOn_Strd_Item_In_Comparison = (
  selectedItem,
  strand,
  sameReport,
  Nav,
  strandName,
  Taxonomy,
  ActiveGrade
) => {
  return (dispatch, getState) => {
    if (Nav.class || Nav.student) {
      let SameStudent = sameReport;
      let student = selectedItem;
      let { LastActiveUniversalProps } = getState();
      dispatch({
        type: CLICK_ON_STD_STRAND_IN_COMPARISON,
        payload: {
          student,
          strand,
          SameStudent,
          strandName,
          Taxonomy,
          ActiveGrade,
          LastActiveUniversalProps
        },
      });
    } else if (Nav.school) {
      let SameClass = sameReport;
      let Selected_class = selectedItem;
      let { Universal, LastActiveUniversalProps } = getState();
      dispatch({
        type: CLICK_ON_CLASS_STRAND_IN_COMPARISON,
        payload: {
          Selected_class,
          strand,
          SameClass,
          strandName,
          Taxonomy,
          ActiveGrade,
          LastActiveUniversalProps,
        },
      });
    } else if (Nav.district) {
      let SameSchool = sameReport;
      let { Universal, LastActiveUniversalProps } = getState();

      let payload = {
        selectedItem,
        strand,
        SameSchool,
        strandName,
        Taxonomy,
        ActiveGrade,
      };
      let action = {
        payload,
      };
      let ToTestScore = false;
      let { updatedLastActivePropsState, updatedUniversalState } =
        Save_Roster_Details_On_Clicking_School_In_Compare_Reports(
          Universal,
          action,
          ToTestScore,
          LastActiveUniversalProps
        );
      dispatch({
        type: CLICK_ON_SCHOOL_STRAND_IN_COMPARISON,
        payload: {
          selectedItem,
          strand,
          SameSchool,
          strandName,
          Taxonomy,
          ActiveGrade,
          updatedLastActivePropsState,
          updatedUniversalState,
        },
      });
    }
  };
};
export const ClickOn_Test_Item_In_Comparison = (
  selectedUser,
  SelectedTest,
  sameReport,
  Nav
) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState();
    if (Nav.class || Nav.student) {
      let SameStudent = sameReport;
      let student = selectedUser;
      dispatch({
        type: CLICK_ON_STD_TEST_IN_COMPARISON,
        payload: {
          student,
          SelectedTest,
          SameStudent,
          LastActiveUniversalProps,
        },
      });
    } else if (Nav.school) {
      let SameClass = sameReport;
      let Selected_class = selectedUser;
      dispatch({
        type: CLICK_ON_CLASS_TEST_IN_COMPARISON,
        payload: {
          Selected_class,
          SelectedTest,
          SameClass,
          LastActiveUniversalProps,
        },
      });
    } else if (Nav.district) {
      let SameSchool = sameReport;
      let selectedItem = selectedUser;

      let payload = { selectedItem, SelectedTest, SameSchool };
      let action = {
        payload,
      };
      let ToTestScore = true;
      let { updatedLastActivePropsState, updatedUniversalState } =
        Save_Roster_Details_On_Clicking_School_In_Compare_Reports(
          Universal,
          action,
          ToTestScore,
          LastActiveUniversalProps
        );

      dispatch({
        type: CLICK_ON_SCHOOL_TEST_IN_COMPARISON,
        payload: {
          selectedItem,
          SelectedTest,
          SameSchool,
          updatedLastActivePropsState,
          updatedUniversalState,
        },
      });
    }
  };
};

export const ClickOnCompareItem = (SelectedItem, Nav, ActiveGrade) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState();

    let payload = { SelectedItem, Nav, ActiveGrade, Universal };
    let action = {
      payload,
    };

    let { updatedLastActivePropsState, updatedUniversalState } =
      ClickOnCompareItem_service(action, Universal, LastActiveUniversalProps);
    dispatch({
      type: CLICK_ON_COMPARISON_ITEM,
      payload: {
        SelectedItem,
        Nav,
        ActiveGrade,
        Universal,
        updatedLastActivePropsState,
        updatedUniversalState,
      },
    });
  };
};
