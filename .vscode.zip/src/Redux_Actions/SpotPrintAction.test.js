import { expect } from 'chai';
import * as SpotPrintAction from '../Redux_Actions/SpotPrintAction';
import * as SpotPrintTypes from '../Reducer_Action_Types/SpotPrintTypes';
import axios from 'axios';
//import { getRequiredDataFromPersist } from '../../src/Components/ReusableComponents/AllReusableFunctions';

jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});
  // describe('actionCreators', () => {
  //   it('returns the expected object for selectAssessmentItem', () => {
  //     const result = actionCreators.handleSpotPrintOptionSelect("batch");
  //     console.log("result",result);
  //     expect(result).to.deep.equal({
  //       type: actionTypes.SPOT_PRINTING_SELECTED,
  //       selectedOption: 'batch',
  //     });
  //   });
  // });

  describe("Authentication actions", () =>{
    afterEach(() => {
      jest.clearAllMocks();
    });
  it("SpotPrintAction for SPOT_PRINTING_SELECTED batch option", ()=>{
    const dispatch = jest.fn();
    SpotPrintAction.handleSpotPrintOptionSelect("batch")(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SpotPrintTypes.SpotPrintTypes.SPOT_PRINTING_SELECTED, payload: { selectedOption :"batch"}});
  });
  it("SpotPrintAction for SPOT_PRINTING_SELECTED single option", ()=>{
    const dispatch = jest.fn();
    SpotPrintAction.handleSpotPrintOptionSelect("single")(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SpotPrintTypes.SpotPrintTypes.SPOT_PRINTING_SELECTED, payload: { selectedOption :"single"}});
  });
  it("SpotPrintAction for SPOT_PRINTING_CANCEL", ()=>{
    const dispatch = jest.fn();
    SpotPrintAction.handleCancelSpotPrint("dummy","dummy")(dispatch);
    expect(dispatch.mock.calls.length).to.equal(1);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: SpotPrintTypes.SpotPrintTypes.SPOT_PRINTING_CANCEL});
  });

  // it("actionCreators for SPOT_PRINT_SELECT_SHOW ", ()=>{
  //   const dispatch = jest.fn();
  //   //const fn= getState();
  //   const noop = () => {};
  //   let batch_options = getRequiredDataFromPersist("batch_options", noop)
  //   SpotPrintAction.handleSpotPrintingSelectShowOption("avg",noop)(dispatch);
  //   expect(dispatch.mock.calls.length).to.equal(1);
  //   expect(dispatch.mock.calls[0][0]).to.eql({  type: SpotPrintTypes.SpotPrintTypes.SPOT_PRINT_SELECT_SHOW, payload: { option :"avg"}});
  // });
});