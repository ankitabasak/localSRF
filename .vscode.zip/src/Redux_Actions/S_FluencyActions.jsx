import { S_FluencyTypes } from '../Reducer_Action_Types/S_FluencyTypes.jsx';
import { Student_Fluency_Api, ORR_URL, dummyToken, CSV_DOWNLOAD_STUDENT } from '../Utils/globalVars';
import axios from 'axios';

export const S_Fluency_Chart_Data = (AccessToken, data) => {
  let AuthURL = ORR_URL + Student_Fluency_Api;
  let Payload;
  let dummyToken;
  Payload = data;
  return dispatch => {
    dispatch({
      type: S_FluencyTypes.SFA_LOADER
    })
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        dispatch({
          type: S_FluencyTypes.S_FLUENCY_DATA_SUCCESS,
          payload: {
            Response_Data
          }
        });
      })
      .catch(function (error) {
        if (error.response) {
          if (error.response.data.errorCode === 407) {
            dispatch({
              type: S_FluencyTypes.S_FLUENCY_RUBRIC_FAIL,
              payload: error.response.data.errorMessage
            });
          } else {
            dispatch({
              type: S_FluencyTypes.S_FLUENCY_DATA_FAIL,
              payload: null
            });
          }
        } else {
          dispatch({
            type: S_FluencyTypes.S_FLUENCY_DATA_FAIL,
            payload: null
          });
        }

      });
  };
};

//load icon action
export const LOADER_ICON = obj => {
  return dispatch => {
    dispatch({
      type: S_FluencyTypes.LOAD_ICON,
      payload: obj
    });
  };
};

export const SFA_SCROLL = data => {
  return dispatch => {
    dispatch({
      type: S_FluencyTypes.SFA_XAXIS_SCROLL,
      payload: data
    });
  };
};

export const OVERLAY_FLAG = data => {
  return dispatch => {
    dispatch({
      type: S_FluencyTypes.SHOW_OVERLAY_FLAG,
      payload: data
    });
  };
};


export const Update_Sfa_Tooltip = data => {
  return dispatch => {
    dispatch({
      type: S_FluencyTypes.SFA_UPDATE_TOOLTIP_DATA,
      payLoad: data
    });
  };
}

export const SF_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: S_FluencyTypes.SF_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SF_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_STUDENT;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: S_FluencyTypes.SF_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: S_FluencyTypes.S_FLUENCY_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};