import {
  Base_URL,
  RosterTab_Post,
  Ts_Roster_Grades,
  Get_Grades_schools_for_Dist,
  Get_classes_for_Dist,
  Get_Teachers_Students_for_Dist,
  api_request_headers,
} from "../Utils/globalVars";
import {
  U_S_Action_Types,
  APPLY_FILTERS_IN_ROSTER_TAB,
  GET_TS_ROSTER_GRADES,
  GET_TS_ROSTER_GRADES_SUCCESS,
  GET_TS_ROSTER_GRADES_FAIL,
  GET_ROSTER_GRADES_AND_SCHOOLS,
  GET_ROSTER_GRADES_AND_SCHOOLS_SUCCESS,
  GET_ROSTER_CLASSES,
  GET_ROSTER_CLASSES_SUCCESS,
  GET_ROSTER_TEACHERS_STUDENTS,
  GET_ROSTER_TEACHERS_STUDENTS_SUCCESS,
  APPLY_FILTERS_IN_TEST_TAB,
  SAVE_SELECTED_SCHOOL_API_SUCCESS,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { Return_ERROR_Status_Code } from "../Components/ReusableComponents/AllReusableFunctions";
import {
  SaveSelected_School_in_RosterTab_service,
  ApplyFilterInRoasterTab_service,
} from "../services/UniversalSelectorActions.service";

import axios from "axios";
import { postErrorLog } from "./AuthenticationAction";
import {
  rosterGradeAnd_Schools_success,
  teachers_Students_Success,
} from "../services/universalSelector/universalSelector_1";
import { Save_Selected_School_Api_CAll_function } from "../Redux_Reducers/U_reducer_functions_to_returnSate";

/**
 *
 * @param {object} field  -- school/class/student
 * Action to open And close DropDown View of list selection for school,class & student.
 */

export const OpenSelectorInRoaster = (
  field,
  Call_Get_SChool_Details_Api,
  selected_School,
  AccessToken,
  Dateterm,
  fromDist_Reports
) => {
  return (dispatch, getState) => {
    let No_teachers_There_For_School = false;

    if (selected_School && selected_School.grades) {
      let Teachers = [];
      selected_School.grades.map((item) => {
        let teach = item.teachers ? item.teachers : [];
        Teachers = Teachers.concat(teach);
      });

      No_teachers_There_For_School = Teachers.length == 0;
    } else {
      No_teachers_There_For_School = true;
    }
    if (Call_Get_SChool_Details_Api && No_teachers_There_For_School) {
      let ReqPayload = {
        dateTerm: Dateterm,
        school: selected_School,
      };

      let URL = Base_URL + RosterTab_Post;

      dispatch({
        type: U_S_Action_Types.SAVE_SELECTED_SCHOOL_API,
        payload: { AccessToken, fromDist_Reports },
      });

      let seconds_Start = new Date().getTime() / 1000;
      api_request_headers.Authorization = "Bearer ".concat(AccessToken);
      axios
        .post(URL, ReqPayload, {
          headers: api_request_headers,
        })
        .then(function (response) {
          let PayloadData = response.data.value;

          let { Universal, LastActiveUniversalProps } = getState();

          let payload = {
            PayloadData,
            fromDist_Reports,
          };
          let action = {
            payload,
          };

          let { updatedLastActivePropsState, updatedUniversalState } =
            Save_Selected_School_Api_CAll_function(
              JSON.parse(JSON.stringify(Universal)),
              action,
              JSON.parse(JSON.stringify(LastActiveUniversalProps))
            );

          dispatch({
            type: SAVE_SELECTED_SCHOOL_API_SUCCESS,
            payload: {
              PayloadData,
              fromDist_Reports,
              updatedLastActivePropsState,
              updatedUniversalState,
            },
          });
        })
        .catch(function (error) {
          dispatch(postErrorLog(AccessToken, error, seconds_Start));
          // error.message == 'Network Error' ? 502 :
          let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });

          dispatch({
            type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
            payload: { statusCode },
          });
        });
    } else {
      dispatch({
        type: U_S_Action_Types.OPEN_SELECTOR_IN_ROSTER,
        payload: field,
      });
    }
  };
};

export const SaveSelectedSchool = (
  school,
  index,
  check,
  AccessToken,
  Dateterm,
  fromDist_Reports,
  Current_Selected_Sc_List,
  SchoolAdmin
) => {
  return (dispatch, getState) => {
    let UniversalState = getState().Universal;
    let isTeacher = UniversalState.ContextHeader.User_Role == "TEACHER";

    if (
      school !== "All" &&
      (fromDist_Reports ||
        getState().Universal.NavigationByHeaderSelection.Summary_Reports ||
        ((SchoolAdmin || isTeacher) &&
          (school.grades == null || school.grades == undefined)))
    ) {
      let DatesList = UniversalState.ContextHeader.Date_Tab.DistrictTerms_New;

      let CUrrentTermObj =
        DatesList &&
        DatesList.find((item) => item.termId === UniversalState.currentTermID);

      let ReqPayload = {
        dateTerm: CUrrentTermObj ? CUrrentTermObj : Dateterm,
        school: school,
      };

      let URL = Base_URL + RosterTab_Post;

      dispatch({
        type: U_S_Action_Types.SAVE_SELECTED_SCHOOL_API,
        payload: { AccessToken, school },
      });
      let seconds_Start = new Date().getTime() / 1000;
      api_request_headers.Authorization = "Bearer ".concat(AccessToken);
      axios
        .post(URL, ReqPayload, {
          headers: api_request_headers,
        })
        .then(function (response) {
          let PayloadData = response.data.value;

          let { Universal, LastActiveUniversalProps } = getState();

          let payload = {
            PayloadData,
            fromDist_Reports,
          };
          let action = {
            payload,
          };

          let { updatedLastActivePropsState, updatedUniversalState } =
            Save_Selected_School_Api_CAll_function(
              JSON.parse(JSON.stringify(Universal)),
              action,
              JSON.parse(JSON.stringify(LastActiveUniversalProps))
            );

          dispatch({
            type: SAVE_SELECTED_SCHOOL_API_SUCCESS,
            payload: {
              PayloadData,
              fromDist_Reports,
              updatedLastActivePropsState,
              updatedUniversalState,
            },
          });
        })
        .catch(function (error) {
          dispatch(postErrorLog(AccessToken, error, seconds_Start));
          let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });

          dispatch({
            type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
            payload: { statusCode },
          });
        });
    } else {
      let U_selector = getState().Universal;
      let RosterData = SaveSelected_School_in_RosterTab_service(
        U_selector,
        school,
        index,
        check
      );

      RosterData = RosterData.Roster_Data;
      dispatch({
        type: U_S_Action_Types.SAVE_SELECTED_SCHOOL,
        payload: { school, index, check, RosterData },
      });
    }
  };
};

/**
 * Action triggers to apply Roaster tab filter
 */
export const ApplyRoasterTabFilter = (sameClass, Nav) => {
  return (dispatch, getState) => {
    const state = getState();
    const U_selector = state.Universal;
    let LastActiveUniversalProps = JSON.parse(JSON.stringify( state.LastActiveUniversalProps));

    let payload = { sameClass, Nav, U_selector };

    let StateToSet = ApplyFilterInRoasterTab_service(
      U_selector,
      LastActiveUniversalProps
    );

    dispatch({
      type: APPLY_FILTERS_IN_ROSTER_TAB,
      payload: { sameClass, Nav, U_selector, StateToSet },
    });
  };
};

/**
 *
 * @param {Roaster,test,date} selectedModule
 *  Action to open universal filter tabs ()
 */
export const OpenUniversalFilter = (selectedModule) => {
  return (dispatch, getState) => {
    let Nav = getState().Universal.NavigationByHeaderSelection;

    dispatch({
      type: U_S_Action_Types.OPEN_UNIVERSAL_FILTER,
      payload: { selectedModule, Nav },
    });
  };
};

/**
 *
 * @param {true/false } value
 * @param {selected test id,name} Element
 * triggers after selection of a test from test tab.
 */
export const CheckOrUncheckTestCheckBox = (value, Element) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.CHECK_OR_UNCHECK_TEST_CHECKBOX,
      payload: { value, Element },
    });
  };
};

/**
 *
 * @param {Object} Element --selected testtype id,name
 *
 */
export const UncheckTestTypeByClickingOnDisplaySpan = (Element) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.UNCHECK_TEST_TYPE_BY_CLICKING_ON_DISPLAY_SPAN,
      payload: { Element: Element },
    });
  };
};

export const OpenOrCloseTestTypes = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.OPEN_OR_CLOSE_TEST_TYPES,
    });
  };
};

export const ApplyFiltersInTestTab = (
  AccessToken,
  Req_Payload,
  IsClassInstance,
  U_selector
) => {
  return (dispatch, getState) => {
    const state = getState();
    const Nav = state.Universal.NavigationByHeaderSelection;
    const selectedTest =
      state.Universal.UniversalSelecter.TestTab.SelectedTestList;
    dispatch({
      type: APPLY_FILTERS_IN_TEST_TAB,
      payload: { Nav, U_selector, selectedTest },
    });
  };
};

export const CheckOrUncheckTestTypeCheckBox = (value, Element) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.CHECK_OR_UNCHECK_TEST_TYPE_CHECKBOX,
      payload: { value, Element },
    });
  };
};

export const StoreFilteredListInTest = (list, listType, Searchvalue) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_FILTERED_LIST_IN_TEST,
      payload: { list, listType, Searchvalue },
    });
  };
};

/** Action to Close universal filter tabs */
export const CloseUniversalFilter = (from) => {
  return (dispatch, getState) => {
    const stateOfContext = getState();

    dispatch({
      type: U_S_Action_Types.CLOSE_UNIVERSAL_FILTER,
      payload: from,
      stateOfContext,
    });
  };
};

export const Get_TestStatus_Roster_Grades = (AccessToken, ReqPayload) => {
  return (dispatch, getState) => {
    let URL = Base_URL + Ts_Roster_Grades;

    dispatch({
      type: GET_TS_ROSTER_GRADES,
      payload: AccessToken,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;

        dispatch({
          type: GET_TS_ROSTER_GRADES_SUCCESS,
          payload: { PayloadData },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: GET_TS_ROSTER_GRADES_FAIL,
          payload: { statusCode },
        });

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });

        dispatch({
          type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
          payload: { statusCode },
        });
      });
  };
};
export const Get_Roster_GradesAndschools = (AccessToken, ReqPayload) => {
  return (dispatch, getState) => {
    let URL = Base_URL + Get_Grades_schools_for_Dist;

    dispatch({
      type: GET_ROSTER_GRADES_AND_SCHOOLS,
      payload: AccessToken,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        let { lazyLoad_eAR_Default_Api } = getState().Authentication.Auth_Apis;

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = { PayloadData, lazyLoad_eAR_Default_Api };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          rosterGradeAnd_Schools_success(
            action,
            Universal,
            LastActiveUniversalProps
          );

        dispatch({
          type: GET_ROSTER_GRADES_AND_SCHOOLS_SUCCESS,
          payload: {
            PayloadData,
            lazyLoad_eAR_Default_Api,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
      });
  };
};

export const Get_Roster_Classes = (AccessToken, ReqPayload) => {
  return (dispatch, getState) => {
    let URL = Base_URL + Get_classes_for_Dist;

    dispatch({
      type: GET_ROSTER_CLASSES,
      payload: AccessToken,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;

        let NostrandsONInitialLoad =
          getState().DistrictReducer.D_StandardPerformance_Overview
            .StandardPerformanceFilter.NodataInStrands;

        dispatch({
          type: GET_ROSTER_CLASSES_SUCCESS,
          payload: { PayloadData, NostrandsONInitialLoad },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
      });
  };
};

export const Get_Roster_Teachers_Students = (AccessToken, ReqPayload) => {
  return (dispatch, getState) => {
    let URL = Base_URL + Get_Teachers_Students_for_Dist;

    dispatch({
      type: GET_ROSTER_TEACHERS_STUDENTS,
      payload: AccessToken,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;

        let action = {
          payload: { PayloadData },
        };
        let { Universal, LastActiveUniversalProps } = getState();
        let { updatedLastActivePropsState, updatedUniversalState } =
          teachers_Students_Success(
            action,
            Universal,
            LastActiveUniversalProps
          );

        dispatch({
          type: GET_ROSTER_TEACHERS_STUDENTS_SUCCESS,
          payload: {
            PayloadData,
            updatedUniversalState,
            updatedLastActivePropsState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
      });
  };
};
