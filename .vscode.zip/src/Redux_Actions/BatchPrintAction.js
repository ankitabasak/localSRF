import { BatchPrintTypes } from "../Reducer_Action_Types/BatchPrintTypes";
import { U_S_Action_Types } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { Get_BatchPrint_SingleTest, Get_BatchPrint_Summary, Base_URL, Get_BatchPrint_StudentList, ClassSummary, api_request_headers } from "../Utils/globalVars";
import axios from "axios";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { Return_ERROR_Status_Code, getRequiredDataFromPersist } from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog } from "./AuthenticationAction";

export const batchPrintingCancel = (from, fromtab) => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINTING_CANCEL,
            payload: { from, fromtab }
        })
    }
}

export const batchPrintingPrintClick = (from, fromtab, ReqPayload, AccessToken, popUpStatus) => {

    let URL = Base_URL;

    if (from == "class") {
        if (fromtab == "summary") {
            URL = URL + Get_BatchPrint_Summary
        } else {
            URL = URL + Get_BatchPrint_SingleTest
        }
    } else {
        if (fromtab == "summary") {
            URL = URL + Get_BatchPrint_Summary
        } else {
            URL = URL + Get_BatchPrint_SingleTest
        }
    }

    return (dispatch, getState) => {

        const { SingleTestAnalysis } = getState()

        const { class_TestAnalysis, student_TestAnalysis } = SingleTestAnalysis

        let selectedTaxonomyList;

        if (from == 'class') {
            selectedTaxonomyList = class_TestAnalysis.Filter.TaxonomyParams.selectedTaxonomyList_temp
        } else {
            selectedTaxonomyList = student_TestAnalysis.Filter.TaxonomyParams.selectedTaxonomyList_temp
        }

        dispatch({
            type: BatchPrintTypes.BATCH_PRINT_API,
            payload: { from, fromtab, popUpStatus }
        })

        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        axios.post(URL, ReqPayload, {
            headers: api_request_headers,
        }).then(function (response) {
            let payloadData = response.data.value;
            dispatch({
                type: BatchPrintTypes.BATCH_PRINT_API_SUCCESS,
                payload: { from, fromtab, payloadData, popUpStatus, selectedTaxonomyList }
            })
        }).catch(function (error) {
            dispatch(postErrorLog(AccessToken,error,seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })

            dispatch({
                type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
                payload: error.response
            })
        });

    }
}
export const batchPrintingSelectDescription = (from, fromtab, selectedOption) => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINT_SELECT_DESCRIPTION,
            payload: { from, fromtab, selectedOption }
        })
    }
}
export const batchPrintingSelectedPage = (from, fromtab, selectedPage) => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINT_CURRENT_SELECTED_PAGE,
            payload: { from, fromtab, selectedPage }
        })
    }
}
export const batchPrintingPopupStatus = (from, fromtab) => {
    return (dispatch,getState) => {
        let batch_options = getRequiredDataFromPersist("batch_options", getState());
        dispatch({
            type: BatchPrintTypes.BATCH_PRINTING_POPUP_STATUS,
            payload: { from, fromtab, batch_options }
        })

    }
}

export const handleCancelBatchPrint = (from, fromtab) => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINTING_CANCEL,
            payload: { from, fromtab }
        })
    }
}

export const handleBatchPrintOptionSelect = (from, fromtab, selectedOption) => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINTING_SELECTED,
            payload: { from, fromtab, selectedOption }
        })
    }
}

export const handleDefaultReportPrint = (from, fromtab, popUpStatus) => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.DEFAULT_REPORT_SELECTED,
            payload: { from, fromtab, popUpStatus }
        })
    }
}

export const resetTriggerPDF = () => {
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINT_RESET_PDF_TRIGGER
        })
    }
}

export const batchPrintGetStudentList = (ReqPayload, AccessToken) => {

    let URL = Base_URL + Get_BatchPrint_StudentList;
    return (dispatch) => {
        dispatch({
            type: BatchPrintTypes.BATCH_PRINT_GET_STUDENTS_LIST
        })

        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        axios.post(URL, ReqPayload, {
            headers: api_request_headers,
        }).then(function (response) {
            let payloadData = response.data.value;
            dispatch({
                type: BatchPrintTypes.BATCH_PRINT_GET_STUDENTS_LIST_SUCCESS,
                payload: { payloadData }
            })
        }).catch(function (error) {
            dispatch(postErrorLog(AccessToken,error,seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })

            dispatch({
                type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
                payload: error.response
            })

        });
    }

}