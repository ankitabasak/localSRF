import { Class_RB_Types } from "../Reducer_Action_Types/Class_RB_Action_Types";
import {
  CRB_Chart_API,
  Base_URL,
  ORR_URL,
  CRB_SidePanel_API,
  CSV_DOWNLOAD_CLASS
} from "../Utils/globalVars";
// import Axios from "axios";
import axios from "axios";

export const Show_loading_Icon = () => {
  return dispatch => {
    dispatch({
      type: Class_RB_Types.API_LOADER,
      payload: {}
    });
  };
};

//function to show icons and sort columns
export const CLASS_RB_SORT_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: Class_RB_Types.CLASS_RB_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

// chart loading failed
export const Chart_loading_Failed = data => {
  return dispatch => {
    dispatch({ type: Class_RB_Types.API_ERROR_HANDLER, payload: data });
  };
};
// chart loading failed
export const updateSelectedItems = data => {
  let cpbSidePanelRequestList = [];

  return dispatch => {
    Promise.resolve(
      dispatch({ type: Class_RB_Types.UPDATE_SELECTED_BOXES, payload: data })
    ).then(() => {
      // let recList = setGradeToSelectedLevels(selectedLevels);
      //   dispatch(CRB_SidePanel_API_Call(token, payload));
    });
  };
};
// Update accordion state
export const Update_Accordion_State = (state, index) => {
  let updatedState = state;
  updatedState[index] = !updatedState[index];
  return dispatch => {
    dispatch({ type: Class_RB_Types.UPDATE_ACCORDION_STATE, payload: updatedState });
  };
};


//CRB Chart API call
export const CRB_Chart_API_Call = (AccessToken, payLoad) => {

  let API_URL = ORR_URL + CRB_Chart_API;

  return dispatch => {
    axios.post(API_URL, payLoad, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        responseType: "application/json",
        Authorization: "Bearer ".concat(AccessToken)
      }
    })
      .then(response => {
        if (
          response.data.responseList &&
          response.data.responseList.length > 0
        ) {

          // Merging duplicate rubrics
          response.data.responseList = mergeDuplicateRubricsData(response.data.responseList)

          let selectedErrors = {
            recentRecordCount: [],
            firstRecordCount: [],
            allRecordRange: []
          };
          let errorList =
            response.data.responseList[response.data.responseList.length - 1]
              .resultList;
          errorList.forEach(item => {
            if (item["recentRecordCount"]) {
              selectedErrors["recentRecordCount"].push({
                criteriaName: item.sourceCriteriaName,
                rbType: "recentRecordCount",
                rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                sourceCriteriaId: item["sourceCriteriaId"],
                selectedRanges: null
              });
            } else if (item["firstRecordCount"]) {
              selectedErrors["firstRecordCount"].push({
                criteriaName: item.sourceCriteriaName,
                rbType: "firstRecordCount",
                rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                sourceCriteriaId: item["sourceCriteriaId"],
                selectedRanges: null
              });
            } else {

              if (item['range0_25']) {
                selectedErrors["allRecordRange"].push({
                  criteriaName: item.sourceCriteriaName,
                  rbType: "allRecordRange",
                  rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                  sourceCriteriaId: item["sourceCriteriaId"],
                  selectedRanges: '0-25'
                });
              } else if (item['range26_50']) {
                selectedErrors["allRecordRange"].push({
                  criteriaName: item.sourceCriteriaName,
                  rbType: "allRecordRange",
                  rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                  sourceCriteriaId: item["sourceCriteriaId"],
                  selectedRanges: '26-50'
                });
              } else if (item['range51_75']) {
                selectedErrors["allRecordRange"].push({
                  criteriaName: item.sourceCriteriaName,
                  rbType: "allRecordRange",
                  rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                  sourceCriteriaId: item["sourceCriteriaId"],
                  selectedRanges: '51-75'
                });
              } else if (item['range76_100']) {
                selectedErrors["allRecordRange"].push({
                  criteriaName: item.sourceCriteriaName,
                  rbType: "allRecordRange",
                  rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                  sourceCriteriaId: item["sourceCriteriaId"],
                  selectedRanges: '76-100'
                });
              }
            }
          });
          // selectedBoxes
          let selectedBoxes = {};

          if (
            selectedErrors["recentRecordCount"] &&
            selectedErrors["recentRecordCount"].length > 0
          ) {
            selectedBoxes["recentRecordCount"] =
              selectedErrors["recentRecordCount"];
          } else if (
            selectedErrors["firstRecordCount"] &&
            selectedErrors["firstRecordCount"].length > 0
          ) {
            selectedBoxes["firstRecordCount"] =
              selectedErrors["firstRecordCount"];
          } else if (selectedErrors["allRecordRange"] &&
            selectedErrors["allRecordRange"].length > 0) {
            selectedBoxes["allRecordRange"] =
              selectedErrors["allRecordRange"];
          }

          Promise.resolve(
            dispatch({
              type: Class_RB_Types.CRB_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseList,
                selectedBoxes: selectedBoxes
              }
            })
          ).then(response => {
            let tempobj = [];
            let sb = selectedBoxes;
            let label = null;

            if (sb["recentRecordCount"] && sb["recentRecordCount"].length > 0) {
              label = "recentRecord";
              sb["recentRecordCount"].forEach(obj => {
                tempobj.push({
                  sourceRubricId: obj["rubricId"],
                  sourceCriteriaId: obj["sourceCriteriaId"],
                  selectedRanges: null
                });
              });
            } else if (
              sb["firstRecordCount"] &&
              sb["firstRecordCount"].length > 0
            ) {
              label = "firstRecord";
              sb["firstRecordCount"].forEach(obj => {
                tempobj.push({
                  sourceRubricId: obj["rubricId"],
                  sourceCriteriaId: obj["sourceCriteriaId"],
                  selectedRanges: null
                });
              });
            } else if (
              sb["allRecordRange"] &&
              sb["allRecordRange"].length > 0
            ) {
              label = "allRecordRange";
              sb["allRecordRange"].forEach(obj => {
                tempobj.push({
                  sourceRubricId: obj["rubricId"],
                  sourceCriteriaId: obj["sourceCriteriaId"],
                  selectedRanges: obj['selectedRanges']
                });
              });
            }
          });
        } else {
          dispatch({
            type: Class_RB_Types.API_ERROR_HANDLER,
            payload: {
              noChartData: true,
              apiLoadFail: false,
              isApiLoading: false,
              timeout: false
            }
          });
        }

      })
      .catch(function (error) {
        if (error.response) {
          if (error.response.data.errorCode === 407) {
            dispatch({
              type: Class_RB_Types.C_RB_RUBRIC_FAIL,
              payload: error.response.data.errorMessage
            });
          } else {
            dispatch({
              type: Class_RB_Types.API_ERROR_HANDLER,
              payload: {
                noChartData: false,
                apiLoadFail: true,
                isApiLoading: false,
                timeout: false
              }
            });
          }
        } else {
          dispatch({
            type: Class_RB_Types.API_ERROR_HANDLER,
            payload: {
              noChartData: false,
              apiLoadFail: true,
              isApiLoading: false,
              timeout: false
            }
          });
        }
      });
  };

  // update chart scroll update
};

export const CRB_SidePanel_API_Call = (AccessToken, payLoad) => {

  let API_URL = ORR_URL + CRB_SidePanel_API;

  return dispatch => {
    axios.post(API_URL, payLoad, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        responseType: "application/json",
        Authorization: "Bearer ".concat(AccessToken)
      }
    })
      .then(response => {
        dispatch({
          type: Class_RB_Types.CRB_SIDEPANEL_API_SUCCESS,
          payload: response.data
        });
      })
      .catch(function (error) {
        dispatch({
          type: Class_RB_Types.SIDE_PANEL_API_FAIL
        });
      });
  };
};

// table sort
export const SAVE_SORTED_GRID_DATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: Class_RB_Types.SAVE_SORTED_GRID_DATA,
      payload: { SortedArray }
    });
  };
};

// table sort

//function to show icons and sort columns
export const SCHOOL_RB_SORT_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: Class_RB_Types.School_RB_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

function mergeDuplicateRubricsData(data) {
  const resultArray = []
  let mergeItems = []
  data.forEach((obj) => {
    mergeItems = [];
    if (rubricNotProccessed(resultArray, obj)) {
      let duplicateItems = data.filter((item) => {
        return obj.sourceRubricName == item.sourceRubricName;
      })

      if (duplicateItems.length > 1) {
        let tempObj = duplicateItems[0];
        duplicateItems.forEach((subItems) => {
          mergeItems = [...mergeItems, ...subItems['resultList']]
        })
        tempObj['resultList'] = getUnique(mergeItems, 'sourceCriteriaName');
        resultArray.push(tempObj)
      } else {
        resultArray.push(duplicateItems[0])
      }
    }
  })
  return resultArray;
}
function rubricNotProccessed(dataList, item) {
  let rubricNotFound = true;
  if (dataList.length > 0) {
    dataList.forEach((obj) => {
      if (obj.sourceRubricName == item.sourceRubricName) {
        rubricNotFound = false;

      }
    })
  }
  return rubricNotFound;
}
function getUnique(arr, comp) {

  const unique = arr
    .map(e => e[comp])

    // store the keys of the unique objects
    .map((e, i, final) => final.indexOf(e) === i && i)

    // eliminate the dead keys & store unique objects
    .filter(e => arr[e]).map(e => arr[e]);

  return unique;
}

export const CRB_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: Class_RB_Types.CRB_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const CRB_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_CLASS;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: Class_RB_Types.CRB_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        dispatch({
          type: Class_RB_Types.API_ERROR_HANDLER,
          payload: {
            noChartData: false,
            apiLoadFail: true,
            isApiLoading: false,
            timeout: false
          }
        });
      });
  };
};