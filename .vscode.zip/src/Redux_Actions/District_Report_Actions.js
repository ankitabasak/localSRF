import {
  Base_URL,
  DistrictAGPCSV,
  Get_District_sp_grades_Api,
  Get_District_QuestionCount,
  Get_LineChart_of_District_strands,
  Get_District_strands,
  Get_Schools_Of_SelectedStrand,
  Get_Dist_TS_Graph,
  Get_Selected_Test_Details_In_Dist_TS_,
  api_request_headers,
} from "../Utils/globalVars";
import { School_Action_Types } from "../Reducer_Action_Types/School_Report_Types";
import { AGP_CSVPOPUPCONFIRMATION } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import Axios from "axios";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  District_Action_Types,
  GET_DISTRICT_STRAND_DETAILS_SUCCESS,
  GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS,
  GET_DISTRICT_STRANDS_GRADES,
  GET_DISTRICT_STRANDS_GRADES_SUCCESS,
  GET_DISTRICT_TS_GRAPH_DETAILS,
  GET_DISTRICT_STRAND_DETAILS_FAIL,
  GET_DISTRICT_STRAND_DETAILS,
  GET_SCHOOL_DETAILS_ON_STRAND_SELECTION_SUCCESS,
  GET_SELECTED_TS_DETAILS,
  GET_DISTRICT_STRANDS_QUESTION_COUNT_SUCCESS,
  GET_SELECTED_TS_DETAILS_SUCCESS_IN_DISTRICT,
  GET_DISTRICT_STRANDS_QUESTION_COUNT,
} from "../Reducer_Action_Types/District_Report_Types";

import {
  Sort_ApiResponse_Payload_Array,
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  GetAssessed_Ques_ToPersist,
  GetTaxonomy_ToPersist,
  GetTaxonomy_ToPersist_AndStrandDetails,
  setStudentIdsWhenMultiSelectionsInSADA,
  TestToPersistInTestScoreGraph,
} from "../Components/ReusableComponents/AllReusableFunctions";

import { postErrorLog } from "./AuthenticationAction";
import { district_TS_OR_SP_Success } from "../services/universalSelector/universalSelector_1";
import { filterAssessedGrade } from "../Utils/reUsableSnipets";

/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 *
 * to get school grades from server.
 *
 */
export const getGradeListOfDistrict = (AccessToken, ReqPayload) => {
  let URL = Base_URL + Get_District_sp_grades_Api;

  return (dispatch,getState) => {
    dispatch({
      type: GET_DISTRICT_STRANDS_GRADES,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let { persitedTestAssessGrade } = getState().SummaryReports;
        let ActiveGrade = ReqPayload.grade;
        if (
          PayloadData !== null &&
          PayloadData !== undefined &&
          ActiveGrade !== undefined
        ) {
          const found = PayloadData.find((item) => item.grade == ActiveGrade);
          if (found !== undefined) {
            ActiveGrade = found;
          } else {
            ActiveGrade = PayloadData[0];
          }
        } else {
          ActiveGrade = PayloadData[0];
        }
        let SelectedTestAssessedGrade = null;
        if (persitedTestAssessGrade && persitedTestAssessGrade != null) {
          SelectedTestAssessedGrade = filterAssessedGrade(persitedTestAssessGrade,PayloadData);
          ActiveGrade = SelectedTestAssessedGrade[0];
      }
        PayloadData = Sort_ApiResponse_Payload_Array(PayloadData, "grades");
        dispatch({
          type: GET_DISTRICT_STRANDS_GRADES_SUCCESS,
          payload: { PayloadData, ActiveGrade },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
/**
 *
 * @param {Boolean} openOrClose
 * @param {String} SelectedNav
 * is to open the tooltip in district standards performance/testscores overview component.
 */
export const OpenOrCloseTooltipIn_D_Reports = (openOrClose, SelectedNav) => {
  return (dispatch) => {
    dispatch({
      type: District_Action_Types.OPEN_OR_CLOSE_TOOLTIP_IN_D_REPORTS,
      payload: { openOrClose, SelectedNav },
    });
  };
};
/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 */
export const getTestAssessmentMaxCountOfDistrict = (
  AccessToken,
  ReqPayload
) => {
  let URL = Base_URL + Get_District_QuestionCount;

  return (dispatch, getState) => {
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    dispatch({
      type: GET_DISTRICT_STRANDS_QUESTION_COUNT
      
    });
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let LastActiveNav = getState().LastActiveUniversalProps.NaviGation;

        let QuestionToPersist;
        if (!LastActiveNav.district) {
          QuestionToPersist = GetAssessed_Ques_ToPersist(
            LastActiveNav,
            getState
          );
          // let Universal =
        }
        dispatch({
          type: GET_DISTRICT_STRANDS_QUESTION_COUNT_SUCCESS,
          payload: { PayloadData, QuestionToPersist },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} reqObject
 * @param {Boolean} EnableLoading
 * to get class strands table details.
 */
export const Get_District_StandardPerformance_Details = (
  AccessToken,
  reqObject,
  EnableLoading
) => {
  let URL = Base_URL + Get_District_strands;
  return (dispatch, getState) => {
    dispatch({
      type: GET_DISTRICT_STRAND_DETAILS,
      payload: EnableLoading,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, reqObject, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let Data = response.data.value;
        Data = Data == null || Data == undefined ? [] : Data;

        let { Universal, LastActiveUniversalProps,DistrictReducer } = getState();

        let LastNav = LastActiveUniversalProps.NaviGation;
        let UserPreferences = Universal.UserPreferences;
        let last_active_Taxonomy_And_StrandDetails;
        let currentNav = Universal.NavigationByHeaderSelection;
        if (currentNav.S_performance && currentNav.Overview) {
          if (
            (currentNav.S_performance && currentNav.Overview) ||
            LastNav.Summary_Reports
          ) {
            last_active_Taxonomy_And_StrandDetails =
              GetTaxonomy_ToPersist_AndStrandDetails(LastNav, getState);
          }
        }
        let payload = {
          Data,
          last_active_Taxonomy_And_StrandDetails,
          UserPreferences,
          LastNav,
        };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          district_TS_OR_SP_Success(
            action,
            Universal,
            LastActiveUniversalProps,
            "Strands"
          );

        dispatch({
          type: GET_DISTRICT_STRAND_DETAILS_SUCCESS,

          payload: {
            Data,
            last_active_Taxonomy_And_StrandDetails,
            UserPreferences,
            LastNav,
            updatedLastActivePropsState,
            updatedUniversalState,
            DistrictReducer
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        dispatch({
          type: GET_DISTRICT_STRAND_DETAILS_FAIL,
          payload: error,
        });
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} strandName --selected STrand Name
 * @param {string} standardAvg -- selected standard evg.
 */
export const GetSchoolDetailsOf_SelectedStrands = (
  AccessToken,
  ReqPayload,
  strandId,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading,
  selectedTaxonomy,
  Sel_Ass_Ques
) => {
  let URL = Base_URL + Get_Schools_Of_SelectedStrand;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: District_Action_Types.GET_SCHOOL_DETAILS_ON_STRAND_SELECTION,
      payload: {
        strandId,
        standardId,
        standardAvg,
        strandName,
        standard,
        Enableloading,
      },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let PayloadData = response.data.value;

        dispatch({
          type: GET_SCHOOL_DETAILS_ON_STRAND_SELECTION_SUCCESS,
          payload: {
            PayloadData,
            strandId,
            standardId,
            standardAvg,
            strandName,
            selectedTaxonomy,
            Sel_Ass_Ques,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} standardAvg
 * @param {string} strandName
 * @param {string} standard
 */
export const GetLineChartDetailsofSelected_Standards_In_District_Report = (
  AccessToken,
  ReqPayload,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading
) => {
  let URL = Base_URL + Get_LineChart_of_District_strands;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: District_Action_Types.GET_LINECHART_DATA_OF_DISTRICT_STRANDS,
      payload: Enableloading,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        dispatch({
          type: District_Action_Types.GET_LINECHART_DATA_OF_DISTRICT_STRANDS_SUCCESS,
          payload: { PayloadData, strandName, persist_compare_checkboxes },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const AGPDistrictCSV = (AccessToken, ReqPayload) => {
  let URL = DistrictAGPCSV;
  //let URL = Base_URL + REPLACE_ORGINAL_URL_HERE;

  return (dispatch, getState) => {
    //ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(getState(), ReqPayload.studentIds);

    dispatch({
      type: District_Action_Types.AGP_DISTRICT_CSV,
      ReqPayload,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        dispatch({
          type: AGP_CSVPOPUPCONFIRMATION,
          payload: true,
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {string} token -- Jwt AccessToken.
 * @param {object} ReqPayload -- Api Req_Payload.
 * @param {Boolean} Enableload
 * Get School test score graph details
 */
export const Get_District_TestScores_Graph = (
  AccessToken,
  ReqPayload,
  Enableload
) => {
  let URL = Base_URL + Get_Dist_TS_Graph;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: GET_DISTRICT_TS_GRAPH_DETAILS,
      payload: Enableload,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let ResPayload = response.data.value;

        let TestToPersist = TestToPersistInTestScoreGraph(
          ResPayload,
          getState()
        );

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = { ResPayload, TestToPersist };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          district_TS_OR_SP_Success(
            action,
            Universal,
            LastActiveUniversalProps,
            "TestScore"
          );

        dispatch({
          type: GET_DISTRICT_TS_GRAPH_DETAILS_SUCCESS,
          payload: {
            ResPayload,
            TestToPersist,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {string} AccessToken --jwt token.
 * @param {object} reqObject --request payload.
 */
export const Get_Selected_TS_Details_IN_Dist_Report = (
  AccessToken,
  reqObject,
  test,
  enableLoading
) => {
  let URL = Base_URL + Get_Selected_Test_Details_In_Dist_TS_;

  return (dispatch, getState) => {
    reqObject.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      reqObject.studentIds
    );

    dispatch({
      type: GET_SELECTED_TS_DETAILS,
      payload: { test, enableLoading },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, reqObject, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData.ReqComponentCode = reqObject.componentCode;

        let { Universal, LastActiveUniversalProps } = getState();

        let action = {
          payload: PayloadData,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          district_TS_OR_SP_Success(
            action,
            Universal,
            LastActiveUniversalProps,
            "TestScore"
          );

        dispatch({
          type: GET_SELECTED_TS_DETAILS_SUCCESS_IN_DISTRICT,
          payload: {
            PayloadData,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {string} motion -- Bubble Motion Left/ Right :
 * @param {object} Nav -- Navigation details
 */

export const Move_ChartPaginationDisplayBubbles_SC_D = (motion, Nav) => {
  return (dispatch) => {
    if (Nav.school) {
      dispatch({
        type: School_Action_Types.MOVE_LINE_CHART_PAGINATIO_BUBBLE_IN_SCHOOL,
        payload: { motion, Nav },
      });
    } else {
      dispatch({
        type: District_Action_Types.MOVE_LINE_CHART_PAGINATIO_BUBBLE_IN_DIST,
        payload: { motion, Nav },
      });
    }
  };
};

/**
 *
 * @param {int} Chart_Bubble_Start  -- Chart_Bubble_Start
 * @param {int} positionfrom_BubbleStart -- ex : 1,2,
 * @param {object} Nav -- navigation details
 */

export const Change_LineChart_paginationBubble_SC_D = (
  Chart_Bubble_Start,
  positionfrom_BubbleStart,
  Nav
) => {
  return (dispatch) => {
    if (Nav.school) {
      dispatch({
        type: School_Action_Types.CHANGE_LINE_CHART_PAGINATION_BUBBLE_SCHOOL,
        payload: { Chart_Bubble_Start, positionfrom_BubbleStart, Nav },
      });
    } else {
      dispatch({
        type: District_Action_Types.CHANGE_LINE_CHART_PAGINATION_BUBBLE_DIST,
        payload: { Chart_Bubble_Start, positionfrom_BubbleStart, Nav },
      });
    }
  };
};

/**
 *
 * @param {Array} SortedArray  --oreted Array List
 * @param {Array} ArrayList  -- ArrayList
 * @param {int} minValue  -- Min Value of Sort.
 * @param {int} maxValue  --Max Value of Sort.
 * @param {int} ActiveColumn   --Sorting Column Value.
 * @param {object} Navigation --
 */
export const SaveSorted_OrderOverViewSchoolsList = (
  SortedArray,
  ArrayList,
  minValue,
  maxValue,
  ActiveColumn,
  Navigation
) => {
  return (dispatch) => {
    if (Navigation.school) {
    } else {
      dispatch({
        type: District_Action_Types.SAVE_SORTED_SCHOOL_DETAILS_LIST_,
        payload: {
          SortedArray,
          ArrayList,
          minValue,
          maxValue,
          ActiveColumn,
          Navigation,
        },
      });
    }
  };
};
