import { SchoolRLPTypes } from '../Reducer_Action_Types/School_RlpActionTypes.jsx';
import {
  School_Rlp_Grid_Api,
  School_Rlp_Class_level_Grid_Api,
  School_Rlp_MainChart_Api,
  School_Rlp_ClassLevel_Api,
  ORR_URL,
  CSV_DOWNLOAD_SCHOOL
} from '../Utils/globalVars';
import axios from 'axios';
import { RLP_CHART_API_SUCCESS } from '../Reducer_Action_Types/UniversalSelectorActionTypes.js';
import { CHANGE_TERM_ON_RLP_DATA_FAIL_METHOD } from './C_ReadingLevelAction.jsx';

export const School_RLP_Grid_Chart_Table_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + School_Rlp_Grid_Api;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        if (Response_Data.SUCCESSFULL) {
          dispatch({
            type: SchoolRLPTypes.SCHOOL_RLP_GRID_DATA,
            payload: Response_Data
          });
        }
      }).catch(() => {
        dispatch({
          type: SchoolRLPTypes.SCHOOL_RLP_GRID_API_CALL_FAIL
        });
      });
  };
};

export const School_Class_Grid_Chart_Table_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + School_Rlp_Class_level_Grid_Api;
  if (Payload.grade) {
    delete Payload['grade'];
  }
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        if (Response_Data.SUCCESSFULL) {
          dispatch({
            type: SchoolRLPTypes.SCHOOL_RLP_GRID_DATA,
            payload: Response_Data
          });
        }
      }).catch(() => {
        dispatch({
          type: SchoolRLPTypes.SCHOOL_RLP_GRID_API_CALL_FAIL
        });
      });
  };
};

// for setting loading icon chart for data request
export const School_Show_loading_Icon = data => {
  return dispatch => {
    dispatch({ type: SchoolRLPTypes.CHART_API_LOADER, payload: '' });
  };
};

// chart loading failed
export const Chart_loading_Failed = data => {
  data['noChartData'] = 'false';
  return dispatch => {
    dispatch({ type: SchoolRLPTypes.CHART_LOADING_FAILED, payload: data });
  };
};
// chart loading failed
export const Api_Timeout = data => {
  return dispatch => {
    dispatch({ type: SchoolRLPTypes.API_TIMEOUT });
  };
};

// Schooll level 1.1 chart API
export const School_Level_RLP_Chart_API = (AccessToken, data) => {
  let AuthURL = ORR_URL + School_Rlp_MainChart_Api;
  if (data['value']) {
    delete data['value'];
  }
  let dummyToken;
  let Payload = data;

  return (dispatch, getState) => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then((response) => {
        if (
          response.data.responseData.gradeWiseResultList &&
          response.data.responseData.gradeWiseResultList.length > 0
        ) {
          let selectedLevels = getFirstReadingLevels(
            response.data.responseData.gradeWiseResultList[0],
            'SLRLP'
          );

          Promise.resolve(
            dispatch({
              type: SchoolRLPTypes.SCHOOL_RLP_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseData,
                selectedLevels: selectedLevels
              }
            }),
            dispatch({
              type: RLP_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseData
              }
            }),
          );
        } else {
          let { loadedOrrReportsForTerm } = getState().Universal;
          let ModifiedDateTab = getState().DateTabReducer;
          let { SelectedDistrictTerm, TermsListWithOutUTCFormat } = ModifiedDateTab.DateTabComponents;
          TermsListWithOutUTCFormat = Array.isArray(TermsListWithOutUTCFormat) ? TermsListWithOutUTCFormat : [];
          let currentDistrictIndex = TermsListWithOutUTCFormat.findIndex(item => item.termId == SelectedDistrictTerm.termId)
          if (currentDistrictIndex > -1 && currentDistrictIndex + 1 < TermsListWithOutUTCFormat.length && !loadedOrrReportsForTerm) {
            dispatch(CHANGE_TERM_ON_RLP_DATA_FAIL_METHOD(currentDistrictIndex));
          } else {
            dispatch({
              type: SchoolRLPTypes.CHART_LOADING_FAILED,
              payload: {
                apiLoadFail: false,
                constructedData: null,
                timeout: false,
                noChartData: true
              }
            });
          }
        }
      })
      .catch(function (error) {
        dispatch({
          type: SchoolRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: false
          }
        });
      });
  };

  // update chart scroll update
};
// School level 1.2 chart API
export const School_Class_Level_RLP_Chart_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + School_Rlp_ClassLevel_Api;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        if (
          response.data.responseData.gradeWiseResultList &&
          response.data.responseData.gradeWiseResultList.length > 0
        ) {
          response.data.responseData.gradeWiseResultList = getClassName(response.data.responseData.gradeWiseResultList)
          let selectedLevels = getFirstReadingLevels(
            {
              ...response.data.responseData.gradeWiseResultList[0],
              grade: Payload.grade
            },
            'CLRLP'
          );
          Promise.resolve(
            dispatch({
              type: SchoolRLPTypes.SCHOOL_RLP_CLASS_LEVEL_CHART_API_SUCCESS,
              payload: {
                responseData: response.data.responseData,
                schoolLevelGrade: Payload.grade,
                selectedLevels: selectedLevels
              }
            })
          ).then(() =>
            dispatch(
              School_Class_Grid_Chart_Table_API(AccessToken, {
                ...Payload,
                ['selectedLevels']: setGradeToSelectedLevels(selectedLevels)
              })
            )
          );
        } else {
          dispatch({
            type: SchoolRLPTypes.CHART_LOADING_FAILED,
            payload: {
              apiLoadFail: true,
              constructedData: null,
              timeout: false,
              noChartData: true
            }
          });
        }
      })
      .catch(function (error) {
        dispatch({
          type: SchoolRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: false
          }
        });
      });
  };

  // update chart scroll update
};

export const Selected_Levels = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.UPDATE_SELECTED_LEVELS,
      payload: data
    });
  };
};
export const School_Level_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCHOOL_RLP_CHART_SCROLL_DATA,
      payload: data
    });
  };
};

export const Sum_ScRlp_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SUMMARY_SCRLP_CHART_SCROLL_DATA,
      payload: data
    });
  };
};

//function to show icons and sort columns
export const SORT_SCLRLP_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCHOOL_RLP_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SAVE_SORTED_SCLRLPDATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCHOOL_RLP_SAVE_SORT_ARRAY,
      payload: { SortedArray }
    });
  };
};

export const SCHOOL_CLASS_LEVEL_GRID_API = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + School_Rlp_Class_level_Grid_Api;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        if (Response_Data.SUCCESSFULL) {
          dispatch({
            type: SchoolRLPTypes.SCHOOL_RLP_CLASS_LEVEL_GRID_API_SUCCESS,
            payload: Response_Data
          });
        }
      });
  };
};
function getFirstReadingLevels(firstGradeData, from) {
  let levels = [];
  let recordType = '';
  let gradeType = '';
  if (from == 'SLRLP') {
    gradeType = 'grade';
  } else if (from == 'CLRLP') {
    gradeType = 'className';
  }
  if (
    firstGradeData.recordDataList.recentRecord &&
    firstGradeData.recordDataList.recentRecord.length > 0
  ) {
    recordType = 'recentRecord';
    firstGradeData.recordDataList.recentRecord.forEach(obj => {
      if (from == 'SLRLP') {
        levels.push({
          orrAssignmentId: obj.orrAssignmentId,
          [gradeType]: firstGradeData[gradeType]
        });
      } else if (from == 'CLRLP') {
        levels.push({
          orrAssignmentId: obj.orrAssignmentId,
          [gradeType]: firstGradeData[gradeType],
          classId: firstGradeData['classId'],
          grade: firstGradeData.grade
        });
      }
    });
  } else if (
    firstGradeData.recordDataList.firstRecord &&
    firstGradeData.recordDataList.firstRecord.length > 0
  ) {
    recordType = 'firstRecord';
    firstGradeData.recordDataList.firstRecord.forEach(obj => {
      if (from == 'SLRLP') {
        levels.push({
          orrAssignmentId: obj.orrAssignmentId,
          [gradeType]: firstGradeData[gradeType]
        });
      } else if (from == 'CLRLP') {
        levels.push({
          orrAssignmentId: obj.orrAssignmentId,
          [gradeType]: firstGradeData[gradeType],
          classId: firstGradeData['classId'],
          grade: firstGradeData.grade
        });
      }
    });
  }

  return { [recordType]: levels };
}

function setGradeToSelectedLevels(SL_Levels) {
  if (Object.keys(SL_Levels).length > 0) {
    return SL_Levels[Object.keys(SL_Levels)[0]];
  }
}

//show and collapse class bar
export const SHOW_HIDE_BAR = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCHOOL_CLASS_NAME,
      payload: data
    });
  };
};

//to get class name
function getClassName(className) {
  className.sort((a, b) => {
    if (a.className < b.className) { return -1; }
    if (a.className > b.className) { return 1; }
    return 0;
  })
  return className
}


export const Sum_Sc_RLP_Chart_API = (AccessToken, data) => {
  let AuthURL = ORR_URL + School_Rlp_MainChart_Api;
  if (data['value']) {
    delete data['value'];
  }

  let Payload = data;

  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(response => {
        if (
          response.data.responseData.gradeWiseResultList &&
          response.data.responseData.gradeWiseResultList.length > 0
        ) {
          let selectedLevels = getFirstReadingLevels(
            response.data.responseData.gradeWiseResultList[0],
            'SLRLP'
          );


          dispatch({
            type: SchoolRLPTypes.SUM_SC_RLP_CHART_API_SUCCESS,
            payload: {
              responseData: response.data.responseData,
              selectedLevels: selectedLevels
            }
          })

        } else {
          dispatch({
            type: SchoolRLPTypes.CHART_LOADING_FAILED,
            payload: {
              apiLoadFail: false,
              constructedData: null,
              timeout: false,
              noChartData: true
            }
          });
        }
      })
      .catch(function (error) {
        dispatch({
          type: SchoolRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: false
          }
        });
      });
  };

  // update chart scroll update
};

export const SCHRLP_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCHRLP_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SCHRLP_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_SCHOOL;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: SchoolRLPTypes.SCHRLP_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: false
          }
        });
      });
  };
};

export const SCHRLP2_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCHRLP2_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SCHRLP2_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_SCHOOL;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: SchoolRLPTypes.SCHRLP2_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolRLPTypes.CHART_LOADING_FAILED,
          payload: {
            apiLoadFail: true,
            constructedData: null,
            timeout: false,
            noChartData: true
          }
        });
      });
  };
};
export const updateDropDownData = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCRLP_UPDATE_DROP_DOWN_DATA,
      payLoad: data
    })
  }
}



export const updateChartDetails = data => {

  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCRLP_UPDATE_CHART_DATA,
      payLoad: data
    })
  }
}

export const updateAllMonth = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCRLP_UPDATE_ALL_DATA,
      payLoad: data
    })
  }
}

export const toggleDropDown = data => {
  return dispatch => {
    dispatch({
      type: SchoolRLPTypes.SCRLP_UPDATE_TOGGLE,
      payLoad: data
    })
  }
}
