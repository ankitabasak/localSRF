import {
  U_S_Action_Types,
  STUDENT_DATA_ACTION,
  STUDENT_DATA_ACTION_SUCCESS,
  STUDENT_DATA_ACTION_FAIL,
  SAVE_SELECTED_STUDENT_DATA,
  COMPARE_CONTEXT_SELECTION,
  STUDENTDATA_INFO_ICON,
  PD_TESTS_INFOICON,
  PD_DATES_INFOICON,
  GET_TEST_TAB_RESULTS,
  GET_TEST_TAB_RESULTS_SUCCESS,
  GET_USER_ACCESSABLE_REPORTS_FAIL,
  GET_USER_ACCESSABLE_REPORTS_SUCCESS,
  GET_USER_ACCESSABLE_REPORTS,
  SET_GET_INITIAL_APPLICATION_DATA,
  GET_INITIAL_APPLICATION_DATA,
  GET_INITIAL_APPLICATION_DATA_SUCCESS,
  GET_INITIAL_APPLICATION_DATA_FAIL,
  SAVE_CONTEXT_SELECTION,
  GET_DATE_TAB_RESULTS_SUCCESS,
  GET_DATE_TAB_RESULTS,
  APPLY_FILTER_IN_DATE_TAB,
  RETURN_TO_PREVIOUS_REPORT_UNIVERSAL,
  PD_CLASS_COMPARE_CHECKBOXES,
  BELL_NOTIFICATION_API_SUCCESS,
  STUDENT_GRADE_TESTCOUNTANDDATES,
  BELL_NOTIFICATION_API,
  BELL_NOTIFICATION,
  AGP_CSVPOPUP,
  AGP_CSVPOPUPCONFIRMATION,
  AGP_ALREADY_REQUESTED,
  AGP_CSV_CHECKBOXES,
  AGP_CSV_RADIOBOXES,
  SET_GET_TEST_TAB_RESULTS,
  GET_INITIAL_SCHOOL_OBJECT,
  GET_INITIAL_SCHOOL_OBJECT_SUCCESS,
  GET_INITIAL_SCHOOL_OBJECT_FAIL,
  STORE_DATA_FROM_ASSESSMENT,
  SWITCH_DOWNLOAD_SUCCESS,
  HIDE_DOWNLOAD_NOTIFICATION_DOT_ICON,
  GET_SUMMARYREPORTS_DEFAULT,
  GET_SUMMARYREPORTS_DEFAULT_SUCCESS,
  SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD,
  GET_ROSTERTAB_COMPLETE_DATA_SUCCESS,
  SEPARATE_ROSTER_TAB_DETAILS,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";

import axios from "axios";
import {
  Get_Tests,
  Base_URL,
  InitialLoad,
  ACCESSIBLE_REPORTS,
  DateTab_BeforeInitial,
  RosterTab_Post,
  DISTRICT_ADMIN_REPORTS,
  api_request_headers,
  CompleteAndFailedJobCount,
  ENABLE_USAGE_WIDGET,
} from "../Utils/globalVars";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { hasUsageReports } from "../Utils/UsageReporting/usageReports";
import { Save_contextSelection_service } from "../services/UniversalSelectorActions.service";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  getStdPersistChanged,
  setStudentIdsWhenMultiSelectionsInSADA,
  retriggerAPI,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog } from "./AuthenticationAction";
import { SeparateRoster_tab_details } from "../Redux_Reducers/U_reducer_functions_to_returnSate";
import { Strands_GradeDetails_Of_Taxonomy } from "./summaryReports_Actions";
import {
  assessmentDefaultApiSuccess,
  rosterDataFor_DA_AfterDefaultLoad,
  summaryDefaultSuccess,
} from "../services/universalSelector/universalSelector_1";
import {
  rosterTabCompleteDataSuccess,
  TestTabResultsSuccess_service,
} from "../services/universalSelector/universalSelector_2";
import {
  APPLY_FILTER_IN_DATE_TAB_US_Red_Func,
  DateTabResultsSuccess,
  ReturnBackReport_Button_In_Nodata,
} from "../services/universalSelector/universalSelector_3";

/**
 *
 * @param {Boolean} NavToStrands
 * @param {Boolean} SameReportData
 *
 * if only strands not available,then will use this SameReportData prop.
 *
 * When User Clicks On Back To Previous report then we will call this.
 */
export const Return_to_previous_report_Universal = (
  NavToStrands,
  SameReportData,
  Last_Active_Reports,
  Date_Last_Active_repo,
  Nav
) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState();

    let payload = {
      NavToStrands,
      SameReportData,
      Last_Active_Reports,
      Date_Last_Active_repo,
      Nav,
    };
    let action = {
      payload,
    };

    let { updatedLastActivePropsState, updatedUniversalState } =
      ReturnBackReport_Button_In_Nodata(
        action,
        Universal,
        LastActiveUniversalProps
      );

    dispatch({
      type: RETURN_TO_PREVIOUS_REPORT_UNIVERSAL,
      payload: {
        NavToStrands,
        SameReportData,
        Last_Active_Reports,
        Date_Last_Active_repo,
        Nav,
        updatedLastActivePropsState,
        updatedUniversalState,
      },
    });
  };
};

/**
 *
 * @param {User Monitor Screen Width} ScreenWidth
 */
export const SaveMonitorScreenWidth = (ScreenWidth) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_USER_MONITOR_SCREEN_WIDTH,
      payload: ScreenWidth,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const UsageSetUiNavigationLevel = (navigationLevel) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_SET_UI_NAVIGATION_LEVEL,
      navigationLevel,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const ResetUsageUiNavigationLevel = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_RESET_UI_NAVIGATION_LEVEL,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const SetUsageReportsGrade = (grades) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORT_SET_GRADE,
      grades,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const SetUsageReportsDistrictName = (name) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORT_SET_DISTRICT_NAME,
      name,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const SetUsageDates = (dates) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORTS_SET_DATES,
      dates,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const SetUsageRosterList = (dataType, ids) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORTS_SET_ROSTER_LIST,
      dataType,
      ids,
    });
  };
};

/**
 * action To change grade level for Usage Reports only
 */
export const SetUsageInitialData = (
  realmId,
  districtIds,
  schoolIds,
  grade,
  teacherIds,
  classIds
) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORTS_SET_INITIAL_IDS,
      realmId,
      districtIds,
      schoolIds,
      grade,
      teacherIds,
      classIds,
    });
  };
};

/**
 * action To set the disabled state of terms for Usage Reports only
 */
export const SetUsageReportTermDisabled = (disabled) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORT_SET_TERM_DISABLED,
      disabled,
    });
  };
};

/**
 * action To change collective noun ids for Usage Reports only
 */
export const SetUsageReportsCollectiveNounIds = (collectiveNounType, ids) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORT_SET_COLLECTIVE_NOUN_IDS,
      collectiveNounType,
      ids,
    });
  };
};

/**
 * action To change collective noun UI ids for Usage Reports only
 */
export const SetUsageReportsCollectiveNounUiIds = (collectiveNounType, ids) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORT_SET_COLLECTIVE_NOUN_UI_IDS,
      collectiveNounType,
      ids,
    });
  };
};

/**
 * action To change loading status for dropdown list for Usage Reports only
 */
export const SetUsageReportsLoadingStatus = (collectiveNounType, status) => {
  const validTypes = ["school", "grade", "teacher", "class", "student"];
  const loadType = collectiveNounType.split("Loading")[0].toLowerCase();
  if (validTypes.indexOf(loadType) === -1) {
    console.log("Invalid loading type provided by BUUR: ", collectiveNounType);
    return state;
  }
  if (typeof status !== "boolean") {
    console.log(
      "Invalid loading status type provided by BUUR: ",
      collectiveNounType
    );
    return state;
  }
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORTS_SET_LOADING_STATUS,
      loadType,
      status,
    });
  };
};

/**
 * action To change navigaton level for Usage Reports only
 */
export const SetUsageReportsBetweenTerms = (status) => {
  if (typeof status !== "boolean") {
    console.log("Invalid between terms status type provided by BUUR: ", status);
    return state;
  }
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORTS_SET_BETWEEN_TERMS,
      status,
    });
  };
};

/**
 * action To change navigaton level for Usage Reports only
 */
export const SetUsageReportsNavigationLevel = (level) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.USAGE_REPORT_SET_NAVIGATION_LEVEL,
      level,
    });
  };
};

export const SetUsageContextNames = (names) => {
    return dispatch => {
        dispatch({
            type: U_S_Action_Types.USAGE_REPORT_SET_CONTEXT_NAMES,
            names
        });
    };
};

// export const SetUsageContextNames = (names) => {
//     return dispatch => {
//         dispatch({
//             type: U_S_Action_Types.USAGE_REPORT_SET_CONTEXT_NAMES,
//             names
//         });
//     };
// };

/**
 * action To Open Or Close Main Menu in the header.
 */
export const MainMenuOpenOrClose = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.MAIN_MENU_OPEN_OR_CLOSE,
    });
  };
};

/**
 *
 * @param {Selected Tab.} selectionoption
 * action triggers on any tab selection in the dashboard.
 */

export const SaveContextSelection = (
  selectionoption,
  productListForGroupPopUp,
  Class_SP_Filter,
  Student,
  Class,
  SlectedStudent,
  SlectedClass,
  SelectedSchool,
  ActiveGrade
) => {
  return (dispatch, getState) => {
    let Un_State = getState().Universal;
    let { LastActiveUniversalProps } = getState();
    const { LoginDetails, Auth_Apis } = getState().Authentication;
    let CompareReducer_Main = getState().ComparisonReducer;
    const { SummaryReports } = getState();
    let Nav = { ...Un_State.NavigationByHeaderSelection };
    let CompareReducer = {};
    let CallTestStatus_Tests = false;
    let TestStatusRed = getState().TestStatusReducer;
    let LeftViewNotSelected;
    let summaryReports = getState().SummaryReports;
    let newGrade = ActiveGrade;
    let newClass = SlectedClass;
    if (selectionoption === "usageReports") {
      dispatch({
        type: U_S_Action_Types.SELECT_USAGE_REPORTS,
        payload: {},
      });
    } else {
      if (
        (Nav.S_performance || Nav.T_scores || Nav.test_status) &&
        Nav.Overview
      ) {
        switch (true) {
          case Nav.student:
            if (Nav.S_performance) {
              let StudentReports =
                getState().StudentReports.S_StandardPerformance_Overview;
              LeftViewNotSelected =
                StudentReports.StrandNameOfSelectedStandard == "" &&
                StudentReports.selectedStandardId == "";
            }
            break;
          case Nav.class:
            let ClassReports;
            if (Nav.S_performance) {
              ClassReports = getState().Reports.StandardPerformance_Overview;
              LeftViewNotSelected =
                ClassReports.StrandNameOfSelectedStandard == "" &&
                ClassReports.selectedStandardId == "";
            } else if (Nav.T_scores) {
              ClassReports = getState().Reports.Test_Scores_OverTime;
              LeftViewNotSelected =
                ClassReports.SelectedTestData.componentCode == "" ||
                ClassReports.SelectedTestData.componentCode == undefined;
            } else if (Nav.test_status) {
              ClassReports = getState().TestStatusReducer.Class.StatusDetail;
              LeftViewNotSelected =
                ClassReports.selectedTest.componentCode == "" ||
                ClassReports.selectedTest.componentCode == undefined;
            }
            break;
          case Nav.school:
            let SchoolReports;
            if (Nav.S_performance) {
              SchoolReports =
                getState().schoolReducer.Sc_StandardPerformance_Overview;
              LeftViewNotSelected =
                SchoolReports.StrandNameOfSelectedStandard == "" &&
                SchoolReports.selectedStandardId == "";
            } else if (Nav.T_scores) {
              SchoolReports = getState().schoolReducer.Sc_Test_Scores_OverTime;
              LeftViewNotSelected =
                SchoolReports.SelectedTestData.componentCode == "" ||
                SchoolReports.SelectedTestData.componentCode == undefined;
            } else if (Nav.test_status) {
              SchoolReports = getState().TestStatusReducer.School.StatusDetail;
              LeftViewNotSelected =
                SchoolReports.selectedTest.componentCode == "" ||
                SchoolReports.selectedTest.componentCode == undefined;
            }
            break;
          case Nav.district:
            let DistrictReports;
            if (Nav.S_performance) {
              DistrictReports =
                getState().DistrictReducer.D_StandardPerformance_Overview;
              LeftViewNotSelected =
                DistrictReports.StrandNameOfSelectedStandard == "" &&
                DistrictReports.selectedStandardId == "";
            } else if (Nav.T_scores) {
              DistrictReports =
                getState().DistrictReducer.D_Test_Scores_OverTime;
              LeftViewNotSelected =
                DistrictReports.SelectedTestData.componentCode == "" ||
                DistrictReports.SelectedTestData.componentCode == undefined;
            } else if (Nav.test_status) {
              DistrictReports =
                getState().TestStatusReducer.District.StatusDetail;
              LeftViewNotSelected =
                DistrictReports.selectedTest.componentCode == "" ||
                DistrictReports.selectedTest.componentCode == undefined;
            }
            break;
          default:
            break;
        }
      }
      switch (selectionoption) {
        case "student":
          CompareReducer = CompareReducer_Main.studentComparison;
          break;
        case "class":
          CompareReducer = CompareReducer_Main.classComparison;
          break;
        case "school":
          CompareReducer = CompareReducer_Main.schoolComparison;
          break;
        case "district":
          CompareReducer = CompareReducer_Main.districtComparison;
          break;
        default:
          break;
      }
      let TeststatusDataisThere;
      if (selectionoption == "test_status") {
        TeststatusDataisThere = Nav.student
          ? TestStatusRed.Student.ActualList.length > 0 &&
            TestStatusRed.Student.filteredData.length > 0
          : Nav.class
          ? TestStatusRed.Class.ActualList.length > 0 ||
            TestStatusRed.Class.ActualList.length == undefined
          : Nav.school
          ? TestStatusRed.School.ActualList.length > 0 ||
            TestStatusRed.School.ActualList.length == undefined
          : Nav.district
          ? TestStatusRed.District.ActualList.length > 0 ||
            TestStatusRed.District.ActualList.length == undefined
          : false;
      }
      let ts_overview_compare = getRequiredDataFromPersist(
        "persist_compare_checkboxes",
        getState()
      );
      let Sta_Persist_Object = getRequiredDataFromPersist("sta", getState());
      let ts_compare_checkboxes = getRequiredDataFromPersist(
        "persist_compare_checkboxes",
        getState()
      );
      let persist_compare_checkboxes = getRequiredDataFromPersist(
        "persist_compare_checkboxes",
        getState()
      );
      let sp_persistance = getRequiredDataFromPersist(
        "sp_persistance",
        getState()
      );
      let TsStudent_Apis = TestStatusRed.Student.Apicalls;
      let stdModified = getStdPersistChanged(getState());
      let Actions = {
        payload: {
          selectionoption,
          productListForGroupPopUp,
          Class_SP_Filter,
          Student,
          Class,
          SlectedStudent,
          SlectedClass: newClass,
          SelectedSchool,
          ActiveGrade: newGrade,
          Nav,
          Modified_State,
          CompareReducer,
          TeststatusDataisThere,
          CallTestStatus_Tests,
          ts_overview_compare,
          ts_compare_checkboxes,
          Sta_Persist_Object,
          persist_compare_checkboxes,
          sp_persistance,
          TsStudent_Apis,
          stdModified,
          LeftViewNotSelected,
          SummaryReports,
          Auth_Apis,
        },
      };
      let StateResponse = Save_contextSelection_service(
        JSON.parse(JSON.stringify(Un_State)),
        Actions,
        Un_State.assessmentLinkData,
        summaryReports,
        LastActiveUniversalProps
      );
      let Modified_State = StateResponse.StateToSet;
      let TestsModified = StateResponse.TestModified;
      let { updatedLastActivePropsState } = StateResponse;
      switch (selectionoption) {
        case "student":
          if (Nav.test_status) {
            CallTestStatus_Tests = CHeckTest_StatusAPI_For_Student();
          }
          break;
        case "class":
          if (Nav.test_status) {
            CallTestStatus_Tests = CHeckTest_StatusAPI_For_CLass();
          }
          break;
        case "school":
          if (Nav.test_status) {
            CallTestStatus_Tests = CHeckTest_StatusAPI_For_School();
          }
          break;
        case "district":
          if (Nav.test_status) {
            CallTestStatus_Tests = Modified_State.ApiCalls.getTests
          }
          break;
        default:
          break;
      }

      function CHeckTest_StatusAPI_For_School() {
        return (
          Modified_State.ApiCalls.Get_Selected_School_Info ||
          Modified_State.ApiCalls.getTests
        );
      }

      function CHeckTest_StatusAPI_For_CLass() {
        let clsis = Modified_State.ContextHeader.Roster_Tab.SelectedClass;
        return (
          TestStatusRed.Class.ActualList.length == 0 ||
          LastActiveUniversalProps.Class_TestStaus.selectedClass.id !== clsis.id
        );
      }

      function CHeckTest_StatusAPI_For_Student() {
        Student = Student == undefined || Student == null ? {} : Student;
        SlectedStudent =
          SlectedStudent == undefined || SlectedStudent == null
            ? {}
            : SlectedStudent;
        let stdid =
          Student.id == undefined
            ? SlectedStudent.id == undefined
              ? Un_State.ContextHeader.Roster_Tab.SelectedStudent.id
              : SlectedStudent.id
            : Student.id;
        return (
          TestStatusRed.Student.ActualList.length == 0 ||
          LastActiveUniversalProps.Student_TestStaus.selectedStudent.id !==
            stdid
        );
      }

      if (selectionoption == "test_status") {
        let highestTerm = LastActiveUniversalProps.Date_TabFullDetails[0];
        highestTerm = highestTerm == undefined ? {} : highestTerm;
        if (
          Un_State.ContextHeader.Date_Tab.selectedterm_Obj.termId ==
          highestTerm.termId
        ) {
        } else {
          if (CHeckTest_StatusAPI_For_CLass()) {
            TeststatusDataisThere ||
            Modified_State.NavigationByHeaderSelection.district
              ? false
              : (Modified_State.ApiCalls.Get_Selected_School_Info = true);
          }
        }
      }
      let Modif_Apis = Modified_State.ApiCalls;
      let Modif_Nav = Modified_State.NavigationByHeaderSelection;
      let Std_Report = getState().StudentReports;
      let cls_Report = getState().Reports;
      let sc_Report = getState().schoolReducer;
      let dis_Report = getState().DistrictReducer;
      let SummaryRedu = getState().Summary;
      let ComparisonReducer = getState().ComparisonReducer;
      let ApisActive;
      switch (true) {
        case Modif_Nav.S_performance:
          ApisActive = Modif_Nav.student
            ? Modif_Apis.Get_Student_SP_Grade
            : Modif_Nav.class
            ? Modif_Apis.Get_Class_SP_Grade
            : Modif_Nav.school
            ? Modif_Apis.Get_school_sp_grades
            : Modif_Nav.district
            ? Modif_Apis.Get_District_sp_grades
            : true;
          let SP_Datais_NotThere;
          if (Modif_Nav.class && Modif_Nav.grouping) {
            let groupingred = getState().ClassGroupingReducer;
            SP_Datais_NotThere =
              groupingred.GroupPage.GroupingList.length == 0 ||
              groupingred.G_ApiCalls.getGrades;
          } else {
            SP_Datais_NotThere = Modif_Nav.student
              ? Modif_Nav.summary
                ? SummaryRedu.Student.ActualList.length == 0 ||
                  SummaryRedu.Student.NodataAvailable
                : Std_Report.S_StandardPerformance_Overview
                    .StandardPerformanceFilter.NodataInStrands ||
                  Std_Report.S_StandardPerformance_Overview.ActualList.length ==
                    0
              : Modif_Nav.class
              ? Modif_Nav.summary
                ? SummaryRedu.Class.ActualList.length == 0 ||
                  SummaryRedu.Class.NodataAvailable
                : cls_Report.StandardPerformance_Overview
                    .StandardPerformanceFilter.NodataInStrands ||
                  cls_Report.StandardPerformance_Overview.ActualList.length == 0
              : Modif_Nav.school
              ? Modif_Nav.summary
                ? SummaryRedu.School.ActualList.length == 0 ||
                  SummaryRedu.School.NodataAvailable
                : sc_Report.Sc_StandardPerformance_Overview
                    .StandardPerformanceFilter.NodataInStrands ||
                  sc_Report.Sc_StandardPerformance_Overview.ActualList.length ==
                    0
              : Modif_Nav.district
              ? Modif_Nav.summary
                ? SummaryRedu.District.ActualList.length == 0 ||
                  SummaryRedu.District.NodataAvailable
                : dis_Report.D_StandardPerformance_Overview
                    .StandardPerformanceFilter.NodataInStrands
              : true;
            if (Modif_Nav.comparison) {
              let Std_Comparison = Modif_Nav.class
                ? ComparisonReducer.classComparison.Std_Comparison
                : Modif_Nav.school
                ? ComparisonReducer.schoolComparison.Std_Comparison
                : Modif_Nav.district
                ? ComparisonReducer.districtComparison.Std_Comparison
                : ComparisonReducer.studentComparison.Std_Comparison;
              ApisActive =
                ApisActive ||
                Std_Comparison.PopupFilter.C_SP_ApiCalls.getGrades ||
                Std_Comparison.PopupFilter.C_SP_ApiCalls.getassessed_Ques ||
                Std_Comparison.PopupFilter.C_SP_ApiCalls.getStrands;
            }
          }
          if (!ApisActive && !SP_Datais_NotThere && !Nav.Summary_Reports) {
            updatedLastActivePropsState.NaviGation = {
              ...Modif_Nav,
            };
          }
          break;
        case Modif_Nav.T_scores:
          ApisActive = Modif_Nav.student
            ? Modif_Apis.Get_Student_TestScores
            : Modif_Nav.class
            ? Modif_Apis.Get_Class_TestScores
            : Modif_Nav.school
            ? Modif_Apis.get_school_TS_Graph
            : Modif_Nav.district
            ? Modif_Apis.get_District_TS_graph
            : true;
          let T_DetailsNotThere = Modif_Nav.student
            ? Std_Report.S_Test_Scores_OverView.ActualLineChartList.length == 0
            : Modif_Nav.class
            ? cls_Report.Test_Scores_OverTime.ActualLineChartList.length == 0
            : Modif_Nav.school
            ? sc_Report.Sc_Test_Scores_OverTime.ActualLineChartList.length == 0
            : Modif_Nav.district
            ? dis_Report.D_Test_Scores_OverTime.ActualLineChartList.length == 0
            : true;
          if (!ApisActive && !T_DetailsNotThere) {
            updatedLastActivePropsState.NaviGation = {
              ...Modif_Nav,
            };
          }
          break;
        case Modif_Nav.test_status:
          let TS_Redu = getState().TestStatusReducer;
          ApisActive = Modif_Nav.student
            ? TS_Redu.Student.Apicalls.GetTestTab_TestStatus ||
              TS_Redu.Student.Apicalls.GetDetailsData ||
              TS_Redu.Student.Apicalls.No_Tests_In_TestStatus ||
              CallTestStatus_Tests
            : Modif_Nav.class
            ? TS_Redu.Class.Apicalls.GetTestTab_TestStatus ||
              TS_Redu.Class.Apicalls.GetSummaryData ||
              TS_Redu.Class.Apicalls.No_Tests_In_TestStatus ||
              CallTestStatus_Tests
            : Modif_Nav.school
            ? TS_Redu.School.Apicalls.GetTestTab_TestStatus ||
              TS_Redu.School.Apicalls.GetSummaryData ||
              TS_Redu.School.Apicalls.No_Tests_In_TestStatus ||
              CallTestStatus_Tests
            : Modif_Nav.district
            ? TS_Redu.District.Apicalls.GetTestTab_TestStatus ||
              TS_Redu.District.Apicalls.GetSummaryData ||
              TS_Redu.District.Apicalls.No_Tests_In_TestStatus ||
              CallTestStatus_Tests
            : true;
          if (!ApisActive) {
            updatedLastActivePropsState.NaviGation = {
              ...Modif_Nav,
            };
          }
          break;
        case Modif_Nav.S_performance:
          let St_Redu = getState().SingleTestAnalysis;
          if (Modif_Nav.grouping) {
            let GroupingRed = getState().ClassGroupingReducer;
            ApisActive = Modif_Nav.class
              ? GroupingRed.GroupPage.GroupingList.length == 0 ||
                GroupingRed.openEditedGroupPopUp
              : true;
          } else {
            ApisActive = Modif_Nav.student
              ? St_Redu.student_TestAnalysis.ApiCalls.getData
              : Modif_Nav.class
              ? St_Redu.class_TestAnalysis.ApiCalls.getData
              : Modif_Nav.school
              ? St_Redu.school_TestAnalysis.ApiCalls.getData
              : Modif_Nav.district
              ? St_Redu.district_TestAnalysis.ApiCalls.getData
              : true;
          }
          if (!ApisActive) {
            updatedLastActivePropsState.NaviGation = {
              ...Modif_Nav,
            };
          }
        default:
          break;
      }
      /**
       * setting state for DateTabReducer :
       *
       */
      let modified_DateTabReducer = getState().DateTabReducer;
      if (selectionoption == "ORR" || selectionoption == "Assessement") {
        if (selectionoption == "test_status") {
          let CurrentTermis =
            updatedLastActivePropsState.Date_TabFullDetails[0];
          modified_DateTabReducer.Context_DateTab_TestStatus.DefaultTerm =
            CurrentTermis;
          modified_DateTabReducer.Context_DateTab_TestStatus.SelectedDistrictTerm =
            CurrentTermis;
          modified_DateTabReducer = {
            ...modified_DateTabReducer,
            DateTabComponents: JSON.parse(
              JSON.stringify(modified_DateTabReducer.Context_DateTab_TestStatus)
            ),
          };
        } else if (
          Nav.test_status &&
          (selectionoption == "S_performance" || selectionoption == "T_scores")
        ) {
          modified_DateTabReducer = {
            ...modified_DateTabReducer,
            DateTabComponents: JSON.parse(
              JSON.stringify(modified_DateTabReducer.Context_DateTab)
            ),
          };
        } else if (selectionoption == "ORR") {
          if (Un_State.loadedOrrReportsForTerm) {
            modified_DateTabReducer = {
              ...modified_DateTabReducer,
              DateTabComponents: JSON.parse(
                JSON.stringify(modified_DateTabReducer.ORR_Context_DateTab)
              ),
            };
          } else {
            let selectedTermIs =
              modified_DateTabReducer.DateTabComponents
                .TermsListWithOutUTCFormat[0];
            if (selectedTermIs) {
              let ORRContext = {
                ...modified_DateTabReducer.ORR_Context_DateTab,
                TermsListWithOutUTCFormat:
                  modified_DateTabReducer.DateTabComponents
                    .TermsListWithOutUTCFormat,
                SelectedDistrictTerm: selectedTermIs,
                EndDateInDateTab: selectedTermIs.termEndDate,
                StartDateInDateTab: selectedTermIs.termStartDate,
              };
              modified_DateTabReducer = {
                ...modified_DateTabReducer,
                DateTabComponents: JSON.parse(JSON.stringify(ORRContext)),
                ORR_Context_DateTab: ORRContext,
              };
            }
          }
        } else if (selectionoption == "Assessement" && Nav.ORR) {
          modified_DateTabReducer = {
            ...modified_DateTabReducer,
            DateTabComponents: JSON.parse(
              JSON.stringify(modified_DateTabReducer.Context_DateTab)
            ),
          };
        }
        let { SelectedDistrictTerm } =
          modified_DateTabReducer.DateTabComponents;
        Modified_State = {
          ...Modified_State,
          ContextHeader: {
            ...Modified_State.ContextHeader,
            Date_Tab: {
              ...Modified_State.ContextHeader.Date_Tab,
              selected_District_term: SelectedDistrictTerm.termRange,
              Report_termStartDate: SelectedDistrictTerm.termStartDate,
              Report_termEndDate: SelectedDistrictTerm.termEndDate,
              selectedTermId: SelectedDistrictTerm.termId,
              dateRange: SelectedDistrictTerm.termRange,
            },
          },
        };
      }

      dispatch({
        type: SAVE_CONTEXT_SELECTION,
        payload: {
          selectionoption,
          productListForGroupPopUp,
          Class_SP_Filter,
          Student,
          Class,
          SlectedStudent,
          SlectedClass: newClass,
          SelectedSchool,
          ActiveGrade: newGrade,
          Nav,
          Modified_State,
          CompareReducer,
          CallTestStatus_Tests,
          ts_overview_compare,
          Sta_Persist_Object,
          ts_compare_checkboxes,
          TestsModified,
          persist_compare_checkboxes,
          sp_persistance,
          modified_DateTabReducer,
          updatedLastActivePropsState,
        },
      });
    }
  };
};

/**Comparison Context */

export const compareContextSelection = (
  contextSelected,
  contextTabSelected,
  StandardPeformanceData,
  TestScoreData,
  From_DeepLinking
) => {
  return (dispatch, getState) => {
    let PreviousNav = getState().LastActiveUniversalProps.NaviGation;
    let CurrentNav = getState().Universal.NavigationByHeaderSelection;
    dispatch({
      type: COMPARE_CONTEXT_SELECTION,
      payload: {
        contextSelected,
        contextTabSelected,
        StandardPeformanceData,
        TestScoreData,
        From_DeepLinking,
        PreviousNav,
        CurrentNav,
      },
    });
  };
};

/**
 * Action to Open Or Close Footer.
 */

export const FooterAction = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.FOOTER_ACTION,
    });
  };
};

/**
 * action to make context header sticky and vicevesa
 */
export const ChangeStickyContextHeader = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.CHANGE_STICKY_CONTEXT_HEADER,
    });
  };
};

/**
 * using this action to change the sticky universal selector class.
 */
export const ChangeStickyUniversalSelector = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.CHANGE_STICKY_UNIVERSAL_SELECTOR,
    });
  };
};

/**
 *
 * @param {TabName (roaster/test/date)} tab
 * @param {from where we are opening the tab} fromHeaderKy
 * action to open Universal selector from Context header
 */
export const Open_U_Selector_From_ContextHeader = (tab, fromHeaderKy) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.OPEN_U_SELECTOR_FROM_CONTEXTHEADER,
      payload: { tab, fromHeaderKy },
    });
  };
};

// #region Univeral Selecter Tab

/**
 *
 * @param {String} AccessToken
 * get User Accessable Report List.
 */
export const GetUserAccessableReports = (AccessToken, selectedSchoolId) => {
  let URL = Base_URL + ACCESSIBLE_REPORTS;
  return (dispatch) => {
    dispatch({
      type: AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS,
      payload: "on_user_skus",
    });
    dispatch({
      type: GET_USER_ACCESSABLE_REPORTS,
      payload: AccessToken,
      selectedSchoolId: selectedSchoolId,
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .get(URL, {
        headers: api_request_headers,
        // timeout:8500
      })
      .then(function (response) {
        let Response = response.data.value;
        let ReportingAccessParam = [];
        if (Response != undefined && Response !== "") {
          if (Response.length > 0) {
            if (Response.includes("X58691")) {
              ReportingAccessParam.push("eAR");
            }
            if (Response.includes("X69071")) {
              ReportingAccessParam.push("ORR");
            }
            if (Response.includes("X70225")) {
              ReportingAccessParam.push("IR");
            }
            const usageReportShown = hasUsageReports();
            if (usageReportShown) {
              ReportingAccessParam.push("usageReports");
            }
          }
        }

        let UserRole =
          response.data.role == "DISTRICT_ADMIN" &&
          DISTRICT_ADMIN_REPORTS === "false"
            ? "SCHOOL_ADMIN"
            : response.data.role;
        dispatch({
          type: GET_USER_ACCESSABLE_REPORTS_SUCCESS,
          payload: { ReportingAccessParam, UserRole },
        });
      })
      .catch(function (error) {
        console.log(" error : ",error);
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        dispatch({
          type: GET_USER_ACCESSABLE_REPORTS_FAIL,
          payload: error.response,
        });

        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *  Action to get Students and classes On initial load of the application.
 */
export const GetInitialApplicationData = (
  AccessToken,
  ReqPaylod,
  DateTabChanged,
  isTermIdsEqualAndNull,
  lazyLoad_eAR_Default_Api
) => {
  let URL = Base_URL + InitialLoad;
  let IS_ORR_ACCESSIBLE = ReqPaylod.IS_ORR_ACCESSIBLE
    ? ReqPaylod.IS_ORR_ACCESSIBLE
    : false;
  ReqPaylod.isDistrictEnabled = DISTRICT_ADMIN_REPORTS === "true";
  delete ReqPaylod.districtEnabled;
  return (dispatch, getState) => {
    dispatch({
      type: GET_INITIAL_APPLICATION_DATA,
      payload: { AccessToken, lazyLoad_eAR_Default_Api },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPaylod, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let Data = JSON.parse(JSON.stringify(response.data.value));
        let Role =
          response.data.role == "DISTRICT_ADMIN" &&
          DISTRICT_ADMIN_REPORTS === "false"
            ? "SCHOOL_ADMIN"
            : response.data.role;
        let UserId = response.data.userId;
        let userName = response.data.userName;
        let CurrentDateTime = new Date();
        let { Universal, LastActiveUniversalProps } = getState();

        let action = {
          payload: {
            Data,
            Role,
            AccessToken,
            UserId,
            DateTabChanged,
            CurrentDateTime,
            IS_ORR_ACCESSIBLE,
            Universal,
            isTermIdsEqualAndNull,
            lazyLoad_eAR_Default_Api,
            userName,
            ReqPaylod,
          },
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          assessmentDefaultApiSuccess(
            action,
            Universal,
            LastActiveUniversalProps
          );
        dispatch({
          type: GET_INITIAL_APPLICATION_DATA_SUCCESS,
          payload: {
            Data,
            Role,
            AccessToken,
            UserId,
            DateTabChanged,
            CurrentDateTime,
            IS_ORR_ACCESSIBLE,
            Universal,
            isTermIdsEqualAndNull,
            lazyLoad_eAR_Default_Api,
            userName,
            ReqPaylod,
            updatedUniversalState,
            updatedLastActivePropsState,
          },
        });
      })
      .catch(function (error) {
        console.log("error :  ", error);
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: GET_INITIAL_APPLICATION_DATA_FAIL,
          payload: { statusCode },
        });

        if (error.message == "Network Error") {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        }
      });
  };
};

/**
 * post method of roster details.
 */
export const Get_Roster_Tab_Data = (
  AccessToken,
  ReqPayload,
  IsDistrictAdmin,
  NostrandsONInitialLoad,
  DefaultTermObj,
  Dist_StrandsGrades_Obj
) => {
  let URL = Base_URL + RosterTab_Post;
  return (dispatch, getState) => {
    if (IsDistrictAdmin) {
      let { Universal, LastActiveUniversalProps } = getState();
      let action = {
        payload: {
          NostrandsONInitialLoad,
          IsDistrictAdmin,
          DefaultTermObj,
          Dist_StrandsGrades_Obj,
        },
      };
      let { updatedLastActivePropsState, updatedUniversalState } =
        rosterDataFor_DA_AfterDefaultLoad(
          action,
          Universal,
          LastActiveUniversalProps
        );

      dispatch({
        type: SAVE_ROSTER_DATA_FOR_DISTRICT_ADMIN_AFTER_DEFAULT_LOAD,
        payload: {
          NostrandsONInitialLoad,
          IsDistrictAdmin,
          DefaultTermObj,
          Dist_StrandsGrades_Obj,
          updatedLastActivePropsState,
          updatedUniversalState,
        },
      });
    } else {
      let { Universal, LastActiveUniversalProps } = getState();
      dispatch({
        type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA,
        payload: AccessToken,
      });
      let seconds_Start = new Date().getTime() / 1000;
      api_request_headers.Authorization = "Bearer ".concat(AccessToken);
      axios
        .post(URL, ReqPayload, {
          headers: api_request_headers,
        })
        .then(function (response) {
          let PayloadData = response.data.value;
          let UserId = response.data.userId;
          let UserROle = response.data.role;

          let action = {
            payload: {
              PayloadData,
              UserId,
              UserROle,
            },
          };
          let { updatedLastActivePropsState, updatedUniversalState } =
            rosterTabCompleteDataSuccess(
              action,
              Universal,
              LastActiveUniversalProps
            );
          dispatch({
            type: GET_ROSTERTAB_COMPLETE_DATA_SUCCESS,
            payload: {
              PayloadData,
              UserId,
              UserROle,
              updatedLastActivePropsState,
              updatedUniversalState,
            },
          });
        })
        .catch(function (error) {
          dispatch(postErrorLog(AccessToken, error, seconds_Start));
          let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

          if (statusCode == 502) {
            dispatch({
              type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
              payload: { statusCode },
            });
          }
          dispatch({
            type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
            payload: { statusCode },
          });
        });
    }
  };
};

/**
 * Devide and store roster Tab Details
 */
export const Separate_Roster_Tab_Details = (
  NostrandsONInitialLoad,
  DefaultTermObj,
  UserReportsAccess
) => {
  return (dispatch, getState) => {
    let DateTabState = getState().DateTabReducer;
    let UniversalState = getState().Universal;
    let { LastActiveUniversalProps } = getState();
    let { lazyLoad_eAR_Default_Api } = getState().Authentication.Auth_Apis;
    let SelectedTerm = DateTabState.DateTabComponents.SelectedDistrictTerm;
    DefaultTermObj =
      SelectedTerm &&
      UniversalState.ContextHeader.Date_Tab.selectedTermId ===
        SelectedTerm.termId
        ? SelectedTerm
        : DefaultTermObj;
    let Action = {
      payload: {
        NostrandsONInitialLoad,
        DefaultTermObj,
        UserReportsAccess,
        lazyLoad_eAR_Default_Api,
      },
    };
    let serviceresponse = SeparateRoster_tab_details(
      UniversalState,
      Action,
      LastActiveUniversalProps
    );
    let { updatedUniversalState, updatedLastActivePropsState } =
      serviceresponse;
    dispatch({
      type: SEPARATE_ROSTER_TAB_DETAILS,
      payload: {
        updatedUniversalState,
        NostrandsONInitialLoad,
        DefaultTermObj,
        UserReportsAccess,
        updatedLastActivePropsState,
      },
    });
  };
};

/**
 *
 * @param { string} AccessToken  -- jwt token Of User
 * @param { String } DistrictId --Selected school details.
 * @param { Object } SchoolObj --Selected school details.
 * action to get Class list of selected school.
 */
export const GetGradesListOn_School = (AccessToken, DistrictId, SchoolObj) => {
  let URL =
    Base_URL +
    "roster/grades?districtId=" +
    DistrictId +
    "&schoolId=" +
    SchoolObj.id;
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.GET_GRADES_LIST_,
      payload: SchoolObj,
    });
    let seconds_Start = new Date().getTime() / 1000;
    axios({
      method: "get",
      url: URL,
      headers: {
        Authorization: "Bearer ".concat(AccessToken),
      },
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        dispatch({
          type: U_S_Action_Types.GET_GRADES_LIST_SUCCESS,
          payload: { PayloadData, isDefault: false },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: U_S_Action_Types.GET_GRADES_LIST_FAIL,
          payload: error.response,
        });
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const GetClassesBasedOnTeacher = (item) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_TEACHER,
      payload: {
        item,
      },
    });
  };
};

/**
 *  Action triggers to apply Date tab filter
 */
export const ApplyFilterInDate_Tab = (value) => {
  return (dispatch, getState) => {
    let Nav = getState().Universal.NavigationByHeaderSelection;

    let { Universal, LastActiveUniversalProps } = getState();

    let payload = { value, Nav };
    let action = {
      payload,
    };

    let { updatedLastActivePropsState, updatedUniversalState } =
      APPLY_FILTER_IN_DATE_TAB_US_Red_Func(
        action,
        Universal,
        LastActiveUniversalProps
      );
    dispatch({
      type: APPLY_FILTER_IN_DATE_TAB,
      payload: {
        value,
        Nav,
        updatedLastActivePropsState,
        updatedUniversalState,
      },
    });
  };
};
/**
 *
 * @param {String} value
 * @param {String} field
 * will use this to set changed props in date tab.
 */
export const StoreSelectedValuesInDateTab = (value, field) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.STORE_SELECTED_VALUES_IN_DATE_TAB,
      payload: { value, field },
    });
  };
};

/**
 *
 * @param {Boolean} to_open
 */
export const OpenOrCLoseMonthsListInDateTabCalendar = (to_open) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.OPEN_OR_CLOSE_MONTHS_IN_DATE_TAB_CALENDAR,
      payload: to_open,
    });
  };
};
/**
 *
 * @param {String} SelectedMonth
 * @param {String} fullDatetoSave
 */
export const ChangeMonthINDateTab_Calendar = (
  SelectedMonth,
  fullDatetoSave,
  selectedMonthNameByArrows
) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.CHANGE_MONTHS_IN_DATETAB_IN_CALENDAR,
      payload: { SelectedMonth, fullDatetoSave, selectedMonthNameByArrows },
    });
  };
};

export const SetOptionContextHeader = (enableordisableoption) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SET_ENABLE_OPTIONS,
      payload: { enableordisableoption },
    });
  };
};

//#region Test Tab
/**
 *
 * @param { Object } ReqPayload
 * @param { String } AccessToken
 * @param { String } GetS_Strads_LineChart
 * Action to Get Test List After Applyfilter in Roaster Tab
 */
export const Get_TestTabResults = (
  AccessToken,
  ReqPayload,
  Get_S_Strads_LineChart,
  SelectedMultipleStudents
) => {
  let URL = Base_URL + Get_Tests;
  return (dispatch, getState) => {
    const state = getState();
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );
    let UniversalSelector = state.Universal;
    UniversalSelector.ContextHeader.from_rostertab = true;
    let Nav = state.Universal.NavigationByHeaderSelection;
    dispatch({
      type: GET_TEST_TAB_RESULTS,
      payload: { ReqPayload, Nav },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    fetch(URL, {
      method: "post",
      headers: api_request_headers,
      body: JSON.stringify(ReqPayload),
    })
      .then((res) => res.json())
      .then((res) => {
        let Response = res.value;
        // let TestTab = state.PersistanceReducer.SingleTest_Persistance
        let persistedTest = getRequiredDataFromPersist("sta_test", state);

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
          Response,
          Get_S_Strads_LineChart,
          SelectedMultipleStudents,
          Nav,
          UniversalSelector,
          ReqPayload,
          persistedTest,
        };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          TestTabResultsSuccess_service(
            action,
            Universal,
            JSON.parse(JSON.stringify( LastActiveUniversalProps))
          );

        dispatch({
          type: GET_TEST_TAB_RESULTS_SUCCESS,
          payload: {
            Response,
            Get_S_Strads_LineChart,
            SelectedMultipleStudents,
            Nav,
            UniversalSelector,
            ReqPayload,
            persistedTest,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let retries = getState().Authentication.retryApis;
        let seconds_End = new Date().getTime() / 1000;
        let diffTime = seconds_End - seconds_Start;
        let statusCode =
          error.message == "Failed to fetch" && diffTime < 90
            ? 502
            : error.response == undefined
            ? 504
            : error.response.status;
        let isAPIRetry = retriggerAPI(diffTime, retries, statusCode);
        if (isAPIRetry) {
          dispatch({
            type: SET_GET_TEST_TAB_RESULTS,
            payload: { ReqPayload, Nav },
          });
        } else {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        }
      });
  };
};

export const Get_DateTabResults = (AccessToken, ReqPayload) => {
  let URL = Base_URL + DateTab_BeforeInitial;
  return (dispatch, getState) => {
    dispatch({
      type: GET_DATE_TAB_RESULTS,
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios({
      method: "get",
      url: URL,
      headers: api_request_headers,
      data: {},
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let TemsDetailsWithOutUTCFormat =
          PayloadData && JSON.parse(JSON.stringify(PayloadData));

        let { Universal, LastActiveUniversalProps } = getState();
        let payload = { PayloadData, TemsDetailsWithOutUTCFormat };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          DateTabResultsSuccess(action, Universal, LastActiveUniversalProps);
        dispatch({
          type: GET_DATE_TAB_RESULTS_SUCCESS,
          payload: {
            PayloadData,
            TemsDetailsWithOutUTCFormat,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const getInitialSchoolObjService = (AccessToken, requestObj) => {
  let URL = Base_URL + "school/getInitialSchoolObj";
  return (dispatch) => {
    dispatch({
      type: GET_INITIAL_SCHOOL_OBJECT,
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios({
      method: "post",
      url: URL,
      headers: api_request_headers,
      data: requestObj,
    })
      .then(function (response) {
        dispatch({
          type: GET_INITIAL_SCHOOL_OBJECT_SUCCESS,
          payload: response.data.value,
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: GET_INITIAL_SCHOOL_OBJECT_FAIL,
          payload: { statusCode },
        });
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

//#endregion Test Tab

/**
 *
 * @param {Selected Date} value
 * action to save selected date in date tab
 */
export const SaveSelected_Date = (value) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_DATE,
      payload: value,
    });
  };
};

/**
 *
 * @param {Selected Range} value
 * action to save selected Range in date tab
 */
export const SaveSelected_Range = (value) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_RANGE,
      payload: value,
    });
  };
};

/**
 * Action to open dropdown to display dates list.
 */
export const OpenSelectorInDateTab = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.OPEN_SELECTOR_IN_DATE_TAB,
    });
  };
};
/**
 *
 * @param {string} from
 *  to open dates in Date tab
 */
export const OpenDatePickerInDateTab = (from) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.OPEN_DATE_PICKER_IN_DATE_TAB,
      payload: from,
    });
  };
};

export const OpenDateRangeInDateTab = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.OPEN_DATE_RANGE_IN_DATE_TAB,
    });
  };
};

// #endregion

/**
 *
 * @param {Object} selectedStudent --selected student.
 * @param {String} SelectedStrand
 * @param {String} SelectedStandard_id
 *
 * it triggers when the user selects a student from the class based report.
 * after state changes by this action. it will start executing the api to get the complete details of a student details.(ex: strands table ,test list of a student,overview details)
 */
export const GetCompleteStudentReport = (
  selectedStudent,
  SelectedStrand,
  SelectedStandard,
  CurrentDataForStudentId
) => {
  return (dispatch, getState) => {
    const { LastActiveUniversalProps } = getState();
    dispatch({
      type: U_S_Action_Types.SET_PROP_TO_GET_COMPLETE_STUDENT_REPORT,
      payload: {
        selectedStudent,
        SelectedStrand,
        SelectedStandard,
        CurrentDataForStudentId,
        LastActiveUniversalProps,
      },
    });
  };
};

// Orr drill down for District Charts
export const navigateToClassReport = (selectedClass, fluencyRubrix) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.ORR_DISTRICT_DRILL_DOWN,
      payload: { selectedClass: selectedClass, fluencyRubrix: fluencyRubrix },
    });
  };
};
// Orr drill down for District RHO Chart
export const navigateToStudentRHOReport = (selStudent, selClass) => {
  selStudent["grade"] =
    selStudent["grade"] && `grade_${selStudent["grade"].toLocaleLowerCase()}`;
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.ORR_DISTRICT_RHO_DRILL_DOWN,
      payload: {
        selStudent,
        selectedClass: selClass,
      },
    });
  };
};

// Orr drill down for school level charts
export const navigateToStudentReport = (selectedStudent, fluencyRubrix) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.ORR_SCHOOL_DRILL_DOWN,
      payload: {
        selectedStudent: selectedStudent,
        fluencyRubrix: fluencyRubrix,
      },
    });
  };
};
// Orr drill down for Class level charts
export const navigateToStudentReportFromClassReport = (
  selectedStudent,
  fluencyRubrix
) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.ORR_CLASS_DRILL_DOWN,
      payload: {
        selectedStudent: selectedStudent,
        fluencyRubrix: fluencyRubrix,
      },
    });
  };
};
/**
 *
 * @param {Object} selectedClass
 * @param {Object} School_Sp_Object
 *
 * when class selected from right side view of school strands report, then we will navigate to class report and will display with the current strand details of a class.
 */
export const GetCompleteClassReport = (
  selectedClass,
  School_Sp_Object,
  Current_Class_SP_Grade
) => {
  return (dispatch, getState) => {
    let { LastActiveUniversalProps } = getState();
    dispatch({
      type: U_S_Action_Types.SET_PROP_TO_GET_COMPLETE_CLASS_REPORT,
      payload: {
        selectedClass,
        School_Sp_Object,
        Current_Class_SP_Grade,
        LastActiveUniversalProps,
      },
    });
  };
};
export const NavigateTo_School_Reports_On_SchoolSelection_from_List = (
  SelectedSchool,
  SP_Reducer
) => {
  return (dispatch, getState) => {
    let { LastActiveUniversalProps } = getState();
    dispatch({
      type: U_S_Action_Types.SET_PROP_TO_GET_COMPLETE_SCHOOL_REPORT,
      payload: { SelectedSchool, SP_Reducer, LastActiveUniversalProps },
    });
  };
};

export const GetStudent_Data_Action = (field, res, getTestsAfterStd_Data) => {
  return (dispatch, getState) => {
    let isPastDistrictTerm = getState().Universal.isPastDistrictTerm;

    if (field == "beforeApi") {
      dispatch({
        type: STUDENT_DATA_ACTION,
      });
    } else if (field == "success") {
      dispatch({
        type: STUDENT_DATA_ACTION_SUCCESS,
        payload: { res, getTestsAfterStd_Data, isPastDistrictTerm },
      });
    } else if (field == "fail") {
      dispatch({
        type: STUDENT_DATA_ACTION_FAIL,
        payload: { getTestsAfterStd_Data, isPastDistrictTerm },
      });
    }
  };
};
export const ClickAgpcsvPopup = (
  value,
  requestObj,
  AccessToken,
  make_api_call
) => {
  return (dispatch) => {
    dispatch({
      type: AGP_CSVPOPUP,
      payload: value,
    });
    if (value) {
      make_api_call = true;
    }
    dispatch(
      StudentGradeTestCountAPI(value, requestObj, AccessToken, make_api_call)
    );
  };
};
export const ClickStudentDataInfoIcon = (infoFor) => {
  return (dispatch) => {
    dispatch({
      type: STUDENTDATA_INFO_ICON,
      payload: infoFor,
    });
  };
};

export const ClickPdTestsInfoIcon = (infoFor) => {
  return (dispatch) => {
    dispatch({
      type: PD_TESTS_INFOICON,
      payload: infoFor,
    });
  };
};

export const ClickPdDatesInfoIcon = (infoFor) => {
  return (dispatch) => {
    dispatch({
      type: PD_DATES_INFOICON,
      payload: infoFor,
    });
  };
};
export const ClickPDClassCompareCheckBox = (value) => {
  return (dispatch) => {
    dispatch({
      type: PD_CLASS_COMPARE_CHECKBOXES,
      payload: value,
    });
  };
};

// AGP action types start
export const ClickBellNotification = (value) => {
  return (dispatch) => {
    dispatch({
      type: BELL_NOTIFICATION,
      payload: value,
    });
  };
};

export const hideDownloadNotificationDotIcon = () => {
  return (dispatch) => {
    dispatch({
      type: HIDE_DOWNLOAD_NOTIFICATION_DOT_ICON,
    });
  };
};

export const LoadBellNotificationAPI = (AccessToken, userId) => {
  //let URL = Base_URL +"getCompleteAndFailedJobCount?userId="+userId;
  let URL = CompleteAndFailedJobCount + userId;
  return (dispatch) => {
    dispatch({
      type: BELL_NOTIFICATION_API,
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .get(URL, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let Response = response.data.value;
        dispatch({
          type: BELL_NOTIFICATION_API_SUCCESS,
          payload: { Response },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AGP_CSVPOPUP,
          payload: value,
        });
        if (value) {
          make_api_call = true;
        }
        dispatch(
          StudentGradeTestCountAPI(
            value,
            requestObj,
            AccessToken,
            make_api_call
          )
        );
      });
  };
};
export const StudentGradeTestCountAPI = (
  value,
  requestObj,
  AccessToken,
  make_api_call
) => {
  let URL = Base_URL + "getStudentGradeTestCountAndDates";
  return (dispatch) => {
    if (value && make_api_call) {
      let seconds_Start = new Date().getTime() / 1000;
      api_request_headers.Authorization = "Bearer ".concat(AccessToken);
      axios({
        method: "post",
        url: URL,
        headers: api_request_headers,
        data: requestObj,
      })
        .then(function (response) {
          dispatch({
            type: STUDENT_GRADE_TESTCOUNTANDDATES,
            payload: response.data.value,
          });
        })
        .catch(function (error) {
          //   dispatch(postErrorLog(AccessToken, error, seconds_Start))
          let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        });
    }
  };
};
export const ClickAgpcsvPopupConfirmation = (value) => {
  return (dispatch) => {
    dispatch({
      type: AGP_CSVPOPUPCONFIRMATION,
      payload: value,
    });
  };
};
export const AlreadyRequested = (value) => {
  return (dispatch) => {
    dispatch({
      type: AGP_ALREADY_REQUESTED,
      payload: value,
    });
  };
};

export const AgpCSVCheckboxes = (value, standardORTestScore) => {
  return (dispatch) => {
    dispatch({
      type: AGP_CSV_CHECKBOXES,
      payload: { value, standardORTestScore },
    });
  };
};
export const AgpCSVRadioboxes = (value, requestObj, AccessToken, Nav) => {
  return (dispatch, getState) => {
    let ContextHeader = getState().Universal.ContextHeader;
    requestObj.rosterGrade =
      value == "ALL" ? value : ContextHeader.Roster_Tab.selectedRosterGrade;
    dispatch({
      type: AGP_CSV_RADIOBOXES,
      payload: value,
    });
    dispatch(StudentGradeTestCountAPI(true, requestObj, AccessToken, true));
  };
};

export const StoreDataFromAssessment = (data) => {
  return (dispatch) => {
    dispatch({
      type: STORE_DATA_FROM_ASSESSMENT,
      payload: data,
    });
  };
};

//AGP action types ends

export const GetSummaryDefault = (AccessToken, requestObj) => {
  let URL = Base_URL + "summary/default";
  return (dispatch, getState) => {
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    if (requestObj.termId == undefined) {
      const { DateTabReducer } = getState();
      requestObj.termId = DateTabReducer.Context_DateTab.SelectedDistrictTerm.termId;
    }
    dispatch({
      type: GET_SUMMARYREPORTS_DEFAULT,
    });

    axios({
      method: "post",
      url: URL,
      headers: api_request_headers,
      data: requestObj,
    })
      .then(function (response) {
        let Data = JSON.parse(JSON.stringify(response.data.value));
        let Role =
          response.data.role == "DISTRICT_ADMIN" &&
          DISTRICT_ADMIN_REPORTS === "false"
            ? "SCHOOL_ADMIN"
            : response.data.role;
        let UserId = response.data.userId;
        let userName = response.data.userName;
        let CurrentDateTime = new Date();
        let { Universal, LastActiveUniversalProps } = getState();
        let { NavigationByHeaderSelection } = Universal;
        let fromContext =
          Role == "DISTRICT_ADMIN"
            ? "district"
            : Role == "SCHOOL_ADMIN"
            ? "school"
            : "class";
        let { viewDetails } =
          Data && Data.standardPerformance
            ? Data.standardPerformance
            : { viewDetails: undefined };
        let selectedTaxonomy_input; // it should be undefined ;
        let {
          gradeDetails,
          HeaderStrands,
          TaxonomyList,
          selectedTaxonomy,
          studentList,
        } = Strands_GradeDetails_Of_Taxonomy(
          viewDetails,
          selectedTaxonomy_input,
          fromContext
        );
        let payload = {
          Data,
          Role,
          AccessToken,
          UserId,
          CurrentDateTime,
          Universal,
          gradeDetails,
          HeaderStrands,
          TaxonomyList,
          selectedTaxonomy,
          studentList,
          NavigationByHeaderSelection,
          fromContext,
          userName,
        };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          summaryDefaultSuccess(action, Universal, LastActiveUniversalProps);

        dispatch({
          type: GET_SUMMARYREPORTS_DEFAULT_SUCCESS,
          payload: {
            Data,
            Role,
            AccessToken,
            UserId,
            CurrentDateTime,
            Universal,
            gradeDetails,
            HeaderStrands,
            TaxonomyList,
            selectedTaxonomy,
            studentList,
            NavigationByHeaderSelection,
            fromContext,
            userName,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        console.log(" error : ", error);
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
