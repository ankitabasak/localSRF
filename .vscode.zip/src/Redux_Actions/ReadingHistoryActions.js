import { ReadingHistoryTypes } from '../Reducer_Action_Types/ReadingHistoryTypes';
import { Reading_History_API, ORR_URL, CSV_DOWNLOAD_STUDENT } from '../Utils/globalVars';
import axios from 'axios';

/**
 * @param {object } readingHistoryFilterData
 * @param { string }  externalFilter
 * @param {string} internalFilter
 */
export const READING_HISTORY_STUDENT_DATA = (AccessToken, payLoad, value) => {
  let AuthURL = ORR_URL + Reading_History_API;

  let Payload = {
    filters: payLoad
  };

  return dispatch => {
    dispatch({
      type: ReadingHistoryTypes.SRH_LOADER,
    })

    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;
        dispatch({
          type: ReadingHistoryTypes.READING_HISTORY_DATA_SUCCESS,
          payload: Response_Data,
          value: value
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: ReadingHistoryTypes.READING_HISTORY_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

export const SRH_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: ReadingHistoryTypes.SRH_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SRH_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_STUDENT;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: ReadingHistoryTypes.SRH_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: ReadingHistoryTypes.READING_HISTORY_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

export const SORT_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: ReadingHistoryTypes.READING_HISTORY_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SORTED_S_READING_HISTORY_DATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: ReadingHistoryTypes.SAVE_SORTED_S_READING_HISTORY_DATA,
      payload: { SortedArray }
    });
  };
};

//error handling
export const S_RH_ERRORHANDLING = obj => {
  return dispatch => {
    dispatch({
      type: ReadingHistoryTypes.SRH_ERROR_HANDLING,
      payload: obj
    });
  };
};
