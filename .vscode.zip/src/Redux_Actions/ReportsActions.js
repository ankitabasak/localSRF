import axios from "axios";
import {
  Get_Class_TestScores_Details_URL,
  Get_Class_Strands,
  Base_URL,
  Get_Class_TestScores_OverTime_API,
  SchoolCSVDownload,
  ClassCSVDownload,
  StudentCSVDownload,
  Students_of_class_strands,
  LineChart_of_class_strands,
  ClassTestGradeListUrl,
  ClassTestAssessmentUrl,
  DistrictCSVDownload,
  RosterTab_Post,
  DistrictTestStatusCSVDownload,
  SchoolTestStatusCSVDownload,
  ClassTestStatusCSVDownload,
  StudentTestStatusCSVDownload,
  api_request_headers,
  Disable_AutoSelect_Std_Pref_LeftView,
} from "../Utils/globalVars";
import {
  Report_Action_Types,
  CHANGE_BUBBLE_OF_PAGINATION_FOR_REMAINIG,
  MOVE_BUBBLES_OF_PAGINATION_FOR_REMAINING,
  GET_STANDARDPERFORMANCE_DETAIL_SUCCESS,
  GET_STUDENTS_OF_A_CLASS_STRAND_SUCCESS,
  SELECTED_TEST_GRADE_DROPDOWN_CLASS,
  TEST_ASSESSMENT_MAX_COUNT_CLASS_SUCCESS,
  TEST_GRADE_LIST_OF_CLASS_SUCCESS,
  TEST_ASSESSMENT_MAX_COUNT_CLASS,
  CHANGE_TOGGLE_IN_SP_OVERVIEW_COMPONENT,
  GET_CLASS_TESTSCORES_OVER_TIME_SUCCESS,
} from "../Reducer_Action_Types/ReportsActionTypes";
import {
  Student_ReportActionTypes,
  SELECTED_TEST_GRADE_DROPDOWN_STUDENT,
} from "../Reducer_Action_Types/Student_ReportTypes";
import { U_S_Action_Types } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  School_Action_Types,
  SELECTED_TEST_GRADE_DROPDOWN_IN_SCHOOL,
  SELECTED_TEST_ASSESSED_DROPDOWN_IN_SCHOOL,
  CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_SCHOOL_REPORT,
} from "../Reducer_Action_Types/School_Report_Types";
import {
  SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT,
  SELECTED_TEST_GRADE_DROPDOWN_IN_DISTRICT,
  SELECTED_TEST_ASSESSED_DROPDOWN_IN_DISTRICT,
  CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_DISTRICT_REPORT,
  SAVE_SORTED_SCHOOL_DETAILS_LIST,
  OPEN_OR_CLOSE_STRANDS_GRADES_LIST_DISTRICT,
  MOVE_HEADER_IN_DISTRICT_STRANDS_TABLE,
  OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_DISTRICT,
  OPEN_OR_CLOSE_STRANDS_QUESTIONS_LIST_DISTRICT,
} from "../Reducer_Action_Types/District_Report_Types";
import { ClassGroupingTypes } from "../Reducer_Action_Types/ClassGroupingTypes";
import {
  CHANGE_BUBBLE_OF_PAGINATION_IN_SUMMARY,
  MOVE_BUBBLES_OF_PAGINATION_IN_SUMMARY,
} from "../Reducer_Action_Types/SummaryActionsTypes";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  GetAssessed_Ques_ToPersist,
  GetTaxonomy_ToPersist_AndStrandDetails,
  Strands_Grade_ToPersist,
  Sort_ApiResponse_Payload_Array,
  calculateStrandAvgOnTaxonimy_Filter,
  sortTaxonomyDataBasedOnUserPrefferences,
  retriggerAPI,
  DateFormarFor_APiCalls,
  GetComponentCode_In_The_Array,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { multiDimensionalUnique_inClass } from "../Redux_Reducers/ReportsReducer";
import { postErrorLog } from "./AuthenticationAction";
import { class_SP_Success, class_TS_Overtime_Success } from "../services/universalSelector/universalSelector_1";
import { SUMMARY_CLASS_CSV } from "../Reducer_Action_Types/summaryReports_Action_Types";
import {
  SummaryTests
} from "../Redux_Actions/summaryReports_Actions";
export const Get_CSV_Details = (AccessToken, ReqPayload, Nav,requestFromTestStatus) => {
  let URL;
  let currentNavContext;
  if (Nav.district) {
    URL = Base_URL + DistrictCSVDownload;
    if (Nav.test_status) {
      URL = Base_URL + DistrictTestStatusCSVDownload;
    }
  } else if (Nav.school) {
    URL = Base_URL + SchoolCSVDownload;
    if (Nav.test_status || requestFromTestStatus) {
      URL = Base_URL + SchoolTestStatusCSVDownload;
    }
  } else if (Nav.class) {
    URL = Base_URL + ClassCSVDownload;
    if (Nav.test_status || requestFromTestStatus) {
      URL = Base_URL + ClassTestStatusCSVDownload;
    }
  } else {
    URL = Base_URL + StudentCSVDownload;
    if (Nav.test_status) {
      URL = Base_URL + StudentTestStatusCSVDownload;
    }
  }
  if (Nav.district) {
    currentNavContext = {
      currentContext: "district",
    };
  } else if (Nav.school) {
    currentNavContext = { currentContext: "school" };
  } else if (Nav.class) {
    currentNavContext = { currentContext: "class" };
  } else if (Nav.student) {
    currentNavContext = { currentContext: "student" };
  }

  currentNavContext.reportDataCSV = requestFromTestStatus?false:!Nav.test_status; //temp change
  currentNavContext.testStatus = requestFromTestStatus?true:Nav.test_status; //temp change

  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.GET_CSV_DATA,
      payload: {
        currentNavContext,Nav
      },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;

        dispatch({
          type: Report_Action_Types.GET_CSV_DATA_SUCCESS,
          payload: { ResPayload, currentNavContext },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));

        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
export const SPGet_CSV_Details = (AccessToken, ReqPayload, Nav,TestsResponse) => {
  let URL;
  let currentNavContext;
  if (Nav.district) {
    URL = Base_URL + DistrictCSVDownload;
    if (Nav.test_status) {
      URL = Base_URL + DistrictTestStatusCSVDownload;
    }
  } else if (Nav.school) {
    URL = Base_URL + SchoolCSVDownload;
    if (Nav.test_status) {
      URL = Base_URL + SchoolTestStatusCSVDownload;
    }
  } else if (Nav.class) {
    URL = Base_URL + ClassCSVDownload;
    if (Nav.test_status) {
      URL = Base_URL + ClassTestStatusCSVDownload;
    }
  } else {
    URL = Base_URL + StudentCSVDownload;
    if (Nav.test_status) {
      URL = Base_URL + StudentTestStatusCSVDownload;
    }
  }
  if (Nav.district) {
    currentNavContext = {
      currentContext: "district",
    };
  } else if (Nav.school) {
    currentNavContext = { currentContext: "school" };
  } else if (Nav.class) {
    currentNavContext = { currentContext: "class" };
  } else if (Nav.student) {
    currentNavContext = { currentContext: "student" };
  }

  currentNavContext.reportDataCSV = true; //temp change
  currentNavContext.testStatus = false; //temp change

  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.GET_CSV_DATA,
      payload: {
        currentNavContext,Nav
      },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    if(TestsResponse && TestsResponse.tests && TestsResponse.tests.length>0){
      let SummaryComponentCodes = TestsResponse && TestsResponse.tests &&  TestsResponse.tests.length>0 ? GetComponentCode_In_The_Array(TestsResponse.tests):[];
      ReqPayload.componentCodeList = SummaryComponentCodes;
    }
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;

        dispatch({
          type: Report_Action_Types.GET_CSV_DATA_SUCCESS,
          payload: { ResPayload, currentNavContext },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));

        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const SummaryGet_CSV_Details = (AccessToken, ReqPayload, Nav,DateTabReducer,Roster_data,TestsApiReqObj,TestsResponse,FromTestStatus) => {

  /* Summary Test status changes starts */

    let Date_TS_Cont = DateTabReducer.Context_DateTab_TestStatus
 
     let StartDate = Date_TS_Cont.StartDateInDateTab;
     let EndDate = Date_TS_Cont.EndDateInDateTab;
 
     StartDate = StartDate == '' ?
       Date_TS_Cont.SelectedDistrictTerm.termStartDate :
       StartDate;
 
     EndDate = EndDate == '' ?
       Date_TS_Cont.SelectedDistrictTerm.termEndDate :
       EndDate;
     let Resp = DateFormarFor_APiCalls(StartDate, EndDate);
     ReqPayload.startDate = Resp.StartDate;
     ReqPayload.endDate = Resp.EndDate;
 
     // test Status related updated based on context here
     let selectedIds;
     let selectedContext
 
     if (Nav.student) {
       selectedIds = Roster_data.SelectedStudent.id == undefined ? "" : [Roster_data.SelectedStudent.id];
       selectedContext = "student";
 
       //delete ReqPayload.districtId
       //delete ReqPayload.schoolId
     } else if (Nav.class) {
       selectedIds = Roster_data.StudentIds;
       selectedContext = "student";
       //  delete ReqPayload.districtId
       //  delete ReqPayload.schoolId
     } else if (Nav.school) {
       selectedIds = Roster_data.ClassIds;
       selectedContext = "school";
       delete ReqPayload.districtId
     } else {
       selectedIds = Roster_data.SchoolIds;
       selectedContext = "school"
     }
 
     ReqPayload.termId = Date_TS_Cont.SelectedDistrictTerm.termId
     ReqPayload.ids = selectedIds
     ReqPayload.context = selectedContext
     delete ReqPayload.classIds
     delete ReqPayload.studentIds
     delete ReqPayload.standardIds
   /* Summary Test status changes ends */
 /* for summary tests api*/
 TestsApiReqObj.termId = Date_TS_Cont.SelectedDistrictTerm.termId;
 TestsApiReqObj.startDate = Resp.StartDate;
 TestsApiReqObj.endDate = Resp.EndDate;
 
 /* for summary tests  api end */
   let URL;
   let currentNavContext;
   if (Nav.district) {
     URL = Base_URL + DistrictCSVDownload;
     if (Nav.test_status) {
       URL = Base_URL + DistrictTestStatusCSVDownload;
     }
   } else if (Nav.school) {
     URL = Base_URL + SchoolCSVDownload;
     if (Nav.test_status) {
       URL = Base_URL + SchoolTestStatusCSVDownload;
     }
   } else if (Nav.class) {
     URL = Base_URL + ClassCSVDownload;
     if (Nav.test_status || true) {
       URL = Base_URL + ClassTestStatusCSVDownload;
     }
   } else {
     URL = Base_URL + StudentCSVDownload;
     if (Nav.test_status) {
       URL = Base_URL + StudentTestStatusCSVDownload;
     }
   }
 
   if (Nav.district) {
     currentNavContext = {
       currentContext: "district",
     };
   } else if (Nav.school) {
     currentNavContext = { currentContext: "school" };
   } else if (Nav.class) {
     currentNavContext = { currentContext: "class" };
   } else if (Nav.student) {
     currentNavContext = { currentContext: "student" };
   }
 
   currentNavContext.reportDataCSV = false;
   currentNavContext.testStatus = true;
   
 
   return (dispatch,getState) => {
     dispatch({
       type: SUMMARY_CLASS_CSV,
       payload: {
        FromTestStatus
      }});
 
     dispatch({
       type: Report_Action_Types.GET_CSV_DATA,
       payload: {
         currentNavContext,Nav
       },
     });
     let seconds_Start = new Date().getTime() / 1000;
     api_request_headers.Authorization = "Bearer ".concat(AccessToken);
     if(TestsResponse && TestsResponse.tests && TestsResponse.tests.length>0){
       let SummaryComponentCodes = TestsResponse && TestsResponse.tests &&  TestsResponse.tests.length>0 ? GetComponentCode_In_The_Array(TestsResponse.tests):[];
       ReqPayload.componentCodeList = SummaryComponentCodes;
     }
     axios
       .post(URL, ReqPayload, {
         headers: api_request_headers,
       })
       .then(function (response) {
         let ResPayload = response.data.value;
         let SummaryTestStatus = true;
         dispatch({
           type: Report_Action_Types.GET_CSV_DATA_SUCCESS,
           payload: { ResPayload, currentNavContext,SummaryTestStatus },
         });
       })
       .catch(function (error) {
         dispatch(postErrorLog(AccessToken, error, seconds_Start));
 
         let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
 
         dispatch({
           type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
           payload: { statusCode },
         });
       });
 
     
   };
 };
export const SetDownloadCsvToFalse = () => {
  return (dispatch,getState) => {
    let { Universal } = getState();
    let {NavigationByHeaderSelection} = Universal;
    dispatch({
      type: Report_Action_Types.DOWNLOADED_CSV_DATA,
      payload:  NavigationByHeaderSelection 
    });
  };
};

export const Reset_CSV_download = () => {
  return (dispatch,getState) => {
    let { Universal } = getState();
    let {NavigationByHeaderSelection} = Universal;
    dispatch({
      type: Report_Action_Types.DOWNLOADED_CSV_DATA,
      payload:  NavigationByHeaderSelection 
    });
  };
};
/**
 *
 * @param {string} token -- Jwt AccessToken.
 * @param {object} ReqPayload -- Api Req_Payload.
 * @param {Boolean} Enableload
 */
export const Get_Class_TestScores_Over_Time = (
  AccessToken,
  ReqPayload,
  Enableload
) => {
  let URL = Base_URL + Get_Class_TestScores_OverTime_API;

  return (dispatch, getState) => {
    dispatch({
      type: Report_Action_Types.GET_CLASS_TESTSCORES_OVER_TIME,
      payload: Enableload,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;
        let compareOptions = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = { ResPayload, compareOptions };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          class_TS_Overtime_Success(
            action,
            Universal,
            LastActiveUniversalProps
          );
        dispatch({
          type: GET_CLASS_TESTSCORES_OVER_TIME_SUCCESS,
          payload: {
            ResPayload,
            compareOptions,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch(postErrorLog(AccessToken, error, seconds_Start));

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {Boolean} openOrClose --true/false
 * @param {String} SelectedNav  -- string
 * triggers when user open/close the info note in class_testScore_Overview.
 */
export const OpenOrCloseNoteIn_TS_OT = (openOrClose, SelectedNav) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.OPEN_OR_CLOSE_NOTEIN_TS_OT,
      payload: { openOrClose, SelectedNav },
    });
  };
};

/**
 *
 * @param {string} selectedOption --class/school/district ,
 * @param {CheckOrUncheck} CheckOrUncheck --true/false
 * for changeing compare tab option.
 */
export const CheckCompareTabs = (selectedOption, CheckOrUncheck) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.CHECK_COMPARE_TABS_IN_CLASS,
      payload: { selectedOption, CheckOrUncheck },
    });
  };
};

/**
 *
 * @param {String} selectedOption
 * @param {Boolean} CheckOrUncheck
 * when click on checkbox label name , then it will execute to change selected line in the graph.
 */

export const EnableOrDisableLineColorIn_LC = (
  selectedOption,
  CheckOrUncheck
) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.ENABLE_OR_DISABLE_LINE_COLOR_IN_LC,
      payload: { selectedOption, CheckOrUncheck },
    });
  };
};
/**
 *
 * @param {String} AccessToken
 * @param {Object} reqObject
 * @param {Boolean} EnableLoading
 * to get class strands table details.
 */
export const Get_Class_StandardPerformance_Details = (
  AccessToken,
  reqObject,
  EnableLoading
) => {
  let URL = Base_URL + Get_Class_Strands;

  return (dispatch, getState) => {
    dispatch({
      type: Report_Action_Types.GET_STANDARDPERFORMANCE_DETAIL,
      payload: EnableLoading,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, reqObject, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let Data = response.data.value;
        // Data = Data == null || Data == undefined ? {} : Data;

        let UserPreferences = getState().Universal.UserPreferences;
        let LastNav = getState().LastActiveUniversalProps.NaviGation;
        let last_active_Taxonomy_And_StrandDetails;
        let currentNav = getState().Universal.NavigationByHeaderSelection;
        if (currentNav.S_performance && currentNav.Overview) {
          last_active_Taxonomy_And_StrandDetails =
            GetTaxonomy_ToPersist_AndStrandDetails(LastNav, getState);
        }

        let StdReports = getState().StudentReports;
        let ClassReports = getState().Reports;
        let SchoolReports = getState().schoolReducer;
        let DistrictReports = getState().DistrictReducer;

        let Action = {
          payload: {
            Data,
            DataForGrade: reqObject.grade,
            last_active_Taxonomy_And_StrandDetails,
            LastNav,
            currentNav,
            sc_Asse_ques_api,
            Sc_strads_Api,
            cs_ques,
            cs_taxon,
            StdReports,
            SchoolReports,
            DistrictReports,
            UserPreferences,
          },
        };

        let Class_StrandsToSet = ClassStrandsState_OnSTrandsSuccess(
          ClassReports,
          Action
        );

        let Sc_strads_Api, sc_Asse_ques_api, D_strandsApi, D_Asse_Ques_Api;

        let sc_ques =
          SchoolReports.Sc_StandardPerformance_Overview
            .StandardPerformanceFilter.TestAssessment;
        let sc_taxon =
          SchoolReports.Sc_StandardPerformance_Overview
            .StandardPerformanceFilter.Taxonomy;

        let D_ques =
          DistrictReports.D_StandardPerformance_Overview
            .StandardPerformanceFilter.TestAssessment;
        let D_taxon =
          DistrictReports.D_StandardPerformance_Overview
            .StandardPerformanceFilter.Taxonomy;

        let cs_ques =
          Class_StrandsToSet.StandardPerformance_Overview
            .StandardPerformanceFilter.TestAssessment;
        let cs_taxon =
          Class_StrandsToSet.StandardPerformance_Overview
            .StandardPerformanceFilter.Taxonomy;

        if (
          sc_ques.selectedTestAssessment !== cs_ques.selectedTestAssessment &&
          response.data.value !== null
        ) {
          sc_Asse_ques_api = true;
        }

        if (
          sc_taxon.selectedTaxonomy !== cs_taxon.selectedTaxonomy &&
          response.data.value !== null
        ) {
          Sc_strads_Api = true;
        }

        if (
          D_ques.selectedTestAssessment !== cs_ques.selectedTestAssessment &&
          response.data.value !== null
        ) {
          D_strandsApi = true;
        }

        if (
          D_taxon.selectedTaxonomy !== cs_taxon.selectedTaxonomy &&
          response.data.value !== null
        ) {
          D_Asse_Ques_Api = true;
          // sc_taxon.TaxonomyList.find(item => item == cs_ques.selectedTaxonomy) ? true : undefined
        }

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
          Data,
          DataForGrade: reqObject.grade,
          last_active_Taxonomy_And_StrandDetails,
          LastNav,
          currentNav,
          sc_Asse_ques_api,
          Sc_strads_Api,
          cs_ques,
          cs_taxon,
          StdReports,
          SchoolReports,
          DistrictReports,
          Class_StrandsToSet,
          D_strandsApi,
          D_Asse_Ques_Api,
        };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          class_SP_Success(action, Universal, LastActiveUniversalProps);

        dispatch({
          type: GET_STANDARDPERFORMANCE_DETAIL_SUCCESS,
          payload: {
            Data,
            DataForGrade: reqObject.grade,
            last_active_Taxonomy_And_StrandDetails,
            LastNav,
            currentNav,
            sc_Asse_ques_api,
            Sc_strads_Api,
            cs_ques,
            cs_taxon,
            StdReports,
            SchoolReports,
            DistrictReports,
            Class_StrandsToSet,
            D_strandsApi,
            D_Asse_Ques_Api,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        dispatch({
          type: Report_Action_Types.GET_STANDARDPERFORMANCE_DETAIL_FAIL,
          payload: error,
        });
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

//

/**
 *
 * @param {Toggle Test Grade DropDown Selection Standard performance} SelectedToggle
 */

export const toggleClickOnTestDropDown = (testDropDown_Status) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.OPEN_OR_CLOSE_TEST_GRADE_DROPDOWN,
      payload: testDropDown_Status,
    });
  };
};

/**
 *
 * @param {Selected Test Grade DropDown Standard performance} SelectedToggle
 */

export const selectedTestDropDownStandardPerformance = (testgrade_selected) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.SELECTED_TEST_GRADE_DROPDOWN,
      payload: testgrade_selected,
    });
  };
};

/**
 *
 * @param {Toggle Test Assessed Question DropDown Selection Standard performance} SelectedToggle
 */

export const toggleClickOnTestAssessedDropDown = (testAssessment_Status) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.OPEN_OR_CLOSE_TEST_ASSESSED_DROPDOWN,
      payload: testAssessment_Status,
    });
  };
};

/**
 *
 * @param {Selected Test Assessed Question DropDown Standard performance} SelectedToggle
 */

export const selectedTestAssessedDropDownStandardPerformance = (
  testAssessment_selected
) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.SELECTED_TEST_ASSESSED_DROPDOWN,
      payload: testAssessment_selected,
    });
  };
};

/**
 *
 * @param {string} SelectedToggle  -- selected toggle option (ex: graph/student)
 * it will trigger when user selected any graph ot students list view in the standardperformance overview component.
 */

export const ChangeToggleIn_SP_Overview = (SelectedToggle, from, Nav) => {
  return (dispatch, getState) => {
    if (from == "schoolreport") {
      let { openInfoTooltip_in_P_OT_header } =
        getState().schoolReducer.Sc_StandardPerformance_Overview;
      if (!openInfoTooltip_in_P_OT_header) {
        dispatch({
          type: CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_SCHOOL_REPORT,
          payload: SelectedToggle,
        });
      }
    } else if (from == "districtreport") {
      let { openInfoTooltip_in_SP } =
        getState().DistrictReducer.D_StandardPerformance_Overview;
      if (!openInfoTooltip_in_SP) {
        dispatch({
          type: CHANGE_TOGGLE_IN_SP_RIGHT_VIEW_OF_DISTRICT_REPORT,
          payload: SelectedToggle,
        });
      }
    } else {
      let { openInfoTooltip_in_P_OT_header } =
        getState().Reports.StandardPerformance_Overview;
      if (!openInfoTooltip_in_P_OT_header) {
        dispatch({
          type: CHANGE_TOGGLE_IN_SP_OVERVIEW_COMPONENT,
          payload: SelectedToggle,
        });
      }
    }
  };
};
/**
 * action is to open or close info note popup on performance overtime graph header of strand details.
 * it is for all reports in the application.
 * @param {Boolean} OpenOrClose
 * @param {Object} Nav
 */
export const OpenOrClose_P_OT_Info_Popup = (OpenOrClose, Nav) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.OPEN_OR_CLOSE_P_OT_INFO_POPUP,
      payload: { OpenOrClose, Nav },
    });
  };
};

/**
 *
 * @param {String} selectedfiield
 * @param {Boolean} check
 */
export const CompareCheckBoxOption_For_STrands_LC = (selectedfiield, check) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.COMPARE_CHECKBOX_OPTION_FOR_STRANDS_LC,
      payload: { selectedfiield, check },
    });
  };
};
/**
 *
 * @param {String} selectedfiield
 * @param {Boolean} check
 */
export const EnableOrDisableLineColorIn_LC_For_STrands_LC = (
  selectedfiield,
  check
) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.ENABLE_OR_DISABLE_LINE_COLOR_IN_LC_FOR_STRAND_LC,
      payload: { selectedfiield, check },
    });
  };
};

/**
 *
 * @param {string} AccessToken --jwt token.
 * @param {object} reqObject --request payload.
 */
export const Get_Class_TestScores_Details = (
  AccessToken,
  reqObject,
  test,
  enableLoading,
  dontPersistforStudent
) => {
  let URL = Base_URL + Get_Class_TestScores_Details_URL;

  return (dispatch, getState) => {
    dispatch({
      type: Report_Action_Types.GET_CLASS_TESTSCORES_DETAIL,
      payload: { test, enableLoading, dontPersistforStudent },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, reqObject, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        dispatch({
          type: Report_Action_Types.GET_CLASS_TESTSCORES_DETAIL_SUCCESS,
          payload: PayloadData,
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        let retries = getState().Authentication.retryApis;
        let seconds_End = new Date().getTime() / 1000;
        let diffTime = seconds_End - seconds_Start;
        let isAPIRetry = retriggerAPI(diffTime, retries, statusCode);
        if (isAPIRetry) {
          dispatch({
            type: Report_Action_Types.SET_GET_CLASS_TESTSCORES_DETAIL,
          });
        } else {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        }
      });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 * @param {string} Column  --Sort Happend on this Column
 * @param {string} SortType  --desc/asc
 * @param {object} CurrentNav --Navigation Details.
 */
export const SaveSorted_OverViewStudentList = (
  SortedArray,
  Column,
  SortType,
  CurrentNav
) => {
  return (dispatch) => {
    if (CurrentNav.school) {
      dispatch({
        type: School_Action_Types.SAVE_SORTED_CLASS_DETAILS_LIST,
        payload: { SortedArray, Column, SortType, CurrentNav },
      });
    } else if (CurrentNav.district) {
      dispatch({
        type: SAVE_SORTED_SCHOOL_DETAILS_LIST,
        payload: { SortedArray, Column, SortType, CurrentNav },
      });
    } else {
      dispatch({
        type: Report_Action_Types.SAVE_SORTED_STUDENT_DETAILS_LIST,
        payload: { SortedArray, Column, SortType, CurrentNav },
      });
    }
  };
};

/**
 *
 * @param {Array} SortedArray  --oreted Array List
 * @param {Array} ArrayList  -- ArrayList
 * @param {int} minValue  -- Min Value of Sort.
 * @param {int} maxValue  --Max Value of Sort.
 * @param {int} ActiveColumn   --Sorting Column Value.
 * @param {object} Navigation --
 *
 *
 * base on current active report it will work for both call report and school report instances.
 */
export const SaveSorted_OrderOverViewStudentList = (
  SortedArray,
  ArrayList,
  minValue,
  maxValue,
  ActiveColumn,
  Navigation
) => {
  return (dispatch) => {
    if (Navigation.school) {
      dispatch({
        type: School_Action_Types.SAVE_SORTED_CLASS_DETAILS_LIST_BY_HEADER,
        payload: {
          SortedArray,
          ArrayList,
          minValue,
          maxValue,
          ActiveColumn,
          Navigation,
        },
      });
    } else {
      dispatch({
        type: Report_Action_Types.SAVE_SORTED_STUDENTS_DETAILS_LIST_BY_HEADER,
        payload: {
          SortedArray,
          ArrayList,
          minValue,
          maxValue,
          ActiveColumn,
          Navigation,
        },
      });
    }
  };
};

/**
 *
 * @param {string} motion -- Bubble Motion Left/ Right :
 * @param {object} Nav -- Navigation details
 */

export const MoveChartPaginationDisplayBubbles = (motion, Nav) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.MOVE_LINE_CHART_PAGINATIO_BUBBLE,
      payload: { motion, Nav },
    });
  };
};

/**
 *
 * @param {int} Chart_Bubble_Start  -- Chart_Bubble_Start
 * @param {int} positionfrom_BubbleStart -- ex : 1,2,
 * @param {object} Nav -- navigation details
 */

export const ChangeLineChart_paginationBubble = (
  Chart_Bubble_Start,
  positionfrom_BubbleStart,
  Nav
) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.CHANGE_LINE_CHART_PAGINATION_BUBBLE,
      payload: { Chart_Bubble_Start, positionfrom_BubbleStart, Nav },
    });
  };
};
/**
 *
 * @param {string} motion  pagination moving direction (left/right)
 * @param {Object} Nav -- navigation object
 */
export const MoveBubblesOfPaginationFor_Remaining = (motion, Nav) => {
  return (dispatch) => {
    if (Nav.summary) {
      dispatch({
        type: MOVE_BUBBLES_OF_PAGINATION_IN_SUMMARY,
        payload: { motion, Nav },
      });
    } else {
      dispatch({
        type: MOVE_BUBBLES_OF_PAGINATION_FOR_REMAINING,
        payload: { motion, Nav },
      });
    }
  };
};

/**
 *
 * @param {int} BubbleStart --pagination bubble start at
 * @param {} positionfrom_BubbleStart  --from bubble ex: 0,1,2
 * @param {Object} Nav -- Navigation Details
 * @param {int} CountPerPage  --number of records per each page
 */

export const Change_Bubble_Of_PaginationFor_Remaining = (
  BubbleStart,
  positionfrom_BubbleStart,
  CountPerPage,
  Nav
) => {
  return (dispatch) => {
    if (Nav.summary) {
      dispatch({
        type: CHANGE_BUBBLE_OF_PAGINATION_IN_SUMMARY,
        payload: { BubbleStart, positionfrom_BubbleStart, CountPerPage, Nav },
      });
    } else {
      dispatch({
        type: CHANGE_BUBBLE_OF_PAGINATION_FOR_REMAINIG,
        payload: { BubbleStart, positionfrom_BubbleStart, CountPerPage, Nav },
      });
    }
  };
};

/**
 *
 * @param {int} xU  -- x-axis value
 * @param {int } yU  --y-axis value
 * @param {object} tooltip_data  --selected circle data
 * @param {boolean} tooltipDisplay --true/false
 * @param {boolean} ShowTollTipPopUp
 * @param {int} index --index value of selected circle.
 */
export const SetToolTipAndBarValues = (
  xU,
  yU,
  tooltip_data,
  tooltipDisplay,
  index,
  ShowTollTipPopUp,
  Nav
) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.SET_TOOLTIP_AND_BAR_VALUE,
      payload: {
        xU,
        yU,
        tooltip_data,
        tooltipDisplay,
        index,
        ShowTollTipPopUp,
        Nav,
      },
    });
  };
};
/**
 * @param {Object} Nav -- navigation props.
 * Action to Close ToolTip View.
 *
 */

export const CloseToolTip = (Nav) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.CLOSE_TOOLTIP_VIEW,
      payload: Nav,
    });
  };
};

/**
 *
 * @param {string} MotionDirection --  Left Or right
 * we trigger this from both class and school instance.
 */

export const MoveHeaderIn_Strands_Table = (MotionDirection, Nav) => {
  return (dispatch) => {
    Nav.class || Nav.school || Nav.district;
    if (Nav.class) {
      dispatch({
        type: Report_Action_Types.MOVE_HEADER_IN_STRANDS_PERFORMANCE_TABLE,
        payload: MotionDirection,
      });
    } else if (Nav.school) {
      dispatch({
        type: School_Action_Types.MOVE_HEADER_IN_SCHOOL_STRANDS_TABLE,
        payload: MotionDirection,
      });
    } else if (Nav.district) {
      dispatch({
        type: MOVE_HEADER_IN_DISTRICT_STRANDS_TABLE,
        payload: MotionDirection,
      });
    }
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} strandName --selected STrand Name
 * @param {string} standardAvg -- selected standard evg.
 */
export const GetStudentsListOfstandardOrStrandId = (
  AccessToken,
  ReqPayload,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading,
  updateinStudent,
  selectedTaxonomy,
  Sel_Ass_Ques
) => {
  let URL = Base_URL + Students_of_class_strands;

  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.GET_STUDENTS_OF_A_CLASS_STRAND,
      payload: {
        standardId,
        standardAvg,
        strandName,
        standard,
        Enableloading,
        updateinStudent,
      },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        dispatch({
          type: GET_STUDENTS_OF_A_CLASS_STRAND_SUCCESS,
          payload: {
            PayloadData,
            standardId,
            standardAvg,
            strandName,
            standard,
            selectedTaxonomy,
            Sel_Ass_Ques,
          },
        });
      })
      .catch(function (error) {
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
/**
 *
 * @param {String} AccessToken
 * @param {object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} standardAvg
 * @param {string} strandName
 * @param {string} standard
 */
export const GetLineChartDetailsofSelected_Standards = (
  AccessToken,
  ReqPayload,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading
) => {
  let URL = Base_URL + LineChart_of_class_strands;

  return (dispatch, getState) => {
    dispatch({
      type: Report_Action_Types.GET_LINECHART_DETAILS_OF_A_CLASS_STRAND,
      payload: Enableloading,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        timeout: 0,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        dispatch({
          type: Report_Action_Types.GET_LINECHART_DETAILS_OF_A_STRAND_SUCCESS,
          payload: { PayloadData, strandName, persist_compare_checkboxes },
        });
      })
      .catch(function (error) {
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

// Standard perforamance block filter

export const toggleClickOnStandardPerformanceFilter = (
  fromWhereItCame,
  whichDropDown,
  dropDownStatus
) => {
  let SelectedType = "";

  if (fromWhereItCame == "class") {
    if (whichDropDown == "grade") {
      SelectedType =
        Report_Action_Types.OPEN_OR_CLOSE_TEST_GRADE_DROPDOWN_CLASS;
    } else if (whichDropDown == "assessment") {
      SelectedType =
        Report_Action_Types.OPEN_OR_CLOSE_TEST_ASSESSMENT_DROPDOWN_CLASS;
    } else if (whichDropDown == "taxonomy") {
      SelectedType = Report_Action_Types.OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_CLASS;
    }
  } else if (fromWhereItCame == "school") {
    if (whichDropDown == "grade") {
      SelectedType = School_Action_Types.OPEN_OR_CLOSE_STRANDS_GRADES_LIST;
    } else if (whichDropDown == "taxonomy") {
      SelectedType = School_Action_Types.OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_SCHOOL;
    } else {
      SelectedType = School_Action_Types.OPEN_OR_CLOSE_STRANDS_QUESTIONS_LIST;
    }
  } else if (fromWhereItCame == "district") {
    if (whichDropDown == "grade") {
      SelectedType = OPEN_OR_CLOSE_STRANDS_GRADES_LIST_DISTRICT;
    } else if (whichDropDown == "taxonomy") {
      SelectedType = OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_DISTRICT;
    } else {
      SelectedType = OPEN_OR_CLOSE_STRANDS_QUESTIONS_LIST_DISTRICT;
    }
  } else {
    if (whichDropDown == "grade") {
      SelectedType =
        Student_ReportActionTypes.OPEN_OR_CLOSE_TEST_GRADE_DROPDOWN_STUDENT;
    } else if (whichDropDown == "assessment") {
      SelectedType =
        Student_ReportActionTypes.OPEN_OR_CLOSE_TEST_ASSESSMENT_DROPDOWN_STUDENT;
    } else {
      SelectedType =
        Student_ReportActionTypes.OPEN_OR_CLOSE_TAXONOMY_DROPDOWN_STUDENT;
    }
  }

  return (dispatch) => {
    dispatch({
      type: SelectedType,
      payload: dropDownStatus,
    });
  };
};

export const Set_StandardPerformanceFilter = (
  fromWhereItCame,
  whichDropDown,
  filterSelectedData
) => {
  let SelectedData = "";

  if (fromWhereItCame == "class") {
    if (whichDropDown == "grade") {
      SelectedData = SELECTED_TEST_GRADE_DROPDOWN_CLASS;
    } else if (whichDropDown == "assessment") {
      SelectedData = Report_Action_Types.SELECTED_TEST_ASSESSED_DROPDOWN_CLASS;
    } else {
      SelectedData = Report_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_CLASS;
    }
  } else if (fromWhereItCame == "district") {
    if (whichDropDown == "grade") {
      SelectedData = SELECTED_TEST_GRADE_DROPDOWN_IN_DISTRICT;
    } else if (whichDropDown == "taxonomy") {
      SelectedData = SELECTED_TEST_TAXONOMY_DROPDOWN_DISTRICT;
    } else {
      SelectedData = SELECTED_TEST_ASSESSED_DROPDOWN_IN_DISTRICT;
    }
  } else if (fromWhereItCame == "school") {
    if (whichDropDown == "grade") {
      SelectedData = SELECTED_TEST_GRADE_DROPDOWN_IN_SCHOOL;
    } else if (whichDropDown == "taxonomy") {
      SelectedData = School_Action_Types.SELECTED_TEST_TAXONOMY_DROPDOWN_SCHOOL;
    } else {
      SelectedData = SELECTED_TEST_ASSESSED_DROPDOWN_IN_SCHOOL;
    }
  } else {
    if (whichDropDown == "grade") {
      SelectedData = SELECTED_TEST_GRADE_DROPDOWN_STUDENT;
    } else if (whichDropDown == "assessment") {
      SelectedData =
        Student_ReportActionTypes.SELECTED_TEST_ASSESSED_DROPDOWN_STUDENT;
    } else {
      SelectedData =
        Student_ReportActionTypes.SELECTED_TEST_TAXONOMY_DROPDOWN_STUDENT;
    }
  }

  return (dispatch) => {
    dispatch({
      type: SelectedData,
      payload: filterSelectedData,
    });
  };
};

export const getGradeListOfClass = (AccessToken, ReqPayload) => {
  let URL = Base_URL + ClassTestGradeListUrl;

  return (dispatch, getState) => {
    dispatch({
      type: Report_Action_Types.LOADER_ON_TEST_GRADE_LIST_CLASS,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        timeout: 0,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData =
          PayloadData == null || PayloadData == undefined ? [] : PayloadData;

        let changesFrom = "class";
        let { LastActiveUniversalProps } = getState();
        let PreviousRepo_Nav = LastActiveUniversalProps.NaviGation;
        let CurrentNav = getState().Universal.NavigationByHeaderSelection;

        let ActiveStrandGrade = Strands_Grade_ToPersist(
          PreviousRepo_Nav,
          getState
        );
        let { persitedTestAssessGrade } = getState().SummaryReports;
        dispatch({
          type: TEST_GRADE_LIST_OF_CLASS_SUCCESS,
          payload: {
            PayloadData,
            PreviousRepo_Nav,
            CurrentNav,
            ActiveStrandGrade,
            LastActiveUniversalProps,
            persitedTestAssessGrade
          },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const getTestAssessmentMaxCountOfClass = (AccessToken, ReqPayload) => {
  let URL = Base_URL + ClassTestAssessmentUrl;

  return (dispatch, getState) => {
    dispatch({
      type: TEST_ASSESSMENT_MAX_COUNT_CLASS,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        timeout: 0,
      })
      .then(function (response) {
        let PayloadData = response.data.value;

        let LastActiveNav = getState().LastActiveUniversalProps.NaviGation;

        let QuestionToPersist;
        if (!LastActiveNav.class) {
          QuestionToPersist = GetAssessed_Ques_ToPersist(
            LastActiveNav,
            getState
          );
        }

        dispatch({
          type: TEST_ASSESSMENT_MAX_COUNT_CLASS_SUCCESS,
          payload: { PayloadData, QuestionToPersist },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
export const Get_class_grouping_CSV_download = () => {
  return (dispatch) => {
    dispatch({
      type: ClassGroupingTypes.TRIGGER_GROUPING_DOWNLOAD_CSV,
    });
  };
};
export const Reset_class_grouping_CSV_download = () => {
  return (dispatch) => {
    dispatch({
      type: ClassGroupingTypes.RESET_GROUPING_DOWNLOAD_CSV,
    });
  };
};

// School Popup

export const schoolCSV_PopUp_enable = (popUp_status) => {
  return (dispatch, getState) => {
    let SelectedRosterGrade =
      getState().Universal.ContextHeader.Roster_Tab.selectedRosterGrade;
    dispatch({
      type: Report_Action_Types.TRIGGER_SCHOOL_POPUP_DOWNLOAD_CSV,
      payload: { popUp_status, SelectedRosterGrade },
    });
  };
};

export const schoolCSV_popUp_select_school = (
  AccessToken,
  ReqPayload,
  selected_school,
  selectedRosterGrade
) => {
  let URL = Base_URL + RosterTab_Post;

  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.SCHOOL_POPUP_DROPDOWN_SCHOOLS,
      payload: selected_school,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData = PayloadData === null ? null : PayloadData[0].grades;
        let gradeListData = getListOfGradesFromObject(PayloadData);
        dispatch({
          type: Report_Action_Types.SCHOOL_POPUP_DROPDOWN_SCHOOLS_SUCCESS,
          payload: { gradeListData, selectedRosterGrade },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        if (statusCode == 502) {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        }

        dispatch({
          type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
          payload: { statusCode },
        });
      });
  };
};

export const getListOfGradesFromObject = (payloadData) => {
  let gradesList = [];

  if (payloadData != null) {
    payloadData.map((grade) => {
      let gradeobj = {
        grade: grade.grade,
      };
      gradesList.push(gradeobj);
    });
  } else {
    gradesList = null;
  }

  return gradesList;
};
export const schoolCSV_popUp_select_grade = (selected_grade) => {
  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.SCHOOL_POPUP_DROPDOWN_GRADE,
      payload: selected_grade,
    });
  };
};

export const schoolCSV_popUp_apply_download = (AccessToken, ReqPayload) => {
  let URL = Base_URL + SchoolCSVDownload;

  return (dispatch) => {
    dispatch({
      type: Report_Action_Types.SCHOOL_POPUP_APPLY_DOWNLOAD,
      payload: selected_grade,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        timeout: 0,
      })
      .then(function (response) {
        let PayloadData = response.data.value;
        dispatch({
          type: Report_Action_Types.SCHOOL_POPUP_DROPDOWN_SCHOOLS_SUCCESS,
          payload: PayloadData,
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const openCloseDropDownCSVPopup = (whichDropdown, currentStatus) => {
  let actionToTakesPlace;

  if (whichDropdown == "school") {
    actionToTakesPlace =
      Report_Action_Types.OPEN_CLOSE_POPUP_CSV_DOWNLOAD_SCHOOL;
  } else {
    actionToTakesPlace =
      Report_Action_Types.OPEN_CLOSE_POPUP_CSV_DOWNLOAD_GRADE;
  }

  return (dispatch) => {
    dispatch({
      type: actionToTakesPlace,
      payload: !currentStatus,
    });
  };
};

export function ClassStrandsState_OnSTrandsSuccess(state, action) {
  let List_Class_STrands =
    action.payload.Data == null ? [] : action.payload.Data;
  let { LastNav } = action.payload;
  if (List_Class_STrands.length == 0) {
    return {
      ...state,
      StandardPerformance_Overview: {
        ...state.StandardPerformance_Overview,
        StandardPerformanceFilter: {
          ...state.StandardPerformance_Overview.StandardPerformanceFilter,
          NodataInStrands: true,
        },
      },
      ApiCalls_Reports: {
        ...state.ApiCalls_Reports,
        loading_Strands_table: false,
      },
    };
  } else {
    let StandsList = { ...action.payload.Data };
    let StrandTaxonomyList = [];
    let comesfrom_compare =
      state.StandardPerformance_Overview.strandSelectedFromCompare;
    let { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist } =
      action.payload.last_active_Taxonomy_And_StrandDetails;
    StandsList.strands = Sort_ApiResponse_Payload_Array(
      StandsList.strands,
      "strands"
    );

    let SetValues = [];
    StandsList.strands.map((strand) => {
      strand.standards.map((single_standard) => {
        StrandTaxonomyList.push(single_standard.taxonomy);
        SetValues.push({
          setId: single_standard.setId,
          taxonomy: single_standard.taxonomy,
        });
      });
    });
    StrandTaxonomyList = [...new Set(StrandTaxonomyList)];

    StrandTaxonomyList.sort();

    SetValues = multiDimensionalUnique_inClass(SetValues);

    if (
      action.payload.UserPreferences !== null &&
      action.payload.UserPreferences != undefined &&
      action.payload.UserPreferences.standardsetorders.length > 0
    ) {
      StrandTaxonomyList = sortTaxonomyDataBasedOnUserPrefferences(
        action.payload.UserPreferences,
        SetValues
      );
    }

    let TaxonomyExist = last_active_Taxonomy
      ? StrandTaxonomyList.includes(last_active_Taxonomy)
      : StrandTaxonomyList.includes(
          state.StandardPerformance_Overview.selected_Taxonomy_From_Compare
        );

    let Selec_Taxonomyis =
      comesfrom_compare && TaxonomyExist
        ? state.StandardPerformance_Overview.selected_Taxonomy_From_Compare
        : last_active_Taxonomy && TaxonomyExist
        ? last_active_Taxonomy
        : comesfrom_compare && TaxonomyExist
        ? state.StandardPerformance_Overview.selected_Taxonomy_From_Compare
        : StrandTaxonomyList[0];

    if (!StrandTaxonomyList.includes(Selec_Taxonomyis)) {
      Selec_Taxonomyis = StrandTaxonomyList[0];
    }

    // End of Taxonomy Logic Will goes here
    StandsList.strands = Sort_ApiResponse_Payload_Array(
      StandsList.strands,
      "strands"
    );

    let SelectionBasedTaxonomyList = { ...StandsList };

    SelectionBasedTaxonomyList.strands = SelectionBasedTaxonomyList.strands
      .map((strand) => {
        return {
          ...strand,
          standards: [
            ...strand.standards.filter(
              (single_taxonomy_standard) =>
                single_taxonomy_standard.taxonomy == Selec_Taxonomyis
            ),
          ],
        };
      })
      .filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);

    SelectionBasedTaxonomyList = calculateStrandAvgOnTaxonimy_Filter(
      SelectionBasedTaxonomyList
    );

    let SelectedStrand =
      !Disable_AutoSelect_Std_Pref_LeftView &&
      SelectionBasedTaxonomyList.strands !== undefined &&
      SelectionBasedTaxonomyList.strands !== null
        ? SelectionBasedTaxonomyList.strands[0]
        : {
            strandName: LastNav.class
              ? state.StandardPerformance_Overview.StrandNameOfSelectedStandard
              : "",
            strandAvg: LastNav.class
              ? state.StandardPerformance_Overview.selectedStandarAvg
              : "",
            strandId: LastNav.class
              ? state.StandardPerformance_Overview.selectedStandardId
              : "",
          };

    let StrandName = SelectedStrand.strandName;
    let Avarage = SelectedStrand.strandAvg;
    let standardId = "";
    let StandardsObj = {};
    StandardsObj =
      StandardsObj == undefined || StandardsObj == null ? {} : StandardsObj;

    let Strand_Fn_Response = {}; // CheckIs_Selected_Strand_exist_in_the_List_Or_Not(StandsList, state.S_StandardPerformance_Overview.StrandNameOfSelectedStandard, standardId, StandardsObj);
    if (comesfrom_compare && TaxonomyExist) {
      let Strand_List = action.payload.Data == null ? [] : StandsList.strands;

      standardId =
        state.StandardPerformance_Overview.selectedStandard_From_Compare;
      StrandName =
        state.StandardPerformance_Overview.selectedStrand_From_Compare;
      let StandardIdIsNot_Exist = false;
      let STrandIsNotExist = false;

      if (standardId !== "") {
        let selectedstrand = Strand_List.filter(
          (item) => item.strandName == StrandName
        );
        if (selectedstrand[0] !== undefined) {
          StandardsObj = selectedstrand[0].standards.find(function (element) {
            return element.standardId == standardId;
          });
          if (StandardsObj == undefined) {
            StandardIdIsNot_Exist = true;
          } else {
            Avarage = StandardsObj.standardAvg;
          }
        } else {
          STrandIsNotExist = true;
        }
      } else {
        StandardsObj = {};
        Avarage = "";
      }

      /**
       *  start , if strand or standard is not there in payload data
       */

      if (STrandIsNotExist) {
        StrandName = Strand_List[0].strandName;
        StandardsObj = {};
        Avarage = "";
        standardId = "";
      } else if (StandardIdIsNot_Exist) {
        StandardsObj = {};
        Avarage = "";
        standardId = "";
      }

      /**
       *  End , if strand or standard is not there in payload data
       */
    } else {
    }

    SelectionBasedTaxonomyList =
      SelectionBasedTaxonomyList === null ? [] : SelectionBasedTaxonomyList;

    let IndexofCurrentSTrand = SelectionBasedTaxonomyList.strands.findIndex(
      (item) => item.strandName == StrandName
    );
    let HeaderStart = state.StandardPerformance_Overview.headerStart;
    let HeaderEnd = state.StandardPerformance_Overview.headerEnd;
    let Diff = window.screen.width < 1281 ? 4 : 6;

    if (IndexofCurrentSTrand + 1 > HeaderEnd) {
      HeaderEnd = IndexofCurrentSTrand + 1;
      HeaderStart = HeaderEnd - Diff;
    }

    let RightSideApiCall =
      StrandName !== "" && StrandName !== null && StrandName !== undefined;

    return {
      ...state,
      StandardPerformance_Overview: {
        ...state.StandardPerformance_Overview,
        ActualList: SelectionBasedTaxonomyList,
        originalStrandsList:
          action.payload.Data === null ? [] : action.payload.Data,
        // selectedStrandId: SelectedStrand.strandId,
        selectedStandarAvg: Avarage,
        selectedStandardId: standardId,
        StrandNameOfSelectedStandard: StrandName,
        selectedstandardObject: StandardsObj,
        headerStart: HeaderStart,
        headerEnd: HeaderEnd,
        StandardPerformanceFilter: {
          ...state.StandardPerformance_Overview.StandardPerformanceFilter,
          NodataInStrands: false,
          TestGrade: {
            ...state.StandardPerformance_Overview.StandardPerformanceFilter
              .TestGrade,
            gradefor_last_Active_report:
              state.StandardPerformance_Overview.StandardPerformanceFilter
                .TestGrade.selectedTestgrade,
          },
          Taxonomy: {
            ...state.StandardPerformance_Overview.StandardPerformanceFilter
              .Taxonomy,
            selectedTaxonomy: Selec_Taxonomyis,
            TaxonomyList: StrandTaxonomyList,
            OpenCloseTaxonomy: false,
          },
          SetValues: SetValues,
        },

        selectedStrand_From_Compare: "",
        selectedStandard_From_Compare: "",
        selected_Taxonomy_From_Compare: "",
        strandSelectedFromCompare: false,
      },
      ApiCalls_Reports: {
        ...state.ApiCalls_Reports,
        get_students_and_Graph_ofClassStrand: RightSideApiCall, //true,
        loading_Strands_table: false,
      },
    };
  }
}
