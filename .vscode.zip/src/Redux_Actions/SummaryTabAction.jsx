import { SummaryTypes } from '../Reducer_Action_Types/SummaryTabTypes.jsx';


export const SHOW_SUMMARY_POPUP = () => {
    return (dispatch) => {
        dispatch({
            type: SummaryTypes.SHOW_SUMMARY_TAB,
            payLoad: true
        })
    }
}



export const CLOSE_SUMMARY_POPUP = () => {
    return (dispatch) => {
        dispatch({
            type: SummaryTypes.CLOSE_SUMMARY_TAB,
            payLoad: false
        })
    }
}