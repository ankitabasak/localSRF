import { C_ReadingLevelTypes } from "../Reducer_Action_Types/C_ReadingLevelTypes.jsx";
import {
  Class_Reading_Level_Grid_Api,
  ORR_URL,
  Class_Reading_Level_Target_Api,
  Class_Reading_Level_API,
  CSV_DOWNLOAD_CLASS,
  dummyToken
} from "../Utils/globalVars";
import axios from "axios";
import { CHANGE_TERM_ON_RLP_DATA_FAIL, RLP_CHART_API_SUCCESS } from "../Reducer_Action_Types/UniversalSelectorActionTypes.js";

export const READING_LEVEL_GRID_DATA = (AccessToken, data) => {
  let AuthURL = ORR_URL + Class_Reading_Level_Grid_Api;
  return dispatch => {
    axios
      .post(AuthURL, data, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;
        dispatch({
          type: C_ReadingLevelTypes.CLASS_READING_LEVEL_GRID_DATA_SUCCESS,
          payload: Response_Data
        });
      }).catch(error => {
        dispatch({
          type: C_ReadingLevelTypes.CLASS_RLP_GRID_API_FAIL,
          payload: null
        });
      });
  };
};

//function to show icons and sort columns
export const SORT_RLP_GRID_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.C_RLP_GRID_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};
export const RETAIN_BUBBLE_COLOR = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.RETAIN_BUBBLE_COLOR,
      payload: data
    });
  };
};
export const CLEAR_BUBBLE_COLOR = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.CLEAR_BUBBLE_COLOR,
      payload: data
    });
  };
};
export const SIDE_PANEL_SPINNER = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.CLASS_RLP_SPINNER_RESET,
      payload: data
    });
  };
};

export const updateDropDownData = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.UPDATE_DROP_DOWN_DATA,
      payLoad: data
    })
  }
}



export const updateChartDetails = data => {

  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.UPDATE_CHART_DATA,
      payLoad: data
    })
  }
}

export const updateAllMonth = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.UPDATE_ALL_DATA,
      payLoad: data
    })
  }
}

export const toggleDropDown = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.UPDATE_TOGGLE,
      payLoad: data
    })
  }
}


export const CHART_SPINNER = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.CHART_SPINNER_RESET
    });
  };
};
/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SORT_C_RLP_DATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.SAVE_SORTED_RLP_DATA,
      payload: { SortedArray }
    });
  };
};

export const RLP_DONUT_TARGET_DATA = (AccessToken, data) => {
  let AuthURL = ORR_URL + Class_Reading_Level_Target_Api;
  let Payload = { classRLPRtSidePanelFilter: data };
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, data, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;

        dispatch({
          type: C_ReadingLevelTypes.RLP_TARGET_DATA,
          payload: Response_Data
        });
      });
  };
};

export const ACHIEVED_TARGET_DATA = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.ACHIEVED_DATA,
      payload: { data }
    });
  };
};

export const NOT_ACHIEVED_TARGET_DATA = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.NOT_ACHIEVED_DATA,
      payload: { data }
    });
  };
};

export const DEFAULT_TARGET_DATA = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.DEFAULT_DATA,
      payload: { data }
    });
  };
};

export const UPDATE_DONUT_FLAG = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.FLAG_UPDATE,
      payload: { data }
    });
  };
};

export const Update_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.UPDATE_CHART_SCROLL_DATA,
      payload: data
    });
  };
};

export const Summary_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.SUM_CHART_SCROLL_DATA,
      payload: data
    });
  };
};

export const CLASS_READING_LEVEL_PROGRESS = (AccessToken, filterData) => {
  let AuthURL = ORR_URL + Class_Reading_Level_API;

  const filterTypes = [
    "frustrationalRecordData",
    "independentRecordData",
    "instructionalRecordData"
  ];
  if (filterData) {
    return (dispatch, getState) => {
      axios
        .post(AuthURL, filterData, {
          headers: {
            "Access-Control-Allow-Origin": "*",
            responseType: "application/json",
            Authorization: "Bearer ".concat(AccessToken)
          }
        })
        .then(response => {
          let dataFortableRecentRecord = [];
          let dataFortableForFirstRecord = [];
          let recentRecord = {};
          let firstRecord = {};

          if (
            response.data &&
            response.data.responseData.recordDataList.length !== 0
          ) {
            let Response_Data = response.data;
            response.data.responseData.recordDataList.forEach(element => {
              if (element.recentRecord) {
                return (recentRecord = element);
              } else if (element.firstRecord) {
                return (firstRecord = element);
              }
            });

            filterTypes.forEach(filterName => {
              if (
                recentRecord[filterName] &&
                recentRecord[filterName].recordList.length > 0
              ) {
                recentRecord[filterName].recordList.forEach(obj => {
                  let tempName;

                  if (filterName == "frustrationalRecordData") {
                    tempName = "Frustrational";
                  } else if (filterName == "independentRecordData") {
                    tempName = "Independent";
                  } else if (filterName == "instructionalRecordData") {
                    tempName = "Instructional";
                  }
                  dataFortableRecentRecord.push({
                    proficiencyType: tempName,
                    readingLevel: obj.recordLevel
                  });
                });
              } else if (
                firstRecord[filterName] &&
                firstRecord[filterName].recordList.length > 0
              ) {
                firstRecord[filterName].recordList.forEach(obj => {
                  let tempName;
                  if (filterName == "frustrationalRecordData") {
                    tempName = "Frustrational";
                  } else if (filterName == "independentRecordData") {
                    tempName = "Independent";
                  } else if (filterName == "instructionalRecordData") {
                    tempName = "Instructional";
                  }
                  dataFortableForFirstRecord.push({
                    proficiencyType: tempName,
                    readingLevel: obj.recordLevel
                  });
                });
              }
            });


            //async action dispatch

            let dataList = response.data.responseData.recordDataList;
            let firstRecordData = null;
            let recentRecordData = null;
            if (dataList && dataList.length > 0) {
              dataList.forEach(obj => {
                if (obj.firstRecord) {
                  firstRecordData = { [obj.month]: [] };

                  if (
                    obj["frustrationalRecordData"] &&
                    obj["frustrationalRecordData"]["recordList"].length > 0
                  ) {
                    obj["frustrationalRecordData"]["recordList"].forEach(
                      list => {
                        firstRecordData[obj.month].push({
                          type: "Frustrational",
                          readingLevel: list.recordLevel,
                          month: list.month,
                          monthYear: obj.monthYear,
                          recentRecord: false
                        });
                      }
                    );
                  }
                  if (
                    obj["independentRecordData"] &&
                    obj["independentRecordData"]["recordList"].length > 0
                  ) {
                    obj["independentRecordData"]["recordList"].forEach(list => {
                      firstRecordData[obj.month].push({
                        type: "Independent",
                        readingLevel: list.recordLevel,
                        month: list.month,
                        monthYear: obj.monthYear,
                        recentRecord: false
                      });
                    });
                  }
                  if (
                    obj["instructionalRecordData"] &&
                    obj["instructionalRecordData"]["recordList"].length > 0
                  ) {
                    obj["instructionalRecordData"]["recordList"].forEach(
                      list => {
                        firstRecordData[obj.month].push({
                          type: "Instructional",
                          readingLevel: list.recordLevel,
                          month: list.month,
                          monthYear: obj.monthYear,
                          recentRecord: false
                        });
                      }
                    );
                  }
                } else if (obj.recentRecord) {
                  recentRecordData = { [obj.month]: [] };
                  if (
                    obj["frustrationalRecordData"] &&
                    obj["frustrationalRecordData"]["recordList"].length > 0
                  ) {
                    obj["frustrationalRecordData"]["recordList"].forEach(
                      list => {
                        recentRecordData[obj.month].push({
                          type: "Frustrational",
                          readingLevel: list.recordLevel,
                          month: list.month,
                          monthYear: obj.monthYear,
                          recentRecord: true
                        });
                      }
                    );
                  }
                  if (
                    obj["independentRecordData"] &&
                    obj["independentRecordData"]["recordList"].length > 0
                  ) {
                    obj["independentRecordData"]["recordList"].forEach(list => {
                      recentRecordData[obj.month].push({
                        type: "Independent",
                        readingLevel: list.recordLevel,
                        month: list.month,
                        monthYear: obj.monthYear,
                        recentRecord: true
                      });
                    });
                  }
                  if (
                    obj["instructionalRecordData"] &&
                    obj["instructionalRecordData"]["recordList"].length > 0
                  ) {
                    obj["instructionalRecordData"]["recordList"].forEach(
                      list => {
                        recentRecordData[obj.month].push({
                          type: "Instructional",
                          readingLevel: list.recordLevel,
                          month: list.month,
                          monthYear: obj.monthYear,
                          recentRecord: true
                        });
                      }
                    );
                  }
                }
              });
            }
            let selectdBubbles = recentRecordData
              ? recentRecordData
              : firstRecordData;

            let sidePanelList = {};
            let key = Object.keys(selectdBubbles);

            if (selectdBubbles[key[0]] && selectdBubbles[key[0]].length > 0) {
              let listItems = [];
              sidePanelList["monthYear"] =
                selectdBubbles[key[0]][0]["monthYear"];
              selectdBubbles[key[0]].forEach(item => {
                listItems.push({
                  readingLevel: item["readingLevel"],
                  proficiencyType: item["type"]
                });
              });
              sidePanelList["readingLevelList"] = listItems;
            }

            filterData["sidePanelFilter"] = sidePanelList;

            Promise.resolve(
              dispatch({
                type: C_ReadingLevelTypes.CLASS_READING_LEVEL_PROGRESS,
                payload: {
                  responseData: Response_Data["responseData"],
                  selectedBubbles: selectdBubbles
                }
              })
            ).then(() => {
              dispatch({
                type: RLP_CHART_API_SUCCESS,
                payload: {
                  responseData: response.data.responseData,
                }
              })
            });
          } else {
            let { loadedOrrReportsForTerm, NavigationByHeaderSelection } = getState().Universal;
            let ModifiedDateTab = getState().DateTabReducer;
            let { SelectedDistrictTerm, TermsListWithOutUTCFormat } = ModifiedDateTab.DateTabComponents;
            TermsListWithOutUTCFormat = Array.isArray(TermsListWithOutUTCFormat) ? TermsListWithOutUTCFormat : [];
            let currentDistrictIndex = TermsListWithOutUTCFormat.findIndex(item => item.termId == SelectedDistrictTerm.termId)
            if (currentDistrictIndex > -1 && currentDistrictIndex + 1 < TermsListWithOutUTCFormat.length && !loadedOrrReportsForTerm  && NavigationByHeaderSelection.ORR) {
              dispatch(CHANGE_TERM_ON_RLP_DATA_FAIL_METHOD(currentDistrictIndex));
            } else {
              dispatch({
                type: C_ReadingLevelTypes.CLASS_RLP_DATA_FAIL,
                payload: ""
              });

            }
          }
          // let Response_Data = response.data;

          // dispatch({
          //   type: C_ReadingLevelTypes.CLASS_READING_LEVEL_PROGRESS,
          //   payload: Response_Data
          // });
        })
        .catch(error => {
          dispatch({
            type: C_ReadingLevelTypes.CLASS_RLP_DATA_FAIL,
            payload: null
          });
        });
    };
  }
};

export const CLRLP_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: C_ReadingLevelTypes.CLRLP_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const CLRLP_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_CLASS;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: C_ReadingLevelTypes.CLRLP_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: C_ReadingLevelTypes.CLASS_RLP_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

export const CHANGE_TERM_ON_RLP_DATA_FAIL_METHOD = (currentDistrictIndex) => {
  return (dispatch, getState) => {

    let ModifiedDateTabReducer = getState().DateTabReducer;
    let ModifiedUniversalReducer = getState().Universal;
    let { TermsListWithOutUTCFormat } = ModifiedDateTabReducer.DateTabComponents;

    let newTermObj = TermsListWithOutUTCFormat[currentDistrictIndex + 1];
    ModifiedDateTabReducer = {
      ...ModifiedDateTabReducer,
      callApplyDateTab_InDateTab_JS: true,
      DateTabComponents: {
        ...ModifiedDateTabReducer.DateTabComponents,
        SelectedDistrictTerm: newTermObj,
        StartDateInDateTab: newTermObj.termStartDate,
        EndDateInDateTab: newTermObj.termEndDate
      },
      ORR_Context_DateTab: {
        ...ModifiedDateTabReducer.ORR_Context_DateTab,
        SelectedDistrictTerm: newTermObj,
        StartDateInDateTab: newTermObj.termStartDate,
        EndDateInDateTab: newTermObj.termEndDate
      }
    };

    ModifiedUniversalReducer = {
      ...ModifiedUniversalReducer,
      ContextHeader: {
        ...ModifiedUniversalReducer.ContextHeader,
        Date_Tab: {
          ...ModifiedUniversalReducer.ContextHeader.Date_Tab,
          Report_termEndDate: newTermObj.termEndDate,
          Report_termStartDate: newTermObj.termStartDate,
          selectedterm_Obj: newTermObj,
          selectedTermId: newTermObj.termId,
          selected_District_term: newTermObj.termName
        }
      }
    }

    dispatch({
      type: CHANGE_TERM_ON_RLP_DATA_FAIL,
      payload: { ModifiedDateTabReducer, ModifiedUniversalReducer }
    });
  }
}