import { expect } from 'chai';
import * as TSActions from '../Redux_Actions/TestStatus.Actions';
import {GET_TESTSTATUS_SUMMARY_DATA} from '../Reducer_Action_Types/TestStatus.Types';

jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});

let AccessToken = "eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MzI1NTE1OTMsImlzcyI6ImF0bGFudGlzIiwiaWQiOjY3NDQ4MzMuMCwiZmlyc3RfbmFtZSI6IkJyYW5kb24iLCJsYXN0X25hbWUiOiJNY0NveSIsInJlYWxtX2lkIjoxOTQzLjAsImVtYWlsIjoibWNjb3licmFuZG9uQGR1YmxpbnVzZC5vcmciLCJyb2xlcyI6eyJESVNUUklDVF9BRE1JTiI6WzU0ODY0MS4wXX0sImFzc2VtYmx5X2NvZGVzX2hhc2giOiI5N0QxNzBFMTU1MEVFRTRBRkMwQUYwNjVCNzhDREEzMDJBOTc2NzRDIiwicmVhbG0iOiJkdWJsaW4iLCJ1c2VybmFtZSI6Im1jY295YnJhbmRvbkBkdWJsaW51c2Qub3JnIiwiYXBwVHlwZSI6InVua25vd24iLCJzZWNfaGFzaCI6ImI2YjA2NGI1NTgwNzA4MTA3ZGVjZjdiZmI3ZDhlNDY2In0.ESffmYtC0JrG1XDkqEJQR0ymAPfRrLEC0Op9vzdVEic",
ReqPayload = {
    context: "district",
    currentTermId: "5096",
    districtId: 548641,
    endDate: "2021-10-01 23:59:59",
    ids: [548641],
    isPastDistrictTerm: false,
    page: 1,
    rosterGrade: "grade_3",
    startDate: "2019-08-08 00:00:00",
    testStatus: "InProgress"
},
fromContext = "district",
Nav = {
    Assessement: true,
    ORR: false,
    O_R_R: "display_and_not_selected",
    Overview: false,
    S_performance: false,
    Summary_Reports: false,
    Summary_Tab: false,
    T_scores: false,
    class: false,
    comparison: false,
    district: true,
    errorAnalysis: false,
    fluencyAnalysis: false,
    grouping: false,
    open_comparison_modal: false,
    readingBehaviors: false,
    readingHistory: false,
    rlp: true,
    school: false,
    st_analysis: false,
    student: false,
    summary: false,
    test_status: true,
    usageReport: false
},
persistfromsummaryTS = true;

  describe("test status actions", () =>{
    afterEach(() => {
      jest.clearAllMocks();
    });
  it("call test status summary data", ()=>{
    const dispatch = jest.fn();
    TSActions.Get_TestStatusSummaryData(AccessToken,
        ReqPayload,
        fromContext,
        Nav,
        persistfromsummaryTS)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: GET_TESTSTATUS_SUMMARY_DATA, payload: { Nav,
        AccessToken,
        ReqPayload,
        fromContext
    }});
  });
});