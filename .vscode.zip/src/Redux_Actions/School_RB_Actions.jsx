import { School_RB_Types } from "../Reducer_Action_Types/School_RB_Action_Types.jsx";
import {
    School_RB_Chart_API,
    ORR_URL,
    School_RB_SidePanel_API,
    Grade_List,
    CSV_DOWNLOAD_SCHOOL
} from "../Utils/globalVars";
import Axios from "axios";

export const Show_loading_Icon = () => {
    return dispatch => {
        dispatch({
            type: School_RB_Types.API_LOADER,
            payload: {}
        });
    };
};

// chart loading failed
export const Chart_loading_Failed = data => {
    return dispatch => {
        dispatch({ type: School_RB_Types.API_ERROR_HANDLER, payload: data });
    };
};
// chart loading failed
export const updateSelectedItems = data => {
    let cpbSidePanelRequestList = [];

    return dispatch => {
        Promise.resolve(
            dispatch({ type: School_RB_Types.UPDATE_SELECTED_BOXES, payload: data })
        ).then(() => {
            // let recList = setGradeToSelectedLevels(selectedLevels);
            //   dispatch(School_RB_SidePanel_API_Call(token, payload));
        });
    };
};

export const School_RB_Dropdown = (AccessToken, payLoad, cxtGrade) => {
    let AuthURL = ORR_URL + Grade_List;
    let apiPayload = payLoad
    let gradeSel = cxtGrade && cxtGrade.length > 0 && cxtGrade.replace('grade_', '').toLocaleUpperCase();
    return dispatch => {
        Axios
            .post(AuthURL, payLoad, {
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    responseType: "application/json;charset=UTF-8",
                    Authorization: "Bearer ".concat(AccessToken)
                }
            })
            .then(response => {
                let Response = response.data;
                if (response.data.grades.length === 0) {
                    dispatch({
                        type: School_RB_Types.SCL_GRADES_NOT_AVAILABLE,
                        payload: true,
                    })
                } else {
                    let grade = gradeSel ? (response.data.grades.indexOf(gradeSel) > -1 ? gradeSel : Response.grades[0]) : Response.grades[0];
                    apiPayload['externalFilter']['grade'] = grade;
                    let payLoad = apiPayload;
                    Promise.resolve(
                        dispatch({
                            type: School_RB_Types.SCHOOL_RB_DROPDOWN_SUCCESS,
                            payload: Response,
                        })
                    ).then(() =>
                        dispatch(School_RB_Chart_API_Call(AccessToken, payLoad))
                    );
                }
            })
            .catch(function () {
                dispatch({
                    type: School_RB_Types.API_ERROR_HANDLER,
                    payload: {
                        noChartData: false,
                        apiLoadFail: true,
                        isApiLoading: false,
                        timeout: false
                    }
                });
            });
    };
};
//School RB Chart API call
export const School_RB_Chart_API_Call = (AccessToken, payLoad) => {

    let API_URL = ORR_URL + School_RB_Chart_API;
    //let API_URL = ORR_URL + CRB_Chart_API;

    return dispatch => {
        Axios.post(API_URL, payLoad, {
            headers: {
                "Access-Control-Allow-Origin": "*",
                responseType: "application/json",
                Authorization: "Bearer ".concat(AccessToken)
            }
        })
            .then(response => {
                let parsedConfig = JSON.parse(response.config.data);
                let gradeSelected = parsedConfig.externalFilter['grade'];

                if (
                    response.data.responseList &&
                    response.data.responseList.length > 0
                ) {
                    // Merging duplicate rubrics
                    response.data.responseList = mergeDuplicateRubricsData(response.data.responseList)

                    let selectedErrors = {
                        recentRecordCount: [],
                        firstRecordCount: [],
                        allRecordRange: []
                    };
                    let errorList =
                        response.data.responseList[response.data.responseList.length - 1]
                            .resultList;
                    errorList.forEach(item => {
                        if (item["recentRecordCount"]) {
                            selectedErrors["recentRecordCount"].push({
                                criteriaName: item.sourceCriteriaName,
                                rbType: "recentRecordCount",
                                rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                                sourceCriteriaId: item["sourceCriteriaId"],
                                selectedRanges: null
                            });
                        } else if (item["firstRecordCount"]) {
                            selectedErrors["firstRecordCount"].push({
                                criteriaName: item.sourceCriteriaName,
                                rbType: "firstRecordCount",
                                rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                                sourceCriteriaId: item["sourceCriteriaId"],
                                selectedRanges: null
                            });
                        } else {

                            if (item['range0_25']) {
                                selectedErrors["allRecordRange"].push({
                                    criteriaName: item.sourceCriteriaName,
                                    rbType: "allRecordRange",
                                    rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                                    sourceCriteriaId: item["sourceCriteriaId"],
                                    selectedRanges: '0-25'
                                });
                            } else if (item['range26_50']) {
                                selectedErrors["allRecordRange"].push({
                                    criteriaName: item.sourceCriteriaName,
                                    rbType: "allRecordRange",
                                    rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                                    sourceCriteriaId: item["sourceCriteriaId"],
                                    selectedRanges: '26-50'
                                });
                            } else if (item['range51_75']) {
                                selectedErrors["allRecordRange"].push({
                                    criteriaName: item.sourceCriteriaName,
                                    rbType: "allRecordRange",
                                    rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                                    sourceCriteriaId: item["sourceCriteriaId"],
                                    selectedRanges: '51-75'
                                });
                            } else if (item['range76_100']) {
                                selectedErrors["allRecordRange"].push({
                                    criteriaName: item.sourceCriteriaName,
                                    rbType: "allRecordRange",
                                    rubricId: response.data.responseList[response.data.responseList.length - 1]["sourceRubricId"],
                                    sourceCriteriaId: item["sourceCriteriaId"],
                                    selectedRanges: '76-100'
                                });
                            }
                        }
                    });
                    // selectedBoxes
                    let selectedBoxes = {};

                    if (
                        selectedErrors["recentRecordCount"] &&
                        selectedErrors["recentRecordCount"].length > 0
                    ) {
                        selectedBoxes["recentRecordCount"] =
                            selectedErrors["recentRecordCount"];
                    } else if (
                        selectedErrors["firstRecordCount"] &&
                        selectedErrors["firstRecordCount"].length > 0
                    ) {
                        selectedBoxes["firstRecordCount"] =
                            selectedErrors["firstRecordCount"];
                    } else if (selectedErrors["allRecordRange"] &&
                        selectedErrors["allRecordRange"].length > 0) {
                        selectedBoxes["allRecordRange"] =
                            selectedErrors["allRecordRange"];
                    }

                    dispatch({
                        type: School_RB_Types.SCHOOL_RB_CHART_API_SUCCESS,
                        payload: {
                            responseData: response.data.responseList,
                            selectedBoxes: selectedBoxes,
                            selectedGrade: gradeSelected
                        }
                    });
                } else {
                    dispatch({
                        type: School_RB_Types.API_ERROR_HANDLER,
                        payload: {
                            noChartData: true,
                            apiLoadFail: false,
                            isApiLoading: false,
                            timeout: false
                        }
                    });
                }

            })
            .catch(function (error) {
                if (error.response) {
                    if (error.response.data.errorCode === 407) {
                        dispatch({
                            type: School_RB_Types.SC_RB_RUBRIC_FAIL,
                            payload: error.response.data.errorMessage
                        });
                    } else {
                        dispatch({
                            type: School_RB_Types.API_ERROR_HANDLER,
                            payload: {
                                noChartData: false,
                                apiLoadFail: true,
                                isApiLoading: false,
                                timeout: false
                            }
                        });
                    }
                } else {
                    dispatch({
                        type: School_RB_Types.API_ERROR_HANDLER,
                        payload: {
                            noChartData: false,
                            apiLoadFail: true,
                            isApiLoading: false,
                            timeout: false
                        }
                    });
                }


            });
    };

    // update chart scroll update
};

export const School_RB_SidePanel_API_Call = (AccessToken, payLoad) => {

    let API_URL = ORR_URL + School_RB_SidePanel_API;

    return dispatch => {
        Axios.post(API_URL, payLoad, {
            headers: {
                "Access-Control-Allow-Origin": "*",
                responseType: "application/json",
                Authorization: "Bearer ".concat(AccessToken)
            }
        })
            .then(response => {
                dispatch({
                    type: School_RB_Types.SCHOOL_RB_SIDEPANEL_API_SUCCESS,
                    payload: response.data
                });
            })
            .catch(function (error) {
                dispatch({
                    type: School_RB_Types.SCHOOL_RB_SIDEPANEL_API_FAILURE
                });
            });
    };
};

// table sort
export const SAVE_SORTED_GRID_DATA = SortedArray => {
    return dispatch => {
        dispatch({
            type: School_RB_Types.SAVE_SORTED_GRID_DATA,
            payload: { SortedArray }
        });
    };
};

// Update accordion state
export const Update_Accordion_State = (state, index) => {
    let updatedState = state;
    updatedState[index] = !updatedState[index];
    return dispatch => {
        dispatch({ type: School_RB_Types.UPDATE_ACCORDION_STATE, payload: updatedState });
    };
};

// Update accordion state
export const Update_Chart_Accordion_State = (state, index) => {
    let updatedState = state;
    updatedState[index] = !updatedState[index];
    return dispatch => {
        dispatch({ type: School_RB_Types.UPDATE_CHART_ACCORDION_STATE, payload: updatedState });
    };
};

//function to show icons and sort columns
export const SCHOOL_RB_SORT_COLUMN = (sortColumn, sortType) => {
    return dispatch => {
        dispatch({
            type: School_RB_Types.SCHOOL_RB_SORT_COLUMN,
            payload: { sortColumn, sortType }
        });
    };
};


function mergeDuplicateRubricsData(data) {
    const resultArray = []
    let mergeItems = []
    data.forEach((obj) => {
        mergeItems = [];
        if (rubricNotProccessed(resultArray, obj)) {
            let duplicateItems = data.filter((item) => {
                return obj.sourceRubricName == item.sourceRubricName;
            })

            if (duplicateItems.length > 1) {
                let tempObj = duplicateItems[0];
                duplicateItems.forEach((subItems) => {
                    mergeItems = [...mergeItems, ...subItems['resultList']]
                })
                tempObj['resultList'] = getUnique(mergeItems, 'sourceCriteriaName');
                resultArray.push(tempObj)
            } else {
                resultArray.push(duplicateItems[0])
            }
        }
    })
    return resultArray;
}
function rubricNotProccessed(dataList, item) {
    let rubricNotFound = true;
    if (dataList.length > 0) {
        dataList.forEach((obj) => {
            if (obj.sourceRubricName == item.sourceRubricName) {
                rubricNotFound = false;

            }
        })
    }
    return rubricNotFound;
}
function getUnique(arr, comp) {

    const unique = arr
        .map(e => e[comp])

        // store the keys of the unique objects
        .map((e, i, final) => final.indexOf(e) === i && i)

        // eliminate the dead keys & store unique objects
        .filter(e => arr[e]).map(e => arr[e]);

    return unique;
}

export const SRB_CSVDATA_DOWNLOAD_RESET = data => {
    return dispatch => {
        dispatch({
            type: School_RB_Types.SRB_CSVDATA_DOWNLOAD_RESET,
            payLoad: data['payLoad']
        });
    };
}

export const SRB_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
    let AuthURL = ORR_URL + CSV_DOWNLOAD_SCHOOL;

    return dispatch => {
        Axios
            .post(AuthURL, apiPayload, {
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    responseType: 'application/json;charset=UTF-8',
                    Authorization: 'Bearer '.concat(AccessToken)
                }
            })
            .then(function (response) {
                let Response = response.data;

                dispatch({
                    type: School_RB_Types.SRB_CSVDATA_DOWNLOAD_SUCCESS,
                    payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
                });
            })
            .catch(function (error) {
                let statusCode =
                    error.response == undefined ? 401 : error.response.status;
                dispatch({
                    type: School_RB_Types.API_ERROR_HANDLER,
                    payload: {
                        noChartData: false,
                        apiLoadFail: true,
                        isApiLoading: false,
                        timeout: false
                    }
                });
            });
    };
};