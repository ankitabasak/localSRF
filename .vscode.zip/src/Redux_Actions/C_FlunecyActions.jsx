import { C_FluencyTypes } from "../Reducer_Action_Types/C_FluencyTypes.jsx";
import {
  Class_Fluency_Grid_Api,
  Class_Fluency_Chart_Api,
  ORR_URL,
  CSV_DOWNLOAD_CLASS,
  Class_Fluency_Progress_API,
  Class_Fluency_Progress_Grid_API
} from "../Utils/globalVars";
import axios from "axios";
/**
 *
 * @param selectedTab
 * action triggers on any tab selection in the Fluency tab.
 */

//  for cpo box higlight
export const Selected_Errors = selectedErrors => {
  let type = C_FluencyTypes;

  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CPOT_SELECTED_ERRORS,
      payload: selectedErrors
    });
  };
};
export const SelectFluencyTab = selectedTab => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.TAB_SELECTED,
      payload: selectedTab
    });
  };
};

export const SIDE_PANEL_API_LOADER = state => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.SIDE_PANEL_API_LOADER,
      payload: state
    });
  };
};
export const Fluency_Chart_Table_API = (AccessToken, data) => {
  let AuthURL = ORR_URL + Class_Fluency_Grid_Api;
  let Payload;
  if (data) {
    Payload = data;
    return dispatch => {
      axios
        .post(AuthURL, Payload, {
          headers: {
            "Access-Control-Allow-Origin": "*",
            responseType: "application/json",
            Authorization: "Bearer ".concat(AccessToken)
          }
        })
        .then(response => {
          let Response_Data = response.data;
          let recentRecord = false;
          let firstRecord = false;

          if (Response_Data.cfaGridResponse && Response_Data.cfaGridResponse.cfaGridStudentList.length > 0) {
            // to find out the firt/recent Record
            if (Payload.gridFilter && Payload.gridFilter.length > 0) {
              recentRecord = Payload.gridFilter[0].recentRecord;
              firstRecord = Payload.gridFilter[0].firstRecord;
            }
            Promise.resolve(
              dispatch({
                type: C_FluencyTypes.FLUENCY_GRID_DATA,
                payload: {
                  ...Response_Data,
                  recentRecord: recentRecord,
                  firstRecord: firstRecord,
                  gridData: Payload.gridFilter
                }
              })
            ).then(() =>
              dispatch(
                SIDE_PANEL_API_LOADER({ apiLoading: false, apiError: false, hideCreateGroup: false })
              )
            );
          } else {
            dispatch(
              SIDE_PANEL_API_LOADER({ apiLoading: false, apiError: true })
            );
          }
        })
        .catch(function (error) {
          dispatch(
            SIDE_PANEL_API_LOADER({ apiLoading: false, apiError: true })
          );
        });
    };
  }
  // Class fluency chart api call
};

export const Fluency_Chart_Api_Request = (AccessToken, data) => {
  let AuthURL = ORR_URL + Class_Fluency_Chart_Api;

  let payload = data;

  if (payload) {
    return dispatch => {
      dispatch({
        type: C_FluencyTypes.CFA_LOADER
      })
      axios
        .post(AuthURL, payload, {
          headers: {
            "Access-Control-Allow-Origin": "*",
            responseType: "application/json",
            Authorization: "Bearer ".concat(AccessToken)
          }
        })
        .then(function (response) {

          if (
            response.data &&
            response.data.responseData.readingLevelAxis.length > 0 &&
            response.data.responseData.recordDataList !== null
          ) {
            let Response_Data = response.data;
            let recentBubbles =
              response.data.responseData.recordDataList[
              response.data.responseData.recordDataList.length - 1
              ];
            let gridFilter = [];
            let gdFilterForGrid = [];
            recentBubbles.wcpmList.forEach(element => {
              gdFilterForGrid.push({
                "fluencyFrom": element.fluencyFrom,
                "fluencyTo": element.fluencyTo,
                "readingLevel": element.readingLevel,
                "wcpmRange": element.wcpmRange,
                firstRecord: recentBubbles.firstRecord,
                recentRecord: recentBubbles.recentRecord
              })
              gridFilter.push({
                monthName: element.monthName,
                monthYear: element.monthYear,
                readingLevel: element.readingLevel,
                value: element.value,
                wcpmRange: element.wcpmRange,
                fluencyFrom: element.fluencyFrom,
                fluencyTo: element.fluencyTo,
                firstRecord: recentBubbles.firstRecord,
                recentRecord: recentBubbles.recentRecord
              });
            });

            Response_Data["recentMonthBubbles"] = {
              [gridFilter[0].monthName]: gridFilter
            };

            let monthYear = gridFilter[0].monthName + ' ' + gridFilter[0].monthYear.substr(0, 4);
            payload["gridFilter"] = gdFilterForGrid;
            payload["month_YYYY"] = monthYear;
            payload["date_YYYY_MM"] = gridFilter[0].monthYear;
            //async action dispatch
            Promise.resolve(
              dispatch({
                type: C_FluencyTypes.CF_CHART_DATA_SUCCESS,
                payload: Response_Data,
                value: data.value
              })
            );
          } else {
            dispatch({
              type: C_FluencyTypes.CF_CHART_DATA_FAILURE,
              payload: { noData: true }
            });
          }
        })
        .catch(function (error) {
          dispatch({
            type: C_FluencyTypes.CF_CHART_DATA_FAILURE,
            payload: { apiFail: true }
          });
        });
    };
  }
};

export const Update_Scroll_Data = data => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.UPDATE_CHART_SCROLL_DATA,
      payload: data
    });
  };
};
//function to show icons and sort columns
export const SORT_FLUENCY_GRID_COLUMN = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.C_FLUENCY_GRID_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SORT_C_FLUENCY_DATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.SAVE_SORTED_FLUENCY_DATA,
      payload: { SortedArray }
    });
  };
};
export const UPDATE_ALL_RECORDS_TYPE = value => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.UPDATE_ALL_RECORDS_TYPE,
      payload: value
    });
  };
};
export const API_LOADER = status => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.API_LOADER,
      payload: { status: status }
    });
  };
};

export const UPDATE_SELECTED_BOXES = status => {
  let monthName = "default";
  if (status[0]) {
    monthName = status[0].monthName;
  }

  return dispatch => {
    dispatch({
      type: C_FluencyTypes.UPDATE_SELECTED_BOXES,
      payload: { [monthName]: status }
    });
  };
};

export const CLASS_FPO_SIDEPANEL_SPINNER = obj => {
  if (obj.showSpinner) {
    return dispatch => {
      dispatch({
        type: C_FluencyTypes.CLASS_FPO_SIDEPANEL_SPINNER
      });
    };
  }
};
export const CLASS_FPO_API = (AccessToken, payLoadData) => {

  let AuthURL = ORR_URL + Class_Fluency_Progress_API;

  let Payload = payLoadData;
  let acessToken = AccessToken;
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFPOT_LOADER
    })
    axios
      .post(AuthURL, Payload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response_Data = response.data;

        let SelectedErr = {};
        let recordType = "";

        if (Response_Data.firstRecord['phrasing'] || (Response_Data.allRecordsAverage || Response_Data.recentRecord)) {
          if (Response_Data.dataRecordType["recentRecord"]) {
            let errList = [];
            Object.keys(Response_Data["recentRecord"]).forEach(key => {
              if (!Response_Data.recentRecord["recentRecordNull"] && Response_Data["recentRecord"][key]) {
                Response_Data["recentRecord"][key].forEach(obj => {
                  if (obj.value > 0) {
                    errList.push({
                      criteriaId: obj.criteriaId,
                      errorName: key,
                      recordType: "recentRecord",
                      rubrixScore: obj.score
                    });
                  }
                });
              }
            });
            if (errList.length > 0) {
              SelectedErr["recentRecord"] = errList;
              recordType = "recentRecord";
            }
          }
          // for all records type
          if (Response_Data.dataRecordType["allRecords"]) {
            let errList = [];
            Object.keys(Response_Data["allRecordsAverage"]).forEach(key => {
              if (!Response_Data.allRecordsAverage["recentRecordNull"] && Response_Data["allRecordsAverage"][key] && key != 'recentRecordNull') {
                Response_Data["allRecordsAverage"][key].forEach(obj => {
                  if (obj.value > 0) {
                    errList.push({
                      criteriaId: obj.criteriaId,
                      errorName: key,
                      recordType: "allRecordsAverage",
                      rubrixScore: obj.score
                    });
                  }
                });
              }
            });
            if (errList.length > 0) {
              SelectedErr["allRecordsAverage"] = errList;
              recordType = "allRecordsAverage";
            }
          }

          // if no error list in recent or allRecords , update it from first record
          if (!SelectedErr["allRecordsAverage"] && !SelectedErr["recentRecord"]) {

            let errList = [];
            Object.keys(Response_Data["firstRecord"]).forEach(key => {
              if (key != "recentRecordNull" && Response_Data["firstRecord"][key]) {
                Response_Data["firstRecord"][key].forEach(obj => {
                  if (obj.value > 0) {
                    errList.push({
                      criteriaId: obj.criteriaId,
                      errorName: key,
                      recordType: "firstRecord",
                      rubrixScore: obj.score
                    });
                  }
                });
              }
            });
            if (errList.length > 0) {
              SelectedErr["firstRecord"] = errList;
              recordType = "firstRecord";
            }

          }

          // fetch initial students data from the existing, constructing list as per API requirement
          if (SelectedErr[recordType]) {
            let criteriaRangesLists = [];
            SelectedErr[recordType].forEach(obj => {
              criteriaRangesLists.push({
                criteriaId: obj.criteriaId,
                score: obj.rubrixScore
              });
            });
            Payload["listItems"] = criteriaRangesLists;
            Payload["recordType"] = recordType;
          }

          Promise.resolve(
            dispatch({
              type: C_FluencyTypes.C_FPO_API_SUCCESS,
              payload: Response_Data,
              value: payLoadData.value,
              errorList: SelectedErr
            })
          );
        } else {
          dispatch(API_LOADER({
            isApiLoading: false,
            apiLoadFail: false,
            apiTimeOut: false,
            noChartData: true
          }))
        }

      })
      .catch((error) => {
        if (error.response) {
          if (error.response.data.errorCode === 407) {
            dispatch({
              type: C_FluencyTypes.C_FLUENCY_RUBRIC_FAIL,
              payload: error.response.data.errorMessage
            });
          } else {
            dispatch(API_LOADER({
              isApiLoading: false,
              apiLoadFail: false,
              apiTimeOut: false,
              noChartData: true
            }))
          }
        } else {
          dispatch(API_LOADER({
            isApiLoading: false,
            apiLoadFail: false,
            apiTimeOut: false,
            noChartData: true
          }))
        }

      });
  };
};

export const C_FPO_Grid_Api = (AccessToken, payLoadData) => {
  let AuthURL = ORR_URL + Class_Fluency_Progress_Grid_API;

  // let Payload = payLoadData;
  let selectedCriteriaRanges = {
    allRecordsAverage:
      payLoadData["recordType"] == "allRecordsAverage" ? true : false,
    criteriaRangesLists: payLoadData["listItems"],
    firstRecord: payLoadData["recordType"] == "firstRecord" ? true : false,
    recentRecord: payLoadData["recordType"] == "recentRecord" ? true : false
  };

  payLoadData["selectedCriteriaRanges"] = selectedCriteriaRanges;

  return dispatch => {
    axios
      .post(AuthURL, payLoadData, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;

        dispatch({
          type: C_FluencyTypes.C_FPO_GRID_API_SUCCESS,
          payload: Response_Data,
          value: payLoadData.value
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: C_FluencyTypes.CLASS_FPO_SIDEPANEL_API_FAIL
        });
      });
  };
};

//function to show icons and sort columns
export const SORT_CFPO_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CLASS_FPO_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

export const SAVE_SORTED_CFPO = SortedArray => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFPO_SORTED_DATA,
      payload: { SortedArray }
    });
  };
};

export const updateDropDownData = data => {

  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFA_UPDATE_DROP_DOWN_DATA,
      payLoad: data
    })
  }
}



export const updateChartDetails = data => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFA_UPDATE_CHART_DATA,
      payLoad: data
    })
  }
}

export const updateAllMonth = data => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFA_UPDATE_ALL_DATA,
      payLoad: data
    })
  }
}

export const toggleDropDown = data => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFA_UPDATE_TOGGLE,
      payLoad: data
    })
  }
}

export const CFA_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFA_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const CFA_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_CLASS;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: C_FluencyTypes.CFA_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        dispatch({
          type: C_FluencyTypes.CF_CHART_DATA_FAILURE,
          payload: { noData: true }
        });
      });
  };
};

export const CFR_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CFR_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const CFR_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_CLASS;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: C_FluencyTypes.CFR_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        dispatch(API_LOADER({
          isApiLoading: false,
          apiLoadFail: false,
          apiTimeOut: false,
          noChartData: true
        }))
      });
  };
};



//tabs for class FA
export const UpDateFluencySubTab = tabSelected => {
  return dispatch => {
    dispatch({
      type: C_FluencyTypes.CLASS_FA_TABS,
      payload: tabSelected
    });
  };
};