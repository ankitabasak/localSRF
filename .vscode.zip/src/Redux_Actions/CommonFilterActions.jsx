export const showPopUpFnt = flagStatus => {
  return {
    type: 'summaryFlagStatus',
    payload: flagStatus

  };
}

export const selRadio = data => {
  return {
    type: 'update_filter',
    payLoad: data[data.key],
    key: data.key
  }
}

export const SAVE_SELECTED_FILTER =data =>{
  return {
    type:'save_selected_filter',
    payLoad : data
  }
}


export const RESET_FILTER =data =>{
  return {
    type:'reset_filter',
    payLoad : data
  }
}