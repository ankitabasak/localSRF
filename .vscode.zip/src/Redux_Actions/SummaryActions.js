import axios from "axios";

import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  GET_SUMMARY_REPORTS,
  SET_GET_SUMMARY_REPORTS,
  GET_SUMMARY_REPORTS_SUCCESS,
  RIGHT_OR_LEFT_NAVIGATION_IN_SUMMARY,
  COMPARE_CHECKBOXES_IN_SUMMARY,
  TAXONOMY_DROPDOWN_ACTION_IN_SUMMARY,
  TAXONOMY_SELECTED_IN_SUMMARY,
  SELECTED_STANDARD_IN_SUMMARY_REPORTS,
  SORT_SUMMARY_REPORT,
  GET_SUMMARY_REPORTS_FAIL,
} from "../Reducer_Action_Types/SummaryActionsTypes";
import {
  Base_URL,
  StudentSummary,
  ClassSummary,
  SchoolSummary,
  DistrictSummary,
  api_request_headers,
} from "../Utils/globalVars";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  setStudentIdsWhenMultiSelectionsInSADA,
  retriggerAPI,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog } from "./AuthenticationAction";
import { SelectedStrandSummaryReports_service } from "../services/universalSelector/universalSelector_2";
import { SetPreviousReport_Props } from "../services/universalSelector/universalSelector_3";

export const GetSummarayData = (AccessToken, ReqPayload, Nav) => {
  let URL = Base_URL;
  URL += Nav.student
    ? StudentSummary
    : Nav.class
    ? ClassSummary
    : Nav.school
    ? SchoolSummary
    : DistrictSummary;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: GET_SUMMARY_REPORTS,
      payload: {
        Nav,
        AccessToken,
        ReqPayload,
      },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;
        ResPayload =
          ResPayload == null || ResPayload == undefined ? {} : ResPayload;
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        let sp_persistance = getRequiredDataFromPersist(
          "sp_persistance",
          getState()
        );
        let UserPreferences = getState().Universal.UserPreferences;

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
            Nav,
            ResPayload,
            persist_compare_checkboxes,
            sp_persistance,
            UserPreferences,
        };
        let action = {
          payload,
        };
        let updatedLastActivePropsState = LastActiveUniversalProps, 
        updatedUniversalState = Universal;

        if (action.payload.ResPayload.summaryList == null) {
            // will not update any state prop. will return same state
        } else {
    
            // let RosterData = Universal.ContextHeader.Roster_Tab;
            let fromContext = action.payload.Nav.student ? 'student' : action.payload.Nav.class ?
                'class' : action.payload.Nav.school ? 'school' : 'district';

                action = {
                    ...action,
                    payload:{
                        ...action.payload,
                        fromContext: fromContext
                    },
                  };
            let responseStates =
        SetPreviousReport_Props(
            JSON.parse(JSON.stringify( Universal)),
            action,
           JSON.parse(JSON.stringify( LastActiveUniversalProps))
          );

          updatedLastActivePropsState= responseStates.updatedLastActivePropsState;
           updatedUniversalState = responseStates.updatedUniversalState;
    
        }

        


        
        dispatch({
          type: GET_SUMMARY_REPORTS_SUCCESS,
          payload: {
            Nav,
            ResPayload,
            persist_compare_checkboxes,
            sp_persistance,
            UserPreferences,
            updatedLastActivePropsState, updatedUniversalState
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));

        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        let retries = getState().Authentication.retryApis;
        let seconds_End = new Date().getTime() / 1000;
        let diffTime = seconds_End - seconds_Start;
        let isAPIRetry = retriggerAPI(diffTime, retries, statusCode);
        if (isAPIRetry) {
          dispatch({
            type: SET_GET_SUMMARY_REPORTS,
            payload: {
              Nav,
            },
          });
        } else {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });

          dispatch({
            type: GET_SUMMARY_REPORTS_FAIL,
            payload: {
              Nav,
            },
          });
        }
      });
  };
};
export const NavagationInSummaryReports = (Nav, Direction) => {
  return (dispatch) => {
    dispatch({
      type: RIGHT_OR_LEFT_NAVIGATION_IN_SUMMARY,
      payload: {
        Nav,
        Direction,
      },
    });
  };
};

export const CompareCheckBoxInSummary = (Nav, fromCheckBox) => {
  return (dispatch) => {
    dispatch({
      type: COMPARE_CHECKBOXES_IN_SUMMARY,
      payload: {
        Nav,
        fromCheckBox,
      },
    });
  };
};
export const TaxonomyDropDown_Action_SummaryReports = (Nav) => {
  return (dispatch) => {
    dispatch({
      type: TAXONOMY_DROPDOWN_ACTION_IN_SUMMARY,
      payload: {
        Nav,
      },
    });
  };
};

export const ChangeTaxonomyIn_SummarayPage = (selected, Nav) => {
  return (dispatch) => {
    dispatch({
      type: TAXONOMY_SELECTED_IN_SUMMARY,
      payload: {
        selected,
        Nav,
      },
    });
  };
};

export const ClickOn_Items__In_Summary = (
  standardData,
  Nav,
  SameReports,
  selectedItem,
  ActiveGrade,
  OnStrands_Click
) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState();

    let payload = {
      standardData,
      Nav,
      SameReports,
      selectedItem,
      ActiveGrade,
      OnStrands_Click,
    };
    let action = {
      payload,
    };

    let { updatedLastActivePropsState, updatedUniversalState } =
      SelectedStrandSummaryReports_service(
        action,
        Universal,
        LastActiveUniversalProps
      );

    dispatch({
      type: SELECTED_STANDARD_IN_SUMMARY_REPORTS,
      payload: {
        standardData,
        Nav,
        SameReports,
        selectedItem,
        ActiveGrade,
        OnStrands_Click,
        updatedLastActivePropsState,
        updatedUniversalState,
      },
    });
  };
};
export const SortSummary_List = (SortOn, sortType, Nav, standard) => {
  standard = standard == undefined ? {} : standard;
  return (dispatch) => {
    dispatch({
      type: SORT_SUMMARY_REPORT,
      payload: {
        sortType,
        SortOn,
        Nav,
        standard,
      },
    });
  };
};
