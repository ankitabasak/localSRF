import { TestStatusPrintTypes } from "../Reducer_Action_Types/TestStatusPrintTypes";
import axios from "axios";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { U_S_Action_Types } from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import { Return_ERROR_Status_Code } from "../Components/ReusableComponents/AllReusableFunctions";
import { Get_TestStatus_Pdf_school, Get_TestStatus_Pdf_class, Get_TestStatus_Pdf_district, Base_URL, api_request_headers } from "../Utils/globalVars";
import { postErrorLog } from "./AuthenticationAction";

export const openPopUpInTestStatusPrint = (selectedContext,sortingDataPDF,StatusDetails)=>{
    return (dispatch) => {
        dispatch({
            type: TestStatusPrintTypes.TEST_STATUS_PRINT_POPUP_STATUS,
            payload: {
                selectedContext,sortingDataPDF,StatusDetails
            }
        })
    }
}

export const handleCancelTestStatus = (selectedContext) => {
    return (dispatch) => {
        dispatch({
            type:TestStatusPrintTypes.TEST_STATUS_PRINT_CANCEL,
            payload:{
                selectedContext
            }
        })
    }
}

export const handleClickOnStatusCode = (selectedContext,selectedStatus,currentStatus) => {
    let updatedStatus = !currentStatus

    return (dispatch) => {
        dispatch({
            type:TestStatusPrintTypes.TEST_STATUS_PRINT_STATUS_CHANGE,
            payload:{
                selectedContext,
                selectedStatus,
                updatedStatus
            }
        })
    }
}
export const handleClickOnReportLevelCode = (selectedContext,selectedStatus) => {
    return (dispatch) => {
        dispatch({
            type:TestStatusPrintTypes.TEST_STATUS_PRINT_REPORT_CHANGE,
            payload:{
                selectedContext,
                selectedStatus
            }
        })
    }
}

export const handleApplyFilterInTestStatus = (selectedContext,ReqPayload,AccessToken) => {

    let URL = Base_URL;

    if (selectedContext == "class") {
        URL = URL + Get_TestStatus_Pdf_class
    } else if (selectedContext == "school") {
        URL = URL + Get_TestStatus_Pdf_school
    }else if (selectedContext == "district") {
        URL = URL + Get_TestStatus_Pdf_district
    }

    return (dispatch) => {
        dispatch({
            type:TestStatusPrintTypes.TEST_STATUS_PRINT_API,
            payload:{
                selectedContext
            }
        })
        
        let seconds_Start = new Date().getTime() / 1000;
        api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
        axios.post(URL, ReqPayload, {
            headers: api_request_headers,
        }).then(function (response) {
            let payloadData = response.data.value;
            dispatch({
                type: TestStatusPrintTypes.TEST_STATUS_PRINT_API_SUCCESS,
                payload: { selectedContext, payloadData }
            })
        }).catch(function (error) {
            dispatch(postErrorLog(AccessToken,error,seconds_Start))
            let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

            dispatch({
                type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
                payload: { statusCode }
            })

            dispatch({
                type: U_S_Action_Types.GET_ROSTERTAB_COMPLETE_DATA_FAIL,
                payload: error.response
            })
        });
          
    }
}

export const handleStudentFilterInTestStatus = (mainData) => {
    return (dispatch) => {
        dispatch({
            type:TestStatusPrintTypes.TEST_STATUS_PRINT_STUDENT_ACTION,
            payload:{
                mainData
            }
        })
    }
}

export const ApplyFilterActionTestStatus = (selectedContext) => {
    return (dispatch) => {
        dispatch({
            type:TestStatusPrintTypes.TEST_STATUS_PRINT_APPLY_FILTER,
            payload:{
                selectedContext
            }
        })
    }
}
export const resetTestStatusTriggerPDF = (selectedContext) => {
    return (dispatch) => {
        dispatch({
            type: TestStatusPrintTypes.PRINT_RESET_PDF_TRIGGER,
            payload:{
                selectedContext
            }
        })
    }
}