import { DistrictFAType } from "../Reducer_Action_Types/District_FA_Types.jsx";
import {
  District_FA_Chart_API,
  District_FA_SidePanel_API,
  ORR_URL,
  CSV_DOWNLOAD_DISTRICT
} from "../Utils/globalVars";
import axios from "axios";

/**
 *
 * @param {object }
 */
export const DISTRICT_FA_CHART_API_CALL = (AccessToken, ChartPayload) => {
  let AuthURL = ORR_URL + District_FA_Chart_API;

  let payLoad = ChartPayload;

  return dispatch => {
    axios
      .post(AuthURL, payLoad, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;
        if (Response['recordDataList'] && Response['recordDataList'].length > 0) {
          dispatch({
            type: DistrictFAType.DISTRICT_FA_CHART_API_CALL_SUCCESS,
            payload: Response
          })
        } else {
          dispatch({
            type: DistrictFAType.DISTRICT_FA_CHART_API_FAIL,
            payload: {
              apiLoadFail: false,
              noData: true,
              SFA_Chart_API_Response: null,
              SFA_Chart_Constructed_Data: null,
              SFA_SidePanelData: null
            }
          });
        }

      })
      .catch(error => {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: DistrictFAType.DISTRICT_FA_CHART_API_FAIL,
          payload: {
            apiLoadFail: true,
            noData: false,
            SFA_Chart_API_Response: null,
            SFA_Chart_Constructed_Data: null,
            SFA_SidePanelData: null
          }
        });
      });
  };
};

// Side panel api
export const DISTRICT_FA_SIDEPANEL_API_CALL = (AccessToken, payLoad) => {
  let AuthURL = ORR_URL + District_FA_SidePanel_API;

  let gridPayload = payLoad;

  return dispatch => {
    axios
      .post(AuthURL, gridPayload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;

        dispatch({
          type: DistrictFAType.DISTRICT_FA_GRID_API_CALL_SUCCESS,
          payload: Response
        });
      })
      .catch(error => {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: DistrictFAType.DISTRICT_FA_GRID_API_CALL_FAIL,
          payload: statusCode
        });
      });
  };
};
export const Update_Accordion_State = (state, index) => {
  let updatedState = state;
  updatedState[index] = !updatedState[index];
  return dispatch => {
    dispatch({ type: DistrictFAType.UPDATE_ACCORDION_STATE, payload: updatedState });
  };
};
export const UPDATE_SELECTED_BUBLIST = bubList => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.UPDATE_SELECTED_BUBLIST,
      payload: bubList
    });
  };
};
//tabs for District FA
export const ScFA_TAB_SELECTION = tabSelected => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DISTRICT_FA_TABS,
      payload: tabSelected
    });
  };
};


export const UPDATE_CHARTDATA_FOR_NEWGRADE = (
  responseDataList,
  selectedGrade,
  apiPayload,
  AccessToken
) => {
  let index = 0;
  let payload = apiPayload;
  return dispatch => {
    dispatch({
      type: DistrictFAType.UPDATE_CHARTDATA_FOR_NEWGRADE,
      payload: {
        apiResponse: responseDataList,
        selectedGradeIndex: selectedGrade
      }
    });
  };
};

export const UPDATE_SCROLL_DATA = data => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.UPDATE_SCROLL_DATA,
      payload: data
    });
  };
};

export const onLoadErrSelection = (recordData, errNames, recType) => {
  let defVal;
  let errObj;
  let defErrList = [];
  let defErrObj = [];
  let selObj;
  let onLoadSelErr = {};
  recordData["accuracy"] !== null &&
    Object.keys(recordData).forEach((obj, key) => {
      if (obj === errNames[key] && obj !== "recentRecordNull") {
        recordData[obj].forEach(errVal => {
          defVal = errVal;
          errObj = {
            // errorName: errNames[key],
            score: defVal.score,
            // value: defVal.value,
            criteriaId: defVal.criteriaId
          };

          if (defVal.value !== 0) {
            selObj = {
              errorName: errNames[key],
              rubrixScore: defVal.score,
              value: defVal.value,
              criteriaId: defVal.criteriaId,
              recordType: recType
            };
            defErrList.push(errObj);
            defErrObj.push(selObj);
            onLoadSelErr = {
              [recType]: defErrObj
            };
          }
        });
      }
    });

  return { defErrList: defErrList, onLoadSelErr: onLoadSelErr };
};

export const selectedScGrade = gradeSel => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DISTRICT_SELECTED_GRADE,
      payLoad: gradeSel
    });
  };
};

//load icon action
export const DFA_LOAD_ICON = (data) => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.LOAD_ICON_STATUS,
      payload: data
    });
  };
};




// Sort for District FA
export const SAVE_SORTED_SCFADATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DISTRICT_FA_SORTED_DATA,
      payload: { SortedArray }
    });
  };
};

//function to show icons and sort columns
export const SORT_SCFA_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DISTRICT_FA_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

export const SAVE_SORTED_SCFDATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.FPOT_SORTED_DATA,
      payload: { SortedArray }
    });
  };
};



export const UpdateRecordType = data => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DISTRICT_RECORD_TYPE,
      payload: data
    });
  };
};

export const SelectedErrors = data => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.UPDATE_SEL_DISTRICT_ERRORS,
      payload: data
    });
  };
};

export const UPDATE_ACCORDIAN = data => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DISTRICT_FPOT_CLASS_NAME,
      payload: data
    });
  };
};

export const DSTFA_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: DistrictFAType.DSTFA_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const DSTFA_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_DISTRICT;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: DistrictFAType.DSTFA_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: DistrictFAType.DISTRICT_FA_CHART_API_FAIL,
          payload: {
            apiLoadFail: true,
            noData: false,
            SFA_Chart_API_Response: null,
            SFA_Chart_Constructed_Data: null,
            SFA_SidePanelData: null
          }
        });
      });
  };
};