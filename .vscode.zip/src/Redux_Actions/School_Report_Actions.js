import {
  Base_URL,
  Get_School_gradesList,
  Get_school_strands,
  Get_School_QuestionCount,
  Get_Class_Details_Of_Selected_Strand,
  LineChart_of_School_strands,
  Get_School_TestScore_Graph,
  Get_School_selected_TS_Details,
  api_request_headers,
  Disable_AutoSelect_Std_Pref_LeftView,
} from "../Utils/globalVars";

import {
  School_Action_Types,
  SET_TOOLTIP_AND_BAR_VALUE_,
  GET_SCHOOL_STRANDS_QUESTION_COUNT_SUCCESS,
  GET_SCHOOL_STRAND_DETAILS_SUCCESS,
  GET_SCHOOL_STRANDS_GRADES_SUCCESS,
  GET_SCHOOL_STRAND_DETAILS,
  GET_CLASS_DETAILS_ON_STRAND_SELECTION_SUCCESS,
  GET_SELECTED_TS_CLASS_INFO_IN_SCHOOL,
  GET_SCHOOL_STRAND_DETAILS_FAIL,
  GET_SCHOOL_STRANDS_QUESTION_COUNT,
  GET_SELECTED_TS_CLASS_INFO_SUCCESS_IN_SCHOOL,
  GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS,
  SUMMARY_DRILLDOWN_TAXONAMY_PERSIST_CLEANUP,
} from "../Reducer_Action_Types/School_Report_Types";

import Axios from "axios";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  GetAssessed_Ques_ToPersist,
  GetTaxonomy_ToPersist_AndStrandDetails,
  Strands_Grade_ToPersist,
  calculateStrandAvgOnTaxonimy_Filter,
  Sort_ApiResponse_Payload_Array,
  sortTaxonomyDataBasedOnUserPrefferences,
  setStudentIdsWhenMultiSelectionsInSADA,
  toggleToPersist_In_StrandsOverview,
} from "../Components/ReusableComponents/AllReusableFunctions";
import {
  CheckIs_Selected_Strand_exist_in_the_List_Or_Not,
  checkIfStandardExistInSelectedListOrNot,
} from "../Redux_Reducers/Report_redux_functions_to_returnState";
import { multiDimensionalUnique } from "../Redux_Reducers/StudentReportReducer";
import { postErrorLog } from "./AuthenticationAction";
import { SetLastApplyiedDataOn_Success_Of_School_Reports } from "../Redux_Reducers/U_reducer_functions_to_returnSate";

/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 *
 * to get school grades from server.
 *
 */
export const getGradeListOfSchool = (AccessToken, ReqPayload) => {
  let URL = Base_URL + Get_School_gradesList;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: School_Action_Types.GET_SCHOOL_STRANDS_GRADES,
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;

        PayloadData = PayloadData == null ? [] : PayloadData;
        // let standardPerformancegradeStatus = true;

        let PreviousRepo_Nav = getState().LastActiveUniversalProps.NaviGation;
        let CurrentNav = getState().Universal.NavigationByHeaderSelection;

        let ActiveStrandGrade = Strands_Grade_ToPersist(
          PreviousRepo_Nav,
          getState
        );
        let { persitedTestAssessGrade } = getState().SummaryReports;
        dispatch({
          type: GET_SCHOOL_STRANDS_GRADES_SUCCESS,
          payload: {
            PayloadData,
            PreviousRepo_Nav,
            CurrentNav,
            ActiveStrandGrade,
            persitedTestAssessGrade
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 */
export const getTestAssessmentMaxCountOfSchool = (AccessToken, ReqPayload) => {
  let URL = Base_URL + Get_School_QuestionCount;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: GET_SCHOOL_STRANDS_QUESTION_COUNT,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;

        let LastActiveNav = getState().LastActiveUniversalProps.NaviGation;

        let QuestionToPersist;
        if (!LastActiveNav.school) {
          QuestionToPersist = GetAssessed_Ques_ToPersist(
            LastActiveNav,
            getState
          );
        }

        dispatch({
          type: GET_SCHOOL_STRANDS_QUESTION_COUNT_SUCCESS,
          payload: { PayloadData, QuestionToPersist },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {string} selectedfiield
 * @param {Boolean} check
 * @param {String} IN_TS_Overview
 *
 * on selection of compare check boxes in linechart of strands and linechart of test scores  in school report
 *
 */

export const CompareCheckBoxOption_For_School_LC = (
  selectedfiield,
  check,
  IN_TS_Overview
) => {
  return (dispatch) => {
    dispatch({
      type: School_Action_Types.COMPARE_CHECKBOX_OPTION_FOR_SCHOOL_LC,
      payload: { selectedfiield, check, IN_TS_Overview, IN_TS_Overview },
    });
  };
};
/**
 *
 * @param {Boolean} openOrClose
 * @param {String} SelectedNav
 * is to open the note in school standards performance/ testcsores overview component.
 */
export const OpenOrCloseTooltipIn_SC_OT = (openOrClose, SelectedNav) => {
  return (dispatch) => {
    dispatch({
      type: School_Action_Types.OPEN_OR_CLOSE_TOOLTIP_IN_S_SP_OT,
      payload: { openOrClose, SelectedNav },
    });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} reqObject
 * @param {Boolean} EnableLoading
 * to get class strands table details.
 */
export const Get_School_StandardPerformance_Details = (
  AccessToken,
  reqObject,
  EnableLoading
) => {
  let URL = Base_URL + Get_school_strands;
  return (dispatch, getState) => {
    reqObject.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      reqObject.studentIds
    );
    reqObject.currentTermId =
      reqObject.currentTermId == undefined
        ? getState().Universal.currentTermID
        : reqObject.currentTermId;
    // let activeToggle = toggleToPersist_In_StrandsOverview(getState)

    dispatch({
      type: GET_SCHOOL_STRAND_DETAILS,
      payload: { EnableLoading },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, reqObject, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let Data = response.data.value;

        Data = Data == null ? [] : Data;

        let PreviousRepo_Nav = getState().LastActiveUniversalProps.NaviGation;
        let CurrentNav = getState().Universal.NavigationByHeaderSelection;

        let last_active_Taxonomy_And_StrandDetails = {};
        if (CurrentNav.S_performance && CurrentNav.Overview) {
          last_active_Taxonomy_And_StrandDetails =
            GetTaxonomy_ToPersist_AndStrandDetails(PreviousRepo_Nav, getState);
        }

        //#region start setting state

        let state = getState().schoolReducer;
        let UserPreferences = getState().Universal.UserPreferences;
        let SchoolReports_StateToSet;

        let List_Class_STrands = Data;
        let LastNav = getState().LastActiveUniversalProps.NaviGation;
        if (List_Class_STrands.length == 0) {
          SchoolReports_StateToSet = {
            ...state,
            Sc_StandardPerformance_Overview: {
              ...state.Sc_StandardPerformance_Overview,
              StandardPerformanceFilter: {
                ...state.Sc_StandardPerformance_Overview
                  .StandardPerformanceFilter,
                NodataInStrands: true,
              },
            },
            Sc_ApiCalls: {
              ...state.Sc_ApiCalls,
              loading_Strands_table: false,
            },
          };
        } else {
          const strandOrignalList = Data;
          let StandsList = Data;
          let StrandTaxonomyList = [];
          let comesfrom_compare =
            state.Sc_StandardPerformance_Overview.strandSelectedFromCompare;

          StandsList.strands = Sort_ApiResponse_Payload_Array(
            StandsList.strands,
            "strands"
          );

          // Taxonomy Logic Will goes here
          let SetValues = [];
          StandsList.strands.map((strand) => {
            strand.standards.map((single_standard) => {
              StrandTaxonomyList.push(single_standard.taxonomy);
              SetValues.push({
                setId: single_standard.setId,
                taxonomy: single_standard.taxonomy,
              });
            });
          });
          StrandTaxonomyList = [...new Set(StrandTaxonomyList)];
          SetValues = multiDimensionalUnique(SetValues);
          StrandTaxonomyList.sort();

          if (
            UserPreferences !== null &&
            UserPreferences != undefined &&
            UserPreferences.standardsetorders.length > 0
          ) {
            StrandTaxonomyList = sortTaxonomyDataBasedOnUserPrefferences(
              UserPreferences,
              SetValues
            );
          }

          let {
            last_active_Taxonomy,
            StrandNameToPersist,
            StandardIdToPersist,
          } = last_active_Taxonomy_And_StrandDetails;
          let TaxonomyExist = last_active_Taxonomy
            ? StrandTaxonomyList.includes(last_active_Taxonomy)
            : StrandTaxonomyList.includes(
                state.Sc_StandardPerformance_Overview
                  .selected_Taxonomy_From_Compare
              );
          let Selec_Taxonomyis =
            comesfrom_compare && TaxonomyExist
              ? state.Sc_StandardPerformance_Overview
                  .selected_Taxonomy_From_Compare
              : last_active_Taxonomy && TaxonomyExist
              ? last_active_Taxonomy
              : comesfrom_compare && TaxonomyExist
              ? state.Sc_StandardPerformance_Overview
                  .selected_Taxonomy_From_Compare
              : StrandTaxonomyList[0];
              let taxonomyfromSPSummary = state.taxonomyfromSPSummary;
              let SPSummarydrillDown = state.SPSummarydrillDown;
              if(SPSummarydrillDown && taxonomyfromSPSummary !="" &&  StrandTaxonomyList.includes(taxonomyfromSPSummary)){
                Selec_Taxonomyis = taxonomyfromSPSummary;
              }
          // End of Taxonomy Logic Will goes here
          StandsList.strands = Sort_ApiResponse_Payload_Array(
            StandsList.strands,
            "strands"
          );

          let SelectionBasedTaxonomyList = { ...StandsList };

          SelectionBasedTaxonomyList.strands =
            SelectionBasedTaxonomyList.strands
              .map((strand) => {
                return {
                  ...strand,
                  standards: [
                    ...strand.standards.filter(
                      (single_taxonomy_standard) =>
                        single_taxonomy_standard.taxonomy == Selec_Taxonomyis
                    ),
                  ],
                };
              })
              .filter(
                (emptyRemovalStrands) => emptyRemovalStrands.standards.length
              );

          SelectionBasedTaxonomyList = calculateStrandAvgOnTaxonimy_Filter(
            SelectionBasedTaxonomyList
          );

          let SelectedStrand =
            !Disable_AutoSelect_Std_Pref_LeftView &&
            (SelectionBasedTaxonomyList.strands !== undefined ||
              SelectionBasedTaxonomyList.strands !== null)
              ? SelectionBasedTaxonomyList.strands[0]
              : {
                  strandName: LastNav.school
                    ? state.Sc_StandardPerformance_Overview
                        .StrandNameOfSelectedStandard
                    : "",
                  strandAvg: LastNav.school
                    ? state.Sc_StandardPerformance_Overview.selectedStandarAvg
                    : "",
                  selectedStandardId: LastNav.school
                    ? state.Sc_StandardPerformance_Overview.selectedStandardId
                    : "",
                };

          let StrandName = SelectedStrand.strandName;
          let Avarage = SelectedStrand.strandAvg;
          let standardId =
            state.Sc_StandardPerformance_Overview.selectedStandardId;
          let StandardsObj =
            state.Sc_StandardPerformance_Overview.selectedstandardObject;
          StandardsObj =
            StandardsObj == undefined || StandardsObj == null
              ? {}
              : StandardsObj;

          let Strand_Fn_Response =
            CheckIs_Selected_Strand_exist_in_the_List_Or_Not(
              StandsList,
              state.Sc_StandardPerformance_Overview
                .StrandNameOfSelectedStandard,
              standardId,
              StandardsObj
            );

          if (comesfrom_compare && TaxonomyExist) {
            let Strand_List = Data == null ? [] : StandsList.strands;

            if (
              PreviousRepo_Nav.district &&
              Disable_AutoSelect_Std_Pref_LeftView
            ) {
              StrandName =
                getState().DistrictReducer.D_StandardPerformance_Overview
                  .StrandNameOfSelectedStandard;
              standardId =
                getState().DistrictReducer.D_StandardPerformance_Overview
                  .selectedStandardId;
            } else if (
              PreviousRepo_Nav.class &&
              Disable_AutoSelect_Std_Pref_LeftView
            ) {
              StrandName =
                getState().Reports.StandardPerformance_Overview
                  .StrandNameOfSelectedStandard;
              standardId =
                getState().Reports.StandardPerformance_Overview
                  .selectedStandardId;
            }

            // standardId = state.Sc_StandardPerformance_Overview.selectedStandard_From_Compare;
            // StrandName = state.Sc_StandardPerformance_Overview.selectedStrand_From_Compare;

            let StandardIdIsNot_Exist = false;
            let STrandIsNotExist = false;

            if (standardId !== "") {
              let selectedstrand = Strand_List.filter(
                (item) => item.strandName == StrandName
              );
              if (selectedstrand[0] !== undefined) {
                StandardsObj = selectedstrand[0].standards.find(function (
                  element
                ) {
                  return element.standardId == standardId;
                });
                if (StandardsObj == undefined) {
                  StandardIdIsNot_Exist = true;
                } else {
                  Avarage = StandardsObj.standardAvg;
                }
              } else {
                STrandIsNotExist = true;
              }
            } else {
              StandardsObj = {};
              Avarage = "";
            }

            /**
             *  start , if strand or standard is not there in payload data
             */
            if (STrandIsNotExist) {
              StrandName = Strand_List[0].strandName;
              StandardsObj = {};
              Avarage = "";
              standardId = "";
            } else if (StandardIdIsNot_Exist) {
              StandardsObj = {};
              Avarage = "";
              standardId = "";
            }

            /**
             *  End , if strand or standard is not there in payload data
             */
          } else if (Strand_Fn_Response.ReplaceValues) {
            if (!Disable_AutoSelect_Std_Pref_LeftView) {
              StrandName =
                state.Sc_StandardPerformance_Overview
                  .StrandNameOfSelectedStandard;
              Avarage =
                Strand_Fn_Response.selectedStandarAvg == ""
                  ? state.Sc_StandardPerformance_Overview.selectedStandarAvg
                  : Strand_Fn_Response.selectedStandarAvg;
              standardId =
                Strand_Fn_Response.StandardsObj.standardId == undefined
                  ? ""
                  : Strand_Fn_Response.StandardsObj.standardId;
              StandardsObj =
                state.Sc_StandardPerformance_Overview.selectedstandardObject;
            }

            if (
              PreviousRepo_Nav.student &&
              PreviousRepo_Nav.S_performance &&
              PreviousRepo_Nav.Overview &&
              Disable_AutoSelect_Std_Pref_LeftView
            ) {
              StrandName =
                getState().StudentReports.S_StandardPerformance_Overview
                  .StrandNameOfSelectedStandard;
              StandardsObj =
                getState().StudentReports.S_StandardPerformance_Overview
                  .selectedstandardObject;
            } else if (
              PreviousRepo_Nav.class &&
              PreviousRepo_Nav.S_performance &&
              PreviousRepo_Nav.Overview &&
              Disable_AutoSelect_Std_Pref_LeftView
            ) {
              StrandName =
                getState().Reports.StandardPerformance_Overview
                  .StrandNameOfSelectedStandard;
              StandardsObj =
                getState().Reports.StandardPerformance_Overview
                  .selectedstandardObject;
            } else {
            }
          } else {
          }

          StandardsObj =
            StandardsObj == null ||
            StandardsObj == undefined ||
            StandardsObj == ""
              ? {}
              : StandardsObj;

          SelectionBasedTaxonomyList =
            SelectionBasedTaxonomyList === null
              ? []
              : SelectionBasedTaxonomyList;

          let IndexofCurrentSTrand =
            SelectionBasedTaxonomyList.strands.findIndex(
              (item) => item.strandName == StrandName
            );
          let HeaderStart = state.Sc_StandardPerformance_Overview.headerStart;
          let HeaderEnd = state.Sc_StandardPerformance_Overview.headerEnd;
          let Diff = window.screen.width < 1281 ? 4 : 6;

          if (IndexofCurrentSTrand + 1 > HeaderEnd) {
            HeaderEnd = IndexofCurrentSTrand + 1;
            HeaderStart = HeaderEnd - Diff;
          }

          if (
            StandardsObj.standardId !== undefined &&
            StandardsObj.standardId !== null
          ) {
            const checkPoint = checkIfStandardExistInSelectedListOrNot(
              StandardsObj.standardId,
              SelectionBasedTaxonomyList.strands
            );
            if (!checkPoint) {
              StandardsObj = null;
            }
          }

          let rightSideList =
            StrandName !== "" &&
            StrandName !== null &&
            StrandName !== undefined;
          SchoolReports_StateToSet = {
            ...state,
            Sc_StandardPerformance_Overview: {
              ...state.Sc_StandardPerformance_Overview,
              originalList: strandOrignalList,
              ActualList: SelectionBasedTaxonomyList,
              List: StandsList === null ? [] : StandsList,
              selectedStandardId:
                StandardsObj !== null && StandardsObj !== undefined
                  ? StandardsObj.standardId !== undefined &&
                    StandardsObj.standardId !== null
                    ? StandardsObj.standardId
                    : ""
                  : "",
              selectedStandarAvg: Avarage,
              StrandNameOfSelectedStandard: StrandName,
              selectedstandardObject: StandardsObj,
              headerStart: HeaderStart,
              headerEnd: HeaderEnd,
              StandardPerformanceFilter: {
                ...state.Sc_StandardPerformance_Overview
                  .StandardPerformanceFilter,
                NodataInStrands: false,
                TestGrade: {
                  ...state.Sc_StandardPerformance_Overview
                    .StandardPerformanceFilter.TestGrade,
                  gradefor_last_Active_report:
                    state.Sc_StandardPerformance_Overview
                      .StandardPerformanceFilter.TestGrade.selectedTestgrade,
                },
                Taxonomy: {
                  ...state.Sc_StandardPerformance_Overview
                    .StandardPerformanceFilter.Taxonomy,
                  selectedTaxonomy: Selec_Taxonomyis,
                  TaxonomyList: StrandTaxonomyList,
                  OpenCloseTaxonomy: false,
                },
                SetValues: SetValues,
              },
              selectedStrand_From_Compare: "",
              selected_Taxonomy_From_Compare: "",
              selectedStandard_From_Compare: "",
              strandSelectedFromCompare: false,
            },
            Sc_ApiCalls: {
              ...state.Sc_ApiCalls,
              get_classList_and_Graph_ofClassStrand: rightSideList,
              loading_Strands_table: false,
            },
          };
        }

        //#endregion

        let D_Strands =
          getState().DistrictReducer.D_StandardPerformance_Overview
            .StandardPerformanceFilter;

        let Sc_Strands =
          SchoolReports_StateToSet.Sc_StandardPerformance_Overview
            .StandardPerformanceFilter;

        let EnableD_StrandsApis = false;

        if (
          D_Strands.Taxonomy.selectedTaxonomy !==
            Sc_Strands.Taxonomy.selectedTaxonomy ||
          D_Strands.TestAssessment.selectedTestAssessment !==
            Sc_Strands.TestAssessment.selectedTestAssessment ||
          (D_Strands.TestGrade.selectedTestgrade &&
            D_Strands.TestGrade.selectedTestgrade.grade !==
              Sc_Strands.TestGrade.selectedTestgrade.grade)
        ) {
          EnableD_StrandsApis = true;
        }

        let { Universal, LastActiveUniversalProps } = getState();
        let reqFrom = "Strands";
        let DataList = Data == null ? [] : Data;
        let payload = {
          Data,
          DataForGrade: reqObject.grade,
          PreviousRepo_Nav,
          CurrentNav,
          last_active_Taxonomy_And_StrandDetails,
          SchoolReports_StateToSet,
          EnableD_StrandsApis,
          reqFrom,
          DataList,
        };
        let action = {
          payload,
        };
        let { updatedLastActivePropsState, updatedUniversalState } =
          SetLastApplyiedDataOn_Success_Of_School_Reports(
            JSON.parse(JSON.stringify(Universal)),
            action,
            JSON.parse(JSON.stringify(LastActiveUniversalProps))
          );
        dispatch({
          type: GET_SCHOOL_STRAND_DETAILS_SUCCESS,
          payload: {
            Data,
            DataForGrade: reqObject.grade,
            PreviousRepo_Nav,
            CurrentNav,
            last_active_Taxonomy_And_StrandDetails,
            SchoolReports_StateToSet,
            EnableD_StrandsApis,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
        const isSchoolDrillDownfromSummary = state.SPSummarydrillDown;
        if(isSchoolDrillDownfromSummary){
        dispatch({
          type: SUMMARY_DRILLDOWN_TAXONAMY_PERSIST_CLEANUP
        });
      }
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        dispatch({
          type: GET_SCHOOL_STRAND_DETAILS_FAIL,
          payload: error,
        });
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {Object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} strandName --selected STrand Name
 * @param {string} standardAvg -- selected standard evg.
 */
export const GetClassDetailsOf_SelectedStrands = (
  AccessToken,
  ReqPayload,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading,
  selectedTaxonomy,
  Sel_Ass_Ques
) => {
  let URL = Base_URL + Get_Class_Details_Of_Selected_Strand;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    let activeToggle = toggleToPersist_In_StrandsOverview(getState);
    dispatch({
      type: School_Action_Types.GET_CLASS_DETAILS_ON_STRAND_SELECTION,
      payload: {
        standardId,
        standardAvg,
        strandName,
        standard,
        Enableloading,
        activeToggle,
      },
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let PayloadData = response.data.value;

        dispatch({
          type: GET_CLASS_DETAILS_ON_STRAND_SELECTION_SUCCESS,
          payload: {
            PayloadData,
            standardId,
            standardAvg,
            strandName,
            standard,
            selectedTaxonomy,
            Sel_Ass_Ques,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {String} AccessToken
 * @param {object} ReqPayload
 * @param {string} strandId
 * @param {string} standardId
 * @param {string} standardAvg
 * @param {string} strandName
 * @param {string} standard
 */
export const GetLineChartDetailsofSelected_Standards_OfSchool = (
  AccessToken,
  ReqPayload,
  standardId,
  standardAvg,
  strandName,
  standard,
  Enableloading
) => {
  let URL = Base_URL + LineChart_of_School_strands;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: School_Action_Types.GET_LINECHART_DATA_OF_SCHOOL_STRANDS,
      payload: Enableloading,
    });

    let seconds_Start = new Date().getTime() / 1000;

    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        dispatch({
          type: School_Action_Types.GET_LINECHART_DATA_OF_SCHOOL_STRANDS_SUCCESS,
          payload: { PayloadData, strandName, persist_compare_checkboxes },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {string} token -- Jwt AccessToken.
 * @param {object} ReqPayload -- Api Req_Payload.
 * @param {Boolean} Enableload
 * Get School test score graph details
 */
export const Get_school_TestScores_Graph = (
  AccessToken,
  ReqPayload,
  Enableload
) => {
  let URL = Base_URL + Get_School_TestScore_Graph;

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: School_Action_Types.GET_SCHOOL_TS_GRAPH_DETAILS,
      payload: Enableload,
    });

    let seconds_Start = new Date().getTime() / 1000;
    const state = getState();
    let LastActiveNav = state.LastActiveUniversalProps.NaviGation;
    const Class_Testscore = state.Reports;
    const School_Testscore = state.schoolReducer;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, ReqPayload, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let ResPayload = response.data.value;

        let { Universal, LastActiveUniversalProps } = getState();
        let reqFrom = "TestScore";
        let DataList = ResPayload == null ? [] : ResPayload;
        let payload = {
          ResPayload,
          Class_Testscore,
          School_Testscore,
          reqFrom,
          DataList,
        };
        let action = {
          payload,
        };
        let { updatedLastActivePropsState, updatedUniversalState } =
          SetLastApplyiedDataOn_Success_Of_School_Reports(
            JSON.parse(JSON.stringify(Universal)),
            action,
            JSON.parse(JSON.stringify(LastActiveUniversalProps))
          );

        dispatch({
          type: GET_SCHOOL_TS_GRAPH_DETAILS_SUCCESS,
          payload: {
            ResPayload,
            Class_Testscore,
            School_Testscore,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {string} AccessToken --jwt token.
 * @param {object} reqObject --request payload.
 */
export const Get_Selected_TS_Details = (
  AccessToken,
  reqObject,
  test,
  enableLoading
) => {
  let URL = Base_URL + Get_School_selected_TS_Details;

  return (dispatch, getState) => {
    reqObject.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      reqObject.studentIds
    );
    dispatch({
      type: GET_SELECTED_TS_CLASS_INFO_IN_SCHOOL,
      payload: { test, enableLoading },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    Axios.post(URL, reqObject, {
      headers: api_request_headers,
    })
      .then(function (response) {
        let PayloadData = response.data.value;
        PayloadData.ReqComponentCode = reqObject.componentCode;
        dispatch({
          type: GET_SELECTED_TS_CLASS_INFO_SUCCESS_IN_SCHOOL,
          payload: PayloadData,
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

/**
 *
 * @param {int} xU  -- x-axis value
 * @param {int } yU  --y-axis value
 * @param {object} tooltip_data  --selected circle data
 * @param {boolean} tooltipDisplay --true/false
 * @param {boolean} ShowTollTipPopUp
 * @param {int} index --index value of selected circle.
 */
export const SetToolTipAndBarValues_InSchool_ = (
  xU,
  yU,
  tooltip_data,
  tooltipDisplay,
  index,
  ShowTollTipPopUp,
  Nav
) => {
  return (dispatch) => {
    dispatch({
      type: SET_TOOLTIP_AND_BAR_VALUE_,
      payload: {
        xU,
        yU,
        tooltip_data,
        tooltipDisplay,
        index,
        ShowTollTipPopUp,
        Nav,
      },
    });
  };
};
