import {
  Base_URL,
  Get_Tests,
  DistrictAGPCSV,
  api_request_headers,
  Get_TestStatus_Summary,
  SummaryDistrictTestStatus,
  SummarySchooltTestStatus,
  SPOT_PDF_DOWNLOAD,
} from "../Utils/globalVars";
import axios from "axios";
import {
  STANDARDPERFORMANCE_SUMMARYREPORTS_API,
  STANDARDPERFORMANCE_SUMMARYREPORTS_API_SUCCESS,
  TAXONOMY_BUTTON_CLICK,
  ON_TAXONOMY_SELECTION,
  HEADER_NAV_CLICK,
  DRILLDOWN_FROM_SUMMARYREPORTS_MODULE,
  CSV_MODEL,
  CSV_MODEL_TESTSTATUS,
  CANCEL_TESTSTATUS_CSV_MODEL,
  CSV_CHECKBOXES,
  SUMMARY_CSV_SUCCESS,
  SUMMARY_CSV,
  SUMMARY_TESTS_API_SUCCESS,
  SUMMARY_TESTSTATUS_API,
  SUMMARY_TESTSTATUS_API_SUCCESS,
  SUMMARY_TESTSTATUS_DRILLDOWN,
  GETTESTSFORSUMMARY_SUCCESS,
  GETTESTSFORSUMMARY,
  GET_SUMMARY_SP_PDF_DATA,
  GET_SUMMARY_SP_PDF_DATA_SUCCESS,
  GET_SUMMARY_SP_PDF_DATA_FAIL,
  DOWNLOAD_TS_PDF,
  DOWNLOAD_TS_PDF_SUCCESS,
  GRADE_BUTTON_CLICK,
  ON_GRADE_SELECTION,
  SUMMARY_TESTGRADES,
  SUMMARY_TESTGRADES_SUCCESS,
  DRILLDOWN_FROM_SCHOOL_DISTRICT
} from "../Reducer_Action_Types/summaryReports_Action_Types";
import {
  check_Selected_item_Of_Array,
  GetAllRosterDataOfA_Grade,
  getClassAndTeacherOf_Student,
  SortArrayBaseOnTrueOrFalse,
  SortObjectByKey,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { ON_TEST_STATUS_SELECTION } from "../Reducer_Action_Types/TestStatus.Types";
import {
  OnTestStatusSelection,
  Get_TestStatusDetailsData,
} from "./TestStatus.Actions";
import { StudentGradeTestCountAPI } from "./UniversalSelectorActions";
import { postErrorLog, trackingUsage } from "./AuthenticationAction";
import { Return_ERROR_Status_Code } from "../Components/ReusableComponents/AllReusableFunctions";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { SaveAppiledChangesOnSuccessResponse } from "../services/universalSelector/universalSelector_4";
import { SUMMARY_TESTSTATUS_API_SUCCESS_US_Redux_Fun } from "../services/universalSelector/universalSelector_3";
import { SummaryGet_CSV_Details,Get_CSV_Details, SPGet_CSV_Details } from "../Redux_Actions/ReportsActions";
import { rosterGrade } from "../Utils/reUsableSnipets";
const getToken = (state) => {
  return state.Authentication.LoginDetails.JWTToken;
};

export function Strands_GradeDetails_Of_Taxonomy(
  viewDetails,
  selectedTaxonomy,
  fromContext
) {
  let TaxonomyList = [];
  let gradeDetails = {};
  let studentList = {};
  let HeaderStrands = {};
  viewDetails &&
    Object.keys(viewDetails).map(function (key, index) {
      if (
        (selectedTaxonomy === undefined && index === 0) ||
        key === selectedTaxonomy
      ) {
        HeaderStrands = viewDetails[key].averageScoresByStrand;
        gradeDetails = viewDetails[key].gradeDetails;
        studentList = viewDetails[key].studentList;
        selectedTaxonomy = key;
      }

      TaxonomyList.push(key);
    });
  return {
    TaxonomyList,
    selectedTaxonomy,
    gradeDetails,
    HeaderStrands,
    studentList,
  };
}
export const DrillDownFromTSSummaryReports = (
  selectedItem,
  selectedStatus,
  fromContext,
  Nav,
  ReqObject,
  SelectedSumGrade,
  datalength
) => {
  ReqObject.testStatus = selectedStatus;
  ReqObject.componentCodeList = [selectedItem.componentCode];
  ReqObject.testType = selectedItem.testTitle;
  if (fromContext == "district") {
    ReqObject.rosterGrade = SelectedSumGrade;
  }

  let selectedStatus1 = selectedStatus;
  if (selectedStatus == "Complete") {
    selectedStatus1 = "completed";
  } else if (selectedStatus == "In Progress") {
    selectedStatus1 = "in-progress";
  } else if (selectedStatus == "NeedsToBeGraded") {
    selectedStatus1 = "need-tobe-graded";
  } else {
    selectedStatus1 = "not-started";
  }

  return (dispatch, getState) => {
    let Token = getToken(getState());
    if (fromContext == "class") {
      SelectedSumGrade =
        getState().Universal.ContextHeader.Roster_Tab.selectedRosterGrade;
    }
    let universalState = DrillDownUniverasalSetup(
      getState().Universal,
      SelectedSumGrade,
      Nav,
      fromContext
    );

    dispatch({
      type: SUMMARY_TESTSTATUS_DRILLDOWN,
      payload: {
        universalState,
        Nav,
        fromContext,
        selectedStatus1,
        selectedItem,
        datalength,
      },
    });
  };
};
export const GetSummaryTestStatusReports = (reqPayload, context) => {
  return (dispatch, getState) => {
    let Token = getToken(getState());

    let EndPoint =
      context === "district"
        ? SummaryDistrictTestStatus
        : context === "school"
        ? SummarySchooltTestStatus
        : Get_TestStatus_Summary;
    let URL = Base_URL.concat(EndPoint);
    
    dispatch({
      type: SUMMARY_TESTSTATUS_API,
      payload: {  context, reqPayload },
    });

    axios
      .post(URL, reqPayload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          Authorization: "Bearer ".concat(Token),
        },
      })
      .then(function (response) {
        let Data = response.data.value != null ? response.data.value : {};
        let { LastActiveUniversalProps, Universal } = getState();

        let { updatedLastActivePropsState, updatedUniversalState } =
          SUMMARY_TESTSTATUS_API_SUCCESS_US_Redux_Fun(
            context,
            Universal,
            LastActiveUniversalProps
          );
        dispatch({
          type: SUMMARY_TESTSTATUS_API_SUCCESS,
          payload: { Data, context, updatedLastActivePropsState },
        });
      })
      .catch(function (error) {
        console.log("error is : ", error);
      });
  };
};
export const SummaryTests = (
  AccessToken,
  ReqPayload,
  Nav,
  DateTabReducer,
  Summary_Roster_Data,
  TestsApiReqObj,
  SummaryComponentCodes
) => {
  let URL = Base_URL + Get_Tests;
  return (dispatch, getState) => {
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    let FromTestStatus = true;
    dispatch({
      type: GETTESTSFORSUMMARY,
      payload: { Nav,FromTestStatus },
    });
    fetch(URL, {
      method: "post",
      headers: api_request_headers,
      body: JSON.stringify(TestsApiReqObj),
    })
      .then((res) => res.json())
      .then((res) => {
        let Response = res.value;
        dispatch(
          SummaryGet_CSV_Details(
            AccessToken,
            ReqPayload,
            Nav,
            DateTabReducer,
            Summary_Roster_Data,
            TestsApiReqObj,
            Response,
            FromTestStatus
          )
        );
        dispatch({
          type: GETTESTSFORSUMMARY_SUCCESS,
          payload: { Response, Nav },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
      });
  };
};
export const SummarySPTests = (
  AccessToken,
  ReqPayload,
  Nav,
  DateTabReducer,
  Summary_Roster_Data,
  TestsApiReqObj,
  SummaryComponentCodes
) => {
  let URL = Base_URL + Get_Tests;
  return (dispatch, getState) => {
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    let FromTestStatus = false;
    dispatch({
      type: GETTESTSFORSUMMARY,
      payload: { Nav, FromTestStatus },
    });
    fetch(URL, {
      method: "post",
      headers: api_request_headers,
      body: JSON.stringify(TestsApiReqObj),
    })
      .then((res) => res.json())
      .then((res) => {
        let Response = res.value;
        dispatch(
          SPGet_CSV_Details(
            AccessToken,
            ReqPayload,
            Nav,
            Response
          )
        );
        dispatch({
          type: GETTESTSFORSUMMARY_SUCCESS,
          payload: { Response, Nav },
        });
      })
      .catch((error) => {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
      });
  };
};
export const Getstandardperformance_SummaryReports = (fromContext) => {
  return (dispatch, getState) => {
    let Token = getToken(getState());
    let { ContextHeader, NavigationByHeaderSelection } = getState().Universal;
    let { SummaryReports } = getState();

    const { Summary_Reports, school } = NavigationByHeaderSelection;

    let URL =
      Base_URL + `${fromContext}/summary/assessments/standardperformance`;

    let reqPayload = {
      districtId: ContextHeader.DistrictId,
      termId:
        getState().DateTabReducer.DateTabComponents.SelectedDistrictTerm.termId,
    };
    if (ContextHeader.DistrictId == null) {
      reqPayload.districtId =
        ContextHeader.Roster_Tab.SelectedDistrict.id != undefined
          ? ContextHeader.Roster_Tab.SelectedDistrict.id
          : null;
    }
    if (school) {
      reqPayload.schoolId = ContextHeader.Summary_Roster_Data.SelectedSchool.id;
    }
    if (NavigationByHeaderSelection.class) {
      (reqPayload.classId = ContextHeader.Summary_Roster_Data.SelectedClass.id),
        (reqPayload.schoolId =
          ContextHeader.Summary_Roster_Data.SelectedSchool.id),
        (reqPayload.rosterGrade = rosterGrade(ContextHeader.Summary_Roster_Data));
    }
    reqPayload.grade = SummaryReports[`${fromContext}`].assessments.standardperformance.selectedTestGrade;
    if (fromContext !== "class") {
        delete reqPayload.grade;
    }
    dispatch({
      type: STANDARDPERFORMANCE_SUMMARYREPORTS_API,
      payload: { reqPayload, fromContext },
    });
    axios
      .post(URL, reqPayload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          Authorization: "Bearer ".concat(Token),
        },
      })
      .then(function (response) {
        let Data = response.data.value;
        let viewDetails = Data && Data.viewDetails;
        let selectedTaxonomy_input; // it should be undefined ;

        let {
          gradeDetails,
          HeaderStrands,
          TaxonomyList,
          selectedTaxonomy,
          studentList,
        } = Strands_GradeDetails_Of_Taxonomy(
          viewDetails,
          selectedTaxonomy_input,
          fromContext
        );

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
          Data,
          TaxonomyList,
          selectedTaxonomy,
          HeaderStrands,
          gradeDetails,
          NavigationByHeaderSelection,
          fromContext,
          studentList,
        };
        let action = {
          payload,
        };
        let updatedLastActivePropsState = LastActiveUniversalProps,
          updatedUniversalState = Universal;
        if (
          action.payload.Data &&
          action.payload.Data.viewDetails &&
          Object.keys(action.payload.Data.viewDetails).length > 0
        ) {
          let responseStates = SaveAppiledChangesOnSuccessResponse(
            JSON.parse(JSON.stringify(Universal)),
            action,
            JSON.parse(JSON.stringify(LastActiveUniversalProps))
          );

          updatedLastActivePropsState =
            responseStates.updatedLastActivePropsState;
          updatedUniversalState = responseStates.updatedUniversalState;
        }
        dispatch({
          type: STANDARDPERFORMANCE_SUMMARYREPORTS_API_SUCCESS,
          payload: {
            Data,
            TaxonomyList,
            selectedTaxonomy,
            HeaderStrands,
            gradeDetails,
            NavigationByHeaderSelection,
            fromContext,
            studentList,
            updatedUniversalState,
            updatedLastActivePropsState,
          },
        });
      })
      .catch(function (error) {
        console.log("error is : ", error);
      });
  };
};
export const TaxonomyButtonClick = (fromContext) => {
  return (dispatch, getState) => {
    dispatch({
      type: TAXONOMY_BUTTON_CLICK,
      payload: { fromContext },
    });
  };
};
export const GradeButtonClick = (fromContext) => {
  return (dispatch) => {
    dispatch({
      type: GRADE_BUTTON_CLICK,
      payload: {  fromContext }
    });
  };
};
export const GradeSelection= (item,fromContext) => {
  return (dispatch) => {
    dispatch({
      type: ON_GRADE_SELECTION,
      payload: { item,fromContext }
    });
  };
};
export const onTaxonomySelection = (taxonomy, fromContext) => {
  return (dispatch, getState) => {
    let viewDetails =
      getState().SummaryReports[`${fromContext}`].assessments
        .standardperformance.data;
    let {
      gradeDetails,
      HeaderStrands,
      TaxonomyList,
      selectedTaxonomy,
      studentList,
    } = Strands_GradeDetails_Of_Taxonomy(viewDetails, taxonomy, fromContext);
    const onTaxonomySelection = true;
    dispatch({
      type: ON_TAXONOMY_SELECTION,
      payload: {
        TaxonomyList,
        selectedTaxonomy,
        HeaderStrands,
        gradeDetails,
        fromContext,
        onTaxonomySelection,
        studentList,
      },
    });
  };
};

export const headerNavClick = (navDirection, fromContext) => {
  return (dispatch, getState) => {
    let { data, headerNavStart, headerNavEnd } =
      getState().SummaryReports[`${fromContext}`].assessments
        .standardperformance;
    if (navDirection === "left") {
      headerNavStart -= 1;
      headerNavEnd -= 1;
    } else {
      headerNavStart += 1;
      headerNavEnd += 1;
    }
    let state = getState().SummaryReports;
    let SummaryReportsReducer = {
      ...state,
      [`${fromContext}`]: {
        ...state[`${fromContext}`],
        assessments: {
          ...state[`${fromContext}`].assessments,
          standardperformance: {
            ...state[`${fromContext}`].assessments.standardperformance,
            headerNavStart: headerNavStart,
            headerNavEnd: headerNavEnd,
          },
        },
      },
    };
    dispatch({
      type: HEADER_NAV_CLICK,
      payload: { SummaryReportsReducer },
    });
  };
};

export const DrillDownFromSummaryReports_Module = (
  selectedTaxonomy,
  standard,
  grade,
  fromContext,
  studentData
) => {
  return (dispatch, getState) => {
    let Nav = getState().Universal.NavigationByHeaderSelection;
    let { SummaryReports, Authentication } = getState();
    let {selectedTestGrade, TestGradeList} = SummaryReports[`${fromContext}`].assessments.standardperformance;
    let universalState = DrillDown_Summary_Module_For_Universal_reducer(
      getState().Universal,
      grade,
      Nav,
      fromContext,
      studentData,
      selectedTestGrade
    );
    if(fromContext == "student"){
      selectedTestGrade = SummaryReports.class.assessments.standardperformance.selectedTestGrade;
    }
   
    let Reports_State_SP_Overview =
      DrillDown_Summary_Module_For_Reports_reducer(
        getState(),
        selectedTaxonomy,
        standard,
        grade,
        Nav,
        fromContext
      );
    dispatch({
      type: DRILLDOWN_FROM_SUMMARYREPORTS_MODULE,
      payload: { Reports_State_SP_Overview, universalState, Nav, fromContext,selectedTestGrade },
    });
  };
};
export const ClickOnCSVModel = (
  flag,
  fromContext,
  requestObj,
  AccessToken,
  Nav,
  make_api_call
) => {
  return (dispatch) => {
    dispatch({
      type: CSV_MODEL,
      payload: { flag, fromContext },
    });
    if (flag) {
      make_api_call = true;
    }
    dispatch(
      StudentGradeTestCountAPI(flag, requestObj, AccessToken, make_api_call)
    );
  };
};
export const ClickOnTestStatusCSVModel = (
  flag,
  fromContext,
  requestObj,
  AccessToken,
  Nav,
  make_api_call
) => {
  return (dispatch) => {
    dispatch({
      type: CSV_MODEL_TESTSTATUS,
      payload: { flag, fromContext, Nav },
    });
    if (flag) {
      make_api_call = true;
    }
    dispatch(
      StudentGradeTestCountAPI(flag, requestObj, AccessToken, make_api_call)
    );
  };
};
export const CancelTestStatusCSVModel = (flag, fromContext) => {
  return (dispatch) => {
    dispatch({
      type: CANCEL_TESTSTATUS_CSV_MODEL,
      payload: { flag, fromContext },
    });
  };
};
export const CSVCheckboxes = (value, standardORTestScore) => {
  return (dispatch) => {
    dispatch({
      type: CSV_CHECKBOXES,
      payload: { value, standardORTestScore },
    });
  };
};
const DrillDown_Summary_Module_For_Universal_reducer = (
  state,
  summaryGrade,
  Nav,
  fromContext,
  studentData,
  selectedTestGrade
) => {
  const { Summary_Roster_Data, Roster_Tab } = state.ContextHeader;
  let { selectedRosterGrade, GradesList, SelectedSchool } = Roster_Tab;
  const { district, school } = Nav;
  const schoolIsDifferent =
    school &&
    Summary_Roster_Data.SelectedSchool &&
    Summary_Roster_Data.SelectedSchool.id !== SelectedSchool.id;
  const gradeisDifferent =
    Summary_Roster_Data.selectedRosterGrade !== summaryGrade;

  let ClassList = [];
  let TeacherIds = [];
  let classIds = [];
  let StudentIds = [];
  let StudentList = [];

  let Context_Assessment_Roster = JSON.parse(
    JSON.stringify(Summary_Roster_Data)
  );
  let Universal_Assessment_Roster = {
    ...state.UniversalSelecter.Summary_Roster_Data,
  };

  // if (fromContext == "school") {
  //     Context_Assessment_Roster = JSON.parse(JSON.stringify(selectedRosterGrade));
  // } else {

  let NavigationByHeaderSelection = {
    ...state.NavigationByHeaderSelection,
    Assessement: true,
    Overview: true,
    S_performance: true,
    Summary_Reports: false,
    T_scores: false,
    test_status: false,
    summary: false,
    comparison: false,
    st_analysis: false,
  };
  if (schoolIsDifferent) {
    let ActiveSchool =
      Summary_Roster_Data.schoolsList &&
      Summary_Roster_Data.schoolsList.find(
        (item) => item.id == Summary_Roster_Data.SelectedSchool.id
      );
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      schoolsList: Summary_Roster_Data.schoolsList,
      SchoolIds: Summary_Roster_Data.SchoolIds,
      SelectedSchool: Summary_Roster_Data.SelectedSchool,
      // GradesList: ActiveSchool.grades
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      // ActualGrades: [...ActiveSchool.grades],
      ActualSchools: [...Summary_Roster_Data.schoolsList],
      schoolsList: [...Summary_Roster_Data.schoolsList],
      SelectedSchool: Summary_Roster_Data.SelectedSchool,
      // GradesList: [...ActiveSchool.grades],
      SchoolIds: Summary_Roster_Data.SchoolIds,
    };
    // GradesList = ActiveSchool.grades;
  }

  if (gradeisDifferent && !district) {
    let selectedGrade = Summary_Roster_Data.GradesList.find(
      (gradeItem) => gradeItem.grade === summaryGrade
    );
    const TeacherList = selectedGrade.teachers;

    let RosterDetailsOfAGrade = GetAllRosterDataOfA_Grade(
      selectedGrade,
      Summary_Roster_Data.GradesList
    );

    TeacherList.map((teacher) => {
      TeacherIds.push(teacher.id);
      teacher.check = true;
      teacher.classes.map((classItem) => {
        classItem.check = true;
        classIds.push(classItem.id);
        ClassList.push(classItem);
        let Student = classItem.students;
        Student &&
          Student.map((item) => {
            item.check = true;
            StudentIds.push(item.id);
            StudentList.push(item);
          });
      });
    });

    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
      StudentIds: StudentIds,
      StudentsList: StudentList,
      TeachersList: TeacherList,
      TeacherIds: TeacherIds,
      ClassList: [...ClassList],
      ClassIds: classIds,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: summaryGrade,
      ActualClasses: [...ClassList],
      ActualStudents: [...StudentList],
      ActualTeachers: [...TeacherList],
      ClassIds: classIds,
      ClassList: [...ClassList],
      SelectedClass: "All",
      SelectedStudent: "All",
      SelectedTeacher: "All",
      StudentIds: StudentIds,
      StudentsList: [...StudentList],
      TeacherIds: TeacherIds,
      TeachersList: [...TeacherList],
    };
  } else if (gradeisDifferent) {
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: summaryGrade,
    };
  }
  if (fromContext == "student") {
    let stdList = SortArrayBaseOnTrueOrFalse(
      check_Selected_item_Of_Array(
        Context_Assessment_Roster.StudentsList,
        studentData,
        "forstudent"
      )
    );

    let Teachers = check_Selected_item_Of_Array(
      Universal_Assessment_Roster.ActualTeachers,
      Context_Assessment_Roster.SelectedTeacher
    );

    let Classes = check_Selected_item_Of_Array(
      Universal_Assessment_Roster.ActualClasses,
      Context_Assessment_Roster.SelectedClass
    );

    let classTeacherRes = getClassAndTeacherOf_Student(Teachers, studentData);
    NavigationByHeaderSelection = {
      ...NavigationByHeaderSelection,
      class: false,
      student: true,
      Summary_Reports: false,
      Assessement: true,
    };
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      SelectedStudent: studentData,
      ActualStudents: stdList,
      StudentIds: [studentData.id],
      StudentsList: JSON.parse(JSON.stringify(stdList)),

      ClassList: JSON.parse(JSON.stringify(Classes)),
      TeachersList: JSON.parse(JSON.stringify(Teachers)),
      SelectedClass: classTeacherRes.selectedClass,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedStudent: studentData,
      ActualStudents: stdList,
      StudentIds: [studentData.id],
      StudentsList: JSON.parse(JSON.stringify(stdList)),

      ActualTeachers: JSON.parse(JSON.stringify(Teachers)),
      TeachersList: JSON.parse(JSON.stringify(Teachers)),
      ActualClasses: JSON.parse(JSON.stringify(Classes)),
      ClassList: JSON.parse(JSON.stringify(Classes)),
      SelectedClass: classTeacherRes.selectedClass,
    };
  }
  // }
  let callGetTests = gradeisDifferent || !(fromContext == "student");
  return {
    ...state,
    drillDownFromSummaryReports: true,
    ApiCalls: {
      ...state.ApiCalls,
      callGetTestsAfterLazyLoadSuccess:  callGetTests && state.lazyLoadingScreenInUniversal,
      getTests:callGetTests && !state.lazyLoadingScreenInUniversal,
      getStudentData_cls: fromContext == "student" ? true : false,
      getTestsAfterStd_Data: fromContext == "student" ? true : false,
      // Get_Student_TestScores :  fromContext == "student"?true:false,
    },
    NavigationByHeaderSelection: NavigationByHeaderSelection,
    ContextHeader: {
      ...state.ContextHeader,
      Roster_Tab: Context_Assessment_Roster,
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      Roster_Data: Universal_Assessment_Roster,
    },
  };
};

const DrillDown_Summary_Module_For_Reports_reducer = (
  store,
  selectedTaxonomy,
  standard,
  grade,
  Nav,
  fromContext
) => {
  let state_Strands = Nav.district
    ? store.DistrictReducer.D_StandardPerformance_Overview
    : Nav.school
    ? store.schoolReducer.Sc_StandardPerformance_Overview
    : fromContext == "class"
    ? store.Reports.StandardPerformance_Overview
    : store.StudentReports.S_StandardPerformance_Overview;

  if (fromContext == "class" || fromContext == "student") {
    state_Strands = {
      ...state_Strands,
      selected_Taxonomy_From_Compare: selectedTaxonomy,
      selectedStrand_From_Compare: standard,
      strandSelectedFromCompare: true,
    };
  }
  return {
    ...state_Strands,
    StrandNameOfSelectedStandard_to_persist: standard,
    StrandNameOfSelectedStandard: standard,
    StandardPerformanceFilter: {
      ...state_Strands.StandardPerformanceFilter,
      Taxonomy: {
        ...state_Strands.StandardPerformanceFilter.Taxonomy,
        selectedTaxonomy: selectedTaxonomy,
        taxonomyToPersist: selectedTaxonomy,
      },
    },
  };
};
export const SummaryCSV = (AccessToken, ReqPayload, flag, fromContext) => {
  let URL = DistrictAGPCSV;

  return (dispatch, getState) => {
    // dispatch({
    //     type: SUMMARY_CSV
    // })

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
        timeout: 0,
      })
      .then(function (response) {
        const { Universal } = getState();
        const { NavigationByHeaderSelection } = Universal;
        let context= "district";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        }
        dispatch({
          type: SUMMARY_CSV_SUCCESS,
          payload: { flag, fromContext },
        });
        dispatch(trackingUsage(`summary_csvdownload:${context}`));
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
const DrillDown_TSSummaryFor_Universal_reducer = (state, SelectedSumGrade) => {
  const { Summary_Roster_Data, Roster_Tab } = state.ContextHeader;
  let { selectedRosterGrade, GradesList, SelectedSchool } = Roster_Tab;
  const { district, school } = state.NavigationByHeaderSelection;

  let Nav = {
    ...state.NavigationByHeaderSelection,
    S_performance: false,
    Summary_Reports: false,
    //Overview: false,
    Assessement: true,
    test_status: true,
  };
  let Context_Assessment_Roster = JSON.parse(
    JSON.stringify(Summary_Roster_Data)
  );
  let Universal_Assessment_Roster = {
    ...state.UniversalSelecter.Summary_Roster_Data,
  };
  if (school || district) {
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: SelectedSumGrade,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: SelectedSumGrade,
    };
  }
  if (school || district) {
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: SelectedSumGrade,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: SelectedSumGrade,
    };
  }
  if (Nav.class && state.ContextHeader.User_Role !== "DISTRICT_ADMIN") {
    return {
      ...state,
      ...state,
      ApiCalls: {
        ...state.ApiCalls,
        getTests: true,
        get_complete_Student_Report: false,
      },
      NavigationByHeaderSelection: Nav,
      ContextHeader: {
        ...state.ContextHeader,
        Roster_Tab: {
          ...state.ContextHeader.Roster_Tab,
          SelectedClass: state.ContextHeader.Summary_Roster_Data.SelectedClass,
        },
      },
      UniversalSelecter: {
        ...state.UniversalSelecter,
        Roster_Data: {
          ...state.UniversalSelecter.Roster_Data,
          SelectedClass: state.UniversalSelecter.Roster_Data,
        },
      },
    };
  } else {
    return {
      ...state,
      ...state,
      ApiCalls: {
        ...state.ApiCalls,
        getTests: true,
        get_complete_Student_Report: false,
      },
      NavigationByHeaderSelection: Nav,
      ContextHeader: {
        ...state.ContextHeader,
        Roster_Tab: Context_Assessment_Roster,
      },
      UniversalSelecter: {
        ...state.UniversalSelecter,
        Roster_Data: Universal_Assessment_Roster,
      },
    };
  }
};
const DrillDownUniverasalSetup = (
  state,
  summaryGrade,
  Nav,
  fromContext,
  studentData
) => {
  const { Summary_Roster_Data, Roster_Tab } = state.ContextHeader;
  let { selectedRosterGrade, GradesList, SelectedSchool } = Roster_Tab;
  const { district, school } = Nav;
  const schoolIsDifferent =
    school &&
    Summary_Roster_Data.SelectedSchool &&
    Summary_Roster_Data.SelectedSchool.id !== SelectedSchool.id;
  const gradeisDifferent =
    Summary_Roster_Data.selectedRosterGrade !== summaryGrade;

  let ClassList = [];
  let TeacherIds = [];
  let classIds = [];
  let StudentIds = [];
  let StudentList = [];

  let Context_Assessment_Roster = JSON.parse(
    JSON.stringify(Summary_Roster_Data)
  );
  let Universal_Assessment_Roster = {
    ...state.UniversalSelecter.Summary_Roster_Data,
  };

  let NavigationByHeaderSelection = {
    ...state.NavigationByHeaderSelection,
    S_performance: false,
    Summary_Reports: false,
    Overview: false,
    Assessement: true,
    test_status: true,
    st_analysis: false,
    T_scores: false,
  };
  if (schoolIsDifferent) {
    let ActiveSchool =
      Summary_Roster_Data.schoolsList &&
      Summary_Roster_Data.schoolsList.find(
        (item) => item.id == Summary_Roster_Data.SelectedSchool.id
      );
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      schoolsList: Summary_Roster_Data.schoolsList,
      SchoolIds: Summary_Roster_Data.SchoolIds,
      SelectedSchool: Summary_Roster_Data.SelectedSchool,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,

      ActualSchools: [...Summary_Roster_Data.schoolsList],
      schoolsList: [...Summary_Roster_Data.schoolsList],
      SelectedSchool: Summary_Roster_Data.SelectedSchool,
      SchoolIds: Summary_Roster_Data.SchoolIds,
    };
  }

  if (gradeisDifferent && !district) {
    let selectedGrade = Summary_Roster_Data.GradesList.find(
      (gradeItem) => gradeItem.grade === summaryGrade
    );
    const TeacherList = selectedGrade && selectedGrade.teachers;

    let RosterDetailsOfAGrade = GetAllRosterDataOfA_Grade(
      selectedGrade,
      Summary_Roster_Data.GradesList
    );

    TeacherList &&
      TeacherList.map((teacher) => {
        TeacherIds.push(teacher.id);
        teacher.check = true;
        teacher.classes.map((classItem) => {
          classItem.check = true;
          classIds.push(classItem.id);
          ClassList.push(classItem);
          let Student = classItem.students;
          Student &&
            Student.map((item) => {
              item.check = true;
              StudentIds.push(item.id);
              StudentList.push(item);
            });
        });
      });

    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
      StudentIds: StudentIds,
      StudentsList: StudentList,
      TeachersList: TeacherList,
      TeacherIds: TeacherIds,
      ClassList: [...ClassList],
      ClassIds: classIds,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: summaryGrade,
      ActualClasses: [...ClassList],
      ActualStudents: [...StudentList],
      ActualTeachers: [...TeacherList],
      ClassIds: classIds,
      ClassList: [...ClassList],
      SelectedClass: "All",
      SelectedStudent: "All",
      SelectedTeacher: "All",
      StudentIds: StudentIds,
      StudentsList: [...StudentList],
      TeacherIds: TeacherIds,
      TeachersList: [...TeacherList],
    };
  } else if (gradeisDifferent) {
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: summaryGrade,
    };
  }
  if (fromContext == "student") {
    let stdList = SortArrayBaseOnTrueOrFalse(
      check_Selected_item_Of_Array(
        Context_Assessment_Roster.StudentsList,
        studentData,
        "forstudent"
      )
    );

    let Teachers = check_Selected_item_Of_Array(
      Universal_Assessment_Roster.ActualTeachers,
      Context_Assessment_Roster.SelectedTeacher
    );

    let Classes = check_Selected_item_Of_Array(
      Universal_Assessment_Roster.ActualClasses,
      Context_Assessment_Roster.SelectedClass
    );

    let classTeacherRes = getClassAndTeacherOf_Student(Teachers, studentData);
    NavigationByHeaderSelection = {
      ...NavigationByHeaderSelection,
      class: false,
      student: true,
      Summary_Reports: false,
      Assessement: true,
    };
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      SelectedStudent: studentData,
      ActualStudents: stdList,
      StudentIds: [studentData.id],
      StudentsList: JSON.parse(JSON.stringify(stdList)),

      ClassList: JSON.parse(JSON.stringify(Classes)),
      TeachersList: JSON.parse(JSON.stringify(Teachers)),
      SelectedClass: classTeacherRes.selectedClass,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedStudent: studentData,
      ActualStudents: stdList,
      StudentIds: [studentData.id],
      StudentsList: JSON.parse(JSON.stringify(stdList)),

      ActualTeachers: JSON.parse(JSON.stringify(Teachers)),
      TeachersList: JSON.parse(JSON.stringify(Teachers)),
      ActualClasses: JSON.parse(JSON.stringify(Classes)),
      ClassList: JSON.parse(JSON.stringify(Classes)),
      SelectedClass: classTeacherRes.selectedClass,
    };
  }
  // }
  return {
    ...state,
    ...state,
    ApiCalls: {
      ...state.ApiCalls,
      getTests: true,
      get_complete_Student_Report: false,
    },
    NavigationByHeaderSelection: NavigationByHeaderSelection,
    ContextHeader: {
      ...state.ContextHeader,
      Roster_Tab: Context_Assessment_Roster,
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      Roster_Data: Universal_Assessment_Roster,
    },
  };
};

export const Get_PDF_Details = (AccessToken, ReqPayload, Nav) => {
  let URL = SPOT_PDF_DOWNLOAD;
  return (dispatch, getState) => {
    dispatch({
      type: GET_SUMMARY_SP_PDF_DATA,
      payload: {
        Nav,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    let headers_pdf = {
      "Access-Control-Allow-Origin": "*",
      Authorization: "Bearer ".concat(AccessToken),
    };
    axios
      .post(URL, ReqPayload, {
        headers: headers_pdf,
        responseType: "blob",
      })
      .then(function (response) {
        const { Universal } = getState();
        const { NavigationByHeaderSelection } = Universal;
        let fileName = "district summary SP immidiate.pdf";
        if (
          NavigationByHeaderSelection.school &&
          NavigationByHeaderSelection.S_performance
        ) {
          fileName = "school summary SP immidiate.pdf";
        } else if (
          NavigationByHeaderSelection.class &&
          NavigationByHeaderSelection.S_performance
        ) {
          fileName = "class summary SP immidiate.pdf";
        } else if (
          NavigationByHeaderSelection.student &&
          NavigationByHeaderSelection.S_performance
        ) {
          fileName = "student summary SP immidiate.pdf";
        }
        let ResPayload = response.data;

        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        let context= "district";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        }  else if(NavigationByHeaderSelection.class)
        {
        context = "class";
        } else if(NavigationByHeaderSelection.student)
        {
        context = "student";
        }
        dispatch({
          type: GET_SUMMARY_SP_PDF_DATA_SUCCESS,
          payload: { ResPayload,Nav },
        });
        dispatch(trackingUsage(`summaryreports_standardperformancepdf:${context}`));
      })
      .catch(function (error) {
          dispatch(postErrorLog(AccessToken, error, seconds_Start));
          let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
          dispatch({
            type: GET_SUMMARY_SP_PDF_DATA_FAIL,
            payload: { Nav },
          });
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
export const DownloadTSPDF = (AccessToken, ReqPayload, Nav) => {
  let URL = SPOT_PDF_DOWNLOAD;
  return (dispatch, getState) => {
    dispatch({
      type: DOWNLOAD_TS_PDF,
      payload: {
        Nav,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    let headers_pdf = {
      "Access-Control-Allow-Origin": "*",
      Authorization: "Bearer ".concat(AccessToken),
    };
    axios
      .post(URL, ReqPayload, {
        headers: headers_pdf,
        responseType: "blob",
      })
      .then(function (response) {
        const { Universal } = getState();
        const { NavigationByHeaderSelection } = Universal;
        let fileName = "District summary TestStatus.pdf";
        if (
          NavigationByHeaderSelection.school &&
          NavigationByHeaderSelection.S_performance
        ) {
          fileName = "School summary TestStatus.pdf";
        } else if (
          NavigationByHeaderSelection.class &&
          NavigationByHeaderSelection.S_performance
        ) {
          fileName = "Class summary TestStatus.pdf";
        }
        let ResPayload = response.data;

        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", fileName);
        document.body.appendChild(link);
        link.click();
        let context= "district";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        }  else if(NavigationByHeaderSelection.class)
        {
        context = "class";
        } else if(NavigationByHeaderSelection.student)
        {
        context = "student";
        }
      dispatch({
          type: DOWNLOAD_TS_PDF_SUCCESS,
          payload: { ResPayload,Nav },
        });
        dispatch(trackingUsage(`summaryreports_teststatuspdf:${context}`))
      })
      .catch(function (error) {
          dispatch(postErrorLog(AccessToken, error, seconds_Start));
          let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode }
        });
      });
  };
};
export const getGradeList = (AccessToken, ReqPayload, fromContext) => {

  let URL = Base_URL + `${fromContext}/standardperformance/grades`;
  // if(fromContext === "district" ){
  // URL = "https://jsonplaceholder.typicode.com/posts";
  // }
  return (dispatch) => {
    // if(fromContext === "class" ){
     
      dispatch({
        type: SUMMARY_TESTGRADES,
        payload: {
          fromContext
        }
      });
    // }

  let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios.post(URL, ReqPayload, {
      headers: api_request_headers,
      timeout: 0,
    }).then(function (response) {
        let PayloadData = response.data.value;

        PayloadData = PayloadData == null ? [] : PayloadData;
        dispatch({
          type: SUMMARY_TESTGRADES_SUCCESS,
          payload: {
            PayloadData,fromContext
          }
        });

        // }
      })
      .catch(function (error) {
        //dispatch(postErrorLog(AccessToken, error, seconds_Start));
      });
  };
};
export const DrillDownFromSchoolAndDistrict = (
  grade,
  fromContext,
  selectedTaxonomy
) => {
  return (dispatch, getState) => {
    let Nav = getState().Universal.NavigationByHeaderSelection;
    let selectedRosterGrade = getState().Universal.ContextHeader.Roster_Tab.selectedRosterGrade
   let universalState = School_District_DrillDown_Universal_function(
      getState().Universal,
      grade,
      Nav,
      fromContext
    );
    let issameGrade=  false;
    if(selectedRosterGrade == grade){
      issameGrade = true;
    }
    dispatch({
      type: DRILLDOWN_FROM_SCHOOL_DISTRICT,
      payload: { universalState, Nav, fromContext,selectedTaxonomy,grade,issameGrade }
    });
  };
};
export const School_District_DrillDown_Universal_function = (
  state,
  summaryGrade,
  Nav,
  fromContext
) => {
  const { Summary_Roster_Data, Roster_Tab } = state.ContextHeader;
  let { selectedRosterGrade, GradesList, SelectedSchool } = Roster_Tab;
  const { district, school } = Nav;
  const schoolIsDifferent =
    school &&
    Summary_Roster_Data.SelectedSchool &&
    Summary_Roster_Data.SelectedSchool.id !== SelectedSchool.id;
  const gradeisDifferent =
  selectedRosterGrade !== summaryGrade;

  let ClassList = [];
  let TeacherIds = [];
  let classIds = [];
  let StudentIds = [];
  let StudentList = [];

  let Context_Assessment_Roster = JSON.parse(
    JSON.stringify(Summary_Roster_Data)
  );
  let Universal_Assessment_Roster = {
    ...state.UniversalSelecter.Summary_Roster_Data,
  };

  let NavigationByHeaderSelection = {
    ...state.NavigationByHeaderSelection,
    Assessement: true,
    Overview: true,
    S_performance: true,
    Summary_Reports: false,
    T_scores: false,
    test_status: false,
    summary: false,
    comparison: false,
    st_analysis: false,
  };
  if (schoolIsDifferent) {
    let ActiveSchool =
      Summary_Roster_Data.schoolsList &&
      Summary_Roster_Data.schoolsList.find(
        (item) => item.id == Summary_Roster_Data.SelectedSchool.id
      );
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      schoolsList: Summary_Roster_Data.schoolsList,
      SchoolIds: Summary_Roster_Data.SchoolIds,
      SelectedSchool: Summary_Roster_Data.SelectedSchool,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      ActualSchools: [...Summary_Roster_Data.schoolsList],
      schoolsList: [...Summary_Roster_Data.schoolsList],
      SelectedSchool: Summary_Roster_Data.SelectedSchool,
      SchoolIds: Summary_Roster_Data.SchoolIds,
    };

  }

  if (gradeisDifferent && !district) {
    let selectedGrade = Summary_Roster_Data.GradesList.find(
      (gradeItem) => gradeItem.grade === summaryGrade
    );
    const TeacherList = selectedGrade.teachers;

    let RosterDetailsOfAGrade = GetAllRosterDataOfA_Grade(
      selectedGrade,
      Summary_Roster_Data.GradesList
    );

    TeacherList.map((teacher) => {
      TeacherIds.push(teacher.id);
      teacher.check = true;
      teacher.classes.map((classItem) => {
        classItem.check = true;
        classIds.push(classItem.id);
        ClassList.push(classItem);
        let Student = classItem.students;
        Student &&
          Student.map((item) => {
            item.check = true;
            StudentIds.push(item.id);
            StudentList.push(item);
          });
      });
    });

    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
      StudentIds: StudentIds,
      StudentsList: StudentList,
      TeachersList: TeacherList,
      TeacherIds: TeacherIds,
      ClassList: [...ClassList],
      ClassIds: classIds,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: summaryGrade,
      ActualClasses: [...ClassList],
      ActualStudents: [...StudentList],
      ActualTeachers: [...TeacherList],
      ClassIds: classIds,
      ClassList: [...ClassList],
      SelectedClass: "All",
      SelectedStudent: "All",
      SelectedTeacher: "All",
      StudentIds: StudentIds,
      StudentsList: [...StudentList],
      TeacherIds: TeacherIds,
      TeachersList: [...TeacherList],
    };
  } else if (gradeisDifferent) {
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
    };
    Universal_Assessment_Roster = {
      ...Universal_Assessment_Roster,
      SelectedGrade: summaryGrade,
    };
  }
  if(Context_Assessment_Roster.selectedRosterGrade == "All" && !gradeisDifferent){
    Context_Assessment_Roster = {
      ...Context_Assessment_Roster,
      selectedRosterGrade: summaryGrade,
    };
  }
  let callGetTests = gradeisDifferent;
  return {
    ...state,
    drillDownFromSummaryReports: true,
    ApiCalls: {
      ...state.ApiCalls,
      callGetTestsAfterLazyLoadSuccess:  callGetTests && state.lazyLoadingScreenInUniversal,
      getTests:callGetTests && !state.lazyLoadingScreenInUniversal,
      getStudentData_cls: fromContext == "student" ? true : false,
      getTestsAfterStd_Data: fromContext == "student" ? true : false,
    },
    NavigationByHeaderSelection: NavigationByHeaderSelection,
    ContextHeader: {
      ...state.ContextHeader,
      Roster_Tab: Context_Assessment_Roster,
    },
    UniversalSelecter: {
      ...state.UniversalSelecter,
      Roster_Data: Universal_Assessment_Roster,
    },
  };
};