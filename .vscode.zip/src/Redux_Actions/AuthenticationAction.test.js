import { expect } from 'chai';
import * as AuthenticationAction from '../Redux_Actions/AuthenticationAction';
import * as AuthenticationTypes from '../Reducer_Action_Types/AuthenticationTypes';
import axios from 'axios';
jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});


describe("Authentication actions", () =>{
  afterEach(() => {
    jest.clearAllMocks();
  });
it("DisplayNoDataView action returns the expeted object ", ()=>{
  const dispatch = jest.fn();
  AuthenticationAction.DisplayNoDataView()(dispatch);
  expect(dispatch.mock.calls.length).to.equal(1);
  expect(dispatch.mock.calls[0][0]).to.eql({  type: AuthenticationTypes.AuthActionTypes.DISPLAY_NO_DATA_COMPO});
});

it("SaveUserNameAndPass action returns the expeted object ", ()=>{
  const dispatch = jest.fn();
  AuthenticationAction.SaveUserNameAndPass("Krish","username")(dispatch);
  expect(dispatch.mock.calls.length).to.equal(1);
  expect(dispatch.mock.calls[0][0]).to.eql({  type: AuthenticationTypes.AuthActionTypes.SAVE_USERNAME_AND_PASSWORD, payload: { value :"Krish", fromfield:"username" }});
});

it("TakeMeBackOnNodataComp action returns the expeted object ", ()=>{
  const dispatch = jest.fn();
  AuthenticationAction.TakeMeBackOnNodataComp()(dispatch);
  expect(dispatch.mock.calls.length).to.equal(1);
  expect(dispatch.mock.calls[0][0]).to.eql({  type: AuthenticationTypes.AuthActionTypes.TAKE_ME_BACK_IN_NODATA_COMP});
});


it("Reset_state_in_all_reducers action returns the expeted object ", ()=>{
  const dispatch = jest.fn();
  AuthenticationAction.Reset_state_in_all_reducers()(dispatch);
  expect(dispatch.mock.calls.length).to.equal(1);
  expect(dispatch.mock.calls[0][0]).to.eql({  type: AuthenticationTypes.AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS});
});

// it("Get_JWTToken_Authentication Success action returns the expeted object ", async ()=>{
 
// const dispatch = jest.fn();
//     const mockResponseData = jest.fn((Response_Data) => {
//     return {
//       data: Response_Data,         
//     };
//     });    
//     const users = mockResponseData(200);

//     axios.post.mockImplementationOnce(() => {
//       return Promise.resolve(users);
//     });
//     try {
//         await AuthenticationAction.Get_JWTToken_Authentication( "Krish", "password", "realm")(dispatch);
//         expect(dispatch.mock.calls.length).to.equal(2);
//         expect(dispatch.mock.calls[0][0]).to.eql({  type: AuthenticationTypes.AuthActionTypes.POST_CREATE_JWT_TOKEN})
//         expect(dispatch.mock.calls[1][0]).to.eql({ type: AuthenticationTypes.AuthActionTypes.POST_CREATE_JWT_TOKEN_SUCCESS, payload: { Response_Data :200, username: "Krish", password: "password" } });
//     }catch (err) {
//       await AuthenticationAction.Get_JWTToken_Authentication( "", "", "realm").toThrow(TypeError)(dispatch);
//       expect(dispatch.mock.calls.length).to.equal(0);
//       // expect(dispatch.mock.calls[1][0]).to.eql({ type: AuthenticationTypes.AuthActionTypes.POST_CREATE_JWT_TOKEN_SUCCESS, payload: { Response_Data :200, username: "Krish", password: "password" } });
//     }

// });


/* it("postErrorLog  action returns the expeted object ", async ()=>{

   const t = () => {
    throw new TypeError("UNKNOWN ERROR");
  };
  expect(t).throw(TypeError);
  expect(t).throw("UNKNOWN ERROR"); 
 
    const dispatch = jest.fn();
    const mockAccessToken = "thisisatoken";
    const diffTime= 95;
    const url ="url";
    const statusCode= 504;
    const secondsStart ="10:52:00";
    let error = {
                    message: "request param missing",
                            role: null,
                            status: "FAILED",
                            statusCode: 500,
                            statusDescription: "Internal server error",
                            userId: null,
                            value: null,
                };
    const mockResponseData = jest.fn((Response_Data) => {
    return {
      data: Response_Data,         
    };
  });
    const users = mockResponseData(200);

   axios.post.mockImplementationOnce(() => {
      return Promise.resolve(users);
    });
try {
  console.log("error", error.message);
    await AuthenticationAction.postErrorLog( mockAccessToken,error, secondsStart)(dispatch);
    expect(dispatch.mock.calls.length).to.equal(2);
    expect(dispatch.mock.calls[0][0]).to.eql({  type: AuthenticationTypes.AuthActionTypes.ERROR_LOG})
     expect(dispatch.mock.calls[1][0]).to.eql({ type: AuthenticationTypes.AuthActionTypes.ERROR_LOG_SUCCESS, payload: { Response_Data :200} });
}catch (err) {
  await AuthenticationAction.postErrorLog( "", null, null).toThrow(TypeError)(dispatch);
 }

}); */

});