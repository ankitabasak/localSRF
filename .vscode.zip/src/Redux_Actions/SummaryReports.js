import { STANDARDPERFORMANCE_SUMMARYREPORTS_API, STANDARDPERFORMANCE_SUMMARYREPORTS_API_SUCCESS } from "../Reducer_Action_Types/summaryReports_Action_Types"
import { REHYDRATE } from "redux-persist";


export const DefaultStateProps = {

    district: {
        assessments: {
            apiCalls: {
                strandsApi: false,
                loadingOnStrands: false,
            },
            standardperformance: {
                data: {},
                taxonomyList: [],
                selectedTaxonomy: '',
                HeaderStrands: {},
                gradeDetails: {}
            },
            testStatus: {

            }
        }

    },
    school: {

    },
    class: {

    }, student: {

    }

}


export default (state = DefaultStateProps, action) => {
    switch (action.type) {

        case REHYDRATE:
            return DefaultStateProps;

        case STANDARDPERFORMANCE_SUMMARYREPORTS_API:
            return {
                ...state, district: {
                    ...state.district,
                    assessments: {
                        ...state.district.assessments,
                        apiCalls: {
                            ...state.district.assessments.apiCalls,
                            strandsApi: false,
                            loadingOnStrands: true,
                        },
                    }
                }
            }


        case STANDARDPERFORMANCE_SUMMARYREPORTS_API_SUCCESS:
            return {
                ...state,
                district: {
                    ...state.district,
                    assessments: {
                        ...state.district.assessments,
                        apiCalls: {
                            ...state.district.assessments.apiCalls,
                            loadingOnStrands: false,
                        },
                        standardperformance: {
                            ...state.district.assessments.standardperformance,
                            ...state.district.assessments.standardperformance,

                            taxonomyList: action.payload.TaxonomyList,
                            data: action.payload.Data && action.payload.Data.viewDetails,
                            selectedTaxonomy: action.payload.selectedStrands,
                            HeaderStrands: action.payload.HeaderStrands,
                            gradeDetails: action.payload.gradeDetails
                        }
                    }
                }
            }

        default:
            return {
                ...state
            }

    }
} 