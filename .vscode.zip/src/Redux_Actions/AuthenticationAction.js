import { AuthActionTypes } from '../Reducer_Action_Types/AuthenticationTypes';
import {

  Get_JWT_Token,
  api_request_headers, ERROR_LOG_API, Base_URL
} from '../Utils/globalVars';
import axios from 'axios';
import { U_S_Action_Types } from '../Reducer_Action_Types/UniversalSelectorActionTypes';
import { getRealmFromURL } from '../Components/ReusableComponents/AllReusableFunctions';

export const DisplayNoDataView = () => {
  return dispatch => {
    dispatch({
      type: AuthActionTypes.DISPLAY_NO_DATA_COMPO
    });
  };
};

export const SaveUserNameAndPass = (value, fromfield) => {
  return dispatch => {
    dispatch({
      type: AuthActionTypes.SAVE_USERNAME_AND_PASSWORD,
      payload: { value, fromfield }
    });
  };
};

/**
 *
 * @param {object } Auth_Details  -- logIn Details Of User
 * @param { string }  username
 * @param {string} password
 */
export const Get_JWTToken_Authentication = (
  username,
  password,
  realm
) => {
  let AuthURL = Get_JWT_Token;

  let Payload = {
    username: username || 'superadmin',
    password: password || 'password',
    realm: realm || 'techsupport'
    // realm:'saaseng'
  };

  return dispatch => {
    dispatch({

      type: AuthActionTypes.POST_CREATE_JWT_TOKEN
    });
    axios
      .post(AuthURL, Payload, {
        headers: {
          responseType: 'application/json;charset=UTF-8'
        }
      })
      .then(function (response) {
        let Response_Data = response.data;
        dispatch({
          type: AuthActionTypes.POST_CREATE_JWT_TOKEN_SUCCESS,
          payload: { Response_Data, username, password }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: AuthActionTypes.POST_CREATE_JWT_TOKEN_FAIL,
          payload: statusCode
        });
      });
  };
};

export const TakeMeBackOnNodataComp = () => {
  return (dispatch) => {
    dispatch({
      type: AuthActionTypes.TAKE_ME_BACK_IN_NODATA_COMP,
    })
  }
}

export const Reset_state_in_all_reducers = () => {
  return (dispatch) => {
    dispatch({
      type: AuthActionTypes.RESET_REDUCERS_STATE_IN_ALL_REDUCERS
    })
  }
}
export const postErrorLog = (AccessToken, error, secondsStart) => {
  let URL = ERROR_LOG_API;
  let message = error != undefined && error.response != undefined && error.response.data != undefined ? error.response.data.errorMessage : "";
  let description = error != undefined && error.response != undefined && error.response.data != undefined ? error.response.data.statusDescription : "";
  let statusCode = error != undefined && error.response != undefined && error.response.status != undefined ? error.response.status : "";
  let ErrorUrl = error != undefined && error.config != undefined && error.config.url != undefined ? error.config.url : "";
  let secondsEnd = new Date().getTime() / 1000;
  let realm = getRealmFromURL(window.location.href)
  let diffTime = secondsEnd - secondsStart;

  statusCode = error.message == 'Network Error' && diffTime < 90 ? "" : error.response == undefined ? 504 : error.response.status

  if (statusCode && message == "") {
    message = "Timeout error";
    description = "90 seconds limit exceded";
  }
  let ReqPayload = {
    "application": "Assessment Reporting",
    "code": statusCode,
    "exception": description,
    "trace": ErrorUrl + " " + (message !== "" && message != null ? ", " + message : message),
    "platform": navigator.appVersion,
    "realm": realm,
    "data": null
  };
  return (dispatch, getState) => {
    const { Universal } = getState();
    const { ContextHeader } = Universal;
    ReqPayload.userId = ContextHeader.Default_UserId != undefined && ContextHeader.Default_UserId != '' ? ContextHeader.Default_UserId : 0;
    dispatch({
      type: AuthActionTypes.ERROR_LOG,
    })
    api_request_headers.Authorization = 'Bearer '.concat(AccessToken);
    axios.post(URL, ReqPayload, {
      headers: api_request_headers,
    }
    ).then(function (response) {
      let ResPayload = response.data.value
      dispatch({
        type: AuthActionTypes.ERROR_LOG_SUCCESS,
        payload: ResPayload
      })
    }).catch(function (error) {
    });
  }
}

// tracking the usage 
export const trackingUsage = (on) => {


  let BaseEnv =  Base_URL && Base_URL.substring(
  Base_URL.lastIndexOf("buapi-") + 6, 
  Base_URL.lastIndexOf(".benchmarkuniverse"));
  let env = BaseEnv; 
  if(BaseEnv == "prod"){
    env = "production";
  }
return (dispatch, getState) => {
const { Universal } = getState();
const { ContextHeader } = Universal;
let sid = "dbd133971567b7eeb8ca3e319b0cd8ba36ce9edd";
if(env == "qa" || env == "staging" || env == "production"){
const LocalStorgae = localStorage.getItem('persist:benchmarkuniverse');
let parsedObject = JSON.parse(LocalStorgae);
let notnullcheck = parsedObject && Object.keys(parsedObject.auth).length == 0;
let auth =  !notnullcheck && parsedObject && parsedObject.auth != null && JSON.parse(parsedObject.auth)
if(parsedObject && auth && auth.sid && auth.sid != undefined && auth.sid !=""){
  const url = `https://maple-${env}.benchmarkuniverse.com/event/receive?sid=${auth.sid}`;
  axios
    .post(url, {
      actor: ContextHeader.Default_UserId,
      verb: "click",
      on: on,
    })
    .then((response) => {
      dispatch({
        type: AuthActionTypes.TRACKING_USAGE,
      });
    });
  }
}else{
  const url = `https://maple-${env}.benchmarkuniverse.com/event/receive?sid=${sid}`;
  axios
  .post(url, {
    actor: ContextHeader.Default_UserId,
    verb: "click",
    on: on,
  })
  .then((response) => {

    dispatch({
      type: AuthActionTypes.TRACKING_USAGE,
    });
  });
}


};
};