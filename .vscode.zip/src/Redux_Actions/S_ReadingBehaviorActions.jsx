import { S_RBTypes } from '../Reducer_Action_Types/S_ReadingBehaviorTypes.jsx';
import { ORR_URL, Student_Reading_Behavior, CSV_DOWNLOAD_STUDENT } from '../Utils/globalVars';
import axios from 'axios';

/**
 *
 * @param {object }
 */
export const S_RB_API_CALL = (AccessToken, payLoad, value) => {
  let AuthURL = ORR_URL + Student_Reading_Behavior;

  return dispatch => {
    dispatch({
      type: S_RBTypes.SRB_LOADER,
    })
    axios
      .post(AuthURL, payLoad, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: S_RBTypes.S_READING_BEHAVIOR_API_SUCCESS,
          payload: Response,
          value: value
        });
      })
      .catch(function (error) {
        if (error.response) {
          if (error.response.data.errorCode === 407) {
            dispatch({
              type: S_RBTypes.SRB_RUBRIC_FAIL,
              payload: error.response.data.errorMessage
            });
          }
          else {
            dispatch({
              type: S_RBTypes.S_READING_BEHAVIOR_API_FAIL,
              payload: null
            });
          }
        } else {
          dispatch({
            type: S_RBTypes.S_READING_BEHAVIOR_API_FAIL,
            payload: null
          });
        }

      });
  };
};

//show and collapse class bar
export const SHOW_HIDE_BAR = (state, index) => {
  let data = state;
  data[index] = !data[index];
  return dispatch => {
    dispatch({
      type: S_RBTypes.SHOW_RUBRIC_DATA,
      payload: data
    });
  };
};

//error handling action
export const SRB_ERROR_HANDLING = obj => {
  return dispatch => {
    dispatch({
      type: S_RBTypes.SRB_EH,
      payload: obj
    });
  };
};

//function to scroll data
export const SRB_SCROLL = data => {
  return dispatch => {
    dispatch({
      type: S_RBTypes.SRB_DATA_SCROLL,
      payload: data
    });
  };
};

export const SRB_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: S_RBTypes.SRB_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SRB_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_STUDENT;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: S_RBTypes.SRB_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: S_RBTypes.S_READING_BEHAVIOR_API_FAIL,
          payload: statusCode
        });
      });
  };
};