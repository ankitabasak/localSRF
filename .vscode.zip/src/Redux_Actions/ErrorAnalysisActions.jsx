import { ErrorAnalysisActionTypes } from '../Reducer_Action_Types/ErrorAnalysisActionTypes.jsx';
import axios from 'axios';
import {
  Student_Error_Analysis_API,
  ORR_URL,
  dummyToken,
  CSV_DOWNLOAD_STUDENT
} from '../Utils/globalVars';

/**
 * @param {object } readingHistoryFilterData
 * @param { string }  externalFilter
 * @param {string} internalFilter
 */
export const ERROR_ANALYSIS_STUDENT_DATA = (AccessToken, payLoad, value) => {
  let AuthURL = ORR_URL + Student_Error_Analysis_API;
  let dummyToken;
  let Payload = {
    filters: payLoad
  };

  return dispatch => {
    dispatch({
      type: ErrorAnalysisActionTypes.SEA_LOADER,
    })

    axios
      .post(AuthURL, Payload, {
        headers: {
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;
        dispatch({
          type: ErrorAnalysisActionTypes.ERROR_ANALYSIS_STUDENT_DATA_SUCCESS,
          payload: Response_Data,
          value: value
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: ErrorAnalysisActionTypes.ERROR_ANALYSIS_STUDENT_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

export const SEA_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: ErrorAnalysisActionTypes.SEA_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SEA_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_STUDENT;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: ErrorAnalysisActionTypes.SEA_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: ErrorAnalysisActionTypes.ERROR_ANALYSIS_STUDENT_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

//EA scroll action
export const scroll_Ea = (data, date, firstIndex, lastIndex) => {
  return dispatch => {
    dispatch({
      type: ErrorAnalysisActionTypes.SCROLL_DATA,
      payload: { data, date, firstIndex, lastIndex }
    });
  };
};

//EA icon change
export const iconUpdate = data => {
  return dispatch => {
    dispatch({
      type: ErrorAnalysisActionTypes.ICON_UPDATE,
      payload: data
    });
  };
};

export const STUDENT_EA_ERRORHANDLING = obj => {
  return dispatch => {
    dispatch({
      type: ErrorAnalysisActionTypes.SEA_ERROR_HANDLING,
      payload: obj
    });
  };
};

export const pieChartState = obj => {
  return dispatch => {
    dispatch({
      type: ErrorAnalysisActionTypes.PIE_CHART_STATE_UPDATE,
      payLoad: obj
    });
  };
};
