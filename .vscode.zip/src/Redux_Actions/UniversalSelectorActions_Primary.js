import {
  U_S_Action_Types,
  ONGOTO_ST_ANALYSIS_ACTION,
  DRILLDOWN_TO_STUDENT_TESTSTATUS_FROMCLASS,
  DRILLDOWN_TO_CLASS_TESTSTATUS,
  DRILLDOWN_TO_SCHOOL_TESTSTATUS,
  MOVE_TO_SINGLE_TEST_FROM_TEST_STATUS,
  SAVE_SELECTED_STUDENT_DATA,
  STUDENTDATA_INFO_ICON,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import {
  DrillDownTo_Class_TestStatus,
  DrillDownTo_School_TestStatus,
  MoveToSingleTest_TestStatus,
} from "../Redux_Reducers/Reducers_Functions_To_Return_State";
import { DrillDownToStudent_FromTestStatus } from "../services/universalSelector/universalSelector_3";

export const SaveTestDataAfterSorting = (A_List, S_Column, S_Type) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_DATA_AFTER_SORTING_IN_TEST_TAB,
      payload: { A_List, S_Column, S_Type },
    });
  };
};

export const StoreFilteredListInRoster = (list, listType, Searchvalue) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_FILTERED_LIST_IN_ROSTER,
      payload: { list, listType, Searchvalue },
    });
  };
};

export const SaveSelected_RosterGrade = (grade) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_GRADES,
      payload: grade,
    });
  };
};

export const SaveSelectedTeacher = (teacher, idx, check) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_TEACHERS,
      payload: {
        teacher,
        idx,
        check,
      },
    });
  };
};

export const SaveSelectedStudent = (Student, Indx, check) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_STUDENT,
      payload: {
        Student,
        Indx,
        check,
      },
    });
  };
};

export const SaveSelected_CLass = (ClassObj, Indx, check) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.SAVE_SELECTED_CLASSES,
      payload: {
        ClassObj,
        Indx,
        check,
      },
    });
  };
};

export const ChangePaginationBubble = (
  BubbleStart,
  positionfrom_BubbleStart,
  CountPerPage
) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.CHANGE_PAGINATION_BUBBLE,
      payload: { BubbleStart, positionfrom_BubbleStart, CountPerPage },
    });
  };
};

export const MovePaginationDisplayBubbles = (motion) => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.MOVE_PAGINATION_DISPLAY_BUBBLES,
      payload: motion,
    });
  };
};

export const OnGoTo_ST_Analysis = () => {
  return (dispatch) => {
    dispatch({
      type: ONGOTO_ST_ANALYSIS_ACTION,
      // payload: motion
    });
  };
};
export const DoneInTestTypeView = () => {
  return (dispatch) => {
    dispatch({
      type: U_S_Action_Types.DONE_IN_TEST_TYPE_UI,
    });
  };
};

export const DrillDownToStudent_TestStatus_FromClass = (sele_student) => {
  return (dispatch, getState) => {
    let Uni_STate = getState().Universal;

    let { Universal, LastActiveUniversalProps } = getState();

    let payload = {
      sele_student,Uni_STate
    };
    let action = {
      payload,
    };
    let { updatedLastActivePropsState, updatedUniversalState } =
      DrillDownToStudent_FromTestStatus(
        Universal,
        action,
        LastActiveUniversalProps
      );

    // let U_State = DrillDownToStudent_FromTestStatus(Uni_STate, student);

    dispatch({
      type: DRILLDOWN_TO_STUDENT_TESTSTATUS_FROMCLASS,
      payload: { updatedLastActivePropsState, updatedUniversalState,sele_student ,Uni_STate},
    });
  };
};

export const DrillDownToClass_TestStatus = (Sel_class) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState();

    let U_State = DrillDownTo_Class_TestStatus(
      Universal,
      Sel_class,
      LastActiveUniversalProps
    );

    dispatch({
      type: DRILLDOWN_TO_CLASS_TESTSTATUS,
      payload: { U_State },
    });
  };
};

export const DrillDownToSchool_TestStatus = (Sel_school) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState();

    let U_State = DrillDownTo_School_TestStatus(
      Universal,
      Sel_school,
      LastActiveUniversalProps
    );

    dispatch({
      type: DRILLDOWN_TO_SCHOOL_TESTSTATUS,
      payload: { U_State, LastActiveUniversalProps },
    });
  };
};

export const MoveToSingleTestFromTestStaus = (option, singleGroup) => {
  return (dispatch, getState) => {
    let { Universal, LastActiveUniversalProps } = getState().Universal;

    let U_State = MoveToSingleTest_TestStatus(
      Universal,
      option,
      singleGroup,
      LastActiveUniversalProps
    );

    dispatch({
      type: MOVE_TO_SINGLE_TEST_FROM_TEST_STATUS,
      payload: { U_State },
    });
  };
};

/**
 *
 * @param {Object} ClassObj
 * @param {Int} Indx
 * @param {Boolean} check
 * Action to save selected class details
 */

export const SaveSelected_StudentData = (ClassObj, Indx, check) => {
  return (dispatch) => {
    dispatch({
      type: SAVE_SELECTED_STUDENT_DATA,
      payload: {
        ClassObj,
        Indx,
        check,
      },
    });
  };
};

export const ClickStudentDataInfoIcon = (infoFor) => {
  return (dispatch) => {
    dispatch({
      type: STUDENTDATA_INFO_ICON,
      payload: infoFor,
    });
  };
};
