import { SchoolFAType } from "../Reducer_Action_Types/School_FA_Types.jsx";
import {
  SFA_Chart_API,
  ORR_URL,
  SFA_SidePanel_API,
  Sc_FA_FPOT_API,
  Sc_FA_FPOT_GRID_API,
  Grade_List,
  CSV_DOWNLOAD_SCHOOL
} from "../Utils/globalVars";
import axios from "axios";

/**
 *
 * @param {object }
 */
export const SCHOOL_FA_CHART_API_CALL = (AccessToken, ChartPayload, selCxtGrade) => {
  let AuthURL = ORR_URL + SFA_Chart_API;

  let payLoad = ChartPayload;

  return dispatch => {
    axios
      .post(AuthURL, payLoad, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;
        if (Response['recordDataList'] && Response['recordDataList'].length > 0) {
          dispatch({
            type: SchoolFAType.SCHOOL_FA_CHART_API_CALL_SUCCESS,
            payload: Response,
            value: selCxtGrade ? selCxtGrade : 0
          });
        } else {
          dispatch({
            type: SchoolFAType.SCHOOL_FA_CHART_API_FAIL,
            payload: {
              isApiLoading: false,
              apiLoadFail: false,
              noChartData: true
            }
          });
        }


      })
      .catch(error => {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolFAType.SCHOOL_FA_CHART_API_FAIL,
          payload: {
            isApiLoading: false,
            apiLoadFail: true,
            noChartData: false
          }
        });
      });
  };
};

// Side panel api
export const SCHOOL_FA_SIDEPANEL_API_CALL = (AccessToken, payLoad) => {
  let AuthURL = ORR_URL + SFA_SidePanel_API;

  let gridPayload = payLoad;

  return dispatch => {
    axios
      .post(AuthURL, gridPayload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;

        dispatch({
          type: SchoolFAType.SCHOOL_FA_GRID_API_CALL_SUCCESS,
          payload: Response
        });
      })
      .catch(error => {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolFAType.SCHOOL_FA_GRID_API_CALL_FAIL,
          payload: statusCode
        });
      });
  };
};
export const Update_Accordion_State = (state, index) => {
  let updatedState = state;
  updatedState[index] = !updatedState[index];
  return dispatch => {
    dispatch({ type: SchoolFAType.UPDATE_ACCORDION_STATE, payload: updatedState });
  };
};
export const UPDATE_SELECTED_BUBLIST = bubList => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.UPDATE_SELECTED_BUBLIST,
      payload: bubList
    });
  };
};
//tabs for school FA
export const ScFA_TAB_SELECTION = tabSelected => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCHOOL_FA_TABS,
      payload: tabSelected
    });
  };
};

export const Sc_GRADES = (AccessToken, payLoad, cxtGrade, recordType) => {
  let AuthURL = ORR_URL + Grade_List;
  let apiPayload = payLoad;
  apiPayload['internalFilter'] = payLoad.internalFilter;
  let dataRecordType = {
    allRecords: recordType === "all" ? true : false,
    recentRecord: recordType === "rec" ? true : false
  };

  let gradeSel = cxtGrade && cxtGrade.length > 0 && cxtGrade.replace('grade_', '').toLocaleUpperCase();
  return dispatch => {
    axios
      .post(AuthURL, apiPayload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;
        if (response.data.grades.length === 0) {
          dispatch({
            type: SchoolFAType.SCHOOL_GRADES_NOT_AVAILABLE,
            payload: true,
          })
        } else {
          let grade = gradeSel ? (response.data.grades.indexOf(gradeSel) > -1 ? gradeSel : Response.grades[0]) : Response.grades[0];
          apiPayload['dataRecordType'] = dataRecordType;
          apiPayload['externalFilter']['grade'] = grade;
          console.log(apiPayload)
          Promise.resolve(
            dispatch({
              type: SchoolFAType.SCHOOL_GRADES,
              payload: Response,
            })
          ).then(() =>
            dispatch(SCHOOL_FPOT_API_SUCCESS(AccessToken, apiPayload))
          );
        }
        // } else {
        //   dispatch({
        //     type: SchoolFAType.SCHOOL_GRADES,
        //     payload: Response
        //   });
        // }
      });
  };
};

export const SCHOOL_FPOT_API_SUCCESS = (AccessToken, Payload) => {
  let AuthURL = ORR_URL + Sc_FA_FPOT_API;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;
        if (Response.SUCCESSFULL) {
          let errNames = Response.recentRecord
            ? Object.keys(Response.recentRecord)
            : Response.allRecordsAverage
              ? Object.keys(Response.allRecordsAverage)
              : null;
          let data = Response.firstRecord;
          let recRecordData = Response.recentRecord;
          let allRecordData = Response.allRecordsAverage;
          let onLoadDefErrList;
          let firstRecordFlag = false;
          let recRecordFlag = false;
          let allRecordsAverageFlag = false;
          let onLoadDefErr;
          onLoadDefErr = recRecordData
            ? onLoadErrSelection(recRecordData, errNames, "recentRecord")
            : allRecordData
              ? onLoadErrSelection(allRecordData, errNames, "allRecordsAverage")
              : [];

          onLoadDefErrList = onLoadDefErr.defErrList;
          if (
            onLoadDefErrList &&
            onLoadDefErrList.length !== 0 &&
            recRecordData
          ) {
            recRecordFlag = true;
          } else if (
            onLoadDefErrList &&
            onLoadDefErrList.length !== 0 &&
            allRecordData
          ) {
            allRecordsAverageFlag = true;
          } else if (onLoadDefErrList && onLoadDefErrList.length === 0) {
            onLoadDefErr = onLoadErrSelection(data, errNames, "firstRecord");
            onLoadDefErrList = onLoadDefErr.defErrList;
            firstRecordFlag = true;
          }

          let onLoadDefaultErr = {
            errorRangesList: onLoadDefErr.onLoadSelErr
          };

          let gridPayload = {
            externalFilter: Payload.externalFilter,
            internalFilter: Payload.internalFilter,
            selectedCriteriaRanges: {
              allRecordsAverage: allRecordsAverageFlag,
              firstRecord: firstRecordFlag,
              recentRecord: recRecordFlag,
              criteriaRangesLists: onLoadDefErrList
            }
          }
          dispatch({
            type: SchoolFAType.SCHOOL_FA_FPOT_API_SUCCESS,
            payload: { response: Response, firstErrRange: onLoadDefaultErr }
          })
        }
      })
      .catch(error => {
        if (error.response) {
          if (error.response.data.errorCode === 407) {
            dispatch({
              type: SchoolFAType.SC_FPOT_RUBRIC_FAIL,
              payload: error.response.data.errorMessage
            });
          } else {
            let statusCode =
              error.response == undefined ? 401 : error.response.status;
            dispatch({
              type: SchoolFAType.SCHOOL_FA_FPOT_API_FAIL,
              payload: statusCode
            });
          }
        } else {
          let statusCode =
            error.response == undefined ? 401 : error.response.status;
          dispatch({
            type: SchoolFAType.SCHOOL_FA_FPOT_API_FAIL,
            payload: statusCode
          });
        }
      });
  };
};


export const UPDATE_CHARTDATA_FOR_NEWGRADE = (
  responseDataList,
  selectedGrade,
  apiPayload,
  AccessToken
) => {
  let payload = apiPayload;
  return dispatch => {
    dispatch({
      type: SchoolFAType.UPDATE_CHARTDATA_FOR_NEWGRADE,
      payload: {
        apiResponse: responseDataList,
        selectedGradeIndex: selectedGrade
      }
    });
  };
};

export const UPDATE_SCROLL_DATA = data => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.UPDATE_SCROLL_DATA,
      payload: data
    });
  };
};

export const onLoadErrSelection = (recordData, errNames, recType) => {
  let defVal;
  let errObj;
  let defErrList = [];
  let defErrObj = [];
  let selObj;
  let onLoadSelErr = {};
  recordData["accuracy"] !== null &&
    Object.keys(recordData).forEach((obj, key) => {
      if (obj === errNames[key] && obj !== "recentRecordNull") {
        recordData[obj].forEach(errVal => {
          defVal = errVal;
          errObj = {
            // errorName: errNames[key],
            score: defVal.score,
            // value: defVal.value,
            criteriaId: defVal.criteriaId
          };

          if (defVal.value !== 0) {
            selObj = {
              errorName: errNames[key],
              rubrixScore: defVal.score,
              value: defVal.value,
              criteriaId: defVal.criteriaId,
              recordType: recType
            };
            defErrList.push(errObj);
            defErrObj.push(selObj);
            onLoadSelErr = {
              [recType]: defErrObj
            };
          }
        });
      }
    });

  return { defErrList: defErrList, onLoadSelErr: onLoadSelErr };
};

export const selectedScGrade = gradeSel => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCHOOL_SELECTED_GRADE,
      payLoad: gradeSel
    });
  };
};

//load icon action
export const LOAD_ICON = (data) => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.LOAD_ICON_STATUS,
      payload: data
    });
  };
};
//load icon for ScFA
export const FA_LOAD_ICON = (data) => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.FA_LOAD_ICON_STATUS
    });
  };
};



export const ScFa_Api_Timeout = (data) => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.FA_TIME_OUT_STATUS
    });
  };
};

export const School_Fpot_Grid_Api_Call = (AccessToken, payLoad) => {
  let AuthURL = ORR_URL + Sc_FA_FPOT_GRID_API;
  return dispatch => {
    axios
      .post(AuthURL, payLoad, {
        headers: {
          "Access-Control-Allow-Origin": "*",
          responseType: "application/json;charset=UTF-8",
          Authorization: "Bearer ".concat(AccessToken)
        }
      })
      .then(response => {
        let Response = response.data;
        dispatch({
          type: SchoolFAType.SCHOOL_GRID_API_SUCCESS,
          payload: Response
        });
      }).catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolFAType.SCHOOL_GRID_API_FAIL,
          payload: statusCode
        });
      });
  };
}

// Sort for School FA
export const SAVE_SORTED_SCFADATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.FA_SORTED_DATA,
      payload: { SortedArray }
    });
  };
};

//function to show icons and sort columns
export const SORT_SCFA_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCHOOL_FA_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

export const SAVE_SORTED_SCFDATA = SortedArray => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.FPOT_SORTED_DATA,
      payload: { SortedArray }
    });
  };
};

//function to show icons and sort columns
export const SORT_SCFPOT_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCHOOL_FPOT_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

export const UpdateRecordType = data => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCHOOL_RECORD_TYPE,
      payload: data
    });
  };
};

export const SelectedErrors = data => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.UPDATE_SEL_SCHOOL_ERRORS,
      payload: data
    });
  };
};

export const UPDATE_ACCORDIAN = data => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCHOOL_FPOT_CLASS_NAME,
      payload: data
    });
  };
};

export const SCFA_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SCFA_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SCFA_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_SCHOOL;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: SchoolFAType.SCFA_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolFAType.SCHOOL_FA_CHART_API_FAIL,
          payload: {
            isApiLoading: false,
            apiLoadFail: true,
            noChartData: false
          }
        });
      });
  };
};

export const SFR_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: SchoolFAType.SFR_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SFR_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_SCHOOL;

  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: SchoolFAType.SFR_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: SchoolFAType.SCHOOL_FA_FPOT_API_FAIL,
          payload: statusCode
        });
      });
  };
};