import { expect } from 'chai';
import * as DistrictFaAction from './District_FA_Action';
import  * as  DistrictFAType   from '../Reducer_Action_Types/District_FA_Types';
import axios from 'axios';

jest.mock('axios', () => {
  return {
    post: jest.fn(() => Promise.resolve({ data: {} })),
  };
});


describe("UPDATE_CHARTDATA_FOR_NEWGRADE actions", () =>{
  afterEach(() => {
    jest.clearAllMocks();
  });
  
it("UPDATE_CHARTDATA_FOR_NEWGRADE", () => {
  const dispatch = jest.fn();
  DistrictFaAction.UPDATE_CHARTDATA_FOR_NEWGRADE()(dispatch);
  expect(dispatch.mock.calls.length).to.equal(1);
  expect(dispatch.mock.calls[0][0]).to.eql({
    "payload": {
      "apiResponse": undefined, 
      "selectedGradeIndex": undefined
    }, 
    "type": DistrictFAType.DistrictFAType.UPDATE_CHARTDATA_FOR_NEWGRADE
  });
});

});