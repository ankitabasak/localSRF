import axios from "axios";
import {
  ST_AnalysisTypes,
  GET_SINGLE_TEST_ANALYSIS_DATA_SUCCESS,
} from "../Reducer_Action_Types/ST_AnalysisTypes";
import {
  Base_URL,
  student_singleTestAnalysis_url,
  class_singleTestAnalysis_url,
  district_singleTestAnalysis_url,
  school_singleTestAnalysis_url,
  api_request_headers,
} from "../Utils/globalVars";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import {
  Return_ERROR_Status_Code,
  getRequiredDataFromPersist,
  Sort_ApiResponse_Payload_Array,
  setStudentIdsWhenMultiSelectionsInSADA,
  ViewListSortByUserPreferences,
  getGradeOfClassFromRoaster,
} from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog } from "./AuthenticationAction";
import { SetPreviousReport_Props } from "../services/universalSelector/universalSelector_3";

export const OpenFilterToggle = (fromContext, currentStatus) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.OPEN_FILTER_TOGGLE,
      payload: { fromContext, currentStatus },
    });
  };
};

export const SelectSortByType = (fromContext, selectedSortBy) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SELECTED_SORTBY_TYPE,
      payload: { fromContext, selectedSortBy },
    });
  };
};
export const navigationArrowsStandardSingleTest = (
  fromContext,
  NavLeftCount,
  NavRightCount,
  NavType
) => {
  if (NavType == "left") {
    NavLeftCount = NavLeftCount - 1;
    NavRightCount = NavRightCount - 1;
  } else {
    NavLeftCount = NavLeftCount + 1;
    NavRightCount = NavRightCount + 1;
  }

  const NavigationCounters = {
    NavigationLeftCount: NavLeftCount,
    NavigationRightCount: NavRightCount,
  };

  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SINGLE_TEST_PAGE_STANDARDS_NAV,
      payload: {
        fromContext,
        NavigationCounters,
      },
    });
  };
};
export const SingleTestViewPagedDisplay = (fromContext, currentPageNumber) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.ST_ANALYSIS_SELECTED_VIEW_PAGE_DISPLAY,
      payload: { fromContext, currentPageNumber },
    });
  };
};

export const SelectViewType = (
  fromContext,
  selectedView,
  allTaxonomiesSelected
) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SELECTED_VIEW_TYPE,
      payload: { fromContext, selectedView, allTaxonomiesSelected },
    });
  };
};

export const SelectAvgType = (fromContext, selectedAvgType) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SELECTED_AVG_TYPE,
      payload: { fromContext, selectedAvgType },
    });
  };
};

export const SingleTestApplyFilter = (fromContext) => {
  return (dispatch, getState) => {
    const stateOfContext = getState();
    const { SingleTestAnalysis } = stateOfContext;
    dispatch({
      type: ST_AnalysisTypes.SINGLE_TEST_APPLY_FILTER,
      payload: { fromContext, SingleTestAnalysis },
    });
  };
};

export const SingleTestCancelFilter = (fromContext) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SINGLE_TEST_CANCEL_FILTER,
      payload: fromContext,
    });
  };
};

export const GetSingleTestData = (fromContext, AccessToken, ReqPayload) => {
  let URL = Base_URL;

  if (fromContext == "student") {
    URL = URL + student_singleTestAnalysis_url;
  } else if (fromContext == "class") {
    URL = URL + class_singleTestAnalysis_url;
  } else if (fromContext == "school") {
    URL = URL + school_singleTestAnalysis_url;
  } else {
    URL = URL + district_singleTestAnalysis_url;
  }

  return (dispatch, getState) => {
    ReqPayload.studentIds = setStudentIdsWhenMultiSelectionsInSADA(
      getState(),
      ReqPayload.studentIds
    );

    dispatch({
      type: ST_AnalysisTypes.GET_SINGLE_TEST_ANALYSIS_DATA,
      payload: fromContext,
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;
        let checkSTData =
          ResPayload.testByQuestionList || ResPayload.testByViewList;
        let Sta_Persist_Object = getRequiredDataFromPersist("sta", getState());
        let persist_compare_checkboxes = getRequiredDataFromPersist(
          "persist_compare_checkboxes",
          getState()
        );
        const selectedTest =
          getState().Universal.UniversalSelecter.TestTab.SelectedTestList;
        let UserPreferences = getState().Universal.UserPreferences;
        UserPreferences = UserPreferences && UserPreferences.standardsetorders;
        let testByViewList = ResPayload && ResPayload.testByViewList;
        let UpdatedtestByViewList = [];
        UserPreferences &&
          UserPreferences.length !==
            process.env.USERPREFERENCES_EXPECTED_COUNT - 1 &&
          UserPreferences.map((item, idx) => {
            let Item =
              testByViewList &&
              testByViewList.find((item1) => item1.setId === item.setValue);
            if (Item) {
              UpdatedtestByViewList.push(Item);
            }
            if (idx === UserPreferences.length - 1) {
              ResPayload.testByViewList = UpdatedtestByViewList;
            }
          });
        if (
          ResPayload.testByViewList != null &&
          UserPreferences.length > 0 &&
          UserPreferences.length ==
            process.env.USERPREFERENCES_EXPECTED_COUNT &&
          testByViewList != null &&
          testByViewList.length < process.env.USERPREFERENCES_EXPECTED_COUNT
        ) {
          ResPayload.testByViewList = Sort_ApiResponse_Payload_Array(
            ResPayload.testByViewList,
            "view"
          );
        }
        if (
          ResPayload.testByViewList != null &&
          UserPreferences.length > 0 &&
          UserPreferences.length == process.env.USERPREFERENCES_EXPECTED_COUNT
        ) {
          ResPayload.testByViewList = ResPayload.testByViewList.sort(
            ViewListSortByUserPreferences
          );
        }

        let { Universal, LastActiveUniversalProps } = getState();

        let payload = {
          fromContext,
          ResPayload,
          checkSTData,
          Sta_Persist_Object,
          persist_compare_checkboxes,
          selectedTest,
        };
        let action = {
          payload,
        };

        let updatedLastActivePropsState = LastActiveUniversalProps,
          updatedUniversalState = Universal;

        if (
          action.payload.checkSTData != null
            ? action.payload.checkSTData.length != 0
            : false
        ) {
          let pickedDataFromSTA =
            action.payload.ResPayload.concernedData != undefined
              ? action.payload.ResPayload.concernedData
              : null;
          if (pickedDataFromSTA != null && fromContext != "district") {
            pickedDataFromSTA.grade = getGradeOfClassFromRoaster(
              Universal.ContextHeader.Roster_Tab.GradesList,
              pickedDataFromSTA.studentId
            );
          }
          action = {
            ...action,
            payload: {
              ...action.payload,
              pickedDataFromSTA: pickedDataFromSTA,
            },
          };

          let responseStates = SetPreviousReport_Props(
            JSON.parse(JSON.stringify(Universal)),
            action,
            JSON.parse(JSON.stringify(LastActiveUniversalProps))
          );

          updatedLastActivePropsState =
            responseStates.updatedLastActivePropsState;
          updatedUniversalState = responseStates.updatedUniversalState;
        }

        dispatch({
          type: GET_SINGLE_TEST_ANALYSIS_DATA_SUCCESS,
          payload: {
            fromContext,
            ResPayload,
            checkSTData,
            Sta_Persist_Object,
            persist_compare_checkboxes,
            selectedTest,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);

        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};

export const sortByContextInSingleTest = (
  fromContext,
  fromSortType,
  fromSortOn,
  orderOfSort
) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SORTBY_CONTEXT_IN_SINGLE_TEST,
      payload: { fromContext, fromSortType, fromSortOn, orderOfSort },
    });
  };
};

export const SingleTest_checkCompareBoxes = (
  fromContext,
  fromSortype,
  checkFor,
  checkedStatus
) => {
  return (dispatch, getState) => {
    let Sta_Persist_Object = getRequiredDataFromPersist(
      "persist_compare_checkboxes",
      getState()
    );
    dispatch({
      type: ST_AnalysisTypes.COMPARE_CHECKBOXES_IN_SINGLE_TEST,
      payload: {
        fromContext,
        fromSortype,
        checkFor,
        checkedStatus,
        Sta_Persist_Object,
      },
    });
  };
};

export const SingleTest_Nav_through_contexts = (
  fromContext,
  fromSortype,
  paramToFilter
) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SINGLE_TEST_NAV_THROUGH_CONTEXTS,
      payload: {
        fromContext,
        fromSortype,
        paramToFilter,
      },
    });
  };
};
export const SingleTest_Deleted_Que_Tooltip = (
  fromContext,
  value,
  index,
  singleViewData
) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SINGLE_TEST_DELETED_QUESTION_TOOLTIP,
      payload: {
        fromContext,
        value,
        index,
        singleViewData,
      },
    });
  };
};
export const SingleTest_Deleted_View_Tooltip = (
  fromContext,
  value,
  index,
  singleViewData,
  ViewShortValue
) => {
  return (dispatch) => {
    dispatch({
      type: ST_AnalysisTypes.SINGLE_TEST_DELETED_VIEW_TOOLTIP,
      payload: { fromContext, value, index, singleViewData, ViewShortValue },
    });
  };
};
