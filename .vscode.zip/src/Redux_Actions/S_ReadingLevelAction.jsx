import { StudentRlpTypes } from '../Reducer_Action_Types/S_ReadingLevelTypes.jsx';
import { Reading_Level_API, ORR_URL, Proxy_URL, CSV_DOWNLOAD_STUDENT } from '../Utils/globalVars';
import axios from 'axios';

/**
 *
 * @param {object }
 */
export const S_RLP_API_CALL = (AccessToken, payLoad, value) => {
  let AuthURL = ORR_URL + Reading_Level_API;

  let Payload = {
    filters: payLoad
  };
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.STUDENT_LOADING_ICON
    });
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: StudentRlpTypes.S_READING_LEVEL_API_SUCCESS,
          payload: Response,
          value: value
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: StudentRlpTypes.S_READING_LEVEL_API_FAIL,
          payload: statusCode
        });
      });
  };
};

export const Student_loading_Icon = () => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.STUDENT_LOADING_ICON
    });
  };
};

export const SRL_CHART_YAXIS_SCROLL = srlpChartData => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.S_READING_LEVEL_CHART_YAXIS_SCROLL,
      payload: srlpChartData
    });
  };
};
export const SRL_CHART_XAXIS_SCROLL = srlpChartData => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.S_READING_LEVEL_CHART_XAXIS_SCROLL,
      payload: srlpChartData
    });
  };
};

export const SUMMARY_SRL_CHART_YAXIS_SCROLL = srlpChartData => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.S_SUMRLP_CHART_YAXIS_SCROLL,
      payload: srlpChartData
    });
  };
};
export const SUMMARY_SRL_CHART_XAXIS_SCROLL = srlpChartData => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.S_SUMRLP_CHART_XAXIS_SCROLL,
      payload: srlpChartData
    });
  };
};

export const show_pop_update = data => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.S_SHOW_POPUP,
      payLoad: data
    });
  };
};

export const SRLP_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.SRLP_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const SRLP_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_STUDENT;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: StudentRlpTypes.SRLP_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: StudentRlpTypes.S_READING_LEVEL_API_FAIL,
          payload: statusCode
        });
      });
  };
};
export const Chart_Enabled = data => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.SRLP_CHART_ENABLED,
      payLoad: data
    });
  };
}

export const Update_Tooltip_data = data => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.SRLP_UPDATE_TOOLTIP_DATA,
      payLoad: data
    });
  };
}


export const Update_Tooltip_Data_For_Print = data => {
  return dispatch => {
    dispatch({
      type: StudentRlpTypes.SRLP_UPDATE_TOOLTIP_DATA_PRINT,
      payLoad: data
    });
  };
}
