import {
  GET_CLASS_OBJECT_WHICH_HAS_REPORTS,
  GET_CLASS_OBJECT_WHICH_HAS_REPORTS_SUCCESS,
  U_S_Action_Types,
} from "../Reducer_Action_Types/UniversalSelectorActionTypes";
import {
  DrillDownTo_Class_TestStatus,
  DrillDownTo_School_TestStatus,
  MoveToSingleTest_TestStatus,
} from "../Redux_Reducers/Reducers_Functions_To_Return_State";
import { SetRosterDataOnClassSelection } from "../services/universalSelector/Roster.service";
import { DrillDownToStudent_FromTestStatus } from "../services/universalSelector/universalSelector_3";
import { APIURLs, api_request_headers, Base_URL } from "../Utils/globalVars";
import axios from "axios";
import { postErrorLog } from "./AuthenticationAction";
import { Return_ERROR_Status_Code } from "../Components/ReusableComponents/AllReusableFunctions";
export const Get_ClassObject_WhichHas_Reports = (ReqPayload) => {
  return (dispatch, getState) => {
    let URL = Base_URL + APIURLs[`getClassWhichHasReports`];
    let { Authentication, Universal } = getState();
    const { JWTToken } = Authentication.LoginDetails;
    dispatch({
      type: GET_CLASS_OBJECT_WHICH_HAS_REPORTS,
      payload: {
        ...Universal,
        ApiCalls: {
          ...Universal.ApiCalls,
          loadingFor: "classObject",
          getRosterClassWhichHasData: false,
        },
      },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(JWTToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let classId = response.data.value;

        let action = {
          payload: { classId },
        };
        let { Universal, LastActiveUniversalProps } = getState();
        let updatedUniversalState = SetRosterDataOnClassSelection(
          action,
          Universal
        );

        const Nav = updatedUniversalState.NavigationByHeaderSelection

        dispatch({
          type: GET_CLASS_OBJECT_WHICH_HAS_REPORTS_SUCCESS,
          payload: {
            ReqPayload,
            updatedUniversalState,
            Nav
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
      });
  };
};
