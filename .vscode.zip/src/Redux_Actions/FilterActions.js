import { FilterActionTypes } from '../Reducer_Action_Types/FilterActionTypes';
import { Reading_Level_API, ORR_URL } from '../Utils/globalVars';
import axios from 'axios';

/**
 *
 * @param {object } ,externalFilter, internalFilter
 */
export const GET_SELECTED_DATA = (
  AccessToken,
  externalFilter,
  internalFilter,
  value
) => {
  let AuthURL = ORR_URL + Reading_Level_API;

  let Payload = {
    filters: {
      externalFilter: externalFilter,
      internalFilter: internalFilter
    }
  };
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;

        dispatch({
          type: FilterActionTypes.POST_FILTER_DATA_SUCCESS,
          payload: Response_Data,
          value: value
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 401 : error.response.status;
        dispatch({
          type: FilterActionTypes.POST_FILTER_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};