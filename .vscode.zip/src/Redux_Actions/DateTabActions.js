import { DateTabActionTypes } from '../Reducer_Action_Types/DateTabActionTypes';


export const DistrictTermsDropDown = () => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.DISTRICT_TERM_DROPDOWN_OPEN
        })
    }
}

export const SelectedDistrictTerm = (value) => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.SELECTED_DISTRICT_TERM,
            payload: value
        })
    }
}

export const DateRangeDropDown = () => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.DATE_RANGE_DROPDOWN_OPEN
        })
    }
}

export const SelectedRange = (value, checkState, monthsIndex) => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.SELECTED_DATE_RANGE,
            payload: { value, checkState, monthsIndex }
        })
    }
}

export const OpenDatePicker = (value) => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.OPEN_DATE_PICKER_DATE_TAB,
            payload: value
        })
    }
}


export const openMonthDropdown = () => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.OPEN_MONTH_DROPDOWN_DATETAB,
        })
    }
}

export const SelectedMonth = (value, number) => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.SELECTED_MONTH_DATETAB,
            payload: { value, number }
        })
    }
}

export const SetAfterClickDateInCalendar = (value, checkState) => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.SET_AFTER_CLICK_DATE_IN_CALENDAR,
            payload: { value, checkState }
        })
    }
}

export const ClickedLeftRightArrowsForMonthChange = (value, number) => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.CLICKED_LEFT_RIGHT_ARROWS_MONTHS_DATETAB,
            payload: { value, number }
        })
    }
}
export const resetCallApplyDateTab_InDateTab_JS = () => {
    return (dispatch) => {
        dispatch({
            type: DateTabActionTypes.RESET_CALLAPPLY_DATE_TAB_IN_DATETAB_JS_PROPS,
        })
    }
}