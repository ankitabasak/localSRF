import { C_EaTypes } from '../Reducer_Action_Types/C_ErrorAnalysisTypes.jsx';
import {
  Class_Error_Analysis,
  ORR_URL,
  CSV_DOWNLOAD_CLASS,
  Class_Error_Grid_Api
} from '../Utils/globalVars';
import axios from 'axios';


export const CLASS_EA_API = (AccessToken, payLoadData) => {
  let AuthURL = ORR_URL + Class_Error_Analysis;
  let Payload = payLoadData;
  let gridPayload;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;
        if (Response_Data.errorCountRangeList) {
          let firstRec = Object.keys(Response_Data.firstRecord).slice(0, 6);
          let errNames = Response_Data.recentRecord
            ? Object.keys(Response_Data.recentRecord).slice(0, 6)
            : Response_Data.allRecordsAverage
              ? Object.keys(Response_Data.allRecordsAverage).slice(0, 6)
              : null;

          let data = Response_Data.firstRecord;
          let recRecordData = Response_Data.recentRecord;
          let allRecordData = Response_Data.allRecordsAverage;
          let onLoadDefErrList;
          let firstRecordFlag = false;
          let recRecordFlag = false;
          let allRecordsAverageFlag = false;
          let onLoadDefErr;

          onLoadDefErr = recRecordData
            ? onLoadPayloadConst(recRecordData, errNames, 'recentRecord')
            : allRecordData
              ? onLoadPayloadConst(allRecordData, errNames, 'allRecordsAverage')
              : [];

          onLoadDefErrList = onLoadDefErr.defErrList;
          if (
            onLoadDefErrList &&
            onLoadDefErrList.length !== 0 &&
            recRecordData
          ) {
            recRecordFlag = true;
          } else if (
            onLoadDefErrList &&
            onLoadDefErrList.length !== 0 &&
            allRecordData && !Response_Data.recentRecordNull
          ) {
            allRecordsAverageFlag = true;
          } else if (
            onLoadDefErrList &&
            onLoadDefErrList.length !== 0 &&
            allRecordData && Response_Data.recentRecordNull
          ) {
            onLoadDefErr = onLoadPayloadConst(data, errNames, 'firstRecord');
            onLoadDefErrList = onLoadDefErr.defErrList;
            firstRecordFlag = true;
          }
          else if (onLoadDefErrList && onLoadDefErrList.length === 0) {
            onLoadDefErr = onLoadPayloadConst(data, errNames, 'firstRecord');
            onLoadDefErrList = onLoadDefErr.defErrList;
            firstRecordFlag = true;
          }

          gridPayload = {
            externalFilter: payLoadData.externalFilter,
            internalFilter: payLoadData.internalFilter,
            selectedErrorRanges: {
              errorRangesList: onLoadDefErrList,
              allRecordsAverage: allRecordsAverageFlag,
              firstRecord: firstRecordFlag,
              recentRecord: recRecordFlag
            }
          };

          let onLoadDefaultErr = {
            errorRangesList: onLoadDefErr.onLoadSelErr
          };
          dispatch({
            type: C_EaTypes.CLASS_EA_DATA_SUCCESS,
            payload: {
              responseData: Response_Data,
              firstErrRange: onLoadDefaultErr
            },
            value: payLoadData.value
          });
        } else {
          dispatch({
            type: C_EaTypes.CLASS_EA_NO_DATA,
            payload: true
          });
        }
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 500 : error.response.status;
        dispatch({
          type: C_EaTypes.CLASS_EA_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};

export const Class_EA_Grid_Table = (AccessToken, data) => {
  let AuthURL = ORR_URL + Class_Error_Grid_Api;
  let Payload = data;
  let dummyToken;
  return dispatch => {
    axios
      .post(AuthURL, Payload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response_Data = response.data;
        dispatch({
          type: C_EaTypes.CLASS_EA_GRID_TABLE_SUCCESS,
          payload: Response_Data
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 500 : error.response.status;
        dispatch({
          type: C_EaTypes.CLASS_EA_GRID_TABLE_FAIL,
          payload: statusCode
        });
      });
  };
};

//function to show icons and sort columns
export const SORT_EA_GRID = (sortColumn, sortType) => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.CLASS_EA_SORT_COLUMN,
      payload: { sortColumn, sortType }
    });
  };
};

/**
 *
 * @param {Array} SortedArray --  SortedArray
 */
export const SAVE_SORTED_EA = SortedArray => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.CEA_SORTED_DATA,
      payload: { SortedArray }
    });
  };
};

export const Selected_Errors = data => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.UPDATE_SELECTED_ERRORS,
      payload: data
    });
  };
};

//load icon action
export const LOAD_STATUS_ICON = () => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.STATUS_LOAD_ICON,
      payload: true
    });
  };
};

//load icon action
export const LOAD_ICON = () => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.LOAD_ICON,
      payload: true
    });
  };
};

export const Update_RecordType = data => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.UPDATE_RECORD_TYPE,
      payload: data
    });
  };
};

export const onLoadPayloadConst = (recordData, errNames, recType) => {
  let defVal;
  let errObj;
  let defErrList = [];
  let defErrObj = [];
  let selObj;
  let onLoadSelErr = {};
  Object.keys(recordData).forEach((obj, key) => {
    if (obj === errNames[key]) {
      recordData[obj].forEach(errVal => {
        defVal = errVal;
        errObj = {
          errorName: errNames[key],
          fromRange: defVal.fromRange,
          toRange: defVal.toRange
        };

        if (defVal.value !== 0) {
          selObj = {
            errorName: errNames[key],
            range: `${defVal.fromRange}-${defVal.toRange}`,
            recordType: recType
          };
          defErrList.push(errObj);
          defErrObj.push(selObj);
          onLoadSelErr = {
            [recType]: defErrObj
          };
        }
      });
    }
  });

  return { defErrList: defErrList, onLoadSelErr: onLoadSelErr };
};

export const Chart_loading_Failed = data => {
  return dispatch => {
    dispatch({ type: C_EaTypes.API_ERROR_HANDLER, payload: data });
  };
};

export const CEA_CSVDATA_DOWNLOAD_RESET = data => {
  return dispatch => {
    dispatch({
      type: C_EaTypes.CEA_CSVDATA_DOWNLOAD_RESET,
      payLoad: data['payLoad']
    });
  };
}

export const CEA_CSVDATA_DOWNLOAD_APICALL = (AccessToken, apiPayload) => {
  let AuthURL = ORR_URL + CSV_DOWNLOAD_CLASS;


  return dispatch => {

    axios
      .post(AuthURL, apiPayload, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          responseType: 'application/json;charset=UTF-8',
          Authorization: 'Bearer '.concat(AccessToken)
        }
      })
      .then(function (response) {
        let Response = response.data;

        dispatch({
          type: C_EaTypes.CEA_CSVDATA_DOWNLOAD_SUCCESS,
          payLoad: { downloadInProgress: true, csvData: { header: Response['headers'], data: Response['data'] } }
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 500 : error.response.status;
        dispatch({
          type: C_EaTypes.CLASS_EA_DATA_FAIL,
          payload: statusCode
        });
      });
  };
};