import axios from "axios";

import {
  Base_URL,
  Get_TestStatus_Summary,
  Get_TestStatus_Details,
  DistrictTestStatusCSVDownload,
  SchoolTestStatusCSVDownload,
  ClassTestStatusCSVDownload,
  StudentTestStatusCSVDownload,
  Check_IsAssignmentIDAvailable,
  api_request_headers,
  Get_TestStatus_Summary_Count,
  Get_Teachers_Students_for_Dist,
  Get_TestStatus_Summary_Ditrict,
  testsStatusSummaryDrillDown,
} from "../Utils/globalVars";
import {
  ON_TEST_STATUS_SELECTION,
  OPEN_OR_CLOSE_TESTSTATUS_INFO_POPUP,
  SORT_TEST_STATUS_DATA,
  SORT_TEST_STATUS_DETAILS_DATA,
  FILTER_STUDENT_TESTSTATUS_DATA,
  GET_TESTSTATUS_SUMMARY_DATA,
  GET_TESTSTATUS_SUMMARY_DATA_SUCCESS,
  PAGINATION_BUBBLE_SELECTION_TEST_STATUS,
  PAGINATION_NAVIGATE_SELECTION_TEST_STATUS,
  GET_TESTSTATUS_SUMMARY_DETAILS,
  SET_GET_TESTSTATUS_SUMMARY_DATA,
  SET_GET_TESTSTATUS_SUMMARY_DETAILS,
  GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS,
  GET_TEST_STATUS_CSV_DATA,
  GET_TEST_STATUS_CSV_DATA_SUCCESS,
  TESTSTATUS_DOWNLOADED_CSV_DATA,
  CHECK_ASSIGNMENT_ID,
  SET_CHECK_ASSIGNMENT_ID,
  CHECK_ASSIGNMENT_ID_SUCCESS,
  GET_TESTSTATUS_SUMMARY_DATA_FAIL,
  GET_TESTSTATUS_SUMMARY_DATA_COUNT,
  GET_TESTSTATUS_SUMMARY_DATA_COUNT_SUCCESS,SHOWALL_RESULTS
} from "../Reducer_Action_Types/TestStatus.Types";

import { COUNT_END_TESTSTATUS } from "../Redux_Reducers/TestStatus.Reducer";
import { AuthActionTypes } from "../Reducer_Action_Types/AuthenticationTypes";
import { retriggerAPI } from "../Components/ReusableComponents/AllReusableFunctions";
import { postErrorLog } from "./AuthenticationAction";
import { GET_TESTSTATUS_SUMMARY_DATA_SUCCESS_US_Redux_Fun } from "../services/universalSelector/universalSelector_3";
export const OnTestStatusSelection = (
  selectedItem,
  selectedStatus,
  fromContext,
  Nav
) => {
  return (dispatch) => {
    dispatch({
      type: ON_TEST_STATUS_SELECTION,
      payload: {
        selectedItem,
        selectedStatus,
        fromContext,
        Nav,
      },
    });
  };
};
export const Get_TestStatusSummaryDataCount = (
  AccessToken,
  ReqPayload,
  fromContext,
  Nav
) => {
  let URL = Base_URL + Get_TestStatus_Summary_Count;

  return (dispatch, getState) => {
    dispatch({
      type: GET_TESTSTATUS_SUMMARY_DATA_COUNT,
      payload: {
        Nav,
        AccessToken,
        ReqPayload,
        fromContext,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;
        if (ResPayload == null || ResPayload == undefined) {
          ResPayload = 0;
        }
        dispatch({
          type: GET_TESTSTATUS_SUMMARY_DATA_COUNT_SUCCESS,
          payload: {
            ResPayload,
            fromContext,
          },
        });
      })
      .catch(function (error) {
        let statusCode =
          error.response == undefined ? 502 : error.response.status;
        //  dispatch(postErrorLog(AccessToken,error,seconds_Start))
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
/**
 * action is to open or close info note popup on Test status Summary header.
 * it is for all reports in the application.
 * @param {Boolean} OpenOrClose
 * @param {Object} Nav
 */
export const OpenOrClose_TestStatus_Info_Popup = (OpenOrClose, Nav) => {
  return (dispatch) => {
    dispatch({
      type: OPEN_OR_CLOSE_TESTSTATUS_INFO_POPUP,
      payload: { OpenOrClose, Nav },
    });
  };
};
export const Get_TestStatus_CSV_Details = (AccessToken, ReqPayload, Nav) => {
  let URL;
  let currentNavContext;
  if (Nav.district) {
    URL = Base_URL + DistrictTestStatusCSVDownload;
  } else if (Nav.school) {
    URL = Base_URL + SchoolTestStatusCSVDownload;
  } else if (Nav.class) {
    URL = Base_URL + ClassTestStatusCSVDownload;
  } else {
    URL = Base_URL + StudentTestStatusCSVDownload;
  }

  if (Nav.district) {
    currentNavContext = {
      currentContext: "district",
    };
  } else if (Nav.school) {
    currentNavContext = { currentContext: "school" };
  } else if (Nav.class) {
    currentNavContext = { currentContext: "class" };
  } else if (Nav.student) {
    currentNavContext = { currentContext: "student" };
  }
  currentNavContext.test_status = Nav.test_status;

  return (dispatch) => {
    dispatch({
      type: GET_TEST_STATUS_CSV_DATA,
      payload: {
        currentNavContext,
      },
    });

    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;
        dispatch({
          type: GET_TEST_STATUS_CSV_DATA_SUCCESS,
          payload: {
            ResPayload,
            currentNavContext,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode = Return_ERROR_Status_Code(error, seconds_Start);
        dispatch({
          type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
          payload: { statusCode },
        });
      });
  };
};
export const SortTestStatusSummaryData = (sortType, sortOn, fromContext) => {
  return (dispatch) => {
    dispatch({
      type: SORT_TEST_STATUS_DATA,
      payload: {
        sortType,
        sortOn,
        fromContext,
      },
    });
  };
};

export const SortTestStatusDetailsData = (sortType, sortOn, fromContext) => {
  return (dispatch) => {
    dispatch({
      type: SORT_TEST_STATUS_DETAILS_DATA,
      payload: {
        sortType,
        sortOn,
        fromContext,
      },
    });
  };
};
export const ShowAllResults = (fromContext) => {
  return (dispatch,getState) => {
    dispatch({
      type: SHOWALL_RESULTS,
      payload: {fromContext}
    });
  };
};

export const FilterStudent_TestStatus_Data = (List, FilterStatusFiled) => {
  return (dispatch) => {
    dispatch({
      type: FILTER_STUDENT_TESTSTATUS_DATA,
      payload: {
        FilterStatusFiled,
      },
    });
  };
};

export const Pagination_Bubble_Selection = (
  BubbleStart,
  positionfrom_BubbleStart,
  fromContext_Blog
) => {
  return (dispatch, getState) => {
    let Nav = getState().Universal.NavigationByHeaderSelection;

    let Page_At = positionfrom_BubbleStart + BubbleStart;
    let start;
    let end;
    let Page_Count;
    Page_Count = COUNT_END_TESTSTATUS;
    start = Page_At * Page_Count - Page_Count;
    end = Page_At * Page_Count;

    dispatch({
      type: PAGINATION_BUBBLE_SELECTION_TEST_STATUS,
      payload: {
        Nav,
        start,
        end,
        Page_Count,
        Page_At,
        fromContext_Blog,
      },
    });
  };
};

export const Pagination_Navigate_Selection = (
  Left_Or_Right,
  Current_Bubble_STart,
  fromContext
) => {
  return (dispatch, getState) => {
    let Nav = getState().Universal.NavigationByHeaderSelection;

    let bubble_Start = Current_Bubble_STart;
    if (Left_Or_Right == "left") {
      bubble_Start = bubble_Start - 1;
    } else {
      bubble_Start = bubble_Start + 1;
    }

    dispatch({
      type: PAGINATION_NAVIGATE_SELECTION_TEST_STATUS,
      payload: {
        bubble_Start,
        fromContext,
        Nav,
      },
    });
  };
};

export const Get_TestStatusSummaryData = (
  AccessToken,
  ReqPayload,
  fromContext,
  Nav,
  persistfromsummaryTS
) => {
  let testStatusAPI = Nav.district && !ReqPayload.componentCodeList
      ? Get_TestStatus_Summary_Ditrict
      : Get_TestStatus_Summary;
      if(persistfromsummaryTS ){
        testStatusAPI = testsStatusSummaryDrillDown;
      }
  let URL = Base_URL + testStatusAPI;

  return (dispatch, getState) => {
    dispatch({
      type: GET_TESTSTATUS_SUMMARY_DATA,
      payload: {
        Nav,
        AccessToken,
        ReqPayload,
        fromContext,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;

        if (ResPayload == null || ResPayload == undefined) {
          ResPayload = {};
          ResPayload.tests = [];
        }

        let DateTab_TSContext =
          getState().DateTabReducer.Context_DateTab_TestStatus;
        let DataIsNotThere = ResPayload.tests.length == 0;
        let U_selector = getState().Universal;
        let { LastActiveUniversalProps } = getState();

        let PreviousDataNav = LastActiveUniversalProps.NaviGation;
        let data_From_AssessMent = U_selector.assessmentLinkData;
        let testStatusReducer = getState().TestStatusReducer;
        let SummaryReports = getState().SummaryReports;
        let payload = {
          Nav,
          ResPayload,
          fromContext,
          DateTab_TSContext,
          DataIsNotThere,
          PreviousDataNav,
          data_From_AssessMent,
          testStatusReducer,
          ReqPayload,
          U_selector,
        };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          GET_TESTSTATUS_SUMMARY_DATA_SUCCESS_US_Redux_Fun(
            action,
            U_selector,
            LastActiveUniversalProps,
            testStatusReducer
            
          );

        dispatch({
          type: GET_TESTSTATUS_SUMMARY_DATA_SUCCESS,
          payload: {
            Nav,
            ResPayload,
            fromContext,
            DateTab_TSContext,
            DataIsNotThere,
            PreviousDataNav,
            data_From_AssessMent,
            testStatusReducer,
            ReqPayload,
            U_selector,
            updatedLastActivePropsState,
            updatedUniversalState,
            SummaryReports
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let retries = getState().Authentication.retryApis;
        let statusCode =
          error.response == undefined ? 502 : error.response.status;
        let seconds_End = new Date().getTime() / 1000;
        let diffTime = seconds_End - seconds_Start;
        let isAPIRetry = retriggerAPI(diffTime, retries, statusCode);
        if (isAPIRetry) {
          dispatch({
            type: SET_GET_TESTSTATUS_SUMMARY_DATA,
            payload: {
              fromContext,
            },
          });
        } else {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });

          dispatch({
            type: GET_TESTSTATUS_SUMMARY_DATA_FAIL,
            payload: {
              fromContext,
              ReqPayload,
            },
          });
        }
      });
  };
};

export const Get_TestStatusDetailsData = (
  AccessToken,
  ReqPayload,
  fromContext,
  Nav
) => {
  let URL = Base_URL + Get_TestStatus_Details;

  return (dispatch, getState) => {
    dispatch({
      type: GET_TESTSTATUS_SUMMARY_DETAILS,
      payload: {
        Nav,
        fromContext,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;

        let { LastActiveUniversalProps, Universal,TestStatusReducer } = getState();

        let payload = { Nav, Nav, ResPayload, fromContext };
        let action = {
          payload,
        };

        let { updatedLastActivePropsState, updatedUniversalState } =
          GET_TESTSTATUS_SUMMARY_DATA_SUCCESS_US_Redux_Fun(
            action,
            Universal,
            LastActiveUniversalProps,
            TestStatusReducer
          );

        dispatch({
          type: GET_TESTSTATUS_SUMMARY_DETAILS_SUCCESS,
          payload: {
            Nav,
            ResPayload,
            fromContext,
            updatedLastActivePropsState,
            updatedUniversalState,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let retries = getState().Authentication.retryApis;
        let seconds_End = new Date().getTime() / 1000;
        let diffTime = seconds_End - seconds_Start;
        let statusCode =
          error.response == undefined ? 502 : error.response.status;
        let isAPIRetry = retriggerAPI(diffTime, retries, statusCode);
        if (isAPIRetry) {
          dispatch({
            type: SET_GET_TESTSTATUS_SUMMARY_DETAILS,
            payload: {
              fromContext,
            },
          });
        } else {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        }
      });
  };
};

export const Check_ISAssignmentIDAvailable = (
  AccessToken,
  ReqPayload,
  fromContext,
  Nav
) => {
  let URL = Base_URL + Check_IsAssignmentIDAvailable;

  return (dispatch, getState) => {
    let TSState = getState().TestStatusReducer;
    let StateToSet;

    StateToSet = CHECK_ASSIGNMENT_ID_ReduxFunc(TSState, fromContext);

    dispatch({
      type: CHECK_ASSIGNMENT_ID,
      payload: {
        Nav,
        fromContext,
        StateToSet,
      },
    });
    let seconds_Start = new Date().getTime() / 1000;
    api_request_headers.Authorization = "Bearer ".concat(AccessToken);
    axios
      .post(URL, ReqPayload, {
        headers: api_request_headers,
      })
      .then(function (response) {
        let ResPayload = response.data.value;
        let TSState1 = getState().TestStatusReducer;
        StateToSet = CHECK_ASSIGNMENT_ID_SUCCESS_ReduxFunc(
          TSState1,
          fromContext,
          ResPayload
        );
        dispatch({
          type: CHECK_ASSIGNMENT_ID_SUCCESS,
          payload: {
            Nav,
            ResPayload,
            fromContext,
            StateToSet,
          },
        });
      })
      .catch(function (error) {
        dispatch(postErrorLog(AccessToken, error, seconds_Start));
        let statusCode =
          error.response == undefined ? 502 : error.response.status;

        let retries = getState().Authentication.retryApis;
        let seconds_End = new Date().getTime() / 1000;
        let diffTime = seconds_End - seconds_Start;
        let isAPIRetry = retriggerAPI(diffTime, retries, statusCode);
        if (isAPIRetry) {
          dispatch({
            type: SET_CHECK_ASSIGNMENT_ID,
            payload: {
              fromContext,
            },
          });
        } else {
          dispatch({
            type: AuthActionTypes.TECHNICAL_ISSUE_ERROR,
            payload: { statusCode },
          });
        }
      });
  };
};

export const SetTestStatusDownloadCsvToFalse = () => {
  return (dispatch) => {
    dispatch({
      type: TESTSTATUS_DOWNLOADED_CSV_DATA,
    });
  };
};

export const ResetTestStatus_CSV_download = (Nav) => {
  let currentNavContext;

  if (Nav.district) {
    currentNavContext = {
      currentContext: "district",
    };
  } else if (Nav.school) {
    currentNavContext = { currentContext: "school" };
  } else if (Nav.class) {
    currentNavContext = { currentContext: "class" };
  } else if (Nav.student) {
    currentNavContext = { currentContext: "student" };
  }
  return (dispatch) => {
    dispatch({
      type: TESTSTATUS_DOWNLOADED_CSV_DATA,
      payload: { currentNavContext },
    });
  };
};

function CHECK_ASSIGNMENT_ID_ReduxFunc(state, fromContext) {
  switch (fromContext) {
    case "district":
      return {
        ...state,
        District: {
          ...state.District,
          Apicalls: {
            ...state.District.Apicalls,
            Check_AssignmentIDAvailable: false,
          },
        },
      };
    case "school":
      return {
        ...state,
        School: {
          ...state.School,
          Apicalls: {
            ...state.School.Apicalls,
            Check_AssignmentIDAvailable: false,
          },
        },
      };
    case "class":
      return {
        ...state,
        Class: {
          ...state.Class,
          Apicalls: {
            ...state.Class.Apicalls,
            Check_AssignmentIDAvailable: false,
          },
        },
      };

    default:
      return {
        ...state,
      };
  }
}

function CHECK_ASSIGNMENT_ID_SUCCESS_ReduxFunc(
  state,
  fromContext,
  DataIsThere
) {
  let selectedStatusCode;
  let Index;
  let dataExist = getDatawhichIsTrue(DataIsThere);

  if (fromContext == "district") {
    Index = parseInt(state.District.StatusDetail.indexOf_Test);
    selectedStatusCode = statusCodeSelection(
      state.District.ActualList.tests[Index],
      dataExist
    );
  } else if (fromContext == "school") {
    Index = parseInt(state.School.StatusDetail.indexOf_Test);
    selectedStatusCode = statusCodeSelection(
      state.School.ActualList.tests[Index],
      dataExist
    );
  } else if (fromContext == "class") {
    Index = parseInt(state.Class.StatusDetail.indexOf_Test);
    selectedStatusCode = statusCodeSelection(
      state.Class.ActualList.tests[Index],
      dataExist
    );
  } else {
    selectedStatusCode = null;
  }

  switch (fromContext) {
    case "district":
      if (selectedStatusCode !== null) {
        return {
          ...state,
          District: {
            ...state.District,
            Apicalls: {
              ...state.District.Apicalls,
              GetDetailsData: true,
              loadingOnGetDetailsData: true,
            },
            StatusDetail: {
              ...state.District.StatusDetail,
              selectedStatus: selectedStatusCode,
              selectedTest: state.District.ActualList.tests[Index],
            },
          },
        };
      } else {
        Index = parseInt(state.District.StatusDetail.indexOf_Test) + 1;

        return {
          ...state,
          District: {
            ...state.District,
            Apicalls: {
              ...state.District.Apicalls,
              Check_AssignmentIDAvailable: true,
            },
            StatusDetail: {
              ...state.District.StatusDetail,
              indexOf_Test: Index,
              selectedTest: state.District.ActualList.tests[Index],
            },
          },
        };
      }
    case "school":
      if (selectedStatusCode != null) {
        return {
          ...state,
          School: {
            ...state.School,
            Apicalls: {
              ...state.School.Apicalls,
              GetDetailsData: true,
              loadingOnGetDetailsData: true,
            },
            StatusDetail: {
              ...state.School.StatusDetail,
              selectedStatus: selectedStatusCode,
              selectedTest: state.School.ActualList.tests[Index],
            },
          },
        };
      } else {
        Index = parseInt(state.School.StatusDetail.indexOf_Test) + 1;

        return {
          ...state,
          School: {
            ...state.School,
            Apicalls: {
              ...state.School.Apicalls,
              Check_AssignmentIDAvailable: true,
            },
            StatusDetail: {
              ...state.School.StatusDetail,
              indexOf_Test: Index,
              selectedTest: state.School.ActualList.tests[Index],
            },
          },
        };
      }
    case "class":
      if (selectedStatusCode != null) {
        return {
          ...state,
          Class: {
            ...state.Class,
            Apicalls: {
              ...state.Class.Apicalls,
              GetDetailsData: true,
              loadingOnGetDetailsData: true,
            },
            StatusDetail: {
              ...state.Class.StatusDetail,
              selectedStatus: selectedStatusCode,
              selectedTest: state.Class.ActualList.tests[Index],
            },
          },
        };
      } else {
        Index = parseInt(state.Class.StatusDetail.indexOf_Test) + 1;

        return {
          ...state,
          Class: {
            ...state.Class,
            Apicalls: {
              ...state.Class.Apicalls,
              Check_AssignmentIDAvailable: true,
            },
            StatusDetail: {
              ...state.Class.StatusDetail,
              indexOf_Test: Index,
              selectedTest: state.Class.ActualList.tests[Index],
            },
          },
        };
      }

    default:
      return {
        ...state,
      };
  }
}

export function getDatawhichIsTrue(DataIsThere) {
  let returnedList = [];

  if (DataIsThere["NotStarted"]) {
    returnedList.push("NotStarted");
  }
  if (DataIsThere["In Progress"]) {
    returnedList.push("in-progress");
  }
  if (DataIsThere["NeedsToBeGraded"]) {
    returnedList.push("need-tobe-graded");
  }
  if (DataIsThere["Complete"]) {
    returnedList.push("completed");
  }
  return returnedList;
}

export function statusCodeSelection(testSelected, codeList) {
  if (
    testSelected.inProgressCount !== null &&
    testSelected.inProgressCount !== 0 &&
    codeList.indexOf("in-progress") !== -1
  ) {
    return "in-progress";
  } else if (
    testSelected.needsToBeGradedCount !== null &&
    testSelected.needsToBeGradedCount !== 0 &&
    codeList.indexOf("need-tobe-graded") !== -1
  ) {
    return "need-tobe-graded";
  } else if (
    testSelected.notStartedCount !== null &&
    testSelected.notStartedCount !== 0 &&
    codeList.indexOf("NotStarted") !== -1
  ) {
    return "not-started";
  } else if (
    testSelected.completedCount !== null &&
    testSelected.completedCount !== 0 &&
    codeList.indexOf("completed") !== -1
  ) {
    return "completed";
  } else {
    return null;
  }
}
