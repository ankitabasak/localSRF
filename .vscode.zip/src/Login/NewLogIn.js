import React, { Component } from 'react';
import {
  Get_JWTToken_Authentication, DisplayNoDataView, SaveUserNameAndPass
} from '../Redux_Actions/AuthenticationAction';

import { connect } from 'react-redux';

import './style8.css';

import BGimage from '../../public/assets/background.jpg'
import { STANDALONE_MODE } from '../Utils/globalVars'
const BG = require('../../public/assets/background.jpg')

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      executableCounter: 0,
      error: '',
      userName: '',
      password: '',
      realm: ''
    }
  }

  LogInClick() {
    let Auth_LoginDetails = this.props.LoginDetails
    if (Auth_LoginDetails.password !== '' && Auth_LoginDetails.userName !== '' && Auth_LoginDetails.realm !== '') {
      this.props.Get_JWTToken_Authentication(Auth_LoginDetails.userName, Auth_LoginDetails.password, Auth_LoginDetails.realm);
    } else alert('user details are require to login');
  }

  componentDidMount() {

    if (!STANDALONE_MODE) {
      this.props.history.push('/reporting');
    }
  }

  componentDidUpdate() {
    let Auth_LoginDetails = this.props.LoginDetails;
    if (Auth_LoginDetails.loginSuccess) {
      this.props.history.push('/reporting');
    }
  }

  render() {
    return (
      <div
        className="backgroundcss">
        <div id="onlyLandscape">
          <p>Use Landscape mode for optimum viewing results.</p>
        </div>
        <div class="login">
          <div id="loginContainer">
            <div className="pagewrap">
              <h1 id="logo">Benchmark Universe</h1>
              <div className="pagewrap shrinked">

                <div className="form-wrap" align="center"><div>
                  <div className="loginMessage">{this.props.LoginDetails.errorCode == 401 ? "Logins are Incorrect" : ""}</div>
                  <div className="form-bg">
                    <form className="form">
                      <input type="text"
                        value={this.props.LoginDetails.userName}
                        placeholder="Type your user name"
                        name="username" className="field username"
                        onChange={(txt) => this.props.SaveUserNameAndPass(txt.target.value, 'username')
                          // this.setState({ userName: txt.target.value })
                        } />
                      <input type="password"
                        value={this.props.LoginDetails.password}
                        placeholder="Type your password" name="password"
                        className="field password"
                        onChange={(txt) => this.props.SaveUserNameAndPass(txt.target.value, 'password')
                          // this.setState({ password: txt.target.value })
                        } />
                      <input type="text"
                        value={this.props.LoginDetails.schoolId}
                        placeholder="Type your schoolId" name="schoolId"
                        className="field"
                        onChange={(txt) => this.props.SaveUserNameAndPass(txt.target.value, 'schoolId')
                          // this.setState({ password: txt.target.value })
                        } />
                      <select className="field selectBox"
                        value={this.props.LoginDetails.realm}
                        onSelect={(txt) => console.log(" txt.target.value :", txt.target.value)}
                        onChange={(txt) => this.props.SaveUserNameAndPass(txt.target.value, 'realm')}
                      ><option value="">Select Realm</option>
                        <option value="sulphur">sulphur</option>
                        <option value="sdusd">sdusd</option>
                        <option value="fcusd">fcusd</option>
                        <option value="dodea">dodea</option>
                        <option value="lausd">lausd</option>
                        <option value="fauquier">fauquier</option>
                        <option value="pwcs">pwcs</option>
                        <option value="bec-micro">bec-micro</option>
                        <option value="vibgyor">vibgyor</option>
                        <option value="dev">dev</option>
                        <option value="palmbeach">palmbeach</option>
                        <option value="saaseng">saaseng</option>
                        <option value="holtville">holtville</option>
                        <option value="bec-eassessment">bec-eassessment</option>
                        <option value="onlyardata">onlyardata</option>
                        <option value="ba-bec">ba-bec</option>
                        <option value="ardata">ardata</option>
                        <option value="onlyorrdata">onlyorrdata</option>
                        <option value="ardataorrdata">ardataorrdata</option>
                        <option value="bec-micro">bec-micro</option>
                        <option value="dublin">dublin</option>
                        <option value="tusd1">tusd1</option>
                        <option value="lammersville">lammersville</option>
                        <option value="fremont">fremont</option>
                      </select>
                      <a href="javascript:void(0)" id="sysCheck">System Check</a>
                      <a href="javascript:void(0)" id="forgotPass">Forgot Password?</a>
                      <input id="login"
                        style={{
                          background:
                            this.props.LoginDetails.disableLogIn ? "#cfd0d1" : ""
                        }}

                        onClick={() => {
                          // this.props.DisplayNoDataView();

                          this.LogInClick()
                          // this.props.history.push('/dashboard')
                          // this.props.history.push('/class/testscore/overview');
                        }}
                        type="button"
                        value="Sign In"
                        className="button" />

                    </form>
                  </div>
                  <div className="sso-login-buttons">
                  </div>
                  <div className="copy" style={{ marginTop: 0 }}>
                    <p style={{
                      marginBottom: 0,
                      marginTop: 0
                    }}>For information about a Benchmark Universe subscription, email <a className="techSupport" href="">Technical Support</a> or call (855)-245-9751.</p>
                  </div></div></div>

              </div>

              <footer>
                <div className="right">
                  <a id="privacyPolicy" href="javascript:void(0)" data-route="privacyPolicy">Privacy Policy</a> |
            <span id="copyWright"> © 2019 Benchmark Education Company, LLC</span>
                </div>
                <div className="clear"></div>
              </footer>
            </div>
          </div>
        </div>
      </div >
    );
  }
}
const mapStateToProps = ({ Authentication }) => {

  const { LoginDetails } = Authentication
  return { LoginDetails };
}

export default connect(mapStateToProps, {
  Get_JWTToken_Authentication, DisplayNoDataView, SaveUserNameAndPass

})(Login);