import 'react-app-polyfill/ie11';
import 'react-app-polyfill/stable';
import React from 'react';
import { HashRouter, Route, Switch, BrowserRouter } from 'react-router-dom';

// Styles
// Import Flag Icons Set
// Import Font Awesome Icons Set
// Import Simple Line Icons Set
// import 'simple-line-icons/css/simple-line-icons.css';
// Import Main styles for this application
// import '../scss/style.scss'
// import '../scss/core/_dropdown-menu-right.scss'
// Containers
import Main from './Components/Common/Main';

import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';

import configureStore from './Config_Setup/ReduxSetUp/ConfigStore';
import '../public/css/bootstrap.min.css';
import '../public/css/style.css';
import Login from './Login/NewLogIn'

/**
 * Enable this if we want to include redux persist.
 */
const { persistor, store } = configureStore();

const App = ({JWTToken = ''}) => (
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <HashRouter>
        <Switch>
          <Route exact path='/' component={Login} />
          <Main LoginDetailsFromIndex={{"selectedSchoolId": '', JWTToken }} />
        </Switch>
      </HashRouter>
    </PersistGate>
  </Provider>
);

export default App;
