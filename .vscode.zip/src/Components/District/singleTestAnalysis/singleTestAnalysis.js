import React, { Component } from 'react';
import { connect } from 'react-redux';

import ST_analysisPage from "../../../Utils/st_analysis/ST_analysisPage";
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class d_st_analysis extends Component {

    componentDidMount(){
        this.props.trackingUsage("assessmentreports_singletestanalysis:district");
    }
    render() { 
        let singleTestAnalysisData = this.props.district_TestAnalysis
        let fromContext = 'district'
        return (
            <ST_analysisPage fromContext={fromContext} singleTestData={singleTestAnalysisData} /> 
        );
    }
}

const mapStateToProps = ({ Universal, Authentication, SingleTestAnalysis }) => {

    const { district_TestAnalysis } = SingleTestAnalysis

    return {
        Universal, Authentication, district_TestAnalysis
    }
}

const mapStateToDispatch = {
    trackingUsage
}

export default connect(mapStateToProps,mapStateToDispatch)(d_st_analysis);
