import React, { Component } from 'react';


import Chart from '../../Utils/LineChart/LineChart';
import ChartPagination from '../../Utils/LineChart/LineChartPagination';
import OverviewDetailHeader from '../TestScore/OverView/OverviewDetail/OverviewDetailHeader';
import OverviewDetailStudentList from '../TestScore/OverView/OverviewDetail/OverviewDetailStudentList';
import {
    OpenOrCloseNoteIn_TS_OT, CheckCompareTabs,
    EnableOrDisableLineColorIn_LC
} from '../../Redux_Actions/ReportsActions';
import { convertUTCDateToLocalDate, ParamsForStudentsListTable, LineChartInput_Params, GetIds_of_Each_Object_In_The_Array } from './../ReusableComponents/AllReusableFunctions';
import CompareCheckBoxes from '../../Utils/CompareCheckBoxes';
import { connect } from 'react-redux';
import '../class/ClassMain.css';
import LoadingScreen from '../../Utils/LoadingScreen/LoadingScreen';

import { OpenOrCloseTooltipIn_D_Reports, Get_District_TestScores_Graph, Get_Selected_TS_Details_IN_Dist_Report } from '../../Redux_Actions/District_Report_Actions';
import TestScoreOverTimePDF from '../../Utils/PrintPDF/TestScoreOverTimePDF';
import TestScoreDetailListPDF from '../../Utils/PrintPDF/TestScoreDetailListPDF';
import info_icon from '../../../public/images/info_icon.svg';
import { ACHIEVEMENT_LEVELS_ENABLE, Disable_AutoSelect_TS_Overview_LeftView, DISPLAY_LOCAL_TIME_IN_UI } from '../../Utils/globalVars';
import Make_A_Selection_Msg from '../../Utils/Make_A_Selection';
import { trackingUsage } from '../../Redux_Actions/AuthenticationAction';
import { EnddateValues, StartdateValues } from '../../Utils/reUsableSnipets';
class d_ts_overview extends Component {
    constructor(props) {
        super(props);
        this.InfoPopUp = {},
            this.i_span_ref = {},
            this.InfoTooltipPopUp = {},
            this.i_span_tooltip_ref = {},
            this.state = {
                studentsData: []
            };
        this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
        this.SelectCompareOption = this.SelectCompareOption.bind(this);
        this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
    }

    componentWillMount() {
        this.Apicalls(this.props.ApiCalls.get_District_TS_graph);
        // this.Apicalls(true);
    }

    componentDidUpdate() {

        this.Apicalls(this.props.ApiCalls.get_District_TS_graph);
        this.GetSelected_Test_Class_List();

    }

    /**
      * Enable this when we need to show Info Icon At Test Scores Over Time.
      */
    componentDidMount() {
        document.addEventListener("mousedown", this.handleClickOutside_info);
        this.GetSelected_Test_Class_List();
        this.props.trackingUsage("assessmentreports_testscoresoverview:district");
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleClickOutside_info);
    }

    /**
     *
     * @param {Object} event
     * triggers when click on outside of info div At Test Scores Over Time Info Icon.
     */

    handleClickOutside_info(event) {
        if (event.target == null || event.target == undefined) {
            // this.handleMouseOut(this.props.ToolTipData);
        } else if (this.props.D_Test_Scores_OverTime.OpenInfoNote) {
            if (this.InfoPopUp !== null && this.InfoPopUp !== undefined) {
                let isitemexists = this.InfoPopUp.contains(event.target);
                let is_IExist = this.i_span_ref.contains(event.target)
                let ToolTipsRefsExists;
                if ((isitemexists == undefined || isitemexists == null || isitemexists == false) && (is_IExist == undefined || is_IExist == null || is_IExist == false)) {
                    // this.setState({ show_P_Overtime_Info: false })
                    this.props.OpenOrCloseNoteIn_TS_OT(false)
                }
            }
        } else if (this.props.D_Test_Scores_OverTime.openInfoTooltip_in_TS) {
            if (this.InfoTooltipPopUp !== null && this.InfoTooltipPopUp !== undefined) {
                let isitemexists = this.InfoTooltipPopUp.contains(event.target);
                let is_IExist = this.i_span_tooltip_ref.contains(event.target)
                if ((isitemexists == undefined || isitemexists == null || isitemexists == false) && (is_IExist == undefined || is_IExist == null || is_IExist == false)) {
                    this.props.OpenOrCloseTooltipIn_D_Reports(false, "T_Scores")
                }
            }
        }
    }

    /**
     *
     * @param {String} SelectedOption
     * this will trigger when  option is selected from CompareCheckBoxes.js component.
     */
    SelectCompareOption(SelectedOption, Check) {
        let SchoolData = this.props.D_Test_Scores_OverTime.Actual_School_LC_List;
        let SchoolDataChecked = this.props.D_Test_Scores_OverTime.checkSchool;
        let DistrictData = this.props.D_Test_Scores_OverTime.Actual_District_LC_List;
        let DistrictDataChecked = this.props.D_Test_Scores_OverTime.checkDistrict;
        this.props.CheckCompareTabs(SelectedOption, Check);

    }

    /**
     * when user click on checbox comp label, then it will execute
     */
    ClickOnLabelName(labelName, checkOrUncheck) {

        this.props.EnableOrDisableLineColorIn_LC(labelName, checkOrUncheck);
    }

    /**
     *
     * @param {Boolean} shoulddoApiCall
     * @paaram {Boolean} isSchool ,
     * @param {Boolean} isDistrict
     * if param is true then will make api call to
     */
    Apicalls(shoulddoApiCall, isSchool, isDistrict) {

        const { getTests, loadingFor } = this.props.ApiCalls;
        if (shoulddoApiCall && !getTests && loadingFor !== "tests") {

            let AccessToken = this.props.LoginDetails.JWTToken;
            let Context_Header = this.props.ContextHeader;
            let Selected_List = Context_Header.TestTab.TestList.filter(item => item.check)
            let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');

            // let ClassList = [];
            // Context_Header.ClassList_Actual.map(classitem => ClassList.push(classitem.id))


            let Sc_Ids = Context_Header.Roster_Tab.SchoolIds.length ==
                Context_Header.Roster_Tab.schoolsList.length ? [] : Context_Header.Roster_Tab.SchoolIds
            let currentTermId = this.props.currentTermID;

            let startDate = Context_Header.Date_Tab.Report_termStartDate;
            let endDate = Context_Header.Date_Tab.Report_termEndDate;
            let districtId = Context_Header.DistrictId;
            
            if (startDate == undefined || startDate == "") {
                startDate = StartdateValues(this.props.Context_DateTab);
            }
            if (endDate == undefined || endDate == "") {
                endDate = EnddateValues(this.props.Context_DateTab);
            }
            if (districtId == undefined) {
                districtId = Context_Header.Default_districtID;
            }

            let TS_Details_Req_Payload = {
                "componentCodeList": SelectedTests,
                "districtId": districtId,
                "startDate": startDate,
                "endDate": endDate,
                "schoolIds": Sc_Ids,
                "classIds": Context_Header.Roster_Tab.ClassIds,
                "studentIds": Context_Header.Roster_Tab.StudentIds,
                "rosterGrade": Context_Header.Roster_Tab.selectedRosterGrade,
                "termId": Context_Header.Date_Tab.selectedTermId,
                "isPastDistrictTerm": Context_Header.Date_Tab.isPastDistrictTerm,
                "currentTermId": currentTermId, // datetab api response first alpha term_id
                "isCustomAchievements": ACHIEVEMENT_LEVELS_ENABLE
            };
            let Enableload = true;

            this.props.Get_District_TestScores_Graph(AccessToken, TS_Details_Req_Payload, Enableload)
        }
    }

    GetSelected_Test_Class_List() {

        let D_API_ = this.props.D_ApiCalls;

        if (D_API_.get_TS_Details) {

            let AccessToken = this.props.LoginDetails.JWTToken;
            let Context_Header = this.props.ContextHeader;
            let test = this.props.D_Test_Scores_OverTime.SelectedTestData

            let Selected_List = Context_Header.TestTab.TestList.filter(item => item.check)
            let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
            if(SelectedTests == undefined || SelectedTests.length == 0){
                Selected_List = this.props.UniversalSelecter.TestTab.TestList.filter(item => item.check)
                SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
            }

            let Sc_Ids = Context_Header.Roster_Tab.SchoolIds.length ==
                Context_Header.Roster_Tab.schoolsList.length ? [] : Context_Header.Roster_Tab.SchoolIds
            let currentTermId = this.props.currentTermID;
            const {Context_DateTab} = this.props;
            let districtId = Context_Header.DistrictId;
            let startDate = Context_Header.Date_Tab.Report_termStartDate;
            let endDate = Context_Header.Date_Tab.Report_termEndDate;
            if (startDate == undefined || startDate == "") {
                startDate = StartdateValues(Context_DateTab);
            }
            if (endDate == undefined || endDate == "") {
                endDate = EnddateValues(Context_DateTab);
            }
            if (districtId == undefined) {
                districtId = Context_Header.Default_districtID;
            }
            let reqPayload = {
                "schoolIds": Sc_Ids,
                "districtId": districtId,
                "componentCode": test.componentCode, //mandatory
                "startDate": startDate,
                "endDate": endDate,
                "studentIds": Context_Header.Roster_Tab.StudentIds,
                "classIds": Context_Header.Roster_Tab.ClassIds,
                "componentCodeList": SelectedTests,
                "rosterGrade": Context_Header.Roster_Tab.selectedRosterGrade,
                "termId": Context_Header.Date_Tab.selectedTermId,
                "isPastDistrictTerm": Context_Header.Date_Tab.isPastDistrictTerm,
                "currentTermId": currentTermId, // datetab api response first alpha term_id
                "isCustomAchievements": ACHIEVEMENT_LEVELS_ENABLE
            }

            let enableLoading = true
            this.props.Get_Selected_TS_Details_IN_Dist_Report(AccessToken, reqPayload, test, enableLoading);

        }
    }

    render() {
        let Test_Scores_Details = this.props.D_TS_School_ListTable.ActualList;
        let GraphPagination = this.props.D_StandardPerformance_Overview.LineChart_Pagination;
        let PerformanceFilter = this.props.D_StandardPerformance_Overview.StandardPerformanceFilter;
        let selectedTestAssessment;
        let selectedTestGrade;
        selectedTestAssessment = PerformanceFilter.TestAssessment.selectedTestAssessment;
        selectedTestGrade = PerformanceFilter.TestGrade.selectedTestgrade == '' ||
            PerformanceFilter.TestGrade.selectedTestgrade == null ? '' :
            PerformanceFilter.TestGrade.selectedTestgrade.grade;
        let ActualListForGraph = JSON.parse(JSON.stringify(this.props.D_StandardPerformance_Overview.ActualLineChartData));
        // let Pagination_Start = GraphPagination.Chart_Page_Count_Start;
        // let Pagination_End = GraphPagination.Chart_Page_Count_End;
        let ToolTipData = this.props.D_StandardPerformance_Overview.Strands_ToolTipData;
        let StrandReducer = this.props.D_StandardPerformance_Overview;
        let TotalQuestions = ActualListForGraph.reduce((initial, item) => initial + parseInt(item.totalQuestions), 0);
        let Standard_performance_details = this.props.D_StandardPerformance_Overview;
        let ClassChecked = false;
        //API modified changes
        if (Test_Scores_Details.studentTestScoreList != undefined) {
            Test_Scores_Details = Test_Scores_Details.studentTestScoreList;
        }

        let { lessthan40Studentcount, l40width, l40to59Studentcount, l40to59width, l60to79Studentcount,
            l60to79width, l80Studentcount, g80width, totalStudentCount, totalAverageScore, testName,
            submittedStartDate, submittedEndDate, sortedValue } = ParamsForStudentsListTable(Test_Scores_Details.testScoreList, this.props.D_TS_School_ListTable.SortedArray, this.props.NavigationByHeaderSelection, this.props.AchivementLevels)

        let Ts_Score_Redux_Props = this.props.D_Test_Scores_OverTime;
        let Array = JSON.parse(JSON.stringify(Ts_Score_Redux_Props.ActualLineChartList));
        let Compare_School_List = [...Ts_Score_Redux_Props.Actual_School_LC_List];
        let Compare_District_List = [...Ts_Score_Redux_Props.Actual_District_LC_List];
        let Pagination_Start = this.props.D_LineChart_Pagination.Chart_Page_Count_Start;
        let Pagination_End = this.props.D_LineChart_Pagination.Chart_Page_Count_End;
        let ApiClassReports = this.props.D_ApiCalls;
        const { XAxis_Params, YAxis_Params, DatatPointParams, tooltipParams, data,
            margin, width, height, Ipadwidth, Ipadheight, dataset_2, dataset_3
        } = LineChartInput_Params(Array, Pagination_Start, Pagination_End, 'd_ts_overview', Compare_School_List, Compare_District_List)

        let { SelectedTestData } = this.props.D_Test_Scores_OverTime
        testName = SelectedTestData.testName;

        const selectedTest_submitStart = (DISPLAY_LOCAL_TIME_IN_UI === true) ? (SelectedTestData.submitStart !== undefined ? convertUTCDateToLocalDate(SelectedTestData.submitStart, SelectedTestData.submitStartTime) : SelectedTestData.submitStart) : SelectedTestData.submitStart;

        const selectedTest_submitEnd = (DISPLAY_LOCAL_TIME_IN_UI === true) ? (SelectedTestData.submitEnd !== undefined ? convertUTCDateToLocalDate(SelectedTestData.submitEnd, SelectedTestData.submitEndTime) : SelectedTestData.submitEnd) : SelectedTestData.submitEnd;

        const Compare_School = [...dataset_2];
        const Compare_District = [...dataset_3];
        const SchoolChecked = Ts_Score_Redux_Props.checkSchool;
        const DistrictChecked = Ts_Score_Redux_Props.checkDistrict;
        const LastChecked_CB = Ts_Score_Redux_Props.lastSelectedCheckBox;
        const DataToDisplayForStudentsList = this.props.D_TS_School_ListTable.List.testScoreList;
        let LoadingLinechart = ApiClassReports.loading_on_TS_LC || this.props.ApiCalls.loadingFor == "tests"


        // All related to PDF
        let HeaderDetailsForPrint = this.props.ContextHeader;
        let TestDetailsForPrint = {
            testName,
            submittedStartDate,
            submittedEndDate
        }
        let CompareOptionsForPrint = {
            TS_Overtime: this.props.D_Test_Scores_OverTime,
            LastChecked_CB: LastChecked_CB
        }
        let MetaDataForPrint = {
            totalListCount: totalStudentCount,
            totalAverageScore: totalAverageScore,
            sortedValue: sortedValue,
            l40: lessthan40Studentcount,
            l40width: l40width,
            g40tol59: l40to59Studentcount,
            l40to59width: l40to59width,
            g60tol79: l60to79Studentcount,
            l60to79width: l60to79width,
            g80: l80Studentcount,
            g80width: g80width,
            Pagination_Start,
            Pagination_End
        }
        // End of PDF Stuff

        let NoTestSelectedInGraph = (testName == undefined || testName == null) && !ApiClassReports.get_TS_Details && !ApiClassReports.loading_on_TS_LC && Disable_AutoSelect_TS_Overview_LeftView

        return (
            <div className="class_main">
                <div className="class_main_center">
                    <div className="class_main_inr">

                        <div className="class_left_block" style={{ position: "relative" }}>
                            <div className="class_widget_title test_score_overtime overrightinfostyle">
                                <span className="float-left">Test Scores over Time
                </span>
                                <span onClick={() => this.props.OpenOrCloseTooltipIn_D_Reports(true, "T_Scores")}>
                                    <span ref={(refs) => refs == null ? null : this.i_span_tooltip_ref = refs}><img src={info_icon} style={{ cursor: "pointer" }} /></span>
                                    {Ts_Score_Redux_Props.openInfoTooltip_in_TS ?
                                        <div className="infoIconTooltipBlock_TS">
                                            <div
                                                ref={(InfoTooltipPopUp) => InfoTooltipPopUp !== null ? this.InfoTooltipPopUp = InfoTooltipPopUp : null}
                                                className="infoIconTooltipBlockInr">
                                                <span className="infoIconTooltipBlockArrow_TS" style={{ padding: "0px" }}></span>
                                                <b>Note:</b> The average score listed in the line graph below is calculated from all data available for each assessment based on the context selected. It does not assume the cohort of students remains the same across the assessments listed.
</div>
                                        </div>
                                        : null}
                                </span>
                                {!LoadingLinechart ? <span className="float-left" style={{ padding: "0px" }}><TestScoreOverTimePDF
                                    data={data} XAxis_Params={XAxis_Params}
                                    Pagination={GraphPagination}
                                    selectedTestAssessment={selectedTestAssessment}
                                    selectedTestGrade={selectedTestGrade}
                                    YAxis_Params={YAxis_Params}
                                    DataSetParam={DatatPointParams}
                                    TooltipParams={tooltipParams}
                                    ToolTipData={this.props.D_ToolTipData}
                                    ClassChecked={ClassChecked}
                                    SchoolChecked={SchoolChecked}
                                    DistrictChecked={DistrictChecked}
                                    LastChecked_CB={LastChecked_CB}
                                    Navselection={this.props.NavigationByHeaderSelection.class}//this.props.nav
                                    TS_Overtime={this.props.D_Test_Scores_OverTime}
                                    CheckeThis={this.SelectCompareOption}
                                    ClickOnLabel={this.ClickOnLabelName}
                                    totalAverageScore={StrandReducer.selectedStandarAvg}
                                    totalQuestions={TotalQuestions}
                                    standardName={StrandReducer.StrandNameOfSelectedStandard}
                                    strandName={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDef}
                                    strandDetailsDesc={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardName}
                                    strandDescription={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDesc}
                                />
                                </span> : null}
                            </div>
                            <div>

                                {!LoadingLinechart ?
                                    <div style={{ width: '100%', float: 'left' }}>
                                        <div style={{ width: '100%', float: 'left' }}>
                                            <Chart margin={margin}
                                                width={this.props.UserScreenWidth < 1230 ? Ipadwidth : width}
                                                height={this.props.UserScreenWidth < 1230 ? Ipadheight : height}
                                                data={data}
                                                Compare_School={Compare_School}
                                                Compare_District={Compare_District}
                                                XAxis_Params={XAxis_Params} YAxis_Params={YAxis_Params}
                                                DataSetParam={DatatPointParams}
                                                SchoolChecked={SchoolChecked}
                                                DistrictChecked={DistrictChecked}
                                                LastChecked_CB={LastChecked_CB}
                                                ToolTipData={this.props.D_ToolTipData}
                                                TooltipParams={tooltipParams}
                                            // data2={data2} data3={data3}
                                            />
                                        </div>
                                        {this.props.D_LineChart_Pagination.Chart_TotalBubbles > 1 ?
                                            <ChartPagination
                                                pagination={this.props.D_LineChart_Pagination}
                                            /> : null}
                                        <div className="Test_names_label" style={{ float: 'left', paddingTop: 15 }}>Test Names</div>
                                    </div> : <LoadingScreen />}
                            </div>
                        </div>
                        <div className="centre_line"></div>
                        <div className="class_right_block" style={{ position: "relative" }}>
                            <div className="class_widget_title "><span className="float-right">Test Score Detail
                            {(ApiClassReports.loading_LC_students == false) && (this.props.D_TS_School_ListTable.List_Includes_NullScores.testScoreList !== undefined && this.props.D_TS_School_ListTable.List_Includes_NullScores.testScoreList.length > 0) ? <TestScoreDetailListPDF
                                    Header={HeaderDetailsForPrint}
                                    TestDetails={TestDetailsForPrint}
                                    CompareOptions={CompareOptionsForPrint}
                                    MetaData={MetaDataForPrint}
                                    sortedArrayData={this.props.D_TS_School_ListTable.SortedArray}
                                    ActualList={this.props.D_TS_School_ListTable.ActualList}
                                    Data={this.props.D_TS_School_ListTable}
                                    DataToDisplay={DataToDisplayForStudentsList}
                                    PaginationData={this.props.Pagination_For_Remaining}
                                    fromComp="d_ts_overview"
                                /> : null}
                            </span></div>

                            {NoTestSelectedInGraph ? <Make_A_Selection_Msg
                                message="Make a selection in the graph to see details." />
                                : ApiClassReports.loading_LC_students == false && !LoadingLinechart ?
                                    <div className="standard-widget-class_level">
                                        <OverviewDetailHeader
                                            fromComp="d_ts_overview"
                                            checkSchool={this.props.D_Test_Scores_OverTime.checkSchool}
                                            checkDistrict={this.props.D_Test_Scores_OverTime.checkDistrict}
                                            Data={this.props.D_TS_School_ListTable}
                                            ActualList={this.props.D_TS_School_ListTable.ActualList}
                                            l40={lessthan40Studentcount} l40width={l40width} g40tol59={l40to59Studentcount}
                                            l40to59width={l40to59width} g60tol79={l60to79Studentcount} l60to79width={l60to79width}
                                            g80={l80Studentcount} g80width={g80width} studentTotalC={totalStudentCount} averagescore={totalAverageScore}
                                            testName={testName} startDate={selectedTest_submitStart} endDate={selectedTest_submitEnd} />

                                        <OverviewDetailStudentList
                                            totalstudentcount={totalStudentCount}
                                            studentsdata={Test_Scores_Details}
                                            sortedValue={sortedValue}
                                            Data={this.props.D_TS_School_ListTable}
                                            pagination={this.props.D_Pagination_For_Remaining}
                                            DataToDisplay={DataToDisplayForStudentsList}
                                            sortedArrayData={this.props.D_TS_School_ListTable.SortedArray} />
                                    </div> : <LoadingScreen />}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = ({ Reports, Universal, Authentication, DistrictReducer,DateTabReducer }) => {

    const { LoginDetails, UserScreenWidth } = Authentication;
    const { AchivementLevels, ContextHeader, ApiCalls, UniversalSelecter, NavigationByHeaderSelection,currentTermID } = Universal

    const { D_StandardPerformance_Overview, D_Test_Scores_OverTime, D_LineChart_Pagination, D_ApiCalls, D_TS_School_ListTable, D_ToolTipData,
        D_Pagination_For_Remaining
    } = DistrictReducer;
    const { Context_DateTab } = DateTabReducer;
    return {
        D_StandardPerformance_Overview, D_LineChart_Pagination, LoginDetails, AchivementLevels, ContextHeader, ApiCalls,
        UniversalSelecter, NavigationByHeaderSelection, UserScreenWidth, D_Pagination_For_Remaining,
        D_ToolTipData, D_ApiCalls, D_TS_School_ListTable,
        D_Test_Scores_OverTime, currentTermID, Context_DateTab
    };
}

export default connect(mapStateToProps, {
    OpenOrCloseNoteIn_TS_OT, CheckCompareTabs,
    EnableOrDisableLineColorIn_LC, Get_District_TestScores_Graph, Get_Selected_TS_Details_IN_Dist_Report, OpenOrCloseTooltipIn_D_Reports,trackingUsage
})(d_ts_overview);
