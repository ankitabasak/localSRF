import React, { Component } from "react";
import { connect } from "react-redux";

import {
  convertToNumberGrade,
  ParamsForStudentsListTable,
  LineChartInput_Params,
  GetIds_of_Each_Object_In_The_Array,
} from "../ReusableComponents/AllReusableFunctions";
import {
  SummaryBlock,
  DetailsBlock,
} from "../../Utils/TestStatus/TestScore_Blocks";
import {
  openPopUpInTestStatusPrint,
  handleApplyFilterInTestStatus,
} from "../../Redux_Actions/TestStatusPrintActions";
import {
  OnTestStatusSelection,
  SortTestStatusSummaryData,
  SortTestStatusDetailsData,
  Get_TestStatusSummaryData,
  Get_TestStatusSummaryDataCount,
  Check_ISAssignmentIDAvailable,
  Get_TestStatusDetailsData,
  Pagination_Bubble_Selection,
  Pagination_Navigate_Selection,
  OpenOrClose_TestStatus_Info_Popup,
  ShowAllResults,
} from "../../Redux_Actions/TestStatus.Actions";

import {
  OnGoTo_ST_Analysis,
  DrillDownToSchool_TestStatus,
} from "../../Redux_Actions/UniversalSelectorActions_Primary";
import { SaveContextSelection } from "../../Redux_Actions/UniversalSelectorActions";
import ic_print from "../../../public/images/ic_print_new.svg";
import info_icon from "../../../public/images/info_icon.svg";
import {
  Call_TestStatusSummaryData,
  Call_TestStatusDetailsData,
  triggerPdfDownload,
} from "../../services/testStatus.service";
import TestStatusPopup from "../../Utils/TestStatusPrintModel/testStatusPrint";
import DistrictTestStatusPDF from "../../Components/ReusableComponents/TestStatusPDF/DistrictTestStatusPDF";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";
import ic_test_status from "../../../public/images/ic_test_status.svg";

class d_TestStatus extends Component {
  constructor(props) {
    super(props);
    this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
    (this.P_OT_infoRef = {}), this.Note_InfoRefs;
    (this.InfoTooltipPopUp = {}),
      (this.i_span_tooltip_ref = {}),
      (this.SortTableData = this.SortTableData.bind(this));
    this.SortDetailsData = this.SortDetailsData.bind(this);
    this.OnStatusSelection = this.OnStatusSelection.bind(this);
    this.NavToSingleTest = this.NavToSingleTest.bind(this);
    this.OnSelecting_ItemName_InRightSide =
      this.OnSelecting_ItemName_InRightSide.bind(this);
    // this.OnGoTo_ST_Analysis = this.OnGoTo_ST_Analysis.bind(this)
    this.state = {
      OpenPerformanceOT: false,
      OpenStudentsList: true,
      show_P_Overtime_Info: false,
    };
  }

  componentDidMount() {
    Call_TestStatusSummaryData(this.props, "district");
    Call_TestStatusDetailsData(this.props, "district");
    triggerPdfDownload(
      this.props,
      "district",
      this.props.districtTestStatusPrint.triggerAPI
    );
    document.addEventListener("mousedown", this.handleClickOutside_info);
    this.props.trackingUsage("assessmentreports_teststatussummary:district");
  }

  componentDidUpdate(prevProps, prevState) {
    Call_TestStatusSummaryData(this.props, "district");
    Call_TestStatusDetailsData(this.props, "district");
    triggerPdfDownload(
      this.props,
      "district",
      this.props.districtTestStatusPrint.triggerAPI
    );
    if (
      prevProps.TestStatusReducer.District.Apicalls.GetDetailsData !==
        this.props.TestStatusReducer.District.Apicalls.GetDetailsData &&
      this.props.TestStatusReducer.District.Apicalls.GetDetailsData
    ) {
      this.props.trackingUsage("assessmentreports_teststatusdetail:district"); //call usage tracking here for test status details
    }
  }
  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside_info);
  }
  handleClickOutside_info(event) {
    if (event.target == null || event.target == undefined) {
    } else if (this.props.TestStatusReducer.District.openInfoPopUp) {
      if (this.Note_InfoRefs !== null && this.Note_InfoRefs !== undefined) {
        let isitemexists = this.Note_InfoRefs.contains(event.target);
        if (
          isitemexists == undefined ||
          isitemexists == null ||
          isitemexists == false
        ) {
          this.props.OpenOrClose_TestStatus_Info_Popup(
            false,
            this.props.NavigationByHeaderSelection
          );
        }
      }
    }
  }

  renderAllResultsBlock(Roster_Tab) {
    const { selectedStatus } =
      this.props.TestStatusReducer.District.PersistedDataFromSum;
    return (
      selectedStatus != null &&
      selectedStatus != "" && (
        <div
          className="ts_show_all_result_block"
          onClick={() => this.props.ShowAllResults("district")}
        >
          <div className="ts_all_result_tooltip">
            <span class="ts_all_result_tooltip_arrow"></span>
            <span class="ts_show_all_result_tooltip_text">
              Shows all tests for Grade{" "}
              {convertToNumberGrade(Roster_Tab.selectedRosterGrade)}
            </span>
          </div>
          <img src={ic_test_status} width="17.13px" height="18px" />
          <span className="ts_show_all_result_txt"> Show All Results</span>
        </div>
      )
    );
  }

  render() {
    const { ContextHeader } = this.props;
    const { Roster_Tab } = ContextHeader;
    let StatusDetails = this.props.TestStatusReducer.District.StatusDetail;
    let TestStatus_Info_Popup =
      this.props.TestStatusReducer.District.openInfoPopUp;
    const { loadingOnGetSummaryData, loadingOnGetDetailsData } =
      this.props.TestStatusReducer.District.Apicalls;
    let TestApiOr_SchoolApi =
      this.props.ApiCalls.getTests ||
      this.props.ApiCalls.Get_Selected_School_Info ||
      this.props.ApiCalls.loadingFor == "tests" ||
      this.props.ApiCalls.loadingFor == "school";

    const testSummaryLoading = loadingOnGetSummaryData && !TestApiOr_SchoolApi;
    const testDetailLoading = loadingOnGetDetailsData;

    const districtTestStatusPrint = this.props.districtTestStatusPrint;
    const sortingDataPDF = {
      summaryLevel: {
        SortStatus: this.props.TestStatusReducer.District.SortStatus,
        SortStatus_Type: this.props.TestStatusReducer.District.SortStatus_Type,
      },
      detailLevel: {
        SortStatus: StatusDetails.SortField,
        SortStatus_Type: StatusDetails.SortType,
      },
    };
    return (
      <div className="testStatus">
        {districtTestStatusPrint.triggerPDF ? <DistrictTestStatusPDF /> : null}
        {/*  */}
        {districtTestStatusPrint !== undefined ? (
          districtTestStatusPrint.popupStatus ? (
            <TestStatusPopup
              testStatusPrintData={districtTestStatusPrint}
              contextSelected="district"
            />
          ) : null
        ) : null}
        {/*  */}
        <div className="testStatusMain">
          <div className="testStatus_header">
            <div className="testStatus_summary_head">
              Summary{" "}
              <span
                onClick={() =>
                  this.props.OpenOrClose_TestStatus_Info_Popup(
                    true,
                    this.props.NavigationByHeaderSelection
                  )
                }
                // ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                className="infoIconBlock"
              >
                <img src={info_icon} />
                {TestStatus_Info_Popup ? (
                  <div className="infoIconTooltipBlock_TestStatus">
                    <div
                      ref={(ref) =>
                        ref !== null ? (this.Note_InfoRefs = ref) : null
                      }
                      className="infoIconTooltipBlockInr_TestStatus"
                    >
                      <span className="infoIcon_Tooltip_BlockArrow_Test_Status"></span>
                      <b>Note:</b> Students who have taken a test more than once
                      will be repeated in the test status results.
                    </div>
                  </div>
                ) : null}
              </span>
              {(!loadingOnGetSummaryData) && this.renderAllResultsBlock(Roster_Tab)}
            </div>
            <div className="testStatus_detail_head">
              <span className="testStatus_detail_head_title">Detail</span>
              {!loadingOnGetSummaryData && (
                <span
                  className="testStatus_detail_print"
                  onClick={() => {
                    this.props.openPopUpInTestStatusPrint(
                      "district",
                      sortingDataPDF,
                      StatusDetails
                    );
                  }}
                >
                  <img src={ic_print} />
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="testStatus_mainBlock">
          {SummaryBlock(
            this.props.TestStatusReducer.District,
            this.SortTableData,
            this.OnStatusSelection,
            this.props.Pagination_Bubble_Selection,
            this.props.Pagination_Navigate_Selection,
            testSummaryLoading,
            "district",
            this.props.ApiCalls.loadingFor == "tests"
          )}
          {DetailsBlock(
            testSummaryLoading,
            StatusDetails,
            this.SortDetailsData,
            this.props.Pagination_Bubble_Selection,
            this.props.Pagination_Navigate_Selection,
            testDetailLoading,
            this.props.NavigationByHeaderSelection,
            this.props.ContextHeader,
            () => this.props.OnGoTo_ST_Analysis(),
            this.NavToSingleTest,
            this.OnSelecting_ItemName_InRightSide,
            "district",
            this.props.ApiCalls.loadingFor == "tests"
          )}
        </div>
      </div>
    );
  }

  NavToSingleTest(option) {
    this.props.SaveContextSelection(option);
  }

  SortTableData(sortType, sortOn) {
    this.props.SortTestStatusSummaryData(sortType, sortOn, "district");
  }

  OnStatusSelection(selectedItem, selectedStatus) {
    let Nav = this.props.NavigationByHeaderSelection;

    this.props.OnTestStatusSelection(
      selectedItem,
      selectedStatus,
      "district",
      Nav
    );
  }

  SortDetailsData(sortType, sortOn) {
    this.props.SortTestStatusDetailsData(sortType, sortOn, "district");
  }

  OnSelecting_ItemName_InRightSide(selected) {
    this.props.DrillDownToSchool_TestStatus(selected);
  }

  // Pagination_Bubble_Selection(BubbleStart, positionfrom_BubbleStart, fromContext_Blog) {

  //     // let Page_At_RP = action.payload.positionfrom_BubbleStart + action.payload.BubbleStart;
  //     // let start_RP;
  //     // let end_RP;
  //     // let Page_Count_RP;
  //     // Page_Count_RP = COUNT_END_SUMMARY
  //     // start_RP = (Page_At_RP * Page_Count_RP) - Page_Count_RP;
  //     // end_RP = Page_At_RP * Page_Count_RP;
  // }

  // Pagination_Navigate_Selection(Left_Or_Right, Current_Bubble_STart, fromContext_Blog) {
  // }
}

const mapStateToProps = ({
  StudentReports,
  Reports,
  Universal,
  Authentication,
  TestStatusReducer,
  DateTabReducer,
  TestStatusPrintReducer,
}) => {
  const { Class, StandardPerformance_Overview, ToolTipData, ApiCalls_Reports } =
    Reports;
  const { S_ApiCalls, S_StandardPerformance_Overview } = StudentReports;
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    currentTermID,
  } = Universal;
  const { districtTestStatusPrint } = TestStatusPrintReducer;
  return {
    Class,
    LoginDetails,
    ContextHeader,
    ApiCalls,
    ToolTipData,
    ApiCalls_Reports,
    StandardPerformance_Overview,
    UniversalSelecter,
    S_StandardPerformance_Overview,
    NavigationByHeaderSelection,
    S_ApiCalls,
    districtTestStatusPrint,
    TestStatusReducer,
    DateTabReducer,
    Universal,
    currentTermID,
  };
};

export default connect(mapStateToProps, {
  OnTestStatusSelection,
  SortTestStatusSummaryData,
  SortTestStatusDetailsData,
  Pagination_Bubble_Selection,
  Pagination_Navigate_Selection,
  OpenOrClose_TestStatus_Info_Popup,
  Get_TestStatusSummaryData,
  Get_TestStatusSummaryDataCount,
  Check_ISAssignmentIDAvailable,
  Get_TestStatusDetailsData,
  OnGoTo_ST_Analysis,
  SaveContextSelection,
  DrillDownToSchool_TestStatus,
  openPopUpInTestStatusPrint,
  handleApplyFilterInTestStatus,
  trackingUsage,
  ShowAllResults,
})(d_TestStatus);
