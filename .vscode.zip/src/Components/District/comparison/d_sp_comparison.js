import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    Comparison_Popup
} from '../../../Redux_Actions/ComparisonActions';

import Std_Perf_ComparisonPopup from "../../../Utils/Comparison/Std_Perf_ComparisonPopup";
import Std_Perf_ComparisonPage from "../../../Utils/Comparison/Std_Perf_ComparisonPage";
import Compare_Comp_Apis from '../../../Utils/Comparison/Compare_Comp_Apis';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class d_sp_comparison extends Component {

    constructor(props) {
        super(props);
    }
    componentDidMount(){
        this.props.trackingUsage("assessmentreports_standardperformancecomparison:district");
    }

    render() {

        const districtComparison = this.props.districtComparison.Std_Comparison

        const popupFilter = districtComparison.PopupFilter;
        let Nav = this.props.NavigationByHeaderSelection;
        let fromNavContext = "district";
        return (
            <div>
                <Compare_Comp_Apis
                    comparisonData={districtComparison}
                    fromContext={fromNavContext}
                    fromtab="std_performance"
                    popupData={popupFilter}
                />
                {popupFilter.openPopup
                    // && (popupFilter.Strands_And_Standards.Original_List_temp.length != 0)
                    ? <Std_Perf_ComparisonPopup
                        comparisonData={districtComparison}
                        fromContext={fromNavContext}
                        fromtab="std_performance"
                        popupData={popupFilter} /> : null}
                {districtComparison.ComparisonData.Operational_Data != null ?
                    <Std_Perf_ComparisonPage fromContext={fromNavContext} fromtab="std_performance" comparisonData={districtComparison} />
                    : null}
            </div>
        )
    }
}

const MapStateToProps = ({ Universal, Authentication, ComparisonReducer, Reports }) => {

    const { ContextHeader, NavigationByHeaderSelection } = Universal

    const { districtComparison } = ComparisonReducer

    const { StandardPerformance_Overview } = Reports

    return {
        Universal, Authentication, ContextHeader, districtComparison, NavigationByHeaderSelection, StandardPerformance_Overview
    }
}

const MapActionToProps = {
    Comparison_Popup,
    trackingUsage
}

export default connect(MapStateToProps, MapActionToProps)(d_sp_comparison);

// Custom functions to perform some actions

export function SelectedTestList(testsList) {

    let ComponentsList = [];
    testsList == undefined ? null : testsList.map((test, i) => {
        // if (test.productId == SelectedProductID) {
        ComponentsList.push(test.componentCode);
        //}
    })
    return ComponentsList;
}