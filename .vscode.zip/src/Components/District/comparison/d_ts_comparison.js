import React, { Component } from 'react';
import { connect } from 'react-redux';
import {

} from '../../../Redux_Actions/ComparisonActions';

import LoadingScreen from '../../../Utils/LoadingScreen/LoadingScreen';
import { GetIds_of_Each_Object_In_The_Array } from '../../ReusableComponents/AllReusableFunctions';

import { Get_Cs_ComparisionTab_Data } from '../../../Redux_Actions/ComparisonActions';
import TestScore_ComparisonPage from '../../../Utils/Comparison/TestScore_ComparisonPage';
import { GetTestScore_CompareData } from '../../../services/compare.service';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';
import { EnddateValues, StartdateValues } from '../../../Utils/reUsableSnipets';

class d_ts_comparison extends Component {

    constructor(props) {
        super(props);
    }

    componentDidUpdate() {
        // this.CallApi();
        GetTestScore_CompareData(this.props, 'district');
    }

    componentDidMount() {
        // this.CallApi();
        GetTestScore_CompareData(this.props, 'district');
        this.props.trackingUsage("assessmentreports_testscorescomparison:district");
    }

    CallApi(props) {
        let Apicall = this.props.districtComparison.Ts_Comparison.ApiCalls.getTestscore;
        if ((Apicall || props) && (this.props.ContextHeader.TestTab.TestList != undefined)) {
            let Token = this.props.LoginDetails.JWTToken
            let C_RosterData = this.props.ContextHeader.Roster_Tab;
            let Selected_List = this.props.ContextHeader.TestTab.TestList.filter(item => item.check)
            let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');

            let Sc_Ids = C_RosterData.SchoolIds.length ==
                C_RosterData.schoolsList.length ? [] : C_RosterData.SchoolIds
            const { ContextHeader, Context_DateTab } = this.props;
            let startDate = ContextHeader.Date_Tab.Report_termStartDate;
            let endDate = ContextHeader.Date_Tab.Report_termEndDate;
            let districtId = C_RosterData.SelectedDistrict.id;
            if (startDate == undefined || startDate == "") {
                startDate = StartdateValues(Context_DateTab);
            }
            if (endDate == undefined || endDate == "") {
                endDate = EnddateValues(Context_DateTab);
            }
            if (districtId == undefined) {
                districtId = ContextHeader.Default_districtID;
            }

            let Request = {
                "schoolIds": Sc_Ids,
                "districtId": districtId,
                "componentCodeList": SelectedTests,
                "startDate": this.props.ContextHeader.Date_Tab.Report_termStartDate,
                "endDate": this.props.ContextHeader.Date_Tab.Report_termEndDate,
                "rosterGrade":this.props.ContextHeader.Roster_Tab.selectedRosterGrade,
                "termId":this.props.ContextHeader.Date_Tab.selectedTermId
            }
            if (Request.componentCodeList.length > 0) {
                this.props.Get_Cs_ComparisionTab_Data('district', 'testscores', Token, Request);
            }
        }
    }


    render() {

        let Ts_Comparison_props = this.props.districtComparison.Ts_Comparison
        let Nav = this.props.NavigationByHeaderSelection;
        let fromNavContext = "district";

        return (

            <div className="bec_compare_tab_main">

                {Ts_Comparison_props.ApiCalls.loadingComparison_Data || Ts_Comparison_props.ComparisonData.Operational_Data.length == 0 ? <LoadingScreen /> : <TestScore_ComparisonPage fromContext={fromNavContext} fromtab="testscores" comparisonData={Ts_Comparison_props} />

                }
            </div>
        )
    }
}

const MapStateToProps = ({ Universal, Authentication, ComparisonReducer, Reports,DateTabReducer }) => {

    const { LoginDetails } = Authentication

    const { ContextHeader, NavigationByHeaderSelection, ApiCalls,currentTermID,UniversalSelecter } = Universal

    const { districtComparison } = ComparisonReducer

    const { StandardPerformance_Overview } = Reports
    const { Context_DateTab } = DateTabReducer;
    return {
        Universal, LoginDetails, ContextHeader, districtComparison, NavigationByHeaderSelection,
        StandardPerformance_Overview, ApiCalls,currentTermID,Context_DateTab,UniversalSelecter
    }
}

export default connect(MapStateToProps, {
    Get_Cs_ComparisionTab_Data,trackingUsage
})(d_ts_comparison);