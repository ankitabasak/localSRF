import React, { Component } from "react";
import "../../../public/css/style.css";
import { connect } from "react-redux";
import info_icon from "../../../public/images/info_icon.svg";
import Strands_Assessment from "../Standard_Performance/Strands_Assessment";
import Chart from "../../Utils/LineChart/LineChart";
import ChartPagination from "../../Utils/LineChart/LineChartPagination";
import { PerformanceOTchartHeader } from "../class/c_sp_overview";
import OverviewDetailHeader from "../TestScore/OverView/OverviewDetail/OverviewDetailHeader";
import OverviewDetailStudentList from "../TestScore/OverView/OverviewDetail/OverviewDetailStudentList";
import {
  ChangeToggleIn_SP_Overview,
  OpenOrClose_P_OT_Info_Popup,
  CompareCheckBoxOption_For_STrands_LC,
  EnableOrDisableLineColorIn_LC_For_STrands_LC,
  // getTestAssessmentMaxCountOfClass
} from "../../Redux_Actions/ReportsActions";

import ReactHtmlParser from "react-html-parser";
import {
  convertToNumberGrade,
  ParamsForStudentsListTable,
  LineChartInput_Params,
  GetIds_of_Each_Object_In_The_Array,
  Get_Ids_Of_Student_List,
} from "./../ReusableComponents/AllReusableFunctions";
import LoadingScreen from "../../Utils/LoadingScreen/LoadingScreen";
import PrintList from "../ReusableComponents/PDFReports/PrintList";
import PrintLineChart from "../ReusableComponents/PDFReports/PrintLineChart";

import {
  OpenOrCloseTooltipIn_D_Reports,
  getGradeListOfDistrict,
  getTestAssessmentMaxCountOfDistrict,
  Get_District_StandardPerformance_Details,
  GetSchoolDetailsOf_SelectedStrands,
  GetLineChartDetailsofSelected_Standards_In_District_Report,
} from "../../Redux_Actions/District_Report_Actions";
import { getexact_standard_avg_on_class_student_persist } from "../Common/MainFilter/MainFilter";
import IR_Bulb from "../../Utils/IR_Bulb";
import {
  get_District_GradeData,
  Get_District_Strand_Details,
} from "../../services/district.service";
import Make_A_Selection_msg from "../../Utils/Make_A_Selection";
import {
  Disable_AutoSelect_Std_Pref_LeftView,
  ENABLE_SPOT_PDF_DOWNLOAD,
  SPOT_PDF_ENABLE,
} from "../../Utils/globalVars";
import SpotPrint from "../../Utils/SpotPDF/SpotPrint";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";
import { isUniversalApIsActive } from "../ReusableComponents/AllReusableFunctions_Two";
import { EnddateValues, StartdateValues } from "../../Utils/reUsableSnipets";

class d_sp_overview extends Component {
  constructor(props) {
    super(props);
    this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
    (this.P_OT_infoRef = {}), this.Note_InfoRefs;
    (this.InfoTooltipPopUp = {}),
      (this.i_span_tooltip_ref = {}),
      (this.SelectedCheckBoxOption = this.SelectedCheckBoxOption.bind(this));
    this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
    this.state = {
      OpenPerformanceOT: false,
      OpenStudentsList: true,
      show_P_Overtime_Info: false,
    };
  }

  componentWillMount() {
    // this.getGradeData();
    get_District_GradeData(this.props);
    Get_District_Strand_Details(this.props);
    // this.ApiCalls();
    this.RightSideViewApiCalls();
  }
  componentDidUpdate() {
    // this.getGradeData();
    get_District_GradeData(this.props);
    Get_District_Strand_Details(this.props);
    // this.ApiCalls();
    this.RightSideViewApiCalls();
  }

  componentDidMount() {
    document.addEventListener("mousedown", this.handleClickOutside_info);
    this.props.trackingUsage(
      "assessmentreports_standardperformanceoverview:district"
    );
  }

  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside_info);
  }

  // getGradeData() {
  //     let shouldmakeApicall = this.props.ApiCalls.Get_District_sp_grades
  //     if (shouldmakeApicall) {

  //         let AccessToken = this.props.LoginDetails.JWTToken;
  //         let Disply = this.props.ContextHeader;

  //         // let C_RosterData= Disply.

  //         let schoolsList = [];
  //         Disply.LastApplyiedSchools.map(schoolitem => schoolsList.push(schoolitem.id))

  //         let Selected_List = Disply.TestTab.TestList.filter(item => item.check)
  //         let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');

  //         let Dist_id = Disply.Roster_Tab.SelectedDistrict.id;

  //         Dist_id = Dist_id == undefined || Dist_id == null ? Disply.Default_districtID : Dist_id

  //         let Sc_Ids = Disply.Roster_Tab.SchoolIds.length ==
  //         Disply.Roster_Tab.schoolsList.length ? [] : Disply.Roster_Tab.SchoolIds

  //         let Req_Payload = {
  //             "schoolIds": Sc_Ids,
  //             "startDate": Disply.Date_Tab.Report_termStartDate,
  //             "endDate": Disply.Date_Tab.Report_termEndDate,
  //             "districtId": Dist_id,
  //             "componentCodeList": SelectedTests,
  //             "classIds": Disply.Roster_Tab.ClassIds,
  //             "studentIds": Disply.Roster_Tab.StudentIds,
  //             "assessedQuestionsNo": 1,
  //             "grade": Disply.Roster_Tab.selectedRosterGrade
  //         }
  //         this.props.getGradeListOfDistrict(AccessToken, Req_Payload);
  //     }
  // }

  handleClickOutside_info(event) {
    if (event.target == null || event.target == undefined) {
      // this.handleMouseOut(this.props.ToolTipData);
    } else if (
      this.props.D_StandardPerformance_Overview.openInfoPopUp_in_P_OT_header
    ) {
      if (this.Note_InfoRefs !== null && this.Note_InfoRefs !== undefined) {
        let isitemexists = this.Note_InfoRefs.contains(event.target);
        let ToolTipsRefsExists;
        if (
          isitemexists == undefined ||
          isitemexists == null ||
          isitemexists == false
        ) {
          // this.setState({ show_P_Overtime_Info: false })
          this.props.OpenOrClose_P_OT_Info_Popup(
            false,
            this.props.NavigationByHeaderSelection
          );
        }
      }
    } else if (
      this.props.D_StandardPerformance_Overview.openInfoTooltip_in_SP
    ) {
      if (
        this.InfoTooltipPopUp !== null &&
        this.InfoTooltipPopUp !== undefined
      ) {
        let isitemexists = this.InfoTooltipPopUp.contains(event.target);
        let is_IExist = this.i_span_tooltip_ref.contains(event.target);
        if (
          (isitemexists == undefined ||
            isitemexists == null ||
            isitemexists == false) &&
          (is_IExist == undefined || is_IExist == null || is_IExist == false)
        ) {
          this.props.OpenOrCloseTooltipIn_D_Reports(false, "S_performance");
        }
      }
    }
  }

  /**
   *
   * @param {Boolean} shouldmakeApicall
   * if param is true then will make api call to
   */
  // ApiCalls(shouldmakeApicall) {
  //     shouldmakeApicall = this.props.ApiCalls.Get_District_strands;
  //     if (shouldmakeApicall) {
  //         let AccessToken = this.props.LoginDetails.JWTToken;
  //         let U_Selector = this.props.UniversalSelecter.TestTab;
  //         let Disply = this.props.ContextHeader;
  //         let Selected_List = Disply.TestTab.TestList.filter(item => item.check)
  //         let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
  //         let ActualStudents = Disply.StudentList_Actual;
  //         let SelectedStudents = Disply.SelectedMultipleStudents;

  //         let StandardPerformanceFilter = this.props.D_StandardPerformance_Overview.StandardPerformanceFilter;
  //         let selectedTestgrade = StandardPerformanceFilter.TestGrade.selectedTestgrade;
  //         let selectedTestAssessment = StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
  //         selectedTestAssessment = selectedTestAssessment == '' ? 1 : selectedTestAssessment;

  //         let ClassList = [];
  //         Disply.ClassList_Actual.map(classitem => ClassList.push(classitem.id))

  //         let Sc_Ids = Disply.Roster_Tab.SchoolIds.length ==
  //         Disply.Roster_Tab.schoolsList.length ? [] : Disply.Roster_Tab.SchoolIds

  //         let Req_Payload = {
  //             "classIds": Disply.Roster_Tab.ClassIds,
  //             // "schoolId": Disply.School.id,
  //             "schoolIds": Sc_Ids,
  //             "startDate": Disply.Date_Tab.Report_termStartDate,
  //             "endDate": Disply.Date_Tab.Report_termEndDate,
  //             "districtId": Disply.DistrictId,
  //             "componentCodeList": SelectedTests,
  //             "assessedQuestionsNo": selectedTestAssessment,
  //             "grade": selectedTestgrade.grade,
  //         }
  //         let EnableLoading = true;
  //         this.props.Get_District_StandardPerformance_Details(AccessToken, Req_Payload, EnableLoading)

  //         StandardPerformanceFilter.DontCall_standardMaxAssessmentCountApi == true ? null : this.props.getTestAssessmentMaxCountOfDistrict(AccessToken, Req_Payload);
  //     }
  // }

  /**
   * check to make any api call to get class details or linechart data.
   */
  RightSideViewApiCalls() {
    let APi = this.props.D_ApiCalls;
    let SchoolStrandsObject = this.props.D_StandardPerformance_Overview;
    let TestsApi =
      this.props.ApiCalls.getTests || this.props.ApiCalls.loadingFor == "tests";
      const {loadingOn_D_Sp_Grades, loadingOn_D_Sp, Get_District_sp_grades, Get_District_strands }= this.props.ApiCalls
     let universalApis = isUniversalApIsActive(this.props.Universal)
     let D_SP_API_Calls = loadingOn_D_Sp_Grades  || Get_District_sp_grades || APi.get_Sp_Assessed_Ques ||
     Get_District_strands || loadingOn_D_Sp
    if (
      (APi.get_SchoolList_and_Graph_ofStrand ||
        APi.Get_OnlyGraphOnCompareInStrandsComp) &&
      !universalApis && !D_SP_API_Calls
    ) {
      let StrandsList = [];
      let strandAvg = "";
      let strandName = "";
      let standardId = "";
      let selectedStandard = null;
      let Strand_List = SchoolStrandsObject.ActualList.strands || [];

      let strandardsarray = [];

      let StrandSelectionIsExist =
        (SchoolStrandsObject.selectedStandardId === "" ||
          SchoolStrandsObject.selectedStandardId === null) &&
        (SchoolStrandsObject.StrandNameOfSelectedStandard == "" ||
          SchoolStrandsObject.StrandNameOfSelectedStandard == null);

      if (!StrandSelectionIsExist) {
        if (
          SchoolStrandsObject.selectedStandardId === "" ||
          SchoolStrandsObject.selectedStandardId === null
        ) {
          // let SelectedStrand = [];
          for (var i = 0; i < Strand_List.length; i++) {
            if (
              Strand_List[i].strandName ==
              SchoolStrandsObject.StrandNameOfSelectedStandard
            ) {
              StrandsList = Strand_List[i];
              break;
            }
          }

          StrandsList =
            StrandsList.standards == undefined
              ? Strand_List[0] || {}
              : StrandsList;

          strandAvg = StrandsList.strandAvg;
          strandName = StrandsList.strandName;

          if (StrandsList.standards) {
            strandardsarray = GetIds_of_Each_Object_In_The_Array(
              StrandsList.standards,
              strandName,
              "forapicall"
            );
          }
        } else if (
          SchoolStrandsObject.selectedStandardId !== "" &&
          SchoolStrandsObject.selectedStandardId !== null
        ) {
          strandAvg = SchoolStrandsObject.selectedstandardObject.standardAvg;
          standardId = SchoolStrandsObject.selectedstandardObject.standardId;
          strandName = SchoolStrandsObject.StrandNameOfSelectedStandard;
          strandardsarray =
            SchoolStrandsObject.selectedstandardObject.nationalStdIds !=
            undefined
              ? SchoolStrandsObject.selectedstandardObject.nationalStdIds
              : [SchoolStrandsObject.selectedstandardObject.standardId];
          selectedStandard = SchoolStrandsObject.selectedstandardObject;
        }
      } else {
        StrandsList = SchoolStrandsObject.ActualList.strands[0];
        strandAvg = StrandsList.strandAvg;
        strandName = StrandsList.strandName;
        strandardsarray = GetIds_of_Each_Object_In_The_Array(
          StrandsList.standards,
          strandName,
          "forapicall"
        );
      }

      let AccessToken = this.props.LoginDetails.JWTToken;
      let U_Selector = this.props.UniversalSelecter.TestTab;
      let Disply = this.props.ContextHeader;
      let Selected_List = Disply.TestTab.TestList.filter((item) => item.check);

      let SelectedTests = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );
      // let ActualStudents = Disply.StudentList_Actual;
      // let SelectedStudents = Disply.SelectedMultipleStudents;

      let StandardPerformanceFilter =
        this.props.D_StandardPerformance_Overview.StandardPerformanceFilter;
      let selectedTestgrade =
        StandardPerformanceFilter.TestGrade.selectedTestgrade;
      let selectedTestAssessment =
        StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
      selectedTestAssessment =
        selectedTestAssessment == "" ? 1 : selectedTestAssessment;

      // let schoolsList = Get_Ids_Of_Student_List(Disply.LastApplyiedSchools);
      // Disply.LastApplyiedSchools.map(schoolitem => schoolsList.push(schoolitem.id))

      let ApplyiedRosterData = Disply.Roster_Tab;
      let Sc_Ids =
        Disply.Roster_Tab.SchoolIds.length ==
        Disply.Roster_Tab.schoolsList.length
          ? []
          : Disply.Roster_Tab.SchoolIds;

      let currentTermId = this.props.currentTermID;
      let districtId = Disply.DistrictId;
      let startDate = Disply.Date_Tab.Report_termStartDate;
      let endDate = Disply.Date_Tab.Report_termEndDate;
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(this.props.Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(this.props.Context_DateTab);
      }
      if (districtId == undefined) {
        districtId = Disply.Default_districtID;
      }


      let Req_Payload = {
        assessedQuestionsNo: selectedTestAssessment,
        grade: selectedTestgrade.grade,
        schoolIds: Sc_Ids,
        districtId: districtId,
        componentCodeList: SelectedTests,
        startDate: startDate,
        endDate: endDate,
        standardIds: strandardsarray,
        classIds: Disply.Roster_Tab.ClassIds,
        studentIds: Disply.Roster_Tab.StudentIds,
        rosterGrade: Disply.Roster_Tab.selectedRosterGrade,
        termId: Disply.Date_Tab.selectedTermId,
        isPastDistrictTerm: Disply.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
        // "isDistrict": true
      };

      let Enableloading = true;
      let UpdatedselectedStandard = null;
      if (selectedStandard === null || selectedStandard === undefined) {
      } else {
        let standardDetails = getexact_standard_avg_on_class_student_persist(
          Strand_List,
          strandName,
          selectedStandard
        );
        UpdatedselectedStandard = standardDetails.UpdatedselectedStandard;
        strandAvg = standardDetails.strandAvg;
      }

      if (Req_Payload.districtId !== "" && Req_Payload.schoolIds !== "") {
        let Sel_Taxonomy =
          this.props.D_StandardPerformance_Overview.StandardPerformanceFilter
            .Taxonomy.selectedTaxonomy;
        let Sel_Ques =
          this.props.D_StandardPerformance_Overview.StandardPerformanceFilter
            .TestAssessment.selectedTestAssessment;

        APi.Get_OnlyGraphOnCompareInStrandsComp
          ? null
          : this.props.GetSchoolDetailsOf_SelectedStrands(
              AccessToken,
              Req_Payload,
              "",
              standardId,
              strandAvg,
              strandName,
              UpdatedselectedStandard,
              Enableloading,
              Sel_Taxonomy,
              Sel_Ques
            );

        this.props.GetLineChartDetailsofSelected_Standards_In_District_Report(
          AccessToken,
          Req_Payload,
          standardId,
          strandAvg,
          strandName,
          UpdatedselectedStandard,
          Enableloading
        );
      }
    }
  }

  /**
   *
   * @param {String} selectedfiield
   * @param {boolean} check
   */
  SelectedCheckBoxOption(selectedfiield, check) {
    this.props.CompareCheckBoxOption_For_STrands_LC(selectedfiield, check);
  }

  /**
   * when user click on checbox comp label, then it will execute
   */
  ClickOnLabelName(labelName, checkOrUncheck) {
    this.props.EnableOrDisableLineColorIn_LC_For_STrands_LC(
      labelName,
      checkOrUncheck
    );
  }

  /**
   *
   * @param {string} ActiveToggle -- selected toggle name.
   * @returns {JSX Element/null}
   */
  PerformanceOTchart(ActiveToggle, ApiCallReports) {
    let GraphPagination =
      this.props.D_StandardPerformance_Overview.LineChart_Pagination;
    let PerformanceFilter =
      this.props.D_StandardPerformance_Overview.StandardPerformanceFilter;
    let selectedTestAssessment;
    let selectedTestGrade;
    selectedTestAssessment =
      PerformanceFilter.TestAssessment.selectedTestAssessment;
    selectedTestGrade = PerformanceFilter.TestGrade.selectedTestgrade;
    if (ActiveToggle == "linechart") {
      let ActualListForGraph = JSON.parse(
        JSON.stringify(
          this.props.D_StandardPerformance_Overview.ActualLineChartData
        )
      );
      let Pagination_Start = GraphPagination.Chart_Page_Count_Start;
      let Pagination_End = GraphPagination.Chart_Page_Count_End;
      let ToolTipData =
        this.props.D_StandardPerformance_Overview.Strands_ToolTipData;
      let StrandReducer = this.props.D_StandardPerformance_Overview;
      let TotalQuestions = ActualListForGraph.reduce(
        (initial, item) => initial + parseInt(item.totalQuestions),
        0
      );
      let Standard_performance_details =
        this.props.D_StandardPerformance_Overview;
      let LastChecked_CB = Standard_performance_details.lastSelectedCheckBox;
      const {
        XAxis_Params,
        YAxis_Params,
        DatatPointParams,
        tooltipParams,
        data,
        margin,
        width,
        height,
        Ipadwidth,
        Ipadheight,
      } = LineChartInput_Params(
        ActualListForGraph,
        Pagination_Start,
        Pagination_End,
        "c_sp_overview"
      );
      let ClassChecked = false; // for class instance we no need this so by default we are sending false.
      let SchoolChecked = Standard_performance_details.checkSchool;
      let DistrictChecked = Standard_performance_details.checkDistrict;

      //IR related stuff

      const { selectedstandardObject, StrandNameOfSelectedStandard } = this
        .props.D_StandardPerformance_Overview
        ? this.props.D_StandardPerformance_Overview
        : "";
      const setId =
        selectedstandardObject !== null ? selectedstandardObject.setId : "";
      let strandNames =
        StrandNameOfSelectedStandard !== null &&
        StrandNameOfSelectedStandard !== ""
          ? setId + "~" + StrandNameOfSelectedStandard
          : "";
      let standardNames =
        selectedstandardObject !== null
          ? selectedstandardObject.standardId
          : "";
      let Grade = selectedTestGrade
        ? convertToNumberGrade(selectedTestGrade.grade)
        : "";
      //IR related stuff ends
      let need_To_Select_Strad_Or_Standard =
        strandNames == "" &&
        !ApiCallReports.Get_OnlyGraphOnCompareInStrandsComp &&
        !ApiCallReports.loading_on_strands_Lc &&
        Disable_AutoSelect_Std_Pref_LeftView;

      return (
        <div className="widget-base-block mx-auto">
          {ApiCallReports.loading_on_strands_Lc ? (
            <LoadingScreen />
          ) : need_To_Select_Strad_Or_Standard ? (
            <Make_A_Selection_msg message="Make a selection in the table to see details." />
          ) : (
            <div className="widget-base-block-inr">
              <div className="widget-base-title-block">
                <div className="float-left widget-base-block-title text-center">
                  <span className="print_pdf_icon">
                    {ENABLE_SPOT_PDF_DOWNLOAD ? (
                      <SpotPrint />
                    ) : (
                      <PrintLineChart
                        data={data}
                        XAxis_Params={XAxis_Params}
                        Pagination={GraphPagination}
                        selectedTestAssessment={selectedTestAssessment}
                        selectedTestGrade={selectedTestGrade}
                        YAxis_Params={YAxis_Params}
                        DataSetParam={DatatPointParams}
                        // TooltipParams={tooltipParams}
                        TooltipParams={tooltipParams}
                        ToolTipData={ToolTipData}
                        ClassChecked={ClassChecked}
                        SchoolChecked={SchoolChecked}
                        DistrictChecked={DistrictChecked}
                        LastChecked_CB={LastChecked_CB}
                        Navselection={
                          this.props.NavigationByHeaderSelection.class
                        }
                        TS_Overtime={Standard_performance_details}
                        CheckeThis={this.SelectedCheckBoxOption}
                        ClickOnLabel={this.ClickOnLabelName}
                        standardName={
                          StrandReducer.StrandNameOfSelectedStandard
                        }
                        strandName={
                          StrandReducer.selectedstandardObject == null
                            ? null
                            : StrandReducer.selectedstandardObject.standardDef
                        }
                        strandDetailsDesc={
                          StrandReducer.selectedstandardObject == null
                            ? null
                            : StrandReducer.selectedstandardObject.standardName
                        }
                        strandDescription={
                          StrandReducer.selectedstandardObject == null
                            ? null
                            : StrandReducer.selectedstandardObject.standardDesc
                        }
                        totalAverageScore={StrandReducer.selectedStandarAvg}
                        totalQuestions={TotalQuestions}
                      />
                    )}
                  </span>
                  <span>{StrandReducer.StrandNameOfSelectedStandard}</span>
                </div>

                {StrandReducer.selectedstandardObject ==
                null ? null : StrandReducer.selectedstandardObject
                    .standardName == undefined ? null : (
                  <div className="float-left widget-base-block-title text-center">
                    <span
                      style={{ float: "left", textAlign: "left", width: "93%" }}
                    >
                      {StrandReducer.selectedstandardObject.standardName}:{" "}
                      {ReactHtmlParser(
                        StrandReducer.selectedstandardObject.standardDesc
                      )}
                    </span>
                    <span
                      style={{
                        float: "left",
                        width: "6%",
                        position: "relative",
                        left: "6px",
                      }}
                    >
                      <IR_Bulb
                        ir_bulb_icon={
                          this.props.LoginDetails.ReportingAccessParam
                        }
                        display_position="left"
                        view={setId}
                        grade={Grade}
                        strand={strandNames}
                        standard={standardNames}
                      />
                    </span>
                  </div>
                )}

                <div className="widget-base-sub-title text-center">
                  <span>
                    Average Score: {StrandReducer.selectedStandarAvg}% based on{" "}
                    {TotalQuestions} questions
                  </span>
                  <span
                    onClick={() =>
                      this.props.OpenOrClose_P_OT_Info_Popup(
                        true,
                        this.props.NavigationByHeaderSelection
                      )
                    }
                    // ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                  >
                    <span>
                      <img
                        src={info_icon}
                        style={{
                          cursor: "pointer",
                          marginLeft: "4px",
                          marginTop: "-4px",
                        }}
                      />
                    </span>
                  </span>

                  {Standard_performance_details.openInfoPopUp_in_P_OT_header ? (
                    <div className="infoIconTooltipBlock">
                      <div
                        ref={(ref) =>
                          ref !== null ? (this.Note_InfoRefs = ref) : null
                        }
                        className="infoIconTooltipBlockInr"
                      >
                        <span className="infoIconTooltipBlockArrow"></span>
                        <b>Note:</b> Average Score for all standards reports
                        equals (earned points/total points)*100
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>

              {PerformanceOTchartHeader(
                true,
                ActualListForGraph,
                GraphPagination,
                this.props.UserScreenWidth,
                ToolTipData,
                StrandReducer,
                "c_sp_overview",
                ClassChecked,
                SchoolChecked,
                DistrictChecked,
                LastChecked_CB
              )}
            </div>
          )}
        </div>
      );
    } else return null;
  }
  /**
   * @param {string} ActiveToggle --selected toggle name
   * @returns {JSX Element}
   */

  SchoolsListView(ActiveToggle, ApiCallReports) {
    if (ActiveToggle == "schoollist") {
      let StrandReducer = this.props.D_StandardPerformance_Overview;
      let StandardPerformanceFilter = StrandReducer.StandardPerformanceFilter;
      let selectedTestGrade;
      selectedTestGrade = StandardPerformanceFilter.TestGrade.selectedTestgrade;
      let selectedTestAssessment;
      selectedTestAssessment =
        StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
      let Test_Scores_Details = StrandReducer.SP_ActualStudentsList;

      let DataToDisplay = StrandReducer.SP_StudentsList.filter(
        (item) => item.schoolScore !== null
      );

      let GraphDataForSelectedStrand =
        this.props.D_StandardPerformance_Overview.ActualLineChartData;
      let Standard_performance_details =
        this.props.D_StandardPerformance_Overview;

      let TotalQuestions_At_StudentList =
        DataToDisplay.length > 0 ? DataToDisplay[0].questionCount : "";

      const {
        lessthan40Studentcount,
        l40width,
        l40to59Studentcount,
        l40to59width,
        l60to79Studentcount,
        l60to79width,
        l80Studentcount,
        g80width,
        totalStudentCount,
        totalAverageScore,
        testName,
        submittedStartDate,
        submittedEndDate,
        sortedValue,
        pdfl40to50width,
        pdfl40width,
        pdfl60to79width,
        pdfg80width,
      } = ParamsForStudentsListTable(
        Test_Scores_Details,
        StrandReducer.SortedArray_SP_StudentsList,
        this.props.NavigationByHeaderSelection,
        this.props.AchivementLevels
      );

      let Nav = this.props.NavigationByHeaderSelection;
      let SchoolList =
        this.props.D_StandardPerformance_Overview.SP_ActualStudentsList.filter(
          (item) => item.schoolScore !== null
        );

      //IR related stuff

      const { selectedstandardObject, StrandNameOfSelectedStandard } = this
        .props.D_StandardPerformance_Overview
        ? this.props.D_StandardPerformance_Overview
        : "";
      const setId =
        selectedstandardObject !== null ? selectedstandardObject.setId : "";
      let strandNames =
        StrandNameOfSelectedStandard !== null &&
        StrandNameOfSelectedStandard !== ""
          ? setId + "~" + StrandNameOfSelectedStandard
          : "";
      let standardNames =
        selectedstandardObject !== null
          ? selectedstandardObject.standardId
          : "";
      let Grade = selectedTestGrade
        ? convertToNumberGrade(selectedTestGrade.grade)
        : "";
      //IR related stuff ends
      // Standard_performance_details = Standard_performance_details.strands;
      let HeaderDetails = this.props.ContextHeader;
      let need_To_Select_Strad_Or_Standard =
        strandNames == "" &&
        !ApiCallReports.get_SchoolList_and_Graph_ofStrand &&
        !ApiCallReports.loading_on_strands_schools &&
        Disable_AutoSelect_Std_Pref_LeftView;

      return (
        <div className="widget-base-block mx-auto">
          {ApiCallReports.loading_on_strands_schools ? (
            <LoadingScreen />
          ) : need_To_Select_Strad_Or_Standard ? (
            <Make_A_Selection_msg message="Make a selection in the table to see details." />
          ) : (
            <div className="widget-base-block-inr">
              <div className="widget-base-title-block">
                <div className="float-left widget-base-block-title text-center">
                  <span>{StrandReducer.StrandNameOfSelectedStandard}</span>
                  <span className="print_pdf_icon">
                    <PrintList
                      totalstudentlist={totalStudentCount}
                      l40studentcount={lessthan40Studentcount}
                      l40to59Studentcount={l40to59Studentcount}
                      l60to79Studentcount={l60to79Studentcount}
                      l80Studentcount={l80Studentcount}
                      averageScore={
                        this.props.D_StandardPerformance_Overview
                          .selectedStandarAvg
                      }
                      questionCount={TotalQuestions_At_StudentList}
                      standardName={StrandReducer.StrandNameOfSelectedStandard}
                      strandName={
                        StrandReducer.selectedstandardObject == null
                          ? null
                          : StrandReducer.selectedstandardObject.standardDef
                      }
                      strandDetailsDesc={
                        StrandReducer.selectedstandardObject == null
                          ? null
                          : StrandReducer.selectedstandardObject.standardName
                      }
                      strandDescription={
                        StrandReducer.selectedstandardObject == null
                          ? null
                          : StrandReducer.selectedstandardObject.standardDesc
                      }
                      DataToDisplay={
                        StrandReducer.SP_StudentsList == null
                          ? null
                          : StrandReducer.SP_StudentsList
                      }
                      HeaderDetails={HeaderDetails}
                      pdfl40to50width={pdfl40to50width}
                      pdfl40width={pdfl40width}
                      pdfl60to79width={pdfl60to79width}
                      pdfg80width={pdfg80width}
                      selectedTestGrade={selectedTestGrade}
                      selectedTestAssessment={selectedTestAssessment}
                      Data={this.props.D_StandardPerformance_Overview}
                      pagination={
                        this.props.D_StandardPerformance_Overview
                          .StdList_Pagination
                      }
                    />
                  </span>
                </div>
                {StrandReducer.selectedstandardObject ==
                null ? null : StrandReducer.selectedstandardObject
                    .standardName == undefined ? null : (
                  <div className="float-left widget-base-block-title text-center">
                    <span
                      style={{ float: "left", textAlign: "left", width: "93%" }}
                    >
                      {StrandReducer.selectedstandardObject.standardName}:{" "}
                      {ReactHtmlParser(
                        StrandReducer.selectedstandardObject.standardDesc
                      )}
                    </span>
                    <span
                      style={{
                        float: "left",
                        width: "6%",
                        position: "relative",
                        left: "6px",
                      }}
                    >
                      <IR_Bulb
                        ir_bulb_icon={
                          this.props.LoginDetails.ReportingAccessParam
                        }
                        display_position="left"
                        view={setId}
                        grade={Grade}
                        strand={strandNames}
                        standard={standardNames}
                      />
                    </span>
                  </div>
                )}
                <div className="widget-base-sub-title text-center">
                  <span>
                    Average Score:{" "}
                    {
                      this.props.D_StandardPerformance_Overview
                        .selectedStandarAvg
                    }
                    % based on {TotalQuestions_At_StudentList} questions
                  </span>

                  <span
                    onClick={() =>
                      this.props.OpenOrClose_P_OT_Info_Popup(
                        true,
                        this.props.NavigationByHeaderSelection
                      )
                    }
                    ref={(ref) =>
                      ref !== null ? (this.Note_InfoRefs = ref) : null
                    }
                  >
                    <span>
                      <img
                        src={info_icon}
                        style={{
                          cursor: "pointer",
                          marginLeft: "4px",
                          marginTop: "-4px",
                        }}
                      />
                    </span>
                  </span>
                  {Standard_performance_details.openInfoPopUp_in_P_OT_header ? (
                    <div className="infoIconTooltipBlock">
                      <div
                        ref={(ref) =>
                          ref !== null ? (this.Note_InfoRefs = ref) : null
                        }
                        className="infoIconTooltipBlockInr"
                      >
                        <span className="infoIconTooltipBlockArrow"></span>
                        <b>Note:</b> Average Score for all standards reports
                        equals (earned points/total points)*100
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>
              <OverviewDetailHeader
                fromComp="sc_sp_overview"
                Data={this.props.D_StandardPerformance_Overview}
                ActualList={SchoolList}
                l40={lessthan40Studentcount}
                l40width={l40width}
                g40tol59={l40to59Studentcount}
                l40to59width={l40to59width}
                g60tol79={l60to79Studentcount}
                l60to79width={l60to79width}
                g80={l80Studentcount}
                g80width={g80width}
                studentTotalC={totalStudentCount}
                averagescore={totalAverageScore}
                testName={testName}
                startDate={submittedStartDate}
                endDate={submittedEndDate}
              />
              <OverviewDetailStudentList
                fromComp="sc_sp_overview"
                totalstudentcount={totalStudentCount}
                studentsdata={Test_Scores_Details}
                sortedValue={sortedValue}
                Data={this.props.D_StandardPerformance_Overview}
                DataToDisplay={DataToDisplay}
                pagination={
                  this.props.D_StandardPerformance_Overview.StdList_Pagination
                }
                sortedArrayData={
                  this.props.D_StandardPerformance_Overview.SortedArray
                }
              />
            </div>
          )}
        </div>
      );
    } else return null;
  }

  /**
   *
   * @param {Object} ref --ref of the element
   * @param {String} from  --from toggle ex: student/linechart
   * @param {String} ActiveToggle  -- present displaying view student/linechart.
   * before proceed to change  ActiveToggle, will check user click position , if user clicks on info icon then will open note
   */

  ClickOn_Toggles(ref, from, ActiveToggle) {
    let Nav = this.props.NavigationByHeaderSelection;

    let ChangeToggle_To =
      from == "linechart"
        ? ActiveToggle == "linechart"
          ? "schoollist"
          : "linechart"
        : ActiveToggle == "schoollist"
        ? "linechart"
        : "schoollist";
    if (this.Note_InfoRefs !== undefined) {
      let ClickOnIcon = this.Note_InfoRefs.contains(ref.target);
      let PopOpen =
        this.props.D_StandardPerformance_Overview.openInfoPopUp_in_P_OT_header;
      ClickOnIcon
        ? PopOpen
          ? null
          : this.props.OpenOrClose_P_OT_Info_Popup(
              true,
              this.props.NavigationByHeaderSelection
            )
        : this.props.ChangeToggleIn_SP_Overview(
            ChangeToggle_To,
            "districtreport"
          );
    } else {
      this.props.ChangeToggleIn_SP_Overview(ChangeToggle_To, "districtreport");
    }
  }

  LineChart_Widget(
    Standard_performance_details,
    ActiveToggle,
    ApiCallReports,
    No_loader
  ) {
    return (
      <div
        className={
          ActiveToggle == "linechart"
            ? "standard-widget performance_overtime_block active-widget"
            : "standard-widget performance_overtime_block"
        }
      >
        <div
          onClick={(ref) =>
            this.ClickOn_Toggles(ref, "linechart", ActiveToggle)
          }
          className="sidewidget-header"
        >
          <span className="sidewidget-header-icon">
            <i className="material-icons">show_chart </i>
          </span>
          <span className="sidewidget-header-title">Performance Over Time</span>
          <span
            onClick={() =>
              this.props.OpenOrCloseTooltipIn_D_Reports(true, "S_performance")
            }
          >
            <span
              ref={(refs) =>
                refs == null ? null : (this.i_span_tooltip_ref = refs)
              }
            >
              <img
                src={info_icon}
                style={{
                  cursor: "pointer",
                  marginLeft: "4px",
                  marginTop: "5px",
                }}
              />
            </span>
            {Standard_performance_details.openInfoTooltip_in_SP ? (
              <div
                className="infoIconTooltipBlock_POT"
                style={ActiveToggle == "linechart" ? { top: 72 } : {}}
              >
                <div
                  ref={(InfoTooltipPopUp) =>
                    InfoTooltipPopUp !== null
                      ? (this.InfoTooltipPopUp = InfoTooltipPopUp)
                      : null
                  }
                  className="infoIconTooltipBlockInr"
                >
                  <span className="infoIconTooltipBlockArrow_POT"></span>
                  <b>Note:</b> The average score listed in the line graph below
                  is calculated from all data available for each assessment
                  based on the context selected. It does not assume the cohort
                  of students remains the same across the assessments listed.
                </div>
              </div>
            ) : null}
          </span>
        </div>

        {No_loader
          ? this.PerformanceOTchart(ActiveToggle, ApiCallReports)
          : null}
      </div>
    );
  }

  SchoolList_Widget(
    Standard_performance_details,
    ActiveToggle,
    ApiCallReports,
    No_loader
  ) {
    return (
      <div
        className={
          ActiveToggle == "schoollist"
            ? "standard-widget active-widget"
            : "standard-widget"
        }
      >
        <div
          onClick={
            (ref) => this.ClickOn_Toggles(ref, "schoollist", ActiveToggle)
            // this.setState({ OpenStudentsList: true, OpenPerformanceOT: false })
          }
          className="sidewidget-header"
        >
          <span className="sidewidget-header-icon">
            <i className="material-icons">view_list</i>
          </span>
          <span className="sidewidget-header-title">School List</span>
        </div>
        {No_loader ? (
          <div> {this.SchoolsListView(ActiveToggle, ApiCallReports)} </div>
        ) : (
          <LoadingScreen />
        )}
      </div>
    );
  }

  returnTogglesBasedOnSelection() {
    let Standard_performance_details =
      this.props.D_StandardPerformance_Overview;
    let ActiveToggle = Standard_performance_details.ActiveToggelIn_SP_Overview;
    let ApiCallReports = this.props.D_ApiCalls;
    let No_loader = !isUniversalApIsActive(this.props.Universal) &&
      ApiCallReports.loading_Strands_table == false &&
      this.props.ApiCalls.loadingFor !== "tests";
    return ActiveToggle == "linechart" ? (
      <div className="col-sm-12 float-left m-0 p-0">
        {this.SchoolList_Widget(
          Standard_performance_details,
          ActiveToggle,
          ApiCallReports,
          No_loader
        )}
        {this.LineChart_Widget(
          Standard_performance_details,
          ActiveToggle,
          ApiCallReports,
          No_loader
        )}
      </div>
    ) : (
      <div className="col-sm-12 float-left m-0 p-0">
        {this.LineChart_Widget(
          Standard_performance_details,
          ActiveToggle,
          ApiCallReports,
          No_loader
        )}
        {this.SchoolList_Widget(
          Standard_performance_details,
          ActiveToggle,
          ApiCallReports,
          No_loader
        )}
      </div>
    );
  }

  render() {
    let Standard_performance_details =
      this.props.D_StandardPerformance_Overview;
    let ActiveToggle = Standard_performance_details.ActiveToggelIn_SP_Overview;
    let ApiCallReports = this.props.D_ApiCalls;
    // let ActiveToggle = Standard_performance_details.ActiveToggelIn_SP_Overview
    let U_Apis = this.props.ApiCalls;
    return (
      <div className="main-middle-block">
        {/* { ApiCallReports.loading_Strands_table == false ?  */}

        <div className="main-middle-block-inr">
          <div className="bec-standards-overview-left">
            {U_Apis.loadingFor == "datetab" || U_Apis.loadingFor == "tests" ? (
              <LoadingScreen />
            ) : (
              <Strands_Assessment
                stranddetails={Standard_performance_details}
                Apicalls={ApiCallReports}
              />
            )}
          </div>
          {/* right block start */}
          <div className="bec-standards-overview-right">
            {this.returnTogglesBasedOnSelection()}
          </div>
          {/* right block end */}
        </div>
        {/* : <LoadingScreen/> } */}
      </div>
    );
  }
}

const mapStateToProps = ({
  StudentReports,
  Reports,
  Universal,
  Authentication,
  DistrictReducer,
  DateTabReducer,
}) => {
  const { Class, ToolTipData } = Reports;
  const {} = StudentReports;
  const { LoginDetails } = Authentication;
  const {
    AchivementLevels,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    currentTermID,
  } = Universal;

  const { D_StandardPerformance_Overview, D_ApiCalls } = DistrictReducer;
  const { Context_DateTab } = DateTabReducer;
  return {
    Class,
    LoginDetails,
    AchivementLevels,
    ContextHeader,
    ApiCalls,
    ToolTipData,
    D_ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    D_StandardPerformance_Overview,
    currentTermID,
    Context_DateTab,
    Universal
  };
};

export default connect(mapStateToProps, {
  ChangeToggleIn_SP_Overview,
  OpenOrClose_P_OT_Info_Popup,
  CompareCheckBoxOption_For_STrands_LC,
  EnableOrDisableLineColorIn_LC_For_STrands_LC,

  // getTestAssessmentMaxCountOfClass,
  getTestAssessmentMaxCountOfDistrict,
  Get_District_StandardPerformance_Details,
  GetSchoolDetailsOf_SelectedStrands,
  GetLineChartDetailsofSelected_Standards_In_District_Report,
  getGradeListOfDistrict,
  OpenOrCloseTooltipIn_D_Reports,
  trackingUsage,
})(d_sp_overview);

/**
 *
 * @param {Boolean} isActive
 * @param {Array} ActualArrayList
 * @param {Object} Pagination
 * @param {Int16Array} UserScreenWidth
 * @param {Object} ToolTipData
 * @param {Object} StrandReducer
 * @param {String} FromComponent
 * @param {Boolean} SchoolChecked
 * @param {Boolean} DistrictChecked
 */
// export const PerformanceOTchartHeader = (isActive, ActualArrayList, Pagination, UserScreenWidth, ToolTipData, StrandReducer, FromComponent, ClassChecked, SchoolChecked, DistrictChecked, LastChecked_CB) => {

//     let Array = JSON.parse(JSON.stringify(ActualArrayList));
//     let Pagination_Start = Pagination.Chart_Page_Count_Start;
//     let Pagination_End = Pagination.Chart_Page_Count_End;
//     const { XAxis_Params, YAxis_Params, DatatPointParams, tooltipParams, data,
//         margin, width, height, Ipadwidth, Ipadheight
//     } = LineChartInput_Params(Array, Pagination_Start, Pagination_End, FromComponent)

//     // let TotalQuestions = ToolTipData.tooltipData == null ? "" : ToolTipData.tooltipData.totalQuestions

//     return <div style={{ width: '100%', float: 'left' }}>
//         <Chart margin={margin}
//             width={UserScreenWidth < 1230 ? Ipadwidth : width}
//             height={UserScreenWidth < 1230 ? Ipadheight : height}
//             data={data} XAxis_Params={XAxis_Params}
//             YAxis_Params={YAxis_Params}
//             DataSetParam={DatatPointParams}
//             // TooltipParams={tooltipParams}
//             TooltipParams={tooltipParams}
//             ToolTipData={ToolTipData}
//             ClassChecked={ClassChecked}
//             SchoolChecked={SchoolChecked}
//             DistrictChecked={DistrictChecked}
//             LastChecked_CB={LastChecked_CB}
//         // data2={data2} data3={data3}
//         />
//         <div style={{ 'marginLeft': '70px' }} > {Pagination.Chart_TotalBubbles > 1 ? <ChartPagination
//             pagination={Pagination} /> : null}
//             <div className="Test_names_label" style={{ float: 'left', paddingTop: 15 }}>Test Names</div>
//         </div>
//     </div>

// }
