import React, { Component } from "react";
import { connect } from "react-redux";
import WidgetLayout from "../../../Utils/SummaryBlock/widgetLayout";
import TestStatus from "../../../Utils/SummaryBlock/testStatus";
import StdOverview from "../../../Utils/SummaryBlock/stdOverview";
import NoDataFoundLayout from "../../../Utils/SummaryBlock/noDataFoundLayout/noDataFoundLayout";
import LoadingScreen from "../../../Utils/LoadingScreen/LoadingScreen";
import {
  Getstandardperformance_SummaryReports,
  getGradeList,
} from "../../../Redux_Actions/summaryReports_Actions";
import SummaryTab from "../../Chart_Summary/Summary.jsx"; //= require('../../Chart_Summary/Summary.jsx');
import BuurSummaryWidget from "../../BuurSummaryWidget/index.jsx";
import ClassTestStatus, { getStartEndDates, ReqIdsAndContext } from "../../../Utils/SummaryBlock/testStatus/ClassTestStatus";
import {
  ENABLE_ORR_WIDGET,
  ENABLE_SP_WIDGET,
  ENABLE_TEST_STATUS_WIDGET,
  ENABLE_USAGE_WIDGET,
  SUMMARYREPORTS_PDF,
  SUMMARYREPORTS_TS_PDF,
} from "../../../Utils/globalVars";
import { isArray } from "highcharts";
import CsvIcon from "../../../../public/images/ic_save.svg";
import { trackingUsage } from "../../../Redux_Actions/AuthenticationAction";
import ActiveContext from "../../../Utils/activeContext";
import { gradeApiReqPayload } from "../../../Utils/SummaryBlock/testStatusReqObject";
import {GetSummaryTestStatusReports} from '../../../Redux_Actions/summaryReports_Actions';
const BannerText = (Bannermessage) => {
  return (
    Bannermessage && (
      <div>
        {" "}
        <div class="ar_summary_PastDistictTermBannerBox">
          <span class="ar_summary_PastDistictTermBannerBoxclosebtn">×</span>
          <span>
            Select the <b>{Bannermessage}</b> to view past school year reports.{" "}
          </span>
        </div>
      </div>
    )
  );
};

class districtSummaryScreen extends Component {
  constructor(props) {
    super(props);
    const { Authentication } = this.props;
    const { LoginDetails } = Authentication;
    const { ReportingAccessParam } = LoginDetails;
    let OnlyORRAccess =
      !ReportingAccessParam.includes("eAR") &&
      ReportingAccessParam.includes("ORR");
    let BotheARandORR =
      ReportingAccessParam.includes("ORR") &&
      ReportingAccessParam.includes("eAR");
    this.state = {
      isIpadScreen: false,
      name: "ipadview",
      showUsageData:
        ReportingAccessParam.includes("usageReports") && ENABLE_USAGE_WIDGET
          ? true
          : false,
      showTestStatusData:
        !(
          ReportingAccessParam.includes("usageReports") && ENABLE_USAGE_WIDGET
        ) &&
        ReportingAccessParam.includes("eAR") &&
        (!ReportingAccessParam.includes("ORR") || !ENABLE_ORR_WIDGET)
          ? true
          : false,
      showStandardsPerformanceData:
        !ENABLE_USAGE_WIDGET &&
        ReportingAccessParam.includes("eAR") &&
        (!ReportingAccessParam.includes("ORR") || !ENABLE_ORR_WIDGET) &&
        !ENABLE_TEST_STATUS_WIDGET
          ? true
          : false,
      showOrrData:
        !(
          ReportingAccessParam.includes("usageReports") && ENABLE_USAGE_WIDGET
        ) &&
        (BotheARandORR || OnlyORRAccess)
          ? true
          : false,
    };

    this.hideComponent = this.hideComponent.bind(this);
    this.updatePredicate = this.updatePredicate.bind(this);
  }

  componentDidMount() {
    this.SummaryapiCalls();
    this.updatePredicate();
    if (ENABLE_TEST_STATUS_WIDGET){
      this.classTestStatusApiCalls();
    }
    window.addEventListener("resize", this.updatePredicate);
    let { NavigationByHeaderSelection } = this.props;

    let context = "district";
    if (NavigationByHeaderSelection.school) {
      context = "school";
    } else if (NavigationByHeaderSelection.class) {
      context = "class";
    } else if (NavigationByHeaderSelection.student) {
      context = "student";
    }
    this.props.trackingUsage(
      `summaryreports_summarypagedefaultload:${context}`
    );
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.updatePredicate);
  }
  updatePredicate() {
    this.setState({ isIpadScreen: window.innerWidth <= 1024 });
  }

  componentDidUpdate() {
    if (ENABLE_SP_WIDGET) {
      this.SummaryapiCalls();
    }
    if (ENABLE_TEST_STATUS_WIDGET){
      this.classTestStatusApiCalls();
    }
  }

  classTestStatusApiCalls(){
    let Nav = this.props.NavigationByHeaderSelection;
    let { student, school, district } = Nav
    const { Authentication, ContextHeader, isPastDistrictTerm, currentTermID, Context_DateTab_TestStatus } = this.props
    const { Summary_Roster_Data, DistrictId, Date_Tab } = ContextHeader
    
    const { LoginDetails, Auth_Apis } = Authentication
    const { ReportingAccessParam } = LoginDetails
    let OnlyORRAccess =
      !ReportingAccessParam.includes('eAR') &&
      ReportingAccessParam.includes('ORR')
    const { ApiCalls } = this.props
    const fromContext = district
      ? 'district'
      : school
        ? 'school'
        : student
          ? 'student'
          : 'class'
    const { apiCalls, testStatus } = this.props.SummaryReports[
      `${fromContext}`
    ].assessments;

    if (
      !OnlyORRAccess &&
      !student &&
      this.props.ApiCalls.DefaultApiSuccess &&
      this.props.ApiCalls.DefaultSummaryApiSuccess &&
      apiCalls.testStatusAPI &&
      this.props.ApiCalls.Done_RosterTab_Details_Setup
      && Nav.class
    ) {
      const [selectedIds, selectedContext] = ReqIdsAndContext(Nav, Summary_Roster_Data);
      let selectedClass = Summary_Roster_Data.SelectedClass.id == undefined ? "" :
        Summary_Roster_Data.SelectedClass.id;

      let schoolId = Summary_Roster_Data.SelectedSchool.id == undefined ? "" :
        Summary_Roster_Data.SelectedSchool.id;

      const [StartDate, EndDate] = getStartEndDates(Context_DateTab_TestStatus)

      let selectedRosterGrade = Summary_Roster_Data.selectedRosterGrade == "All" ? (Summary_Roster_Data.GradesList[0] && Summary_Roster_Data.GradesList[0].grade) : Summary_Roster_Data.selectedRosterGrade

      let SumTestStatusReq = {
        "ids": selectedIds,
        "schoolId": schoolId,
        "districtId": DistrictId,
        "context": selectedContext,
        "startDate": StartDate,
        "endDate": EndDate,
        "classId": selectedClass,
        "studentIds": Summary_Roster_Data.StudentIds,
        "rosterGrade": selectedRosterGrade,
        "isPastDistrictTerm": isPastDistrictTerm,
        "currentTermId": currentTermID,
        "page": 1
      }
      Summary_Roster_Data.StudentIds.length>0 && selectedClass !="" &&
        this.props.GetSummaryTestStatusReports(SumTestStatusReq, fromContext)
    }
  }

  SummaryapiCalls() {
    let { student, school, district } = this.props.NavigationByHeaderSelection;
    const { Authentication } = this.props;
    const { LoginDetails } = Authentication;
    const { ReportingAccessParam } = LoginDetails;
    let OnlyORRAccess =
      !ReportingAccessParam.includes("eAR") &&
      ReportingAccessParam.includes("ORR");
    const { ApiCalls } = this.props;

    const fromContext = ActiveContext(this.props.NavigationByHeaderSelection);
    const { apiCalls, standardperformance } =
      this.props.SummaryReports[`${fromContext}`].assessments;
    let SchoolApi =
      (ApiCalls.Get_Selected_School_Info && school) ||
      ApiCalls.loadingFor == "school" ||
      ApiCalls.loadingFor == "classObject" ||
      ApiCalls.loadingFor == "studentData" ||
      (ApiCalls.getStudentData_cls && student) ||
      (ApiCalls.getInitialSchoolObj && school) ||
      (ApiCalls.getRosterClassWhichHasData &&
        this.props.NavigationByHeaderSelection.class);
    if (!SchoolApi) {
      if (
        apiCalls.TestGradeApi && this.props.NavigationByHeaderSelection.class
      ) {
        let GradesReqPayload = gradeApiReqPayload(this.props);
        this.props.getGradeList(
          LoginDetails.JWTToken,
          GradesReqPayload,
          fromContext
        );
      }
      let selectedTestGradeCond = false;

      if (school) {
        selectedTestGradeCond = true;
      } else if (this.props.NavigationByHeaderSelection.class) {
        selectedTestGradeCond = standardperformance.selectedTestGrade != "";
      } else if (district) {
        selectedTestGradeCond = true;
      }
      if (
        (apiCalls.strandsApi &&
          !OnlyORRAccess &&
          !student &&
          ApiCalls.Done_RosterTab_Details_Setup &&
          selectedTestGradeCond) ||
        (district && apiCalls.strandsApi) // 2nd condition for grade dropddown selection
      ) {
        if (district) {
          //this condition for district reload
            this.props.Getstandardperformance_SummaryReports(fromContext);
        } else {
          this.props.Getstandardperformance_SummaryReports(fromContext);
        }
      }
    }
  }

  hideComponent(name) {
    switch (name) {
      case "showUsageData":
        this.setState({
          showUsageData: true,
          showTestStatusData: false,
          showStandardsPerformanceData: false,
          showOrrData: false,
        });
        break;
      case "showTestStatusData":
        this.setState({
          showUsageData: false,
          showTestStatusData: true,
          showStandardsPerformanceData: false,
          showOrrData: false,
        });
        break;
      case "showStandardsPerformanceData":
        this.setState({
          showUsageData: false,
          showTestStatusData: false,
          showStandardsPerformanceData: true,
          showOrrData: false,
        });
        break;
      case "showOrrData":
        this.setState({
          showUsageData: false,
          showTestStatusData: false,
          showStandardsPerformanceData: false,
          showOrrData: true,
        });
        break;
      default:
        null;
    }
  }

  renderORR_RLP(
    renderCondition,
    loader,
    NoDatascreen_ORR,
    isPastDistrictTerm,
    NoaccessToReports,
    OnlyORRData
  ) {
    if (renderCondition) {
      const Nav = this.props.NavigationByHeaderSelection;
      const { SelectedClass } = this.props.ContextHeader.Summary_Roster_Data;
      let showLoaderForClass =
        Nav.class && (!SelectedClass || !SelectedClass.id);
      let innerView = <NoDataFoundLayout orrnodata />;
      if (loader || showLoaderForClass) {
        innerView = <LoadingScreen />;
      } else if (!NoDatascreen_ORR && !isPastDistrictTerm) {
        innerView = <SummaryTab widgetForSummaryReports={true} />;
      }

      return (
        <WidgetLayout
          widgetTitle="Oral Reading Records | Reading Level Progress"
          enablePrint={false}
          NoaccessToReports={NoaccessToReports}
          OnlyORRData={OnlyORRData}
        >
          {innerView}
        </WidgetLayout>
      );
    }
  }

  renderAssessment_Widgets(
    {
      NoaccessToReports,
      fromContext,
      loadingScreenInUniversal,
      NoDatascreen_testStatus,
      isPastDistrictTerm,
    },
    haveAccess
  ) {
    if (!NoaccessToReports && haveAccess) {
      let innerView = <NoDataFoundLayout testnodata />;
      if (loadingScreenInUniversal) {
        //loadingScreenInUniversal
        innerView = <LoadingScreen />;
      } else if (!NoDatascreen_testStatus && !isPastDistrictTerm) {
        innerView =
          fromContext === "class" ? (
            <ClassTestStatus NoDatascreen={NoDatascreen_testStatus} />
          ) : (
            <TestStatus />
          );
      }
      return (
        <WidgetLayout
          widgetTitle="Assessments | Test Status"
          TSPrint={SUMMARYREPORTS_TS_PDF}
          NoaccessToReports={NoaccessToReports}
          TestStatusCSV={true}
          fromContext={fromContext}
        >
          {innerView}
        </WidgetLayout>
      );
    }
  }
  render() {
    const { UniversalFilter } = this.props;
    let UniversalApiCalls = this.props.ApiCalls;
    const { loaderGetRosterCompleteData } = UniversalApiCalls;
    const { DistrictRLPState } = this.props.DistrictRlpData1;
    let { LoginDetails, Auth_Apis } = this.props.Authentication;
    const { ReportingAccessParam } = LoginDetails;
    const { RosterApi } = Auth_Apis;
    let OnlyORRData =
      !ReportingAccessParam.includes("eAR") &&
      ReportingAccessParam.includes("ORR");
    let BotheARandORR =
      ReportingAccessParam.includes("ORR") &&
      ReportingAccessParam.includes("eAR");
    const fromContext = ActiveContext(this.props.NavigationByHeaderSelection);

    let NoaccessToReports = false;
    let NoDatascreen_Strands = false; //dynamic props will come here
    let NoDatascreen_testStatus = false;
    const { ContextHeader, SchoolRLPState } = this.props;
    const { Date_Tab } = ContextHeader;
    let { TermsListWithOutUTCFormat } = this.props.DateTabComponents;

    let isPastDistrictTerm =
      Date_Tab.summaryReportsTerm &&
      isArray(TermsListWithOutUTCFormat) &&
      TermsListWithOutUTCFormat.length > 0 &&
      TermsListWithOutUTCFormat &&
      TermsListWithOutUTCFormat[0] &&
      Date_Tab.summaryReportsTerm.termId !==
        TermsListWithOutUTCFormat[0].termId;
    const { responseData } = SchoolRLPState;
    let ClassGridRlpData = this.props.ClassGridRlpData;

    let ORRWidgetDataNotExists =
      (!ClassGridRlpData.isApiLoading &&
        ClassGridRlpData.responseData != undefined &&
        ClassGridRlpData.responseData != null &&
        ClassGridRlpData.responseData.readingLevelAxis != undefined &&
        ClassGridRlpData.responseData.readingLevelAxis == null) ||
      (!ClassGridRlpData.isApiLoading && ClassGridRlpData.noChartData) ||
      (!SchoolRLPState.isApiLoading &&
        responseData != null &&
        responseData.readingLevelAxis != undefined &&
        responseData.readingLevelAxis == null) ||
      (!SchoolRLPState.isApiLoading && SchoolRLPState.noChartData) ||
      (!DistrictRLPState.isApiLoading && DistrictRLPState.noChartData) ||
      (!DistrictRLPState.isApiLoading &&
        DistrictRLPState.responseData != null &&
        DistrictRLPState.responseData.readingLevelAxis != undefined &&
        DistrictRLPState.responseData.readingLevelAxis == null)
        ? true
        : false;

    let NoDatascreen_ORR =
      ORRWidgetDataNotExists || (isPastDistrictTerm ? true : false);
    let SummaryReports_nodta_text =
      "Required summary details for assessments standard performance details not available...!";
    const { loadingScreenInUniversal, isTermIdsEqualAndNull } = this.props;
    const { apiCalls, standardperformance } =
      this.props.SummaryReports[`${fromContext}`].assessments;
    NoDatascreen_testStatus = apiCalls.testStatusNoData;
    //  : school ?
    //     this.props.SummaryReports.school.assessments : this.props.NavigationByHeaderSelection.class ? this.props.SummaryReports.class.assessments :
    //         this.props.SummaryReports.student.assessments

    let HeaderStrands_Length = Object.keys(
      standardperformance.HeaderStrands
    ).length;

    let StrandsLoading =
      loadingScreenInUniversal ||
      apiCalls.loadingOnStrands ||
      apiCalls.strandsApi;
    let summary_stand_perf_data_length =
      standardperformance !== undefined
        ? standardperformance.data != null &&
          standardperformance.data != undefined &&
          standardperformance.data != SummaryReports_nodta_text
          ? Object.keys(standardperformance.data).length
          : 0
        : 0;
    NoDatascreen_Strands = apiCalls.Nodata; //((!StrandsLoading && summary_stand_perf_data_length === 0) || (!StrandsLoading && this.props.isPastDistrictTerm)) ? true : false;
    if(apiCalls.Nodata && this.props.NavigationByHeaderSelection.class) {
      NoDatascreen_Strands = apiCalls.Nodata
    }else {
    NoDatascreen_Strands =
      summary_stand_perf_data_length != 0 ||
      Date_Tab.selectedterm_Obj.termRange ==
        (Date_Tab.DistrictTerms_New[0] &&
          Date_Tab.DistrictTerms_New[0].termRange)
        ? false
        : true;
      }
    if (isPastDistrictTerm) {
      NoDatascreen_Strands = true;
    }
    let { banner } = this.props.SummaryReports[`${fromContext}`].assessments;
    let Bannermessage;
    if (
      (isPastDistrictTerm && !OnlyORRData) ||
      (NoDatascreen_Strands && NoDatascreen_testStatus && !NoDatascreen_ORR)
    ) {
      Bannermessage = "Assessments tab";
    } else if (
      (NoDatascreen_Strands || HeaderStrands_Length == 0) &&
      NoDatascreen_testStatus &&
      NoDatascreen_ORR &&
      BotheARandORR
    ) {
      Bannermessage = "Assessments tab or the Oral Reading Records tab";
    } else if (NoDatascreen_ORR) {
      Bannermessage = "Oral Reading Records tab";
      banner = true;
    }
    const {
      showUsageData,
      showTestStatusData,
      showStandardsPerformanceData,
      showOrrData,
    } = this.state;
    // const isIpadScreen =
    //   this.props.UserScreenWidth == 1024 || this.props.UserScreenWidth < 1024
    const isIpadScreen = this.state.isIpadScreen;

    let SummaryWidgetLoader =
      loadingScreenInUniversal ||
      loaderGetRosterCompleteData ||
      RosterApi ||
      UniversalApiCalls.Get_Selected_School_Info ||
      UniversalApiCalls.getInitialSchoolObj ||
      (UniversalApiCalls.loadingFor == "school" && UniversalFilter == "");

    if (isIpadScreen) {
      return (
        <div className="ar_summary_assessments">
          {/* { Bannermessage && banner && BannerText(Bannermessage)} */}
          <div className="ar_summaryWidget-Ipad-block">
            <div className="ar_summaryWidget-Inr-menu">
              <ul className="ar_summaryWidget-Inr-menu-ul">
                {ReportingAccessParam.includes("usageReports") &&
                ENABLE_USAGE_WIDGET ? (
                  <li
                    className={
                      showUsageData
                        ? "ar_summaryWidget-Inr-menu-li ar_summaryWidget-Inr-menu-li-active"
                        : "ar_summaryWidget-Inr-menu-li"
                    }
                    onClick={() => this.hideComponent("showUsageData")}
                  >
                    Usage
                  </li>
                ) : null}
                {ReportingAccessParam.includes("ORR") && ENABLE_ORR_WIDGET ? (
                  <li
                    className={
                      showOrrData
                        ? "ar_summaryWidget-Inr-menu-li ar_summaryWidget-Inr-menu-li-active"
                        : "ar_summaryWidget-Inr-menu-li"
                    }
                    onClick={() => this.hideComponent("showOrrData")}
                  >
                    Oral Reading Records
                  </li>
                ) : null}
                {NoaccessToReports ? null : NoaccessToReports ? null : ReportingAccessParam.includes(
                    "eAR"
                  ) && ENABLE_TEST_STATUS_WIDGET ? (
                  <li
                    className={
                      showTestStatusData
                        ? "ar_summaryWidget-Inr-menu-li ar_summaryWidget-Inr-menu-li-active"
                        : "ar_summaryWidget-Inr-menu-li"
                    }
                    onClick={() => this.hideComponent("showTestStatusData")}
                  >
                    Test Status
                  </li>
                ) : null}
                {ReportingAccessParam.includes("eAR") && ENABLE_SP_WIDGET ? (
                  <li
                    className={
                      showStandardsPerformanceData
                        ? "ar_summaryWidget-Inr-menu-li ar_summaryWidget-Inr-menu-li-active"
                        : "ar_summaryWidget-Inr-menu-li"
                    }
                    onClick={() =>
                      this.hideComponent("showStandardsPerformanceData")
                    }
                  >
                    Standards Performance
                  </li>
                ) : null}
              </ul>
            </div>
            <div className="ar_summaryWidget-Inr-menu-widgetlayout">
              <div className="ar_summaryWidget-Inr-menu-widgetlayout-inr">
                <div
                  className={
                    BotheARandORR
                      ? "ar_summary_assessments-inr ar_summary_orr-inr"
                      : "ar_summary_assessments-inr"
                  }
                >
                  <div style={{ width: "100%" }}>
                    {showUsageData && (
                      <WidgetLayout
                        widgetTitle="Usage | Overview"
                        enablePrint={false}
                        NoaccessToReports={NoaccessToReports}
                        OnlyORRData={OnlyORRData}
                      >
                        {loadingScreenInUniversal ||
                        apiCalls.loadingOnStrands ? (
                          <LoadingScreen />
                        ) : !NoDatascreen_ORR ? (
                          <SummaryTab widgetForSummaryReports={true} />
                        ) : (
                          <NoDataFoundLayout Usagenodata />
                        )}
                      </WidgetLayout>
                    )}

                    {showTestStatusData && ENABLE_TEST_STATUS_WIDGET && (
                      <WidgetLayout
                        widgetTitle="Assessments | Test Status"
                        TSPrint={SUMMARYREPORTS_TS_PDF}
                        NoaccessToReports={NoaccessToReports}
                        TestStatusCSV={true}
                        fromContext={fromContext}
                      >
                        {loadingScreenInUniversal || apiCalls.loadingOnTestStatus ? (
                          <LoadingScreen />
                        ) : !NoDatascreen_testStatus && !isPastDistrictTerm ? (
                          fromContext === "class" ? (
                            <ClassTestStatus
                              NoDatascreen={NoDatascreen_testStatus}
                            />
                          ) : (
                            <TestStatus />
                          )
                        ) : (
                          <NoDataFoundLayout testnodata />
                        )}
                      </WidgetLayout>
                    )}

                    {showStandardsPerformanceData && ENABLE_SP_WIDGET && (
                      <WidgetLayout
                        widgetTitle="Assessments | Standards Performance"
                        enablePrint={false}
                        NoaccessToReports={NoaccessToReports}
                        standardperformanceCSV={true}
                        standardperformancePrint={SUMMARYREPORTS_PDF}
                        fromContext={fromContext}
                      >
                        {StrandsLoading ? (
                          <LoadingScreen />
                        ) : !NoDatascreen_Strands &&
                          !isPastDistrictTerm &&
                          HeaderStrands_Length != 0 ? (
                          <StdOverview
                            fromContext={fromContext}
                            apiCalls={apiCalls}
                            standardperformance={standardperformance}
                          />
                        ) : (
                          <NoDataFoundLayout standardedsnodata />
                        )}
                      </WidgetLayout>
                    )}
                    {this.renderORR_RLP(
                      showOrrData && ENABLE_ORR_WIDGET,
                      SummaryWidgetLoader,
                      NoDatascreen_ORR,
                      isPastDistrictTerm,
                      NoaccessToReports,
                      OnlyORRData
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="ar_summary_assessments">
        {/* { Bannermessage && banner && BannerText(Bannermessage)} */}

        {/* {!ENABLE_ORR_WIDGET && !ENABLE_SP_WIDGET && !ENABLE_TEST_STATUS_WIDGET && !ENABLE_USAGE_WIDGE && <div>
                    
                    </div>} */}

        <div
          className={
            BotheARandORR
              ? "ar_summary_assessments-inr ar_summary_orr-inr"
              : "ar_summary_assessments-inr"
          }
        >
          {ReportingAccessParam.includes("usageReports") &&
          ENABLE_USAGE_WIDGET ? (
            <WidgetLayout
              widgetTitle="Usage | Overview"
              enablePrint={false}
              NoaccessToReports={NoaccessToReports}
            >
              {SummaryWidgetLoader ? (
                <LoadingScreen />
              ) : !isPastDistrictTerm ? (
                <BuurSummaryWidget />
              ) : (
                <NoDataFoundLayout Usagenodata />
              )}
            </WidgetLayout>
          ) : null}

          {/* here ORR changes */}

          {this.renderORR_RLP(
            ReportingAccessParam.includes("ORR") && ENABLE_ORR_WIDGET,
            SummaryWidgetLoader,
            NoDatascreen_ORR,
            isPastDistrictTerm,
            NoaccessToReports,
            OnlyORRData
          )}

          {this.renderAssessment_Widgets(
            {
              NoaccessToReports,
              fromContext,
              loadingScreenInUniversal,
              NoDatascreen_testStatus,
              isPastDistrictTerm,
            },
            ReportingAccessParam.includes("eAR") && ENABLE_TEST_STATUS_WIDGET
          )}

          {NoaccessToReports
            ? null
            : this.props.Authentication.LoginDetails.ReportingAccessParam.includes(
                "eAR"
              ) &&
              ENABLE_SP_WIDGET && (
                <WidgetLayout
                  widgetTitle="Assessments | Standards Performance"
                  enablePrint={false}
                  NoaccessToReports={NoaccessToReports}
                  standardperformanceCSV={true}
                  standardperformancePrint={SUMMARYREPORTS_PDF}
                  fromContext={fromContext}
                >
                  {StrandsLoading ? (
                    <LoadingScreen />
                  ) : !NoDatascreen_Strands &&
                    !isPastDistrictTerm &&
                    HeaderStrands_Length != 0 ? (
                    <StdOverview
                      fromContext={fromContext}
                      apiCalls={apiCalls}
                      standardperformance={standardperformance}
                    />
                  ) : (
                    <NoDataFoundLayout standardedsnodata />
                  )}
                </WidgetLayout>
              )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  SummaryTabReducer,
  Universal,
  SummaryReports,
  DistrictRlpData1,
  Authentication,
  SchoolRlpData,
  ClassGridRlpData,
  DateTabReducer,
}) => {
  const { popUp } = SummaryTabReducer;
  const { SchoolRLPState } = SchoolRlpData;
  const {
    NavigationByHeaderSelection,
    loadingScreenInUniversal,
    isTermIdsEqualAndNull,
    isPastDistrictTerm,
    ApiCalls,
    ContextHeader,
    UserScreenWidth,
    UniversalFilter,
    currentTermID,
    UniversalSelecter
  } = Universal;
  const { DateTabComponents, Context_DateTab_TestStatus } = DateTabReducer;
  return {
    popUp,
    NavigationByHeaderSelection,
    loadingScreenInUniversal,
    SummaryReports,
    isTermIdsEqualAndNull,
    isPastDistrictTerm,
    DistrictRlpData1,
    ApiCalls,
    Authentication,
    ContextHeader,
    UserScreenWidth,
    SchoolRLPState,
    ClassGridRlpData,
    DateTabComponents,
    UniversalFilter,
    Context_DateTab_TestStatus,
    currentTermID,
    UniversalSelecter
  };
};
export default connect(mapStateToProps, {
  Getstandardperformance_SummaryReports,
  trackingUsage,
  getGradeList,
  GetSummaryTestStatusReports
})(districtSummaryScreen);
