import React, { Component } from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import DropdownPagination from './DropdownPagination/index.jsx';
import '../../../public/css/style.css';
import './index.css';

class CheckboxSearchDropdown extends Component {
  static ellipsisName(name) {
    return name == undefined
      ? ''
      : name.length > 24
        ? name.slice(0, 24) + '...'
        : name;
  }

  static tooltipDisplay(tooltipName) {
    let contextTooltip = null;
    if (tooltipName !== null && tooltipName !== undefined) {
      tooltipName.length > 24 ? contextTooltip =
          <div className="bec_tooltip">
            <div className="bec_tooltip_arrow"></div>
            <div className="bec_tooltip_content">
              {tooltipName}
            </div>
          </div>
        : null;
    }
    return contextTooltip;
  }

  constructor(props) {
    super(props);
    this.toggleDropdown = this.toggleDropdown.bind(this);
    this.updateSelectionItems = this.updateSelectionItems.bind(this);
    this.generateDropdownItems = this.generateDropdownItems.bind(this);
    this.generateSelectedItemsLabel = this.generateSelectedItemsLabel.bind(this);
    this.modifyPagination = this.modifyPagination.bind(this);
    this.state = {
      searchText: '',
      openDropdown: false,
      itemStatus: {},
      filteredItems: [],
      selectedItems: [],
      propValidation: true,
      paginationOffset: 0
    };
  }

  componentDidMount() {
    this.initDropdownState();
    this.updateSelectionItems('');
  }

  componentDidUpdate(prevProps) {
    if (JSON.stringify(prevProps.preSelectedItems) !== JSON.stringify(this.props.preSelectedItems)) {
      setTimeout(() => {
        this.initDropdownState();
        this.updateSelectionItems(this.state.searchText);
      }, 1);
    }
    if (JSON.stringify(prevProps.selectionItems) !== JSON.stringify(this.props.selectionItems)) {
      setTimeout(() => {
        this.setState({
          searchText: '',
          openDropdown: false,
          itemStatus: {},
          filteredItems: [],
          selectedItems: [],
          paginationOffset: 0,
          propValidation: true
        });
        this.initDropdownState();
        this.updateSelectionItems('');
      }, 1);
    }
    if (prevProps.externalCloseDropdown !== this.props.externalCloseDropdown && this.props.externalCloseDropdown) {
      this.setState({
        openDropdown: false
      });
    }
  }

  initDropdownState() {
    const itemStatus = {};
    if (!Array.isArray(this.props.selectionItems)) {
      this.setState({propValidation: false});
      return;
    }
    if (this.props.allOption && this.props.maxSelections === 1) {
      itemStatus.All = false;
      if (this.props.preSelectedItems.indexOf('All') > -1) {
        itemStatus.All = true;
      }
    }
    this.props.selectionItems.forEach((item) => {
      itemStatus[item.id] = false;
      if (Array.isArray(this.props.preSelectedItems)) {
        if (this.props.preSelectedItems.indexOf(item.id) > -1) {
          itemStatus[item.id] = true;
        }
      }
    });
    this.setState({itemStatus});
  }

  isAllSelected() {
    if (this.props.maxSelections === 1) {
      return this.state.itemStatus.All;
    }
    let isAll = true;
    this.state.filteredItems.forEach((item) => {
      if (this.state.itemStatus[item.id] !== true) {
        isAll = false;
      }
    });
    return isAll;
  }

  toggleDropdown(e) {
    const newToggle = this.props.frozen ? false : !this.state.openDropdown;
    if (newToggle) {
      this.props.onOpenDropdown(this.props.checkboxGlobalId);
    }
    this.setState({openDropdown: newToggle});
  }

  handleOptionClick(id) {
    const newItemStatus = {...this.state.itemStatus};
    const newStatus = !this.state.itemStatus[id];
    if (this.props.maxSelections === 1) {
      Object.keys(newItemStatus).forEach((key) => {
        newItemStatus[key] = false;
      });
      newItemStatus[id] = true;
    } else if (id !== 'All') {
      newItemStatus[id] = newStatus;
    } else {
      const allStatus = !this.isAllSelected();
      this.state.filteredItems.forEach((item) => {
        newItemStatus[item.id] = allStatus;
      });
    }
    this.setState({itemStatus: newItemStatus});
    setTimeout(() => {
      this.updateSelectionItems(this.state.searchText);
    }, 1);
  }

  generateItem(id, name, status) {
    const selectedClassName = status ? 'item-selected' : '';
    const itemDisplay = (this.props.maxSelections > 1) ?
      (<div className="multi-selection">
        <div className="input-checkbox-container">
          <div className="input-checkbox">
            <input
              checked={status}
              value={id}
              type="checkbox" />
            <span className="checkbox"></span>
          </div>
        </div>
        <span className="checkbox-label">{name}</span>
      </div>) : (
        <div
          className="single-selection"
        >{name}</div>
      );
    return (<li value={id}
                onClick={() => this.handleOptionClick(id)}
                className={selectedClassName}
            >{itemDisplay}</li>);
  }

  generateDropdownItems() {
    const dropdownItems = [];
    const allLine = [];
    let allContainer = '';
    let itemCount = 0;
    if (this.props.allOption) {
      allLine.push(this.generateItem('All', 'All', this.isAllSelected()));
      allContainer = (<div className="all-option-container">{allLine}</div>);
    }
    this.state.filteredItems.forEach((item) => {
      if (itemCount >= this.state.paginationOffset
        && itemCount < this.state.paginationOffset + this.props.paginationItemsPerPage) {
        dropdownItems.push(this.generateItem(item.id, item.name, this.state.itemStatus[item.id]));
      }
      itemCount = itemCount + 1;
    });
    return (
      <React.Fragment>
        <ul>
          {allContainer}
        </ul>
        <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={this.props.scrollAreaMaxHeight}>
          <ul>
            {dropdownItems}
          </ul>
        </Scrollbars>
      </React.Fragment>
    );
  }

  updateSelectionItems(searchText) {
    const filteredItems = [];
    if (!Array.isArray(this.props.selectionItems)) {
      this.setState({propValidation: false});
      return;
    }
    let newPaginationOffset = this.state.paginationOffset;
    this.props.selectionItems.forEach((item) => {
      if (item.name !== undefined) {
        if (item.name.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || !this.props.hasSearch) {
          filteredItems.push(item);
        }
      }
    });
    const selectedItems = [];
    filteredItems.forEach((item) => {
      if (this.state.itemStatus[item.id]) {
        selectedItems.push(item.id);
      }
    });
    if (filteredItems.length !== this.state.filteredItems.length) {
      newPaginationOffset = 0;
    }
    this.setState({filteredItems, selectedItems, searchText, paginationOffset: newPaginationOffset});
    this.props.onChangeSelectedIds(selectedItems);
  }

  generateSelectedItemsLabel() {
    if (this.props.selectionOverride !== null) {
      return this.props.selectionOverride;
    }
    if (this.state.itemStatus.All) {
      return 'All';
    }
    if (this.state.selectedItems.length === 0) {
      return this.props.placeholder;
    }
    if (this.state.selectedItems.length === 1) {
      let name = '';
      this.props.selectionItems.forEach((item) => {
        if (item.id === this.state.selectedItems[0]) {
          name = item.name;
        }
      });
      return name;
    }
    if (this.state.selectedItems.length === this.state.filteredItems.length) {
      return `All (${this.state.selectedItems.length})`;
    }
    return `Custom (${this.state.selectedItems.length})`;
  }

  modifyPagination(offset) {
    this.setState({paginationOffset: offset});
  }

  render() {
    const dropdownItems = this.generateDropdownItems();
    const selectedItemLabel = this.generateSelectedItemsLabel();
    const noRecords = Array.isArray(this.props.selectionItems)
      ? (this.props.selectionItems.length === 0) : true;
    const noMatches = (this.state.filteredItems.length === 0);
    let noChoice = true;
    if (Array.isArray(this.props.selectionItems)) {
      noChoice = (this.props.selectionItems.length === 1 && this.props.maxSelections === 1 && this.props.preSelectedItems.length === 1);
    }
    const showNoRecordsMessage = (noRecords || this.props.loading || !this.state.propValidation) && this.props.selectionOverride === null;
    return (
      <div className="checkbox-search-dropdown-container">
        <div className="menu-title">
          {this.props.menuTitle}
          <span className="loading-spinner-container">
            {this.props.loading ? <i className="material-icons">autorenew</i> : null}
          </span>
        </div>
        {showNoRecordsMessage ? (<div className="no-records-message">
            {this.props.loading ? '' : this.props.noRecordsMessage}
        </div>) :
        <React.Fragment>
          <div className={(this.state.openDropdown && !this.props.frozen) ?
          "menu-selector active-selector" : "menu-selector"} >
            <button
              style={{
                background: (noChoice ? "#FFF" : "")
              }}
              onClick={noChoice ? () => {} : this.toggleDropdown}
              className={(this.props.frozen || noChoice) ? 'select-dropdown frozen' : 'select-dropdown'}
            >
              <span className="Roster-Dropdown-text">
                {CheckboxSearchDropdown.ellipsisName(selectedItemLabel)}
                {CheckboxSearchDropdown.tooltipDisplay(selectedItemLabel)}
              </span>
            </button>
          </div>
          <div className={(this.state.openDropdown && !this.props.externalCloseDropdown && !this.props.frozen) ?
            "menu-dropdown menu-open" : "menu-dropdown hide"} >
            <div
              className={"menu-dropdown-container"}>
              {this.props.hasSearch && (
              <div
                className="menu-varient-search">
                <input type="text"
                       value={this.state.searchText}
                       onChange={(txt) => this.updateSelectionItems(txt.target.value)}
                       placeholder="Search"
                       className={this.state.searchText.length > 0 ? "roster_magnifier_search_bg_none" : "roster_magnifier_search_bg"}
                />
                {this.state.searchText.length > 0 ?
                  <span
                    onClick={() => this.updateSelectionItems('')}
                    className="menu-varient-search-cancel"
                  >
                    x
                  </span> : null}
              </div>)}
              {noMatches ? (<div className="no-filtered-message">{this.props.noFilteredMessage}</div>) :
              <div className="menu-dropdown-list">
                <div className="menu-dropdown-list-inr">
                  {dropdownItems}
                </div>
              </div>}
            </div>
            <div className="dropdown-pagination-container">
            <DropdownPagination
              itemsPerPage={this.props.paginationItemsPerPage}
              itemCount={this.state.filteredItems.length}
              itemOffset={this.state.paginationOffset}
              onPaginationChange={this.modifyPagination}
            />
            </div>
          </div>
        </React.Fragment>}
      </div>);
  }
}

CheckboxSearchDropdown.defaultProps = {
  checkboxGlobalId: '',
  hasSearch: true,
  menuTitle: '',
  loading: false,
  placeholder: 'Select',
  selectionItems: [],
  preSelectedItems: [],
  paginationItemsPerPage: 20,
  allOption: true,
  maxSelections: 999999,
  frozen: false,
  noRecordsMessage: 'No Records Available',
  noFilteredMessage: 'No Matches Found',
  onChangeSelectedIds: (ids) => { console.log(ids); },
  scrollAreaMaxHeight: 210,
  selectionOverride: null,
  onOpenDropdown: () => {},
  externalCloseDropdown: false
}

export default CheckboxSearchDropdown
