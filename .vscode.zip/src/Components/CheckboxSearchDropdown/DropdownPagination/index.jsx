import React, { Component } from 'react';
import './index.css';

class DropdownPagination extends Component {

  constructor(props) {
    super(props);
    this.paginationAction = this.paginationAction.bind(this);
    this.getPaginationBubbles = this.getPaginationBubbles.bind(this);
    this.state = {
      bubbleStart: 1,
    };
  }

  paginationAction(action) {
    let currentBubble = this.state.bubbleStart;
    if (action === 'left') {
      this.setState({bubbleStart:currentBubble - 1});
      return;
    }
    if (action === 'right') {
      this.setState({bubbleStart:currentBubble + 1});
      return;
    }
    const newOffset = (Number(action) - 1) * this.props.itemsPerPage;
    this.props.onPaginationChange(newOffset);
  }

  getItemsToDisplay(page) {
    const startItem = ((page - 1) * this.props.itemsPerPage) + 1;
    let endItem = startItem + this.props.itemsPerPage - 1;
    if (endItem > this.props.itemCount) {
      endItem = this.props.itemCount;
    }
    return `${startItem}-${endItem}`;
  }

  getPaginationBubbles(Pagination) {
    const totalBubbles = (Pagination.totalPagesCount > this.props.pagesDisplayed)
      ? this.props.pagesDisplayed : Pagination.totalPagesCount;
    const paginationBubbles = [];
    const paginationItemNumbers = [];
    for(var i = 0; i < totalBubbles; i++) {
      const incBubble = i;
      paginationBubbles.push(
        <li
          onClick={() => {
            (Pagination.Bubble_Start + incBubble == Pagination.pageAt) ? null :
              this.paginationAction(Pagination.Bubble_Start + incBubble)
          }}
          title={this.getItemsToDisplay(Pagination.Bubble_Start + incBubble)}
          className={(Pagination.Bubble_Start + incBubble == Pagination.pageAt) ? "active-page" : ""}>
          <span>
            {Pagination.Bubble_Start + incBubble}
          </span>
        </li>);
      paginationItemNumbers.push(
        <li className={Pagination.totalPagesCount > 2 ? "text-left" : null}>
          <span className="page-numbers">
            {this.getItemsToDisplay(Pagination.Bubble_Start + i)}
          </span>
        </li>);
    }
    return (<div style={{float: 'left', maxWidth: '122px', width: '100%'}}>
      <div className="PaginationBubblesAndCount">
        <ul className="page-circle-list">
          {paginationBubbles}
        </ul>
      </div>
      <div style={{display: 'flex', margin: '0px auto', alignItems: 'center', width: '100%', maxWidth: '122px'}}>
        <ul className="page-numbers-list">
          {paginationItemNumbers}
        </ul>
      </div>
    </div>);
  }

  render() {
    const Pagination = {
      totalPagesCount: Math.ceil(this.props.itemCount / this.props.itemsPerPage),
      pageAt: Math.floor(this.props.itemOffset / this.props.itemsPerPage) + 1,
      Bubble_Start: this.state.bubbleStart
    };
    if (Pagination.totalPagesCount < 2) {
      return null;
    }
    const paginationBubbles = this.getPaginationBubbles(Pagination);
    return <div className="dropdown-pagniation"
                style={{ width: `${this.props.paginationWidth}px` }}>
      <div className="dropdown-pagniation-container">
        <span
          onClick={() => {
            Pagination.Bubble_Start === 1 ? null :
              this.paginationAction('left')
          }}
          className={
            Pagination.totalPagesCount > this.props.pagesDisplayed ?
              (Pagination.Bubble_Start === 1 ?
                "scroll-left float-left scroll-disable" :
                "scroll-left float-left scroll-active ") : "scroll-left float-left hidePaginationArrow"} >
                  <i className="material-icons">chevron_left</i>
        </span>
        {paginationBubbles}
        <span
          onClick={() =>
            Pagination.totalPagesCount <= this.props.pagesDisplayed || (Pagination.Bubble_Start + this.props.pagesDisplayed - 1) == Pagination.totalPagesCount ? null :
              this.paginationAction('right')
          }
          className={
            Pagination.totalPagesCount > this.props.pagesDisplayed ?
              (Pagination.Bubble_Start + this.props.pagesDisplayed - 1) == Pagination.totalPagesCount ?
                "scroll-right float-right scroll-disable" : "scroll-right scroll-active float-right" : " scroll-right float-right hidePaginationArrow"}>
                  <i className="material-icons">chevron_right</i>
        </span>
      </div>
    </div>
  }
}

DropdownPagination.defaultProps = {
  itemCount: 0,
  itemsPerPage: 20,
  itemOffset: 0,
  pagesDisplayed: 3,
  onPaginationChange: (action) => { console.log(action); },
  paginationWidth: 206
}

export default DropdownPagination