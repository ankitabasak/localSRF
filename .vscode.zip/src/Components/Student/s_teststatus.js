import React, { Component } from 'react';
import { connect } from "react-redux";
import { TestStatus_Pagination } from '../../Utils/TestStatus/TestScore_Pagination';
import { SortTestStatusDetailsData, SortTestStatusSummaryData, FilterStudent_TestStatus_Data ,Pagination_Bubble_Selection, Pagination_Navigate_Selection,Get_TestStatusDetailsData } from '../../Redux_Actions/TestStatus.Actions';

import {Call_TestStatusDetailsData,triggerPdfDownload} from '../../services/testStatus.service';
import { SaveContextSelection } from '../../Redux_Actions/UniversalSelectorActions';
import ts_ic_not_started from '../../../public/images/ts_ic_not_started.svg';
import ts_ic_not_started_gray_out from '../../../public/images/ts_ic_not_started_gray_out.svg';
import ts_ic_in_progress from '../../../public/images/ts_ic_in_progress.svg';
import ts_ic_in_progress_gray_out from '../../../public/images/ts_ic_in_progress_gray_out.svg';
import ts_ic_grading from '../../../public/images/ts_ic_grading.svg';
import ts_ic_grading_gray_out from '../../../public/images/ts_ic_grading_gray_out.svg';
import ts_ic_completed from '../../../public/images/ts_ic_completed.svg';
import ts_ic_completed_gray_out from '../../../public/images/ts_ic_completed_gray_out.svg';
import ic_print from '../../../public/images/ic_print_new.svg';
import LoadingScreen from '../../Utils/LoadingScreen/LoadingScreen';
import { pageParamsForDisplay } from '../../Utils/TestStatus/reUsableFunctions/testStatusFunctions';
import StudentTestStatusPDF from '../ReusableComponents/TestStatusPDF/StudentTestStatusPDF';
import TestStatusPopup from '../../Utils/TestStatusPrintModel/testStatusPrint';
import {openPopUpInTestStatusPrint,handleStudentFilterInTestStatus} from '../../Redux_Actions/TestStatusPrintActions'
import { convertUTCDateToLocalDate, userTimeZoneDate } from '../ReusableComponents/AllReusableFunctions';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../Utils/globalVars';
import { trackingUsage } from '../../Redux_Actions/AuthenticationAction';

class s_TestStatus extends Component {
    constructor(props) {
        super(props);
        this.SortTableData = this.SortTableData.bind(this);
        this.SortDetailsData = this.SortDetailsData.bind(this);
        this.OnStatusSelection = this.OnStatusSelection.bind(this);
        this.NavToSingleTest = this.NavToSingleTest.bind(this);
        this.state = {}
    }

    componentDidMount() {
        Call_TestStatusDetailsData(this.props, "student")
        triggerPdfDownload(this.props, "student",this.props.studentTestStatusPrint.triggerAPI)
        this.props.trackingUsage("assessmentreports_teststatussummary:student");
    }

    componentDidUpdate() {
        Call_TestStatusDetailsData(this.props, "student")
        triggerPdfDownload(this.props, "student",this.props.studentTestStatusPrint.triggerAPI)
    }
    NavToSingleTest(option, singleGroup) {
        this.props.SaveContextSelection(option, singleGroup);
    }
    render() {

        let Nav = this.props.NavigationByHeaderSelection;
        let U_Api = this.props.ApiCalls;
        const {List,Pagination,Apicalls,SortStatus,SortStatus_Type,CurrentStatus, filteredData, StatusCodes} = this.props.TestStatusReducer.Student;
        const { loadingOnGetDetailsData } = Apicalls
        const { Not_Started, In_Progress, Needs_To_Be_Graded, Complete} = StatusCodes
        let LoginDetails = this.props.LoginDetails;
        let TestApiOr_SchoolApi = U_Api.getTests ||
            U_Api.Get_Selected_School_Info ||
            U_Api.loadingFor == "tests" ||
            U_Api.loadingFor == "school";
        let LoaderEnable = loadingOnGetDetailsData && !TestApiOr_SchoolApi

        const {pageAt,totalPagesCount,Bubble_Start,Count_Per_Page} = Pagination

        let pageSlicers = pageParamsForDisplay(pageAt, Count_Per_Page)
        let currentPageData = filteredData !=undefined ? filteredData.slice(pageSlicers.pageStart, pageSlicers.pageEnd):null

        const studentTestStatusPrint = this.props.studentTestStatusPrint

        const sortingDataPDF = {
            "summaryLevel":{
                "SortStatus":SortStatus,
                "SortStatus_Type":SortStatus_Type
            }
        }
        let rosterData = this.props.ContextHeader.Roster_Tab;
        const full_url = window.location.href;
        const url = full_url.split('#');
        const domain_url = url[0];
        return <div className="testStatus">
                    {studentTestStatusPrint.triggerPDF?<StudentTestStatusPDF />:null}
                    {/* <StudentTestStatusPDF /> */}
                    {/*  */}
                    {studentTestStatusPrint !== undefined ? studentTestStatusPrint.popupStatus ? <TestStatusPopup testStatusPrintData={studentTestStatusPrint} contextSelected="student" />:null:null}
                    {/*  */}
                    <div className="testStatusMain">
                    {
                    LoaderEnable || (currentPageData.length == 0 && CurrentStatus=="AllStatus") ? <LoadingScreen /> :
                        <div className="testStatus_studentContext">

                            <div className="testStatus_student_filter">
                                <div className="testStatus_student_filter_inr">
                                    <div className="testStatusDataFilter">
                                        <ul>
                                            <li className="testStatus_student_filter_lable" key={1}><span>Filter:</span></li>
                                            <li className={CurrentStatus=="AllStatus" ? "activeStatus":null} key={2}>
                                                <span className="testStatus_filter_name"
                                                    onClick={() => {
                                                        this.props.FilterStudent_TestStatus_Data(currentPageData,
                                                            "AllStatus")
                                                    }}
                                                >
                                                    <span className="testStatus_filter_tag_name">All Status</span>
                                                </span>
                                            </li>
                                            <li className={(Not_Started)?(CurrentStatus == "Not Started" ? "activeStatus":null):("test_status_tab_grayout")} key={3}>
                                                <span className="testStatus_filter_name"
                                                    onClick={() => {
                                                        Not_Started?this.props.FilterStudent_TestStatus_Data(currentPageData,
                                                            "Not Started"):null
                                                    }}
                                                >
                                                    <span className="testStatus_filter_icon">
                                                    {(Not_Started)?<img src={ts_ic_not_started} style={{width:"14px"}} />:<img src={ts_ic_not_started_gray_out} style={{width:"14px"}} />}
                                                    </span>
                                                    <span className="testStatus_filter_tag_name">Not Started</span>
                                    </span>
                                            </li>
                                            <li className={(In_Progress)?(CurrentStatus == "In Progress" ? "activeStatus":null):("test_status_tab_grayout")} key={4}>
                                                <span className="testStatus_filter_name"
                                                    onClick={() => {
                                                        In_Progress?this.props.FilterStudent_TestStatus_Data(currentPageData,
                                                            "In Progress"):null
                                                    }}
                                                >
                                                    <span className="testStatus_filter_icon">
                                                        {(In_Progress)?<img src={ts_ic_in_progress} />:<img src={ts_ic_in_progress_gray_out} />}
                                                    </span>
                                                    <span className="testStatus_filter_tag_name">In Progress</span>
                                    </span>
                                            </li>
                                            <li  className={(Needs_To_Be_Graded)?(CurrentStatus == "Needs ToBe Graded" ? "activeStatus":null):("test_status_tab_grayout")} key={5}>
                                                <span className="testStatus_filter_name"
                                                    onClick={() => {Needs_To_Be_Graded?
                                                        this.props.FilterStudent_TestStatus_Data(currentPageData,
                                                            "Needs ToBe Graded")
                                                    :null}}
                                                >
                                                    <span className="testStatus_filter_icon">
                                                    {(Needs_To_Be_Graded)?<img src={ts_ic_grading} />:<img src={ts_ic_grading_gray_out} />}
                                                    </span>
                                                    <span className="testStatus_filter_tag_name">Needs to Be Graded</span>
                                    </span>
                                            </li>
                                            <li className={(Complete)?(CurrentStatus == "Complete" ? "activeStatus":null):("test_status_tab_grayout")} key={6}>
                                                <span className="testStatus_filter_name"
                                                    onClick={() => {
                                                        Complete?this.props.FilterStudent_TestStatus_Data(currentPageData,
                                                            "Complete"):null
                                                    }}
                                                >
                                                    <span className="testStatus_filter_icon">
                                                    {(Complete)?<img src={ts_ic_completed} />:<img src={ts_ic_completed_gray_out} />}
                                                    </span>
                                                    <span className="testStatus_filter_tag_name">Complete</span>
                                    </span>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="testStatusDataPrint" onClick={() => {this.props.openPopUpInTestStatusPrint("student",sortingDataPDF,"")}}>
                                        <img src={ic_print}onClick={()=>this.props.trackingUsage("assessmentreports_teststatuspdf:student")}  width="21" />
                                    </div>
                                </div>
                            </div>
                            <div className="testStatus_studentContextMain">
                                <div className="testStatus_studentContextMain_inr">
                                    <div className="testStatus_student_header">
                                        <div className="testStatus_student_header_inr">
                                            <div className="testStatus_student_header_col">
                                                <div className="testStatus_student_col_inr_blk" style={{float:"left"}}>
                                                    <div className={SortStatus == 'assignmentName' ?"testStatus_student_header_col_name testStatus_student_Active_Sort_cls":"testStatus_student_header_col_name"}>
                                                        Test Name {(filteredData !== undefined && filteredData.length > 0)?`(${ filteredData.length})`:null}
                                                    </div>
                                                    <div className="testStatus_student_header_col_sort">
                                                        <span className={SortStatus_Type == "asc" && SortStatus == 'assignmentName' ? "testStatus_summmaryBlock_table_body_head_col_sort_top testStatusActiveTop" : 'testStatus_summmaryBlock_table_body_head_col_sort_top'}
                                                            onClick={() => {
                                                                this.SortTableData('asc', 'assignmentName')
                                                            }}
                                                        >
                                                        </span>
                                                        <span className={SortStatus_Type == "desc" && SortStatus == 'assignmentName' ? "testStatus_summmaryBlock_table_body_head_col_sort_bottom testStatusActiveBottom" : 'testStatus_summmaryBlock_table_body_head_col_sort_bottom'}

                                                            onClick={() => {
                                                                this.SortTableData('desc', 'assignmentName')
                                                            }}
                                                        >
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="testStatus_student_header_col" style={{maxWidth:105}}>
                                                <div className="testStatus_student_header_col_name">
                                                    Test Status
                                    </div>
                                            </div>
                                            <div className="testStatus_student_header_col">
                                                <div className="testStatus_student_header_col_name" style={{textAlign:"left"}}>
                                                    Assignment
                                    </div>
                                            </div>
                                            <div className="testStatus_student_header_col" style={{maxWidth:114}}>
                                            <div className="testStatus_student_col_inr_blk" style={{maxWidth:97}}>
                                                <div className={SortStatus == 'startDate' ?"testStatus_student_header_col_name testStatus_student_Active_Sort_cls":"testStatus_student_header_col_name"}>
                                                    Start Date
                                                </div>
                                                <div className="testStatus_student_header_col_sort">
                                                    <span className={SortStatus_Type == "asc" && SortStatus == 'startDate' ? "testStatus_summmaryBlock_table_body_head_col_sort_top testStatusActiveTop" : 'testStatus_summmaryBlock_table_body_head_col_sort_top'}
                                                        onClick={() => {
                                                            this.SortTableData('asc', 'startDate')
                                                        }}
                                                    >
                                                    </span>
                                                    <span className={SortStatus_Type == "desc" && SortStatus == 'startDate' ? "testStatus_summmaryBlock_table_body_head_col_sort_bottom testStatusActiveBottom" : 'testStatus_summmaryBlock_table_body_head_col_sort_bottom'}
                                                        onClick={() => {
                                                            this.SortTableData('desc', 'startDate')
                                                        }}
                                                    >
                                                    </span>
                                                </div>
                                                </div>
                                            </div>
                                            
                                            <div className="testStatus_student_header_col" style={{maxWidth:114}}>
                                                <div className="testStatus_student_col_inr_blk" style={{maxWidth:90}}>
                                                <div className={(SortStatus == 'dueDate')?"testStatus_student_header_col_name testStatus_student_Active_Sort_cls":"testStatus_student_header_col_name"}>
                                                    Due Date
                                                </div>
                                                <div className="testStatus_student_header_col_sort">
                                                    <span className={SortStatus_Type == "asc" && SortStatus == 'dueDate' ? "testStatus_summmaryBlock_table_body_head_col_sort_top testStatusActiveTop" : 'testStatus_summmaryBlock_table_body_head_col_sort_top'}
                                                        onClick={() => {
                                                            this.SortTableData('asc', 'dueDate')
                                                        }}
                                                    >
                                                    </span>
                                                    <span className={SortStatus_Type == "desc" && SortStatus == 'dueDate' ? "testStatus_summmaryBlock_table_body_head_col_sort_bottom testStatusActiveBottom" : 'testStatus_summmaryBlock_table_body_head_col_sort_bottom'}
                                                        onClick={() => {
                                                            this.SortTableData('desc', 'dueDate')
                                                        }}
                                                    >
                                                    </span>
                                                </div>
                                                </div>
                                            </div>
                                            <div className="testStatus_student_header_col" style={{maxWidth:110}}>
                                                <div className="testStatus_student_col_inr_blk">
                                                    <div className={SortStatus == 'submissionDate' ?"testStatus_student_header_col_name testStatus_student_Active_Sort_cls":"testStatus_student_header_col_name"}>
                                                    Submit Date
                                                    </div>
                                                    <div className="testStatus_student_header_col_sort">
                                                        <span className={SortStatus_Type == "asc" && SortStatus == 'submissionDate' ? "testStatus_summmaryBlock_table_body_head_col_sort_top testStatusActiveTop" : 'testStatus_summmaryBlock_table_body_head_col_sort_top'}
                                                            onClick={() => {
                                                                this.SortTableData('asc', 'submissionDate')
                                                            }}
                                                        >
                                                        </span>
                                                        <span className={SortStatus_Type == "desc" && SortStatus == 'submissionDate' ? "testStatus_summmaryBlock_table_body_head_col_sort_bottom testStatusActiveBottom" : 'testStatus_summmaryBlock_table_body_head_col_sort_bottom'}
                                                            onClick={() => {
                                                                this.SortTableData('desc', 'submissionDate')
                                                            }}
                                                        >
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="testStatus_student_body">
                                        <div className="testStatus_student_body_inr">

                                            {/* {List != undefined ? currentPageData.length > 0 ? ListItems(currentPageData,Nav,this.props.ContextHeader):"No Data Available for current selection":null} */}
                                            {List != undefined ? currentPageData.length > 0 ? 
                                         
                                            currentPageData.map(item =>

                                                <div className={(item.testStatus === "Needs ToBe Graded" || item.testStatus === "Complete")?"testStatus_student_body_single_row teststatus_sa_da_hand_icon":(Nav.student && (item.testStatus === "Not Started" || item.testStatus === "In Progress") && ( LoginDetails.UserRole === "TEACHER" ))?"testStatus_student_body_single_row teststatus_sa_da_hand_icon":"testStatus_student_body_single_row teststatus_sa_da_arrow_icon"} onClick={() => {
                                                  
                                                    if (Nav.student) {
                                                        switch (item.testStatus) {
                                                
                                                            case 'Not Started':
                                                                if( LoginDetails.UserRole === "TEACHER" ){
                                                                    window.open(domain_url + '#assignments/' + item.assignmentID)
                                                                }
                                                                break;
                                                            case 'In Progress':
                                                                if( LoginDetails.UserRole === "TEACHER" ){
                                                                    window.open(domain_url + '#assignments/' + item.assignmentID)
                                                                }
                                                                break;
                                                            case 'Needs ToBe Graded':
                                                                window.open(domain_url + '#grading/student-view/' + rosterData.SelectedClass.id + '/' + item.testAssignmentId)
                                                                break;
                                                            case 'Complete':
                                                                this.NavToSingleTest('st_analysis_from_Teststatus', item)
                                                
                                                                break;
                                                            default:
                                                                break;
                                                
                                                        }
                                                
                                                    }
                                                   
                                                
                                                }}>
                                                    <div className="testStatus_student_body_col">
                                                        <div className="testStatus_student_body_col_name">
                                                            {item.componentTitle == null || item.componentTitle == "null" ? "-":item.componentTitle}
                                                        </div>
                                                    </div>
                                                    <div className="testStatus_student_body_col" style={{maxWidth:105}}>
                                                        <div className={"testStatus_student_body_col_name " + CheckStatus(item)}>
                                        
                                                        </div>
                                                    </div>
                                                    <div className="testStatus_student_body_col" style={{textAlign:"left"}}>
                                                        <div className="testStatus_student_body_col_name">
                                                            {item.assignmentName == null || item.assignmentName == "null" ? "-":item.assignmentName}
                                                        </div>
                                                    </div>
                                                    <div className="testStatus_student_body_col" style={{maxWidth:114}}>
                                                        <div className="testStatus_student_body_col_name">
                                                        {item.startDate == null || item.startDate == "null" ? "-":((DISPLAY_LOCAL_TIME_IN_UI === true)?convertUTCDateToLocalDate(item.startDate,item.startTime):item.startDate)}
                                                        </div>
                                                    </div>
                                                   <div className="testStatus_student_body_col" style={{maxWidth:114}}>
                                                        <div className="testStatus_student_body_col_name">

                                                        {item.dueDate == null || item.dueDate == "null" ? "-":userTimeZoneDate(item.dueDate,item.dueTime)}

                                                        </div>
                                                    </div>
                                                    <div className="testStatus_student_body_col" style={{maxWidth:114}}>
                                                        <div className="testStatus_student_body_col_name">
                                                            {(item.testStatus == "Not Started") || (item.testStatus == "In Progress") ? "NA":(item.submissionDate == null || item.submissionDate == "null") ? "-":((DISPLAY_LOCAL_TIME_IN_UI === true)?convertUTCDateToLocalDate(item.submissionDate,"00:00:00"):item.submissionDate)}
                                                        </div>
                                                    </div>
                                                </div>
                                        
                                            ) 
                                            :"No Data Available for current selection":null}

                                        </div>
                                    </div>
                                </div>
                                {TestStatus_Pagination(this.props.TestStatusReducer.Student.Pagination, this.props.Pagination_Bubble_Selection, this.props.Pagination_Navigate_Selection, LoaderEnable)}

                            </div>

                        </div>
                    }
                    </div>
               
                </div>
    }
    SortTableData(sortType, sortOn) {

        let Nav = this.props.NavigationByHeaderSelection;
        this.props.SortTestStatusSummaryData(sortType, sortOn, 'student', Nav, this.props.TestStatusReducer)

    }

    OnStatusSelection(selectedItem, selectedStatus) {
        let Nav = this.props.NavigationByHeaderSelection;

        this.props.OnTestStatusSelection(selectedItem, selectedStatus, 'student', Nav)

    }
    SortDetailsData(sortType, sortOn) {
        let Nav = this.props.NavigationByHeaderSelection;

        this.props.SortTestStatusDetailsData(sortType, sortOn, 'student', Nav, this.props.TestStatusReducer)
    }
}

const mapStateToProps = ({ StudentReports, Reports, Universal, Authentication, TestStatusReducer,DateTabReducer,TestStatusPrintReducer }) => {
    const { Class, Student, StandardPerformance_Overview, StudentsListTable } = Reports;
    const { S_StandardPerformance_Overview, S_ToolTipData, S_ApiCalls } = StudentReports;
    const { LoginDetails } = Authentication;
    const { ContextHeader, ApiCalls, UniversalSelecter, UserScreenWidth, NavigationByHeaderSelection,currentTermID } = Universal
    const {studentTestStatusPrint} = TestStatusPrintReducer
    return {
        Class, Student, LoginDetails, StandardPerformance_Overview, UserScreenWidth,
        ContextHeader, ApiCalls, UniversalSelecter, StudentsListTable,
        S_StandardPerformance_Overview, S_ToolTipData, S_ApiCalls, NavigationByHeaderSelection,
        TestStatusReducer,DateTabReducer,studentTestStatusPrint,currentTermID
    };
}

export default connect(mapStateToProps, {
    Get_TestStatusDetailsData, SortTestStatusDetailsData, SortTestStatusSummaryData, FilterStudent_TestStatus_Data, Pagination_Bubble_Selection, Pagination_Navigate_Selection, openPopUpInTestStatusPrint,handleStudentFilterInTestStatus,SaveContextSelection,trackingUsage
})(s_TestStatus);

// const ListItems = (DataArray,Nav,ContextHeader) => {

//     return DataArray.map(item =>

//         <div className="testStatus_student_body_single_row" onClick={() => linkToReport(item,Nav,ContextHeader)}>
//             <div className="testStatus_student_body_col">
//                 <div className="testStatus_student_body_col_name">
//                     {item.componentTitle == null || item.componentTitle == "null" ? "-":item.componentTitle}
//                 </div>
//             </div>
//             <div className="testStatus_student_body_col" style={{maxWidth:105}}>
//                 <div className={"testStatus_student_body_col_name " + CheckStatus(item)}>

//                 </div>
//             </div>
//             <div className="testStatus_student_body_col" style={{textAlign:"left"}}>
//                 <div className="testStatus_student_body_col_name">
//                     {item.assignmentName == null || item.assignmentName == "null" ? "-":item.assignmentName}
//                 </div>
//             </div>
//             <div className="testStatus_student_body_col" style={{maxWidth:114}}>
//                 <div className="testStatus_student_body_col_name">
//                     {item.startDate == null || item.startDate == "null" ? "-":item.startDate}
//                 </div>
//             </div>
//            <div className="testStatus_student_body_col" style={{maxWidth:114}}>
//                 <div className="testStatus_student_body_col_name">
//                     {item.dueDate == null || item.dueDate == "null" ? "-":item.dueDate}
//                 </div>
//             </div>
//             <div className="testStatus_student_body_col" style={{maxWidth:114}}>
//                 <div className="testStatus_student_body_col_name">
//                     {(item.testStatus == "Not Started") || (item.testStatus == "In Progress") ? "NA":(item.submissionDate == null || item.submissionDate == "null") ? "-":item.submissionDate}
//                 </div>
//             </div>
//         </div>

//     )

// }

export function CheckStatus(item) {

    let status;

    if(item.testStatus == "Not Started"){
        status = "not-started"
    }else if(item.testStatus == "Needs ToBe Graded"){
        status = "need-tobe-graded"
    }else if(item.testStatus == "In Progress"){
        status = "in-progress"
    }else{
        status = "complete"
    }

    switch (status) {
        case 'not-started':
            return "statusIcon_not_started";
        case 'in-progress':
            return "statusIcon_in_progress";
        case 'need-tobe-graded':
            return "statusIcon_need_to_be_graded";
        case 'complete':
            return "statusIcon_completed";
        default:
            return "not-applied-anything"
    }
}



