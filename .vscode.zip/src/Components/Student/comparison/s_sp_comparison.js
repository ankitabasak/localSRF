import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    Comparison_Popup
} from '../../../Redux_Actions/ComparisonActions';

import Std_Perf_ComparisonPopup from "../../../Utils/Comparison/Std_Perf_ComparisonPopup";
import Std_Perf_ComparisonPage from "../../../Utils/Comparison/Std_Perf_ComparisonPage";
import Compare_Comp_Apis from '../../../Utils/Comparison/Compare_Comp_Apis';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class s_sp_comparison extends Component {

    constructor(props) {
        super(props);
    }
    componentDidMount(){
        this.props.trackingUsage("assessmentreports_standardperformancecomparison:student");
    }

    render() {

        const studentComparison = this.props.studentComparison.Std_Comparison

        const popupFilter = studentComparison.PopupFilter;
        let Nav = this.props.NavigationByHeaderSelection;
        let fromNavContext = "student";
        return (
            <div>
                <Compare_Comp_Apis
                    comparisonData={studentComparison}
                    fromContext={fromNavContext}
                    fromtab="std_performance"
                    popupData={popupFilter}
                />
                {popupFilter.openPopup && !this.props.CompareDeepLink_Enabled
                    // && (popupFilter.Strands_And_Standards.Original_List_temp.length != 0)
                    ? <Std_Perf_ComparisonPopup
                        comparisonData={studentComparison}
                        fromContext={fromNavContext}
                        fromtab="std_performance"
                        popupData={popupFilter} /> : null}
                {studentComparison.ComparisonData.Operational_Data != null ? <Std_Perf_ComparisonPage fromContext={fromNavContext} fromtab="std_performance" comparisonData={studentComparison} /> : null}

            </div>
        )
    }
}

const MapStateToProps = ({ Universal, Authentication, ComparisonReducer, StudentReports }) => {

    const { ContextHeader, NavigationByHeaderSelection } = Universal

    const { studentComparison, CompareDeepLink_Enabled } = ComparisonReducer

    const { S_StandardPerformance_Overview } = StudentReports;

    return {
        Universal, Authentication, ContextHeader, studentComparison, NavigationByHeaderSelection, S_StandardPerformance_Overview,
        CompareDeepLink_Enabled
    }
}

const MapActionToProps = {
    Comparison_Popup,trackingUsage
}

export default connect(MapStateToProps, MapActionToProps)(s_sp_comparison);

// Custom functions to perform some actions

export function SelectedTestList(testsList) {
    let ComponentsList = [];
    testsList.map((test, i) => {
        // if (test.productId == SelectedProductID) {
        ComponentsList.push(test.componentCode);
        //}
    })
    return ComponentsList;
}