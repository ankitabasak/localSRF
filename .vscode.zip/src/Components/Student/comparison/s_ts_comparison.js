import React, { Component } from "react";
import { connect } from "react-redux";
import {} from "../../../Redux_Actions/ComparisonActions";

import LoadingScreen from "../../../Utils/LoadingScreen/LoadingScreen";
import {
  GetIds_of_Each_Object_In_The_Array,
  AllClassesList,
  GetStudentIdsFor_compare,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compareOfGrade,
} from "../../ReusableComponents/AllReusableFunctions";

import { Get_Cs_ComparisionTab_Data } from "../../../Redux_Actions/ComparisonActions";
import TestScore_ComparisonPage from "../../../Utils/Comparison/TestScore_ComparisonPage";
import { GetTestScore_CompareData } from "../../../services/compare.service";
import { trackingUsage } from "../../../Redux_Actions/AuthenticationAction";

class s_ts_comparison extends Component {
  constructor(props) {
    super(props);
  }

  componentDidUpdate() {
    // this.CallApi();
    GetTestScore_CompareData(this.props, "student");
  }

  componentDidMount() {
    // this.CallApi();
    GetTestScore_CompareData(this.props, "student");
    this.props.trackingUsage("assessmentreports_testscorescomparison:student");
  }

  // CallApi(props) {
  //     let Apicall = this.props.studentComparison.Ts_Comparison.ApiCalls.getTestscore;
  //     if ((Apicall || props) && (this.props.ContextHeader.TestTab.TestList != undefined)) {
  //         let Token = this.props.LoginDetails.JWTToken
  //         let C_RosterData = this.props.ContextHeader.Roster_Tab;
  //         let Selected_List = this.props.ContextHeader.TestTab.TestList.filter(item => item.check)
  //         let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
  //         let AllClassesList_ = AllClassesList(C_RosterData.ClassList);
  //         let AllStudentsList = AllClassesList(C_RosterData.StudentsList);

  //         // let SchoolStds = this.props.LastActiveUniversalProps.School_Report.StudentList;

  //         // let Compare_Std_Ids = SchoolStds == undefined || SchoolStds == null ? []: Get_Ids_Of_Student_List(SchoolStds.filter(item => item.check))
  //         // if (Compare_Std_Ids.length == 0) {
  //         //     let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
  //         //     Compare_Std_Ids = GetStudentIdsFor_compare(Grades)
  //         // }
  //         let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
  //         let selectedGradeForCompare = this.props.ContextHeader.Roster_Tab.selectedRosterGrade
  //         let Compare_Std_Ids = GetStudentIdsFor_compareOfGrade(selectedGradeForCompare, Grades)

  //         let cs_ids=this.props.ContextHeader.Roster_Tab.StudentData_cls_ids;
  //         //    AllClassesList_
  //         //    cs_ids= cs_ids.length==0? [C_RosterData.SelectedClass.id] :cs_ids;
  //         let Request = {
  //             "classIds": cs_ids ,
  //             "schoolId": C_RosterData.SelectedSchool.id,
  //             "classId": C_RosterData.SelectedClass.id,
  //             "districtId": C_RosterData.SelectedDistrict.id,
  //             "studentId": C_RosterData.SelectedStudent.id,
  //             "studentIds": AllStudentsList,
  //             "componentCodeList": SelectedTests,
  //             "startDate": this.props.ContextHeader.Date_Tab.Report_termStartDate,
  //             "endDate": this.props.ContextHeader.Date_Tab.Report_termEndDate,
  //             "compareStudentIds": Compare_Std_Ids
  //         }
  //         if (Request.componentCodeList.length > 0) {
  //             this.props.Get_Cs_ComparisionTab_Data('student', 'testscores', Token, Request);
  //         }
  //     }
  // }
  render() {
    let Ts_Comparison_props = this.props.studentComparison.Ts_Comparison;
    let Nav = this.props.NavigationByHeaderSelection;
    let fromNavContext = "student";
    return (
      <div className="bec_compare_tab_main">
        {Ts_Comparison_props.ApiCalls.loadingComparison_Data ||
        Ts_Comparison_props.ComparisonData.Operational_Data.length == 0 ? (
          <LoadingScreen />
        ) : (
          <TestScore_ComparisonPage
            fromContext={fromNavContext}
            fromtab="testscores"
            comparisonData={Ts_Comparison_props}
          />
        )}
      </div>
    );
  }
}

const MapStateToProps = ({
  Universal,
  Authentication,
  ComparisonReducer,
  Reports,
  LastActiveUniversalProps,DateTabReducer
}) => {
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    NavigationByHeaderSelection,
    ApiCalls,
    currentTermID,UniversalSelecter
  } = Universal;
  const { studentComparison } = ComparisonReducer;
  const { StandardPerformance_Overview } = Reports;
  const { Context_DateTab } = DateTabReducer;
  return {
    Universal,
    LoginDetails,
    ContextHeader,
    studentComparison,
    NavigationByHeaderSelection,
    StandardPerformance_Overview,
    ApiCalls,
    LastActiveUniversalProps,
    currentTermID,
    UniversalSelecter,
    Context_DateTab
  };
};

export default connect(MapStateToProps, {
  Get_Cs_ComparisionTab_Data,trackingUsage
})(s_ts_comparison);
