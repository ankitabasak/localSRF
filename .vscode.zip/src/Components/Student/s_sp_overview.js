import React, { Component } from 'react';
import { connect } from "react-redux";
import Strands_Assessment from '../Standard_Performance/Strands_Assessment';
import { convertToNumberGrade, GetIds_of_Each_Object_In_The_Array, LineChartInput_Params, AllClassesList } from '../ReusableComponents/AllReusableFunctions';
import { PerformanceOTchartHeader } from '../class/c_sp_overview';
import CompareCheckBoxes from '../../Utils/CompareCheckBoxes';
import ReactHtmlParser from 'react-html-parser';

import info_icon from '../../../public/images/info_icon.svg';
import { Get_Student_StandardPerformance_Table, OpenOrCloseNoteIn_S_SP_OT, OpenOrCloseTooltipIn_S_SP_OT, CompareCheckBox_Option_In_Student, EnableOrDisableLineColorIn_S_SP_LC, getTestAssessmentMaxCountOfStudent, getGradeListOfStudent, chnagestudentObjAPICallFlag } from '../../Redux_Actions/Student_ReportsAction';
import LoadingScreen from '../../Utils/LoadingScreen/LoadingScreen';
import PrintLineChart from '../ReusableComponents/PDFReports/PrintLineChart';
import IR_Bulb from '../../Utils/IR_Bulb';
import { Sp_OverView_Grades, Sp_Overview_StrandsData } from '../../services/student.service';
import { Disable_AutoSelect_Std_Pref_LeftView, SPOT_PDF_ENABLE } from '../../Utils/globalVars';
import SpotPrint from '../../Utils/SpotPDF/SpotPrint'
import SpotPDF from '../ReusableComponents/PDFReports/SpotPDF';
import Make_A_Selection_msg from '../../Utils/Make_A_Selection';
import { trackingUsage } from '../../Redux_Actions/AuthenticationAction';
class s_sp_overview extends Component {
    constructor(props) {
        super(props);
        this.InfoPopUp = {},
            this.i_span_ref = {},
            this.InfoTooltipPopUp = {},
            this.i_span_tooltip_ref = {},
            this.state = {}
        this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
        this.SelectedCheckBoxOption = this.SelectedCheckBoxOption.bind(this);
        this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
        this.studentObjAPICallFlagOff = this.studentObjAPICallFlagOff.bind(this);


    }

    /**
     * Addded Event Listener For Mouse Click
     */

    componentDidMount() {

        document.addEventListener("mousedown", this.handleClickOutside_info);
        this.props.trackingUsage("assessmentreports_standardperformanceoverview:student")
    }
    /**
        * Removing Event Listener For Mouse Click
        */
    componentWillUnmount() {

        document.removeEventListener("mousedown", this.handleClickOutside_info);
    }

    /**
     * 
     * @param {Object} event 
     * triggers when click on outside of info div
     */
    handleClickOutside_info(event) {
        if (event.target == null || event.target == undefined) {
            // this.handleMouseOut(this.props.ToolTipData);
        } else if (this.props.S_StandardPerformance_Overview.open_Note_in_SP_Overview) {
            if (this.InfoPopUp !== null && this.InfoPopUp !== undefined) {
                let isitemexists = this.InfoPopUp.contains(event.target);
                let is_IExist = this.i_span_ref.contains(event.target)
                let ToolTipsRefsExists;
                if ((isitemexists == undefined || isitemexists == null || isitemexists == false) && (is_IExist == undefined || is_IExist == null || is_IExist == false)) {
                    // this.setState({ show_P_Overtime_Info: false })
                    this.props.OpenOrCloseNoteIn_S_SP_OT(false)
                }
            }
        } else if (this.props.S_StandardPerformance_Overview.open_Tooltip_in_SP_Overview) {
            if (this.InfoTooltipPopUp !== null && this.InfoTooltipPopUp !== undefined) {
                let isitemexists = this.InfoTooltipPopUp.contains(event.target);
                let is_IExist = this.i_span_tooltip_ref.contains(event.target)
                let ToolTipsRefsExists;
                if ((isitemexists == undefined || isitemexists == null || isitemexists == false) && (is_IExist == undefined || is_IExist == null || is_IExist == false)) {
                    this.props.OpenOrCloseTooltipIn_S_SP_OT(false, "S_performance")
                }
            }
        }
    }

    componentWillMount() {
        Sp_OverView_Grades(this.props)
        Sp_Overview_StrandsData(this.props);
    }
    componentDidUpdate() {
        Sp_OverView_Grades(this.props)
        Sp_Overview_StrandsData(this.props);
    }

    /**
     * 
     * @param {String} SelectedOption 
     * @param {Boolean} check 
     * when user selects check box.
     */
    SelectedCheckBoxOption(SelectedOption, check) {
        this.props.CompareCheckBox_Option_In_Student(SelectedOption, check)
    }

    /**
* when user click on checbox comp label, then it will execute
*/
    ClickOnLabelName(labelName, checkOrUncheck) {

        this.props.EnableOrDisableLineColorIn_S_SP_LC(labelName, checkOrUncheck);
    }
    studentObjAPICallFlagOff() {

        this.props.chnagestudentObjAPICallFlag();
    }



    render() {

        let Standard_performance_details = this.props.S_StandardPerformance_Overview;
        let PerformanceFilter = this.props.S_StandardPerformance_Overview.StandardPerformanceFilter;
        let selectedTestAssessment;
        let GradeObj = PerformanceFilter.TestGrade.selectedTestgrade
        let selectedTestGrade = GradeObj == '' || GradeObj == null ? '' : GradeObj.grade;
        selectedTestAssessment = PerformanceFilter.TestAssessment.selectedTestAssessment;
        let ActualListForGraph = this.props.S_StandardPerformance_Overview.ActualLineChartData;
        let Pagination = this.props.S_StandardPerformance_Overview.LineChart_Pagination;
        let Pagination_Start = Pagination.Chart_Page_Count_Start;
        let Pagination_End = Pagination.Chart_Page_Count_End;
        let ToolTipData = this.props.S_StandardPerformance_Overview.Strands_S_ToolTipData;
        let StrandReducer = this.props.S_StandardPerformance_Overview;
        let loading_on_strands_Lc = this.props.S_ApiCalls.loading_on_strandsLC;

        let Nav = this.props.NavigationByHeaderSelection;

        let TotalQuestions = ActualListForGraph.reduce((initial, item) => initial + parseInt(item.totalQuestions), 0);

        let ClassChecked = Standard_performance_details.checkClass; // for class instance we no need this so by default we are sending false.
        let SchoolChecked = Standard_performance_details.checkSchool;
        let DistrictChecked = Standard_performance_details.checkDistrict;
        let LastChecked_CB = Standard_performance_details.lastSelectedCheckBox;
        let ApiCalldetails = this.props.S_ApiCalls;
        const { XAxis_Params, YAxis_Params, DatatPointParams, tooltipParams, data,
            margin, width, height, Ipadwidth, Ipadheight
        } = LineChartInput_Params(ActualListForGraph, Pagination_Start, Pagination_End, 's_sp_overview');

        let U_Api = this.props.ApiCalls;

        //IR related stuff

        const { selectedstandardObject, StrandNameOfSelectedStandard } = this.props.S_StandardPerformance_Overview ? this.props.S_StandardPerformance_Overview : "";
        const setId = (selectedstandardObject !== null && selectedstandardObject !== undefined) ? selectedstandardObject.setId : "";
        let strandNames = (StrandNameOfSelectedStandard !== null && StrandNameOfSelectedStandard !== '') ? (setId + "~" + StrandNameOfSelectedStandard) : "";
        let standardNames = (selectedstandardObject !== null && selectedstandardObject !== undefined) ? selectedstandardObject.standardId : "";
        let Grade = selectedTestGrade ? convertToNumberGrade(selectedTestGrade) : "";

        let AccessToken = this.props.LoginDetails.JWTToken;
        let Context_Header = this.props.ContextHeader;
        let Req_Payload = {
            "classId": Context_Header.Roster_Tab.SelectedClass.id,
            "schoolId": Context_Header.Roster_Tab.SelectedSchool.id,
            "rosterGrade": Context_Header.Roster_Tab.selectedRosterGrade,
            "startDate": Context_Header.Date_Tab.Report_termStartDate,
            "endDate": Context_Header.Date_Tab.Report_termEndDate,
            "districtId": Context_Header.DistrictId,
            "isPastDistrictTerm": Context_Header.Date_Tab.isPastDistrictTerm,
            "termId": Context_Header.Date_Tab.selectedTermId,
            "currentTermId": this.props.currentTermID
        }

        let SpotPrintReducer = this.props.studentSPOTPrint;

        let need_To_Select_Strad_Or_Standard = strandNames == "" &&
            !(ApiCalldetails.getLineChartOfStrands) && !(ApiCalldetails.loading_on_strands_table)
            && Disable_AutoSelect_Std_Pref_LeftView


        if (!need_To_Select_Strad_Or_Standard && this.props.ApiCalls_Reports.STUDENT_OBJ_API) {
            this.studentObjAPICallFlagOff()
        }
        return (
            <div className="main-middle-block" style={{ position: "relative" }}>
                <div className="main-middle-block-inr">


                    <div className="bec-standards-overview-left">
                        {U_Api.loader_On_Sts_Grades || ((U_Api.loadingFor == 'datetab' || U_Api.loadingFor == "tests") && U_Api.get_S_Grades_Alias) ||
                            (ApiCalldetails.loading_on_strands_table && (Nav.student)
                                // && !U_Api.load_only_strands_inStd
                            )
                            ? <LoadingScreen /> :
                            <Strands_Assessment stranddetails={Standard_performance_details} Apicalls={ApiCalldetails} />}
                        {/* right block start */}
                    </div>

                    <div className="bec-standards-overview-right">
                        <div className="col-sm-12 float-left m-0 p-0">
                            <div className="standard-widget active-widget">
                                <div className="standard-widget performance_overtime_block active-widget" >
                                    <div
                                        className="sidewidget-header">
                                        <span className="sidewidget-header-icon"><i className="material-icons">show_chart </i></span>
                                        <span className="sidewidget-header-title">Performance Over Time</span>
                                        <span onClick={() => this.props.OpenOrCloseTooltipIn_S_SP_OT(true, "S_performance")}

                                            className="infoIconBlock">
                                            <span ref={(refs) => refs == null ? null : this.i_span_tooltip_ref = refs}><img src={info_icon} style={{ marginLeft: "4px", marginTop: "5px", cursor: "pointer" }} /></span>
                                            {Standard_performance_details.open_Tooltip_in_SP_Overview ?
                                                <div className="infoIconTooltipBlock_POT">
                                                    <div
                                                        ref={(InfoTooltipPopUp) => InfoTooltipPopUp !== null ? this.InfoTooltipPopUp = InfoTooltipPopUp : null}
                                                        className="infoIconTooltipBlockInr">
                                                        <span className="infoIconTooltipBlockArrow_POT"></span>
                                                        <b>Note:</b> The average score listed in the line graph below is calculated from all data available for each assessment based on the context selected. It does not assume the cohort of students remains the same across the assessments listed.
                                            </div>
                                                </div>
                                                : null}
                                        </span>
                                    </div>
                                    <div className="widget-base-block mx-auto">
                                        {/* Right block */}
                                        {need_To_Select_Strad_Or_Standard ?
                                            <Make_A_Selection_msg
                                                message="Make a selection in the table to see details."
                                            />
                                            : ApiCalldetails.loading_on_strandsLC == false && Standard_performance_details.ActualList.length !== 0 ?
                                                <div className="widget-base-block-inr">
                                                    <div className="widget-base-title-block">
                                                        <div className="float-left widget-base-block-title text-center">
                                                            <span style={{ float: "right", marginLeft: "10px", cursor: 'pointer' }}>

                                                                {SPOT_PDF_ENABLE === "true" ? <SpotPrint /> : <PrintLineChart
                                                                    data={data} XAxis_Params={XAxis_Params}
                                                                    YAxis_Params={YAxis_Params}
                                                                    DataSetParam={DatatPointParams}
                                                                    // TooltipParams={tooltipParams}
                                                                    selectedTestAssessment={selectedTestAssessment}
                                                                    selectedTestGrade={selectedTestGrade}
                                                                    TooltipParams={tooltipParams}
                                                                    ToolTipData={ToolTipData}
                                                                    ClassChecked={ClassChecked}
                                                                    SchoolChecked={SchoolChecked}
                                                                    DistrictChecked={DistrictChecked}
                                                                    LastChecked_CB={LastChecked_CB}
                                                                    Navselection={this.props.NavigationByHeaderSelection.class}
                                                                    TS_Overtime={Standard_performance_details}
                                                                    CheckeThis={this.SelectedCheckBoxOption}
                                                                    ClickOnLabel={this.ClickOnLabelName}
                                                                    standardName={StrandReducer.StrandNameOfSelectedStandard}
                                                                    Pagination={Pagination}
                                                                    totalAverageScore={StrandReducer.selectedStandarAvg}
                                                                    totalQuestions={TotalQuestions}
                                                                    strandName={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDef}
                                                                    strandDetailsDesc={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardName}
                                                                    strandDescription={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDesc} />}
                                                            </span>
                                                            {(SPOT_PDF_ENABLE === "true") && (SpotPrintReducer.performanceOvertimeData.triggerPDF === true) ? <SpotPDF
                                                                data={ActualListForGraph} XAxis_Params={XAxis_Params}
                                                                YAxis_Params={YAxis_Params}
                                                                DataSetParam={DatatPointParams}
                                                                // TooltipParams={tooltipParams}
                                                                selectedTestAssessment={selectedTestAssessment}
                                                                selectedTestGrade={selectedTestGrade}
                                                                TooltipParams={tooltipParams}
                                                                ToolTipData={ToolTipData}
                                                                ClassChecked={ClassChecked}
                                                                SchoolChecked={SchoolChecked}
                                                                DistrictChecked={DistrictChecked}
                                                                LastChecked_CB={LastChecked_CB}
                                                                Navselection={this.props.NavigationByHeaderSelection.class}
                                                                TS_Overtime={Standard_performance_details}
                                                                CheckeThis={this.SelectedCheckBoxOption}
                                                                ClickOnLabel={this.ClickOnLabelName}
                                                                standardName={StrandReducer.StrandNameOfSelectedStandard}
                                                                Pagination={Pagination}
                                                                totalAverageScore={StrandReducer.selectedStandarAvg}
                                                                totalQuestions={TotalQuestions}
                                                                strandName={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDef}
                                                                strandDetailsDesc={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardName}
                                                                strandDescription={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDesc}
                                                                responseData={SpotPrintReducer.performanceOvertimeData.responseData}
                                                            /> : null}
                                                            <span>{StrandReducer.StrandNameOfSelectedStandard}</span>
                                                        </div>

                                                        {StrandReducer.selectedstandardObject == null || Object.keys(StrandReducer.selectedstandardObject).length === 0 ? null :
                                                            <div className="float-left widget-base-block-title text-center">

                                                                <span style={{ float: "left", textAlign: "left", width: "93%" }}>{StrandReducer.selectedstandardObject.standardName}: {ReactHtmlParser(StrandReducer.selectedstandardObject.standardDesc)}</span>
                                                                <span style={{ float: "left", width: "6%", position: "relative", left: "6px" }}><IR_Bulb ir_bulb_icon={this.props.LoginDetails.ReportingAccessParam} display_position="left" view={setId} grade={Grade} strand={strandNames} standard={standardNames} /></span>
                                                            </div>}

                                                        <div className="widget-base-sub-title text-center">
                                                            <span>Average Score: {StrandReducer.selectedStandarAvg}% based on {TotalQuestions} questions
                        <span onClick={() => this.props.OpenOrCloseNoteIn_S_SP_OT(true)}

                                                                    className="infoIconBlock">
                                                                    <span ref={(refs) => refs == null ? null : this.i_span_ref = refs} ><img src={info_icon} style={{ marginLeft: "4px", marginTop: "-4px", cursor: "pointer" }} /></span>
                                                                    {Standard_performance_details.open_Note_in_SP_Overview ?
                                                                        <div className="infoIconTooltipBlock">
                                                                            <div
                                                                                ref={(InfoPopUp) => InfoPopUp !== null ? this.InfoPopUp = InfoPopUp : null}
                                                                                className="infoIconTooltipBlockInr">
                                                                                <span className="infoIconTooltipBlockArrow"></span>
                                                                                <b>Note:</b> Average Score for all standards reports equals (earned points/total points)*100
                                            </div>
                                                                        </div>
                                                                        : null}
                                                                </span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <CompareCheckBoxes Navselection={this.props.NavigationByHeaderSelection.class}
                                                        TS_Overtime={Standard_performance_details}
                                                        CheckeThis={this.SelectedCheckBoxOption}
                                                        ClickOnLabel={this.ClickOnLabelName}
                                                        lastcheckedlabel={LastChecked_CB} />
                                                    {PerformanceOTchartHeader(true, ActualListForGraph, Pagination, this.props.UserScreenWidth, ToolTipData, StrandReducer, 's_sp_overview', ClassChecked, SchoolChecked, DistrictChecked, LastChecked_CB)}
                                                </div> : <LoadingScreen />}
                                    </div >
                                </div>

                                {/* {PerformanceOTchartHeader(true, ActualListForGraph, Pagination, this.props.UserScreenWidth, ToolTipData, StrandReducer, 's_sp_overview')} */}

                            </div>

                        </div>
                    </div>
                </div>
            </div>
            // </div >

        );

    }
}

const mapStateToProps = ({ StudentReports, Reports, Universal, Authentication, SpotPrintReducer,DateTabReducer }) => {
    const { Class, Student, StandardPerformance_Overview, StudentsListTable, ApiCalls_Reports } = Reports;
    const { S_StandardPerformance_Overview, S_ToolTipData, S_ApiCalls } = StudentReports;
    const { LoginDetails } = Authentication;
    const { ContextHeader, ApiCalls, UniversalSelecter, UserScreenWidth, NavigationByHeaderSelection,currentTermID } = Universal
    const { studentSPOTPrint } = SpotPrintReducer;
    const { Context_DateTab } = DateTabReducer;
    return {
        ApiCalls_Reports, Class, Student, LoginDetails, StandardPerformance_Overview, UserScreenWidth,
        ContextHeader, ApiCalls, UniversalSelecter, StudentsListTable,
        S_StandardPerformance_Overview, S_ToolTipData, S_ApiCalls, NavigationByHeaderSelection, studentSPOTPrint,currentTermID,Context_DateTab

    };
}

export default connect(mapStateToProps, {
    Get_Student_StandardPerformance_Table, chnagestudentObjAPICallFlag, OpenOrCloseNoteIn_S_SP_OT, OpenOrCloseTooltipIn_S_SP_OT,
    CompareCheckBox_Option_In_Student, EnableOrDisableLineColorIn_S_SP_LC,
    getTestAssessmentMaxCountOfStudent, getGradeListOfStudent,trackingUsage
})(s_sp_overview);
