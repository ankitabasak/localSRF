import React, { Component } from 'react';
import { connect } from 'react-redux';

import ST_analysisPage from "../../../Utils/st_analysis/ST_analysisPage";
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class s_st_analysis extends Component {

    componentDidMount(){
        this.props.trackingUsage("assessmentreports_singletestanalysis:student");
    }

    render() { 
        let singleTestAnalysisData = this.props.student_TestAnalysis
        let fromContext = 'student'
        return (
            <ST_analysisPage fromContext={fromContext} singleTestData={singleTestAnalysisData} /> 
        );
    }
}

const mapStateToProps = ({ Universal, Authentication, SingleTestAnalysis }) => {

    const { student_TestAnalysis } = SingleTestAnalysis

    return {
        Universal, Authentication, student_TestAnalysis
    }
}

const mapStateToDispatch = {
trackingUsage
}

export default connect(mapStateToProps,mapStateToDispatch)(s_st_analysis);