import React, { Component } from "react";
import {} from "../../Redux_Actions/ReportsActions";
import { connect } from "react-redux";
import Chart from "../../Utils/LineChart/LineChart";
import ChartPagination from "../../Utils/LineChart/LineChartPagination";
import "./StudentMain.css";
import CompareCheckBoxes from "../../Utils/CompareCheckBoxes";

import { Get_Student_TestScores } from "../../Redux_Actions/ReportsActions";
import {
  OpenOrCloseTooltipIn_S_SP_OT,
  Get_Student_TestScores_Details,
  CompareCheckBoxes_Of_S_TS_Overview,
  EnableOrDisableLineColorIn_S_LC,
} from "../../Redux_Actions/Student_ReportsAction";

import {
  LineChartInput_Params,
  GetStudentId_And_SelectedTestList,
  AllClassesList,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compare,
  getClassAndSchoolListOfStudentData,
} from "./../ReusableComponents/AllReusableFunctions";
import LoadingScreen from "../../Utils/LoadingScreen/LoadingScreen";
import info_icon from "../../../public/images/info_icon.svg";
import TestScoreOverTimePDF from "../../Utils/PrintPDF/TestScoreOverTimePDF";
import { ACHIEVEMENT_LEVELS_ENABLE } from "../../Utils/globalVars";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";
import { EnddateValues, StartdateValues } from "../../Utils/reUsableSnipets";

class s_ts_overview extends Component {
  constructor(props) {
    super(props);
    (this.InfoTooltipPopUp = {}),
      (this.i_span_tooltip_ref = {}),
      (this.state = {});
    this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
    this.SelectCompareOption = this.SelectCompareOption.bind(this);
    this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
  }
  componentDidMount() {
    this.Apicalls("null", undefined);
    this.props.trackingUsage("assessmentreports_testscoresoverview:student");
  }
  /**
   *
   * @param {Object} event
   * triggers when click on outside of info div
   */
  handleClickOutside_info(event) {
    if (event.target == null || event.target == undefined) {
    } else if (this.props.S_Test_Scores_OverView.open_Tooltip_in_TS_Overview) {
      if (
        this.InfoTooltipPopUp !== null &&
        this.InfoTooltipPopUp !== undefined
      ) {
        let isitemexists = this.InfoTooltipPopUp.contains(event.target);
        let is_IExist = this.i_span_tooltip_ref.contains(event.target);
        if (
          (isitemexists == undefined ||
            isitemexists == null ||
            isitemexists == false) &&
          (is_IExist == undefined || is_IExist == null || is_IExist == false)
        ) {
          this.props.OpenOrCloseTooltipIn_S_SP_OT(false, "T_Scores");
        }
      }
    }
  }
  /**
   * if context data is changed from roster,test tabs or select student from class instance, this will trigger when we open this component.
   */
  Apicalls(from, checkOption) {
    const {
      getTests,
      Get_Selected_School_Info,
      loadingFor,
      Get_Student_TestScores,
    } = this.props.ApiCalls;
    let TestApiOr_SchoolApi =
      getTests ||
      Get_Selected_School_Info ||
      loadingFor == "tests" ||
      loadingFor == "school";

    let Nav = this.props.NavigationByHeaderSelection;

    if (
      (Get_Student_TestScores || from == "CompareCheckBox") &&
      !TestApiOr_SchoolApi &&
      Nav.T_scores
    ) {
      let Context_Header = this.props.ContextHeader;
      const { Roster_Tab, Date_Tab, DistrictId } = Context_Header;
      let { Student, SelectedTestList } =
        GetStudentId_And_SelectedTestList(Context_Header);
      let AccessToken = this.props.LoginDetails.JWTToken;
      const AllStudentList = AllClassesList(Roster_Tab.StudentsList);
      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      let Compare_Std_Ids =
        SchoolStds == undefined || SchoolStds == null
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));
      if (Compare_Std_Ids.length == 0) {
        let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }

      let clsIds =
        Roster_Tab.StudentData_cls_ids.length ==
        Roster_Tab.StudentData_cls.length
          ? []
          : Roster_Tab.StudentData_cls_ids;
      let currentTermId = this.props.currentTermID;

      const { UniversalSelecter,Context_DateTab } = this.props;
      let classId = Roster_Tab.SelectedClass.id;
      let startDate = Date_Tab.Report_termStartDate;
      let endDate = Date_Tab.Report_termEndDate;
      let district_Id = DistrictId;
      let schoolId = Roster_Tab.SelectedSchool.id;
      let studentId = Roster_Tab.SelectedStudent.id;
  
      if (classId == undefined) {
        classId = UniversalSelecter.Roster_Data.SelectedClass.id;
      }
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(Context_DateTab);
      }
      if (district_Id == undefined) {
        district_Id = Context_Header.Default_districtID;
      }
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      if (studentId == undefined) {
        studentId = UniversalSelecter.Roster_Data.SelectedStudent.id;
      }

      let TS_Details_Req_Payload = {
        studentId: studentId,
        studentIds: AllStudentList,
        classId: classId,
        classIds: clsIds,
        schoolId: schoolId,
        districtId: district_Id,
        startDate: startDate,
        endDate: endDate,
        componentCodeList: SelectedTestList,
        isClass: true,
        isSchool: true,
        isDistrict: true,
        compareStudentIds: Compare_Std_Ids,
        rosterGrade: Roster_Tab.selectedRosterGrade,
        isPastDistrictTerm: Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
        isCustomAchievements: ACHIEVEMENT_LEVELS_ENABLE,
      };

      const { stdDataSelectedClassIds, stdDataSelectedSchoolIds } =
        getClassAndSchoolListOfStudentData(Roster_Tab);
      TS_Details_Req_Payload.stdDataSelectedClassIds = stdDataSelectedClassIds;
      TS_Details_Req_Payload.stdDataSelectedSchoolIds =
        stdDataSelectedSchoolIds;

      let Enableloading = true;
      Roster_Tab.SelectedStudent.id != undefined
        ? this.props.Get_Student_TestScores_Details(
            AccessToken,
            TS_Details_Req_Payload,
            "afterinitialload",
            checkOption
          )
        : null;
    }
    //   : true
  }

  componentDidUpdate() {
    this.Apicalls("null", undefined);
    document.addEventListener("mousedown", this.handleClickOutside_info);
  }
  /**
   * Removing Event Listener For Mouse Click
   */
  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside_info);
  }
  /**
   * @param {string} checkOption
   * selected compare tabs will appear here
   */
  SelectCompareOption(checkOption, Check) {
    let gotAllValuesInChart =
      this.props.S_Test_Scores_OverView.gotAllValuesInChart;
    gotAllValuesInChart
      ? this.props.CompareCheckBoxes_Of_S_TS_Overview(checkOption, Check)
      : this.Apicalls("CompareCheckBox", checkOption);
  }

  /**
   * when user click on checbox comp label, then it will execute
   */
  ClickOnLabelName(labelName, checkOrUncheck) {
    this.props.EnableOrDisableLineColorIn_S_LC(labelName, checkOrUncheck);
  }

  render() {
    let {
      LineChart_Pagination,
      S_StandardPerformance_Overview,
      S_Test_Scores_OverView,
      S_ToolTipData,
      S_ApiCalls,
    } = this.props;
    const {
      StandardPerformanceFilter,
      ActualLineChartData,
      selectedStandarAvg,
      StrandNameOfSelectedStandard,
      selectedstandardObject,
    } = S_StandardPerformance_Overview;
    let { TestAssessment, TestGrade } = StandardPerformanceFilter;
    let selectedTestAssessment = TestAssessment.selectedTestAssessment;
    let selectedTestGrade =
      TestGrade.selectedTestgrade == "" || TestGrade.selectedTestgrade == null
        ? ""
        : TestGrade.selectedTestgrade.grade;
    let ActualListForGraph = JSON.parse(JSON.stringify(ActualLineChartData));
    let TotalQuestions = ActualListForGraph.reduce(
      (initial, item) => initial + parseInt(item.totalQuestions),
      0
    );

    let Array = JSON.parse(
      JSON.stringify(S_Test_Scores_OverView.ActualLineChartList)
    );
    let Pagination_Start = LineChart_Pagination.Chart_Page_Count_Start;
    let Pagination_End = LineChart_Pagination.Chart_Page_Count_End;
    const {
      XAxis_Params,
      YAxis_Params,
      DatatPointParams,
      tooltipParams,
      data,
      margin,
      width,
      height,
      Ipadwidth,
      Ipadheight,
      dataset_2,
      dataset_3,
    } = LineChartInput_Params(
      Array,
      Pagination_Start,
      Pagination_End,
      "s_ts_overview"
    );

    let ClassChecked = S_Test_Scores_OverView.checkClass;
    let SchoolChecked = S_Test_Scores_OverView.checkSchool;
    let DistrictChecked = S_Test_Scores_OverView.checkDistrict;
    let LastChecked_CB = S_Test_Scores_OverView.lastSelectedCheckBox;

    const {
      getTests,
      Get_Selected_School_Info,
      getStudentData_cls,
      loadingFor,
    } = this.props.ApiCalls;

    let TestOr_SchoolApi =
      getTests ||
      Get_Selected_School_Info ||
      loadingFor == "tests" ||
      loadingFor == "school" ||
      getStudentData_cls ||
      loadingFor == "studentData";

    return (
      <div className="class_main">
        <div className="class_main_center">
          {S_ApiCalls.loading_on_student_TS == false && !TestOr_SchoolApi ? (
            <div className="class_main_inr">
              <CompareCheckBoxes
                Navselection={this.props.NavigationByHeaderSelection.class}
                CheckeThis={this.SelectCompareOption}
                ClickOnLabel={this.ClickOnLabelName}
                TS_Overtime={this.props.S_Test_Scores_OverView}
                lastcheckedlabel={LastChecked_CB}
              />

              <div className="student_testscores_widget_title_main">
                <div className="student_testscores_widget_title overrightinfostyle">
                  <span>
                    <span style={{ float: "left" }}>Test Score Overview</span>
                    <span
                      onClick={() =>
                        this.props.OpenOrCloseTooltipIn_S_SP_OT(
                          true,
                          "T_Scores"
                        )
                      }
                      className="infoIconBlock"
                    >
                      <span
                        ref={(refs) =>
                          refs == null ? null : (this.i_span_tooltip_ref = refs)
                        }
                      >
                        <img
                          src={info_icon}
                          style={{ marginLeft: "3px", cursor: "pointer" }}
                        />
                      </span>
                      {S_Test_Scores_OverView.open_Tooltip_in_TS_Overview ? (
                        <div className="infoIconTooltipBlock_TS">
                          <div
                            ref={(InfoTooltipPopUp) =>
                              InfoTooltipPopUp !== null
                                ? (this.InfoTooltipPopUp = InfoTooltipPopUp)
                                : null
                            }
                            className="infoIconTooltipBlockInr"
                          >
                            <span
                              className="infoIconTooltipBlockArrow_TS"
                              style={{ padding: "0px" }}
                            ></span>
                            <b>Note:</b> The average score listed in the line
                            graph below is calculated from all data available
                            for each assessment based on the context selected.
                            It does not assume the cohort of students remains
                            the same across the assessments listed.
                          </div>
                        </div>
                      ) : null}
                    </span>
                    <span style={{ float: "right", padding: 0 }}>
                      {" "}
                      <TestScoreOverTimePDF
                        data={data}
                        XAxis_Params={XAxis_Params}
                        Pagination={LineChart_Pagination}
                        selectedTestAssessment={selectedTestAssessment}
                        selectedTestGrade={selectedTestGrade}
                        YAxis_Params={YAxis_Params}
                        DataSetParam={DatatPointParams}
                        TooltipParams={tooltipParams}
                        ToolTipData={this.props.S_ToolTipData}
                        ClassChecked={ClassChecked}
                        SchoolChecked={SchoolChecked}
                        DistrictChecked={DistrictChecked}
                        LastChecked_CB={LastChecked_CB}
                        Navselection={
                          this.props.NavigationByHeaderSelection.class
                        } //this.props.nav
                        TS_Overtime={this.props.S_Test_Scores_OverView}
                        CheckeThis={this.SelectCompareOption}
                        ClickOnLabel={this.ClickOnLabelName}
                        totalAverageScore={selectedStandarAvg}
                        totalQuestions={TotalQuestions}
                        standardName={StrandNameOfSelectedStandard}
                        strandName={
                          selectedstandardObject == null
                            ? null
                            : selectedstandardObject.standardDef
                        }
                        strandDetailsDesc={
                          selectedstandardObject == null
                            ? null
                            : selectedstandardObject.standardName
                        }
                        strandDescription={
                          selectedstandardObject == null
                            ? null
                            : selectedstandardObject.standardDesc
                        }
                      />
                    </span>
                  </span>
                </div>
              </div>
              <div className="studentTestscoreOvertimeChart">
                <Chart
                  margin={margin}
                  width={this.props.UserScreenWidth < 1230 ? Ipadwidth : width}
                  height={
                    this.props.UserScreenWidth < 1230 ? Ipadheight : height
                  }
                  data={data}
                  XAxis_Params={XAxis_Params}
                  YAxis_Params={YAxis_Params}
                  DataSetParam={DatatPointParams}
                  TooltipParams={tooltipParams}
                  ToolTipData={S_ToolTipData}
                  ClassChecked={ClassChecked}
                  SchoolChecked={SchoolChecked}
                  DistrictChecked={DistrictChecked}
                  LastChecked_CB={LastChecked_CB}
                />
                <div className="student_testscores_overview_pagination">
                  {this.props.LineChart_Pagination.Chart_TotalBubbles > 1 ? (
                    <ChartPagination
                      pagination={this.props.LineChart_Pagination}
                    />
                  ) : null}
                  <div className="Test_names_label">Test Names</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="Loadercenteralign">
              <LoadingScreen />
            </div>
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  StudentReports,
  Universal,
  Authentication,
  LastActiveUniversalProps,
  DateTabReducer
}) => {
  const { LoginDetails } = Authentication;
  const { S_ApiCalls } = StudentReports;
  const {
    S_StandardPerformance_Overview,
    S_ToolTipData,
    S_Test_Scores_OverView,
    LineChart_Pagination,
  } = StudentReports;
  const {
    UserScreenWidth,
    ApiCalls,
    UniversalSelecter,
    ContextHeader,
    NavigationByHeaderSelection,
    currentTermID,
  } = Universal;
  const { Context_DateTab } = DateTabReducer;
  return {
    LoginDetails,
    S_ApiCalls,
    UserScreenWidth,
    LineChart_Pagination,
    ApiCalls,
    UniversalSelecter,
    ContextHeader,
    S_StandardPerformance_Overview,
    S_ToolTipData,
    S_Test_Scores_OverView,
    NavigationByHeaderSelection,
    LineChart_Pagination,
    LastActiveUniversalProps,
    currentTermID,
    Context_DateTab
  };
};

export default connect(mapStateToProps, {
  OpenOrCloseTooltipIn_S_SP_OT,
  Get_Student_TestScores,
  Get_Student_TestScores_Details,
  CompareCheckBoxes_Of_S_TS_Overview,
  EnableOrDisableLineColorIn_S_LC,
  trackingUsage
})(s_ts_overview);
