import React, { Component } from 'react';
import '../ErrorAnalysisComponents/ErrorAnalysis.css';
import FirstArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end.svg';
import PreviousArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev.svg';
import NextArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next.svg';
import LastArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end.svg';
import FirstActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-active.svg';
import PreviousActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-active.svg';
import NextActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-active.svg';
import LastActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-active.svg';
import ErrorDonutChart from './ErrorValues.jsx';
import MsvDonutChart from './MsvValues.jsx';
import { connect } from 'react-redux';
import {
  scroll_Ea,
  iconUpdate,
  pieChartState
} from '../../../Redux_Actions/ErrorAnalysisActions.jsx';

class ErrorAnalysisChart extends Component {
  constructor(props) {
    super(props);

    this.state = {
      toggleChart: this.props.toggleChart,
      showMsvDiv: this.props.showMsvDiv,
      errorDiv: this.props.errorDiv,
      hideMsvDiv: this.props.hideMsvDiv,
      hideErrDonut: this.props.hideErrDonut
    };
    this.proficiencyType = this.proficiencyType.bind(this);
    this.showLastPassage = this.showLastPassage.bind(this);
    this.toggleMsv = this.toggleMsv.bind(this);
    this.toggleError = this.toggleError.bind(this);
    this.scrollData = this.scrollData.bind(this);
    this.showMsvDiv = this.showMsvDiv.bind(this);
  }

  //to slice an array
  slicedArray(data, date, index, scrollIndex) {
    this.props.scroll_Ea(data, date, index, index + this.props.isMobileView);
  }

  //scroll function to scroll data on x axis
  scrollData(data, date, type) {
    switch (type) {
      case 'right': {
        if (this.props.dataCount < data.substitution.length - this.props.isMobileView) {
          this.slicedArray(data, date, this.props.dataCount + 1);
        }
        if (this.props.dataCount + 1 < data.substitution.length - this.props.isMobileView) {
          const icon = {
            previousIcon: true,
            firstIcon: true,
            lastIcon: true,
            nextIcon: true
          };
          this.props.iconUpdate(icon);
        } else {
          const icon = {
            previousIcon: true,
            firstIcon: true,
            lastIcon: false,
            nextIcon: false
          };
          this.props.iconUpdate(icon);
        }
        break;
      }
      case 'left': {
        if (this.props.dataCount > 0) {
          this.slicedArray(data, date, this.props.dataCount - 1);
        }
        if (this.props.dataCount > 1) {
          const icon = {
            previousIcon: true,
            firstIcon: true,
            lastIcon: true,
            nextIcon: true
          };
          this.props.iconUpdate(icon);
        } else {
          const icon = {
            previousIcon: false,
            firstIcon: false,
            lastIcon: true,
            nextIcon: true
          };
          this.props.iconUpdate(icon);
        }
        break;
      }
      case 'rightMost': {
        if (this.props.dataCount < data.substitution.length - this.props.isMobileView) {
          this.slicedArray(data, date, data.substitution.length - this.props.isMobileView);
        }
        if (this.props.dataCount < data.substitution.length - this.props.isMobileView) {
          const icon = {
            previousIcon: true,
            firstIcon: true,
            lastIcon: false,
            nextIcon: false
          };
          this.props.iconUpdate(icon);
        }
        break;
      }
      case 'leftMost': {
        if (this.props.dataCount < data.substitution.length) {
          this.slicedArray(data, date, 0);
        }

        if (this.props.dataCount < data.substitution.length) {
          const icon = {
            previousIcon: false,
            firstIcon: false,
            lastIcon: true,
            nextIcon: true
          };
          this.props.iconUpdate(icon);
        }
        break;
      }
    }
  }

  // to show MSV analysis
  showMsvDiv() {
    this.props.pieChartState({
      showMsvDiv: true,
      errorDiv: false,
      toggleChart: false
    });
    // this.setState({ showMsvDiv: true });
    // this.setState({ errorDiv: false });
    // this.setState({ toggleChart: false });
  }

  // to show Error analysis
  showErrorDiv() {
    this.props.pieChartState({
      showMsvDiv: false,
      errorDiv: true,
      toggleChart: true
    });
  }

  //toggle charts
  toggleMsv() {
    this.props.pieChartState({
      showMsvDiv: !this.props.showMsvDiv,
      errorDiv: !this.props.errorDiv,
      toggleChart: !this.props.toggleChart
    });
  }

  toggleError() {
    this.props.pieChartState({
      showMsvDiv: !this.props.showMsvDiv,
      errorDiv: !this.props.errorDiv,
      toggleChart: !this.props.toggleChart
    });
  }

  //to display the last passage
  showLastPassage(passage) {
    return (
      <div className="hover-class">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }

  //display x axis with proficiency type
  proficiencyType(type) {
    switch (type) {
      case 'Instructional':
        return 'ar';
      case 'Independent':
        return 'ar-blue';
      case 'Frustrational':
        return 'ar-yellow';
    }
  }

  render() {
    const dateObject = this.props.dataObject.data.dateRangeReadingLevelAxis;
    const studentDataList = this.props.studentData;
    const date = studentDataList.date;
    const substitutionArray = studentDataList.substitution;
    const omissionArray = studentDataList.omission;
    const insertionArray = studentDataList.insertion;
    const meaningCuesArray = studentDataList.meaningCues;
    const omissionToldsArray = studentDataList.omissionTolds;
    const repetationArray = studentDataList.repetation;
    const selfCorrectionArray = studentDataList.selfCorrection;
    const structuralCuesArray = studentDataList.structuralCues;
    const toldArray = studentDataList.told;
    const visualCuesArray = studentDataList.visualCues;
    const dashSymbol = <span>&mdash;</span>;
    const average = this.props.dataObject.data.errorAnalysisAverage;
    const errorValueAverage = this.props.dataObject.data.errorAnalysisDonutData;
    const msvValueAverage = this.props.dataObject.data.msvAnalysisDonutData;

    return (
      <div
        className="container StEaContainer-07-20"
        style={{
          width: '1165px',
          paddingLeft: ' 0px',
          paddingRight: ' 0px'
        }}
      >
        <div className="sea-wrapper resp-sea-wrapper ipad-sea-wrapper">
          <div className="chart-btm-bor1" />
          <div className="chart-btm-bor2" />
          <div className="error-section">
            <span className="vert-error-txt">Error</span>
          </div>
          <div className="error-analysis-section bor-btm">
            <p>Error Analysis</p>
          </div>
          <div className="avg-col-txt">
            <p>Average</p>
          </div>
          <div className="sea-scroller ipad-sea-scroller">
            <div className="sea-table">
              <div onClick={() => this.showErrorDiv()}>
                {/* Substitution start */}
                <div className="first-panel top-border first-row">
                  <span className="sea-sticky-col pos-rel sibling-hover">
                    Substitution
                    <span className="row-strip-1 strip-bg-1" />
                  </span>
                  <span className="sibling-hover">
                    {substitutionArray.map((substitution, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {substitution.value}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-gray sibling-highlight">
                    {average.substitutionAverage}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Substitution end */}
                {/* Omission start */}
                <div className="first-panel">
                  <span className="sea-sticky-col pos-rel  sibling-hover">
                    Omission
                    <span className="row-strip-1 strip-bg-2" />
                  </span>
                  <span className="hideData sibling-hover">
                    {omissionArray.map((omission, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {omission.value}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-gray sibling-highlight">
                    {average.ommissionAverage}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Omission end */}
                {/* Insertion start */}
                <div className="first-panel">
                  <span className="sea-sticky-col pos-rel sibling-hover">
                    Insertion
                    <span className="row-strip-1 strip-bg-3" />
                  </span>
                  <span className="hideData sibling-hover">
                    {insertionArray.map((insertion, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {insertion.value}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-gray sibling-highlight">
                    {average.insertionAverage}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Insertion end */}
                {/* Told start */}
                <div className="first-panel">
                  <span className="sea-sticky-col pos-rel sibling-hover">
                    Told
                    <span className="row-strip-1 strip-bg-4" />
                  </span>
                  <span className="hideData sibling-hover">
                    {toldArray.map((told, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {told.value}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-gray sibling-highlight">
                    {average.toldAverage}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Told end */}
                {/* Repetition start */}
                {process.env.ORR_SHOW_REPETITION_BEHAVIOR_MARKUP === 'true' &&
                  <div className="first-panel">
                    <span className="sea-sticky-col pos-rel sibling-hover">
                      Repetition
                      <span className="row-strip-1 strip-bg-5" />
                    </span>
                    <span className="hideData sibling-hover">
                      {repetationArray.map((repetation, value) => (
                        <span
                          className={
                            'mid-size-td paddingError ' +
                            (value <= 4 ? 'one' : 'one two')
                          }
                        >
                          {repetation.value}
                        </span>
                      ))}
                    </span>
                    <span className="sea-sticky-colr avg-bg-gray sibling-highlight">
                      {average.repetationAverage}
                      <span className="avg-col-line" />
                    </span>
                  </div>
                }
                {/* Repetition end */}
                {/* Self-Correction start */}
                <div className="first-panel">
                  <span className="sea-sticky-col pos-rel sibling-hover">
                    Self-Correction
                    <span className="row-strip-1 strip-bg-6" />
                  </span>
                  <span className="hideData sibling-hover">
                    {selfCorrectionArray.map((selfCorrection, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {selfCorrection.value}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-gray sibling-highlight">
                    {average.selfCorrectionAverage}
                    <span className="avg-col-line" />
                  </span>
                </div>
              </div>
              {/* Self-Correction end */}
              {/* Meaning Cues start */}
              <div
                onClick={() =>
                  this.props.hideMsvDiv !== 'hide-msv' ? this.showMsvDiv() : ''
                }
              >
                <div className="second-panel msv-col-bg">
                  <span className="sea-sticky-col pos-rel  sibling-hover">
                    Meaning
                    <span className="row-strip-1 strip-bg-7" />
                  </span>
                  <span className="hideData  sibling-hover">
                    {meaningCuesArray.map((meaningCues, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {meaningCues.value !== null
                          ? meaningCues.value
                          : dashSymbol}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-darkgray sibling-highlight">
                    {average.meaningCuesAverage !== null
                      ? average.meaningCuesAverage
                      : dashSymbol}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Meaning Cues end */}
                {/* Structural Cues start */}
                <div className="second-panel msv-col-bg">
                  <span className="sea-sticky-col pos-rel  sibling-hover">
                    Structural
                    <span className="row-strip-1 strip-bg-7" />
                  </span>
                  <span className="hideData  sibling-hover">
                    {structuralCuesArray.map((structuralCues, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {structuralCues.value !== null
                          ? structuralCues.value
                          : dashSymbol}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-darkgray sibling-highlight">
                    {average.structuralCuesAverage !== null
                      ? average.structuralCuesAverage
                      : dashSymbol}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Structural Cues end */}
                {/* Visual Cues start */}
                <div className="second-panel msv-col-bg">
                  <span className="sea-sticky-col pos-rel  sibling-hover">
                    Visual
                    <span className="row-strip-1 strip-bg-7" />
                  </span>
                  <span className="hideData  sibling-hover">
                    {visualCuesArray.map((visualCues, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {visualCues.value !== null
                          ? visualCues.value
                          : dashSymbol}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-darkgray sibling-highlight">
                    {average.visualCuesAverage !== null
                      ? average.visualCuesAverage
                      : dashSymbol}
                    <span className="avg-col-line" />
                  </span>
                </div>
                {/* Visual Cues end */}
                {/* Omission & Tolds start */}
                <div className="second-panel msv-col-bg">
                  <span className="sea-sticky-col pos-rel  sibling-hover">
                    {/* Omission &amp; Tolds */}
                    MSV Not Scored
                    <span className="row-strip-1 strip-bg-7" />
                  </span>
                  <span className="hideData  sibling-hover">
                    {omissionToldsArray.map((omissionTolds, value) => (
                      <span
                        className={
                          'mid-size-td paddingError ' +
                          (value <= 4 ? 'one' : 'one two')
                        }
                      >
                        {omissionTolds.value !== null
                          ? omissionTolds.value
                          : dashSymbol}
                      </span>
                    ))}
                  </span>
                  <span className="sea-sticky-colr avg-bg-darkgray sibling-highlight">
                    {average.ommissionToldsAverage !== null
                      ? average.ommissionToldsAverage
                      : dashSymbol}
                    <span className="avg-col-line" />
                  </span>
                </div>
              </div>
              {/* Omission & Tolds end */}
              <div className="no-hover pag-row">
                <span
                  style={{ width: '128px' }}
                  className={
                    'pagination-panel pagination-set1 ' +
                    (this.props.icon.firstIcon ? 'cursor-pointer' : '')
                  }
                >
                  <span
                    onClick={() => this.props.icon.firstIcon &&
                      this.scrollData(
                        this.props.dataObject.data.errorAnalysisData,
                        dateObject,
                        'leftMost'
                      )
                    }
                  >
                    <img
                      src={
                        this.props.icon.firstIcon
                          ? FirstActiveArrow
                          : FirstArrow
                      }
                    />
                  </span>
                  <span
                    className={
                      'pag-prev-img ' +
                      (this.props.icon.previousIcon ? 'cursor-pointer' : '')
                    }
                    onClick={() => this.props.icon.previousIcon &&
                      this.scrollData(
                        this.props.dataObject.data.errorAnalysisData,
                        dateObject,
                        'left'
                      )
                    }
                  >
                    <img
                      src={
                        this.props.icon.previousIcon
                          ? PreviousActiveArrow
                          : PreviousArrow
                      }
                    />
                  </span>
                </span>
                <div className="wd-126">
                  {date.map((date, value) => (
                    <div className="date-alignment" id={value}>
                      <span
                        id={value}
                        // title={date.lastPassage}
                        className={
                          'cursor-pointer ar1 ' +
                          this.proficiencyType(date.proficiency) +
                          (value <= 4 ? ' one' : ' one two')
                        }
                      >
                        {date.assignmentDate}
                        <span
                          id={value}
                          className={
                            'cursor-pointer level-alignment ' +
                            (value <= 4 ? 'one' : 'one two')
                          }
                        >
                          {date.readingLevel}
                        </span>
                      </span>
                      {this.showLastPassage(date.lastPassage)}
                    </div>
                  ))}
                </div>
                <span
                  className="sea-sticky-colr pagination-set2"
                  id="next"
                  onClick={() => this.props.icon.nextIcon &&
                    this.scrollData(
                      this.props.dataObject.data.errorAnalysisData,
                      dateObject,
                      'right'
                    )
                  }
                >
                  <img
                    className={
                      'pag-next-img' +
                      (this.props.icon.nextIcon ? ' cursor-pointer' : '')
                    }
                    src={this.props.icon.nextIcon ? NextActiveArrow : NextArrow}
                  />
                </span>
                <span
                  className={
                    'sea-sticky-colrNew zs-new pagination-set2 mid-size-td ' +
                    (this.props.icon.lastIcon ? 'cursor-pointer' : '')
                  }
                  onClick={() => this.props.icon.lastIcon &&
                    this.scrollData(
                      this.props.dataObject.data.errorAnalysisData,
                      dateObject,
                      'rightMost'
                    )
                  }
                >
                  <img
                    src={this.props.icon.lastIcon ? LastActiveArrow : LastArrow}
                  />
                </span>
              </div>
              {/* date and level start */}

              {/* date and level end */}
            </div>
          </div>
          <div className="assginment-txt">
            <p>Assignment</p>
          </div>
        </div>
        <div className="error-analysis-right resp-ea-rhs ipad-sea-rhs">
          <div className="container ipad-sea-container">
            {this.props.hideErrDonut ? (
              <div>No Data Available</div>
            ) : (
                <div>
                  <div
                    className="panel-bg cursor-pointer"
                    onClick={
                      this.props.hideMsvDiv !== 'hide-msv' ? this.toggleError : ''
                    }
                  >
                    <div className="panel-heading ph-sub res-mb-0 pos-rel">
                      <div className="sea-tab-extra-bg"></div>
                      <h4 className="panel-title pt-sub res-mb-0">
                        <i
                          className={
                            'glyphicon ' +
                            (this.props.toggleChart ? ' icon-open' : 'icon-close')
                          }
                        />
                        <span
                          className={
                            'pt-sub-font' +
                            (this.props.toggleChart ? ' blue-color' : '')
                          }
                        >
                          Error Analysis
                      </span>
                        {/* indicator not needed for now <span
                        className={
                          'fa ' +
                          (this.state.toggleChart
                            ? 'fa-arrow-up'
                            : ' fa-arrow-down')
                        }
                        style={{
                          color: this.state.toggleChart ? '#00539b' : ''
                        }}
                      /> */}
                      </h4>
                    </div>
                  </div>
                  <div
                    className={
                      'bor-lft resp-bor-center ' +
                      (!this.props.showMsvDiv && this.props.errorDiv
                        ? 'show '
                        : 'collapse ')
                    }
                  >
                    <ErrorDonutChart data={errorValueAverage}
                      isMobileView={this.props.isMobileView}
                    />
                  </div>
                </div>
              )}
            <div
              className={
                'panel panel-default  cursor-pointer panel-bg res-mt-5 pos-rel ' +
                this.props.hideMsvDiv
              }
            >
              <div className="sea-tab-extra-bg"></div>
              <div className="mh-32 " onClick={this.toggleMsv}>
                <h4>
                  <i
                    className={
                      'glyphicon ' +
                      (this.props.toggleChart ? 'icon-close' : ' icon-open')
                    }
                  />
                  <span
                    className={
                      'pt-sub-font' +
                      (this.props.toggleChart ? '' : ' blue-color')
                    }
                  >
                    MSV Analysis
                  </span>
                  {/* indicator not needed for now <span
                    className={
                      'fa ' +
                      (this.state.toggleChart
                        ? 'fa-arrow-down'
                        : ' fa-arrow-up')
                    }
                    style={{ color: this.state.toggleChart ? '' : '#00539b' }}
                  /> */}
                </h4>
              </div>
              <div
                className={
                  'bor-lft msv-bor-lft ' +
                  (this.props.showMsvDiv && !this.props.errorDiv
                    ? 'show'
                    : 'collapse')
                }
              >
                <div className="pb-sub pos-rel">
                  <div className="msv-btm-bor"></div>
                  <MsvDonutChart data={msvValueAverage}
                    isMobileView={this.props.isMobileView}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- Right Chart Graph Start --> */}

        {/* <!-- Right Chart Graph Start --> */}
      </div>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { scroll_Ea, iconUpdate, pieChartState }
)(ErrorAnalysisChart);
