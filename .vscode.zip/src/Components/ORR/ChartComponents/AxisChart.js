import React, { Component } from "react";
import { AxisBottom, AxisRight } from "@vx/axis";
import { scaleLinear, scaleBand } from "@vx/scale";
import { Group } from "@vx/group";
import { GridRows } from "@vx/grid";
import { localPoint } from "@vx/event";
import "../FilterComponents/Filter.css";
import { backgroundColor, axisColor, bubbleColor } from "./Graph_Color";
import { LinePath, Circle } from "@vx/shape";
import { curveBasis } from "@vx/curve";
import { withTooltip, Tooltip } from "@vx/tooltip";
import "../../../Utils/LineChart/ToolTip/ToolTip.css";

class AxisChart extends Component {
  constructor(props) {
    super(props);
    this.myRef = React.createRef();
    this.state = {
      xpoint: 0,
      x_coords: 75,
      y_coords: 390,
      showFluency: false,
      showAccuracy: false,

      previousIcon: false,
      firstIcon: false,
      nextIcon: true,
      lastIcon: true,

      bottomIcon: true,
      bottomLastIcon: true,
      topFirstIcon: false,
      topIcon: false,

      enableTooltip: false
    };
    this.getX = 0;
    this.getY = 0;
    this.topIndex = 0;
    this.bottomIndex = 6;
    this.leftIndex = 0;
    this.rightIndex = 5;
    this.xDiff = 0;
    this.xStandardInitialVal = 52;
    this.xInitialVal = this.xStandardInitialVal;
    this.xIdx = 0;
    this.xLastVal = 0;
    this.xLastReturn = 0;
    this.toggleY1 = this.toggleY1.bind(this);
    this.toggleY2 = this.toggleY2.bind(this);
    this.popUpCoordinates = {};
    this.popUpDetails = {};
  }
  toggleY1() {
    if (this.state.showAccuracy !== true) {
      this.setState({ showFluency: !this.state.showFluency });
    }
  }

  toggleY2() {
    if (this.state.showFluency !== true) {
      this.setState({ showAccuracy: !this.state.showAccuracy });
    }
  }

  dateFunction(formattedValue) {
    return formattedValue;
  }

  setX(x, ind) {
    var returnVal = 0;
    if (x == this.xLastVal) {
      return this.xLastReturn;
    }
    if (x < this.xLastVal) {
      // To check for one loop
      this.xIdx = 0;
      this.xDiff = 0;
      this.xInitialVal = this.xStandardInitialVal;
    }
    if (this.xIdx == 0) {
      returnVal = 125 - (x % 172);
      if (Math.ceil(returnVal) != this.xStandardInitialVal) {
        this.xInitialVal = returnVal;
      }
      this.xIdx++;
    } else {
      if (this.xInitialVal != this.xStandardInitialVal && this.xDiff == 0) {
        this.xDiff = Math.abs(x - this.xLastVal - 172);
      }
      if (this.xDiff == 0) {
        returnVal = 125 - (x % 172);
      } else {
        returnVal = this.xInitialVal + this.xIdx * this.xDiff;
      }
      this.xIdx++;
    }
    this.xLastVal = x;
    this.xLastReturn = returnVal;

    return returnVal;
  }

  navigateUp(data) {
    if (this.bottomIndex === 10) {
      document.getElementById("yAxis").scrollTop += 60;
      document.getElementById("plotting_area").scrollTop += 60;
      document.getElementById("startingLevel").scrollTop += 60;
      document.getElementById("readingTarget").scrollTop += 60;
      this.topIndex += 1;
      this.bottomIndex += 1;
      this.setState({ bottomIcon: false });
      this.setState({ topFirstIcon: true });
      this.setState({ bottomLastIcon: false });
      this.setState({ topIcon: true });
    }
    else {
      document.getElementById("yAxis").scrollTop += 60;
      document.getElementById("plotting_area").scrollTop += 60;
      document.getElementById("startingLevel").scrollTop += 60;
      document.getElementById("readingTarget").scrollTop += 60;
      this.topIndex += 1;
      this.bottomIndex += 1;
      this.setState({ bottomIcon: true });
      this.setState({ topFirstIcon: true });
      this.setState({ bottomLastIcon: true });
      this.setState({ topIcon: true });
    }
  }
  navigateAllUp(data) {
    this.topIndex = 0;
    this.bottomIndex = data - 1;
    document.getElementById("yAxis").scrollTop += data * 60 - 6 * 60;
    document.getElementById("plotting_area").scrollTop += data * 60 - 6 * 60;
    document.getElementById("startingLevel").scrollTop += data * 60 - 6 * 60;
    document.getElementById("readingTarget").scrollTop += data * 60 - 6 * 60;
    this.setState({ bottomIcon: false });
    this.setState({ topFirstIcon: true });
    this.setState({ bottomLastIcon: false });
    this.setState({ topIcon: true });
  }
  navigateDown() {
    if (this.bottomIndex === 7) {
      document.getElementById("yAxis").scrollTop -= 60;
      document.getElementById("plotting_area").scrollTop -= 60;
      document.getElementById("startingLevel").scrollTop -= 60;
      document.getElementById("readingTarget").scrollTop -= 60;
      this.topIndex -= 1;
      this.bottomIndex -= 1;
      this.setState({ bottomIcon: true });
      this.setState({ topFirstIcon: false });
      this.setState({ bottomLastIcon: true });
      this.setState({ topIcon: false });
    }
    else {
      this.setState({ bottomIcon: true });
      this.setState({ topFirstIcon: false });
      this.setState({ bottomLastIcon: true });
      this.setState({ topIcon: false });
      document.getElementById("yAxis").scrollTop -= 60;
      document.getElementById("plotting_area").scrollTop -= 60;
      document.getElementById("startingLevel").scrollTop -= 60;
      document.getElementById("readingTarget").scrollTop -= 60;
      this.topIndex -= 1;
      this.bottomIndex -= 1;
    }
  }
  navigateAllDown(data) {
    document.getElementById("yAxis").scrollTop -= data * 60 - 6 * 60;
    document.getElementById("plotting_area").scrollTop -= data * 60 - 6 * 60;
    document.getElementById("startingLevel").scrollTop -= data * 60 - 6 * 60;
    document.getElementById("readingTarget").scrollTop -= data * 60 - 6 * 60;
    this.topIndex = 0;
    this.bottomIndex = data - 6;
    this.setState({ bottomIcon: true });
    this.setState({ topFirstIcon: false });
    this.setState({ bottomLastIcon: true });
    this.setState({ topIcon: false });
  }
  navigateRight(data, xBlockWidth) {
    if (this.rightIndex === data) {
      this.setState({ firstIcon: true });
      this.setState({ previousIcon: true });
      this.setState({ lastIcon: false });
      this.setState({ nextIcon: false });
      document.getElementById("xAxis").scrollLeft += xBlockWidth;
      document.getElementById("plotting_area").scrollLeft += xBlockWidth;
      document.getElementById("fluencyChart").scrollLeft += xBlockWidth;
      document.getElementById("accuracyChart").scrollLeft += xBlockWidth;
      this.rightIndex++;
      this.leftIndex++;
    }
    else {
      document.getElementById("xAxis").scrollLeft += xBlockWidth;
      document.getElementById("plotting_area").scrollLeft += xBlockWidth;
      document.getElementById("fluencyChart").scrollLeft += xBlockWidth;
      document.getElementById("accuracyChart").scrollLeft += xBlockWidth;
      this.setState({ firstIcon: true });
      this.setState({ previousIcon: true });
      this.setState({ lastIcon: true });
      this.setState({ nextIcon: true });
      this.rightIndex++;
      this.leftIndex++;
    }
  }
  navigateAllRight(data, xBlockWidth) {
    document.getElementById("xAxis").scrollLeft =
      data * xBlockWidth - 4 * xBlockWidth;
    document.getElementById("plotting_area").scrollLeft =
      data * xBlockWidth - 4 * xBlockWidth;
    document.getElementById("fluencyChart").scrollLeft =
      data * xBlockWidth - 4 * xBlockWidth;
    document.getElementById("accuracyChart").scrollLeft =
      data * xBlockWidth - 4 * xBlockWidth;
    this.setState({ firstIcon: true });
    this.setState({ previousIcon: true });
    this.setState({ lastIcon: false });
    this.setState({ nextIcon: false });
    this.leftIndex = data - 4;
    this.rightIndex = data;
  }
  navigateLeft(xBlockWidth) {
    if (this.leftIndex === 1) {
      document.getElementById("xAxis").scrollLeft -= xBlockWidth;
      document.getElementById("plotting_area").scrollLeft -= xBlockWidth;
      document.getElementById("accuracyChart").scrollLeft -= xBlockWidth;
      document.getElementById("fluencyChart").scrollLeft -= xBlockWidth;
      this.setState({ firstIcon: false });
      this.setState({ previousIcon: false });
      this.setState({ lastIcon: true });
      this.setState({ nextIcon: true });
    }
    else {
      document.getElementById("xAxis").scrollLeft -= xBlockWidth;
      document.getElementById("plotting_area").scrollLeft -= xBlockWidth;
      document.getElementById("fluencyChart").scrollLeft -= xBlockWidth;
      document.getElementById("accuracyChart").scrollLeft -= xBlockWidth;
      this.leftIndex--;
      this.rightIndex--;
      this.setState({ firstIcon: true });
      this.setState({ previousIcon: true });
      this.setState({ lastIcon: true });
      this.setState({ nextIcon: true });
      return;
    }
  }
  navigateAllLeft(data, xBlockWidth) {
    this.rightIndex = 5;
    this.leftIndex = 0;
    if (this.leftIndex === 0) {
      document.getElementById("xAxis").scrollLeft =
        5 * xBlockWidth - data * xBlockWidth;
      document.getElementById("plotting_area").scrollLeft =
        5 * xBlockWidth - data * xBlockWidth;
      document.getElementById("fluencyChart").scrollLeft =
        5 * xBlockWidth - data * xBlockWidth;
      document.getElementById("accuracyChart").scrollLeft =
        5 * xBlockWidth - data * xBlockWidth;
      this.setState({ firstIcon: false });
      this.setState({ previousIcon: false });
      this.setState({ lastIcon: true });
      this.setState({ nextIcon: true });
    }
  }
  getBackgroundColorYAxis(value) {
    var bgColorValue = [];
    bgColorValue = backgroundColor(value);
    return bgColorValue;
  }
  getAxisColorYAxis(value) {
    var axisColorValue;
    axisColorValue = axisColor(value);
    return axisColorValue;
  }
  getBubbleColor(value) {
    var bubbleColorValue;
    bubbleColorValue = bubbleColor(value);
    return bubbleColorValue;
  }
  clickFuntion(value, cx, cy) {
    this.popUpDetails = value;
    if (this.state.enableTooltip === true) {
      this.setState({ enableTooltip: false });
    } else {
      this.popUpCoordinates = {
        transform: `translate(${cx - 226}px, ${cy - 90}px)`,
        display: "inline-flex",
        position: "absolute"
      };
      this.setState({ enableTooltip: true });
    }
  }
  showTooltip() {
    return (
      <div style={this.popUpCoordinates}>
        <div class="inner-popup pos-rel">
          <div className="small-circle" style={{ backgroundColor: this.getBubbleColor(this.popUpDetails.Z) }}></div>
          <ul class="first-ul">
            <li>
              <span>Reading Level:</span>
              {this.popUpDetails.Y}
            </li>
            <li>
              <span>Assignment:</span> {this.popUpDetails.assignmentTitle}
            </li>
            <li>
              <span>Category:</span> {this.popUpDetails.category}
            </li>
            <li>
              <span>Proficiency:</span> {this.popUpDetails.proficiency}
            </li>
            <li>
              <span>Accuracy:</span> {this.popUpDetails.accuracy} %
            </li>
            <li>
              <span>Fluency:</span> {this.popUpDetails.fluency} wcpm
            </li>
          </ul>
        </div>
      </div>
    );
  }

  render(props) {
    var data = this.props.data;
    var opacityValueStaringLevel = 0.0; // If there is no starting level
    var opacityValueTargetLevel = 0.0; // If there is no target level
    var readingLevelAxis = this.props.readingLevelAxis;
    var studentReadingTarget = this.props.studentReadingTarget;
    var studentStartingLevel = this.props.studentStartingLevel;
    var dateRangeAxis = this.props.dateRange;
    var assignmentDataList = this.props.assignmentList;
    var accuracyAxis = this.props.accuracyAxis;
    var accuracyDataList = this.props.accuracyDataList;
    var fluencyAxis = this.props.fluencyAxis;
    var fluencyDataList = this.props.fluencyDataList;
    var ToolTipParams = this.props.tooltipParams;

    const x = d => d.assignmentDate;
    const y = d => d.letterLevel;
    const fluencyAxisGridLines = v => v.value;
    const accuracyAxisGridLines = v => v.value;
    const accuracyDataValues = a => a.accuracy;
    const fluencyDataValues = f => f.fluency;
    // 02-07-2019
    if (studentStartingLevel.startingLevel !== null) {
      opacityValueStaringLevel = 1;
    }
    if (studentReadingTarget.readingTarget !== null) {
      opacityValueTargetLevel = 1;
    }
    var clusteringCoordinatesData = assignmentDataList.map((dates, index) => {
      return {
        X: dates.assignmentDate,
        Y: dates.letterLevel,
        Z: dates.proficiency,
        accuracy: dates.accuracy,
        proficiency: dates.proficiency,
        fluency: dates.fluency,
        accuracy: dates.accuracy,
        assignmentTitle: dates.assignmentTitle,
        category: dates.category
      };
    });
    var clusteringFluencyData = fluencyDataList.map((data, index) => {
      return {
        date: data.assignmentDate,
        value: data.fluency
      };
    });
    var clusteringAccuracyData = accuracyDataList.map((data, index) => {
      return {
        date: data.assignmentDate,
        value: data.accuracy
      };
    });

    //data should be added
    let { margin, width, height, data2, data3 } = this.props;
    let X_Axis = this.props.XAxis_Params;
    let Y_Axis = this.props.YAxis_Params;

    // scales
    const xScale = scaleBand({
      domain: data.map(x),
      range: [0, data.length * 159]
    });
    const fluencyYScale = scaleLinear({
      range: [fluencyAxis.length * 3, 0],
      domain: fluencyAxis.map(fluencyAxisGridLines)
    });
    const accuracyYScale = scaleLinear({
      range: [accuracyAxis.length * 4, 0],
      domain: accuracyAxis.map(accuracyAxisGridLines)
    });

    // Positions
    const x_c = test => xScale(x(test));
    const y_c = test => fluencyYScale(fluencyDataValues(test));
    const y_d = test => accuracyYScale(accuracyDataValues(test));

    // bounds
    const xMax = width - margin.left;
    const yMax = height - margin.top - margin.bottom;

    // Height of SVG used to scroll
    const scrollSVGHeight = 48;
    const scrollSVGWidth = 57;

    // Height of a block on Y-axis ()
    const yBlockHeight = 60;
    const xBlockWidth = 172;

    // Width of Starting Level and Reading Target
    const startLevelWidth = 100;
    const readingTargetWidth = 100;

    // X Start Gap
    var xStartGap = 45;

    // Total height of Y axis and Total width of X axis
    var totalHeight = readingLevelAxis.length * yBlockHeight;
    var totalWidth = scrollSVGWidth + dateRangeAxis.length * xBlockWidth;

    return (
      <div className="chart-border ">
        {/* Radio button start */}
        <div className="show-radio-btn">
          <form action="#">
            <div className="check-box-heading pull-left">Show:</div>
            <div onClick={this.toggleY1} className="round pull-left">
              <input type="checkbox" />
              <label className={this.state.showFluency ? "check-active" : ""}>
                <span>Fluency</span>
              </label>
            </div>
            <div onClick={this.toggleY2} className="round pull-left">
              <input type="checkbox" />
              <label className={this.state.showAccuracy ? "check-active" : ""}>
                <span>Accuracy</span>
              </label>
            </div>
          </form>
          <div className="hor-line1" />
        </div>
        {/* Radio button end */}

        <div className="readingLevel">Reading Level</div>
        <div className="readingLevel-date">Date</div>

        {/* Reading Level Progress */}
        <div className="reading-level-section pull-left clearfix pt-03">
          <div
            className={
              this.state.topFirstIcon ? "y-top-end-active" : "y-top-end"
            }
            onClick={() => this.navigateAllDown(readingLevelAxis.length)}
          />
          <div
            className={this.state.topIcon ? "y-top-active" : "y-top-inactive"}
            onClick={() => this.navigateDown()}
          />
          <div id="yAxis" style={{ height: "420px", overflow: "hidden" }}>
            {/* SVG for Y-Axis */}
            <svg height={totalHeight} width={60}>
              <g>
                {readingLevelAxis.map((value, index) => {
                  return (
                    <g id="g1">
                      <rect
                        x={2.556}
                        y={index * yBlockHeight}
                        width={56}
                        height={60}
                        opacity={1.7}
                        className="y-axis-border"
                        fill={this.getBackgroundColorYAxis(value.levelName)}
                        key={index}
                      />

                      <rect
                        x="54.434"
                        y={index * yBlockHeight}
                        opacity="1"
                        width="4"
                        height="60"
                        fill={this.getAxisColorYAxis(value.levelName)}
                        class="bor-rhs"
                      />
                      <rect
                        x={2.556}
                        y={index * yBlockHeight}
                        width={56}
                        height={1}
                        opacity={1.7}
                        className="y-axis-border"
                        fill={"#fff"}
                      />
                      <text
                        x={10.434}
                        y={index * yBlockHeight}
                        fontFamily="Quicksand"
                        fill="#333"
                        transform={"translate(13,36)"}
                        fontWeight={600}
                        fontSize={15}
                      >
                        {value.levelName}
                      </text>
                    </g>
                  );
                })}
              </g>
            </svg>
          </div>
          <div
            className={this.state.bottomIcon ? "y-bottom-active" : "y-bottom"}
            onClick={() => this.navigateUp(readingLevelAxis.length)}
          />
          <div
            className={
              this.state.bottomLastIcon ? "y-bottom-end-active" : "y-bottom-end"
            }
            onClick={() => this.navigateAllUp(readingLevelAxis.length)}
          />
        </div>

        <div className="graph-content pull-left pos-rel">
          <div className="graph-svg">
            <div style={{ display: "flex", maxHeight: "543px" }}>
              <div className="vert-line" />
              <div className="vert-line1" />
              {/* SVG for Starting Level */}
              <div
                id="startingLevel"
                style={{
                  height: "526px",
                  width: "150px",
                  overflow: "hidden",
                  marginTop: "20px"
                }}
              >
                <div className="rl-txt">
                  <p>Starting Level</p>
                </div>
                <div className="rt-txt">
                  <p>Reading Target</p>
                </div>
                <div className="rl-blue-txt">
                  <p> Reading Level Progress Over Time</p>
                </div>
                <div class="sub-first-back" />
                <svg
                  width={startLevelWidth + 50}
                  height={totalHeight + scrollSVGHeight + 75}
                  fill="none"
                >
                  <Group top={20} left={28}>
                    <rect
                      x={30.434}
                      y={1.657}
                      opacity={0.7}
                      width={2}
                      height={558}
                      fill="#D6DBE5"
                    />
                    <g>
                      <rect
                        x={35.434}
                        y={1.657}
                        opacity={opacityValueStaringLevel}
                        width={78}
                        height="100%"
                        fill="#D6DBE5"
                      />
                    </g>
                    <g>
                      <circle
                        cx={74}
                        cy={
                          readingLevelAxis.findIndex(
                            item =>
                              item.levelName ===
                              studentStartingLevel.startingLevel
                          ) *
                          yBlockHeight +
                          yBlockHeight +
                          17
                        }
                        r="26"
                        strokeWidth="4px"
                        stroke="#32AC41"
                        fill="#fff"
                      />
                      <text
                        transform={`translate(${69}, ${readingLevelAxis.findIndex(
                          item =>
                            item.levelName ===
                            studentStartingLevel.startingLevel
                        ) *
                          yBlockHeight +
                          yBlockHeight +
                          21})`}
                        fontFamily="Quicksand"
                        fill="#000"
                        fontWeight="500"
                        fontSize="16"
                      >
                        {studentStartingLevel.startingLevel}
                      </text>
                    </g>
                  </Group>
                </svg>
              </div>
              {/* Fluency */}
              <div
                id="fluencyChart"
                style={{
                  position: "absolute",
                  width: "650px",
                  height: "390px",
                  overflow: "hidden",
                  transform: "translate(63px, 76px)"
                }}
              >
                <span style={{
                  float: 'right',
                  color: '#00539b'
                }}>{this.state.showFluency ? "Fluency" : ""}<br></br> {this.state.showFluency ? "(wcpm)" : ""} </span>
                <svg width={data.length * 1500} height={400}>
                  <GridRows
                    top={350}
                    left={0}
                    className={this.state.showFluency ? "show" : "hide"}
                    scale={fluencyYScale}
                    stroke="#D6DBE5"
                    width={data.length * 1500}
                    opacity={opacityValueStaringLevel}
                    height={420}
                    numTicks={10}
                    fill="none"
                  />
                  <LinePath
                    className={this.state.showFluency ? "show" : "hide"}
                    data={fluencyDataList}
                    x={x_c}
                    y={y_c}
                    stroke={"#D6DBE5"}
                    strokeWidth={2}
                    curve={curveBasis}
                    strokeLinecap="round"
                    transform={`translate(${35}, ${350})`}
                  />
                </svg>
              </div>
              {/* Accuracy */}
              <div
                id="accuracyChart"
                style={{
                  position: "absolute",
                  width: "650px",
                  height: "390px",
                  overflow: "hidden",
                  transform: "translate(63px, 76px)"
                }}
              >


                <svg width={data.length * 1500} height={400}>
                  <GridRows
                    top={350}
                    left={0}
                    className={this.state.showAccuracy ? "show" : "hide"}
                    scale={accuracyYScale}
                    stroke="#D6DBE5"
                    width={data.length * 1500}
                    opacity={opacityValueStaringLevel}
                    height={1500}
                    numTicks={10}
                  />
                  <LinePath
                    className={this.state.showAccuracy ? "show" : "hide"}
                    data={accuracyDataList}
                    x={x_c}
                    y={y_d}
                    stroke={"#D6DBE5"}
                    strokeWidth={2}
                    strokeLinecap="round"
                    curve={curveBasis}
                    transform={`translate(${40}, ${350})`}
                  />
                </svg>
              </div>
              {/* SVG for Data Population */}
              <div id="plotting_area" className="viewportRLP">
                {this.state.enableTooltip ? this.showTooltip() : null}
                {/* SVG for fluency and accuracy */}
                <svg
                  width={totalWidth - (startLevelWidth - 950)}
                  height={readingLevelAxis.length * yBlockHeight}
                  fill="none"
                >
                  <Group
                    width={totalWidth - (startLevelWidth - 950)}
                    height={readingLevelAxis.length * yBlockHeight}
                  >
                  </Group>

                  {clusteringCoordinatesData.map((value, index) => {
                    var cx = data.findIndex(
                      item => item.assignmentDate === value.X
                    );
                    cx = xStartGap + cx * xBlockWidth;
                    var cy = readingLevelAxis.findIndex(
                      item => item.levelName === value.Y
                    );
                    cy = cy * yBlockHeight + yBlockHeight / 2;
                    return (
                      <g key={index}>
                        <circle
                          key={index}
                          cx={cx}
                          cy={cy}
                          r="26"
                          strokeWidth="4px"
                          stroke={this.getBubbleColor(value.Z)}
                          fill={"#fff"}
                          cursor="pointer"
                          onClick={event => {
                            this.clickFuntion(value, cx, cy);
                          }}
                        />
                        <text
                          transform={`translate(${cx - 6}, ${cy + 5})`}
                          fontFamily="Quicksand"
                          fill="#000"
                          fontWeight="500"
                          fontSize="16"
                          cursor="pointer"
                          onClick={event => {
                            this.clickFuntion(value, cx, cy);
                          }}
                        >
                          {value.Y}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              </div>

              <div />

              {/* Just for fixing the width and position of Reading Target */}
              <svg
                width={30}
                className={
                  this.state.showFluency || this.state.showAccuracy
                    ? "hide"
                    : "show"
                }
              >
                <Group
                  className={
                    this.state.showFluency || this.state.showAccuracy
                      ? "hide"
                      : "show"
                  }
                >
                  <AxisRight
                    scale={fluencyYScale}
                    top={420}
                    left={55}
                    stroke={"#D6DBE5"}
                    tickTextFill={"#606060"}
                    tickStroke={"#fff"}
                    labelClassName="y---axis"
                    labelOffset={Y_Axis.LabelOffset}
                    hideAxisLine={true}
                  />
                </Group>
              </svg>
              {/* SVG for Fluency and Accuracy ----- Y Axis(Fixed)*/}

              <svg
                width={30}
                className={this.state.showFluency ? "show" : "hide"}
              >
                <Group className={this.state.showFluency ? "show" : "hide"}>
                  <AxisRight
                    scale={fluencyYScale}
                    top={420}
                    tickValues={fluencyAxis.value}
                    left={55}
                    // label={Y_Axis.LabelName}
                    stroke={"#D6DBE5"}
                    tickTextFill={"#606060"}
                    tickStroke={"#fff"}
                    labelClassName="y---axis"
                    labelOffset={Y_Axis.LabelOffset}
                    hideAxisLine={true}
                    tickLabelProps={({ value, index }) => ({
                      dx: "-5em",
                      dy: "0.5em",
                      fill: "black",
                      fontSize: 12,
                      fontWeight: 500
                    })}
                  />
                </Group>
              </svg>
              <svg
                width={30}
                className={this.state.showAccuracy ? "show" : "hide"}
              >
                {accuracyDataList.map((d, i) => {
                  return (
                    <LinePath
                      data={Number(d.fluency)}
                      x={x}
                      y={accuracyDataValues}
                      stroke={"#000"}
                      fill="red"
                      strokeWidth={10}
                    />
                  );
                })}
                <Group className={this.state.showAccuracy ? "show" : "hide"}>
                  <AxisRight
                    scale={accuracyYScale}
                    top={420}
                    tickValues={accuracyAxis.value}
                    left={55}
                    stroke={"#D6DBE5"}
                    tickTextFill={"#606060"}
                    tickStroke={"#fff"}
                    labelClassName="y---axis"
                    labelOffset={Y_Axis.LabelOffset}
                    hideAxisLine={false}
                    tickLabelProps={({ value, index }) => ({
                      dx: "-5em",
                      dy: "0.5em",
                      textAnchor: "start",
                      fill: "black",
                      fontSize: 12,
                      fontWeight: 500
                    })}
                  />
                </Group>
              </svg>
              {/* SVG for Reading Target and RLP Over Time */}
              <div
                id="readingTarget"
                style={{
                  height: "526px",
                  width: "150px",
                  overflow: "hidden",
                  marginTop: "20px",
                  position: "relative"
                }}
              >
                <div className="sub-first-back-rhs" />
                <div className="sub-first-back-rhs-blue" />
                <svg
                  width={startLevelWidth + 50}
                  height={totalHeight + scrollSVGHeight + 75}
                >
                  <Group>
                    <g>
                      <rect
                        x={81.434}
                        y={17.657}
                        opacity={1}
                        width={2}
                        height={558}
                        fill="#D6DBE5"
                      />
                    </g>
                  </Group>
                  <Group>
                    <g>
                      <rect
                        x={-1.566}
                        y={22.657}
                        opacity={opacityValueTargetLevel}
                        width={80}
                        height="100%"
                        fill="#D6DBE5"
                      />
                    </g>
                    <g>
                      <circle
                        cx={40}
                        cy={
                          readingLevelAxis.findIndex(
                            item =>
                              item.levelName ===
                              studentReadingTarget.readingTarget
                          ) *
                          yBlockHeight +
                          yBlockHeight / 2 +
                          70
                        }
                        r="26"
                        strokeWidth="4px"
                        stroke="#32AC41"
                        fill="#fff"
                      />
                      <text
                        transform={`translate(${35}, ${readingLevelAxis.findIndex(
                          item =>
                            item.levelName ===
                            studentReadingTarget.readingTarget
                        ) *
                          yBlockHeight +
                          yBlockHeight / 2 +
                          75})`}
                        fontFamily="Quicksand"
                        fill="#000"
                        fontWeight="500"
                        fontSize="16"
                      >
                        {studentReadingTarget.readingTarget}
                      </text>
                    </g>
                  </Group>
                  <g>
                    <rect
                      x={85.634}
                      y={22.657}
                      width={55}
                      height="100%"
                      fill="#C5E4ED"
                    />
                  </g>
                </svg>
              </div>
            </div>

            {/* SVG for horizontal scroll at X,Y */}
            <div className="date-range-viewport">
              <svg height={30} width="0">
                {/* Change width to 60 for getting the lines */}
                <rect
                  x="58.434"
                  y="1.657"
                  opacity="0.7"
                  width="2"
                  height="30"
                  fill="#D6DBE5"
                />
                <rect
                  x="0.434"
                  y="3.657"
                  opacity="0.7"
                  width="60"
                  height="2"
                  fill="#D6DBE5"
                />
              </svg>
              <div
                className={
                  this.state.firstIcon ? "x-prev-end-active" : "x-prev-end"
                }
                onClick={() => this.navigateAllLeft(data.length, xBlockWidth)}
              />
              <div
                className={this.state.previousIcon ? "x-prev-active" : "x-prev"}
                onClick={() => this.navigateLeft(xBlockWidth)}
              />
              {/* SVG for X-Axis */}
              <div
                id="xAxis"
                style={{
                  maxWidth: "782px",
                  overflow: "hidden",
                  marginLeft: "10px"
                }}
              >
                <div className="hor-line" />
                <svg width={totalWidth} height={scrollSVGHeight}>
                  <Group
                    left={-10}
                    top={-579}
                    width={totalWidth}
                    fill="#242424"
                  >
                    <AxisBottom
                      axisLineClassName="xaxisLine"
                      scale={xScale}
                      top={height - 15}
                      left={10}
                      stroke="transparent"
                      width={totalWidth}
                      tickStroke={"#fff"}
                      tickSize={0}
                      tickLabelProps={(tickValue, index) => ({
                        index: index,
                        textAnchor: "middle",
                        fontSize: 10,
                        fill: "#fff"
                      })}
                      tickComponent={(
                        { formattedValue, x, y, ...tickProps },
                        i
                      ) => (
                          <g
                            transform={`translate(${x + this.setX(x, i)}, ${y -
                              24})`}
                            {...tickProps}
                          >
                            <path
                              className="rhombus"
                              x={0}
                              y={0}
                              fill="#bdc2cd"
                              test="M5.9,1.2L0.7,6.5l5.2,5.4l5.2-5.4L5.9,1.2z"
                            />
                            <polygon
                              fill="#bdc2cd"
                              points="6.5,0 1,6 6.5,12 12,6"
                            />
                            <text
                              transform={"translate(6,32)"}
                              fontSize={16}
                              fontFamily="Questrial"
                              fill="#333333"
                            >
                              {this.dateFunction(formattedValue)}
                            </text>
                          </g>
                        )}
                    />
                  </Group>
                </svg>
              </div>
              <div
                className={this.state.nextIcon ? "x-next-active" : "x-next"}
                onClick={() => this.navigateRight(data.length, xBlockWidth)}
              />
              <div
                className={
                  this.state.lastIcon ? "x-next-end-active" : "x-next-end"
                }
                onClick={() => this.navigateAllRight(data.length, xBlockWidth)}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default AxisChart;
