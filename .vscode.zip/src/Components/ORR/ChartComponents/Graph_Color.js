

var getHexCode = [];
var setBubbleOject = {
  bubbleSize: '',
  fontSize: ''
};
var backgroundColorList = [
  { value: 'AA', hexcode: 'rgba(237,0,141,0.1)' },
  { value: 'A', hexcode: 'rgba(238,59,51,0.1)' },
  { value: 'B', hexcode: 'rgba(238,59,51,0.1)' },
  { value: 'C', hexcode: 'rgba(238,59,51,0.1)' },
  { value: 'D', hexcode: 'rgba(145,72,157,0.1)' },
  { value: 'E', hexcode: 'rgba(145,72,157,0.1)' },
  { value: 'PreA', hexcode: 'rgba(189,194,205,0.1)' },
  { value: 'F', hexcode: 'rgba(0,124,195,0.1)' },
  { value: 'G', hexcode: 'rgba(0,124,195,0.1)' },
  { value: 'H', hexcode: 'rgba(0,164,138,0.1)' },
  { value: 'I', hexcode: 'rgba(0,164,138,0.1)' },
  { value: 'J', hexcode: 'rgba(249,153,28,0.1)' },
  { value: 'K', hexcode: 'rgba(249,153,28,0.1)' },
  { value: 'L', hexcode: 'rgba(28,68,156,0.1)' },
  { value: 'M', hexcode: 'rgba(28,68,156,0.1)' },
  { value: 'N', hexcode: 'rgba(0,172,212,0.1)' },
  { value: 'O', hexcode: 'rgba(0,172,212,0.1)' },
  { value: 'P', hexcode: 'rgba(0,172,212,0.1)' },
  { value: 'Q', hexcode: 'rgba(245,114,36,0.1)' },
  { value: 'R', hexcode: 'rgba(245,114,36,0.1)' },
  { value: 'S', hexcode: 'rgba(0,164,138,0.1)' },
  { value: 'T', hexcode: 'rgba(0,164,138,0.1)' },
  { value: 'U', hexcode: 'rgba(0,164,138,0.1)' },
  { value: 'V', hexcode: 'rgba(28,68,156,0.1)' },
  { value: 'W', hexcode: 'rgba(28,68,156,0.1)' },
  { value: 'X', hexcode: 'rgba(28,68,156,0.1)' },
  { value: 'Y', hexcode: 'rgba(238,59,51,0.1)' },
  { value: 'Z', hexcode: 'rgba(238,59,51,0.1)' },
  { value: 'Z+', hexcode: 'rgba(238,59,51,0.1)' }
];
var axisColorList = [
  { value: 'AA', hexcode: '#ED008D' },
  { value: 'A', hexcode: '#EE3B33' },
  { value: 'B', hexcode: '#EE3B33' },
  { value: 'C', hexcode: '#EE3B33' },
  { value: 'D', hexcode: '#91489d' },
  { value: 'E', hexcode: '#91489d' },
  { value: 'PreA', hexcode: '#BDC2CD' },
  { value: 'F', hexcode: '#007cc3' },
  { value: 'G', hexcode: '#007cc3' },
  { value: 'H', hexcode: '#00a48a' },
  { value: 'I', hexcode: '#00a48a' },
  { value: 'J', hexcode: '#f9991c' },
  { value: 'K', hexcode: '#f9991c' },
  { value: 'L', hexcode: '#1c449c' },
  { value: 'M', hexcode: '#1c449c' },
  { value: 'N', hexcode: '#00acd4' },
  { value: 'O', hexcode: '#00acd4' },
  { value: 'P', hexcode: '#00acd4' },
  { value: 'Q', hexcode: '#f57224' },
  { value: 'R', hexcode: '#f57224' },
  { value: 'S', hexcode: '#00a48a' },
  { value: 'T', hexcode: '#00a48a' },
  { value: 'U', hexcode: '#00a48a' },
  { value: 'V', hexcode: '#1c449c' },
  { value: 'W', hexcode: '#1c449c' },
  { value: 'X', hexcode: '#1c449c' },
  { value: 'Y', hexcode: '#ee3b33' },
  { value: 'Z', hexcode: '#ee3b33' },
  { value: 'Z+', hexcode: '#ee3b33' }
];
var bubbleColorList = [
  { value: 'Instructional', hexcode: '#32ac41' },
  { value: 'Independent', hexcode: '#008ad9' },
  { value: 'Frustrational', hexcode: '#ffc52d' }
];
var bubbleConfiguration = [
  { valueFrom: 0, valueTo: 9, bubbleSize: '28px', fontSize: '12px' },
  { valueFrom: 10, valueTo: 19, bubbleSize: '32px', fontSize: '12px' },
  { valueFrom: 20, valueTo: 29, bubbleSize: '36px', fontSize: '12px' },
  { valueFrom: 30, valueTo: 39, bubbleSize: '40px', fontSize: '12px' },
  { valueFrom: 40, valueTo: 49, bubbleSize: '44px', fontSize: '12px' },
  { valueFrom: 50, valueTo: 59, bubbleSize: '48px', fontSize: '14px' },
  { valueFrom: 60, valueTo: 69, bubbleSize: '52px', fontSize: '14px' },
  { valueFrom: 70, valueTo: 79, bubbleSize: '56px', fontSize: '14px' },
  { valueFrom: 80, valueTo: 89, bubbleSize: '60px', fontSize: '14px' },
  { valueFrom: 90, valueTo: 100, bubbleSize: '60px', fontSize: '14px' }
];
var bubbleBackgroundOnSelectionArray = [
  { value: 'Instructional', hexcode: 'rgba(50, 172, 65, 0.7)' },
  { value: 'Independent', hexcode: 'rgba(0, 138, 217, 0.7)' },
  { value: 'Frustrational', hexcode: 'rgba(255, 197, 45, 0.7)' }
];
export function backgroundColor(value) {
  backgroundColorList.findIndex((item, index) => {
    if (item.value === value) {
      getHexCode = backgroundColorList[index].hexcode;
    }
  });
  return getHexCode;
}

export function axisColor(value) {
  axisColorList.findIndex((item, index) => {
    if (item.value === value) {
      getHexCode = axisColorList[index].hexcode.toString();
    }
  });
  return getHexCode;
}

export function bubbleColor(value) {
  bubbleColorList.findIndex((item, index) => {
    if (item.value === value) {
      getHexCode = bubbleColorList[index].hexcode.toString();
    }
  });
  return getHexCode;
}
export function setBubbleConfiguration(value) {
  bubbleConfiguration.findIndex((item, index) => {
    if (value >= item.valueFrom && value <= item.valueTo) {
      setBubbleOject = {
        bubbleSize: bubbleConfiguration[index].bubbleSize.toString(),
        fontSize: bubbleConfiguration[index].fontSize.toString()
      };
    }
  });
  return setBubbleOject;
}
export function bubbleBackgroundOnSelection(value) {
  bubbleBackgroundOnSelectionArray.findIndex((item, index) => {
    if (item.value === value) {
      getHexCode = bubbleBackgroundOnSelectionArray[index].hexcode.toString();
    }
  });
  return getHexCode;
}
