import React, { Component } from 'react';
import '../../../../public/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';
import '../ReadingHistoryComponents/ReadingHistory.css';
import {
  SORT_COLUMN,
  SORTED_S_READING_HISTORY_DATA
} from '../../../Redux_Actions/ReadingHistoryActions';

import { connect } from 'react-redux';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';

class ReadingHistoryTable extends Component {
  constructor(props) {
    super(props);

    this.historyApiCall = this.historyApiCall.bind(this);
    this.sortData = this.sortData.bind(this);
    this.showToolTip = this.showToolTip.bind(this);
  }

  //Onclick calling sort function and update the sort type and column in store
  historyApiCall(sortColumn, sortType, actualArray) {
    document.getElementById('srh').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_COLUMN(sortColumn, sortType);
  }

  //display reading level
  showToolTip(text) {
    if (text.length > 18) {
      return (
        <React.Fragment>
          <span>{text.substr(0, 18)}...</span>
          <div className="tooltip-container word-bk ">
            <span>{text}</span>
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (<span>{text}</span>)
    }

  }

  displayReadingLevel(startingLevel, readingTarget) {
    if (startingLevel && readingTarget) {
      return (
        <div>
          <span className="column-level fixed-strip">
            Starting Level : <b>{startingLevel}</b>
          </span>
          <span className="column-level fixed-strip">
            Target Level : <b>{readingTarget}</b>
          </span>
        </div>
      );
    }
    if (readingTarget) {
      return (
        <div className="column-width fixed-strip">
          Target Level : <b>{readingTarget}</b>
        </div>
      );
    }
    if (startingLevel) {
      return (
        <div className="column-width fixed-strip">
          Starting Level : <b>{startingLevel}</b>
        </div>
      );
    }
  }
  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);

      let currentNav = this.props.NavigationByHeaderSelection;
      this.props.SORTED_S_READING_HISTORY_DATA(
        sortedArray,
        column,
        sortType,
        currentNav
      );
    }
  }

  /**
   * @param {Array} actualArray --Complete List
   * @param { Object } Data --  Data about column and sort type.
   */
  ReadingHistoryHeaderAndData(Data, actualArray, print, readingLevel) {
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div>
        <div className="container container-alignment rho-container rhoth">
          <div className="row">
            <div className="col-lg-12 pt-8">
              <div className="student-list-header rho-header srho-width">
                {this.returnColumnBasedOnDate(Data, actualArray)}
                {this.returnColumnBasedOnReadingLevel(Data, actualArray)}
                {this.returnColumnBasedOnProficiency(Data, actualArray)}
                {this.returnColumnBasedOnLastPassage(Data, actualArray)}
                {this.returnColumnBasedOnCategory(Data, actualArray)}
                {this.returnColumnBasedOnAccuracy(Data, actualArray)}
                {this.returnColumnBasedOnSelfCorrection(Data, actualArray)}
                {this.returnColumnBasedOnFluency(Data, actualArray)}
                {this.returnColumnBasedOnRetelling()}
                {this.returnColumnBasedOnComprehension(Data, actualArray)}
              </div>
              <div
                className={'student-list-body ' + (print ? '' : 'scroll-body')}
                id="srh"
              >
                {actualArray.map((student, value) => (
                  <div className="student-list-row pos-rel" key={value}>
                    <div className="student-column-list">
                      <span> {student.assignmentDate}</span>
                    </div>
                    <div className="student-column-list">
                      <span>{student.letterLevel}</span>
                    </div>
                    <div className="student-column-list">
                      <span>{student.proficiency}</span>
                    </div>
                    <div className="student-column-list long-text-tooltip">

                      {student.lastPassage !== null
                        ? this.showToolTip(student.lastPassage)
                        : <span>dashSymbol</span>}

                    </div>
                    <div className="student-column-list">
                      <span className="">
                        {student.category !== null
                          ? student.category
                          : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list">
                      <span>
                        {student.accuracy !== null
                          ? student.accuracy + '%'
                          : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list">
                      <span className="">
                        {student.selfCorrection !== null && student.selfCorrection !== 'NA'
                          ? student.selfCorrection
                          : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list">
                      <span>
                        {student.fluency !== null
                          ? student.fluency + ' wcpm'
                          : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list cfpot-tooltip">
                      <span className="">
                        {student.reTelling !== null
                          ? student.reTelling
                          : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list">
                      <span className="">
                        {student.comprehension !== null
                          ? student.comprehension
                          : dashSymbol}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="table-wrap-slp"></div>
              {/* Need to check for null data */}
              {/* {readingLevel.startingLevel === null &&
        readingLevel.readingTarget === null ? (
          ''
        ) : (
          <div className="table-wrap-slp">
            {this.displayReadingLevel(
              readingLevel.startingLevel,
              readingLevel.readingTarget
            )}
          </div>
        )} */}
            </div>
          </div>
        </div>
      </div>
    );
  }

  //function for Self Correction
  returnColumnBasedOnSelfCorrection(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'selfCorrection'
            ? 'rho-student border-btm'
            : 'rho-student '
        } >Self-Correction</span>
        {/* <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'selfCorrection' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('selfCorrection', 'desc', actualArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'selfCorrection' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('selfCorrection', 'asc', actualArray)
            }
          >
            expand_less
          </i>{' '}
        </span> */}
      </div>
    );
  }

  /**
   *function for Reading Level
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnReadingLevel(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'letterLevel'
            ? 'rho-student border-btm'
            : 'rho-student '
        } >Level</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'letterLevel' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('letterLevel', 'desc', actualArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'letterLevel' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('letterLevel', 'asc', actualArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  /**
   *function for Last Passage
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnLastPassage(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'lastPassage'
            ? 'rho-student border-btm'
            : 'rho-student '
        } >Passage</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'lastPassage' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('lastPassage', 'desc', actualArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'lastPassage' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('lastPassage', 'asc', actualArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  /**
   *function for Proficiency
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnProficiency(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'proficiency'
            ? 'rho-student border-btm'
            : 'rho-student '
        }  >Proficiency</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'proficiency' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('proficiency', 'desc', actualArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'proficiency' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('proficiency', 'asc', actualArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  /**
   *function for Accuracy
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnAccuracy(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'accuracy'
            ? 'rho-student border-btm'
            : 'rho-student '
        } >Accuracy</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'accuracy' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() => this.historyApiCall('accuracy', 'desc', actualArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'accuracy' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() => this.historyApiCall('accuracy', 'asc', actualArray)}
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  /**
   *function for Fluency
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnFluency(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'fluency'
            ? 'rho-student border-btm'
            : 'rho-student '
        }>Fluency</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'fluency' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() => this.historyApiCall('fluency', 'desc', actualArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'fluency' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() => this.historyApiCall('fluency', 'asc', actualArray)}
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //Function for Comprehension
  returnColumnBasedOnComprehension(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'comprehension'
            ? 'rho-student border-btm'
            : 'rho-student '
        }>Comprehension</span>
        {/* <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'comprehension' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('comprehension', 'desc', actualArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'comprehension' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('comprehension', 'asc', actualArray)
            }
          >
            expand_less
          </i>{' '}
        </span> */}
      </div>
    );
  }

  /**
   *function for Date
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnDate(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'assignmentDate'
            ? 'rho-student border-btm'
            : 'rho-student '
        } >Date</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'assignmentDate' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('assignmentDate', 'desc', actualArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'assignmentDate' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.historyApiCall('assignmentDate', 'asc', actualArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //Function for Retelling
  returnColumnBasedOnRetelling() {
    return (
      <div className="student-column-list">
        <span className="rho-student">Retell</span>
      </div>
    );
  }
  /**
   *function for Category
   * @param {Object} Data
   * @param {Array} actualArray -- Array which is using to display records
   * @returns {JSX element}
   */
  returnColumnBasedOnCategory(Data, actualArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'category'
            ? 'rho-student border-btm'
            : 'rho-student '
        }>Category</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'category' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() => this.historyApiCall('category', 'desc', actualArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'category' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() => this.historyApiCall('category', 'asc', actualArray)}
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  render() {
    const Data = this.props.Data;
    let actualArray = this.props.ActualArray;
    let print = this.props.print;
    let readingLevel = this.props.ReadingLevel;

    return (
      <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
        {/* <div className="student-list-table"> */}
        <div className="student-list-table-main  student-table-rlp">
          <div className="student-list-table">
            {this.ReadingHistoryHeaderAndData(
              Data,
              actualArray,
              print,
              readingLevel
            )}
          </div>
        </div>
        {/* </div> */}
      </div>
    );
  }
}

const mapStateToProps = ({ Authentication, Universal }) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;

  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection
  };
};

export default connect(
  mapStateToProps,
  { SORT_COLUMN, SORTED_S_READING_HISTORY_DATA }
)(ReadingHistoryTable);