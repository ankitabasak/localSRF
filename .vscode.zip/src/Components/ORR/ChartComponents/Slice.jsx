import React, { Component } from 'react';
import * as d3 from 'd3';
import '../ErrorAnalysisComponents/ErrorAnalysis.css';

class Slice extends React.Component {
  constructor(props) {
    super(props);
    this.state = { isHovered: false };
    this.onMouseOver = this.onMouseOver.bind(this);
    this.onMouseOut = this.onMouseOut.bind(this);
    this.color = this.color.bind(this);
  }

  onMouseOver() {
    this.setState({ isHovered: true });
  }

  onMouseOut() {
    this.setState({ isHovered: false });
  }

  // color(val, msvError) {
  //   if (msvError) {
  //     const color = ['#16a3a7', '#e1e9e6', '#006b83', '#fdd2bc'];
  //     return color[val.index];
  //   } else {
  //     const color = [
  //       '#ec3c44',
  //       '#ca0f17',
  //       '#bc0b12',
  //       '#a20b11',
  //       '#0099f0',
  //       '#025ed5'
  //     ];
  //     return color[val.index];
  //   }
  // }
  color(val, msvError) {
    if (msvError) {
      const color = ['#16a3a7', '#e1e9e6', '#006b83', '#fdd2bc'];
      return color[val.index];
    } else {
      const color = [
        '#ec3c44',
        '#ca0f17',
        '#bc0b12',
        '#a20b11',
        '#008ad9',
        '#025ed5'
      ];
      return color[val.index];
    }
  }

  arcPoint(arc, outerArc, value) {
    var posA = arc.centroid(value);
    var posB = outerArc.centroid(value);
    var posC = outerArc.centroid(value);
    var midAngle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    posC[0] = 100 * 2.3 * (midAngle < Math.PI ? 1 : -1);

    return [posA, posB, posC];
  }

  textPosition(outerArc, value, msvError) {
    var pos = outerArc.centroid(value);
    var midangle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    var txtPos = this.textPos(value, msvError);
    pos[0] = 100 * txtPos * (midangle < Math.PI ? 1 : -1);
    return 'translate(' + pos + ')';
  }

  lableNamePosition(outerArc, value) {
    var pos = outerArc.centroid(value);
    var midangle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    pos[0] = 100 * 1.3 * (midangle < Math.PI ? 1 : -1);
    // pos[1] = 100 * 0.51 * (pos[1] > 1 ? 1 : -1);
    return 'translate(' + pos + ')';
  }

  textAlignment(value) {
    var midangle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    return midangle < Math.PI ? 'start' : 'end';
  }

  textPos(value, msvError) {
    let position;
    if (msvError) {
      position = ['1.3', '1.3', '1.4', '0.80'];
    } else {
      position = ['1.0', '1.2', '1.23', '1.58', '1.15', '.84'];
    }
    return position[value.index];
  }

  lableName(value, msvError) {
    if (msvError) {
      let lableName = [
        'Meaning',
        'Structural',
        'Visual',
        'MSV Not Scored'
      ];
      return lableName[value.index];
    } else {
      let lableName = [
        'Substitution',
        'Omission',
        'Insertion',
        'Told',
        'Repetition',
        'Self-Correction'
      ];
      return lableName[value.index];
    }
  }

  render() {
    let {
      value,
      label,
      innerRadius = 0,
      outerRadius,
      cornerRadius,
      padAngle,
      msvError
    } = this.props;

    let hover = false;

    if (this.state.isHovered) {
      outerRadius *= 1.05;
      innerRadius *= 0.9;
      padAngle *= -1;
      hover = true;
    }

    let arc = d3
      .arc()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius)
      .cornerRadius(cornerRadius)
      .padAngle(padAngle);

    let outerArc = d3
      .arc()
      .innerRadius(value > 7 ? innerRadius * 1.5 : innerRadius * 2) //1.5
      .outerRadius(value > 25 ? outerRadius * 1.8 : outerRadius * 1.2); //1.5
    return (
      <React.Fragment>
        {value.data ? (
          <g
            onMouseOver={this.onMouseOver}
            onMouseOut={this.onMouseOut}
            {...this.props}
          >
            <path d={arc(value)} fill={this.color(value, msvError)} />
            {value.data !== 0 || this.state.isHovered ? (
              <polyline
                stroke={this.state.isHovered ? '#00539b' : '#606060'}
                fill="none"
                strokeWidth="1px"
                points={this.arcPoint(arc, outerArc, value)}
              />
            ) : (
                ''
              )}

            {value.data !== 0 && hover ? (
              <circle
                className="cur-none"
                transform={`translate(${arc.centroid(value)})`}
                r="4"
                cx="0"
                cy="0"
                fill="#00539b"
                stroke="transparent"
                stroke-width="4"
              />
            ) : (
                ''
              )}
            <text
              fontFamily="Questrial"
              fontSize={msvError ? '15px' : ''}
              transform={this.textPosition(outerArc, value, msvError)}
              dy="-.25em"
              textAnchor={this.textAlignment(value)}
              fill={this.state.isHovered ? '#00539b' : 'black'}
            >
              {value.data != 0
                ? this.lableName(value, msvError) + ' (' + (label + '%') + ')'
                : ''}
            </text>
            {/* <text
          font-family="Questrial"
          transform={this.lableNamePosition(outerArc, value)}
          dy="1.0em"
          textAnchor={this.textAlignment(value)}
          fill={this.state.isHovered ? '#00539b' : 'black'}
        >
          {value.data != 0 ? this.lableName(value, msvError) : ''}
        </text> */}
          </g>
        ) : (
            ''
          )}
      </React.Fragment>
    );
  }
}

export default Slice;
