import React, { Component } from 'react';
import * as d3 from 'd3';
import Slice from './Slice.jsx';

class MsvDonutChart extends Component {
  constructor(props) {
    super(props);
    this.renderSlice = this.renderSlice.bind(this);
  }

  render() {
    const average = this.props.data;
    const msvAverage = [
      average.meaningCues,
      average.structuralCues,
      average.visualCues,
      average.ommissionAndTolds
    ];

    let width = this.props.isMobileView ? 480 : 500;
    let height = 300;
    let x = width / 2;
    let y = height / 2 - 30;
    let pie = d3.pie().sort(null);

    return (
      <svg width="500" height="260">
        <g transform={`translate(${x}, ${y})`} style={{ cursor: 'pointer' }}>
          {pie(msvAverage).map(this.renderSlice)}
        </g>
      </svg>
    );
  }

  renderSlice(value, i) {
    let radius = 80;

    return (
      <Slice
        key={i}
        innerRadius={radius * 0.55}
        outerRadius={radius}
        cornerRadius={0}
        padAngle={0.01}
        value={value}
        label={value.data}
        msvError={true}
      />
    );
  }
}

export default MsvDonutChart;
