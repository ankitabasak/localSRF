import React, { Component } from 'react';
import * as d3 from 'd3';
import Slice from './Slice.jsx';

class ErrorDonutChart extends Component {
  render() {
    const average = this.props.data;
    average.repetation = process.env.ORR_SHOW_REPETITION_BEHAVIOR_MARKUP === 'true' ? average.repetation : 0;
    const errorAverage = [
      average.substitution,
      average.ommission,
      average.insertion,
      average.told,
      average.repetation,
      average.selfCorrection
    ];

    let width = this.props.isMobileView ? 480 : 500;
    let height = 300;
    let radius = 90;
    let x = width / 2;
    let y = height / 2 - 8;
    let pie = d3.pie().sort(null);

    return (
      <svg width="500" height="270">
        <g transform={`translate(${x}, ${y})`} style={{ cursor: 'pointer' }}>
          {pie(errorAverage).map(this.renderSlice)}
        </g>
      </svg>
    );
  }

  renderSlice(value, i) {
    let radius = 80;

    return (
      <Slice
        key={i}
        innerRadius={radius * 0.55}
        outerRadius={radius}
        cornerRadius={0}
        padAngle={0.01}
        value={value}
        label={value.data}
      />
    );
  }
}

export default ErrorDonutChart;
