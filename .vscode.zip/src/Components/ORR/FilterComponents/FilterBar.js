import React, { Component } from 'react';
import '../../../../public/css/bootstrap.min.css';
import './Filter.css';
import 'font-awesome/css/font-awesome.min.css';

class FilterBarComponent extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { filterValue } = this.props;
    if (!filterValue) return null;
    return (
      <div>
        {/* <!-- apply filter section start --> */}
        <div className="apply-filter-result">
          <ul>
            <li
              className={filterValue.proficiency.independent ? 'show' : 'hide'}
            >
              <a className="filter-button filter-bg light-blue-bg">
                <i className="fa circle-res light-blue check-circle" />
                Independent
              </a>
            </li>
            <li
              className={
                filterValue.proficiency.instructional ? 'show' : 'hide'
              }
            >
              <a className="filter-button filter-bg instructional-bg">
                <i className="fa circle-res blue check-circle" />
                Instructional
              </a>
            </li>
            <li
              className={
                filterValue.proficiency.frustrational ? 'show' : 'hide'
              }
            >
              <a className="filter-button light-yellow-bg">
                <i className="fa circle-res light-yellow check-circle" />
                Frustrational
              </a>
            </li>
            <li className={filterValue.language.english ? 'show' : 'hide'}>
              <a className="filter-button filter-bg">
                <i className="fa check-circle circle-res light-blue" />
                English
              </a>
            </li>
            <li className={filterValue.language.spanish ? 'show' : 'hide'}>
              <a className="filter-button filter-bg">
                <i className="fa check-circle circle-res light-blue" />
                Spanish
              </a>
            </li>
            <li className={filterValue.category.fiction ? 'show' : 'hide'}>
              <a className="filter-button filter-bg">
                <i className="fa check-circle circle-res light-blue" />
                Fiction
              </a>
            </li>
            <li className={filterValue.category.nonfiction ? 'show' : 'hide'}>
              <a className="filter-button filter-bg">
                <i className="fa check-circle circle-res light-blue" />
                Nonfiction
              </a>
            </li>
            <li className={filterValue.type.unseen ? 'show' : 'hide'}>
              <a className="filter-button filter-bg">
                <i className="fa check-circle circle-res light-blue" />
                Unseen
              </a>
            </li>
            <li className={filterValue.type.seen ? 'show' : 'hide'}>
              <a className="filter-button filter-bg">
                <i className="fa check-circle circle-res light-blue" />
                Seen
              </a>
            </li>
          </ul>
        </div>
        <hr className="line-filter-btm clearfix mb-8" />
        {/* <!-- apply filter section end --> */}
      </div>
    );
  }
}

export default FilterBarComponent;
