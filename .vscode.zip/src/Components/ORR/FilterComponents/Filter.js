import React, { Component } from "react";
import "../../../../public/css/bootstrap.min.css";
import "./Filter.css";
import "font-awesome/css/font-awesome.min.css";
import titleImg from "../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg";
import { GET_SELECTED_DATA } from "../../../Redux_Actions/FilterActions";
import FilterBarComponent from "./FilterBar";
import { connect } from "react-redux";
import References from "../../../../public/assets/orr/rlp-screen/references_ic.svg";
import { selRadio, SAVE_SELECTED_FILTER, RESET_FILTER } from "../../../Redux_Actions/CommonFilterActions.jsx";
import { READING_HISTORY_STUDENT_DATA } from "../../../Redux_Actions/ReadingHistoryActions";
import { ERROR_ANALYSIS_STUDENT_DATA } from "../../../Redux_Actions/ErrorAnalysisActions.jsx";
import { CLASS_READING_HISTORY_DATA, CLASS_RH_ERRORHANDLING } from "../../../Redux_Actions/C_ReadingHistoryActions.jsx";
import {
  CRB_Chart_API_Call,
  Chart_loading_Failed
} from "../../../Redux_Actions/CRB_Actions.jsx";
import {
  Fluency_Chart_Api_Request,
  CLASS_FPO_API,
  API_LOADER
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import { S_RB_API_CALL } from "../../../Redux_Actions/S_ReadingBehaviorActions.jsx";
import {
  CLASS_EA_API,
  LOAD_STATUS_ICON
} from "../../../Redux_Actions/C_ErrorAnalysisAction.jsx";
import {
  School_EA_Dropdown,
  SCHOOL_EA_API,
  SCHOOL_LOAD_STATUS_ICON
} from "../../../Redux_Actions/School_ErrorAnalysisAction.jsx";
import {
  SCHOOL_FPOT_API_SUCCESS,
  LOAD_ICON,
  FA_LOAD_ICON,
  SCHOOL_FA_CHART_API_CALL,
  Sc_GRADES
} from "../../../Redux_Actions/School_FA_Action.jsx";
import {
  SCHOOL_READING_HISTORY_DATA,
  SCHOOL_RH_ERRORHANDLING
} from "../../../Redux_Actions/School_ReadingHistoryAction.jsx";
import {
  School_RB_Chart_API_Call,
  School_RB_Dropdown,
  Show_loading_Icon
} from "../../../Redux_Actions/School_RB_Actions.jsx";
import {
  DISTRICT_READING_HISTORY_DATA,
  DISTRICT_RH_ERRORHANDLING
} from "../../../Redux_Actions/District_ReadingHistoryAction.jsx";
import {
  School_Level_RLP_Chart_API,
  School_Class_Level_RLP_Chart_API,
  School_Show_loading_Icon
} from "../../../Redux_Actions/School_RlpActions.jsx";
import {
  CLASS_READING_LEVEL_PROGRESS,
  CLASS_READING_LEVEL_GRID_DATA,
  CHART_SPINNER
} from "../../../Redux_Actions/C_ReadingLevelAction.jsx";
import {
  District_Class_Level_RLP_Chart_API,
  District_Level_RLP_Chart_API
} from "../../../Redux_Actions/District_RlpActions.jsx";
import {
  DISTRICT_FA_CHART_API_CALL, DFA_LOAD_ICON
} from "../../../Redux_Actions/District_FA_Action.jsx";
import {
  S_Fluency_Chart_Data,
  LOADER_ICON
} from "../../../Redux_Actions/S_FluencyActions.jsx";
import { S_RLP_API_CALL, Student_loading_Icon } from "../../../Redux_Actions/S_ReadingLevelAction.jsx";
import { SHOW_HIDE_GROUPING } from "../../../Redux_Actions/C_GroupingAction.jsx";
import { getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
class Filter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      proficiency: {
        independent: props.CommonFilterData.proficiency.independent,
        instructional: props.CommonFilterData.proficiency.instructional,
        frustrational: props.CommonFilterData.proficiency.frustrational
      },
      language: {
        english: props.CommonFilterData.language.english,
        spanish: props.CommonFilterData.language.spanish
      },
      category: {
        fiction: props.CommonFilterData.category.fiction,
        nonfiction: props.CommonFilterData.category.nonfiction
      },
      type: {
        unseen: props.CommonFilterData.type.unseen,
        seen: props.CommonFilterData.type.seen
      },
      filter: false,
    };

    this.ToggleFilter = this.ToggleFilter.bind(this);
    this.OnChange = this.OnChange.bind(this);
    this.OnFilterMultipleUpdate = this.OnFilterMultipleUpdate.bind(this);
    this.toggleHidden = this.toggleHidden.bind(this);
  }

  componentDidMount() {
    this.setState({ filter: !this.state.filter });
    !this.state.filter && this.props.RESET_FILTER(this.props.filerDataSaved)
  }
  //  Toggle function for filter
  ToggleFilter() {
    this.setState({ filter: !this.state.filter });
    !this.state.filter && this.props.RESET_FILTER(this.props.filerDataSaved)
  }


  //Function to update the state value based on selection
  OnChange(data, key) {
    if (
      this.props.CommonFilterData.proficiency.hasOwnProperty(key) &&
      this.props.CommonFilterData.proficiency[key] === data
    ) {
      this.props.selRadio({
        proficiency: {
          proficiency: {
            ...this.props.CommonFilterData.proficiency,
            [key]: !this.props.CommonFilterData.proficiency[key] //to update the variable keys
          }
        },
        key: 'proficiency'
      })
    }
    if (
      this.props.CommonFilterData.language.hasOwnProperty(key) &&
      this.props.CommonFilterData.language[key] === data
    ) {
      this.props.selRadio({
        language: {
          language: {
            ...this.props.CommonFilterData.language,
            [key]: !this.props.CommonFilterData.language[key]
          }
        }, key: 'language'
      });
    }
    if (
      this.props.CommonFilterData.category.hasOwnProperty(key) &&
      this.props.CommonFilterData.category[key] === data
    ) {
      this.props.selRadio({
        category: {
          category: {
            ...this.props.CommonFilterData.category,
            [key]: !this.props.CommonFilterData.category[key]
          }
        }, key: 'category'
      });
    }
    if (this.props.CommonFilterData.type.hasOwnProperty(key) &&
      this.props.CommonFilterData.type[key] === data) {
      this.props.selRadio({
        type: {
          type: {
            ...this.props.CommonFilterData.type,
            [key]: !this.props.CommonFilterData.type[key]
          }
        }, key: 'type'
      });
    }
  }

  //Function to update the store values and show the filter bar based on api response
  OnFilterMultipleUpdate() {
    if (this.props.NavigationByHeaderSelection.student) {
      let Req_Payload = getCommonHeaders(this.props, 'student');

      if (this.props.NavigationByHeaderSelection.rlp) {
        this.props.Student_loading_Icon('')
        this.props.S_RLP_API_CALL(
          this.props.LoginDetails.JWTToken,
          Req_Payload,
          "student"
        );
      }
      if (this.props.NavigationByHeaderSelection.readingHistory) {
        this.props.READING_HISTORY_STUDENT_DATA(
          this.props.LoginDetails.JWTToken,
          Req_Payload,
          "student"
        );
      }
      if (this.props.NavigationByHeaderSelection.errorAnalysis) {
        this.props.ERROR_ANALYSIS_STUDENT_DATA(
          this.props.LoginDetails.JWTToken,
          Req_Payload,
          "student"
        );
      }
      if (this.props.NavigationByHeaderSelection.fluencyAnalysis) {
        this.props.S_Fluency_Chart_Data(this.props.LoginDetails.JWTToken, Req_Payload, "student");
      }
      if (this.props.NavigationByHeaderSelection.readingBehaviors) {
        this.props.S_RB_API_CALL(
          this.props.LoginDetails.JWTToken,
          Req_Payload,
          "student"
        );
      }
    }
    if (this.props.NavigationByHeaderSelection.class) {
      let payLoad = {
        ...getCommonHeaders(this.props, 'class')
      };
      // rlp onclick api call
      if (this.props.NavigationByHeaderSelection.rlp) {
        this.props.CHART_SPINNER();
        this.props.CLASS_READING_LEVEL_PROGRESS(
          this.props.LoginDetails.JWTToken,
          payLoad
        );
      }
      if (this.props.NavigationByHeaderSelection.readingHistory) {
        this.props.CLASS_RH_ERRORHANDLING({
          isApiLoading: true,
          isDataNotAvailable: false,
          timeOut: false
        });
        this.props.CLASS_READING_HISTORY_DATA(
          this.props.LoginDetails.JWTToken,
          payLoad
        );
      }

      if (this.props.NavigationByHeaderSelection.fluencyAnalysis) {
        this.props.API_LOADER({
          isApiLoading: true,
          apiLoadFail: false,
          apiTimeOut: false,
          noChartData: false
        });
        if (this.props.FluencyTabSelection.wcpm) {
          this.props.Fluency_Chart_Api_Request(
            this.props.LoginDetails.JWTToken,
            payLoad
          );
        }

        if (this.props.FluencyTabSelection.fpot) {
          let cfaRecType = {
            allRecords: this.props.recType === "all" ? true : false,
            recentRecord: this.props.recType === "rec" ? true : false
          };
          this.props.CLASS_FPO_API(this.props.LoginDetails.JWTToken, {
            ...payLoad,
            ["dataRecordType"]: cfaRecType
          });
        }
      }
      if (this.props.NavigationByHeaderSelection.readingBehaviors) {
        this.props.Chart_loading_Failed({
          noChartData: false,
          apiLoadFail: false,
          timeout: false,
          isApiLoading: true
        });

        this.props.CRB_Chart_API_Call(
          this.props.LoginDetails.JWTToken,
          payLoad
        );
      }
      if (this.props.NavigationByHeaderSelection.errorAnalysis) {
        let errorRecType = {
          allRecords: this.props.errorRecordType === "all" ? true : false,
          recentRecord: this.props.errorRecordType === "rec" ? true : false
        };
        this.props.LOAD_STATUS_ICON();
        this.props.CLASS_EA_API(this.props.LoginDetails.JWTToken, {
          ...payLoad,
          ["errorRecordType"]: errorRecType
        });
      }
    }
    if (this.props.NavigationByHeaderSelection.school) {
      let commonHeaders = getCommonHeaders(this.props, 'school');

      let payLoad = {
        ...commonHeaders,
        grade: this.props["grade"]
      };
      if (this.props.NavigationByHeaderSelection.rlp) {
        this.props.School_Show_loading_Icon();
        if (this.props.chartDisplay === "SLRLP") {
          this.props.School_Level_RLP_Chart_API(
            this.props.LoginDetails.JWTToken,
            payLoad
          );
        } else {
          this.props.School_Class_Level_RLP_Chart_API(
            this.props.LoginDetails.JWTToken,
            payLoad
          );
        }
      }
      if (this.props.NavigationByHeaderSelection.readingHistory) {
        // let internalFilter = this.props.CommonFilterData;
        let payLoad = getCommonHeaders(this.props, 'school');
        this.props.SCHOOL_RH_ERRORHANDLING({
          isApiLoading: true,
          isDataNotAvailable: false,
          timeOut: false
        });
        this.props.SCHOOL_READING_HISTORY_DATA(
          this.props.LoginDetails.JWTToken,
          payLoad
        );
      }
      if (this.props.NavigationByHeaderSelection.errorAnalysis) {

        let payload = {
          ["errorRecordType"]: this.props.errorRecordType,
          ...{
            internalFilter: commonHeaders.internalFilter,
            externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScEA" })
          },
        };
        this.props.LOAD_STATUS_ICON();
        this.props.School_EA_Dropdown(this.props.LoginDetails.JWTToken, payload, this.props.ContextHeader.Roster_Tab.selectedRosterGrade);
      }
      if (this.props.NavigationByHeaderSelection.fluencyAnalysis) {
        let payLoad = {
          internalFilter: commonHeaders.internalFilter,
          externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScFR" })
        }
        let grade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
        if (this.props.tabName["fpot"]) {

          let dataRecordType = {
            allRecords: this.props.recType === "all" ? true : false,
            recentRecord: this.props.recType === "rec" ? true : false
          };
          this.props.LOAD_ICON({
            isApiLoading: true,
            apiTimeOut: false,
            hideChart: true
          });

          let gradePayLoad = {
            internalFilter: commonHeaders.internalFilter,
            externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScFR" })
          }

          this.props.Sc_GRADES(this.props.LoginDetails.JWTToken, gradePayLoad, grade,
            'rec');

        } else if (this.props.tabName["wcpm"]) {
          let selCxtGrade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
          let payLoad = commonHeaders;
          this.props.FA_LOAD_ICON();
          this.props.SCHOOL_FA_CHART_API_CALL(this.props.LoginDetails.JWTToken, {
            ...payLoad
          }, selCxtGrade);
        }
      }
      if (this.props.NavigationByHeaderSelection.readingBehaviors) {
        let grade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
        this.props.Show_loading_Icon();
        let payLoad = {
          internalFilter: commonHeaders.internalFilter,
          externalFilter: Object.assign(commonHeaders.externalFilter, {
            chartName: "ScRB",
            grade: grade ? grade : this.props["grade"]
          })
        }
        this.props.School_RB_Dropdown(
          this.props.LoginDetails.JWTToken,
          payLoad,
          grade
        );
      }
    }
    if (this.props.NavigationByHeaderSelection.district) {
      let commonHeaders = getCommonHeaders(this.props, 'district');
      if (this.props.NavigationByHeaderSelection.rlp) {
        let payLoad = {
          ...commonHeaders,
          grade: this.props.gd
        };
        if (this.props.chartDisplay === "SLRLP") {
          this.props.District_Level_RLP_Chart_API(
            this.props.LoginDetails.JWTToken,
            payLoad
          );
        } else {
          this.props.District_Class_Level_RLP_Chart_API(
            this.props.LoginDetails.JWTToken,
            payLoad
          );
        }
      }

      if (this.props.NavigationByHeaderSelection.fluencyAnalysis) {
        this.props.DFA_LOAD_ICON();
        this.props.DISTRICT_FA_CHART_API_CALL(
          this.props.LoginDetails.JWTToken,
          commonHeaders
        );
      }
      else if (this.props.NavigationByHeaderSelection.readingHistory) {
        this.props.DISTRICT_RH_ERRORHANDLING({
          isApiLoading: true,
          isDataNotAvailable: false,
          timeOut: false
        });
        this.props.DISTRICT_READING_HISTORY_DATA(
          this.props.LoginDetails.JWTToken,
          commonHeaders
        );
      }
    }
    this.props.SAVE_SELECTED_FILTER(this.props.CommonFilterData);
    this.setState({ filter: !this.state.filter });
  }

  // toggle grouping
  toggleHidden() {
    this.props.SHOW_HIDE_GROUPING(true);
  }
  render() {
    let show = this.state.filter ? "" : "show";
    let filterValue = this.props.CommonFilterData;
    return (
      <div className="pos-rel">
        <div>
          <div className="container container-alignment sum-modal-crlp">
            <div className="row">
              <div className="col-lg-12 pt-8 filter-ipad-air-03-20">
                <button
                  className={
                    "pull-left filter-btn padt-2 " +
                    (this.state.filter ? "" : "collapsed")
                  }
                  type="button"
                  onClick={this.ToggleFilter}
                  aria-expanded={!this.state.filter}
                >
                  <span
                    className={
                      "close-icon " +
                      (this.state.filter ? "close-filter" : "close-filter-open")
                    }
                  />
                  <span
                    className={
                      this.state.filter ? "close-filter1" : "close-filter-open1"
                    }
                  >
                    Filters
                  </span>
                </button>
                {/* As per Or-1191 we are commenting this code */}
                {/* <div className="float-sm-right rhs-link pr-18">
                  <ul>
                    <li className="pr-57">
                      <img
                        src={References}
                        width="24"
                        height="20"
                        alt="Reference icon"
                      />
                      References
                    </li>
                    <li className="blank"> </li>
                  </ul>
                </div> */}
                <hr className="line-filter clearfix" />
                <div className={"collapse slide-shadow pl-25 " + show}>
                  {/* Proficiency section start */}
                  <div className="form-group filter-fg">
                    <div className="pull-left Proficiency-wrap">
                      <p className="filter-category-title">Proficiency</p>
                      <div className="box">
                        <div
                          className="action-label"
                          onClick={() =>
                            this.OnChange(
                              filterValue.proficiency.independent,
                              "independent"
                            )
                          }
                        >
                          <button
                            className={
                              "btn btn-rounded filter-bg  " +
                              (filterValue.proficiency.independent
                                ? "light-blue-bg"
                                : "filter-hover")
                            }
                          >
                            <i
                              className={
                                "fa circle-res light-blue " +
                                (filterValue.proficiency.independent
                                  ? "check-circle"
                                  : "check-circle-independent")
                              }
                            />
                            Independent
                          </button>
                        </div>
                        <div
                          className="action-label"
                          onClick={() =>
                            this.OnChange(
                              filterValue.proficiency.instructional,
                              "instructional"
                            )
                          }
                        >
                          <button
                            className={
                              "btn btn-rounded filter-bg " +
                              (filterValue.proficiency.instructional
                                ? "instructional-bg"
                                : "filter-hover")
                            }
                          >
                            <i
                              className={
                                "fa circle-res blue " +
                                (filterValue.proficiency.instructional
                                  ? "check-circle"
                                  : "check-circle-instructional")
                              }
                            />
                            Instructional
                          </button>
                        </div>
                        <div
                          className="action-label"
                          onClick={() =>
                            this.OnChange(
                              filterValue.proficiency.frustrational,
                              "frustrational"
                            )
                          }
                        >
                          <button
                            className={
                              "btn btn-rounded filter-bg " +
                              (filterValue.proficiency.frustrational
                                ? "light-yellow-bg"
                                : "filter-hover")
                            }
                          >
                            <i
                              className={
                                "fa circle-res light-yellow  " +
                                (filterValue.proficiency.frustrational
                                  ? "check-circle"
                                  : "check-circle-frustrational")
                              }
                            />
                            Frustrational
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* Proficiency section end */}
                  {/* Language Section start */}
                  <div className="pull-left language-wrap">
                    <p className="filter-category-title">Language</p>
                    <div className="box">
                      <div
                        className="action-label "
                        onClick={() =>
                          this.OnChange(filterValue.language.english, "english")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterValue.language.english ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa circle-res light-blue " +
                              (filterValue.language.english
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          English
                        </button>
                      </div>
                      <div
                        className="action-label "
                        onClick={() =>
                          this.OnChange(filterValue.language.spanish, "spanish")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterValue.language.spanish ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterValue.language.spanish
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Spanish
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* Language Section end */}

                  {/* <!--Category Section start --> */}
                  <div className="pull-left category-wrap">
                    <p className="filter-category-title">Category</p>
                    <div className="box">
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(filterValue.category.fiction, "fiction")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterValue.category.fiction ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterValue.category.fiction
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Fiction
                        </button>
                      </div>
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(
                            filterValue.category.nonfiction,
                            "nonfiction"
                          )
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterValue.category.nonfiction
                              ? ""
                              : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa circle-res " +
                              (filterValue.category.nonfiction
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Nonfiction
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* <!-- Category Section End --> */}

                  {/* <!--Type Section start --> */}
                  <div className="pull-left type-wrap">
                    <p className="filter-category-title">Type</p>
                    <div className="box">
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(filterValue.type.unseen, "unseen")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterValue.type.unseen ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterValue.type.unseen
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Unseen
                        </button>
                      </div>
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(filterValue.type.seen, "seen")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterValue.type.seen ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterValue.type.seen
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Seen
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* <!-- Type Section End --> */}

                  {/* <!--Type Section start --> */}
                  <div className="pull-left apply-btn-wrap pos-rel">
                    <div
                      className="action-label apply-btn-pos right-81"
                      onClick={() => this.OnFilterMultipleUpdate()}
                    >
                      <a className="btn btn-rounded apply-btn ">Apply</a>
                    </div>
                  </div>
                  {/* <!-- Type Section End --> */}
                  <div className="blank-filter clearfix" />
                </div>

                {/* Based on the response from API show the selected filters onclick of apply */}
                <div
                  className={this.state.filter ? "show" : "hide"}
                  style={{ marginTop: "-6px" }}
                >
                  <FilterBarComponent filterValue={filterValue} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  FilterData,
  Universal,
  CommonFilterDetails,
  DistrictRlpData1,
  classFluency,
  Authentication,
  SummaryTabReducer
}) => {
  // const { Axis_chart, Response } = FilterData;
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { CommonFilterData, filerDataSaved } = CommonFilterDetails;
  const { DistrictRLPState } = DistrictRlpData1;
  const { FluencyTabSelection } = classFluency;
  const { popUp } = SummaryTabReducer;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    FluencyTabSelection,
    DistrictRLPState,
    CommonFilterData,
    popUp,
    filerDataSaved
  };
};

export default connect(mapStateToProps, {
  selRadio,
  GET_SELECTED_DATA,
  S_RLP_API_CALL,
  Student_loading_Icon,
  READING_HISTORY_STUDENT_DATA,
  ERROR_ANALYSIS_STUDENT_DATA,
  CLASS_READING_HISTORY_DATA,
  CLASS_RH_ERRORHANDLING,
  CRB_Chart_API_Call,
  Chart_loading_Failed,
  Fluency_Chart_Api_Request,
  CLASS_FPO_API,
  API_LOADER,
  CLASS_READING_LEVEL_PROGRESS,
  CLASS_READING_LEVEL_GRID_DATA,
  CLASS_EA_API,
  CHART_SPINNER,
  SCHOOL_EA_API,
  School_Level_RLP_Chart_API,
  School_Class_Level_RLP_Chart_API,
  School_Show_loading_Icon,
  LOAD_STATUS_ICON,
  SCHOOL_LOAD_STATUS_ICON,
  District_Class_Level_RLP_Chart_API,
  District_Level_RLP_Chart_API,
  S_Fluency_Chart_Data,
  DISTRICT_FA_CHART_API_CALL,
  DFA_LOAD_ICON,
  SHOW_HIDE_GROUPING,
  LOADER_ICON,
  SCHOOL_READING_HISTORY_DATA,
  School_RB_Chart_API_Call,
  School_RB_Dropdown,
  Show_loading_Icon,
  SCHOOL_RH_ERRORHANDLING,
  DISTRICT_READING_HISTORY_DATA,
  DISTRICT_RH_ERRORHANDLING,
  S_RB_API_CALL,
  LOADER_ICON,
  SCHOOL_FPOT_API_SUCCESS,
  FA_LOAD_ICON,
  LOAD_ICON,
  School_EA_Dropdown,
  SCHOOL_FA_CHART_API_CALL,
  Sc_GRADES,
  SAVE_SELECTED_FILTER,
  RESET_FILTER
})(Filter);
