import React, { Component } from 'react';
import Filter from '../FilterComponents/Filter';
import { connect } from 'react-redux';
import ReadingHistoryTable from '../ChartComponents/RHO';
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  READING_HISTORY_STUDENT_DATA,
  S_RH_ERRORHANDLING,
  SRH_CSVDATA_DOWNLOAD_APICALL,
  SRH_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/ReadingHistoryActions';
import NoRecordsData from '../../../Utils/No_Data_Found';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import PrintS_ReadingHistoryData from '../../ReusableComponents/PrintOrrCharts/ReadingHistoryPrint.jsx';
import { formatDate } from '../../../Utils/globalVars';
import { CSVLink } from "react-csv";

class ReadingHistory extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {}
    };
    this.timeOut = this.timeOut.bind(this);
    this.studentReadingHistoryApi = this.studentReadingHistoryApi.bind(this);
  }

  componentDidMount() {
    this.studentReadingHistoryApi();
  }

  // Download csv data
  downLoadCSVData() {
    this.props.SRH_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.props.SRH_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  timeOut() {
    this.props.S_RH_ERRORHANDLING({
      isApiLoading: false,
      isDataNotAvailable: false,
      timeOut: true
    });
  }

  // Function for Student History Api
  studentReadingHistoryApi() {
    let Token = this.props.LoginDetails.JWTToken;
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.setState({
      ...this.state,
      externalFilter: Req_Payload.externalFilter
    });
    this.props.READING_HISTORY_STUDENT_DATA(Token, Req_Payload, 'student');
  }

  render() {
    let Data = this.props.SortData;
    let studentReadingHistoryData = this.props.ReadingHistoryDetails.data;
    let readingLevel = this.props.ReadingLevel;
    const studentList = this.props.ContextHeader.Roster_Tab.SelectedStudent;
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedStudent.name;
    if (this.props.SRHCSVDownload && this.props.SRHCSVDownload['downloadInProgress'] && this.props.SRHCSVDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SRH_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    return (
      <div>
        {this.props.NavigationByHeaderSelection.student && studentList.id ? (
          <div>
            <Filter externalFilter={this.state.externalFilter} />
            {this.props.ReadingHistoryDetails.data &&
              !this.props.ReadingHistoryDetails.timeOut &&
              !this.props.ReadingHistoryDetails.isDataNotAvailable && (
                <div>
                  <span className="printicon-btn">
                    <PrintS_ReadingHistoryData
                      externalFilter={this.state.externalFilter}
                      selectedFilter={this.props.CommonFilterData}
                      navSelected={this.props.NavigationByHeaderSelection}
                      Data={Data}
                      studentDetails={this.props.ContextHeader}
                      ActualArray={studentReadingHistoryData}
                    />
                  </span>

                  <div id="testStuChart">
                    {this.props.SRHCSVDownload && this.props.SRHCSVDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.SRHCSVDownload['csvData'] && this.props.SRHCSVDownload['csvData']['header']}
                        data={this.props.SRHCSVDownload['csvData'] && this.props.SRHCSVDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        filename={`${csvFileName}.csv`}
                      />}
                    <div className="csv-icon-alignment" onClick={() =>
                      this.props.SRHCSVDownload && !this.props.SRHCSVDownload['downloadInProgress'] &&
                      this.downLoadCSVData()}>
                      {this.props.SRHCSVDownload && this.props.SRHCSVDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <ReadingHistoryTable
                      Data={Data}
                      ActualArray={studentReadingHistoryData}
                      ReadingLevel={readingLevel}
                      print={false}
                    />
                  </div>
                </div>
              )}
            {!this.props.ReadingHistoryDetails.data &&
              this.props.ReadingHistoryDetails.isApiLoading && (
                <Spinner
                  startSpinner={this.props.ReadingHistoryDetails.isApiLoading}
                  showTimeOut={this.timeOut}
                />
              )}
            {!this.props.ReadingHistoryDetails.data &&
              this.props.ReadingHistoryDetails.timeOut && (
                <TimeOut tryAgain={this.studentReadingHistoryApi} />
              )}
            {this.props.ReadingHistoryDetails.chartLoadFail &&
              !this.props.ReadingHistoryDetails.timeOut &&
              !this.props.ReadingHistoryDetails.isApiLoading && (
                <ChartNotLoad tryAgain={this.studentReadingHistoryApi} />
              )}
            {this.props.ReadingHistoryDetails.data &&
              this.props.ReadingHistoryDetails.isDataNotAvailable && (
                <NoRecordsData NodataFound={'dataNotAvail'} />
              )}
          </div>
        ) : (
            <NoRosterData />
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  ReadingHistory,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection
  } = Universal;
  const {
    ReadingHistoryDetails,
    Response,
    SortData,
    ReadingLevel,
    SRHCSVDownload
  } = ReadingHistory;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    ReadingHistoryDetails,
    Response,
    SortData,
    ReadingLevel,
    CommonFilterData,
    SRHCSVDownload

  };
};
// export default ReadingHistory;

export default connect(
  mapStateToProps,
  {
    READING_HISTORY_STUDENT_DATA, S_RH_ERRORHANDLING, SRH_CSVDATA_DOWNLOAD_APICALL,
    SRH_CSVDATA_DOWNLOAD_RESET
  }
)(ReadingHistory);
