import React, { Component } from 'react';
import Filter from '../FilterComponents/Filter';
import { connect } from 'react-redux';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import NoRecordsData from '../../../Utils/No_Data_Found';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  ERROR_ANALYSIS_STUDENT_DATA,
  STUDENT_EA_ERRORHANDLING,
  pieChartState,
  SEA_CSVDATA_DOWNLOAD_APICALL,
  SEA_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/ErrorAnalysisActions.jsx';
import ErrorAnalysisChart from '../ChartComponents/ErrorChart.jsx';
import PrintS_Error_Analysis from '../../ReusableComponents/PrintOrrCharts/ErrorAnalysisPrint.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import { formatDate } from '../../../Utils/globalVars';
class ErrorAnalysis extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false,
      hideErrDonut: false
    };
    this.timeOut = this.timeOut.bind(this);
    this.studentErrorAnalysisApi = this.studentErrorAnalysisApi.bind(this);
  }

  componentDidMount() {
    this.studentErrorAnalysisApi();
  }

  // handle timeout
  timeOut() {
    this.props.STUDENT_EA_ERRORHANDLING({
      isApiLoading: false,
      isDataNotAvailable: false,
      timeOut: true
    });
  }

  studentErrorAnalysisApi() {
    let Token = this.props.LoginDetails.JWTToken;
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.setState({
      ...this.state,
      timeOut: false
    });

    if (this.props && !this.state.timeOut) {
      this.setState({
        ...this.state,
        externalFilter: Req_Payload.externalFilter
      });
      this.props.ERROR_ANALYSIS_STUDENT_DATA(Token, Req_Payload, 'student');
    }
  }

  // Download csv data
  downLoadCSVData() {
    this.props.SEA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.props.SEA_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    let studentList = this.props.ContextHeader.Roster_Tab.SelectedStudent;
    let stEaErrHandler = this.props.S_ErrorAnalysisDetails;
    let headerDetails = this.props.ContextHeader;
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedStudent.name;

    if (this.props.SEACSVDownload && this.props.SEACSVDownload['downloadInProgress'] && this.props.SEACSVDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SEA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    return (
      <div>
        {this.props.NavigationByHeaderSelection.student && studentList.id ? (
          <div>
            <Filter
              externalFilter={this.state.externalFilter}
              internalFilter1={this.props.CommonFilterData}
            />
            {this.props.S_ErrorAnalysisDetails.data &&
              !stEaErrHandler.isDataNotAvailable &&
              !stEaErrHandler.timeOut && (
                <React.Fragment>
                  <div id="testStuChart">
                    {this.props.SEACSVDownload && this.props.SEACSVDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.SEACSVDownload['csvData'] && this.props.SEACSVDownload['csvData']['header']}
                        data={this.props.SEACSVDownload['csvData'] && this.props.SEACSVDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        // filename={"SEA_CSV.csv"} 
                        filename={`${csvFileName}.csv`}
                      />}
                    <div className="csv-icon-alignment" onClick={() => !this.props.SEACSVDownload['downloadInProgress'] && this.downLoadCSVData()}>
                      {this.props.SEACSVDownload && this.props.SEACSVDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <ErrorAnalysisChart
                      dataObject={this.props.S_ErrorAnalysisDetails}
                      studentData={this.props.StudentData}
                      icon={this.props.IconUpdate}
                      dataCount={this.props.dataLength}
                      toggleChart={
                        this.props.PieChartUpdate['errorObj']['toggleChart']
                      }
                      showMsvDiv={this.props.PieChartUpdate.errorObj.showMsvDiv}
                      errorDiv={this.props.PieChartUpdate.errorObj.errorDiv}
                      hideMsvDiv={this.props.PieChartUpdate.errorObj.hideMsvDiv}
                      hideErrDonut={this.props.PieChartUpdate.msvObj.hideErrDonut}
                      isMobileView={this.props.isMobileView}
                    />
                  </div>
                  <span className="printicon-btn">
                    <PrintS_Error_Analysis
                      externalFilter={this.state.externalFilter}
                      selectedFilter={this.props.CommonFilterData}
                      navSelected={this.props.NavigationByHeaderSelection}
                      dataObject={this.props.S_ErrorAnalysisDetails}
                      studentData={this.props.StudentData}
                      studentDetails={this.props.ContextHeader}
                      navIcon={this.props.IconUpdate}
                    />
                  </span>
                </React.Fragment>
              )}

            {!this.props.S_ErrorAnalysisDetails.data &&
              stEaErrHandler.isApiLoading && (
                <Spinner
                  startSpinner={!this.props.S_ErrorAnalysisDetails.data}
                  showTimeOut={this.timeOut}
                />
              )}
            {!stEaErrHandler.isApiLoading && stEaErrHandler.timeOut && (
              <TimeOut tryAgain={this.studentErrorAnalysisApi} />
            )}
            {stEaErrHandler.chartLoadFail &&
              !stEaErrHandler.timeOut &&
              !stEaErrHandler.isApiLoading && (
                <ChartNotLoad tryAgain={this.studentErrorAnalysisApi} />
              )}
            {this.props.S_ErrorAnalysisDetails.data &&
              stEaErrHandler.isDataNotAvailable && (
                <NoRecordsData NodataFound={'dataNotAvail'} />
              )}
          </div>
        ) : (
            <NoRosterData />
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  ErrorAnalysis,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection
  } = Universal;

  const { CommonFilterData } = CommonFilterDetails;
  const {
    S_ErrorAnalysisDetails,
    Response,
    StudentData,
    IconUpdate,
    dataLength,
    PieChartUpdate,
    isMobileView,
    SEACSVDownload
  } = ErrorAnalysis;
  return ({
    LoginDetails,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    Response,
    S_ErrorAnalysisDetails,
    StudentData,
    IconUpdate,
    dataLength,
    CommonFilterData,
    PieChartUpdate, isMobileView,
    SEACSVDownload
  });
};

export default connect(
  mapStateToProps,
  {
    ERROR_ANALYSIS_STUDENT_DATA, STUDENT_EA_ERRORHANDLING, pieChartState,
    SEA_CSVDATA_DOWNLOAD_APICALL,
    SEA_CSVDATA_DOWNLOAD_RESET
  }
)(ErrorAnalysis);
