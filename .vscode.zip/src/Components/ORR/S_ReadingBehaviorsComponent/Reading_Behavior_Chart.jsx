import React, { Component } from 'react';
import Filter from '../FilterComponents/Filter';
import { connect } from 'react-redux';
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  S_RB_API_CALL,
  SHOW_HIDE_BAR,
  SRB_ERROR_HANDLING,
  SRB_SCROLL,
  SRB_CSVDATA_DOWNLOAD_APICALL,
  SRB_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/S_ReadingBehaviorActions.jsx';
import NoRecordsData from '../../../Utils/No_Data_Found';
import NoRosterData from '../../../Utils/NoRoster.js';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import RbTable from './RB_Table.jsx';
import PrintSrb from '../../ReusableComponents/PrintOrrCharts/S_RbPrint.jsx';
import NoFluencyData from '../../../Utils/No_Data.js';
import { CSVLink } from "react-csv";

class StudentReadingBehaviorChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {}
    };
    this.showCollapseAccordion = this.showCollapseAccordion.bind(this);
    this.timeOut = this.timeOut.bind(this);
    this.updateSrbScroll = this.updateSrbScroll.bind(this);
    this.s_ReadingBehaviorApi = this.s_ReadingBehaviorApi.bind(this);
  }

  componentDidMount() {
    this.s_ReadingBehaviorApi();
  }

  showCollapseAccordion(list) {
    this.props.SHOW_HIDE_BAR(list);
  }

  //show timeout
  timeOut() {
    this.props.SRB_ERROR_HANDLING({
      apiLoading: false,
      isDataAvailable: false,
      timeOut: true
    });
  }

  // Function for Student Fluency Api
  s_ReadingBehaviorApi() {
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.setState({
      ...this.state,
      externalFilter: Req_Payload.externalFilter
    });

    this.props.S_RB_API_CALL(
      this.props.LoginDetails.JWTToken,
      Req_Payload,
      'student'
    );
  }

  updateSrbScroll(srbData) {
    this.props.SRB_SCROLL(srbData);
  }

  // Download csv data
  downLoadCSVData() {
    this.props.SRB_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.props.SRB_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    if (this.props.SrbCSVDownload && this.props.SrbCSVDownload['downloadInProgress'] && this.props.SrbCSVDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SRB_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedStudent.name;
    return (
      <div>
        {this.props.NavigationByHeaderSelection.student &&
          this.props.ContextHeader.Roster_Tab.SelectedStudent.id ? (
            <React.Fragment>
              <Filter externalFilter={this.state.externalFilter} />
              {this.props.StudentRBState.srbResponse &&
                !this.props.StudentRBState.timeOut &&
                this.props.StudentRBState.isDataAvailable && (
                  <React.Fragment>
                    <span className="printicon-btn">
                      <PrintSrb
                        scroll={false}
                        selectedFilter={this.props.CommonFilterData}
                        studentDetails={this.props.ContextHeader}
                        navSelected={this.props.NavigationByHeaderSelection}
                        StudentRBState={this.props.StudentRBState}
                      />
                    </span>
                    <div id="testStuChart">
                      {this.props.SrbCSVDownload && this.props.SrbCSVDownload['csvData'] &&
                        <CSVLink
                          ref="groupCSV"
                          headers={this.props.SrbCSVDownload['csvData'] && this.props.SrbCSVDownload['csvData']['header']}
                          data={this.props.SrbCSVDownload['csvData'] && this.props.SrbCSVDownload['csvData']['data']}
                          style={{ display: 'none' }}
                          // filename={"SRB_CSV.csv"}
                          filename={`${csvFileName}.csv`}
                        />}
                      <div className="csv-icon-alignment" onClick={() => !this.props.SrbCSVDownload['downloadInProgress'] && this.downLoadCSVData()}>
                        {this.props.SrbCSVDownload && this.props.SrbCSVDownload['downloadInProgress'] ?
                          <span className="csv_download_icon">
                            <i className="material-icons">autorenew</i>
                          </span> :
                          <span className="csv_download_icon">
                            <img src={CsvIcon} width="20" height="20" />
                          </span>}
                      </div>
                      <RbTable
                        scroll={true}
                        srbResponse={this.props.StudentRBState}
                        showHideAccordion={index =>
                          this.props.SHOW_HIDE_BAR(this.props.StudentRBState.showSrbAccordion, index)
                        }
                        scrollSrb={srcData => this.updateSrbScroll(srcData)}
                      ></RbTable>
                    </div>
                  </React.Fragment>
                )}
              {!this.props.StudentRBState.srbResponse &&
                this.props.StudentRBState.apiLoading && (
                  <Spinner
                    startSpinner={this.props.StudentRBState.apiLoading}
                    showTimeOut={this.timeOut}
                  />
                )}
              {!this.props.StudentRBState.apiLoading &&
                this.props.StudentRBState.timeOut && (
                  <TimeOut tryAgain={this.s_ReadingBehaviorApi} />
                )}
              {this.props.StudentRBState.chartLoadFail &&
                !this.props.StudentRBState.timeOut &&
                !this.props.StudentRBState.apiLoading && (
                  <ChartNotLoad tryAgain={this.s_ReadingBehaviorApi} />
                )}
              {this.props.StudentRBState.srbResponse &&
                !this.props.StudentRBState.isDataAvailable && (
                  <NoRecordsData NodataFound={'dataNotAvail'} />
                )}
              {this.props.StudentRBState.rubricDataMsg &&
                <div>
                  <NoFluencyData NoFluencyData={this.props.StudentRBState.rubricDataMsg} />
                </div>
              }
            </React.Fragment>
          ) : (
            <NoRosterData></NoRosterData>
          )}
      </div>
    );
  }
}

// export default FluencyChart;

const mapStateToProps = ({
  Universal,
  Authentication,
  StudentRbData,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection
  } = Universal;
  const { CommonFilterData } = CommonFilterDetails;
  const { StudentRBState, SrbCSVDownload } = StudentRbData;
  return {
    LoginDetails,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    CommonFilterData,
    StudentRBState,
    SrbCSVDownload
  };
};

export default connect(
  mapStateToProps,
  {
    S_RB_API_CALL, SHOW_HIDE_BAR, SRB_ERROR_HANDLING, SRB_SCROLL, SRB_CSVDATA_DOWNLOAD_APICALL,
    SRB_CSVDATA_DOWNLOAD_RESET
  }
)(StudentReadingBehaviorChart);
