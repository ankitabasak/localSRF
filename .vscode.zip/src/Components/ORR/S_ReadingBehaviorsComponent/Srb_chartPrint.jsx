import React, { Component } from 'react';
import '../S_FluencyComponents/Fluency.css';
import './Srb.css';
import ExtremeLeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-new.svg';
import LeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-new.svg';
import RightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-new.svg';
import ExtremeRightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-new.svg';
import ExtremeLeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-active-new.svg';
import LeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-active-new.svg';
import RightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-active-new.svg';
import ExtremeRightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-active-new.svg';
import TickImg from '../../../../public/assets/orr/rlp-screen/tick_ic.svg';

class SRbChart extends Component {
    constructor(props) {
        super(props);
        this.showTitle = this.showTitle.bind(this);
        this.stdProficiencyType = this.stdProficiencyType.bind(this);
        this.displayTick = this.displayTick.bind(this);
        this.showCriteriaName = this.showCriteriaName.bind(this);
        this.showHoverCname = this.showHoverCname.bind(this);
        this.hoverPerDesc = this.hoverPerDesc.bind(this);
        this.scrollSrbAxis = this.scrollSrbAxis.bind(this);
    }

    displayTick(axisData, stuBehaviorListChartDataList) {
        let flag = false;

        if (stuBehaviorListChartDataList) {
            stuBehaviorListChartDataList.forEach((obj, value) => {
                if (
                    obj.assignmentCompletionDate === axisData.assignmentCompletionDate &&
                    obj.letterLevel === axisData.letterLevel
                ) {
                    flag = true;
                }
            });
        }
        if (flag) {
            return (
                <li>
                    <img src={TickImg}></img>
                </li>
            );
        } else {
            return <li>&nbsp;</li>;
        }
    }

    //to display the last passage
    showTitle(passage) {
        return (
            <div className="hover-title">
                {passage}
                <div className="tooltip-dot" />
            </div>
        );
    }

    //to display the criteria name
    showHoverCname(name) {
        let srbHover = false;
        if (name.length > 40) {
            srbHover = true;
        }
        if (srbHover) {
            return (
                <div className="hover-srb">
                    {name}
                    <div className="tooltip-dot" />
                </div>
            );
        }
    }

    hoverPerDesc(perDes) {
        return (
            <div className="hover-per">
                {perDes}
                <div className="tooltip-per-dot" />
            </div>
        );
    }

    showCriteriaName(text) {
        return text
    }

    //to collapse school
    hideShowAccordion(rubricList) {
        this.props.showHideAccordion({
            index
        });
    }
    //display x axis with proficiency type
    stdProficiencyType(type) {
        switch (type) {
            case 'Instructional':
                return 'ar';
            case 'Independent':
                return 'ar-blue';
            case 'Frustrational':
                return 'ar-yellow';
        }
    }

    //scroll axis

    //scroll axis
    scrollSrbAxis(dataArr, index, scrollType) {
        switch (scrollType) {
            case 'right':
                if (index < dataArr.length - 6) {
                    let sIndex = index + 1;

                    this.props.scrollSrb({
                        ['srbXAxis']: dataArr.slice(sIndex, sIndex + 6),
                        scrollIndex: sIndex
                    });
                }
                return;

            case 'left':
                if (index > 0) {
                    let sIndex = index - 1;
                    this.props.scrollSrb({
                        ['srbXAxis']: dataArr.slice(sIndex, sIndex + 6),
                        scrollIndex: sIndex
                    });
                }
                return;

            case 'extremeRight':
                if (index < dataArr.length - 6) {
                    let sIndex = dataArr.length - 6;

                    this.props.scrollSrb({
                        ['srbXAxis']: dataArr.slice(sIndex, sIndex + 6),
                        scrollIndex: sIndex
                    });
                }
                return;
            case 'extremeLeft':
                if (index > 0) {
                    let sIndex = 0;

                    this.props.scrollSrb({
                        ['srbXAxis']: dataArr.slice(0, 6),
                        scrollIndex: sIndex
                    });
                }
                return;
        }
    }

    render() {
        return (
            <React.Fragment>
                <div
                    className="container srb-container srb-pad-left sRb-container-13-20"
                    style={{ maxWidth: '1024px', paddingLeft: '20px', paddingRight: '0px' }}
                >
                    {/* <div className="srb-border" /> */}
                    <div className="row mt-10 pos-rel sRb-row-13-20" style={{ marginTop: '7px;' }}>
                        <p className="srb-title-lhs-print">Reading Behaviors</p>
                        <p className="srb-title-rhs-print srb-title-12-20">Average</p>
                        <div className="col-lg-12 mt-28 pos-rel">
                            {/* <div className="block-name block-name-print">
                                <span>Assignment</span>
                            </div> */}
                            <div className={"sRb-13-20 student-rb-wrap srb-height " + (this.props.scroll ? "scroll-body" : "print-body")}>
                                <div className="tabs">
                                    <div className="tab full-width ipad-full-width scr-width-12-20">
                                        <div className="divider-line-grey-left sRb-divider-12-20"></div>
                                        <div className="divider-line-grey-right"></div>
                                        {/* table start */}
                                        {this.props.srbResponse.srbDataList.map(
                                            (srbDetails, value) => (
                                                <React.Fragment>
                                                    <div className="clearfix">
                                                        {/* <div className="srb-last-colm ipad-last-col">
                                                            <p className="col-content">Processing Behaviors &amp; Strategies</p>
                                                        </div> */}
                                                        <div
                                                            key={value}
                                                            className={'expanded-group pos-rel expand-13-20 scRb-expand-29-20'

                                                            }
                                                            style={{ backgroundColor: '#d6dbe5' }}
                                                            // to keep last accordion open add this condition for onclick
                                                            onClick={() =>
                                                                this.props.showHideAccordion(value)
                                                            }
                                                        >
                                                            <div className="srb-small-strip"></div>
                                                            <div className="tab-bor"></div>
                                                            <span className="tab-label pos-rel">
                                                                <div
                                                                    className={'srb-lhs-strips'

                                                                    }
                                                                ></div>
                                                                {srbDetails.rubricName}
                                                            </span>
                                                        </div>
                                                        <div
                                                            className={
                                                                'tc-13-20 tab-content show'
                                                            }
                                                        >
                                                            {srbDetails.spbChartDataResultList.map(
                                                                (stuBehaviorList, index) => (
                                                                    <div className="inner-wrap pos-rel clearfix">
                                                                        <div className="srb-line-btm srbline-12-20"></div>
                                                                        <div
                                                                            className={
                                                                                'first-block-13-20 first-block srb-list pos-rel show'
                                                                            }
                                                                            key={index}
                                                                        >
                                                                            <span className="">
                                                                                <p
                                                                                    className={
                                                                                        this.props.srbResponse
                                                                                            .showSrbAccordion[
                                                                                            value
                                                                                        ]
                                                                                            ? 'srb-lhs-strips'
                                                                                            : 'srb-lhs-sub-strips'
                                                                                    }
                                                                                ></p>

                                                                                {this.showCriteriaName(
                                                                                    stuBehaviorList.criteriaName
                                                                                )}
                                                                            </span>
                                                                        </div>
                                                                        <div className="mid-check-section  pos-rel">
                                                                            <div className="srb-avr-pos per-hover srb-hover-12-20">
                                                                                {stuBehaviorList.percentage}%
                                                                                <p className="hover-per-desc">
                                                                                    {this.hoverPerDesc(
                                                                                        stuBehaviorList.description
                                                                                    )}
                                                                                </p>
                                                                            </div>

                                                                            <ul>
                                                                                {this.props.srbResponse.srbXAxis.map(
                                                                                    (axisData, v) =>
                                                                                        this.displayTick(
                                                                                            axisData,
                                                                                            stuBehaviorList.chartDataList
                                                                                        )
                                                                                )}
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                )
                                                            )}
                                                        </div>
                                                    </div>
                                                </React.Fragment>
                                            )
                                        )}

                                        {/* table end */}
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

export default SRbChart;