import React, { Component } from 'react';
import '../S_FluencyComponents/Fluency.css';
import './Srb.css';
import ExtremeLeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-new.svg';
import LeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-new.svg';
import RightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-new.svg';
import ExtremeRightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-new.svg';
import ExtremeLeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-active-new.svg';
import LeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-active-new.svg';
import RightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-active-new.svg';
import ExtremeRightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-active-new.svg';
import TickImg from '../../../../public/assets/orr/rlp-screen/tick_ic.svg';

class RbTable extends Component {
  constructor(props) {
    super(props);
    this.showTitle = this.showTitle.bind(this);
    this.stdProficiencyType = this.stdProficiencyType.bind(this);
    this.displayTick = this.displayTick.bind(this);
    this.showCriteriaName = this.showCriteriaName.bind(this);
    this.showHoverCname = this.showHoverCname.bind(this);
    this.hoverPerDesc = this.hoverPerDesc.bind(this);
    this.scrollSrbAxis = this.scrollSrbAxis.bind(this);
  }

  displayTick(axisData, stuBehaviorListChartDataList) {
    let flag = false;

    if (stuBehaviorListChartDataList) {
      stuBehaviorListChartDataList.forEach((obj, value) => {
        if (
          obj.assignmentCompletionDate === axisData.assignmentCompletionDate &&
          obj.letterLevel === axisData.letterLevel
        ) {
          flag = true;
        }
      });
    }
    if (flag) {
      return (
        <li>
          <img src={TickImg}></img>
        </li>
      );
    } else {
      return <li>&nbsp;</li>;
    }
  }

  //to display the last passage
  showTitle(passage) {
    return (
      <div className="hover-title">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }

  //to display the criteria name
  showHoverCname(name) {
    let srbHover = false;
    if (name.length > 40) {
      srbHover = true;
    }
    if (srbHover) {
      return (
        <div className="hover-srb">
          {name}
          <div className="tooltip-dot" />
        </div>
      );
    }
  }

  hoverPerDesc(perDes) {
    return (
      <div className="hover-per">
        {perDes}
        <div className="tooltip-per-dot" />
      </div>
    );
  }

  showCriteriaName(cName) {
    let mobileView = ((window.innerWidth < 1050))
    let letterCnt = mobileView ? 33 : 40;
    let criteriaName = '';
    if (cName.length > letterCnt) {
      criteriaName = cName.substring(0, letterCnt) + '...';
    } else {
      criteriaName = cName;
    }
    return criteriaName;
  }
  //to collapse school
  hideShowAccordion(rubricList) {
    this.props.showHideAccordion({
      index
    });
  }
  //display x axis with proficiency type
  stdProficiencyType(type) {
    switch (type) {
      case 'Instructional':
        return 'ar';
      case 'Independent':
        return 'ar-blue';
      case 'Frustrational':
        return 'ar-yellow ';
    }
  }

  //scroll axis

  //scroll axis
  scrollSrbAxis(dataArr, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataArr.length - 7) {
          let sIndex = index + 1;

          this.props.scrollSrb({
            ['srbXAxis']: dataArr.slice(sIndex, sIndex + 7),
            scrollIndex: sIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let sIndex = index - 1;
          this.props.scrollSrb({
            ['srbXAxis']: dataArr.slice(sIndex, sIndex + 7),
            scrollIndex: sIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataArr.length - 7) {
          let sIndex = dataArr.length - 7;

          this.props.scrollSrb({
            ['srbXAxis']: dataArr.slice(sIndex, sIndex + 7),
            scrollIndex: sIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let sIndex = 0;

          this.props.scrollSrb({
            ['srbXAxis']: dataArr.slice(0, 7),
            scrollIndex: sIndex
          });
        }
        return;
    }
  }

  render() {
    return (
      <React.Fragment>
        <div
          className="container srb-container"
          style={{ maxWidth: '1024px', paddingLeft: '0px', paddingRight: '0px' }}
        >
          {/* <div className="srb-border" /> */}
          <div className="row mt-10" style={{ marginTop: '7px;' }}>
            <div className="col-lg-12 mt-28 pos-rel IpadAir-align-07-20">
              <div className={"student-rb-wrap srb-height " + (this.props.scroll ? "scroll-body" : "print-body")}>
                <div className="tabs">
                  <div className="tab full-width ipad-full-width">
                    <div className="divider-line-grey-left"></div>
                    <div className="divider-line-grey-right"></div>
                    {/* table start */}
                    {this.props.srbResponse.srbDataList.map(
                      (srbDetails, value) => (
                        <React.Fragment>
                          <div className="srb clearfix">
                            <div className="srb-last-colm ipad-last-col">
                              <p className="col-content">Processing Behaviors &amp; Strategies</p>
                            </div>
                            <div
                              key={value}
                              className={
                                this.props.srbResponse.showSrbAccordion[
                                  value
                                ]
                                  ? 'expanded-group pos-rel'
                                  : 'collapsed-group pos-rel'
                              }
                              style={{ backgroundColor: '#d6dbe5' }}
                              // to keep last accordion open add this condition for onclick
                              onClick={() =>
                                this.props.showHideAccordion(value)
                              }
                            >
                              <div className="srb-small-strip"></div>
                              <div className="tab-bor"></div>
                              <span className="tab-label pos-rel">
                                <div
                                  className={
                                    this.props.srbResponse.showSrbAccordion[
                                      value
                                    ]
                                      ? 'srb-lhs-strips'
                                      : 'srb-lhs-sub-strips'
                                  }
                                ></div>
                                {srbDetails.rubricName}
                              </span>
                            </div>
                            <div
                              className={
                                'tab-content ' +
                                (this.props.srbResponse.showSrbAccordion[
                                  value
                                ]
                                  ? 'show'
                                  : 'hide')
                              }
                            >
                              {srbDetails.spbChartDataResultList.map(
                                (stuBehaviorList, index) => (
                                  <div className="inner-wrap pos-rel clearfix">
                                    <div className="srb-line-btm"></div>
                                    <div
                                      className={
                                        'first-block srb-list ' +
                                        (this.props.srbResponse
                                          .showSrbAccordion[
                                          value
                                        ]
                                          ? 'show'
                                          : 'hide')
                                      }
                                      key={index}
                                    >
                                      <span className="pos-rel">
                                        <p
                                          className={
                                            this.props.srbResponse
                                              .showSrbAccordion[
                                              value
                                            ]
                                              ? 'srb-lhs-strips'
                                              : 'srb-lhs-sub-strips'
                                          }
                                        ></p>

                                        {this.showCriteriaName(
                                          stuBehaviorList.criteriaName
                                        )}
                                      </span>
                                      <p className="hover-p">
                                        {this.showHoverCname(
                                          stuBehaviorList.criteriaName
                                        )}
                                      </p>
                                    </div>
                                    <div className="mid-check-section  pos-rel">
                                      <div className="srb-avr-pos per-hover">
                                        {stuBehaviorList.percentage}%
                                        <p className="hover-per-desc">
                                          {this.hoverPerDesc(
                                            stuBehaviorList.description
                                          )}
                                        </p>
                                      </div>

                                      <ul>
                                        {this.props.srbResponse.srbXAxis.map(
                                          (axisData, v) =>
                                            this.displayTick(
                                              axisData,
                                              stuBehaviorList.chartDataList
                                            )
                                        )}
                                      </ul>
                                    </div>
                                  </div>
                                )
                              )}
                            </div>
                          </div>
                        </React.Fragment>
                      )
                    )}

                    {/* table end */}
                  </div>
                </div>
              </div>

              {/* x axis for srb start */}
              <div className="srb-xaxis mt-2">
                <p className="srb-title-lhs">Reading Behaviors</p>
                <p className="srb-title-rhs">Average</p>
                <div className="block-name">
                  <span>Assignment</span>
                </div>
                <div className="srb-tab-top-bor"></div>
                <div className="last-bor-top last-bor-12-20"></div>
                <div className="last-bor-btm"></div>
                <div className="last-bor-top1"></div>
                {/* x axis code start */}
                {this.props.scroll &&
                  <React.Fragment>
                    <div className="prev-arrow-rbsection">
                      <div
                        onClick={() =>
                          this.scrollSrbAxis(
                            this.props.srbResponse.srbResponse.spbxAxisResponseList,
                            this.props.srbResponse.scrollIndex,
                            'extremeLeft'
                          )
                        }
                        className="prev-img1"
                        style={
                          this.props.srbResponse.scrollIndex > 0
                            ? { cursor: 'pointer' }
                            : { cursor: 'default' }
                        }
                      >
                        {this.props.srbResponse.scrollIndex > 0 ? (
                          <img
                            src={ExtremeLeftActiveArrow}
                            width="52px"
                            height="48px"
                          />
                        ) : (
                            <img src={ExtremeLeftArrow} width="52px" height="48px" />
                          )}
                      </div>
                      <div
                        className="prev-img2"
                        style={
                          this.props.srbResponse.scrollIndex > 0
                            ? { cursor: 'pointer' }
                            : { cursor: 'default' }
                        }
                        onClick={() =>
                          this.scrollSrbAxis(
                            this.props.srbResponse.srbResponse.spbxAxisResponseList,
                            this.props.srbResponse.scrollIndex,
                            'left'
                          )
                        }
                      >
                        {this.props.srbResponse.scrollIndex > 0 ? (
                          <img src={LeftActiveArrow} width="52px" height="48px" />
                        ) : (
                            <img src={LeftArrow} width="52px" height="48px" />
                          )}
                      </div>
                    </div>
                    <div
                      className="chart-section pos-rel srb-btm-mid-sec"
                      style={{ width: '589px' }}
                    >
                      <ul>
                        {this.props.srbResponse.srbXAxis &&
                          this.props.srbResponse.srbXAxis.map((xData, value) => (
                            <li className="chart-box-rb pos-rel">
                              <p
                                className={this.stdProficiencyType(
                                  xData.proficiency
                                )}
                              />
                              <p className="cursor-pointer xaxis-txt xaxis-12-20">
                                <span>{xData.assignmentCompletionDate}</span>
                                <br />
                                <span>{xData.letterLevel}</span>
                              </p>
                              <p>{this.showTitle(xData.title)}</p>
                            </li>
                          ))}
                      </ul>
                    </div>
                    <div className="next-arrow-section">
                      <div
                        className="prev-img1"
                        style={
                          this.props.srbResponse.scrollIndex <
                            this.props.srbResponse.srbResponse.spbxAxisResponseList
                              .length -
                            7
                            ? { cursor: 'pointer' }
                            : { cursor: 'default' }
                        }
                        onClick={() =>
                          this.scrollSrbAxis(
                            this.props.srbResponse.srbResponse.spbxAxisResponseList,
                            this.props.srbResponse.scrollIndex,
                            'right'
                          )
                        }
                      >
                        {this.props.srbResponse.scrollIndex <
                          this.props.srbResponse.srbResponse.spbxAxisResponseList
                            .length -
                          7 ? (
                            <img src={RightActiveArrow} width="52px" height="48px" />
                          ) : (
                            <img src={RightArrow} width="52px" height="48px" />
                          )}
                      </div>
                      <div
                        className="prev-img2"
                        style={
                          this.props.srbResponse.scrollIndex <
                            this.props.srbResponse.srbResponse.spbxAxisResponseList
                              .length -
                            7
                            ? { cursor: 'pointer' }
                            : { cursor: 'default' }
                        }
                        onClick={() =>
                          this.scrollSrbAxis(
                            this.props.srbResponse.srbResponse.spbxAxisResponseList,
                            this.props.srbResponse.scrollIndex,
                            'extremeRight'
                          )
                        }
                      >
                        {this.props.srbResponse.scrollIndex <
                          this.props.srbResponse.srbResponse.spbxAxisResponseList
                            .length -
                          7 ? (
                            <img
                              src={ExtremeRightActiveArrow}
                              width="52px"
                              height="48px"
                            />
                          ) : (
                            <img src={ExtremeRightArrow} width="52px" height="48px" />
                          )}
                      </div>
                    </div>
                  </React.Fragment>}
              </div>
              {/* x axis for srb end */}
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default RbTable;
