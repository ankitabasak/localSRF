import React, { Component } from 'react';

import { connect } from 'react-redux';

class ORR_Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            executableCounter: 0,
            error: '',
            userName: '',
            password: '',
            realm: ''
        }
    }

    render() {
        return (
            <div className="text-center">
                {/* <h1>Place Holder For ORR Report </h1> */}
            </div >
        );
    }
}
const mapStateToProps = ({ Universal }) => {

    const { ContextHeader, ApiCalls, StickyUniversalSelector,
        StickyContextHeader, UniversalSelecter, NavigationByHeaderSelection, StandardPerformanceFilter } = Universal;

    return {
        ContextHeader, ApiCalls, StickyUniversalSelector,
        StickyContextHeader, UniversalSelecter, NavigationByHeaderSelection, StandardPerformanceFilter
    }
}

export default connect(mapStateToProps, {

})(ORR_Home);

