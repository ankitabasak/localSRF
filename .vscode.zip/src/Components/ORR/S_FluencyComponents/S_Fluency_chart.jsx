import React, { Component } from 'react';
import FluencyTable from './Fluency_Table.jsx';
import Filter from '../FilterComponents/Filter';
import { connect } from 'react-redux';
import { CSVLink } from "react-csv";
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  S_Fluency_Chart_Data,
  LOADER_ICON,
  SFA_SCROLL,
  OVERLAY_FLAG,
  Update_Sfa_Tooltip,
  SF_CSVDATA_DOWNLOAD_APICALL,
  SF_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/S_FluencyActions.jsx';
import NoRecordsData from '../../../Utils/No_Data_Found';
import NoRosterData from '../../../Utils/NoRoster.js';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import PrintSfa from '../../ReusableComponents/PrintOrrCharts/S_FluencyPrint.jsx'
import NoFluencyData from '../../../Utils/No_Data.js'
import CsvIcon from '../../../../public/images/ic_save.svg';

class StudentFluencyChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {}
    };

    this.updateSfaScrollData = this.updateSfaScrollData.bind(this);
    this.showOverlayDiv = this.showOverlayDiv.bind(this);
    this.studentFluencyApi = this.studentFluencyApi.bind(this);
    this.timeOut = this.timeOut.bind(this);
  }

  componentDidMount() {
    this.studentFluencyApi();
  }

  timeOut() {
    this.props.LOADER_ICON({
      isLoader: false,
      isDataAvailable: false,
      timeOut: true
    });
  }

  // Function for Student Fluency Api
  studentFluencyApi() {
    let Token = this.props.LoginDetails.JWTToken;

    this.setState({
      ...this.state,
      timeOut: false
    });

    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.setState({
      ...this.state,
      externalFilter: Req_Payload.externalFilter
    });

    this.props.S_Fluency_Chart_Data(Token, Req_Payload, 'student');
  }

  updateSfaScrollData(sfaData) {
    this.props.SFA_SCROLL(sfaData);
  }

  showOverlayDiv(flag) {
    this.props.OVERLAY_FLAG(flag);
  }

  tooltipUpdate(data) {
    this.props.Update_Sfa_Tooltip(data)
  }
  // Download csv data
  downLoadCSVData() {
    this.props.SF_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.props.SF_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedStudent.name;
    const width = 780,
      height = 100,
      margin = 20;

    if (this.props.SFCSVDownload && this.props.SFCSVDownload['downloadInProgress'] && this.props.SFCSVDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SF_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }

    return (
      <div>
        {this.props.NavigationByHeaderSelection.student &&
          this.props.ContextHeader.Roster_Tab.SelectedStudent.id ? (
            <React.Fragment>
              <Filter externalFilter={this.state.externalFilter} />
              {this.props.StudentFluencyState.fluencyChartData &&
                this.props.StudentFluencyState.isDataAvailable &&
                !this.props.StudentFluencyState.timeOut && (
                  <React.Fragment>
                    <span className="printicon-btn">
                      <PrintSfa
                        selectedFilter={this.props.CommonFilterData}
                        studentDetails={this.props.ContextHeader}
                        navSelected={this.props.NavigationByHeaderSelection}
                        width={width}
                        height={height}
                        StudentFluencyState={this.props.StudentFluencyState}
                      />
                    </span>
                    <div id="testStuChart">
                      {this.props.SFCSVDownload && this.props.SFCSVDownload['csvData'] &&
                        <CSVLink
                          ref="groupCSV"
                          headers={this.props.SFCSVDownload['csvData'] && this.props.SFCSVDownload['csvData']['header']}
                          data={this.props.SFCSVDownload['csvData'] && this.props.SFCSVDownload['csvData']['data']}
                          style={{ display: 'none' }}
                          // filename={"SFA_CSV.csv"} 
                          filename={`${csvFileName}.csv`}
                        />}
                      <div className="csv-icon-alignment" onClick={() => !this.props.SFCSVDownload['downloadInProgress'] && this.downLoadCSVData()}>
                        {this.props.SFCSVDownload && this.props.SFCSVDownload['downloadInProgress'] ?
                          <span className="csv_download_icon">
                            <i className="material-icons">autorenew</i>
                          </span> :
                          <span className="csv_download_icon">
                            <img src={CsvIcon} width="20" height="20" />
                          </span>}
                      </div>
                      <FluencyTable
                        scrollData={sfaData => this.updateSfaScrollData(sfaData)}
                        width={width}
                        height={height}
                        fluencyData={this.props.StudentFluencyState}
                        showOverlay={overLayFlag => this.showOverlayDiv(overLayFlag)}
                        tooltipUpdate={data => this.tooltipUpdate(data)}
                      />
                    </div>

                  </React.Fragment>
                )}
              {!this.props.StudentFluencyState.fluencyChartData &&
                this.props.StudentFluencyState.isLoader && (
                  <Spinner
                    startSpinner={this.props.StudentFluencyState.isLoader}
                    showTimeOut={this.timeOut}
                  />
                )}
              {!this.props.StudentFluencyState.isLoader &&
                this.props.StudentFluencyState.timeOut && (
                  <TimeOut tryAgain={this.studentFluencyApi} />
                )}
              {this.props.StudentFluencyState.chartLoadFail &&
                !this.props.StudentFluencyState.timeOut &&
                !this.props.StudentFluencyState.isLoader && (
                  <ChartNotLoad tryAgain={this.studentFluencyApi} />
                )}
              {!this.props.StudentFluencyState.isDataAvailable &&
                this.props.StudentFluencyState.fluencyChartData && (
                  <NoRecordsData NodataFound={'dataNotAvail'} />
                )}

              {this.props.StudentFluencyState.rubricDataMsg &&
                <div>
                  <NoFluencyData NoFluencyData={this.props.StudentFluencyState.rubricDataMsg} />
                </div>
              }
            </React.Fragment>
          ) : (
            <NoRosterData></NoRosterData>
          )}
      </div>
    );
  }
}

// export default FluencyChart;

const mapStateToProps = ({
  Universal,
  Authentication,
  StudentFluencyData,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection
  } = Universal;
  const { StudentFluencyState, SFCSVDownload } = StudentFluencyData;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    StudentFluencyState,
    CommonFilterData,
    SFCSVDownload
  };
};

export default connect(
  mapStateToProps,
  {
    S_Fluency_Chart_Data, LOADER_ICON, SFA_SCROLL, OVERLAY_FLAG, Update_Sfa_Tooltip,
    SF_CSVDATA_DOWNLOAD_APICALL,
    SF_CSVDATA_DOWNLOAD_RESET
  }
)(StudentFluencyChart);
