import React, { Component } from 'react';
import * as d3 from 'd3';
import './Fluency.css';
import ExtremeLeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-new.svg';
import LeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-new.svg';
import RightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-new.svg';
import ExtremeRightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-new.svg';
import ExtremeLeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-active-new.svg';
import LeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-active-new.svg';
import RightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-active-new.svg';
import ExtremeRightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-active-new.svg';

class FluencyTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isClicked: false,
      radius: '5',
      isBubSelected: null,
      showToolTip: null,
      tooltipData: null,
      selLevel: null,
      xPos: null,
      yPos: null,
      levPos: null
    };
    // this.onMouseOver = this.onMouseOver.bind(this);
    // this.onMouseOut = this.onMouseOut.bind(this);
    this.fillColor = this.fillColor.bind(this);
    this.showLastPassage = this.showLastPassage.bind(this);
    this.scoreClass = this.scoreClass.bind(this);
    this.showScoreDescription = this.showScoreDescription.bind(this);
    this.stdProficiencyType = this.stdProficiencyType.bind(this);
    this.popData = this.popData.bind(this);
    this.bubbleLvl = this.bubbleLvl.bind(this);
  }

  //fill dot color
  fillColor(d, i) {
    let color = ['', '#ff8e2d', '#ffc52d', ' #32ac41', '#079ccf'];
    return color[d.b];
  }

  scoreClass(d, i) {
    let color = ['', '#ff8e2d', '#ffc52d', ' #32ac41', '#079ccf'];
    return color[d];
  }

  //to display the last passage
  showLastPassage(passage) {
    return (
      <div className="hover-fclass">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }

  //to display the score description
  showScoreDescription(description) {
    return (
      <div className="hover-score">
        {description}
        <div className="tooltip-dot" />
      </div>
    );
  }

  //display x axis with proficiency type
  stdProficiencyType(type) {
    switch (type) {
      case 'Instructional':
        return 'ar';
      case 'Independent':
        return 'ar-blue';
      case 'Frustrational':
        return 'ar-yellow';
    }
  }

  bubbleLvl(val) {
    let bubPos = [468, 365, 265, 162];
    return bubPos[val];
  }

  //overlay function
  popData(d, i, value, xPos, yPos) {
    let toolTipData = {}
    if (this.state.selLevel === value && !this.props.fluencyData.selectedLvl) {
      if (this.state.isBubSelected === i) {
        toolTipData = {
          isBubSelected: null,
          showToolTip: null,
          tooltipData: null,
          selLevel: null,
          xPos: null,
          yPos: null,
          levPos: null
        }
        this.setState({
          isBubSelected: null,
          showToolTip: null,
          tooltipData: null,
          selLevel: null,
          xPos: null,
          yPos: null,
          levPos: null
        });
        this.props.showOverlay(false);
        this.props.tooltipUpdate(toolTipData)
      } else {
        toolTipData = {
          isBubSelected: i,
          showToolTip: true,
          tooltipData: d,
          selLevel: value,
          xPos: xPos,
          yPos: yPos,
          levPos: this.bubbleLvl(value)
        }
        this.setState({
          isBubSelected: i,
          showToolTip: true,
          tooltipData: d,
          selLevel: value,
          xPos: xPos,
          yPos: yPos,
          levPos: this.bubbleLvl(value)
        });
        this.props.tooltipUpdate(toolTipData)
        this.props.showOverlay(true);
      }
    } else {
      toolTipData = {
        isBubSelected: i,
        showToolTip: true,
        tooltipData: d,
        selLevel: value,
        xPos: xPos,
        yPos: yPos,
        levPos: this.bubbleLvl(value)
      }
      this.setState({
        isBubSelected: i,
        showToolTip: true,
        tooltipData: d,
        selLevel: value,
        xPos: xPos,
        yPos: yPos,
        levPos: this.bubbleLvl(value)
      });
      this.props.tooltipUpdate(toolTipData)
      this.props.showOverlay(true);
    }
  }

  //scroll axis
  scrollXAxis(dataArr, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataArr.length - 9) {
          let sIndex = index + 1;

          this.props.scrollData({
            ['xAxisData']: dataArr.slice(sIndex, sIndex + 9),
            scrollIndex: sIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let sIndex = index - 1;
          this.props.scrollData({
            ['xAxisData']: dataArr.slice(sIndex, sIndex + 9),
            scrollIndex: sIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataArr.length - 9) {
          let sIndex = dataArr.length - 9;

          this.props.scrollData({
            ['xAxisData']: dataArr.slice(sIndex, sIndex + 9),
            scrollIndex: sIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let sIndex = 0;

          this.props.scrollData({
            ['xAxisData']: dataArr.slice(0, 9),
            scrollIndex: sIndex
          });
        }
        return;
    }
  }
  render() {
    const margin = 20;
    const { width, height, fluencyData } = this.props;

    const h = height,
      w = width - 2 * margin;

    //number formatter
    const xFormat = d3.format('.1');

    //x scale
    const x = d3
      .scaleLinear()
      .domain([0, 9]) //domain: [min,max] of a d3.extent(data, d => d.a / 2) || d3.max(data, d => d.a)]
      .range([0, w]);

    //y scale
    const y = d3
      .scaleLinear()
      .domain([0, 4]) // domain [0,max] of b (start from 0)
      .range([h, 0]);

    const xPosition = Math.abs(x(0) - x(1)) / 2;
    const yPosition = Math.abs(y(0) - y(1)) / 2 - Math.abs(y(0) - y(1));
    const line = d3
      .line()
      .x(d => x(d.a) - xPosition)
      .y(d => y(d.b) - yPosition);

    const xTicks = x.ticks(8).map((d, value) =>
      x(d) > margin && x(d) < w ? (
        <g key={value} transform={`translate(${x(d) - 3},${h + margin})`}>
          <line
            className="gridline"
            x1="0"
            y1={-h}
            y2="5"
            transform="translate(0.5,-20)"
          />
        </g>
      ) : null
    );

    const yTicks = y.ticks(4).map((d, v) =>
      y(d) > 10 && y(d) < h ? (
        <g key={v} transform={`translate(${0},${y(d)})`}>
          <line
            className="gridline-y"
            x1={w}
            y1="0"
            y2="0"
            transform="translate(0,0)"
          />
        </g>
      ) : null
    );

    return (
      <div>
        <div
          className="container student-fa ipad-pro-align ipadPro ipadAir-15-20"
          style={{ width: '1000px', paddingLeft: '0px', paddingRight: '0px' }}
        >
          {/* <!-- dummy graph start --> */}
          <div className="row mt-10" style={{ marginTop: '7px' }}>
            <div className="col-lg-12 IpadAir-col-07-20">
              <span className="sfa-label-text">Score</span>
              <span className="sfa-text sFatxt-total">Total</span>

              {/* <!-- leftside Start --> */}
              <div className="student-fa-wrap clearfix StFaWrao-07-20">
                {/* <!-- Fourth coloumn start --> */}
                {fluencyData.yAxisModifiedData &&
                  fluencyData.yAxisModifiedData.map((fluencyData, value) => {
                    return (
                      <div key={value} className="first-section  pos-rel">
                        <div className="top-wrap-bor" />
                        <div className="sfa-last-colm">
                          <p>Fluency Over Time</p>
                        </div>
                        <div className="bor-line2" />
                        <div className="row-name">
                          <p>{fluencyData.criteriaName}</p>
                        </div>
                        <div className="row-number">
                          <ul className="mb-0">
                            {fluencyData.studentFACriteriaScoreDataList.map(
                              (scoreData, value) => {
                                return (
                                  <li key={value}
                                    className={
                                      'score-class pos-rel bor-color' + value
                                    }
                                  >
                                    {scoreData.criteriaScore}
                                    <p>
                                      {this.showScoreDescription(
                                        scoreData.criteriaScoreDescription
                                      )}
                                    </p>
                                  </li>
                                );
                              }
                            )}
                          </ul>
                        </div>
                        {/* chart section starts */}

                        <div className="chart-section">
                          <svg
                            className="svg-class"
                            width={w}
                            height={100}
                            transform={`translate(0,-1)`}
                          >
                            <path
                              className="path-class"
                              d={line(
                                fluencyData.studentFABubbleData.filter(obj => {
                                  if (obj.b > 0) {
                                    return obj;
                                  }
                                })
                              )}
                            />
                            {fluencyData.studentFABubbleData.map((d, i) => {
                              return (
                                <React.Fragment>
                                  <g key={i}
                                    onClick={() =>
                                      this.popData(
                                        d,
                                        i,
                                        value,
                                        x(d.a) - xPosition,
                                        y(d.b) - yPosition
                                      )
                                    }
                                  >
                                    <circle
                                      className="dot cursor-pointer"
                                      r="4"
                                      cx={x(d.a) - xPosition}
                                      cy={y(d.b) - yPosition}
                                      fill={this.fillColor(d, i)}
                                      id={i}
                                      key={i}
                                    />
                                  </g>
                                </React.Fragment>
                              );
                            })}
                            {/* {circles} */}

                            <g className="axis-labels">{xTicks}</g>
                            <g className="axis-labels">{yTicks}</g>
                          </svg>
                        </div>

                        {/* chart section ends */}
                        <div className="row-number-last">
                          <ul className="mb-0">
                            {fluencyData.studentFACriteriaPercentageDataList.map(
                              (percentage, value) => {
                                return (
                                  <li key={value}>{percentage.percentage}%</li>
                                );
                              }
                            )}
                          </ul>
                        </div>
                      </div>
                    );
                  })}
              </div>

              {/* <!-- last x row start --> */}
              <div className="sfa-xaxis std-sfa-xaxis">
                <div className="last-bor-top" />
                <div className="last-bor-btm" />
                <div className="last-bor-top1" />
                <div className="prev-arrow-section">
                  <div
                    onClick={() =>
                      this.scrollXAxis(
                        fluencyData.fluencyChartData,
                        fluencyData.scrollIndex,
                        'extremeLeft'
                      )
                    }
                    className="prev-img1"
                    style={
                      fluencyData.scrollIndex > 0
                        ? { cursor: 'pointer' }
                        : { cursor: 'default' }
                    }
                  >
                    {fluencyData.scrollIndex > 0 ? (
                      <img
                        src={ExtremeLeftActiveArrow}
                        width="52px"
                        height="48px"
                      />
                    ) : (
                        <img src={ExtremeLeftArrow} width="52px" height="48px" />
                      )}
                  </div>
                  <div
                    className="prev-img2"
                    style={
                      fluencyData.scrollIndex > 0
                        ? { cursor: 'pointer' }
                        : { cursor: 'default' }
                    }
                    onClick={() =>
                      this.scrollXAxis(
                        fluencyData.fluencyChartData,
                        fluencyData.scrollIndex,
                        'left'
                      )
                    }
                  >
                    {fluencyData.scrollIndex > 0 ? (
                      <img src={LeftActiveArrow} width="52px" height="48px" />
                    ) : (
                        <img src={LeftArrow} width="52px" height="48px" />
                      )}
                  </div>
                </div>
                <div
                  className="chart-section pos-rel axis-width">
                  <div className="block-name">
                    <span>Assignment</span>
                  </div>
                  <ul>
                    {fluencyData.xAxisData &&
                      fluencyData.xAxisData.map((xData, value) => (
                        <li className="chart-box " key={value}>
                          <p
                            className={this.stdProficiencyType(
                              xData.proficiencyType
                            )}
                          />
                          <p className="cursor-pointer">
                            <span>{xData.assignmentCompletionDate}</span>
                            <br />
                            <span>{xData.readingLevel}</span>
                          </p>
                          {this.showLastPassage(xData.description)}
                        </li>
                      ))}
                  </ul>
                </div>
                <div className="next-arrow-section sFa-15-20">
                  <div
                    className="prev-img1 im1"
                    style={
                      fluencyData.scrollIndex <
                        fluencyData.sfaResponse.studentFAAxisDataList.length - 9
                        ? { cursor: 'pointer' }
                        : { cursor: 'default' }
                    }
                    onClick={() =>
                      this.scrollXAxis(
                        fluencyData.fluencyChartData,
                        fluencyData.scrollIndex,
                        'right'
                      )
                    }
                  >
                    {fluencyData.scrollIndex <
                      fluencyData.sfaResponse.studentFAAxisDataList.length - 9 ? (
                        <img src={RightActiveArrow} width="52px" height="48px" />
                      ) : (
                        <img src={RightArrow} width="52px" height="48px" />
                      )}
                  </div>
                  <div
                    className="prev-img2 im2"
                    style={
                      fluencyData.scrollIndex <
                        fluencyData.sfaResponse.studentFAAxisDataList.length - 9
                        ? { cursor: 'pointer' }
                        : { cursor: 'default' }
                    }
                    onClick={() =>
                      this.scrollXAxis(
                        fluencyData.fluencyChartData,
                        fluencyData.scrollIndex,
                        'extremeRight'
                      )
                    }
                  >
                    {fluencyData.scrollIndex <
                      fluencyData.sfaResponse.studentFAAxisDataList.length - 9 ? (
                        <img
                          src={ExtremeRightActiveArrow}
                          width="52px"
                          height="48px"
                        />
                      ) : (
                        <img src={ExtremeRightArrow} width="52px" height="48px" />
                      )}
                  </div>
                </div>
              </div>

              {/* <!-- last x row end --> */}
              {fluencyData.updateSfaToolTip && fluencyData.updateSfaToolTip.showToolTip && fluencyData.overlayFlag && (
                <div
                  className="inner-popup pos-rel popup-wh-sfa"
                  style={{
                    transform: `translate(${fluencyData.updateSfaToolTip.xPos - 57}px, 
                      ${-fluencyData.updateSfaToolTip.levPos -
                      (87 - fluencyData.updateSfaToolTip.yPos)}px)`
                  }}
                >
                  {/* - this.state.levPos */}
                  <div
                    onClick={() =>
                      this.popData(
                        fluencyData.updateSfaToolTip.tooltipData,
                        fluencyData.updateSfaToolTip.isBubSelected,
                        fluencyData.updateSfaToolTip.selLevel
                      )
                    }
                    className="small-circle cursor-pointer"
                    style={{
                      backgroundColor: this.scoreClass(fluencyData.updateSfaToolTip.tooltipData.b)
                    }}
                  />
                  <div className="first-ul stRlp-ul sRlp-overlay-box sfa-top-48">
                    <span className="sfa-font">Score: {fluencyData.updateSfaToolTip.tooltipData.b}</span>
                    <hr className="hr-line"></hr>
                    <span className="student-lh15">{fluencyData.updateSfaToolTip.tooltipData.description}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default FluencyTable;
