import React, { Component } from 'react';
import Filter from '../FilterComponents/Filter';
import { connect } from 'react-redux';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  S_RLP_API_CALL,
  SRL_CHART_YAXIS_SCROLL,
  SRL_CHART_XAXIS_SCROLL,
  Chart_Enabled,
  SRLP_CSVDATA_DOWNLOAD_APICALL,
  SRLP_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import StudentRlpChart from './S_RlpChart.jsx';
import { formatDate } from '../../../Utils/globalVars';
import NoRecordsData from '../../../Utils/No_Data_Found';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import PrintS_RLP from '../../ReusableComponents/PrintOrrCharts/S_RlpPrint.jsx'

class S_ReadingLevelProgress extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false
    };
    this.timeOut = this.timeOut.bind(this);
    this.studentReadingLevelApi = this.studentReadingLevelApi.bind(this);
    this.showChart = this.showChart.bind(this);
  }

  /* componentDidMount() {
    this.studentReadingLevelApi();
  } */

   componentDidMount() { 
   if (this.props.ContextHeader.Roster_Tab.SelectedStudent.id) {
    this.studentReadingLevelApi();
    clearInterval(this.interval);
     }
  }
  componentDidUpdate(prevProps) {
    if (this.props.ContextHeader.Roster_Tab.SelectedStudent.id !== prevProps.ContextHeader.Roster_Tab.SelectedStudent.id) {
    const RosterApicalling = this.props.ApiCalls.loadingFor !==""
    if(!this.props.StudentRlpChartData.sRlpResponse && !RosterApicalling )   {
      this.studentReadingLevelApi();
  }
  }
} 
  // Download csv data
  downLoadCSVData() {

    this.props.SRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.props.SRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }
  showChart(chartEnabled) {
    this.props.Chart_Enabled(chartEnabled)
  }
  // handle timeout
  timeOut() {
    this.setState({ ...this.state, timeOut: true });
  }
  //  Y Scroll
  updateYScrolledData(chartData) {
    this.props.SRL_CHART_YAXIS_SCROLL(chartData);
  }
  updateXScrolledData(chartData) {
    this.props.SRL_CHART_XAXIS_SCROLL(chartData);
  }
  studentReadingLevelApi() {
    let Req_Payload = getCommonHeaders(this.props, 'student');
    this.setState({
      ...this.state,
      timeOut: false
    });

    this.setState({ externalFilter: Req_Payload.externalFilter });
    this.props.S_RLP_API_CALL(
      this.props.LoginDetails.JWTToken,
      Req_Payload,
      'student'
    );

  }

  render() {
    console.log(Intl.DateTimeFormat().resolvedOptions().timeZone);
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedStudent.name;
    if (this.props.SRLPCSVDownload && this.props.SRLPCSVDownload['downloadInProgress'] && this.props.SRLPCSVDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    return (
      <div>
        {this.props.isApiLoading ? <Spinner /> : this.props.NavigationByHeaderSelection.student &&
          this.props.ContextHeader.Roster_Tab.SelectedStudent.id ? (
            <div>
              <Filter externalFilter={this.state.externalFilter} />
              {this.props.StudentRlpChartData.sRlpResponse &&
                !this.props.isDataAvailable && (
                  <React.Fragment>
                    <span className="printicon-btn ipad-pro-portrait">
                      <PrintS_RLP
                        isPrint={true}
                        svgHeight={400}
                        yAlign={40}
                        xAlign={183}
                        radius1={27}
                        radius2={25}
                        yBubleAlign={368}
                        yScaleAlign={5}
                        xTickAlign={2}
                        selectedFilter={this.props.CommonFilterData}
                        studentDetails={this.props.ContextHeader}
                        navSelected={this.props.NavigationByHeaderSelection}
                        StudentRlpChartData={this.props.StudentRlpChartData}
                      />
                    </span>
                    <div id="testStuChart">
                      {this.props.SRLPCSVDownload && this.props.SRLPCSVDownload['csvData'] &&
                        <CSVLink
                          ref="groupCSV"
                          headers={this.props.SRLPCSVDownload['csvData'] && this.props.SRLPCSVDownload['csvData']['header']}
                          data={this.props.SRLPCSVDownload['csvData'] && this.props.SRLPCSVDownload['csvData']['data']}
                          style={{ display: 'none' }}
                          // filename={"SRLP_CSV.csv"}
                          filename={`${csvFileName}.csv`}
                        />}
                      <div className="csv-icon-alignment" onClick={() => !this.props.SRLPCSVDownload['downloadInProgress'] && this.downLoadCSVData()}>
                        {this.props.SRLPCSVDownload && this.props.SRLPCSVDownload['downloadInProgress'] ?
                          <span className="csv_download_icon">
                            <i className="material-icons">autorenew</i>
                          </span> :
                          <span className="csv_download_icon">
                            <img src={CsvIcon} width="20" height="20" />
                          </span>}
                      </div>
                      <StudentRlpChart
                        isPrint={false}
                        svgHeight={460}
                        yAlign={33}
                        xAlign={188}
                        radius1={28}
                        radius2={26}
                        yBubleAlign={414}
                        yScaleAlign={0}
                        xTickAlign={12}
                        sRlpChart={this.props.StudentRlpChartData}
                        initiateXScroll={cData => {
                          this.updateXScrolledData(cData);
                        }}
                        initiateYScroll={cData => {
                          this.updateYScrolledData(cData);
                        }}
                        UpdateSrlpChart={chartEnabled => {
                          this.showChart(chartEnabled)
                        }}
                      />

                      {/* testing purpose start */}
                      {/* <div className="clearfix">
                        <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                                                   <tbody>
                            <tr>
                              <td>
                                <StudentRlpChart sRlpChart={this.props.StudentRlpChartData}
                                  UpdateSrlpChart={chartEnabled => {
                                    this.showChart(chartEnabled)
                                  }} />
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div> */}
                      {/* end */}
                    </div>
                  </React.Fragment>
                )}
              {!this.props.StudentRlpChartData.sRlpResponse &&
                !this.state.timeOut &&
                this.props.isApiLoading && (
                  <Spinner
                    startSpinner={!this.props.StudentRlpChartData.sRlpResponse}
                    showTimeOut={this.timeOut}
                  />
                )}
              {!this.props.StudentRlpChartData.sRlpResponse &&
                this.state.timeOut &&
                !this.props.responseErrCode && (
                  <TimeOut tryAgain={this.studentReadingLevelApi} />
                )}
              {!this.props.StudentRlpChartData.sRlpResponse &&
                this.props.responseErrCode &&
                !this.props.isApiLoading && (
                  <ChartNotLoad tryAgain={this.studentReadingLevelApi} />
                )}
              {this.props.StudentRlpChartData.sRlpResponse &&
                this.props.isDataAvailable && (
                  <NoRecordsData NodataFound={'dataNotAvail'} />
                )}
            </div>
          )  
                    
          :<NoRosterData />    }
      </div>
    );
  }
}
const mapStateToProps = ({
  StudentRlpData,
  CommonFilterDetails,
  Authentication,
  Universal
}) => {
  const {
    StudentRlpChartData,
    SRLPCSVDownload,
    isApiLoading,
    isDataAvailable,
    responseErrCode
  } = StudentRlpData;
  const { CommonFilterData } = CommonFilterDetails;
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection
  } = Universal;
  return {
    CommonFilterData,
    StudentRlpChartData,
    SRLPCSVDownload,
    LoginDetails,
    ContextHeader,
    ApiCalls,
    isApiLoading,
    isDataAvailable,
    UniversalSelecter,
    NavigationByHeaderSelection,
    responseErrCode
  };
};

export default connect(
  mapStateToProps,
  {
    S_RLP_API_CALL,
    SRL_CHART_YAXIS_SCROLL,
    SRL_CHART_XAXIS_SCROLL,
    Chart_Enabled,
    SRLP_CSVDATA_DOWNLOAD_APICALL,
    SRLP_CSVDATA_DOWNLOAD_RESET
  }
)(S_ReadingLevelProgress);
