import React, { Component } from 'react';
import * as d3 from 'd3';
import '../S_FluencyComponents/Fluency.css';

class AccuracyRlpChart extends Component {
  render() {
    const width = 750,
      height = this.props.height,
      margin = 10;
    const { accuracyAxis, aValue } = this.props;

    const h = height,
      w = width - 2 * margin;

    //x scale
    const x = d3
      .scaleLinear()
      .domain([0, 7]) //domain: [min,max] of a d3.extent(data, d => d.a / 2) || d3.max(data, d => d.a)]
      .range([0, 700]);

    //y scale
    const y = d3
      .scaleLinear()
      .domain([0, d3.max(aValue, d => d)]) //0, d3.max(aValue, d => d) or [0, 100]
      .range([h, 0]);

    const line = d3
      .line()
      .x(d => x(d.a))
      .y(d => y(d.b));

    var circles =
      accuracyAxis &&
      accuracyAxis.map((d, i) => {
        return (
          <g transform={`translate(-46, 6)`} key={i}>
            <circle
              className="dot"
              r="4"
              cx={x(d.a)}
              cy={y(d.b)}
              fill="#BDC2CD"
              id={i}
              key={i}
            />
          </g>
        );
      });

    const yTicks = y.ticks(11).map((d, i) =>
      y(d) > -1 && y(d) < h ? (
        <g transform={`translate(${0},${y(d)})`} key={i}>
          <text x="-12" y="5" transform={`translate(${w},${i * 1 - 5})`}>
            {d}
          </text>

          <line
            className="gridline-yxs"
            x1="0"
            x1={w - 30}
            y1={margin + 36}
            y2={margin + 36}
            transform={`translate(${0},${i + 25 * -2})`}
          />
        </g>
      ) : null
    );

    return (
      <g>
        <path
          transform={`translate(-46, 6)`}
          className="path-class"
          d={line(
            accuracyAxis.filter(obj => {
              if (obj.b > 0) {
                return obj;
              }
            })
          )}
        />
        {circles}
        <g className="axis-labels">{yTicks}</g>
        {/* chart section ends */}
      </g>
    );
  }
}

export default AccuracyRlpChart;
