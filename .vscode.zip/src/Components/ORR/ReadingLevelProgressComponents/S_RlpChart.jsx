import React, { Component } from 'react';
import FluencyRlpChart from './Fluency_RlpChart.jsx';
import StudentRlpBubbleChart from './Student_Rlp_BubbleChart.jsx';
import AccuracyRlpChart from './Accuracy_RlpChart.jsx';
import { getAxisColor, getAxisBgColor } from './bubbleConfiguration';
import './S_Rlp.css';
import XprevEnd from '../../../../public/assets/orr/rlp-screen/x-prev-end.svg';
import Xprev from '../../../../public/assets/orr/rlp-screen/x-prev.svg';
import XprevEndActive from '../../../../public/assets/orr/rlp-screen/x-prev-end-active.svg';
import XprevActive from '../../../../public/assets/orr/rlp-screen/x-prev-active.svg';
import XnextEndActive from '../../../../public/assets/orr/rlp-screen/x-next-end-active.svg';
import XnextEnd from '../../../../public/assets/orr/rlp-screen/x-next-end.svg';
import XnextActive from '../../../../public/assets/orr/rlp-screen/x-next-active.svg';
import Xnext from '../../../../public/assets/orr/rlp-screen/x-next.svg';
import BelowEnd from '../../../../public/assets/orr/rlp-screen/srlp-below-end.svg';
import BelowEndActive from '../../../../public/assets/orr/rlp-screen/srlp-below-end-active.svg';
import BelowPrev from '../../../../public/assets/orr/rlp-screen/srlp-below-prev.svg';
import BelowPrevActive from '../../../../public/assets/orr/rlp-screen/srlp-below-prev-active.svg';
import TopEnd from '../../../../public/assets/orr/rlp-screen/srlp-top-end.svg';
import TopEndActive from '../../../../public/assets/orr/rlp-screen/srlp-top-end-active.svg';
import TopNextInactive from '../../../../public/assets/orr/rlp-screen/srlp-top-next-inactive.svg';
import TopNext from '../../../../public/assets/orr/rlp-screen/srlp-top-next.svg';

class StudentRlpChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showFluency: false,
      showAccuracy: false,
      toolTip: null,
      xPoint: '',
      yPoint: '',
      circleColor: {
        Instructional: '#2b9638',
        Independent: '#008ad9',
        Frustrational: '#ffc52d'
      }
    };
    this.toggleY1 = this.toggleY1.bind(this);
    this.toggleY2 = this.toggleY2.bind(this);
    this.showToolTip = this.showToolTip.bind(this);
    this.scrollUpDown = this.scrollUpDown.bind(this);
    this.scrollRightLeft = this.scrollRightLeft.bind(this);
  }

  toggleY1() {
    if (this.state.showAccuracy !== true || this.state.showAccuracy) {
      this.setState({
        showFluency: !this.state.showFluency,
        showAccuracy: false
      });
      this.props.UpdateSrlpChart({
        showFluency: !this.state.showFluency,
        showAccuracy: false
      })
    }
  }

  toggleY2() {
    if (this.state.showFluency !== true || this.state.showFluency) {
      this.setState({
        showAccuracy: !this.state.showAccuracy,
        showFluency: false
      });
      this.props.UpdateSrlpChart({
        showAccuracy: !this.state.showAccuracy,
        showFluency: false
      })
    }
  }

  showToolTip(data, cx, cy) {
    this.setState({
      ...this.state,
      toolTip: data,
      xPoint: cx,
      yPoint: cy
    });
  }

  sliceData(dataList, startIdx, endIdex) {
    return dataList.slice(startIdx, endIdex);
  }
  // scroll methods
  scrollRightLeft(dataList, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataList.length - 7) {
          let scrlIndex = index + 1;

          this.props.initiateXScroll({
            ['modifiedAssignmentData']: dataList.slice(
              scrlIndex,
              scrlIndex + 7
            ),
            XScrollIndex: scrlIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let scrlIndex = index - 1;
          this.props.initiateXScroll({
            ['modifiedAssignmentData']: dataList.slice(
              scrlIndex,
              scrlIndex + 7
            ),
            XScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataList.length - 7) {
          let scrlIndex = dataList.length - 7;

          this.props.initiateXScroll({
            ['modifiedAssignmentData']: dataList.slice(
              scrlIndex,
              scrlIndex + 7
            ),
            XScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let scrlIndex = 0;

          this.props.initiateXScroll({
            ['modifiedAssignmentData']: dataList.slice(0, 7),
            XScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  // UP and Down
  scrollUpDown(dataList, index, scrollType) {
    switch (scrollType) {
      case 'top':
        if (index > 6) {
          let scrlIndex = index - 1;

          this.props.initiateYScroll({
            modifiedReadingLevel: dataList.slice(scrlIndex - 6, scrlIndex),
            YScrollIndex: scrlIndex
          });
        }
        return;

      case 'bottom':
        if (index < dataList.length) {
          let scrlIndex = index + 1;

          this.props.initiateYScroll({
            modifiedReadingLevel: dataList.slice(scrlIndex - 6, scrlIndex),
            YScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeTop':
        if (index > 6) {
          let scrlIndex = 6;

          this.props.initiateYScroll({
            modifiedReadingLevel: dataList.slice(0, 6),
            YScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeBottom':
        if (index < dataList.length) {
          let scrlIndex = dataList.length;

          this.props.initiateYScroll({
            modifiedReadingLevel: dataList.slice(
              dataList.length - 6,
              dataList.length
            ),
            YScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  getAxisBorderColor(readingLevel) {
    return {
      borderRight: `4px solid ` + getAxisColor(readingLevel),
      backgroundColor: getAxisBgColor(readingLevel)
    };
  }

  getPoints(toolTipYPoint, yAlign, printToolTipYPoint) {
    if (this.props.isPrint) {
      return (printToolTipYPoint - 47);
    } else {
      return (toolTipYPoint - yAlign);
    }
  }

  render() {
    let toolTip = this.props.sRlpChart.updateToolTip;
    let printToolTip = this.props.sRlpChart.updateToolTipPrint;
    let apiResponse = this.props.sRlpChart.sRlpResponse;
    const dashSymbol = <span>&mdash;</span>;
    const width = 750,
      height = this.props.svgHeight;
    return (
      <div className="rlpchart-border sRlp-bor-11-20">
        <div className="std-rb-btm-border" />
        <div className="show-radio-btn">
          <div className="check-box-heading pull-left">Show:</div>
          <div onClick={this.toggleY1} className="round pull-left">
            <input type="checkbox" />
            <label
              className={this.props.sRlpChart.showFluency ? ' check-btn' : 'uncheck-btn'}
            >
              <span>Fluency</span>
            </label>
          </div>
          <div onClick={this.toggleY2} className="round pull-left ml-28">
            <input type="checkbox" />
            <label
              style={{ marginLeft: '19px' }}
              className={this.props.sRlpChart.showAccuracy ? ' check-btn' : 'uncheck-btn'}
            >
              <span>Accuracy</span>
            </label>
          </div>
          {this.props.sRlpChart.showFluency && (
            <span
              className="y-label"
              style={{
                float: 'right',
                color: '#00539b'
              }}
            >
              Fluency
              <br /> (wcpm)
            </span>
          )}
          {this.props.sRlpChart.showAccuracy && (
            <span
              className="y-label"
              style={{
                float: 'right',
                color: '#00539b'
              }}
            >
              Accuracy
            </span>
          )}
        </div>
        {/* <div className="hor-line1" /> */}
        <div>
          {/* 19-08-2019 */}
          <div className="pull-left scroll-lhs pos-rel">
            <div className="chart-lhs-bor sRlpchart-11-20" />
            <div
              className="top-arrow-sec"
              style={
                this.props.sRlpChart.YScrollIndex > 6
                  ? { cursor: 'pointer' }
                  : { cursor: 'default' }
              }
              onClick={() => {
                this.scrollUpDown(
                  apiResponse['readingLevelAxis'],
                  this.props.sRlpChart.YScrollIndex,
                  'extremeTop'
                );
              }}
            >
              {this.props.sRlpChart.YScrollIndex > 6 ? (
                <img src={TopEndActive} height="26px" />
              ) : (
                  <img src={TopEnd} height="26px" />
                )}
            </div>
            <div
              className="top-arrow-sec"
              style={
                this.props.sRlpChart.YScrollIndex > 6
                  ? { cursor: 'pointer' }
                  : { cursor: 'default' }
              }
              onClick={() => {
                this.scrollUpDown(
                  apiResponse['readingLevelAxis'],
                  this.props.sRlpChart.YScrollIndex,
                  'top'
                );
              }}
            >
              {this.props.sRlpChart.YScrollIndex > 6 ? (
                <img src={TopNext} />
              ) : (
                  <img src={TopNextInactive} />
                )}
            </div>
            <div className="mid-sec ms-11-20">
              {this.props.sRlpChart.modifiedReadingLevel.map(
                (readingLevel, index) => {
                  return (
                    <div
                      className="vert-scroll-block1 vsb-11-20"
                      key={index}
                      style={this.getAxisBorderColor(readingLevel)}
                    >
                      <div className="rhs-small-bor" />
                      <span>{readingLevel}</span>
                    </div>
                  );
                }
              )}
            </div>
            <div className="bottom-arrow-sec">
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.YScrollIndex <
                    apiResponse.readingLevelAxis.length
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollUpDown(
                    apiResponse['readingLevelAxis'],
                    this.props.sRlpChart.YScrollIndex,
                    'bottom'
                  );
                }}
              >
                {this.props.sRlpChart.YScrollIndex <
                  apiResponse.readingLevelAxis.length ? (
                    <img src={BelowPrevActive} />
                  ) : (
                    <img src={BelowPrev} />
                  )}
              </div>
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.YScrollIndex <
                    apiResponse.readingLevelAxis.length
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollUpDown(
                    apiResponse['readingLevelAxis'],
                    this.props.sRlpChart.YScrollIndex,
                    'extremeBottom'
                  );
                }}
              >
                {this.props.sRlpChart.YScrollIndex <
                  apiResponse.readingLevelAxis.length ? (
                    <img src={BelowEndActive} />
                  ) : (
                    <img src={BelowEnd} />
                  )}
              </div>
            </div>
            <div className="bottom-xaxis-sec m-t-3">
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.XScrollIndex > 0
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.XScrollIndex,
                    'extremeLeft'
                  );
                }}
              >
                {this.props.sRlpChart.XScrollIndex > 0 ? (
                  <img src={XprevEndActive} />
                ) : (
                    <img src={XprevEnd} />
                  )}
              </div>
              <div
                className="top-arrow-sec m-r-1"
                style={
                  this.props.sRlpChart.XScrollIndex > 0
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.XScrollIndex,
                    'left'
                  );
                }}
              >
                {this.props.sRlpChart.XScrollIndex > 0 ? (
                  <img src={XprevActive} />
                ) : (
                    <img src={Xprev} />
                  )}
              </div>
            </div>
          </div>
          <div className="pull-left svg-wrap pos-rel">

            {/* <div className="wpcm_name">
              <p>
                Fluency <br />
                (wcpm)
              </p>
            </div> */}

            <svg
              // style={{ border: '1px solid black' }}
              className="svg-class cRlp-svg-11-20"
              width={width}
              height={this.props.svgHeight}//1000
            >
              {this.props.sRlpChart.modifiedFluencyData.length !== 0 &&
                this.props.sRlpChart.showFluency && (
                  <FluencyRlpChart
                    fluencyAxis={this.props.sRlpChart.modifiedFluencyData}
                    fValue={this.props.sRlpChart.sRlpResponse.fluencyAxis}
                    height={this.props.svgHeight}
                  />
                )}

              {this.props.sRlpChart.modifiedAccuracyData.length !== 0 &&
                this.props.sRlpChart.showAccuracy && (
                  <AccuracyRlpChart
                    accuracyAxis={this.props.sRlpChart.modifiedAccuracyData}
                    aValue={this.props.sRlpChart.sRlpResponse.accuracyAxis}
                    height={this.props.svgHeight}
                  />
                )}
              {this.props.sRlpChart.modifiedAssignmentData.length !== 0 && (
                <StudentRlpBubbleChart
                  isPrint={this.props.isPrint}
                  chartData={this.props.sRlpChart}
                  svgWidth={width}
                  svgHeight={height}
                  getToolTipData={this.showToolTip}
                  radius1={this.props.radius1}
                  radius2={this.props.radius2}
                  yBubleAlign={this.props.yBubleAlign}
                  yScaleAlign={this.props.yScaleAlign}
                  xTickAlign={this.props.xTickAlign}
                />
              )}
            </svg>
          </div>

          {/* 19-08-2019 */}
          <div className="pull-left scroll-lhs pos-rel right-4">
            <div className="chart-lhs-bor-stroke sRlpstroke-11-20"></div>
            <div className="rhs-mid-sec sRlp-rhs-11-20">
              <p>Reading Level Progress Over Time</p>
            </div>

            <div className="bottom-xaxis-sec m-t-3">
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.XScrollIndex <
                    apiResponse.assignmentDataList.length - 7
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.XScrollIndex,
                    'right'
                  );
                }}
              >
                {this.props.sRlpChart.XScrollIndex <
                  apiResponse.assignmentDataList.length - 7 ? (
                    <img src={XnextActive} />
                  ) : (
                    <img src={Xnext} />
                  )}
              </div>
              <div
                className="top-arrow-sec m-r-1"
                style={
                  this.props.sRlpChart.XScrollIndex <
                    apiResponse.assignmentDataList.length - 7
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.XScrollIndex,
                    'extremeRight'
                  );
                }}
              >
                {this.props.sRlpChart.XScrollIndex <
                  apiResponse.assignmentDataList.length - 7 ? (
                    <img src={XnextEndActive} />
                  ) : (
                    <img src={XnextEnd} />
                  )}
              </div>
            </div>
          </div>
        </div>
        {this.props.sRlpChart.showStuToolTip && toolTip && toolTip.d && (
          <div className="new_srlp-print-wrap">
            <div
              className="inner-popup pos-rel popup-wh"
              style={{
                transform: `translate(${toolTip.xPoint - this.props.xAlign}px,                  
                  ${this.getPoints(toolTip.yPoint, this.props.yAlign, printToolTip.yPoint)
                  }px)`
              }}
            >
              <div
                className="small-circle"
                style={{
                  backgroundColor: this.state.circleColor[
                    toolTip.d['proficiency']
                  ]
                }}
              />
              <div className="first-ul stRlp-ul sRlp-overlay-box">
                <li>
                  <span>Reading Level: </span>
                  {toolTip.d.overlayData.readingLevel}
                </li>
                <li>
                  <span>Assignment: </span>
                  {toolTip.d.overlayData.assignmentTitle}
                </li>
                <li>
                  <span>Category: </span>
                  {toolTip.d.overlayData.category}
                </li>
                <li>
                  <span>Proficiency: </span>
                  {toolTip.d.overlayData.proficiency}
                </li>
                <li>
                  <span>Accuracy: </span>
                  {toolTip.d.overlayData.accuracy}%
                </li>
                <li>
                  <span>Fluency: </span>
                  {toolTip.d.overlayData.fluency !== null
                    ? toolTip.d.overlayData.fluency + ' wcpm'
                    : dashSymbol}
                </li>
              </div>
            </div>
          </div>
        )}
        <div className="readingLevel">Reading Level</div>
        <div className="readingLevel-date sRlp-date-02-20">Date</div>
      </div>
    );
  }
}

export default StudentRlpChart;
