import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  SetUsageReportTermDisabled,
  SetUsageReportsCollectiveNounIds,
  SetUsageReportsNavigationLevel,
  SetUsageReportsGrade,
  SetUsageDates,
  SetUsageInitialData,
  SetUsageRosterList,
  SetUsageReportsCollectiveNounUiIds,
  SetUsageReportsLoadingStatus,
  SetUsageReportsBetweenTerms,
  UsageSetUiNavigationLevel,
  SetUsageReportsDistrictName,
  SetUsageContextNames
} from '../../Redux_Actions/UniversalSelectorActions';
import { conditionExecution } from '../../Utils/buurUtils';
import { setContextNames } from '../../Utils/UsageReporting/usageReports';
import './index.css';

const BUURApp = React.lazy(() => import('bu-usage-reporting-ui/App'));

class BuurContainer extends Component {
  static composeUserProfileObject(login) {
    const jwt =
      (login.JWTToken !== null && login.JWTToken !== undefined) ? login.JWTToken : null;
    const id = window.App.model.id;
    const role = (login.UserRole !== undefined) ? login.UserRole : null;
    const userName = window.App.model.attributes.username;
    const firstName = window.App.model.attributes.first_name;
    const lastName = window.App.model.attributes.last_name;
    return {
      jwt,
      id,
      role,
      userName,
      firstName,
      lastName,
    };
  }

  static composeTerms(termData) {
    const terms = [];
    termData.forEach((term) => {
      const {
        termEndDate,
        termId,
        termName,
        termRange,
        termStartDate,
      } = term;
      const formattedTerm = {
        termEndDate,
        termId,
        termName,
        termRange,
        termStartDate,
      };
      terms.push(formattedTerm);
    })
    return terms;
  }

static parseJwt (token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
};

  constructor(props) {
    super(props);
    this.setNavigationLevel = this.setNavigationLevel.bind(this);
    this.setUiNavigationLevel = this.setUiNavigationLevel.bind(this);
    this.handleBuurCallback = this.handleBuurCallback.bind(this);
    this.setCollectiveNounIds = this.setCollectiveNounIds.bind(this);
    this.setDateData = this.setDateData.bind(this);
    this.updateUsageValues = this.updateUsageValues.bind(this);
    this.setLoadingStatus = this.setLoadingStatus.bind(this);
    this.setBetweenTerms = this.setBetweenTerms.bind(this);
    /* Below is test code */
    this.state = { eventText: '' };
    this.changeTestEvent = this.changeTestEvent.bind(this);
    this.testLink = this.testLink.bind(this);
  }

  componentDidMount() {
    this.updateUsageValues();
  }

  updateUsageValues() {
    const jwtData = BuurContainer.parseJwt(window.App.microservices.Session.token);
    const dateTab = this.props.ContextHeader.Date_Tab;
    const roster = this.props.ContextHeader.Roster_Tab;
    const usage = this.props.usageReports;
    const newDateData = {};
    let startDate = usage.startDate;
    let endDate = usage.endDate;
    let termId = usage.termId;
    let newDates = false;
    if (startDate === null || usage.uiStartDate === null) {
      if (dateTab.Report_termStartDate !== undefined && dateTab.Report_termStartDate !== '') {
        startDate = dateTab.Report_termStartDate;
        newDateData.startDate = startDate;
        newDateData.uiStartDate = startDate;
        newDates = true;
      }
    }
    if (endDate === null || usage.uiEndDate === null) {
      if (dateTab.Report_termEndDate !== undefined && dateTab.Report_termEndDate !== '') {
        endDate = dateTab.Report_termEndDate;
        newDateData.endDate = endDate;
        newDateData.uiEndDate = endDate;
        newDates = true;
      }
    }
    if (termId === null || usage.uiTermId === null) {
      if (dateTab.selectedTermId !== undefined && dateTab.selectedTermId !== '') {
        termId = dateTab.selectedTermId;
        newDateData.termId = termId;
        newDateData.uiTermId = termId;
        newDates = true;
      }
    }
    if (newDates) {
      this.setDateData(newDateData);
    }
    if (usage.realmId === null) {
      const idGroups = {
        realmId: jwtData.realm_id,
        district: [],
        school: [],
        grade: [],
        teacher: [],
        class: [],
      };
      const roleData = window.App.model.attributes.roles;
      let nounType = '';
      Object.keys(roleData).forEach((role) => {
        Object.keys(roleData[role]).forEach((id) => {
          nounType = roleData[role][id].collectiveType.toLowerCase();
          if (nounType !== 'group') {
            idGroups[nounType].push(id);
          }
        });
      });
      if (idGroups.district.length === 0) {
        idGroups.district.push(roster.SelectedDistrict.id);
      }
      this.props.SetUsageInitialData(
        idGroups.realmId,
        idGroups.district,
        idGroups.school,
        idGroups.grade,
        idGroups.teacher,
        idGroups.class
      );
    }
  }

  setNavigationLevel(level) {
    const lowerLevel = level.toLowerCase();
    const validNavigationLevels = ['district', 'school', 'class'];
    if (validNavigationLevels.indexOf(lowerLevel) > -1) {
      this.props.SetUsageReportsNavigationLevel(lowerLevel);
    } else {
      console.log('Bad context level provided from BUUR: ', lowerLevel);
    }
  }

  setUiNavigationLevel(level) {
    const lowerLevel = level.toLowerCase();
    const validNavigationLevels = ['district', 'school', 'class'];
    if (validNavigationLevels.indexOf(lowerLevel) > -1) {
      this.props.UsageSetUiNavigationLevel(lowerLevel);
    } else {
      console.log('Bad context level provided from BUUR: ', lowerLevel);
    }
  }

  setGradeLevel(grades) {
    const newGrades = [];
    grades.forEach((grade)=>{
      if (grade.length < 6) {
        newGrades.push(`grade_${grade}`);
      } else {
        newGrades.push(grade);
      }
    });
    this.props.SetUsageReportsCollectiveNounUiIds('uiGradeIds', newGrades);
    this.props.SetUsageReportsGrade(newGrades);
  }

  setCollectiveNounList(buurEvent) {
    const baseType = buurEvent.action.split('List')[0].toLowerCase();
    if (baseType.indexOf('grade') > -1) {
      this.props.SetUsageReportsCollectiveNounUiIds('uiGradeIds', []);
      this.setGradeLevel([]);
    } else {
      this.setCollectiveNounIds({
        action: `${baseType}Ids`,
        data: []
      });
    }
    this.props.SetUsageRosterList(buurEvent.action, buurEvent.data);
  }

  setCollectiveNounIds(buurEvent) {
    let validType = '';
    let uiType = null;
    switch(buurEvent.action) {
      case 'districtIds':
      case 'districtId':
        validType = 'district';
        break;
      case 'schoolIds':
      case 'schoolId':
        validType = 'school';
        uiType = 'uiSchoolIds';

        break;
      case 'teacherIds':
      case 'teacherId':
        validType='teacher';
        uiType = 'uiTeacherIds';

        break;
      case 'classIds':
      case 'classId':
        validType='class';
        uiType = 'uiClassIds';

        break;
      case 'studentIds':
      case 'studentId':
        validType='student';
        uiType = 'uiStudentIds';

        break;
      default:
        validType = '';
    }
    if (validType === '') {
      console.log('Invalid collective noun identifier given by BUUR: ', buurEvent.action);
      return;
    }
    if (uiType !== null) {
      let updatedData = buurEvent.data

      const {refreshCondition,idsReplace} = conditionExecution(uiType,this.props.usageReports)
  
      if(refreshCondition){
        updatedData = idsReplace
      }

      this.props.SetUsageReportsCollectiveNounUiIds(uiType, updatedData);
      const newContextName =
        setContextNames(validType, updatedData, this.props.usageReports[`${validType}List`] );
      this.props.SetUsageContextNames(newContextName);
    }
    this.props.SetUsageReportsCollectiveNounIds(validType, buurEvent.data);
  }

  setDateData(dateObject) {
    this.props.SetUsageDates(dateObject);
  }

  setLoadingStatus(buurEvent) {
    this.props.SetUsageReportsLoadingStatus(buurEvent.action, buurEvent.data);
  }

  setBetweenTerms(status) {
    this.props.SetUsageReportsBetweenTerms(status);
  }

  handleBuurCallback(buurEvent) {
    let eventArray = buurEvent;
    if (!Array.isArray(eventArray)) {
      eventArray = [buurEvent];
    }
    eventArray.forEach((buurAction) => {
      switch (buurAction.action) {
        case 'districtName':
          this.props.SetUsageReportsDistrictName(buurAction.data);
          break;
        case 'disableTerms':
          this.props.SetUsageReportTermDisabled(buurAction.data);
          break;
        case 'navigationLevel':
          this.setNavigationLevel(buurAction.data);
          break;
        case 'uiNavigationLevel':
          this.setUiNavigationLevel(buurAction.data);
          break;
        case 'grades':
        case 'grade':
          this.setGradeLevel(buurAction.data);
          break;
        case 'startDate':
          this.setDateData({startDate: buurAction.data});
          break;
        case 'endDate':
          this.setDateData({endDate: buurAction.data});
          break;
        case 'termID':
          this.setDateData({termId: buurAction.data});
          break;
        case 'betweenTerms':
          this.setBetweenTerms(buurAction.data);
          break;
        case 'schoolLoading':
        case 'gradeLoading':
        case 'teacherLoading':
        case 'classLoading':
        case 'studentLoading':
          this.setLoadingStatus(buurAction);
          break;
        case 'schoolList':
        case 'gradeList':
        case 'teacherList':
        case 'classList':
        case 'studentList':
        case 'gradeList':
          this.setCollectiveNounList(buurAction);
          break;
        default:
          this.setCollectiveNounIds(buurAction);
      }
    });
  }

  changeTestEvent(changeEvent) {
    this.setState({ eventText: changeEvent.currentTarget.value });
  }

  testLink() {
    try {
      const constructedEvent = JSON.parse(this.state.eventText);
      console.log(constructedEvent);
      this.handleBuurCallback(constructedEvent);
    } catch (e) {
      console.log('bad JSON');
    }
  }

  render() {
    const usage = this.props.usageReports;
    const { uiSchoolIds,
      uiTeacherIds,
      uiClassIds,
      uiGradeIds,
      uiStudentIds
    } = usage;
    const userProfile =
      BuurContainer.composeUserProfileObject(this.props.LoginDetails);
    const terms =
      BuurContainer.composeTerms(this.props.ContextHeader.Date_Tab.DistrictTerms_New);
    const { realmId, districtIds, schoolIds, grade, teacherIds, classIds, studentIds } = usage;
    const navigationLevel = usage.navigationLevel;
    const passProps = {
      reportsCallback: this.handleBuurCallback,
      navigationLevel,
      realmId,
      districtIds,
      schoolIds,
      teacherIds,
      classIds,
      grades: grade,
      studentIds,
      uiSchoolIds,
      uiTeacherIds,
      uiClassIds,
      uiGradeIds,
      uiStudentIds,
      startDate: usage.startDate,
      endDate: usage.endDate,
      termId: usage.termId,
      terms,
      userProfile,
    };
    return (
      <div className={"srf-buur-container"}>
        <React.Suspense fallback={<p>Loading BUUR</p>} >
          <BUURApp {...passProps} />
        </React.Suspense>

      </div>
    );
  }
}

/*
<input
          type="text"
          name="eventText"
          value={this.state.eventText}
          onChange={this.changeTestEvent}
        />
        <button onClick={this.testLink}>
          Execute Callback
        </button>
*/

const mapStateToProps = ({ Universal, Authentication }) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, usageReports } = Universal;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    Universal,
    usageReports
  };
};

export default connect(mapStateToProps,{
  SetUsageReportTermDisabled,
  SetUsageReportsCollectiveNounIds,
  SetUsageReportsCollectiveNounUiIds,
  SetUsageReportsNavigationLevel,
  SetUsageReportsGrade,
  SetUsageDates,
  SetUsageInitialData,
  SetUsageRosterList,
  SetUsageReportsLoadingStatus,
  SetUsageReportsBetweenTerms,
  UsageSetUiNavigationLevel,
  SetUsageReportsDistrictName,
  SetUsageContextNames
}) (BuurContainer);
