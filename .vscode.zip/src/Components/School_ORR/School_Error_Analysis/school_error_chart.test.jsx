import Sc_ErrorChart from './school_error_chart';
import React from 'react';
import { shallow } from 'enzyme';

jest.mock('react-redux', () => ({
    connect: jest.fn().mockImplementation(() => (component) => component),
  }));
  function setup(overrides = {}) {
    const props = {
      School_EA_Dropdown: jest.fn(),
      LoginDetails: { JWTToken: 'test token'},
      ContextHeader: {
        Date_Tab: {
          Report_termEndDate: '2015-07-01 00:00:00',
          selectedterm_Obj: {
            termStartDate: '2015-07-01 00:00:00',
          },
        },
        Roster_Tab: {
          SelectedClass: { id: 123 },
          SelectedSchool: { id: 123 },
        }
      }
    };
    const finalProps = Object.assign(props, overrides);
    const wrapper = shallow((
        <Sc_ErrorChart {...finalProps} />
    ));
    return { wrapper };
  };
  describe('Sc_ErrorChart', () => {
    describe('renders properly', () => {
      const { wrapper } = setup();
      it('matches snapshot', () => {
        expect(wrapper.getElement()).toMatchSnapshot();
      });
    });
    describe('renders properly', () => {
      it('MakeSelectionForORR component not render default', () => {
        const { wrapper } = setup({
          'gridTitle' : {
            '2017 August': [{
              "type": "Instructional",
              "readingLevel": "L",
              "month": "2017 August",
              "monthYear": "08/2017",
              "recentRecord": false
            }]
          }
        });
        expect(wrapper.find('NoRosterData')).toHaveLength(1);
      });
    });
  });
