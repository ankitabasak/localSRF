import React, { PureComponent } from 'react';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';
import '../../Class_ORR/class-common.css';
import { connect } from 'react-redux';
import {
  SAVE_SORTED_EA,
  SORT_EA_GRID,
  SHOW_HIDE_BAR
} from '../../../Redux_Actions/School_ErrorAnalysisAction.jsx';
import {
  navigateToStudentReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';

class Sc_Ea_Table extends PureComponent {
  constructor(props) {
    super(props);
    this.goToStudentReport = this.goToStudentReport.bind(this);
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text) {
    if (text && text.length > 20) {
      return (
        <React.Fragment>
          {text.substr(0, 20)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text ? text : <span>&mdash;</span>);
    }
  }
  goToStudentReport(studentInfo) {
    let grade = 'grade_' + this.props.selectedGrade.toLocaleLowerCase();
    studentInfo['grade'] = grade;
    //this.props.GetCompleteStudentReport();
    this.props.navigateToStudentReport(studentInfo, false);
  }

  schoolEaGridData(Data, tableData) {
    return (
      <div className="class_ea-inner-wrap">
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="scea"
        >
          <div className="student-column-list-rhs-sec sc-error-07-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'lastName',
                Data.sortType
              )}
            >
              Class/Student ({tableData.length})
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'lastName', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('lastName', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'lastName', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('lastName', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec sc-error-07-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'readingLevel',
                Data.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'readingLevel', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('readingLevel', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'readingLevel', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('readingLevel', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec sc-error-07-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'proficiency',
                Data.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'proficiency', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('proficiency', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'proficiency', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('proficiency', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec sc-error-07-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'assignmentDate',
                Data.sortType
              )}
            >
              Date
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'assignmentDate', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('assignmentDate', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'assignmentDate', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('assignmentDate', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "cea-scroll")}>
          {tableData.map((schoolDetails, index) => (
            <div
              className="student-list-row-rhs-sec sc-rlp sc-rho-wrap"
              key={index}
            >
              <div
                className={
                  this.props.sideTableData.showAccordion[
                    schoolDetails.className
                  ]
                    ? 'expanded-group cursor-pointer'
                    : 'collapsed-group cursor-pointer'
                }
                style={{ backgroundColor: '#F3F5FA' }}
                onClick={() => this.showCollapse(schoolDetails.className)}
              >
                <span className=" wb-break-all">
                  {schoolDetails.className}&nbsp;&nbsp;(
                  {schoolDetails.studentDetails.length}
                  &nbsp;Students)
                </span>
              </div>

              {schoolDetails.studentDetails.map((tableDetails, value) => (
                <div
                  className={
                    'pos-rel student-list-row-rhs-sec sc-error-07-20 ' +
                    (this.props.sideTableData.showAccordion[
                      schoolDetails.className
                    ]
                      ? 'show'
                      : 'hide')
                  }
                  key={value}
                >
                  <div className="student-column-list-rhs-sec" onClick={() => { this.goToStudentReport(tableDetails) }}>
                    <span className="cursor-pointer wb-break-all long-text-tooltip ">
                      {this.longTextTooltip(tableDetails.firstName + ' ' + tableDetails.lastName)}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec sc-error-07-20">
                    <span>
                      {tableDetails.readingLevel
                        ? tableDetails.readingLevel
                        : dashSymbol}
                    </span>
                  </div>

                  <div className="student-column-list-rhs-sec">
                    <span>
                      {tableDetails.proficiency
                        ? tableDetails.proficiency
                        : dashSymbol}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec">
                    <span>
                      {tableDetails.assignmentDate
                        ? tableDetails.assignmentDate
                        : dashSymbol}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? 'rt-td-active'
      : '';
  }

  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return ' blueColor';
    } else {
      return '';
    }
  }
  //to collapse school
  showCollapse(classList) {
    this.props.SHOW_HIDE_BAR({
      ...this.props.sideTableData.showAccordion,
      [classList]: !this.props.sideTableData.showAccordion[classList]
    });
  }
  //Onclick calling sort function and update the sort type and column in store
  errorAnalysisGrid(sortColumn, sortType, actualArray) {
    document.getElementById('scea').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_EA_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map((actualArray) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(
          actualArray.studentDetails,
          column,
          sortType
        );
      }

    });
    this.props.SAVE_SORTED_EA(stdArray);
  }

  render() {
    return (
      <React.Fragment>
        {this.props.sideTableData && (
          <div className="col-md-4 res-width cea-rhs-rel mt-6 sch-eg-wrap">
            {this.props.sideTableData && (
              <div>
                {/* onclick and on load main api should send the Reading target */}
                <div className="pull-left rt-left-heading">
                  {this.props.sideTableData.selectedRecordDetails
                    .recordTitle === "All Record's Average"
                    ? "All Records' Average"
                    : this.props.sideTableData.selectedRecordDetails
                      .recordTitle}
                </div>
                <div className="pos-rel">
                  <div className="rt-rhs-strip"></div>
                  <hr className="clearfix mb-8" />
                </div>
                <div className="mb-10">
                  <div className="reading-level-label mb-8 color-1">
                    First Record Date Range:
                    <span> {
                      this.props.sideTableData.selectedRecordDetails
                        .firstRecordDateRange
                    }
                    </span>
                  </div>
                  <div className="reading-level-label color-2">
                    Recent Record Date Range:
                    <span> {
                      this.props.sideTableData.selectedRecordDetails
                        .recentRecordDateRange
                    }
                    </span>
                  </div>
                </div>
                <div className="pull-right clearfix new-mb-4 rt-label-txt">
                  <span className="rt-label">
                    No. of students rostered:
                    <span> {
                      this.props.sideTableData.selectedRecordDetails
                        .noOfStudentsRoastered
                    }
                    </span>
                  </span>
                </div>
                <div className="rhs-wrap class-ea school-ea-wrap">
                  <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                    <div className="student-list-table-main">
                      <div className="student-list-table-rhs-sec">
                        {this.schoolEaGridData(
                          this.props.Data,
                          this.props.sideTableData.tableData
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        {this.props.disableDiv && (
          <div className="col-md-4 res-width display-msg err-msg-alignment">
            <img src={spinner} alt="spinner" />
          </div>
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { SAVE_SORTED_EA, SORT_EA_GRID, SHOW_HIDE_BAR, navigateToStudentReport }
)(Sc_Ea_Table);
// export default Sc_Ea_Table;
