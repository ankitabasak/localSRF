import React, { Component } from 'react';
import {
  SCHOOL_EA_API,
  SCHOOL_LOAD_STATUS_ICON,
  SEA_CSVDATA_DOWNLOAD_APICALL,
  SEA_CSVDATA_DOWNLOAD_RESET,
  School_EA_Dropdown
} from '../../../Redux_Actions/School_ErrorAnalysisAction.jsx';

import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import Filter from '../../ORR/FilterComponents/Filter';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import NoRosterData from '../../../Utils/NoRoster.js';
import Sc_Ea_Table from './school-error-grid.jsx';
import SchoolErrorAnalysisChart from './school-error-analysis-chart.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import { connect } from 'react-redux';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import NoRecordsData from '../../../Utils/No_Data_Found';
import PrintScEa from '../../ReusableComponents/PrintOrrCharts/Sc_EaPrint.jsx';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { AGPDistrictCSV } from "../../../Redux_Actions/District_Report_Actions";
import { csvDownload } from "../../../Utils/CSVDownload/AGPReports";
import Confirmation_AgpPopup from "../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup";
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from "../../../Utils/globalVars";

class Sc_ErrorChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      errorRecordType: {},
      timeOut: false,
      defaultFilterRecType: {
        allRecords: false,
        recentRecord: true
      },
      gradeValue: ''
    };
    this.timeOut = this.timeOut.bind(this);
    this.callErrorAnalysisApi = this.callErrorAnalysisApi.bind(this);
    this.gradeChange = this.gradeChange.bind(this);
    this.callApi = this.callApi.bind(this)
  }

  componentDidMount() {
    let commonHeaders = getCommonHeaders(this.props, 'school');

    let payload = {
      errorRecordType: {
        allRecords: false,
        recentRecord: true
      },
      ...{
        internalFilter: commonHeaders.internalFilter,
        externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScEA" })
      }
    };
    this.props.School_EA_Dropdown(this.props.LoginDetails.JWTToken, payload, this.props.ContextHeader.Roster_Tab.selectedRosterGrade);
  }

  // handle timeout
  timeOut() {
    this.setState({ ...this.state, timeOut: true });
  }
  //make api call
  callErrorAnalysisApi(type, grade) {
    this.props.SCHOOL_LOAD_STATUS_ICON();
    let Token = this.props.LoginDetails.JWTToken;
    let commonHeaders = getCommonHeaders(this.props, 'school');
    this.setState({
      ...this.state,
      timeOut: false
    });

    let errorRecordType = {
      allRecords: type === 'all' ? true : false,
      recentRecord: type === 'rec' ? true : false
    };

    let Req_Payload = {
      errorRecordType,
      ...{
        internalFilter: commonHeaders.internalFilter,
        externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScEA", grade: grade })
      },
    };
    this.props.SCHOOL_EA_API(Token, Req_Payload);
  }

  //api call on grade select
  gradeChange(grade) {
    this.callErrorAnalysisApi(this.props.showRecordSea, grade);
  }

  //api call on type select
  callApi(type) {
    this.callErrorAnalysisApi(type, this.props.selectedGrade);
  }

  // Download csv data
  downLoadCSVData() {
    let Req_Payload = {
      schoolChartType: {
        "allGrades": true,
        "allRecordsAvgFlag": 0,
        "chartName": "ScEA",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'school')
    };
    delete Req_Payload.externalFilter.selectedStudentsList;
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, Req_Payload);
    } else {
      this.props.SEA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.SEA_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
    }
  }

  render() {
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedSchool.name;
    if (this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['downloadInProgress'] && this.props.SchoolCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SEA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    return (
      <div>
        {this.props.NavigationByHeaderSelection && this.props.NavigationByHeaderSelection.school &&
          this.props.ContextHeader.Roster_Tab.SelectedSchool.id ? (
            <div>
              <Filter
                externalFilter={this.state.externalFilter}
                internalFilter={this.props.CommonFilterData}
                errorRecordType={this.state.defaultFilterRecType}
                gradeSel={this.props.selectedGrade}
              />
              {this.props.firstRecordObj && (
                <div className="container container-resolution cfa">
                  <React.Fragment>
                    {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                      <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
                    <div className="row" id="testSchoolChart">
                      {this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['csvData'] &&
                        <CSVLink
                          ref="groupCSV"
                          headers={this.props.SchoolCsvDownload['csvData'] && this.props.SchoolCsvDownload['csvData']['header']}
                          data={this.props.SchoolCsvDownload['csvData'] && this.props.SchoolCsvDownload['csvData']['data']}
                          style={{ display: 'none' }}
                          filename={`${csvFileName}.csv`}
                        />}
                      <div className="dst-csv-icon-alignment" onClick={() => !this.props.SchoolCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                        {this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['downloadInProgress'] ?
                          <span className="csv_download_icon">
                            <i className="material-icons">autorenew</i>
                          </span> :
                          <span className="csv_download_icon">
                            <img src={CsvIcon} width="20" height="20" />
                          </span>}
                      </div>
                      <SchoolErrorAnalysisChart
                        seaPrint={false}
                        firstRecord={this.props.firstRecordObj}
                        ContextHeader={this.props.ContextHeader}
                        allRecord={this.props.allRecordObj}
                        recentRecord={this.props.recentRecordObj}
                        makeApiCall={x => { this.callApi(x) }}
                        errorRange={this.props.errorRange}
                        msvErrorRange={this.props.msvErrorRange}
                        showHideRecentRecord={this.props.showHideRecentRecord}
                        SelectedErr={this.props.SelectedErr}
                        CommonFilterData={this.props.CommonFilterData}
                        externalFilter={this.state.externalFilter}
                        showRecord={this.props.showRecordSea}
                        token={this.props.LoginDetails.JWTToken}
                        disableDiv={this.props.disableDiv}
                        dropDownData={this.props.dropDownData}
                        triggerDropDown={x => { this.gradeChange(x) }}
                        selectedGrade={this.props.selectedGrade}
                        isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                      />
                      <Sc_Ea_Table
                        scrollFlag={false}
                        sideTableData={this.props.sideTableData}
                        Data={this.props.SortData}
                        disableDiv={this.props.disableDiv}
                        selectedGrade={this.props.selectedGrade}
                      />
                      {this.props.ErrorCode === 500 && (
                        <div className="col-md-4 res-width err-msg-alignment">
                          <MakeSelectionForORR />
                        </div>
                      )}
                    </div>
                    {this.props.firstRecordObj && this.props.sideTableData && (
                      <span className="print-icon-class-btn ipad-print-algn">
                        <PrintScEa
                          scrollFlag={true}
                          selectedFilter={this.props.CommonFilterData}
                          studentDetails={this.props.ContextHeader}
                          navSelected={this.props.NavigationByHeaderSelection}
                          firstRecord={this.props.firstRecordObj}
                          allRecord={this.props.allRecordObj}
                          recentRecord={this.props.recentRecordObj}
                          errorRange={this.props.errorRange}
                          msvErrorRange={this.props.msvErrorRange}
                          showHideRecentRecord={this.props.showHideRecentRecord}
                          SelectedErr={this.props.SelectedErr}
                          internalFilter={this.props.CommonFilterData}
                          externalFilter={this.state.externalFilter}
                          showRecord={this.props.showRecordSea}
                          token={this.props.LoginDetails.JWTToken}
                          disableDiv={this.props.disableDiv}
                          dropDownData={this.props.dropDownData}
                          selectedGrade={this.props.selectedGrade}
                          sideTableData={this.props.sideTableData}
                          Data={this.props.SortData}
                          disableDiv={this.props.disableDiv}
                          isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                        />
                      </span>
                    )}
                  </React.Fragment>
                </div>
              )}
              {!this.props.firstRecordObj &&
                !this.state.timeOut &&
                !this.props.apiLoadFail &&
                !this.props.noDataFound &&
                !this.props.GradesNotAvailable && (
                  <Spinner
                    startSpinner={!this.props.firstRecordObj}
                    showTimeOut={this.timeOut}
                  />
                )}
              {!this.props.firstRecordObj && this.state.timeOut && (
                <TimeOut tryAgain={() =>
                  this.callErrorAnalysisApi(this.props.showRecordSea,
                    this.props.selectedGrade)
                } />
              )}
              {this.props.apiLoadFail && !this.props.isApiLoading && (
                <ChartNotLoad
                  tryAgain={() =>
                    this.callErrorAnalysisApi(this.props.showRecordSea,
                      this.props.selectedGrade)
                  } />
              )}
              {this.props.noDataFound && !this.props.GradesNotAvailable && (
                <NoRecordsData NodataFound={'dataNotAvail'} />
              )}
              {this.props.GradesNotAvailable && (
                <NoRecordsData NodataFound={'dataNotAvail'} />
              )}
            </div>
          ) : (
            <NoRosterData />
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  SchoolErrorAnalysisData
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const { CommonFilterData } = CommonFilterDetails;
  const {
    noDataFound,
    firstRecordObj,
    allRecordObj,
    recentRecordObj,
    sideTableData,
    errorRange,
    msvErrorRange,
    SortData,
    showHideRecentRecord,
    SelectedErr,
    ErrorCode,
    apiLoadFail,
    isDataAvailable,
    showRecordSea,
    disableDiv,
    dropDownData,
    responseData,
    selectedGrade,
    isAllThreeMsvValuesNull,
    SchoolCsvDownload,
    GradesNotAvailable,
  } = SchoolErrorAnalysisData;
  return {
    noDataFound,
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    firstRecordObj,
    allRecordObj,
    recentRecordObj,
    sideTableData,
    errorRange,
    msvErrorRange,
    SortData,
    showHideRecentRecord,
    SelectedErr,
    ErrorCode,
    apiLoadFail,
    isDataAvailable,
    showRecordSea,
    disableDiv,
    CommonFilterData,
    dropDownData,
    responseData,
    selectedGrade,
    isAllThreeMsvValuesNull,
    SchoolCsvDownload,
    GradesNotAvailable,
    AgpCSV,
  };
};

export default connect(
  mapStateToProps,
  {
    SCHOOL_EA_API,
    SCHOOL_LOAD_STATUS_ICON,
    School_EA_Dropdown,
    SEA_CSVDATA_DOWNLOAD_APICALL,
    SEA_CSVDATA_DOWNLOAD_RESET,
    AGPDistrictCSV,
  }
)(Sc_ErrorChart);
