import '../../Class_ORR/C_ReadingBehaviorComponents/C_RB.css';
import './School_RB.css';

import {
    Chart_loading_Failed,
    SAVE_SORTED_GRID_DATA,
    SCHOOL_RB_SORT_COLUMN,
    SRB_CSVDATA_DOWNLOAD_APICALL,
    SRB_CSVDATA_DOWNLOAD_RESET,
    Sc_RB_GRADES,
    School_RB_Chart_API_Call,
    School_RB_Dropdown,
    School_RB_SidePanel_API_Call,
    Show_loading_Icon,
    Update_Accordion_State,
    Update_Chart_Accordion_State,
    updateSelectedItems
} from '../../../Redux_Actions/School_RB_Actions.jsx';
import React, { PureComponent } from 'react';
import { getCommonHeaders, getDateFormat } from '../../ReusableComponents/OrrReusableComponents';

import { AGPDistrictCSV } from '../../../Redux_Actions/District_Report_Actions';
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from '../../../Utils/globalVars';
import { CSVLink } from "react-csv";
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import Confirmation_AgpPopup from '../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';
import CsvIcon from '../../../../public/images/ic_save.svg';
import Filter from '../../ORR/FilterComponents/Filter';
import NoFluencyData from '../../../Utils/No_Data.js';
import NoRecordsData from '../../../Utils/No_Data_Found';
import NoRosterData from '../../../Utils/NoRoster.js';
import PrintScRb from '../../ReusableComponents/PrintOrrCharts/Sc_RbPrint.jsx';
import SchoolRBSidePanel from './School_RB_SidePanel.jsx';
import School_RB_Chart from './School_RB_Chart.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import { connect } from 'react-redux';
import { csvDownload } from '../../../Utils/CSVDownload/AGPReports';
import {
    navigateToStudentReport
} from "../../../Redux_Actions/UniversalSelectorActions";

class SchoolRBContainer extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            externalFilter: {}
        };
    }

    componentDidMount() {
        let commonHeaders = getCommonHeaders(this.props, 'school');
        this.props.Show_loading_Icon();
        if (!this.props.dropDownData) {
            let payload = {
                errorRecordType: {
                    allRecords: false,
                    recentRecord: true
                },
                ...{
                    internalFilter: commonHeaders.internalFilter,
                    externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScRB" })
                }
            };
            this.props.School_RB_Dropdown(this.props.LoginDetails.JWTToken, payload, this.props.ContextHeader.Roster_Tab.selectedRosterGrade);

        }
    }



    // initiate chart api call
    getCRBChartData() {
        let commonHeaders = getCommonHeaders(this.props, 'school');
        this.props.Show_loading_Icon();
        let payLoad = {
            internalFilter: commonHeaders.internalFilter,
            externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScRB", grade: this.props.selectedGrade })
        }
        this.props.School_RB_Chart_API_Call(this.props.LoginDetails.JWTToken, payLoad);
    }


    // Side panel API call for selcted boxes
    updateSelectedItems(listItems) {
        let commonHeaders = getCommonHeaders(this.props, 'school');
        let payLoad = {
            internalFilter: commonHeaders.internalFilter,
            externalFilter: Object.assign(commonHeaders.externalFilter, { grade: this.props.School_RB_State.selectedGrade })
        }
        this.props.updateSelectedItems(
            listItems,
            payLoad,
            this.props.LoginDetails.JWTToken
        );

        // calling side panel API
        let labelType = Object.keys(listItems)[0];
        let panelApiData = listItems[labelType];
        let cpbSidePanelRequestList = [];

        if (panelApiData && panelApiData.length > 0) {
            panelApiData.forEach(item => {

                cpbSidePanelRequestList.push({
                    sourceCriteriaId: item['sourceCriteriaId'],
                    selectedRanges: item['selectedRanges']

                });
            });
        }

        if (cpbSidePanelRequestList && cpbSidePanelRequestList.length > 0) {
            this.props.School_RB_SidePanel_API_Call(this.props.LoginDetails.JWTToken, {
                ...payLoad,
                ['cpbSidePanelRequestList']: cpbSidePanelRequestList,
                label: labelType.replace('Count', '')
            });
        }

    }

    // handle timeout
    timeOut() {
        this.props.Chart_loading_Failed({
            noChartData: false,
            apiLoadFail: false,
            timeout: true,
            isApiLoading: false
        });
    }

    updateSortColumn(sortColumn, sortType) {
        this.props.SCHOOL_RB_SORT_COLUMN(sortColumn, sortType);
    }

    updateSortData(data) {
        this.props.SAVE_SORTED_GRID_DATA(data);
    }
    fetchGradeData(grade) {
        let commonHeaders = getCommonHeaders(this.props, 'school');
        this.props.Show_loading_Icon();
        let payLoad = {
            internalFilter: commonHeaders.internalFilter,
            externalFilter: Object.assign(commonHeaders.externalFilter, { grade: grade })
        }
        this.props.School_RB_Chart_API_Call(this.props.LoginDetails.JWTToken, payLoad);
    }

    // Download csv data
    downLoadCSVData() {
        let Req_Payload = {
            schoolChartType: {
                "allGrades": true,
                "allRecordsAvgFlag": 0,
                "chartName": "ScRB",
                "gradeValue": null
            },
            ...getCommonHeaders(this.props, 'school')
        };
        delete Req_Payload.externalFilter.selectedStudentsList;
        if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
            csvDownload(this.props, Req_Payload);
        } else {
            this.props.SRB_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
            this.props.SRB_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
        }
    }

    render() {
        let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedSchool.name;
        let chartData = this.props.School_RB_State.chartData;
        let sidePanelData = this.props.School_RB_State.sidePanelData;
        let selectedItems = this.props.School_RB_State.selectedBoxes;
        let dropDownData = this.props.School_RB_State.dropDownData
        if (this.props.School_RB_State.SchoolCsvDownload && this.props.School_RB_State.SchoolCsvDownload['downloadInProgress'] && this.props.School_RB_State.SchoolCsvDownload['csvData']) {
            setTimeout(() => {
                this.refs.groupCSV.link.click();
                this.props.SRB_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
            }, 500)
        }
        return (
            <React.Fragment>
                <Filter externalFilter={this.state.externalFilter} grade={this.props.School_RB_State.selectedGrade} />
                {!this.props.School_RB_State.isApiLoading &&
                    !this.props.School_RB_State.apiLoadFail &&
                    !this.props.School_RB_State.noData && this.props.School_RB_State.rubricDataMsg === null && chartData && (
                        <main>
                            {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                                <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
                            <section>
                                <div
                                    className="container class-RB-container"
                                    style={{
                                        maxWidth: '1165px',
                                        paddingLeft: '0px',
                                        paddingRight: '0px'
                                    }}
                                >
                                    <div className="tabs">
                                        <div className="tab full-width">
                                            <div
                                                className="sea-wrapper pos-rel crb-wrap"
                                                style={{ width: '100%' }}
                                            >
                                                <div className="row" id="testSchoolChart">

                                                    <div className="col-lg-7 res-width-8 cfa-lft-box crb-accor sc_rb_lefttext crb-ipad-view">
                                                        <p class="reading-level-text pull-left">Reading Behavior</p>
                                                        {chartData && (
                                                            <School_RB_Chart
                                                                scroll={true}
                                                                dropDownData={dropDownData}
                                                                chartAccordionState={this.props.School_RB_State.chartAccordionsState}
                                                                updateSelectedGrade={(grade) => { this.fetchGradeData(grade) }}
                                                                data={chartData}
                                                                gradeSelected={this.props.School_RB_State.selectedGrade}
                                                                selectedRB={selectedItems}
                                                                updateSelctedItems={selectedObj => {
                                                                    this.updateSelectedItems(selectedObj);
                                                                }}
                                                                setAccordionState={(index) => { this.props.Update_Chart_Accordion_State(this.props.School_RB_State.chartAccordionsState, index) }}
                                                            />
                                                        )}
                                                    </div>
                                                    <div className="col-md-4 res-width cea-rhs-rel mt-6 crb-ipad-grid-view-rhs scrb-left mtop-10 scrb-mt0">
                                                        {chartData && (
                                                            <SchoolRBSidePanel
                                                                scrollFlag={false}
                                                                schoolData={sidePanelData}
                                                                sidePanelTableData={this.props.School_RB_State.sidePanelTableData}
                                                                sortData={this.props.School_RB_State.SortData}
                                                                selectedLevels={this.props.School_RB_State.selectedBoxes}
                                                                setAccordionState={(index) => { this.props.Update_Accordion_State(this.props.School_RB_State.accordionsState, index) }}
                                                                accordionState={this.props.School_RB_State.accordionsState}
                                                                sidePanelApiFailed={this.props.School_RB_State.sidePanelApiFailed}
                                                                updateSortData={(array) => { this.props.SAVE_SORTED_GRID_DATA(array) }}
                                                                updateSortColumn={(column, sortType) => { this.props.SCHOOL_RB_SORT_COLUMN(column, sortType) }}
                                                                gradeSelected={this.props.School_RB_State.selectedGrade}
                                                                navigateToStudentReport={(studentInfo) => { this.props.navigateToStudentReport(studentInfo, false); }}
                                                            />
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                            {this.props.School_RB_State.SchoolCsvDownload && this.props.School_RB_State.SchoolCsvDownload['csvData'] &&
                                                <CSVLink
                                                    ref="groupCSV"
                                                    headers={this.props.School_RB_State.SchoolCsvDownload['csvData'] && this.props.School_RB_State.SchoolCsvDownload['csvData']['header']}
                                                    data={this.props.School_RB_State.SchoolCsvDownload['csvData'] && this.props.School_RB_State.SchoolCsvDownload['csvData']['data']}
                                                    style={{ display: 'none' }}
                                                    filename={`${csvFileName}.csv`}
                                                />}
                                            <div className="dst-csv-icon-alignment" onClick={() => !this.props.School_RB_State.SchoolCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                                                {this.props.School_RB_State.SchoolCsvDownload && this.props.School_RB_State.SchoolCsvDownload['downloadInProgress'] ?
                                                    <span className="csv_download_icon">
                                                        <i className="material-icons">autorenew</i>
                                                    </span> :
                                                    <span className="csv_download_icon">
                                                        <img src={CsvIcon} width="20" height="20" />
                                                    </span>}
                                            </div>
                                            {chartData && sidePanelData &&
                                                <span className="print-icon-class-btn ipad-print-algn">
                                                    <PrintScRb
                                                        scrollFlag={true}
                                                        selectedFilter={this.props.CommonFilterData}
                                                        studentDetails={this.props.ContextHeader}
                                                        navSelected={this.props.NavigationByHeaderSelection}
                                                        chartAccordionState={this.props.School_RB_State.chartAccordionsState}
                                                        data={chartData}
                                                        gradeSelected={this.props.School_RB_State.selectedGrade}
                                                        selectedRB={selectedItems}
                                                        schoolData={sidePanelData}
                                                        sortData={this.props.School_RB_State.SortData}
                                                        selectedLevels={this.props.School_RB_State.selectedBoxes}
                                                        accordionState={this.props.School_RB_State.accordionsState}
                                                        sidePanelApiFailed={this.props.School_RB_State.sidePanelApiFailed}
                                                    />
                                                </span>}
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </main >
                    )}

                {this.props.School_RB_State.isApiLoading && !chartData && !this.props.School_RB_State.GradesNotAvailable && (
                    <Spinner
                        startSpinner={this.props.School_RB_State.isApiLoading}
                        showTimeOut={this.timeOut}
                    />
                )}
                {this.props.School_RB_State.timeout && (
                    <TimeOut tryAgain={this.getCRBChartData} />
                )}
                {this.props.School_RB_State.apiLoadFail && !this.props.School_RB_State.isApiLoading && <ChartNotLoad tryAgain={this.getCRBChartData} />}
                {this.props.School_RB_State.noChartData && !this.props.School_RB_State.isApiLoading &&
                    !this.props.School_RB_State.GradesNotAvailable && (
                        <NoRecordsData NodataFound={'dataNotAvail'} />
                    )}
                {this.props.School_RB_State.rubricDataMsg && !this.props.School_RB_State.isApiLoading &&
                    <div>
                        <NoFluencyData NoFluencyData={this.props.School_RB_State.rubricDataMsg} />
                    </div>
                }
                {this.props.School_RB_State.GradesNotAvailable && (
                    <NoRecordsData NodataFound={'dataNotAvail'} />
                )}
            </React.Fragment>
        );
    }
}

const mapStateToProps = ({
    Universal,
    Authentication,
    CommonFilterDetails,
    School_RB_State,

}) => {
    const { LoginDetails } = Authentication;
    const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
    const { CommonFilterData } = CommonFilterDetails;
    return {
        LoginDetails,
        ContextHeader,
        NavigationByHeaderSelection,
        CommonFilterData,
        School_RB_State,
        AgpCSV,
    };
};

export default connect(
    mapStateToProps,
    {
        Sc_RB_GRADES,
        School_RB_Chart_API_Call,
        Chart_loading_Failed,
        School_RB_SidePanel_API_Call,
        updateSelectedItems,
        SCHOOL_RB_SORT_COLUMN,
        SAVE_SORTED_GRID_DATA,
        Update_Accordion_State,
        Update_Chart_Accordion_State,
        Show_loading_Icon,
        School_RB_Dropdown,
        navigateToStudentReport,
        SRB_CSVDATA_DOWNLOAD_APICALL,
        SRB_CSVDATA_DOWNLOAD_RESET,
        AGPDistrictCSV,
    }
)(SchoolRBContainer);
