import React, { Component } from 'react';
import arrowDown from '../../../../public/assets/orr/rlp-screen/select-down-arrow.svg';
class School_RB_Chart extends Component {

    constructor(props) {
        super(props);
        this.handleDropdownChange = this.handleDropdownChange.bind(this);
    }
    componentDidMount(props) {
        if (this.props.data && this.props.data.length > 0) {

            this.setState({
                ...this.state,
                accordionSelected: this.props.data.length - 1
            });
        }
    }

    isSelected(item) {
        let listItems = this.props.selectedRB[item["rbType"]];
        let style = { color: "#333333" };
        if (listItems && listItems.length > 0) {
            listItems.forEach((obj, idx) => {
                if (
                    obj.sourceCriteriaId == item.sourceCriteriaId &&
                    obj.criteriaName == item.criteriaName &&
                    obj.selectedRanges == item.selectedRanges
                ) {
                    style = { color: "white", backgroundColor: "rgb(0, 83, 155)" };
                }
            });
        }
        return style;
    }
    // Save selcted boxes
    saveSelectedBoxes(obj) {
        let listItems = this.props.selectedRB[obj["rbType"]];
        let duplicateIdx = -1;
        if (listItems && listItems.length > 0) {
            listItems.forEach((item, idx) => {
                if (
                    obj.sourceCriteriaId == item.sourceCriteriaId &&
                    obj.criteriaName == item.criteriaName &&
                    obj.selectedRanges == item.selectedRanges
                ) {
                    duplicateIdx = idx;
                }
            });

            if (duplicateIdx > -1) {
                listItems.splice(duplicateIdx, 1);
            } else {
                listItems.push(obj);
            }
            this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
        } else {
            listItems = [obj];
            this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
        }
    }

    showCollapseAccordion(list) {
        // this.props.SHOW_HIDE_BAR(list);
    }
    //to collapse school
    hideShowAccordion(rubricList) {
        this.props.showHideAccordion({
            ...this.props.srbResponse.showSrbAccordion,
            [rubricList]: !this.props.srbResponse.showSrbAccordion[rubricList]
        });
    }
    //to display the last passage
    showToolTip(passage) {
        let crbHover = false;
        if (passage.length > 28) {
            crbHover = true;
        }
        if (crbHover) {
            return (
                <div className="hover-crb school-rb word-bk ">
                    {passage}
                    <div className="tooltip-dot" />
                </div>
            );
        }

    }

    showCriteriaName(cName) {
        let criteriaName = "";
        if (cName.length > 28) {
            criteriaName = cName.substring(0, 22) + "...";
        } else {
            criteriaName = cName;
        }
        return criteriaName;
    }

    handleDropdownChange(e) {

        this.props.updateSelectedGrade(e.target.value)
        // this.props.selectedErrGrade(e.target.value);
        // this.props.triggerDropDown(e.target.value);
    }

    render() {
        let gradeForDropDown = this.props.dropDownData
        let chartAccordion = this.props.chartAccordionState;
        if (this.props.data) {

            return (
                <React.Fragment>
                    {/* <!-- Left Chart Table Start --> */}

                    <div className="panel-group panel-width pt-20 school-rb-select-wrap" id="accordion">
                        <div className="crb-top-bor4"></div>
                        <div className="crb-top-bor5"></div>
                        <div className="sfa-grade-select">
                            <div className="bec-select">
                                <div className="select-side">
                                    <img src={arrowDown} alt="select" />
                                </div>
                                <span>Grade</span>
                                <select
                                    className="form-control"
                                    id="sel1"
                                    onChange={this.handleDropdownChange}
                                    value={this.props.gradeSelected}
                                >
                                    {gradeForDropDown && gradeForDropDown.map((value, index) => (
                                        <option key={index} className="cursor-pointer">{value}</option>
                                    ))}
                                </select>
                            </div>
                        </div>

                        <p className="crb-first-record lft-4">First Record</p>
                        <p className="crb-first-record">Recent Record</p>
                        <p className="all-crb-first-record">All Records' Average</p>
                        <div className="class-reading-behaviors">
                            <p>Processing Behaviors &amp; Strategies</p>
                        </div>
                        <div className={this.props.scroll ? "crb-inner-wrap" : "print-body"}>
                            <div className="divider-line-grey-left class-rb-lft-bor"></div>
                            {this.props.data.map((crbMainCategory, index) => {
                                return (
                                    <div className="panel panel-default" key={index}>
                                        <div
                                            className={
                                                chartAccordion[index]
                                                    ? "panel-heading mb-6 cursor-pointer expanded-accord"
                                                    : "panel-heading mb-6 cursor-pointer collapsed-accord"
                                            }
                                        >
                                            <h4
                                                className="panel-title mt-2 pos-rel"
                                                onClick={() => { this.props.setAccordionState(index) }}
                                            >
                                                {
                                                    chartAccordion[index] ? <div class="tab-left-border"></div> : <div className="tabs-bord"></div>
                                                }
                                                <a>{crbMainCategory["sourceRubricName"]}</a>
                                            </h4>
                                        </div>
                                        <div
                                            id="collapseOne"
                                            className="panel-collapse collapse in"
                                            className={
                                                chartAccordion[index]
                                                    ? "panel-collapse collapse in show"
                                                    : "panel-collapse collapse in"
                                            }
                                        >
                                            <div className="panel-body">
                                                <div className="container">
                                                    <div className="row pmb-5 pos-rel">
                                                        <div className="sc_rb_inner-bor"></div>
                                                        <div className="class-rb-col pos-rel pull-left">
                                                            <div class="crb-new-bord-strip"></div>
                                                            <div className="crb-left-color-strip"></div>

                                                            <ul>
                                                                {crbMainCategory["resultList"].map(
                                                                    (crbListItem, index) => {
                                                                        return (
                                                                            <li
                                                                                className="pos-rel crb-hover-container"
                                                                                key={index}
                                                                            >
                                                                                <div class="left-border"></div>
                                                                                <span>
                                                                                    {this.showCriteriaName(
                                                                                        crbListItem["sourceCriteriaName"]
                                                                                    )}
                                                                                </span>
                                                                                {this.showToolTip(
                                                                                    crbListItem["sourceCriteriaName"]
                                                                                )}
                                                                            </li>
                                                                        );
                                                                    }
                                                                )}
                                                            </ul>
                                                        </div>

                                                        <div
                                                            className="crb-first-record-error pos-rel"
                                                            id="firstRecord"
                                                        >

                                                            <div className="class-rb-table">
                                                                <div className="crb-first-error-col pos-rel scRb-first-col">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div class="crb-bor-11"></div>
                                                                    <div class="crb-bor-12"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "firstRecordCount"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "firstRecordCount",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ]
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "firstRecordCount",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: null
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["firstRecordCount"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="crb-first-record-error pos-rel scRb-first-col">
                                                            <div className="class-rb-table">
                                                                <div className="crb-first-error-col pos-rel scRb-first-col">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div class="crb-bor-11"></div>
                                                                    <div class="crb-bor-12"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "recentRecordCount"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "recentRecordCount",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: null
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "recentRecordCount",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: null
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["recentRecordCount"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="crb-first-record-error pos-rel scRb-first-col">
                                                            <div className="class-rb-table">
                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div class="crb-bor-12"></div>
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        'range0_25'
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '0-25'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '0-25'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range0_25"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range26_50"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '26-50'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '26-50'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range26_50"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range51_75"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '51-75'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '51-75'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range51_75"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range76_100"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '76-100'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '76-100'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range76_100"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                        {this.props.scroll &&
                            <div className="crb-perct-analysis pos-rel">
                                <div className="crb-btm-bor"></div>
                                <ul>
                                    <li>
                                        <span className="arrow_box-crb">% of Analysis</span>
                                    </li>
                                    <li style={{ borderBottom: " 4px solid rgb(213, 234, 242" }}>
                                        0-25
                                    </li>
                                    <li style={{ borderBottom: " 4px solid rgb(191, 224, 235" }}>
                                        26-50
                                    </li>
                                    <li style={{ borderBottom: " 4px solid rgb(170, 214, 229" }}>
                                        51-75
                                    </li>
                                    <li style={{ borderBottom: "4px solid rgb(128, 195, 218)" }}>
                                        76-100
                                    </li>
                                </ul>
                            </div>
                        }
                    </div>
                </React.Fragment>
            );
        } else {
            return <div></div>;
        }
    }
}

export default School_RB_Chart;