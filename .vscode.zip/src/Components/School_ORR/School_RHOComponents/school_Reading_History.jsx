import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  SCHOOL_READING_HISTORY_DATA,
  SCHOOL_RH_ERRORHANDLING,
  SCRHO_CSVDATA_DOWNLOAD_APICALL,
  SCRHO_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/School_ReadingHistoryAction.jsx';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import SchoolRho from './SchoolRho.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import NoRecordsData from '../../../Utils/No_Data_Found';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import Filter from '../../ORR/FilterComponents/Filter';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import PrintScRho from '../../ReusableComponents/PrintOrrCharts/Sc_RhoPrint.jsx';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from '../../../Utils/globalVars';
import { AGPDistrictCSV } from '../../../Redux_Actions/District_Report_Actions';
import { csvDownload } from '../../../Utils/CSVDownload/AGPReports';
import Confirmation_AgpPopup from '../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';

class School_Reading_History extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false
    };
    this.timeOut = this.timeOut.bind(this);
    this.schoolReadingHistoryApi = this.schoolReadingHistoryApi.bind(this);
  }

  componentDidMount() {
    this.schoolReadingHistoryApi();
  }
  // handle timeout
  timeOut() {
    this.props.SCHOOL_RH_ERRORHANDLING({
      isApiLoading: false,
      isDataNotAvailable: false,
      timeOut: true
    });
  }

  // Function for school Reading History Api
  schoolReadingHistoryApi() {
    // start spinner befor the api call
    this.props.SCHOOL_RH_ERRORHANDLING({
      isApiLoading: true,
      isDataNotAvailable: false,
      timeOut: false
    });
    this.setState({
      timeOut: false
    });
    let data = getCommonHeaders(this.props, 'school');
    this.props.SCHOOL_READING_HISTORY_DATA(
      this.props.LoginDetails.JWTToken,
      data
    );
  }

  // Download csv data
  downLoadCSVData() {
    let Req_Payload = {
      schoolChartType: {
        "allGrades": true,
        "allRecordsAvgFlag": 0,
        "chartName": "ScRHO",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'school')
    };
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, Req_Payload);
    } else {
      this.props.SCRHO_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.SCRHO_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
    }
  }

  render() {
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedSchool.name;
    let Data = this.props.SortData;
    let schoolReadingHistoryData = this.props.SchoolReadingHistoryDetails;
    let errorHandler = this.props.SchoolReadingHistoryDetails;
    let schoolObject = this.props.ContextHeader.School;
    if (this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['downloadInProgress'] && this.props.SchoolCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SCRHO_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    return (
      <div>
        {this.props.NavigationByHeaderSelection.school ? (
          <div>
            <Filter externalFilter={this.state.externalFilter} />
            {this.props.SchoolReadingHistoryDetails.data &&
              !errorHandler.timeOut &&
              !errorHandler.isDataNotAvailable && (
                <React.Fragment>
                  {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                    <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
                  <span className="print-icon-class-btn ipad-print-algn">
                    <PrintScRho
                      selectedFilter={this.props.CommonFilterData}
                      studentDetails={this.props.ContextHeader}
                      navSelected={this.props.NavigationByHeaderSelection}
                      schoolData={schoolReadingHistoryData}
                    />
                  </span>
                  <div id="testSchoolChart">
                    {this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.SchoolCsvDownload['csvData'] && this.props.SchoolCsvDownload['csvData']['header']}
                        data={this.props.SchoolCsvDownload['csvData'] && this.props.SchoolCsvDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        filename={`${csvFileName}.csv`}
                      />}
                    <div className="dst-csv-icon-alignment" onClick={() => !this.props.SchoolCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                      {this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <SchoolRho
                      schoolData={schoolReadingHistoryData}
                      sortData={this.props.SortData}
                    />
                  </div>
                </React.Fragment>
              )}
            {!this.props.SchoolReadingHistoryDetails.data &&
              errorHandler.isApiLoading && (
                <Spinner
                  startSpinner={errorHandler.isApiLoading}
                  showTimeOut={this.timeOut}
                />
              )}
            {!errorHandler.isApiLoading && errorHandler.timeOut && (
              <TimeOut tryAgain={this.schoolReadingHistoryApi} />
            )}
            {errorHandler.chartLoadFail && !errorHandler.timeOut && !errorHandler.isApiLoading && (
              <ChartNotLoad tryAgain={() => this.schoolReadingHistoryApi()} />
            )}
            {errorHandler.isDataNotAvailable && (
              <NoRecordsData NodataFound={'dataNotAvail'} />
            )}
          </div>
        ) : (
            <div>
              <NoRosterData />
            </div>
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  schoolReadingHistory,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const {
    SchoolReadingHistoryDetails,
    Response,
    SortData,
    isApiLoading,
    isDataNotAvailable,
    SchoolCsvDownload,
  } = schoolReadingHistory;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    SchoolReadingHistoryDetails,
    isApiLoading,
    isDataNotAvailable,
    Response,
    SortData,
    CommonFilterData,
    SchoolCsvDownload,
    AgpCSV,
  };
};

export default connect(
  mapStateToProps,
  {
    SCHOOL_READING_HISTORY_DATA, SCHOOL_RH_ERRORHANDLING,
    SCRHO_CSVDATA_DOWNLOAD_APICALL,
    SCRHO_CSVDATA_DOWNLOAD_RESET,
    AGPDistrictCSV,
  }
)(School_Reading_History);