import React, { Component } from 'react';

class SchoolRhoPrint extends Component {

    arrayConstruction(list, endIndex) {
        var arrayConst = list.map((data, index) => {
            return {
                header: data.className, listItems: this.schoolData(data.studentDetails, endIndex), count: data.studentDetails.length,
            }
        });
        return arrayConst
    }

    schoolData(list, endIndex) {
        var idx = 0
        var result = []
        while (idx < list.length) {
            if (idx % endIndex === 0) result.push([])
            result[result.length - 1].push(list[idx++])

        }
        return result;
    }

    crhoDataConstruction(list, endIndex) {
        let modifiedArray =
            this.arrayConstruction(list, endIndex);

        let total = modifiedArray.map((indArray, mainInd) => {
            return indArray.listItems.map((obj, idx) => {
                return this.printTable(obj, indArray.header, indArray.count, idx)
            })
        })
        return total
    }

    studentCount(list, idx) {
        let start = 1;
        let end = 0;
        if (idx === 0) {
            start = 1;
            end = list.length;
        } else {
            start = idx * 5 - 4;
            end = list.length < 5 ? start + list.length - 1 : idx * list.length
        }
        return `${start} - ${end}`
    }


    printTable(arr, header, count, idx) {
        const dashSymbol = <span>&mdash;</span>;
        return <React.Fragment>
            <table className={"scRhoTh-29-20 crho-table-print crhs-mt" + idx}
                style={{ pageBreakInside: 'avoid', pageBreakAfter: 'auto' }}>
                <tr className="" style={{ border: 'none' }}>
                    <th style={{ border: 'none' }}>{header}</th>
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Student({this.studentCount(arr, idx + 1)}/ {count})</th>
                    {arr.map((classDetails, i) => {
                        return <React.Fragment>
                            <th style={{ textAlign: "left" }}>{classDetails.firstName + ' ' + classDetails.lastName}</th>
                        </React.Fragment>
                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Date</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} >{data.assignmentDate}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Level </th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ height: '30px' }} key={value}>{data.letterLevel}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Proficiency</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.proficiency}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Passage </th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.lastPassage !== null ? data.lastPassage : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Category</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.category !== null ? data.category : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Accuracy</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.accuracy !== null ? data.accuracy + "%" : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Self-Correction</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>
                                    {data.selfCorrection !== null && data.selfCorrection !== 'NA'
                                        ? data.selfCorrection : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Fluency</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.fluency !== null ? data.fluency + ' wcpm' : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Retell</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.reTelling !== null ? data.reTelling : dashSymbol}</td>
                            </React.Fragment>)
                    })}
                </tr>
                <tr className="crho-print">
                    <th style={{ height: '30px' }}>Comprehension</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: 'left', height: '30px' }} key={value}>{data.comprehension !== null ? data.comprehension : dashSymbol}</td>
                            </React.Fragment>)
                    })}
                </tr>
            </table>
            <div className="pagebreak"> </div>
        </React.Fragment>
    }

    render() {
        return (
            <React.Fragment>
                {/* <table className={"crho-table-print crhs-mt" + index}> */}
                {this.crhoDataConstruction(this.props.schoolReadingHistoryData.data, 5)}
                {/* </table> */}
            </React.Fragment>
        )
    }
}

export default SchoolRhoPrint;