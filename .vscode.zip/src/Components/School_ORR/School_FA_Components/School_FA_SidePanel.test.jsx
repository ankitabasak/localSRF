import React from 'react';
import { shallow } from 'enzyme';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import SchoolFASidePanelComponent from './School_FA_SidePanel';

function setup(overrides = {}) {
  const props = {
  };
  const finalProps = Object.assign(props, overrides);
  const wrapper = shallow(( <SchoolFASidePanelComponent {...finalProps} /> ));
  return { wrapper };
};

describe('SchoolFASidePanelComponent', () => {
  describe('renders properly', () => {
    const { wrapper } = setup();
    it('renders component', () => {
      expect(wrapper).toHaveLength(1);
    });

    it('matches snapshot', () => {
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe('renders properly', () => {
    it('MakeSelectionForORR component not render default', () => {
      const { wrapper } = setup({
        bubblesSelected : {
          "recentRecord": [{
            "fluencyFrom": 0,
            "fluencyTo": 660,
            "grade": "K",
            "readingLevel": "A",
            "recordType": "recentRecord"
          }]
        }
      });
      expect(wrapper.find('MakeSelectionForORR')).toHaveLength(0);
    });

    it('MakeSelectionForORR component will render', () => {
      const { wrapper } = setup({
        bubblesSelected: []
      });
      expect(wrapper.find('MakeSelectionForORR')).toHaveLength(1);
    });
  });
});
