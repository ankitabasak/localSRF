import React, { Component } from "react";
import { getBubbleConfig } from "./bubbleConfiguration";
import rightScroll from "../../../../public/assets/orr/rlp-screen/x-next.svg";
import rightScrollActive from "../../../../public/assets/orr/rlp-screen/x-next-active.svg";
import rightExtremeScroll from "../../../../public/assets/orr/rlp-screen/x-next-end.svg";
import rightExtremeScrollActive from "../../../../public/assets/orr/rlp-screen/x-next-end-active.svg";
import arrowDown from '../../../../public/assets/orr/rlp-screen/select-down-arrow.svg';
class SchoolFABubblesComponent extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedBubbles: {},
      apiPayload: {},
      bgColor: { "0-20": "#d5eaf2", "20-80": "#bfe0eb", "80-100": "#aad6e5" }
    };

    this.getBubbleSize = this.getBubbleSize.bind(this);
    this.bubblesSelected = this.bubblesSelected.bind(this);
    this.handleDropdownChange = this.handleDropdownChange.bind(this)
    this.showToolTip = this.showToolTip.bind(this);
  }

  getBubbleSize(value) {
    if (value) {
      let data = getBubbleConfig(value);
      return {
        height: data.bubbleSize,
        width: data.bubbleSize,
        lineHeight: data.bubbleSize,
        fontSize: data.fontSize
      };
    }
  }

  bubblesSelected(bubble) {
    let selectedBubbles = this.props.bubsFromReducer;
    //let selectedBubbles = this.state.selectedBubbles;

    // this.props.bubsFromReducer;

    if (
      selectedBubbles[bubble.recordType] && selectedBubbles[bubble.recordType].length > 0 &&
      selectedBubbles[bubble.recordType][0]["grade"] == bubble["grade"]
    ) {
      let dupBubIdx = this.isDuplicateBubble(
        bubble,
        selectedBubbles[bubble.recordType]
      );
      if (dupBubIdx != -1) {
        selectedBubbles[bubble.recordType].splice(dupBubIdx, 1);
      } else {
        selectedBubbles[bubble.recordType].push(bubble);
      }
    } else {
      selectedBubbles = {};
      selectedBubbles[bubble.recordType] = [bubble];
    }

    this.setState({ ...this.state, ["selectedBubbles"]: selectedBubbles });

    this.props.bubblesSelected(selectedBubbles);
  }

  // check for duplicate bubble
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          obj.fluencyFrom === bubble.fluencyFrom &&
          obj.fluencyTo === bubble.fluencyTo &&
          obj.grade === bubble.grade &&
          obj.readingLevel === bubble.readingLevel
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  getBubBackColor(bubble) {

    let listItems = this.props.bubsFromReducer[bubble.recordType];
    let style = this.getBubbleSize(bubble.bubbleValue);

    if (listItems) {
      listItems.forEach(obj => {
        if (
          obj.fluencyFrom === bubble.fluencyFrom &&
          obj.fluencyTo === bubble.fluencyTo &&
          obj.grade === bubble.grade &&
          obj.readingLevel === bubble.readingLevel
        ) {
          style = {
            ...style,
            ["backgroundColor"]: this.state.bgColor[bubble.axisRange],
            border: "none",
            boxShadow: "inset 0 0 6px -1px rgba(0,0,0,0.5)"
          };
          return;
        }
      });
    }
    return style;
  }
  showToolTip_ttl(passage) {
    return (
      <div className="hover-crb cfa-hover ttl-std word-bk">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }
  showToolTip(passage) {
    return (
      <div className="hover-crb cfa-hover word-bk">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }

  handleDropdownChange(e) {

    this.props.upgradeSelectedGrade(this.props.monthData["gradesForDropDown"].indexOf(e.target.value))
    // this.props.selectedErrGrade(e.target.value);
    // this.props.triggerDropDown(e.target.value);
  }
  render() {
    if (this.props.monthData && this.props.monthData["currentGradeData"]) {
      let monthData = this.props.monthData["currentGradeData"];
      let scrollData = this.props["monthData"];
      let gradeForDropDown = this.props.monthData['gradesForDropDown']
      let selectedReadingLvls = this.props.selectedReadingLevels;


      return (
        <div className="graph-content  pull-left pos-rel no-bord ml-6">
          <p className="sfa-date-txt pull-left">Grade</p>
          <div className="firstColomn-Wrap">
            <div className="month-section">
              <span>Grades {monthData.grade}</span>
            </div>
            {/* first record panel */}

            <div className="first-coloumn pull-left colm-fm pos-rels">
              <div className="sfa-grade-select">
                <div className="bec-select">
                  <div className="select-side">
                    <img src={arrowDown} alt="select" />
                  </div>
                  <span>Grade</span>
                  <select
                    className="form-control"
                    id="sel1"
                    onChange={this.handleDropdownChange}
                    value={monthData['grade']}
                  >
                    {this.props.scFaChart &&
                      <option>{monthData['grade']}</option>}
                    {gradeForDropDown && gradeForDropDown.map((value, index) => (
                      <option key={index}>{value}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="top-slide-section">
                <span>First Record</span>
              </div>
              <div className="up-sec">
                <div className="sub-first-column pull-left pos-rel">
                  <div className="block-sec">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        return (
                          <li key={lvlIndex}>
                            <span>
                              {monthData["firstRecord"].totalStudents[
                                readingLevel
                              ]
                                ? monthData["firstRecord"].totalStudents[
                                readingLevel
                                ] + "%"
                                : ""}
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                  <div className="total-stu crb-hover-container">
                    <p>Total Students</p>
                    {this.showToolTip_ttl(
                      "Total Students Rostered"
                    )}
                  </div>
                  <div className="wcpm-section wcpm-bg">
                    <p>%</p>
                  </div>
                </div>
                <div className="sub-second-column pull-left pos-rel">
                  <div className="block-sec-2nd">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        if (
                          monthData["firstRecord"].wcpmList["0-20"] &&
                          monthData["firstRecord"].wcpmList["0-20"][
                          readingLevel
                          ]
                        ) {
                          return (
                            <li key={lvlIndex}>
                              <span
                                onClick={() => {
                                  this.bubblesSelected({
                                    recordType: "firstRecord",
                                    readingLevel: readingLevel,
                                    grade: monthData["grade"],
                                    fluencyFrom:
                                      monthData["firstRecord"].wcpmList["0-20"][
                                      readingLevel
                                      ]["fluencyFrom"],
                                    fluencyTo:
                                      monthData["firstRecord"].wcpmList["0-20"][
                                      readingLevel
                                      ]["fluencyTo"]
                                  });
                                }}
                                className={
                                  monthData["firstRecord"].wcpmList["0-20"][
                                    readingLevel
                                  ]
                                    ? "default-bubble first-bubble"
                                    : ""
                                }
                                style={this.getBubBackColor({
                                  axisRange: "0-20",
                                  readingLevel: readingLevel,
                                  recordType: "firstRecord",
                                  grade: monthData["grade"],
                                  bubbleValue: monthData["firstRecord"].wcpmList["0-20"][
                                    readingLevel
                                  ].value,
                                  fluencyFrom: monthData["firstRecord"]
                                    .wcpmList["0-20"][readingLevel]
                                    ? monthData["firstRecord"].wcpmList["0-20"][
                                    readingLevel
                                    ]["fluencyFrom"]
                                    : "",
                                  fluencyTo: monthData["firstRecord"].wcpmList[
                                    "0-20"
                                  ][readingLevel]
                                    ? monthData["firstRecord"].wcpmList["0-20"][
                                    readingLevel
                                    ]["fluencyTo"]
                                    : ""
                                })}
                              >
                                {monthData["firstRecord"].wcpmList["0-20"][
                                  readingLevel
                                ]
                                  ? monthData["firstRecord"].wcpmList["0-20"][
                                    readingLevel
                                  ].value + "%"
                                  : ""}
                              </span>
                            </li>
                          );
                        } else {
                          return (
                            <li key={lvlIndex}>
                              <span />
                            </li>
                          );
                        }
                      })}
                    </ul>
                  </div>

                  <div className="wcpm-section wcpm-bg1 crb-hover-container">
                    <p>{"≤20%"}</p>
                    {this.showToolTip(
                      "bottom 20th percentile"
                    )}
                  </div>
                </div>
                <div className="sub-third-column pull-left pos-rel">
                  <div className="block-sec-3rd">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        if (
                          monthData["firstRecord"].wcpmList["20-80"] &&
                          monthData["firstRecord"].wcpmList["20-80"][
                          readingLevel
                          ]
                        ) {
                          return (
                            <li key={lvlIndex}>
                              <span
                                onClick={() => {
                                  this.bubblesSelected({
                                    readingLevel: readingLevel,
                                    recordType: "firstRecord",
                                    grade: monthData["grade"],
                                    fluencyFrom:
                                      monthData["firstRecord"].wcpmList[
                                      "20-80"
                                      ][readingLevel]["fluencyFrom"],
                                    fluencyTo:
                                      monthData["firstRecord"].wcpmList[
                                      "20-80"
                                      ][readingLevel]["fluencyTo"]
                                  });
                                }}
                                className={
                                  monthData["firstRecord"].wcpmList["20-80"][
                                    readingLevel
                                  ]
                                    ? "default-bubble second-bubble "
                                    : ""
                                }
                                style={this.getBubBackColor({
                                  axisRange: "20-80",
                                  recordType: "firstRecord",
                                  bubbleValue: monthData["firstRecord"].wcpmList["20-80"][
                                    readingLevel
                                  ].value,
                                  readingLevel: readingLevel,
                                  grade: monthData["grade"],
                                  fluencyFrom: monthData["firstRecord"]
                                    .wcpmList["20-80"][readingLevel]
                                    ? monthData["firstRecord"].wcpmList[
                                    "20-80"
                                    ][readingLevel]["fluencyFrom"]
                                    : "",
                                  fluencyTo: monthData["firstRecord"].wcpmList[
                                    "20-80"
                                  ][readingLevel]
                                    ? monthData["firstRecord"].wcpmList[
                                    "20-80"
                                    ][readingLevel]["fluencyTo"]
                                    : ""
                                })}
                              >
                                {monthData["firstRecord"].wcpmList["20-80"][
                                  readingLevel
                                ]
                                  ? monthData["firstRecord"].wcpmList["20-80"][
                                    readingLevel
                                  ].value + "%"
                                  : ""}
                              </span>
                            </li>
                          );
                        } else {
                          return (
                            <li key={lvlIndex}>
                              <span />
                            </li>
                          );
                        }
                      })}
                    </ul>
                  </div>
                  <div className="wcpm-section wcpm-bg2 crb-hover-container">
                    <p>{"21-80%"}</p>
                    {this.showToolTip(
                      "majority percentile"
                    )}
                  </div>
                </div>
                <div className="sub-fourth-column pull-left pos-rel">
                  <div className="fourth-line">
                    <div class="top-small-strip"><div class="top-lhs-strip-bar"></div><div class="top-rhs-strip-bar"></div></div>
                  </div>
                  <div className="block-sec-4th">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        if (
                          monthData["firstRecord"].wcpmList["80-100"] &&
                          monthData["firstRecord"].wcpmList["80-100"][
                          readingLevel
                          ]
                        ) {
                          return (
                            <li key={lvlIndex}>
                              <span
                                onClick={() => {
                                  this.bubblesSelected({
                                    readingLevel: readingLevel,
                                    recordType: "firstRecord",
                                    grade: monthData["grade"],
                                    fluencyFrom:
                                      monthData["firstRecord"].wcpmList[
                                      "80-100"
                                      ][readingLevel]["fluencyFrom"],
                                    fluencyTo:
                                      monthData["firstRecord"].wcpmList[
                                      "80-100"
                                      ][readingLevel]["fluencyTo"]
                                  });
                                }}
                                className={
                                  monthData["firstRecord"].wcpmList["80-100"][
                                    readingLevel
                                  ]
                                    ? "default-bubble last-bubble"
                                    : ""
                                }
                                style={this.getBubBackColor({
                                  axisRange: "80-100",
                                  readingLevel: readingLevel,
                                  bubbleValue: monthData["firstRecord"].wcpmList["80-100"][
                                    readingLevel
                                  ].value,
                                  recordType: "firstRecord",
                                  grade: monthData["grade"],
                                  fluencyFrom: monthData["firstRecord"]
                                    .wcpmList["80-100"][readingLevel]
                                    ? monthData["firstRecord"].wcpmList[
                                    "80-100"
                                    ][readingLevel]["fluencyFrom"]
                                    : "",
                                  fluencyTo: monthData["firstRecord"].wcpmList[
                                    "80-100"
                                  ][readingLevel]
                                    ? monthData["firstRecord"].wcpmList[
                                    "80-100"
                                    ][readingLevel]["fluencyTo"]
                                    : ""
                                })}
                              >
                                {monthData["firstRecord"].wcpmList["80-100"][
                                  readingLevel
                                ]
                                  ? monthData["firstRecord"].wcpmList["80-100"][
                                    readingLevel
                                  ].value + "%"
                                  : ""}
                              </span>
                            </li>
                          );
                        } else {
                          return (
                            <li key={lvlIndex}>
                              <span />
                            </li>
                          );
                        }
                      })}
                    </ul>
                  </div>
                  <div className="wcpm-section wcpm-bg3 crb-hover-container">
                    <p>{">80%"}</p>
                    {this.showToolTip(
                      "top 20th percentile"
                    )}
                  </div>
                </div>
              </div>
            </div>
            {/* End of first record panel */}
            {/* Recent Record panel */}
            <div className="first-coloumn pull-left colm-fm">
              <div className="top-slide-section">
                <span>Recent Record</span>
              </div>
              <div className="up-sec">
                <div className="sub-first-column pull-left pos-rel">
                  <div className="block-sec">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        return (
                          <li key={lvlIndex}>
                            <span>
                              {monthData["recentRecord"].totalStudents[
                                readingLevel
                              ]
                                ? monthData["recentRecord"].totalStudents[
                                readingLevel
                                ] + "%"
                                : ""}
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                  <div className="total-stu">
                    <p>Total Students</p>
                    {this.showToolTip_ttl(
                      "Total Students Rostered"
                    )}
                  </div>
                  <div className="wcpm-section wcpm-bg">
                    <p>%</p>
                  </div>
                </div>
                <div className="sub-second-column pull-left pos-rel">
                  <div className="block-sec-2nd">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        if (
                          monthData["recentRecord"].wcpmList["0-20"] &&
                          monthData["recentRecord"].wcpmList["0-20"][
                          readingLevel
                          ]
                        ) {
                          return (
                            <li key={lvlIndex}>
                              <span
                                onClick={() => {
                                  this.bubblesSelected({
                                    readingLevel: readingLevel,
                                    recordType: "recentRecord",
                                    grade: monthData["grade"],
                                    fluencyFrom:
                                      monthData["recentRecord"].wcpmList[
                                      "0-20"
                                      ][readingLevel]["fluencyFrom"],
                                    fluencyTo:
                                      monthData["recentRecord"].wcpmList[
                                      "0-20"
                                      ][readingLevel]["fluencyTo"]
                                  });
                                }}
                                className={
                                  monthData["recentRecord"].wcpmList["0-20"][
                                    readingLevel
                                  ]
                                    ? "default-bubble first-bubble"
                                    : ""
                                }
                                style={this.getBubBackColor({
                                  axisRange: "0-20",
                                  readingLevel: readingLevel,
                                  recordType: "recentRecord",
                                  bubbleValue: monthData["recentRecord"].wcpmList["0-20"][
                                    readingLevel
                                  ].value,
                                  grade: monthData["grade"],
                                  fluencyFrom: monthData["recentRecord"]
                                    .wcpmList["0-20"][readingLevel]
                                    ? monthData["recentRecord"].wcpmList[
                                    "0-20"
                                    ][readingLevel]["fluencyFrom"]
                                    : "",
                                  fluencyTo: monthData["recentRecord"].wcpmList[
                                    "0-20"
                                  ][readingLevel]
                                    ? monthData["recentRecord"].wcpmList[
                                    "0-20"
                                    ][readingLevel]["fluencyTo"]
                                    : ""
                                })}
                              >
                                {monthData["recentRecord"].wcpmList["0-20"][
                                  readingLevel
                                ]
                                  ? monthData["recentRecord"].wcpmList["0-20"][
                                    readingLevel
                                  ].value + "%"
                                  : ""}
                              </span>
                            </li>
                          );
                        } else {
                          return (
                            <li key={lvlIndex}>
                              <span />
                            </li>
                          );
                        }
                      })}
                    </ul>
                  </div>

                  <div className="wcpm-section wcpm-bg1 crb-hover-container">
                    <p>{"≤20%"}</p>
                    {this.showToolTip(
                      "bottom 20th percentile"
                    )}
                  </div>
                </div>
                <div className="sub-third-column pull-left pos-rel">
                  <div className="block-sec-3rd">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        if (
                          monthData["recentRecord"].wcpmList["20-80"] &&
                          monthData["recentRecord"].wcpmList["20-80"][
                          readingLevel
                          ]
                        ) {
                          return (
                            <li key={lvlIndex}>
                              <span
                                onClick={() => {
                                  this.bubblesSelected({
                                    readingLevel: readingLevel,
                                    recordType: "recentRecord",
                                    grade: monthData["grade"],
                                    fluencyFrom:
                                      monthData["recentRecord"].wcpmList[
                                      "20-80"
                                      ][readingLevel]["fluencyFrom"],
                                    fluencyTo:
                                      monthData["recentRecord"].wcpmList[
                                      "20-80"
                                      ][readingLevel]["fluencyTo"]
                                  });
                                }}
                                className={
                                  monthData["recentRecord"].wcpmList["20-80"][
                                    readingLevel
                                  ]
                                    ? "default-bubble second-bubble"
                                    : ""
                                }
                                style={this.getBubBackColor({
                                  axisRange: "20-80",
                                  readingLevel: readingLevel,
                                  bubbleValue: monthData["recentRecord"].wcpmList["20-80"][
                                    readingLevel
                                  ].value,
                                  recordType: "recentRecord",
                                  grade: monthData["grade"],
                                  fluencyFrom: monthData["recentRecord"]
                                    .wcpmList["20-80"][readingLevel]
                                    ? monthData["recentRecord"].wcpmList[
                                    "20-80"
                                    ][readingLevel]["fluencyFrom"]
                                    : "",
                                  fluencyTo: monthData["recentRecord"].wcpmList[
                                    "20-80"
                                  ][readingLevel]
                                    ? monthData["recentRecord"].wcpmList[
                                    "20-80"
                                    ][readingLevel]["fluencyTo"]
                                    : ""
                                })}
                              >
                                {monthData["recentRecord"].wcpmList["20-80"][
                                  readingLevel
                                ]
                                  ? monthData["recentRecord"].wcpmList["20-80"][
                                    readingLevel
                                  ].value + "%"
                                  : ""}
                              </span>
                            </li>
                          );
                        } else {
                          return (
                            <li key={lvlIndex}>
                              <span />
                            </li>
                          );
                        }
                      })}
                    </ul>
                  </div>
                  <div className="wcpm-section wcpm-bg2 crb-hover-container">
                    <p>{"21-80%"}</p>
                    {this.showToolTip(
                      "majority percentile"
                    )}
                  </div>
                </div>
                <div className="sub-fourth-column pull-left pos-rel">
                  <div className="fourth-line">
                    <div class="top-small-strip"><div class="top-lhs-strip-bar"></div><div class="top-rhs-strip-bar"></div></div>
                  </div>
                  <div className="block-sec-4th">
                    <ul>
                      {selectedReadingLvls.map((readingLevel, lvlIndex) => {
                        if (
                          monthData["recentRecord"].wcpmList["80-100"] &&
                          monthData["recentRecord"].wcpmList["80-100"][
                          readingLevel
                          ]
                        ) {
                          return (
                            <li key={lvlIndex}>
                              <span
                                onClick={() => {
                                  this.bubblesSelected({
                                    readingLevel: readingLevel,
                                    recordType: "recentRecord",
                                    grade: monthData["grade"],
                                    readingLevel: readingLevel,
                                    fluencyFrom:
                                      monthData["recentRecord"].wcpmList[
                                      "80-100"
                                      ][readingLevel]["fluencyFrom"],
                                    fluencyTo:
                                      monthData["recentRecord"].wcpmList[
                                      "80-100"
                                      ][readingLevel]["fluencyTo"]
                                  });
                                }}
                                className={
                                  monthData["recentRecord"].wcpmList["80-100"][
                                    readingLevel
                                  ]
                                    ? "default-bubble last-bubble"
                                    : ""
                                }
                                style={this.getBubBackColor({
                                  axisRange: "80-100",
                                  readingLevel: readingLevel,
                                  recordType: "recentRecord",
                                  grade: monthData["grade"],
                                  bubbleValue: monthData["recentRecord"].wcpmList["80-100"][
                                    readingLevel
                                  ].value,
                                  fluencyFrom: monthData["recentRecord"]
                                    .wcpmList["80-100"][readingLevel]
                                    ? monthData["recentRecord"].wcpmList[
                                    "80-100"
                                    ][readingLevel]["fluencyFrom"]
                                    : "",
                                  fluencyTo: monthData["recentRecord"].wcpmList[
                                    "80-100"
                                  ][readingLevel]
                                    ? monthData["recentRecord"].wcpmList[
                                    "80-100"
                                    ][readingLevel]["fluencyTo"]
                                    : ""
                                })}
                              >
                                {monthData["recentRecord"].wcpmList["80-100"][
                                  readingLevel
                                ]
                                  ? monthData["recentRecord"].wcpmList[
                                    "80-100"
                                  ][readingLevel].value + "%"
                                  : ""}
                              </span>
                            </li>
                          );
                        } else {
                          return (
                            <li>
                              <span />
                            </li>
                          );
                        }
                      })}
                    </ul>
                  </div>
                  <div className="wcpm-section wcpm-bg3 crb-hover-container">
                    <p>{">80%"}</p>
                    {this.showToolTip(
                      "top 20th percentile"
                    )}
                  </div>
                </div>
              </div>
            </div>
            {/* End of Recent record panel */}
          </div>
          <div className="last-col-wrap">
            <div className="last-col-lft-bor">
              <div className="last-line-lhs-adj"></div>
              <div className="last-line-rhs-adj"></div>
              <div className="last-line-top-rhs-adj"></div>
            </div>
            <div className="last-col">
              <p>Fluency (wcpm) Progress Over Time</p>
            </div>
            <div className="btm-arrow-lft">
              <div className="btm-ic-rhs-last" onClick={this.props.scrollRight}>
                {scrollData["xScrollIndex"] <
                  scrollData["gradesForDropDown"].length - 1 ? (
                    <img src={rightScrollActive} className="cursor-pointer" />
                  ) : (
                    <img src={rightScroll} className="no-pointer" />
                  )}
              </div>
              <div
                className="btm-ic-rhs-prev"
                onClick={this.props.scrollExtremeRight}
              >
                {scrollData["xScrollIndex"] <
                  scrollData["gradesForDropDown"].length - 1 ? (
                    <img
                      src={rightExtremeScrollActive}
                      className="cursor-pointer"
                    />
                  ) : (
                    <img src={rightExtremeScroll} className="no-pointer" />
                  )}
              </div>
            </div>
          </div>

          <div className="clearfix" />
        </div>
      );
    } else {
      return <div>No Data Found</div>;
    }
  }
}

export default SchoolFABubblesComponent;
