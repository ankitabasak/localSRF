import React, { Component } from "react";
import { dataSorting } from "../../ReusableComponents/OrrReusableComponents";
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';

class SchoolFASidePanelComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showDiv: false,
      accordionList: {}
    };
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text) {
    if (text.length > 20) {
      return (
        <React.Fragment>
          {text.substr(0, 20)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }
  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? "rt-td-active"
      : "";
  }

  //to assign color
  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return " blueColor";
    } else {
      return "";
    }
  }

  //sort school grid on click
  schoolRlpSort(sortColumn, sortType, actualArray) {
    document.getElementById("schoolFA").scrollTo(0, 0);
    this.sortData(sortColumn, sortType, actualArray);
    this.props.updateSortColumn(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map((actualArray) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(
          actualArray.studentDetails,
          column,
          sortType
        );
      }
    });
    this.props.updateSortData(stdArray);
  }

  //to collapse school
  showCollapse(classList) {
    this.setState({
      ...this.state,
      accordionList: {
        ...this.state.accordionList,
        [classList]: !this.state.accordionList[classList]
      }
    });
  }

  // display side table
  displaySideTable(sortData, sideTableData) {
    let accordion = this.props.panelData["accordionList"]
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="schoolFA"
        >
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "lastName",
                sortData.sortType
              )}
            >
              Class/Student
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "lastName", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("lastName", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "lastName", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("lastName", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "grade",
                sortData.sortType
              )}
            >
              Grade
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "grade", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("grade", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "grade", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("grade", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "readingLevel",
                sortData.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "readingLevel", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("readingLevel", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "readingLevel", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("readingLevel", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "proficiency",
                sortData.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "proficiency", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("proficiency", "desc", sideTableData)
                }

              // this.assignClasses(sortData, 'proficiency', 'desc')}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "proficiency", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("proficiency", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "scfa-scroll-body")}>
          {sideTableData.map((schoolDetails, mainIndex) => (
            <div className="student-list-row-rhs-sec sc-rlp" key={mainIndex}>
              <div
                className={
                  accordion[mainIndex]
                    ? "expanded-group cursor-pointer"
                    : "collapsed-group cursor-pointer"
                }
                style={{ backgroundColor: "#F3F5FA" }}
                onClick={() => { this.props.setAccordionState(mainIndex) }}
              >
                <span>
                  {schoolDetails["className"]}&nbsp;&nbsp;(
                  {schoolDetails["studentDetails"].length}
                  &nbsp;Students)
                </span>
              </div>
              {schoolDetails["studentDetails"].map((studentList, value) => (
                <div
                  className={
                    "pos-rel student-list-row-rhs-sec " +
                    (accordion[mainIndex]
                      ? "show"
                      : "hide")
                  }
                  key={value}
                >
                  <div className="student-column-list-rhs-sec " onClick={() => { this.props.navigateToStudentReport(studentList) }}>
                    <span className="cursor-pointer wb-break-all long-text-tooltip">
                      {this.longTextTooltip(studentList.firstName + ' ' + studentList.lastName)}

                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec">
                    <span>
                      {studentList.grade ? studentList.grade : dashSymbol}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec">
                    <span>
                      {studentList.readingLevel
                        ? studentList.readingLevel
                        : dashSymbol}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec">
                    <span>
                      {studentList.proficiency
                        ? studentList.proficiency
                        : dashSymbol}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }
  render() {
    let sidePanelData;
    let sidePanelApiFailed;
    if (this.props.panelData) {
      sidePanelData = this.props.panelData["tableData"];
      sidePanelApiFailed = this.props.sidePanelApiFailed
    }
    let schoolRecords =
      sidePanelData && sidePanelData["selectedRecordTypeDetails"];
    // let sidePanelData = this.props.schoolData.schoolSidePanelData;

    let key =
      this.props.bubblesSelected && Object.keys(this.props.bubblesSelected)[0];
    let selLvls = key && this.props.bubblesSelected[key];

    if (selLvls && selLvls.length > 0 && !this.props.sidePanelApiFailed) {
      return (
        <div
          style={{ width: "431px", paddingLeft: "0px", paddingRight: "0px" }}
        >
          {sidePanelData && !sidePanelApiFailed &&
            <React.Fragment>
              <div className="reading-target-wrap">
                <div className="pull-left rt-left-heading">
                  <div className="mb-8">{schoolRecords["recordTitle"]}</div>
                  <div>
                    Grade: {selLvls[0] ? selLvls[0]["grade"] : ''}
                  </div>
                </div>
                <hr className="clearfix mb-8" />
                <div className="Readingtarget-graph">
                  <div className="chart-details mb-10">
                    <div className="reading-level-label mb-8 color-1">
                      First Record Date Range:
                 <span> {schoolRecords["firstRecordDateRange"]}</span>
                    </div>
                    <div className="reading-level-label color-1">
                      Recent Record Date Range:
                 <span> {schoolRecords["recentRecordDateRange"]}</span>
                    </div>
                  </div>
                </div>
                <div
                  className="pull-right clearfix"
                  style={{ marginBottom: "4px" }}
                >
                  <span style={{ fontSize: "12px", fontWeight: "500" }}>
                    No. of students rostered: {schoolRecords["noOfStudentsRoastered"]}
                  </span>
                </div>
                <div className="rhs-wrap sc_rhs_wrap">
                  <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                    <div className="student-list-table-main scrh-rhs-row">
                      <div className="student-list-table-rhs-sec">
                        {sidePanelData["sFAGridData"] && this.displaySideTable(
                          this.props.sortData,
                          this.props.panelData['sidePanelTableData']
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </React.Fragment>}
          {!sidePanelData && !sidePanelApiFailed &&
            <React.Fragment>
              <div className="display-msg err-msg-alignment cfp-err-msg-alignment top-30">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>

          }
          {!sidePanelData && sidePanelApiFailed && <React.Fragment>
            <div className="display-msg err-msg-alignment cfp-err-msg-alignment top-30">
              The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
            </div>
          </React.Fragment>}
        </div>
      );
    } else {
      return (
        <div
          className="container"
          style={{ width: "431px", paddingLeft: "0px", paddingRight: "0px" }}
        >
          <MakeSelectionForORR />
        </div>
      );
    }
  }
}

export default SchoolFASidePanelComponent;
