import React, { Component } from "react";
import YAxisComponent from "./Y_Axis_Component.jsx";
import SchoolFABubblesComponent from "./School_FA_Bubbles_Components.jsx";
class SchoolFAChartComponent extends Component {
  constructor(props) {
    super(props);

    this.scrollUp = this.scrollUp.bind(this); //sliceArray
    this.scrollDown = this.scrollDown.bind(this);
    this.scrollToBottom = this.scrollToBottom.bind(this);
    this.scrollToTop = this.scrollToTop.bind(this);
    // Horizontal scroll binding
    this.scrollLeft = this.scrollLeft.bind(this); //sliceArray
    this.scrollExtremeLeft = this.scrollExtremeLeft.bind(this);
    this.scrollRight = this.scrollRight.bind(this);
    this.scrollExtremeRight = this.scrollExtremeRight.bind(this);
    this.sliceArray = this.sliceArray.bind(this);
  }

  bubblesSelected(bubList) {
    this.props.updateSelectedBubble(bubList);
  }

  // return sliced array
  sliceArray(array, arrayIndex) {
    return array.slice(arrayIndex, arrayIndex + 5);
  }
  // Y axis scroll functionality
  scrollUp() {
    let chartData = this.props["data"];
    if (
      chartData["yScrollIndex"] <
      chartData["completeReadingLevels"].length - 5
    ) {
      let yScrlIdx = chartData["yScrollIndex"] + 1;
      let scrollReadingLevels = chartData["completeReadingLevels"].slice(
        yScrlIdx,
        yScrlIdx + 5
      );
      this.props.updateScrollData({
        yScrollIndex: yScrlIdx,
        visibleReadingLvls: scrollReadingLevels.reverse()
      });
    }
  }

  // Scrolling down

  scrollDown() {
    let chartData = this.props["data"];
    if (chartData["yScrollIndex"] > 0) {
      let yScrlIdx = chartData["yScrollIndex"] - 1;
      let scrollReadingLevels = chartData["completeReadingLevels"].slice(
        yScrlIdx,
        yScrlIdx + 5
      );
      this.props.updateScrollData({
        yScrollIndex: yScrlIdx,
        visibleReadingLvls: scrollReadingLevels.reverse()
      });
    }
  }

  scrollToBottom() {
    let chartData = this.props["data"];
    if (chartData["yScrollIndex"] > 0) {
      let yScrlIdx = 0;
      let scrollReadingLevels = chartData["completeReadingLevels"].slice(
        yScrlIdx,
        yScrlIdx + 5
      );
      this.props.updateScrollData({
        yScrollIndex: yScrlIdx,
        visibleReadingLvls: scrollReadingLevels.reverse()
      });
    }
  }
  scrollToTop() {
    let chartData = this.props["data"];
    if (
      chartData["yScrollIndex"] <
      chartData["completeReadingLevels"].length - 5
    ) {
      let yScrlIdx = chartData["completeReadingLevels"].length - 5;
      let scrollReadingLevels = chartData["completeReadingLevels"].slice(
        yScrlIdx,
        yScrlIdx + 5
      );
      this.props.updateScrollData({
        yScrollIndex: yScrlIdx,
        visibleReadingLvls: scrollReadingLevels.reverse()
      });
    }
  }
  // Horizontal scroll
  scrollLeft() {
    let chartData = this.props["data"];

    if (chartData["xScrollIndex"] > 0) {
      this.props.updateGradeSelected(chartData["xScrollIndex"] - 1);
    }
  }
  scrollExtremeLeft() {
    let chartData = this.props["data"];
    if (chartData["xScrollIndex"] > 0) {
      this.props.updateGradeSelected(0);
    }
  }

  scrollRight() {
    let chartData = this.props["data"];

    if (chartData["xScrollIndex"] < chartData["gradesForDropDown"].length - 1) {
      this.props.updateGradeSelected(chartData["xScrollIndex"] + 1);
    }
  }
  scrollExtremeRight() {
    let chartData = this.props["data"];
    if (chartData["xScrollIndex"] < chartData["gradesForDropDown"].length - 1) {
      this.props.updateGradeSelected(chartData["gradesForDropDown"].length - 1);
    }
  }


  render() {
    return (
      <React.Fragment>
        <div className="col-lg-7 res-width-8 cfa-lft-box scFareWidth-26-20">
          <p className="reading-level-text pull-left print-schoolfwcpm-rl">Reading Level</p>

          <div className="wrap pos-rel">
            <div className="rhs-line" />
            <div className="rhs-line1" />
            <div className="rhs-line2" />
            <div className="rhs-line3" />
            <YAxisComponent
              axisData={{
                yScrollIndex: this.props.data["yScrollIndex"],
                xScrollIndex: this.props.data["xScrollIndex"],
                completeReadingLevels: this.props.data["completeReadingLevels"],
                YaxisDataRange: this.props.readingLevels
              }}
              scrollUp={this.scrollUp}
              scrollDown={this.scrollDown}
              scrollToBottom={this.scrollToBottom}
              scrollToTop={this.scrollToTop}
              scrollLeft={this.scrollLeft}
              scrollExtremeLeft={this.scrollExtremeLeft}
            />

            <SchoolFABubblesComponent
              scFaChart={this.props.scFaChart}
              upgradeSelectedGrade={(grade) => { this.props.updateGradeSelected(grade) }}
              monthData={this.props.data}
              selectedReadingLevels={this.props.readingLevels}
              bubblesSelected={selectedBubble => {
                this.bubblesSelected(selectedBubble);
              }}
              updateGradeSelected={grade => {
                this.props.updateGradeSelected(grade);
              }}
              bubsFromReducer={this.props.selectedBubsFromReducer}
              scrollRight={this.scrollRight}
              scrollExtremeRight={this.scrollExtremeRight}
            />
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default SchoolFAChartComponent;
