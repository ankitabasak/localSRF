import React, { PureComponent } from 'react';
import '../../../../public/css/style.css';

import activeFpotIcon from '../../../../public/assets/orr/rlp-screen/Line-chart-tab_unselected.svg';
import InActiveFpotIcon from '../../../../public/assets/orr/rlp-screen/Line-chart-tab_selected.svg';
import activeCFA from '../../../../public/assets/orr/rlp-screen/ic_bubble-chart_unselected.svg';
import InActiveCFA from '../../../../public/assets/orr/rlp-screen/ic_bubble-chart_selected.svg';

class Switch_FA_Tab extends PureComponent {
  updateTab(tabName) {
    // this.props.ScFA_TAB_SELECTION(tabName);
    if (tabName == 'fpot') {
      // if (!this.props.FluencyState.progressOverTime.firstRecordObj) {
      this.props.tabSelected('fpot');
      // }
    } else if (tabName == 'wcpm') {
      // if (!this.props.FluencyState.CF_Chart_Response) {
      this.props.tabSelected('wcpm');
      // }
    }
  }

  render() {
    let scfTab = this.props.tabName;

    return (
      <div>
        <div className="container  switching-tabs fa-switch-tab cfa-switcing">
          <div className="row m-0 p-0">
            <div className="col-sm-12 tab-mid text-center tab-btm-bor pos-rel">
              <ul className="p-0 max-1020 tab-mb-0">
                <ul className="p-0 mx-auto max-1020 ipadTab-align">
                  <li
                    onClick={() =>
                      scfTab.fpot ? null : this.updateTab('fpot')
                    }
                    className={scfTab.fpot ? 'active_tab' : 'inactive_tab'}
                  >
                    <img
                      className="mr-10"
                      src={scfTab.fpot ? activeFpotIcon : InActiveFpotIcon}
                    />
                    Fluency Progress Over Time
                  </li>
                  <li
                    className={scfTab.wcpm ? 'active_tab' : 'inactive_tab'}
                    onClick={() =>
                      scfTab.wcpm ? null : this.updateTab('wcpm')
                    }
                  >
                    <img
                      className="mr-10"
                      src={scfTab.wcpm ? activeCFA : InActiveCFA}
                    />
                    Words Correct per Minute Progress
                  </li>
                </ul>
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Switch_FA_Tab;
