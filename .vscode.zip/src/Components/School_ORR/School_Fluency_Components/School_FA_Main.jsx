import React, { Component } from 'react';
import { connect } from 'react-redux';
import Filter from '../../ORR/FilterComponents/Filter';
import Switch_FA_Tab from './School_FA_Tab.jsx';
import { formatDate } from "../../../Utils/globalVars";
import {
  ScFA_TAB_SELECTION,
  Sc_GRADES
} from '../../../Redux_Actions/School_FA_Action.jsx';
import SchoolFpotChart from './SchoolFpotComponents/ScFpot-Chart.jsx';
import SchoolFluencyAnalysisComponent from '../School_FA_Components/School_FA_Components.jsx'

class SchoolFluencyChart extends Component {
  constructor(props) {
    super(props);

    this.setTab = this.setTab.bind(this);
  }

  componentDidMount() {
    if (this.props.FluencyTabSelection['wcpm']) {
      this.props.ScFA_TAB_SELECTION('wcpm');
    } else if (this.props.FluencyTabSelection['fpot']) {
      this.props.ScFA_TAB_SELECTION('fpot');
    }
  }

  setTab(tabName) {
    this.props.ScFA_TAB_SELECTION(tabName);
    // this.props.API_LOADER({
    //   isApiLoading: true,
    //   apiLoadFail: false,
    //   apiTimeOut: false
    // });
    // this.getCFData(tabName);
  }

  render() {
    return (
      <React.Fragment>
        <Filter
          tabName={this.props.ScFTabSelection}
          recType={this.props.School_fpot.showRecord}
          grade={this.props.School_fpot.gradeSelected}
        ></Filter>
        <Switch_FA_Tab
          tabName={this.props.ScFTabSelection}
          tabSelected={tabSel => {
            this.setTab(tabSel);
          }}
        ></Switch_FA_Tab>
        {this.props.ScFTabSelection.fpot ? (
          <SchoolFpotChart></SchoolFpotChart>
        ) : (
            ''
          )}
        {this.props.ScFTabSelection.wcpm ? (
          <SchoolFluencyAnalysisComponent></SchoolFluencyAnalysisComponent>
        ) : (
            ''
          )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ classFluency, School_FA_Reducer, Authentication, Universal, CommonFilterDetails }) => {
  const { ScFTabSelection, gradeList, School_fpot } = School_FA_Reducer;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { LoginDetails } = Authentication;
  const { CommonFilterData } = CommonFilterDetails;
  const { FluencyTabSelection } = classFluency;
  return {
    FluencyTabSelection,
    ScFTabSelection,
    ContextHeader,
    NavigationByHeaderSelection,
    gradeList,
    School_fpot,
    LoginDetails,
    CommonFilterData
  };
};

export default connect(
  mapStateToProps,
  { ScFA_TAB_SELECTION, Sc_GRADES }
)(SchoolFluencyChart);
