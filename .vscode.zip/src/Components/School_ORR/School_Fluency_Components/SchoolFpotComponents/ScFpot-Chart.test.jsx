import React from 'react';
import { shallow } from 'enzyme';
import MakeSelectionForORR from '../../../../Utils/MakeSelectionForORR';
import SchoolFpotChart from './ScFpot-Chart';

jest.mock('react-redux', () => ({
  connect: jest.fn().mockImplementation(() => (component) => component),
}));
function setup(overrides = {}) {
  const props = {
    LOAD_ICON: jest.fn(),
    Sc_GRADES: jest.fn(),
    LoginDetails: { JWTToken: 'test token'},
    ContextHeader: {LoggedInUserName: 'test', Roster_Tab: {SelectedSchool: {name: 'test', id: 123}},
         Date_Tab: {Report_termEndDate: '2015-07-01 00:00:00', selectedterm_Obj: {termStartDate: '2015-07-01 00:00:00'}},},
    NavigationByHeaderSelection: {school: 'test'},
    School_fpot: {showRecord: ''}
  };
  const finalProps = Object.assign(props, overrides);
  const wrapper = shallow((
      <SchoolFpotChart {...finalProps} />
  ));
  return { wrapper };
};


describe('SchoolFpotChart', () => {
  describe('renders properly', () => {
    const { wrapper } = setup();
    it('renders component', () => {
      expect(wrapper).toHaveLength(1);
    });

    it('matches snapshot', () => {
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe('renders properly', () => {
    it('MakeSelectionForORR component not render default', () => {
      const { wrapper } = setup({
        selectedLevels : {
          "recentRecordCount": [{
            "fluencyFrom": 0,
            "fluencyTo": 660,
            "grade": "K",
            "readingLevel": "A",
            "recordType": "recentRecord"
          }]
        }
      });
      expect(wrapper.find('MakeSelectionForORR')).toHaveLength(0);
    });

    it('NoRosterData component will render', () => {
      const { wrapper } = setup({
        bubblesSelected: [],
        ContextHeader: {LoggedInUserName: 'test', Roster_Tab: {SelectedSchool: {name: 'test', id: 123}},
         Date_Tab: {Report_termEndDate: '2015-07-01 00:00:00', selectedterm_Obj: {termStartDate: '2015-07-01 00:00:00'}},},
        NavigationByHeaderSelection: {school: ''},
      });
      expect(wrapper.find('NoRosterData')).toHaveLength(1);
    });
  });
});
