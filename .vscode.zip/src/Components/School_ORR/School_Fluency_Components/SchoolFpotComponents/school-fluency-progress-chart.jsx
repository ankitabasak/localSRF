import React, { PureComponent } from "react";
import "../../../Class_ORR/Class_Error_Analysis/class-error-analysis.css";
import { getCommonHeaders } from '../../../ReusableComponents/OrrReusableComponents';
import {
  UpdateRecordType,
  selectedScGrade,
  LOAD_ICON,
  SelectedErrors,
  School_Fpot_Grid_Api_Call
} from "../../../../Redux_Actions/School_FA_Action.jsx";
import { connect } from "react-redux";
import arrowDown from "../../../../../public/assets/orr/rlp-screen/select-down-arrow.svg";

class SchoolFluencyProgressChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      sidepanelApiInRun: false,
      ErrorList: ["phrasing", "intonation", "pace", "accuracy"],
      xAxis: ["Phrasing", "Intonation", "Pace", "Accuracy"],

      colorBar: [
        "4px solid rgb(255, 142, 45)",
        "4px solid rgb(255, 197, 45)",
        "4px solid rgb(50, 172, 65)",
        "4px solid rgb(7, 156, 207)"
      ],

      isHovered: false,
      outerIndex: "",
      error: "",
      recordType: ""
    };

    this.showRecord = this.showRecord.bind(this);
    this.onMouseOver = this.onMouseOver.bind(this);
    this.onMouseOut = this.onMouseOut.bind(this);
    this.showScErrRecords = this.showScErrRecords.bind(this);
    this.dropDownGrade = this.dropDownGrade.bind(this);
    this.multipleErrSelection = this.multipleErrSelection.bind(this);
  }

  //to display the last passage
  showToolTip(passage) {
    let key = ["Phrasing", "Pace", "Intonation", "Accuracy"];
    let obj = [];
    let pasVal = Object.keys(passage);
    pasVal.map((val, inx) => {
      if (val !== "score") {
        obj.push(passage[val]);
      }
    });

    return (
      <div className="hover-rlp school-tooltip-wrap">
        <ul>
          {key.map((keyName, i) => {
            return (
              <React.Fragment>
                <li>
                  <span className="scfr-tooltip"> {keyName}</span> -
                  <span>{obj[i]}</span>
                </li>
              </React.Fragment>
            );
          })}
        </ul>
        <div className="tooltip-dot" />
      </div>
    );
  }
  onMouseOver(i, errType, recordType) {
    this.setState({
      isHovered: true,
      outerIndex: i,
      error: errType,
      recordType: recordType
    });
  }

  onMouseOut() {
    this.setState({
      isHovered: false,
      outerIndex: "",
      error: "",
      recordType: ""
    });
  }

  //onclick select error
  selectedErrors(errorSel, selError) {
    var errList = selError[errorSel.recordType] || [];
    if (errList) {
      let duplicateIndex = this.isDuplicateBox(errorSel, errList);
      if (duplicateIndex != -1) {
        errList.splice(duplicateIndex, 1);
      } else {
        errList.push(errorSel);
      }
      this.props.SelectedErrors({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });
      this.schoolFpotGridApi({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });
    } else {
      errList = { [errorSel.recordType]: [errorSel] };
      this.props.SelectedErrors({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });

      this.schoolFpotGridApi({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });
    }
  }

  //api call on multiple cell selection
  multipleErrSelection(delay, token, payLoad) {
    let timerId;
    if (this.state.timerVal) {
      clearTimeout(this.state.timerVal);
    }
    if (payLoad.selectedCriteriaRanges.criteriaRangesLists.length > 0) {
      timerId = setTimeout(() => {
        this.props.School_Fpot_Grid_Api_Call(token, payLoad);
        timerId = null;
      }, delay);
    }
    this.setState({ ...this.state, timerVal: timerId });
  }

  // // check for duplicate value
  isDuplicateBox(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          bubble.errorName == obj.errorName &&
          bubble.recordType == obj.recordType &&
          bubble.rubrixScore == obj.rubrixScore
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }

  schoolFpotGridApi(selErrList) {
    let key = Object.keys(selErrList["selectedErrors"]);
    let dataForApi = [];
    if (key && key.length > 0) {
      selErrList["selectedErrors"][key[0]].forEach(item => {
        dataForApi.push({
          criteriaId: item.criteriaId,
          score: item.rubrixScore
        });
      });
    }
    let commonHeaders = getCommonHeaders(this.props, 'school');

    let gridPayload = {
      ...{
        internalFilter: commonHeaders.internalFilter,
        externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScFR", grade: this.props.selGrade })
      },
      selectedCriteriaRanges: {
        allRecordsAverage: selErrList['selectedErrors']['allRecordsAverage']
          ? true
          : false,
        firstRecord: selErrList['selectedErrors']['firstRecord'] ? true : false,
        recentRecord: selErrList['selectedErrors']['recentRecord']
          ? true
          : false,
        criteriaRangesLists: dataForApi
      }
    }

    this.multipleErrSelection(1000, this.props.token, gridPayload);

  }

  //adding background color
  getOnClickColor(selectedErrors, currentLevelInfo) {
    let applyColor = "";
    if (selectedErrors) {
      if (currentLevelInfo.val === 0) {
        applyColor = "default-color-hover";
      } else {
        applyColor = "default-color";
      }

      if (selectedErrors[currentLevelInfo.recordType]) {
        selectedErrors[currentLevelInfo.recordType].forEach(obj => {
          if (
            obj.errorName == currentLevelInfo.errorName &&
            obj.recordType == currentLevelInfo.recordType &&
            obj.rubrixScore == currentLevelInfo.rubrixScore
          ) {
            applyColor = "select-color";
            return;
          }
        });
      }
    }
    return applyColor;
  }

  //apply hover color
  bgColorHover(i) {
    if (
      this.state.recordType === "firstRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "errR"
    ) {
      return "firstRec";
    }
    if (
      this.state.recordType === "firstRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "msvErr"
    ) {
      return "firstRecMsv";
    }
    if (
      this.state.recordType === "recentRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "errR"
    ) {
      return "firstRecErr";
    }
    if (
      this.state.recordType === "recentRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "msvErr"
    ) {
      return "firstRecErrMsv";
    }
    if (
      this.state.recordType === "allRecordsAverage" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "errR"
    ) {
      return "allRecErr";
    }
    if (
      this.state.recordType === "allRecordsAverage" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "msvErr"
    ) {
      return "allRecErrMsv";
    }
  }

  displayRecords(record, errorList, errorRange, recordType, errType) {
    return (
      <div>
        {errorRange.map((valueRange, i) => {
          return (
            <div
              className="first-error-col"
              id={
                errType === "msvErr" && recordType === "firstRecord"
                  ? "msvAvg" + i
                  : recordType === "firstRecord" && errType == "errR"
                    ? "errAvg" + i
                    : recordType === "recentRecord" && errType == "errR"
                      ? "errAvg1" + i
                      : recordType === "recentRecord" && errType == "msvErr"
                        ? "msvAvg1" + i
                        : recordType === "allRecordsAverage" && errType == "errR"
                          ? "allErrAvg" + i
                          : recordType === "allRecordsAverage" && errType == "msvErr"
                            ? "allMsvAvg" + i
                            : ""
              }
            >
              <div className="bor-1 bor-length" />

              <ul className={this.bgColorHover(i)}>
                {errorList.map((value, index) => {
                  let rubrixScore = errorRange[i]["score"];
                  return (
                    <li
                      key={index}
                      className={
                        (record[recordType][value][rubrixScore] && record[recordType][value][rubrixScore].value === 0
                          ? ""
                          : "cursor-pointer hover-cea ") +
                        this.getOnClickColor(this.props.SelectedErr, {
                          val: record[recordType][value][rubrixScore] && record[recordType][value][rubrixScore].value,
                          rubrixScore: rubrixScore,
                          errorName: value,
                          recordType: recordType
                        })
                      }
                      onClick={() => {
                        record[recordType][value][rubrixScore] && record[recordType][value][rubrixScore].value === 0
                          ? ''
                          : this.selectedErrors(
                            {
                              recordType: recordType,
                              rubrixScore: rubrixScore,
                              errorName: value,
                              criteriaId:
                                record[recordType][value][rubrixScore] && record[recordType][value][rubrixScore][
                                'criteriaId'
                                ]
                            },
                            this.props.SelectedErr
                          );
                      }}
                    >
                      {record[recordType][value][rubrixScore] ? record[recordType][value][rubrixScore].value : 0}
                    </li>
                  );
                })}
                <li
                  key={i}
                  className="btm-line cfpot-tooltip"
                  style={{
                    borderBottom:
                      errType === "msvErr"
                        ? this.state.msvBar[i]
                        : this.state.colorBar[i]
                  }}
                  onMouseOver={() =>
                    !errType
                      ? this.onMouseOver(i, "errR", recordType)
                      : this.onMouseOver(i, errType, recordType)
                  }
                  onMouseOut={() =>
                    !errType ? this.onMouseOut(i) : this.onMouseOut(i, errType)
                  }
                >
                  <span> {valueRange["score"]}</span>
                  <span> {this.showToolTip(valueRange)}</span>
                </li>
              </ul>
            </div>
          );
        })}
      </div>
    );
  }

  //show selected record
  showRecord(e) {
    this.props.LOAD_ICON();
    this.props.UpdateRecordType(e.currentTarget.value);
    this.props.apiCall(e.currentTarget.value);
  }

  showScErrRecords(recType) {
    this.props.LOAD_ICON();
    this.props.UpdateRecordType(recType);
    this.props.apiCall(recType);
  }

  dropDownGrade(e) {
    this.props.selectedScGrade(e.target.value);
    this.props.gradeCall(e.target.value);
  }

  render() {
    return (
      <React.Fragment>
        <div className="col-lg-7 res-width-8 class_ea school_fr_wrap sc-fr">
          {/* Radio button start */}
          <div className="show-radio-btn radio_btn_wrap scFaFpot-print-radio-28-20">
            <div className="scfr-grade scfr-def-cursor">Grade: </div>
            <div className="scfr-grade-select">
              {this.props.gradeList && this.props.gradeList.length > 0 &&
                <div className="bec-select">
                  <div className="select-side">
                    <img src={arrowDown} alt="select" />
                  </div>
                  <select
                    className="form-control cursor-pointer"
                    id="selGrd"
                    onChange={this.dropDownGrade}
                    value={this.props.selGrade}
                  >
                    {this.props.scFaPot &&
                      <option>{this.props.selGrade}</option>}
                    {this.props.gradeList.map(value => (
                      <option value={value}>{value}</option>
                    ))}
                  </select>

                </div>
              }
            </div>
            {
              //!this.props.showHideRecentRecord &&
              (
              <React.Fragment>
                <div className="check-box-heading pull-left scfr-def-cursor">
                  Compare No. of Students with:
                </div>
                <div className="round pull-left class_ea_radio">
                  <input
                    type="radio"
                    value="all"
                    checked={this.props.showRecord === "all"}
                    onChange={this.showRecord}
                    disabled={this.props.showHideRecentRecord}
                  />
                  <span className={this.props.showRecord === 'all' ? " checkmark-sel" : "checkmark"} />
                  <span
                    className="cursor-pointer"
                    onClick={() => this.showScErrRecords("all")}
                  // className={this.props.showRecord === 'all' ? 'blueColor' : ''}
                  >
                    All Records' Average
                  </span>
                </div>

                <div className="round pull-left class_ea_radio">
                  <input
                    type="radio"
                    value="rec"
                    checked={this.props.showRecord === "rec"}
                    onChange={this.showRecord}
                    disabled={this.props.showHideRecentRecord}
                  />
                  <span className={this.props.showRecord === 'rec' ? " checkmark-sel" : "checkmark"} />
                  <span
                    className="cursor-pointer"
                    onClick={() => this.showScErrRecords("rec")}
                  // className={this.props.showRecord === 'rec' ? 'blueColor' : ''}
                  >
                    Recent Record
                  </span>
                </div>
              </React.Fragment>
            )}
          </div>

          {/* Radio button end */}
          {/* Left Chart Table Start */}
          <div
            className="sea-wrapper pos-rel school_fa-fpot-wrap"
            style={{ width: "auto" }}
          >
            <div className="error-analysis-section-cea">
              <p>
                Fluency Progress<br></br>(By No. of Students)
              </p>
            </div>

            <div className="sea-scroller-scea">
              <div
                className="bor-bottom sc-fpc-print-top"
                style={{ position: "relative", top: "-10px", left: "-19px" }}
              >
                <hr className="cea-hr-top" />
              </div>
              <div className="scfr-bottom">
                <hr className="cea-hr-top sc-fp-hr" />
              </div>
              <div className="row">
                <div
                  className="error-col-cea pos-rel"
                  style={{ float: "left" }}
                >
                  <p
                    className="col-name print-school-col-name"
                    style={{
                      position: "absolute",
                      top: "-21px",
                      left: "0px",
                      fontSize: "14px",
                      fontWeight: "500",
                      whiteSpace: "nowrap",
                      width: "100%",
                      textAlign: "center"
                    }}
                  >
                    Fluency
                  </p>
                  <ul className="scfr-strip">
                    {this.state.xAxis.map((value, i) => {
                      return (
                        <li
                          className="top-bor pos-rel"
                          className={i == 0 ? "top-bor" : ""}
                          key={i}
                        >
                          <span>{value}</span>
                          <div className={"row-strip-1 strip-bg-" + i + 1} />
                        </li>
                      );
                    })}

                    <li
                      className="pos-rel end-row"
                      style={{ borderBottom: "none", paddingLeft: "0px" }}
                    >
                      <div className="cea-no-of-error"></div>
                      <span className="arrow_box-cea size-box">
                        Rubric Score
                      </span>
                    </li>
                  </ul>
                </div>
                {Object.keys(this.props.firstRecord.firstRecord.phrasing).length > 0 &&
                  <div
                    className="first-record-error pos-rel"
                    style={{ float: "left", width: "auto", marginLeft: "5px" }}
                  >
                    <div className="box-top-bor" />
                    <div className="td-devider1" />
                    <div className="td-devider2" />
                    <div className="td-devider3" />
                    <p
                      className="col-name print-school-col-name"
                      style={{
                        position: "absolute",
                        top: "-21px",
                        left: "0px",
                        fontSize: "14px",
                        fontWeight: "500",
                        whiteSpace: "nowrap",
                        width: "100%",
                        textAlign: "center"
                      }}
                    >
                      First Record
                  </p>

                    <div
                      className="sea-table"
                      style={{
                        borderLeft: "none",
                        borderRight: "none"
                      }}
                    >
                      {this.props.firstRecord && Object.keys(this.props.firstRecord.firstRecord.phrasing).length > 0 &&
                        this.displayRecords(
                          this.props.firstRecord,
                          this.state.ErrorList,
                          this.props.errorRange,
                          "firstRecord",
                          "errR"
                        )}
                    </div>
                  </div>
                }
                <div
                  className="first-record-error pos-rel"
                  style={{ float: "left", width: "auto", marginLeft: "5px" }}
                >
                  <p
                    className="col-name print-school-col-name"
                    style={{
                      position: "absolute",
                      top: "-21px",
                      left: "0px",
                      fontSize: "14px",
                      fontWeight: "500",
                      whiteSpace: "nowrap",
                      width: "100%",
                      textAlign: "center"
                    }}
                  >
                    {/* {!this.props.showHideRecentRecord
                      ? this.props.allRecord
                        ? `All Records' Average`
                        : this.props.recentRecord
                          ? "Recent Record"
                          : ""
                      : ""} */}
                    {
                      this.props.allRecord
                        ? `All Records' Average`
                        : this.props.recentRecord
                        ? "Recent Record"
                        : "Recent Record"
                    }

                  </p>
                  <div className="box-top-bor" />
                  <div className="td-devider1" />
                  <div className="td-devider2" />
                  <div className="td-devider3" />

                  <div className="bor-1 bor-length" />

                  {this.props.recentRecord &&
                  this.props.showHideRecentRecord &&
                  <div className="width256 model_center_no_data_line">
                    No Fluency analysis tracked in most recent record.
                  </div>
                  }

                  {/* --all record code start */}
                  {this.props.allRecord &&
                    !this.props.showHideRecentRecord &&
                    this.displayRecords(
                      this.props.allRecord,
                      this.state.ErrorList,
                      this.props.errorRange,
                      "allRecordsAverage",
                      "errR"
                    )}
                  {/* --all record code end */}
                  {/* { recentRecord start} */}
                  {this.props.recentRecord &&
                    !this.props.showHideRecentRecord &&
                    this.displayRecords(
                      this.props.recentRecord,
                      this.state.ErrorList,
                      this.props.errorRange,
                      "recentRecord",
                      "errR"
                    )}
                  {/* recent record end */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({ Universal }) => {
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  return {
    ContextHeader,
    NavigationByHeaderSelection,
  };
};

export default connect(mapStateToProps, {
  UpdateRecordType,
  selectedScGrade,
  LOAD_ICON,
  SelectedErrors,
  School_Fpot_Grid_Api_Call
})(SchoolFluencyProgressChart);
