import "../SchoolFpotComponents/school-fpot.css";

import {
  LOAD_ICON,
  SCHOOL_FPOT_API_SUCCESS,
  SFR_CSVDATA_DOWNLOAD_APICALL,
  SFR_CSVDATA_DOWNLOAD_RESET,
  Sc_GRADES,
  selectedScGrade
} from "../../../../Redux_Actions/School_FA_Action.jsx";
import React, { PureComponent } from "react";
import { getCommonHeaders, getDateFormat } from '../../../ReusableComponents/OrrReusableComponents';

import { CSVLink } from "react-csv";
import ChartNotLoad from "../../../../Utils/Chart_Not_Load";
import CsvIcon from '../../../../../public/images/ic_save.svg';
import MakeSelectionForORR from '../../../../Utils/MakeSelectionForORR';
import NoFluencyData from '../../../../Utils/No_Data.js';
import NoRecordsData from "../../../../Utils/No_Data_Found";
import NoRosterData from "../../../../Utils/NoRoster.js";
import PrintScFpot from '../../../ReusableComponents/PrintOrrCharts/Sc_FpotPrint.jsx'
import SchoolFluencyProgressChart from "./school-fluency-progress-chart.jsx";
import SchoolFpotGrid from './school-fluency-progress.jsx';
import Spinner from "../../../ReusableComponents/Spinner/Spinner.jsx";
import TimeOut from "../../../ReusableComponents/Spinner/TimeOut.jsx";
import { connect } from "react-redux";
import {
  navigateToStudentReport
} from "../../../../Redux_Actions/UniversalSelectorActions";
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from '../../../../Utils/globalVars';
import { AGPDistrictCSV } from '../../../../Redux_Actions/District_Report_Actions';
import { csvDownload } from '../../../../Utils/CSVDownload/AGPReports';
import Confirmation_AgpPopup from '../../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';

class SchoolFpotChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      dataRecordType: {},
      timeOut: false,
      defaultFilterRecType: {
        allRecords: false,
        recentRecord: true
      }
    };
    this.timeOut = this.timeOut.bind(this);
    this.recTypeActionCall = this.recTypeActionCall.bind(this);
    this.gradeActionCall = this.gradeActionCall.bind(this);
  }

  componentDidMount() {
    let commonHeaders = getCommonHeaders(this.props, 'school');
    let payLoad =
    {
      internalFilter: commonHeaders.internalFilter,
      externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScFR" })
    };
    this.props.LOAD_ICON({
      isApiLoading: true,
      apiTimeOut: false,
      hideChart: true
    }
    );
    this.props.Sc_GRADES(this.props.LoginDetails.JWTToken, payLoad,
      this.props.ContextHeader.Roster_Tab.selectedRosterGrade,
      this.props.School_fpot.showRecord);
  }

  // handle timeout
  timeOut() {
    this.props.LOAD_ICON({
      isApiLoading: false,
      apiTimeOut: true,
      hideChart: true
    }
    );
  }

  //make api call
  schoolFpotApi(type, grade) {
    this.props.LOAD_ICON({
      isApiLoading: true,
      apiTimeOut: false,
      hideChart: true
    }
    );
    let Token = this.props.LoginDetails.JWTToken;
    let dataRecordType = {
      allRecords: type === "all" ? true : false,
      recentRecord: type === "rec" ? true : false
    };
    this.setState({
      dataRecordType: dataRecordType
    });
    let commonHeaders = getCommonHeaders(this.props, 'school');
    let Req_Payload = {
      dataRecordType,
      ...{
        internalFilter: commonHeaders.internalFilter,
        externalFilter: Object.assign(commonHeaders.externalFilter, { chartName: "ScFR", grade: grade })
      }
    };
    this.props.SCHOOL_FPOT_API_SUCCESS(Token, Req_Payload);
  }

  // api call when rec type switched
  recTypeActionCall(recType) {
    let grade = this.props.School_fpot.gradeSelected;
    this.schoolFpotApi(recType, grade);
  }

  //api call when grade switch
  gradeActionCall(grade) {
    let recType = this.props.School_fpot.showRecord;
    this.schoolFpotApi(recType, grade);
  }
  // Download csv data
  downLoadCSVData() {
    let Req_Payload = {
      schoolChartType: {
        "allGrades": true,
        "allRecordsAvgFlag": 0,
        "chartName": "ScFR",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'school')
    };
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, Req_Payload);
    } else {
      this.props.SFR_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.SFR_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
    }
  }

  render() {
    if (this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['downloadInProgress'] && this.props.SchoolCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SFR_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    let loggedInUserName = '';
    let selectedSchool = '';
    if (this.props.ContextHeader) {
      loggedInUserName = this.props.ContextHeader.LoggedInUserName;
      selectedSchool = this.props.ContextHeader.Roster_Tab.SelectedSchool.name;
    }
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + loggedInUserName + " for " + selectedSchool;
    let selectedErr = [];
    if (this.props.School_fpot && this.props.School_fpot["SelectedErr"]) {
      selectedErr = (
        this.props.School_fpot["SelectedErr"]['firstRecord'] ||
        this.props.School_fpot["SelectedErr"]['recentRecord'] ||
        this.props.School_fpot['SelectedErr']["allRecordsAverage"]
      ) || [];
    }
    return (
      <React.Fragment>
        <main>
          <section>
            {this.props.NavigationByHeaderSelection && this.props.NavigationByHeaderSelection.school &&
              this.props.ContextHeader.Roster_Tab.SelectedSchool.id ? (
                <React.Fragment>
                  {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                    <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
                  <div className="container container-resolution cfa">
                    <div className="row" id="testSchoolChart">
                      {this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['csvData'] &&
                        <CSVLink
                          ref="groupCSV"
                          headers={this.props.SchoolCsvDownload['csvData'] && this.props.SchoolCsvDownload['csvData']['header']}
                          data={this.props.SchoolCsvDownload['csvData'] && this.props.SchoolCsvDownload['csvData']['data']}
                          style={{ display: 'none' }}
                          filename={`${csvFileName}.csv`}
                        />}
                      <div className="dst-csv-icon-alignment" onClick={() => !this.props.SchoolCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                        {this.props.SchoolCsvDownload && this.props.SchoolCsvDownload['downloadInProgress'] ?
                          <span className="csv_download_icon">
                            <i className="material-icons">autorenew</i>
                          </span> :
                          <span className="csv_download_icon">
                            <img src={CsvIcon} width="20" height="20" />
                          </span>}
                      </div>
                      {this.props.School_fpot.firstRecordObj &&
                        !this.props.School_fpot.noData &&
                        !this.props.School_fpot.hideChart && !this.props.School_fpot['isApiLoading'] && (
                          <React.Fragment>
                            <SchoolFluencyProgressChart
                              scFaPot={false}
                              schoolId={this.props.ContextHeader.Roster_Tab.SelectedSchool.id}
                              firstRecord={this.props.School_fpot.firstRecordObj}
                              allRecord={this.props.School_fpot.allRecordObj}
                              recentRecord={this.props.School_fpot.recentRecordObj}
                              apiCall={type => this.recTypeActionCall(type)}
                              gradeCall={grade => this.gradeActionCall(grade)}
                              errorRange={this.props.School_fpot.errorRange}
                              showHideRecentRecord={
                                this.props.School_fpot.showHideRecentRecord
                              }
                              SelectedErr={this.props.School_fpot.SelectedErr}
                              CommonFilterData={this.props.CommonFilterData}
                              externalFilter={this.state.externalFilter}
                              showRecord={this.props.School_fpot.showRecord}
                              token={this.props.LoginDetails.JWTToken}
                              gradeList={this.props.gradeList}
                              selGrade={this.props.School_fpot.gradeSelected}
                              ContextHeader={this.props.ContextHeader}
                            />

                            <SchoolFpotGrid
                              scrollFlag={false}
                              fpotSidePanelResponse={
                                this.props.School_fpot.fpotSidePanelResponse
                              }
                              fpotSidePanelData={this.props.School_fpot.fpotSidePanelData}
                              Data={this.props.School_fpot.SortData}
                              panelData={this.props.School_fpot.SfpotGridData}
                              disableDiv={this.props.School_fpot.disableDiv}
                              selectedError={selectedErr}
                              navigateToStudentReport={(studentInfo) => { this.props.navigateToStudentReport(studentInfo, true); }}
                            />
                            {selectedErr.length < 1 && (
                              <div className="col-md-4 res-width">
                                <MakeSelectionForORR />
                              </div>
                            )}
                          </React.Fragment>
                        )}
                    </div>
                    {this.props.School_fpot.firstRecordObj &&
                      !this.props.School_fpot.noData &&
                      !this.props.School_fpot.hideChart && this.props.School_fpot.fpotSidePanelData &&
                      <span className="print-icon-class-btn ipad-print-algn">
                        <PrintScFpot
                          scrollFlag={true}
                          selectedFilter={this.props.CommonFilterData}
                          studentDetails={this.props.ContextHeader}
                          navSelected={this.props.NavigationByHeaderSelection}
                          firstRecord={this.props.School_fpot.firstRecordObj}
                          allRecord={this.props.School_fpot.allRecordObj}
                          recentRecord={this.props.School_fpot.recentRecordObj}
                          errorRange={this.props.School_fpot.errorRange}
                          showHideRecentRecord={
                            this.props.School_fpot.showHideRecentRecord
                          }
                          SelectedErr={this.props.School_fpot.SelectedErr}
                          showRecord={this.props.School_fpot.showRecord}
                          gradeList={this.props.gradeList}
                          selGrade={this.props.School_fpot.gradeSelected}
                          fpotSidePanelResponse={
                            this.props.School_fpot.fpotSidePanelResponse
                          }
                          fpotSidePanelData={this.props.School_fpot}

                        />
                      </span>
                    }
                  </div>
                  {this.props.School_fpot.isApiLoading &&
                    !this.props.School_fpot.apiTimeOut &&
                    this.props.School_fpot.hideChart && (
                      <Spinner
                        startSpinner={!this.props.School_fpot.firstRecordObj}
                        showTimeOut={this.timeOut}
                      />
                    )}
                  {!this.props.School_fpot.isApiLoading &&
                    this.props.School_fpot.apiTimeOut &&
                    this.props.School_fpot.hideChart && (
                      <TimeOut
                        tryAgain={() => this.schoolFpotApi(
                          this.props.School_fpot.showRecord,
                          this.props.School_fpot.gradeSelected
                        )}
                      />
                    )}
                  {this.props.School_fpot.ErrorCode && (
                    <ChartNotLoad
                      tryAgain={() => {
                        this.schoolFpotApi(
                          this.props.School_fpot.showRecord,
                          this.props.School_fpot.gradeSelected
                        );
                      }}
                    />
                  )}
                  {this.props.School_fpot.noData &&
                    this.props.School_fpot.firstRecordObj && !this.props.GradesNotAvailable && (
                      <NoRecordsData NodataFound={"dataNotAvail"} />
                    )}
                  {this.props.School_fpot.rubricDataMsg && !this.props.School_fpot.isApiLoading &&
                    <div>
                      <NoFluencyData NoFluencyData={this.props.School_fpot.rubricDataMsg} />
                    </div>
                  }
                  {
                    this.props.GradesNotAvailable &&
                    <NoRecordsData NodataFound={"dataNotAvail"} />
                  }
                </React.Fragment>
              ) : (
                <NoRosterData />
              )}
          </section>
        </main>
      </React.Fragment>
    );
    // } else {
    //   return '';
    // }
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  School_FA_Reducer
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const { School_fpot, gradeList, SchoolCsvDownload, GradesNotAvailable } = School_FA_Reducer;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    CommonFilterData,
    School_fpot,
    gradeList,
    SchoolCsvDownload,
    GradesNotAvailable,
    AgpCSV,
  };
};

export default connect(mapStateToProps, {
  SCHOOL_FPOT_API_SUCCESS,
  LOAD_ICON,
  navigateToStudentReport,
  selectedScGrade,
  SFR_CSVDATA_DOWNLOAD_APICALL,
  SFR_CSVDATA_DOWNLOAD_RESET,
  Sc_GRADES,
  AGPDistrictCSV,
})(SchoolFpotChart);
