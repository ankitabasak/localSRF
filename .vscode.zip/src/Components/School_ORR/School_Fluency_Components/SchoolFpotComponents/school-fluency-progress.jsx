import React, { PureComponent } from 'react';
import { dataSorting } from '../../../ReusableComponents/OrrReusableComponents';
// import '../class-common.css';
import "../SchoolFpotComponents/school-fpot.css";
import { connect } from 'react-redux';
import { SAVE_SORTED_SCFDATA, SORT_SCFPOT_GRID, UPDATE_ACCORDIAN } from '../../../../Redux_Actions/School_FA_Action.jsx'
import {
  Chart_Enabled
} from '../../../../Redux_Actions/S_ReadingLevelAction.jsx';
import spinner from '../../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';
class SchoolFpotGrid extends PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      showDiv: false,
      accordionList: {}
    };
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  componentDidMount() {
    this.setState({
      ...this.state,
      accordionList: this.props.panelData ? this.props.panelData["accordionList"] : []
    });
  }


  // tooltip for long text
  longTextTooltip(text) {
    if (text.length > 20) {
      return (
        <React.Fragment>
          {text.substr(0, 20)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }
  //to collapse school
  showCollapse(classList) {
    this.props.UPDATE_ACCORDIAN({
      ...this.props.panelData.accordionList,
      [classList]: !this.props.panelData.accordionList[classList]
    })
  }

  scFpoSidePanelData(sortData, sideTableData) {
    const dashSymbol = <span>&mdash;</span>;
    if (this.props.panelData) {
      return (<div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="schoolRlp"
        >
          <div className="student-column-list-rhs-sec sch-fluency-progress-02">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "lastName",
                sortData.sortType
              )}
            >
              Class/Students
              </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "lastName", "desc")
                }
                onClick={() =>
                  this.fpoGrid("lastName", "desc", sideTableData)
                }
              >
                expand_more
                </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "lastName", "asc")
                }
                onClick={() =>
                  this.fpoGrid("lastName", "asc", sideTableData)
                }
              >
                expand_less
                </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec sch-fluency-progress-02">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "grade",
                sortData.sortType
              )}
            >
              Grade
              </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "grade", "desc")
                }
                onClick={() =>
                  this.fpoGrid("grade", "desc", sideTableData)
                }
              >
                expand_more
                </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "grade", "asc")
                }
                onClick={() =>
                  this.fpoGrid("grade", "asc", sideTableData)
                }
              >
                expand_less
                </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec sch-fluency-progress-02">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "readingLevel",
                sortData.sortType
              )}
            >
              Level
              </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "readingLevel", "desc")
                }
                onClick={() =>
                  this.fpoGrid("readingLevel", "desc", sideTableData)
                }
              >
                expand_more
                </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "readingLevel", "asc")
                }
                onClick={() =>
                  this.fpoGrid("readingLevel", "asc", sideTableData)
                }
              >
                expand_less
                </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec sch-fluency-progress-02">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "proficiency",
                sortData.sortType
              )}
            >
              Proficiency
              </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "proficiency", "desc")
                }
                onClick={() =>
                  this.fpoGrid("proficiency", "desc", sideTableData)
                }

              // this.assignClasses(sortData, 'proficiency', 'desc')}
              >
                expand_more
                </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "proficiency", "asc")
                }
                onClick={() =>
                  this.fpoGrid("proficiency", "asc", sideTableData)
                }
              >
                expand_less
                </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "scfa-scroll")}>
          {sideTableData.map((schoolDetails, value) => (
            <div className="student-list-row-rhs-sec sc-rlp" key={value}>
              <div
                className={
                  this.props.panelData.accordionList[schoolDetails["className"]]
                    ? "expanded-group cursor-pointer"
                    : "collapsed-group cursor-pointer"
                }
                style={{ backgroundColor: "#F3F5FA" }}
                onClick={() => this.showCollapse(schoolDetails["className"])}
              >
                <span>
                  {schoolDetails["className"]}&nbsp;&nbsp;(
                    {schoolDetails["studentDetails"].length}
                  &nbsp;Students)
                  </span>
              </div>
              {schoolDetails["studentDetails"].map((studentList, value) => (
                <div
                  className={
                    "pos-rel student-list-row-rhs-sec " +
                    (this.props.panelData.accordionList[schoolDetails["className"]]
                      ? "show"
                      : "hide")
                  }
                  key={value}
                >
                  <div className="student-column-list-rhs-sec sch-fluency-progress-02" onClick={() => {
                    this.props.navigateToStudentReport(studentList)
                  }}>
                    <span className="cursor-pointer wb-break-all long-text-tooltip">
                      {this.longTextTooltip(studentList.firstName + ' ' + studentList.lastName)}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec sch-fluency-progress-02">
                    <span>
                      {studentList.grade ? studentList.grade : dashSymbol}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec sch-fluency-progress-02">
                    <span>
                      {studentList.readingLevel
                        ? studentList.readingLevel
                        : dashSymbol}
                    </span>
                  </div>
                  <div className="student-column-list-rhs-sec sch-fluency-progress-02">
                    <span>
                      {studentList.proficiency
                        ? studentList.proficiency
                        : dashSymbol}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>)
    } else {
      return <div><p>No Data Available</p></div>
    }

  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? 'rt-td-active'
      : '';
  }

  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return ' blueColor';
    } else {
      return '';
    }
  }

  //Onclick calling sort function and update the sort type and column in store
  fpoGrid(sortColumn, sortType, actualArray) {
    document.getElementById('scFpt').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_SCFPOT_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map((actualArray, value) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(
          actualArray.studentDetails,
          column,
          sortType
        );

      }
    });
    this.props.SAVE_SORTED_SCFDATA(stdArray);
  }

  render() {
    return (
      <React.Fragment>
        {/* {!this.props.disableDiv ? */}

        {this.props.panelData && this.props.fpotSidePanelData && (
          <div className="col-md-4 res-width cea-rhs-rel mt-6 mt-15 sc-fp-wrap" id="scFpt">
            <div>
              {/* onclick and on load main api should send the Reading target */}
              <div className="pull-left rt-left-heading">
                {this.props.fpotSidePanelResponse.selectedRecordTypeDetails.recordTitle}
              </div>
              <div className="pos-rel">
                <div className="rt-rhs-strip"></div>
                <hr className="clearfix mb-8" />
              </div>
              <div className="mb-10">
                <div className="reading-level-label mb-8 color-1">
                  First Record Date Range:
                <span> {
                    this.props.fpotSidePanelResponse.selectedRecordTypeDetails
                      .firstRecordDateRange
                  }
                  </span>
                </div>
                <div className="reading-level-label color-2">
                  Recent Record Date Range:
                <span> {
                    this.props.fpotSidePanelResponse.selectedRecordTypeDetails
                      .recentRecordDateRange
                  }
                  </span>
                </div>
              </div>
              <div className="pull-right clearfix new-mb-4 rt-label-txt">
                <span className="rt-label">
                  No. of students rostered:
                <span> {
                    this.props.fpotSidePanelResponse.selectedRecordTypeDetails
                      .noOfStudentsRoastered
                  }
                  </span>
                </span>
              </div>
              <div className="rhs-wrap sc-fluency-progress-rhs-wrap">
                <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                  <div className="student-list-table-main scrh-rhs-row">
                    <div className="student-list-table-rhs-sec sch-fluency-progress-01">
                      {this.scFpoSidePanelData(
                        this.props.Data,
                        this.props.fpotSidePanelData
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}


        {this.props.disableDiv && this.props['selectedError'] && this.props.selectedError.length > 0 &&
          <div className="col-md-4 res-width display-msg err-msg-alignment">
            <img src={spinner} alt="spinner" />
          </div>}
      </React.Fragment>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { SAVE_SORTED_SCFDATA, SORT_SCFPOT_GRID, UPDATE_ACCORDIAN, Chart_Enabled }
)(SchoolFpotGrid);
// export default Ea_Table;
