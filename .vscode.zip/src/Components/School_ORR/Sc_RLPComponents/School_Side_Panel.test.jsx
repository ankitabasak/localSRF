import React from 'react';
import { shallow } from 'enzyme';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import ScSidePanel from './School_Side_Panel';

jest.mock('react-redux', () => ({
  connect: jest.fn().mockImplementation(() => (component) => component),
}));
function setup(overrides = {}) {
  const props = {
    selectedLevels: {
      'recentRecord': {},
      'firstRecord': {},
    }
  };
  const finalProps = Object.assign(props, overrides);
  const wrapper = shallow((
      <ScSidePanel {...finalProps} />
  ));
  return { wrapper };
};

describe('ScSidePanel', () => {
  describe('renders properly', () => {
    const { wrapper } = setup();
    it('renders component', () => {
      expect(wrapper).toHaveLength(1);
    });

    it('matches snapshot', () => {
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe('renders properly', () => {
    it('MakeSelectionForORR component will render', () => {
      const { wrapper } = setup({
        bubblesSelected: []
      });
      expect(wrapper.find('MakeSelectionForORR')).toHaveLength(1);
    });
  });
});
