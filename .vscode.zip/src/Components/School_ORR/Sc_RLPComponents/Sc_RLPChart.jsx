import React, { Component } from 'react';
import '../Sc_RLPComponents/school-rlp.css';
import Filter from '../../ORR/FilterComponents/Filter';
import YAxisComponent from './School_RLP_Reading_Level_Component/School_RLP_Reading_Levels.jsx';
import SchoolRlpGrade from './School_RLP_Grade_Column/SchoolRLPGradeColumn.jsx';
import ScSidePanel from './School_Side_Panel.jsx';
import { connect } from 'react-redux';
import {
  School_Show_loading_Icon,
  School_RLP_Grid_Chart_Table_API,
  School_Class_Grid_Chart_Table_API,
  School_Level_RLP_Chart_API,
  School_Level_Scroll_Data,
  School_Class_Level_RLP_Chart_API,
  Selected_Levels,
  Chart_loading_Failed,
  Api_Timeout,
  SCHRLP_CSVDATA_DOWNLOAD_APICALL,
  SCHRLP_CSVDATA_DOWNLOAD_RESET,
  SCHRLP2_CSVDATA_DOWNLOAD_APICALL,
  SCHRLP2_CSVDATA_DOWNLOAD_RESET,
  updateDropDownData,
  updateAllMonth,
  toggleDropDown,
  updateChartDetails
} from '../../../Redux_Actions/School_RlpActions.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import NoRecordsData from '../../../Utils/No_Data_Found';
import PrintScRlp from '../../ReusableComponents/PrintOrrCharts/Sc_RlpPrint.jsx';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { AGPDistrictCSV } from '../../../Redux_Actions/District_Report_Actions';
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from '../../../Utils/globalVars';
import { csvDownload } from '../../../Utils/CSVDownload/AGPReports';
import Confirmation_AgpPopup from '../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';

class SchoolRLPChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sidepanelApiInRun: false,
      grade: ''
    };
    this.schoolRlpGridApi = this.schoolRlpGridApi.bind(this);
    this.backToMainChart = this.backToMainChart.bind(this);
    this.tryAgainFunction = this.tryAgainFunction.bind(this);
  }

  componentDidMount() {
       if (this.props.ContextHeader.Roster_Tab.SelectedSchool.id) {
    let payLoad = getCommonHeaders(this.props, 'school');
    this.props.School_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
       }
  }
 componentDidUpdate(prevProps) {
    if (this.props.ContextHeader.Roster_Tab.SelectedSchool.id !== prevProps.ContextHeader.Roster_Tab.SelectedSchool.id) {
    let payLoad = getCommonHeaders(this.props, 'school');
    this.props.School_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
    }
  }

  // time out
  timeOut() {
    this.props.Api_Timeout({ timeOut: true });
  }
  //schoolRlp Grid API
  downLoadCSVDataSlRlp2() {
    let Req_Payload = {
      schoolChartType: {
        "allGrades": false,
        "allRecordsAvgFlag": 0,
        "chartName": "ScRLP2",
        "gradeValue": this.state.grade
      },
      ...getCommonHeaders(this.props, 'school')
    };
    delete Req_Payload.externalFilter.selectedStudentsList;
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, Req_Payload);
    } else {
      this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP' &&
        this.props.SCHRLP2_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.SCHRLP2_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
    }
  }
  // Download csv data
  downLoadCSVData() {
    let Req_Payload = {
      schoolChartType: {
        "allGrades": true,
        "allRecordsAvgFlag": 0,
        "chartName": "ScRLP1",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'school')
    };
    delete Req_Payload.externalFilter.selectedStudentsList;
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, Req_Payload);
    } else {
      this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP' &&
        this.props.SCHRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.SCHRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
    }
  }

  schoolRlpGridApi(selectedLevels) {
    let SL;
    let grade = 'grade';

    if (this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP') {
      grade = 'className';
    }

    if (selectedLevels['recentRecord']) {
      SL = selectedLevels['recentRecord'].map(obj => {
        if (grade == 'className') {
          return {
            [grade]: obj[grade],
            classId: obj['classId'],
            orrAssignmentId: obj.orrAssignmentId,
            ['grade']: this.props.SchoolRLPState.schoolLevelGrade
          };
        } else {
          return { [grade]: obj[grade], orrAssignmentId: obj.orrAssignmentId };
        }
      });
    } else if (selectedLevels['firstRecord']) {
      SL = selectedLevels['firstRecord'].map(obj => {
        if (grade == 'className') {
          return {
            [grade]: obj[grade],
            classId: obj['classId'],
            orrAssignmentId: obj.orrAssignmentId,
            ['grade']: this.props.SchoolRLPState.schoolLevelGrade
          };
        } else {
          return { [grade]: obj[grade], orrAssignmentId: obj.orrAssignmentId };
        }
      });
    } else {
      SL = selectedLevels;
    }

    let Payload = {
      ...getCommonHeaders(this.props, 'school'),
      selectedLevels: SL
    };

    if (this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP') {
      if (!this.state.sidepanelApiInRun) {
        this.setState({ ...this.state, sidepanelApiInRun: true });
        setTimeout(() => {
          this.props.School_RLP_Grid_Chart_Table_API(
            this.props.LoginDetails.JWTToken,
            Payload
          );
          this.setState({ ...this.state, sidepanelApiInRun: false });
        }, 500);
      }
    } else if (this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP') {
      if (!this.state.sidepanelApiInRun) {
        this.setState({ ...this.state, sidepanelApiInRun: true });
        setTimeout(() => {
          this.props.School_Class_Grid_Chart_Table_API(
            this.props.LoginDetails.JWTToken,
            Payload
          );
          this.setState({ ...this.state, sidepanelApiInRun: false });
        }, 500);
      }
    }
  }

  // X axis scroll control
  getGradeArray(listItems, index) {
    return listItems.slice(index, this.props.SchoolRLPState['isMobileView']);
  }
  // check for duplicate value
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          JSON.stringify(bubble.orrAssignmentId) ==
          JSON.stringify(obj.orrAssignmentId)
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  saveSelectedLevels(levels, selLvls) {
    let selectedLevels = selLvls[levels.type];
    if (selectedLevels) {
      let duplicateIndex = this.isDuplicateBubble(levels, selectedLevels);

      if (duplicateIndex != -1) {
        selectedLevels.splice(duplicateIndex, 1);
      } else {
        selectedLevels.push(levels);
      }

      this.props.Selected_Levels({
        ['selectedLevels']: { [levels.type]: selectedLevels }
      });

      this.schoolRlpGridApi({ [levels.type]: selectedLevels });
    } else {
      selectedLevels = { [levels.type]: [levels] };

      this.props.Selected_Levels({
        ['selectedLevels']: selectedLevels
      });
      this.schoolRlpGridApi(selectedLevels);
    }
  }

  getAxisRangeData(dataList, index) {
    let rl = dataList.slice(index, 13);
    return rl.reverse();
  }

  scrollUpDown(dataList, index, scrollType) {
    let rl = [];
    switch (scrollType) {
      case 'up':
        if (index < dataList.length - 13) {
          let scrlIndex = index + 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 13);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'down':
        if (index > 0) {
          let scrlIndex = index - 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 13);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeTop':
        if (index < dataList.length - 13) {
          rl = dataList.slice(dataList.length - 13, dataList.length);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: dataList.length - 13
          });
        }
        return;
      case 'extremeBottom':
        if (index > 0) {
          let scrlIndex = 0;
          rl = dataList.slice(0, 13);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  setDataScrollState(data) {
    this.props.School_Level_Scroll_Data(data);
  }

  scrollRightLeft(dataList, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataList.length - this.props.SchoolRLPState['isMobileView']) {
          let scrlIndex = index + 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + this.props.SchoolRLPState['isMobileView']),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let scrlIndex = index - 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + this.props.SchoolRLPState['isMobileView']),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataList.length - this.props.SchoolRLPState['isMobileView']) {
          let scrlIndex = dataList.length - this.props.SchoolRLPState['isMobileView'];

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, dataList.length),
            xScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let scrlIndex = 0;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(0, this.props.SchoolRLPState['isMobileView']),
            xScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  getClassLevelRLPData(grade) {
    this.props.School_Show_loading_Icon('');
    let payLoad = {
      ...getCommonHeaders(this.props, 'school'),
      grade: grade.schoolGrade,
    };

    this.setState({ grade: grade.schoolGrade })

    this.props.School_Class_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }
  // EXPAND AND COLLAPSE DATA UPDATE
  updateExpandCollapseData(dropDownSelection) {
    Promise.resolve(this.props.updateChartDetails(dropDownSelection)).then((response) => {

      if (this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP') {
        let selectedGrades = this.props.SchoolRLPState.constructedData['xAxisData'];
        if (selectedGrades && selectedGrades.length > 0) {
          const selectedGrade = selectedGrades[0];

          let firstRecord = Object.keys(selectedGrade['recordDataList']['firstRecord']);
          let recentRecord = Object.keys(selectedGrade['recordDataList']['recentRecord']);
          let selectedBoxes = {}
          if (recentRecord && recentRecord.length > 0) {
            selectedBoxes['recentRecord'] = []
            recentRecord.forEach((readingLevel) => {
              selectedBoxes['recentRecord'].push({ orrAssignmentId: selectedGrade['recordDataList']['recentRecord'][readingLevel]['orrAssignmentId'], grade: selectedGrade['grade'] })

            })

          } else if (firstRecord && firstRecord.length > 0) {
            selectedBoxes['firstRecord'] = []
            firstRecord.forEach((readingLevel) => {
              selectedBoxes['firstRecord'].push({ orrAssignmentId: selectedGrade['recordDataList']['firstRecord'][readingLevel]['orrAssignmentId'], grade: selectedGrade['grade'] })

            })
          }

          this.props.Selected_Levels({
            ['selectedLevels']: selectedBoxes
          });
          this.schoolRlpGridApi(selectedBoxes);
        }
      } else if (this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP') {
        let selectedGrades = this.props.SchoolRLPState.constructedData['xAxisData'];
        if (selectedGrades && selectedGrades.length > 0) {
          const selectedGrade = selectedGrades[0];

          let firstRecord = Object.keys(selectedGrade['recordDataList']['firstRecord']);
          let recentRecord = Object.keys(selectedGrade['recordDataList']['recentRecord']);
          let selectedBoxes = {}
          if (recentRecord && recentRecord.length > 0) {
            selectedBoxes['recentRecord'] = []
            recentRecord.forEach((readingLevel) => {
              selectedBoxes['recentRecord'].push({
                classId: selectedGrade['classId'],
                className: selectedGrade['className'],
                orrAssignmentId: selectedGrade['recordDataList']['recentRecord'][readingLevel]['orrAssignmentId'],
                grade: selectedGrade['grade']
              })

            })

          } else if (firstRecord && firstRecord.length > 0) {
            selectedBoxes['firstRecord'] = []
            firstRecord.forEach((readingLevel) => {
              selectedBoxes['firstRecord'].push({
                classId: selectedGrade['classId'],
                className: selectedGrade['className'],
                orrAssignmentId: selectedGrade['recordDataList']['firstRecord'][readingLevel]['orrAssignmentId'],
                grade: selectedGrade['grade']
              })

            })
          }

          this.props.Selected_Levels({
            ['selectedLevels']: selectedBoxes
          });
          this.schoolRlpGridApi(selectedBoxes);
        }
      }

    });
  }

  tryAgainFunction(chartToDisplay, grade) {
    if (chartToDisplay == 'CLRLP') {
      this.getClassLevelRLPData(grade)
    } else if (chartToDisplay == 'SLRLP') {
      this.backToMainChart()
    }

  }

  backToMainChart() {
    this.props.School_Show_loading_Icon('');
    let payLoad = getCommonHeaders(this.props, 'school');
    this.props.School_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }
  render() {
    let chartData = this.props.SchoolRLPState.constructedData;
    let gradeSelected = this.props.SchoolRLPState['schoolLevelGrade'];
    let viewSpecificScroll = this.props.SchoolRLPState['isMobileView'];
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedSchool.name;
    if (this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP') {
      if (this.props.schoolCsvDownload && this.props.schoolCsvDownload['downloadInProgress'] && this.props.schoolCsvDownload['csvData']) {
        setTimeout(() => {
          this.refs.groupCSV.link.click();
          this.props.SCHRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
        }, 500)
      }
    }
    if (this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP') {
      if (this.props.schoolCsvDownload && this.props.schoolCsvDownload['downloadInProgress'] && this.props.schoolCsvDownload['csvData']) {
        setTimeout(() => {
          this.refs.groupCSV.link.click();
          this.props.SCHRLP2_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
        }, 500)
      }
    }
    return (
      <div>
        <Filter
          chartDisplay={this.props.SchoolRLPState.currentChartInDisplay}
          grade={gradeSelected}
        />
        {!this.props.SchoolRLPState.isApiLoading && chartData && (
          <div
            className="container"
            style={{
              maxWidth: '1165px',
              paddingLeft: '0px',
              paddingRight: '0px'
            }}
          >
            {/* {this.props.isApiLoading && <Spinner />} */}

            <React.Fragment>
              {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
              <div className="row mt-10" id="testSchoolChart" style={{ marginTop: '7px' }}>
                {this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP' &&
                  this.props.schoolCsvDownload && this.props.schoolCsvDownload['csvData'] &&
                  <CSVLink
                    ref="groupCSV"
                    headers={this.props.schoolCsvDownload['csvData'] && this.props.schoolCsvDownload['csvData']['header']}
                    data={this.props.schoolCsvDownload['csvData'] && this.props.schoolCsvDownload['csvData']['data']}
                    style={{ display: 'none' }}
                    filename={`${csvFileName}.csv`}
                  />}
                {this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP' &&
                  this.props.schoolCsvDownload && this.props.schoolCsvDownload['csvData'] &&
                  <CSVLink
                    ref="groupCSV"
                    headers={this.props.schoolCsvDownload['csvData'] && this.props.schoolCsvDownload['csvData']['header']}
                    data={this.props.schoolCsvDownload['csvData'] && this.props.schoolCsvDownload['csvData']['data']}
                    style={{ display: 'none' }}
                    filename={`${csvFileName}.csv`}
                  />}
                <div className="dst-csv-icon-alignment orr-top4"
                  onClick={
                    () => !this.props.schoolCsvDownload['downloadInProgress'] && this.downLoadCSVData()
                  }>
                  {this.props.schoolCsvDownload && this.props.schoolCsvDownload['downloadInProgress'] ?
                    <span className="csv_download_icon">
                      <i className="material-icons">autorenew</i>
                    </span> :
                    <span className="csv_download_icon">
                      <img src={CsvIcon} width="20" height="20" />
                    </span>}
                </div>
                <div className="srlp-lhs-wrap sc-rlp-wrap ipad-3col">
                  <div className="wrap-srlp pos-rel ">
                    {!this.props.popUp &&
                      <div className="legend_sec">
                        <span>Legend:</span>
                        <div className="gray-rect" />
                        <p>Grade Reading</p>
                        <p>Level Target</p>
                      </div>}

                    <div className="readingLevel-srlp">Reading Level</div>
                    <div className="grade-txt-srlp bt-27">
                      {this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP'
                        ? 'Grade'
                        : 'Classes'}
                    </div>
                    <div className="rhs-line-srlp" />
                    <div className="rhs-line2-srlp" />
                    <div className="rhs-line-btm-srlp" />
                    <div className="rhs-line-btm1-srlp" />

                    {chartData.yAxisDataRange && (
                      <YAxisComponent
                        axisData={{
                          dataRange: chartData.yAxisDataRange,
                          scrollIndex: chartData.yScrollIndex,
                          xScrollIndex: chartData.xScrollIndex,
                          allReadingLevels: chartData.yAxisData
                        }}
                        scrollReadingLevels={scrollType => {
                          this.scrollUpDown(
                            chartData.yAxisData,
                            chartData.yScrollIndex,
                            scrollType
                          );
                        }}
                        scrollGradeLevels={scrollType => {
                          this.scrollRightLeft(
                            chartData.xAxisData,
                            chartData.xScrollIndex,
                            scrollType
                          );
                        }}
                      />
                    )}

                    {chartData.xAxisGradeRange && (
                      <SchoolRlpGrade
                        updateChartDetails={(data) => this.updateExpandCollapseData(data)}
                        toggleDropDown={(data) => this.props.toggleDropDown(data)}
                        updateAllMonth={(data) => this.props.updateAllMonth(data)}
                        updateDropDownDetails={(data) => this.props.updateDropDownData(data)}
                        monthRangeObj={this.props.monthRangeObj}
                        selAll={this.props.selAll}
                        toggleData={this.props.toggleData}
                        viewSpecificScroll={viewSpecificScroll}
                        backToMainChart={this.backToMainChart}
                        gradesData={chartData.xAxisGradeRange}
                        readingLevels={chartData.yAxisDataRange}
                        selectedClassLevels={selectedLevels => {
                          this.saveSelectedLevels(
                            selectedLevels,
                            this.props.SchoolRLPState.schoolsSelected || {}
                          );
                        }}
                        selectedLevels={this.props.SchoolRLPState.schoolsSelected}
                        currentChartInDisplay={
                          this.props.SchoolRLPState.currentChartInDisplay
                        }
                        scrollGradeLevels={scrollType => {
                          this.scrollRightLeft(
                            chartData.xAxisData,
                            chartData.xScrollIndex,
                            scrollType
                          );
                        }}
                        totalGradeItems={chartData.xAxisData}
                        scrollIndex={chartData.xScrollIndex}
                        getClassLevelRLPData={grade => {
                          this.getClassLevelRLPData(grade);
                        }}
                      />
                    )}
                  </div>
                </div>
                <div className="wrap2 sc_wrap2 ipad-sc_wrap2">
                  {
                    <ScSidePanel
                      scrollFlag={false}
                      schoolData={this.props.SchoolRlpGridData}
                      sortData={this.props.SortData}
                      currentChartInDisplay={
                        this.props.SchoolRLPState.currentChartInDisplay
                      }
                      selectedLevels={this.props.SchoolRLPState.schoolsSelected}
                      sidePanelApiFailed={this.props.sidePanelApiFailed}
                    />
                  }
                </div>
              </div>
              {this.props.SchoolRlpGridData &&
                <span className="print-icon-class-btn scrlp-ipad-pro orr-top4">
                  <PrintScRlp
                    monthRangeObj={this.props.monthRangeObj}
                    selAll={this.props.selAll}
                    scrollFlag={true}
                    gradeSelected={gradeSelected}
                    selectedFilter={this.props.CommonFilterData}
                    studentDetails={this.props.ContextHeader}
                    navSelected={this.props.NavigationByHeaderSelection}
                    axisData={{
                      dataRange: chartData.yAxisDataRange,
                      scrollIndex: chartData.yScrollIndex,
                      xScrollIndex: chartData.xScrollIndex,
                      allReadingLevels: chartData.yAxisData
                    }}
                    gradesData={chartData.xAxisGradeRange}
                    readingLevels={chartData.yAxisDataRange}
                    selectedLevels={this.props.SchoolRLPState.schoolsSelected}
                    currentChartInDisplay={
                      this.props.SchoolRLPState.currentChartInDisplay
                    }
                    totalGradeItems={chartData.xAxisData}
                    scrollIndex={chartData.xScrollIndex}
                    schoolData={this.props.SchoolRlpGridData}
                    sortData={this.props.SortData}
                  />
                </span>}
            </React.Fragment>

          </div>
        )}
        {this.props.SchoolRLPState.isApiLoading && !this.props.chartData && !this.props.SchoolRLPState.noChartData && (
          <Spinner
            startSpinner={this.props.isApiLoading}
            showTimeOut={this.timeOut}
          />
        )}
        {!chartData && this.props.SchoolRLPState.timeOut && (
          <TimeOut tryAgain={() => this.tryAgainFunction(this.props.SchoolRLPState.currentChartInDisplay, gradeSelected)} />
        )}
        {!chartData && this.props.SchoolRLPState.apiLoadFail && (
          <ChartNotLoad tryAgain={() => this.tryAgainFunction(this.props.SchoolRLPState.currentChartInDisplay, gradeSelected)} />
        )}
        {!chartData && this.props.SchoolRLPState.noChartData && !this.props.SchoolRLPState.isApiLoading && (<NoRecordsData NodataFound={'dataNotAvail'} />)}

      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  SchoolRlpData,
  SummaryTabReducer
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const { SchoolRLPState,
    SchoolRlpGridData,
    SortData,
    monthRangeObj,
    selAll,
    toggleData,
    sidePanelApiFailed,
    schoolCsvDownload } = SchoolRlpData;
  const { CommonFilterData } = CommonFilterDetails;
  const { popUp } = SummaryTabReducer;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    SchoolRLPState,
    CommonFilterData,
    SchoolRlpGridData,
    sidePanelApiFailed,
    SortData,
    popUp,
    monthRangeObj,
    selAll,
    toggleData,
    schoolCsvDownload,
    AgpCSV,
  };
};

export default connect(
  mapStateToProps,
  {
    School_Show_loading_Icon,
    School_RLP_Grid_Chart_Table_API,
    School_Level_RLP_Chart_API,
    School_Level_Scroll_Data,
    School_Class_Level_RLP_Chart_API,
    School_Class_Grid_Chart_Table_API,
    Selected_Levels,
    Chart_loading_Failed,
    Api_Timeout,
    SCHRLP_CSVDATA_DOWNLOAD_APICALL,
    SCHRLP_CSVDATA_DOWNLOAD_RESET,
    SCHRLP2_CSVDATA_DOWNLOAD_APICALL,
    SCHRLP2_CSVDATA_DOWNLOAD_RESET,
    updateDropDownData,
    updateAllMonth,
    toggleDropDown,
    updateChartDetails,
    AGPDistrictCSV,
  }
)(SchoolRLPChart);
