import React, { Component } from "react";
import { connect } from "react-redux";
import { dataSorting } from "../../ReusableComponents/OrrReusableComponents";
import {
  SORT_SCLRLP_GRID,
  SAVE_SORTED_SCLRLPDATA,
  SHOW_HIDE_BAR
} from "../../../Redux_Actions/School_RlpActions.jsx";
import {
  navigateToStudentReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import {
  Chart_Enabled
} from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';

class ScSidePanel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showDiv: false
    };

    this.goToStudentReport = this.goToStudentReport.bind(this);
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text) {
    if (text && text.length > 20) {
      return (
        <React.Fragment>
          {text.substr(0, 20)}...
          <div className="tooltip-container word-bk scRlpWb-20-20">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text ? text : <span>&mdash;</span>)
    }
  }
  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? "rt-td-active"
      : "";
  }

  //to assign color
  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return " blueColor";
    } else {
      return "";
    }
  }
  // Drill Down

  goToStudentReport(studentInfo) {
    //this.props.GetCompleteStudentReport();
    this.props.Chart_Enabled({
      showFluency: false,
      showAccuracy: false
    });
    this.props.navigateToStudentReport(studentInfo, false);
  }

  //sort school grid on click
  schoolRlpSort(sortColumn, sortType, actualArray) {
    document.getElementById("schoolRlp").scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_SCLRLP_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map((actualArray, value) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(
          actualArray.schoolRLPGradeWiseGridDataRecordDataList,
          column,
          sortType
        );
        this.props.SAVE_SORTED_SCLRLPDATA(sortedArray);
      }
    });

    // this.setState({ ...this.state, sideTableData: stdArray });
  }

  //to collapse school
  showCollapse(classList) {
    this.props.SHOW_HIDE_BAR({
      ...this.props.schoolData.showAccordion,
      [classList]: !this.props.schoolData.showAccordion[classList]
    });
  }

  // display side table
  displaySideTable(sortData, sideTableData) {
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="schoolRlp"
        >
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "lastName",
                sortData.sortType
              )}
            >
              Class/Student
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "lastName", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("lastName", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "lastName", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("lastName", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "grade",
                sortData.sortType
              )}
            >
              Grade
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "grade", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("grade", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "grade", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("grade", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "level",
                sortData.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "level", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("level", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "level", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("level", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "proficiency",
                sortData.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "proficiency", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("proficiency", "desc", sideTableData)
                }

              // this.assignClasses(sortData, 'proficiency', 'desc')}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "proficiency", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("proficiency", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "scrlp-scroll-body")}
        >
          {sideTableData.map((schoolDetails, value) => (
            <div className="student-list-row-rhs-sec sc-rlp" key={value}>
              <div
                className={
                  this.props.schoolData.showAccordion[schoolDetails.schoolName]
                    ? "expanded-group cursor-pointer"
                    : "collapsed-group cursor-pointer"
                }
                style={{ backgroundColor: "#F3F5FA" }}
                onClick={() => this.showCollapse(schoolDetails.schoolName)}
              >
                <span>
                  {schoolDetails.schoolName}&nbsp;&nbsp;(
                  {
                    schoolDetails.schoolRLPGradeWiseGridDataRecordDataList
                      .length
                  }
                  &nbsp;Students)
                </span>
              </div>
              {schoolDetails.schoolRLPGradeWiseGridDataRecordDataList.map(
                (studentList, value) => (
                  <div
                    className={
                      "pos-rel student-list-row-rhs-sec " +
                      (this.props.schoolData.showAccordion[
                        schoolDetails.schoolName
                      ]
                        ? "show"
                        : "hide")
                    }
                    key={value}
                  >
                    <div className="student-column-list-rhs-sec" onClick={() => { this.goToStudentReport(studentList) }}>
                      <span className="cursor-pointer wb-break-all long-text-tooltip">
                        {this.longTextTooltip(studentList.firstName + ' ' + studentList.lastName)}
                      </span>
                    </div>
                    <div className="student-column-list-rhs-sec">
                      <span>
                        {studentList.grade ? studentList.grade : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list-rhs-sec">
                      <span>
                        {studentList.level ? studentList.level : dashSymbol}
                      </span>
                    </div>
                    <div className="student-column-list-rhs-sec">
                      <span>
                        {studentList.proficiency
                          ? studentList.proficiency
                          : dashSymbol}
                      </span>
                    </div>
                  </div>
                )
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }
  render() {
    let schoolRecords;
    let sidePanelData;
    if (this.props.schoolData) {
      schoolRecords = this.props.schoolData;
      sidePanelData = this.props.schoolData.schoolSidePanelData;
    }
    let sidePanelApiFailed = this.props.sidePanelApiFailed;
    let selLvls =
      this.props.selectedLevels["recentRecord"] ||
      this.props.selectedLevels["firstRecord"];

    if (selLvls && selLvls.length > 0) {
      return (
        <div
          className="popUp-width "
        // style={{ width: '431px', paddingLeft: '0px', paddingRight: '0px' }}
        >
          {schoolRecords && !sidePanelApiFailed && <React.Fragment>
            <div className="reading-target-wrap">
              <div className="pull-left rt-left-heading">
                {this.props.currentChartInDisplay == "SLRLP" ? (
                  <span>
                    Grades: {schoolRecords.grade}
                  </span>
                ) : this.props.currentChartInDisplay == "CLRLP" ? (
                  <span>{schoolRecords.classes}</span>
                ) : (
                      ""
                    )}
              </div>
              <hr className="clearfix mb-8" />
              <div className="Readingtarget-graph">
                <div className="chart-details mb-10">
                  <div className="reading-level-label mb-8 color-1">
                    First Record Date Range:
                  <span> {schoolRecords.firstRecDR}</span>
                  </div>
                  <div className="reading-level-label color-1">
                    Recent Record Date Range:
                  <span> {schoolRecords.recentRecDR}</span>
                  </div>
                </div>
              </div>
              <div
                className="pull-right clearfix sum-mr"
                style={{ marginBottom: "4px" }}
              >
                <span style={{ fontSize: "12px", fontWeight: "500" }}>
                  No. of students rostered: {schoolRecords.studentRoster}
                </span>
              </div>
              <div className="rhs-wrap sc_rhs_wrap">
                <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                  <div className="student-list-table-main scrh-rhs-row">
                    <div className="student-list-table-rhs-sec">
                      {this.displaySideTable(this.props.sortData, sidePanelData)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </React.Fragment>
          }
          {!schoolRecords && !sidePanelApiFailed &&
            <React.Fragment>
              <div className="display-msg err-msg-alignment scRlp-err-msg-alignment top-30">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>

          }
          {!schoolRecords && sidePanelApiFailed && <React.Fragment>
            <div className="display-msg err-msg-alignment scRlp-err-msg-alignment top-30">
              The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
            </div>
          </React.Fragment>}
        </div>
      );
    } else {
      return (
        <MakeSelectionForORR />
      );
    }
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(mapStateToProps, {
  SORT_SCLRLP_GRID,
  SAVE_SORTED_SCLRLPDATA,
  SHOW_HIDE_BAR,
  navigateToStudentReport,
  Chart_Enabled
})(ScSidePanel);