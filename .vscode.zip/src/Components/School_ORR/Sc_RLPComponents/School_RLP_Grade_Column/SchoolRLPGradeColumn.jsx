import React, { Component } from 'react';
import rightScroll from '../../../../../public/assets/orr/rlp-screen/x-next.svg';
import rightScrollActive from '../../../../../public/assets/orr/rlp-screen/x-next-active.svg';
import rightExtremeScroll from '../../../../../public/assets/orr/rlp-screen/x-next-end.svg';
import rightExtremeScrollActive from '../../../../../public/assets/orr/rlp-screen/x-next-end-active.svg';
import backArrow from '../../../../../public/assets/orr/rlp-screen/top-arrow.svg';
import Compare_Chart_Data from '../../../ORR_DropDown/Compare_Data.jsx';
import { constructElipsisGradeText } from '../../../../Utils/Text';

class SchoolRlpGrade extends Component {

  constructor() {
    super();
    this.state = { currentIndex: null }
  }
  getGradeRange(GLRange, level, selectedClassLevels, currentLevelInfo) {
    let bgColor = '';
    let textColor = 'black';

    if (GLRange.indexOf(level) > -1) {
      bgColor = '#d6dbe5';
      textColor = 'black';
    }

    if (selectedClassLevels && selectedClassLevels[currentLevelInfo.type]) {
      selectedClassLevels[currentLevelInfo.type].forEach(obj => {
        if (
          JSON.stringify(currentLevelInfo.orrAssignmentId) ==
          JSON.stringify(obj.orrAssignmentId)
        ) {
          bgColor = '#00539B';
          textColor = 'white';
          return;
        }
      });
    }

    return { backgroundColor: bgColor, color: textColor };
  }
  //to display the last passage
  showToolTip(passage) {
    return (
      <div className="hover-rlp">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }
  //to fix ipad hover, keep separate 
  showToolTipForIpad(passage) {
    return (
      <div className="hover-rlp-chart2">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }
  setIndexForTooltip(index) {
    if (this.state['currentIndex'] != null && this.state['currentIndex'] == index) {
      this.setState({ ...this.state, currentIndex: null })
    } else {
      this.setState({ ...this.state, currentIndex: index })
    }

  }
  render() {
    if (this.props.currentChartInDisplay == 'SLRLP') {
      return (
        <div
          className={this.props.gradesData.length == 1 ? "graph-content pull-left pos-rel single-month" : "graph-content pull-left pos-rel "}
          style={{ boder: 'none', marginLeft: '4px' }}
        >
          <Compare_Chart_Data
            summaryFlag={this.props.summaryFlag}
            updateChartDetails={(data) => this.props.updateChartDetails(data)}
            monthRangeObj={this.props.monthRangeObj}
            selAll={this.props.selAll}
            toggleData={this.props.toggleData}
            updateDetails={(data) => this.props.updateDropDownDetails(data)}
            updateAllMonth={(data) => this.props.updateAllMonth(data)}
            toggleDropDown={(data) => this.props.toggleDropDown(data)}
          />
          {this.props.gradesData.map((item, index) => {
            return (
              <div className="first-coloumn-srlp pull-left pos-rel" key={index}>
                <div className="rhs-line3-srlp">
                  <div className="top-small-strip">
                    <div className="top-lhs-strip-bar"></div>
                    <div className="top-rhs-strip-bar"></div>
                  </div>
                  <div className="top-small-strip new-top-small-strip">
                    <div className="btm-lhs-strip-bar"></div>
                    <div className="btm-rhs-strip-bar"></div>
                  </div>
                  <div className="chart-line-lhs-adj"></div>
                  <div className="chart-line-rhs-adj"></div>
                </div>
                <div>
                </div>
                <div className="top-slide-section-srlp">

                </div>
                <div className="up-sec-srlp">
                  <div className="sub-first-column-srlp pull-left pos-rel">
                    <div className="block-sec-srlp">
                      <ul>
                        {this.props.readingLevels.map((readingLevel, index) => {
                          if (
                            item.recordDataList['firstRecord'][readingLevel]
                          ) {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel,
                                  this.props.selectedLevels,
                                  {
                                    type: 'firstRecord',
                                    grade: item.grade,
                                    orrAssignmentId:
                                      item.recordDataList['firstRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  }
                                )}
                                onClick={() => {
                                  this.props.selectedClassLevels({
                                    type: 'firstRecord',
                                    rl: readingLevel,
                                    grade: item.grade,
                                    orrAssignmentId:
                                      item.recordDataList['firstRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  });
                                }}
                                className="cursor-pointer"
                              >
                                <span>
                                  {item.recordDataList['firstRecord'][
                                    readingLevel
                                  ]['percentage'] + '%'}
                                </span>
                              </li>
                            );
                          } else {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel
                                )}
                              >
                                <span />
                              </li>
                            );
                          }
                        })}
                      </ul>
                    </div>
                    <div className="wcpm-section-srlp c1-srlp">
                      <p>First</p>
                    </div>
                  </div>
                  <div className="sub-second-column-srlp pull-left pos-rel">
                    <div className="block-sec-2nd-srlp">
                      <ul>
                        {this.props.readingLevels.map((readingLevel, index) => {
                          if (
                            item.recordDataList['recentRecord'][readingLevel]
                          ) {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel,
                                  this.props.selectedLevels,

                                  {
                                    type: 'recentRecord',
                                    grade: item.grade,
                                    orrAssignmentId:
                                      item.recordDataList['recentRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  }
                                )}
                                onClick={() => {
                                  this.props.selectedClassLevels({
                                    type: 'recentRecord',
                                    grade: item.grade,
                                    orrAssignmentId:
                                      item.recordDataList['recentRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  });
                                }}
                                className="cursor-pointer"
                              >
                                <span>
                                  {item.recordDataList['recentRecord'][
                                    readingLevel
                                  ]['percentage'] + '%'}
                                </span>
                              </li>
                            );
                          } else {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel
                                )}
                              >
                                <span />
                              </li>
                            );
                          }
                        })}
                      </ul>
                    </div>
                    <div className="wcpm-section-srlp c2-srlp">
                      <p>Recent</p>
                    </div>
                  </div>
                </div>
                <div
                  className="month-section-srlp cursor-pointer ipad-hover"
                  onClick={() => {
                    this.props.getClassLevelRLPData({
                      schoolGrade: item.grade
                    });
                  }}
                >
                  <span>{constructElipsisGradeText(item.grade)}</span>
                  {this.showToolTip('Click here for Grade Level Report')}
                </div>
              </div>
            );
          })}

          <div className="last-col-wrap-srlp">
            <div className="last-col-srlp">
              <div className="last-bord">
                <div className="last-line-lhs-adj"></div>
                <div className="last-line-rhs-adj"></div>
                <div className="last-line-top-rhs-adj"></div>
              </div>
              <p>Reading Level Progress</p>
            </div>
            <div className="btm-arrow-lft-srlp">
              <div
                className="btm-ic-rhs-last-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('right');
                }}
              >
                {this.props.scrollIndex <
                  this.props.totalGradeItems.length - this.props.viewSpecificScroll ? <img src={rightScrollActive} className="cursor-pointer" /> : <img src={rightScroll} />
                }

              </div>
              <div
                className="btm-ic-rhs-prev-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('extremeRight');
                }}
              >
                {this.props.scrollIndex <
                  this.props.totalGradeItems.length - this.props.viewSpecificScroll ? <img src={rightExtremeScrollActive} className="cursor-pointer" /> : <img src={rightExtremeScroll} />
                }
              </div>
            </div>
          </div>

          <div style={{ clear: 'both' }} />
        </div>
      );
    } else if (this.props.currentChartInDisplay == 'CLRLP') {
      return (
        <div
          className={this.props.gradesData.length == 1 ? "graph-content pull-left pos-rel single-month-chart single-month-chart2" : this.props.gradesData.length == 2 ? "graph-content pull-left pos-rel dual-month-chart2" : "graph-content pull-left pos-rel chart-2"}
          style={{ border: 'none', left: '2px' }}
        >
          <div
            className="back-btn cursor-pointer"
            onClick={this.props.backToMainChart}
          >
            {this.props.scrollFlag ? "" : <React.Fragment> <img width="18px" src={backArrow} />
              <span>Back to All Grades</span></React.Fragment>}
          </div>
          <Compare_Chart_Data
            summaryFlag={this.props.summaryFlag}
            updateChartDetails={(data) => this.props.updateChartDetails(data)}
            monthRangeObj={this.props.monthRangeObj}
            selAll={this.props.selAll}
            toggleData={this.props.toggleData}
            updateDetails={(data) => this.props.updateDropDownDetails(data)}
            updateAllMonth={(data) => this.props.updateAllMonth(data)}
            toggleDropDown={(data) => this.props.toggleDropDown(data)}
          />
          {this.props.gradesData.map((item, columnIndex) => {
            return (
              <div className="first-coloumn-srlp pull-left pos-rel" key={columnIndex}>
                <div className="rhs-line3-srlp">
                  <div className="top-small-strip">
                    <div className="top-lhs-strip-bar"></div>
                    <div className="top-rhs-strip-bar"></div>
                  </div>
                  <div className="top-small-strip new-top-small-strip">
                    <div className="btm-lhs-strip-bar"></div>
                    <div className="btm-rhs-strip-bar"></div>
                  </div>
                  <div className="chart-line-lhs-adj"></div>
                  <div className="chart-line-rhs-adj"></div>
                </div>
                <div className="top-slide-section-srlp">

                </div>
                <div className="up-sec-srlp">
                  <div className="sub-first-column-srlp pull-left pos-rel">
                    <div className="block-sec-srlp">
                      <ul>
                        {this.props.readingLevels.map((readingLevel, index) => {
                          if (
                            item.recordDataList['firstRecord'][readingLevel]
                          ) {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel,
                                  this.props.selectedLevels,
                                  {
                                    type: 'firstRecord',
                                    className: item.className,
                                    classId: item.classId,
                                    orrAssignmentId:
                                      item.recordDataList['firstRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  }
                                )}
                                onClick={() => {
                                  this.props.selectedClassLevels({
                                    type: 'firstRecord',
                                    rl: readingLevel,
                                    className: item.className,
                                    classId: item.classId,
                                    orrAssignmentId:
                                      item.recordDataList['firstRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  });
                                }}
                                className="cursor-pointer"
                              >
                                <span>
                                  {item.recordDataList['firstRecord'][
                                    readingLevel
                                  ]['percentage'] + '%'}
                                </span>
                              </li>
                            );
                          } else {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel
                                )}
                              >
                                <span />
                              </li>
                            );
                          }
                        })}
                      </ul>
                    </div>
                    <div className="wcpm-section-srlp c1-srlp">
                      <p>First</p>
                    </div>
                  </div>
                  <div className="sub-second-column-srlp pull-left pos-rel">
                    <div className="block-sec-2nd-srlp">
                      <ul>
                        {this.props.readingLevels.map((readingLevel, index) => {
                          if (
                            item.recordDataList['recentRecord'][readingLevel]
                          ) {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel,
                                  this.props.selectedLevels,

                                  {
                                    type: 'recentRecord',
                                    className: item.className,
                                    classId: item.classId,
                                    orrAssignmentId:
                                      item.recordDataList['recentRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  }
                                )}
                                onClick={() => {
                                  this.props.selectedClassLevels({
                                    type: 'recentRecord',
                                    className: item.className,
                                    classId: item.classId,
                                    orrAssignmentId:
                                      item.recordDataList['recentRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  });
                                }}
                                className="cursor-pointer"
                              >
                                <span>
                                  {item.recordDataList['recentRecord'][
                                    readingLevel
                                  ]['percentage'] + '%'}
                                </span>
                              </li>
                            );
                          } else {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel
                                )}
                              >
                                <span />
                              </li>
                            );
                          }
                        })}
                      </ul>
                    </div>
                    <div className="wcpm-section-srlp c2-srlp">
                      <p>Recent</p>
                    </div>
                  </div>
                </div>
                <div
                  className="month-section-srlp cursor-pointer ipad-hover hide-desktop-view">
                  <span>{constructElipsisGradeText(item.className, this.props.gradesData.length)}</span>
                  {this.showToolTip(item.className)}
                </div>
                {/* for ipad */}
                <div className={this.state['currentIndex'] == columnIndex ? 'month-section-srlp-crlp  cursor-pointer ipad-view' : 'month-section-srlp cursor-pointer ipad-view'} onClick={() => { this.setIndexForTooltip(columnIndex) }}>
                  <span>{constructElipsisGradeText(item.className, this.props.gradesData.length)}</span>
                  {this.showToolTipForIpad(item.className)}
                </div>

              </div>
            );
          })}

          <div className="last-col-wrap-srlp">
            <div className="last-col-srlp">
              <div className="rhs-line4-scrlp">
                <div className="last-line-lhs-adj"></div>
                <div className="last-line-rhs-adj"></div>
                <div className="last-line-rhs-adj-sc-rlp"></div>
              </div>
              <p>Reading Level Progress</p>
            </div>
            <div className="btm-arrow-lft-srlp">
              <div
                className="btm-ic-rhs-last-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('right');
                }}
              >
                <img
                  src={
                    this.props.scrollIndex <
                      this.props.totalGradeItems.length - this.props.viewSpecificScroll
                      ? rightScrollActive
                      : rightScroll
                  }
                />
              </div>
              <div
                className="btm-ic-rhs-prev-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('extremeRight');
                }}
              >
                <img
                  src={
                    this.props.scrollIndex <
                      this.props.totalGradeItems.length - this.props.viewSpecificScroll
                      ? rightExtremeScrollActive
                      : rightExtremeScroll
                  }
                />
              </div>
            </div>
          </div>

          <div style={{ clear: 'both' }} />
        </div>
      );
    } else {
      return <div />;
    }
  }
}

export default SchoolRlpGrade;
