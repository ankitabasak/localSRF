import React, { Component } from 'react';
import { connect } from 'react-redux';

import LoadingScreen from '../../../Utils/LoadingScreen/LoadingScreen';
import { GetIds_of_Each_Object_In_The_Array, Get_Ids_Of_Student_List, GetStudentIdsFor_compareOfGrade } from '../../ReusableComponents/AllReusableFunctions';

import { Get_Cs_ComparisionTab_Data } from '../../../Redux_Actions/ComparisonActions';
import TestScore_ComparisonPage from '../../../Utils/Comparison/TestScore_ComparisonPage';
import { GetTestScore_CompareData } from '../../../services/compare.service';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class sc_ts_comparison extends Component {

    constructor(props) {
        super(props);
    }

    componentDidUpdate() {
        // this.CallApi();
        GetTestScore_CompareData(this.props,'school');

    }

    componentDidMount() {
        // this.CallApi();
        GetTestScore_CompareData(this.props,'school');   
        this.props.trackingUsage("assessmentreports_testscorescomparison:school");
    }

    // CallApi(props) {
       
    // }
    render() {

        let Ts_Comparison_props = this.props.schoolComparison.Ts_Comparison
        let Nav = this.props.NavigationByHeaderSelection;
        let fromNavContext = "school"
        return (

            <div className="bec_compare_tab_main">

                {Ts_Comparison_props.ApiCalls.loadingComparison_Data || Ts_Comparison_props.ComparisonData.Operational_Data.length == 0 ? <LoadingScreen /> : <TestScore_ComparisonPage fromContext={fromNavContext} fromtab="testscores" comparisonData={Ts_Comparison_props} />

                }
            </div>
        )
    }
}

const MapStateToProps = ({ Universal, Authentication, ComparisonReducer, Reports,LastActiveUniversalProps,DateTabReducer }) => {

    const { LoginDetails } = Authentication

    const { ContextHeader, NavigationByHeaderSelection, ApiCalls,currentTermID,UniversalSelecter } = Universal

    const { schoolComparison } = ComparisonReducer

    const { StandardPerformance_Overview } = Reports
    const { Context_DateTab } = DateTabReducer;
    return {
        Universal, LoginDetails, ContextHeader, schoolComparison, NavigationByHeaderSelection,
        StandardPerformance_Overview, ApiCalls, LastActiveUniversalProps,currentTermID,Context_DateTab,UniversalSelecter
    }
}

export default connect(MapStateToProps, {
    Get_Cs_ComparisionTab_Data,trackingUsage
})(sc_ts_comparison);