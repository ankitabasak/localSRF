import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    Comparison_Popup
} from '../../../Redux_Actions/ComparisonActions';

import Std_Perf_ComparisonPopup from "../../../Utils/Comparison/Std_Perf_ComparisonPopup";
import Std_Perf_ComparisonPage from "../../../Utils/Comparison/Std_Perf_ComparisonPage";
import Compare_Comp_Apis from '../../../Utils/Comparison/Compare_Comp_Apis';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class sc_sp_comparison extends Component {

    constructor(props) {
        super(props);
    }
    componentDidMount(){
        this.props.trackingUsage("assessmentreports_standardperformancecomparison:school");
    }
    render() {

        const schoolComparison = this.props.schoolComparison.Std_Comparison

        const popupFilter = schoolComparison.PopupFilter;
        let Nav = this.props.NavigationByHeaderSelection;
        let fromNavContext = "school";

        let TestApiOr_SchoolApi = this.props.ApiCalls.getTests ||
            this.props.ApiCalls.Get_Selected_School_Info ||
            this.props.ApiCalls.loadingFor == "tests" ||
            this.props.ApiCalls.loadingFor == "school";
        return (
            <div>
                <Compare_Comp_Apis
                    comparisonData={schoolComparison}
                    fromContext={fromNavContext}
                    fromtab="std_performance"
                    popupData={popupFilter}
                />
                {popupFilter.openPopup && !this.props.CompareDeepLink_Enabled && !TestApiOr_SchoolApi
                    // && (popupFilter.Strands_And_Standards.Original_List_temp.length != 0)
                    ? <Std_Perf_ComparisonPopup
                        comparisonData={schoolComparison}
                        fromContext={fromNavContext}
                        fromtab="std_performance"
                        popupData={popupFilter} /> : null}
                {schoolComparison.ComparisonData.Operational_Data != null ? <Std_Perf_ComparisonPage
                    fromContext={fromNavContext}
                    fromtab="std_performance"
                    comparisonData={schoolComparison}  /> : null}
            </div>
        )
    }
}

const MapStateToProps = ({ Universal, Authentication, ComparisonReducer, Reports }) => {

    const { ContextHeader, NavigationByHeaderSelection, ApiCalls } = Universal

    const { schoolComparison, CompareDeepLink_Enabled, Orig_Ass_Count_Success } = ComparisonReducer

    const { StandardPerformance_Overview } = Reports

    return {
        Universal, Authentication, ContextHeader, schoolComparison,
        NavigationByHeaderSelection, StandardPerformance_Overview,
        CompareDeepLink_Enabled, Orig_Ass_Count_Success, ApiCalls
    }
}

const MapActionToProps = {
    Comparison_Popup,
    trackingUsage
}

export default connect(MapStateToProps, MapActionToProps)(sc_sp_comparison);

// Custom functions to perform some actions

export function SelectedTestList(testsList) {

    let ComponentsList = [];
    testsList == undefined ? null : testsList.map((test, i) => {
        // if (test.productId == SelectedProductID) {
        ComponentsList.push(test.componentCode);
        //}
    })
    return ComponentsList;
}