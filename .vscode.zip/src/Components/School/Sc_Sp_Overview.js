
import React, { Component } from 'react';
import '../../../public/css/style.css';
import info_icon from '../../../public/images/info_icon.svg';
import { connect } from "react-redux";
import Strands_Assessment from '../Standard_Performance/Strands_Assessment';
import Chart from '../../Utils/LineChart/LineChart';
import ChartPagination from '../../Utils/LineChart/LineChartPagination';
import OverviewDetailHeader from '../TestScore/OverView/OverviewDetail/OverviewDetailHeader';
import OverviewDetailStudentList from '../TestScore/OverView/OverviewDetail/OverviewDetailStudentList';
import Make_A_Selection_msg from '../../Utils/Make_A_Selection';
import {
    ChangeToggleIn_SP_Overview, OpenOrClose_P_OT_Info_Popup,
    EnableOrDisableLineColorIn_LC_For_STrands_LC,
    // getTestAssessmentMaxCountOfClass
} from '../../Redux_Actions/ReportsActions';
import {
    CompareCheckBoxOption_For_School_LC
} from '../../Redux_Actions/School_Report_Actions';
import CompareCheckBoxes from '../../Utils/CompareCheckBoxes';
import ReactHtmlParser from 'react-html-parser';
import { convertToNumberGrade, ParamsForStudentsListTable, LineChartInput_Params, GetIds_of_Each_Object_In_The_Array, Return_Taxonomy_Strand_Standards_list } from './../ReusableComponents/AllReusableFunctions';
import LoadingScreen from '../../Utils/LoadingScreen/LoadingScreen';
import PrintList from '../ReusableComponents/PDFReports/PrintList';
import PrintLineChart from '../ReusableComponents/PDFReports/PrintLineChart';

import {
    OpenOrCloseTooltipIn_SC_OT, getGradeListOfSchool, getTestAssessmentMaxCountOfSchool, Get_School_StandardPerformance_Details,
    GetClassDetailsOf_SelectedStrands, GetLineChartDetailsofSelected_Standards_OfSchool
} from '../../Redux_Actions/School_Report_Actions';
import { getexact_standard_avg_on_class_student_persist } from '../Common/MainFilter/MainFilter';
import IR_Bulb from '../../Utils/IR_Bulb';
import { Sp_OverView_Grades, Sp_Overview_School_Strands, school_RightSideViewApiCalls } from '../../services/school.service';
import { Disable_AutoSelect_Std_Pref_LeftView,ENABLE_SPOT_PDF_DOWNLOAD } from '../../Utils/globalVars';
import SpotPrint from '../../Utils/SpotPDF/SpotPrint';
import { trackingUsage } from '../../Redux_Actions/AuthenticationAction';
import { dispatch } from 'd3';

class sc_sp_overview extends Component {
    constructor(props) {
        super(props);
        this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
        this.P_OT_infoRef = {},
            this.Note_InfoRefs;
        this.InfoTooltipPopUp = {},
            this.i_span_tooltip_ref = {},
            this.SelectedCheckBoxOption = this.SelectedCheckBoxOption.bind(this);
        this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
        this.state = {
            OpenPerformanceOT: false,
            OpenStudentsList: true,
            show_P_Overtime_Info: false
        }
    }

    componentWillMount() {
        Sp_OverView_Grades(this.props);
        Sp_Overview_School_Strands(this.props)
        school_RightSideViewApiCalls(this.props);
    }
    componentDidUpdate() {
        Sp_OverView_Grades(this.props);
        Sp_Overview_School_Strands(this.props)
        school_RightSideViewApiCalls(this.props);
    }

    componentDidMount() {
        document.addEventListener("mousedown", this.handleClickOutside_info);        
        this.props.trackingUsage("assessmentreports_standardperformanceoverview:school");
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleClickOutside_info);
    }

    handleClickOutside_info(event) {
        if (event.target == null || event.target == undefined) {
            // this.handleMouseOut(this.props.ToolTipData);
        } else if (this.props.Sc_StandardPerformance_Overview.openInfoPopUp_in_P_OT_header) {
            if (this.Note_InfoRefs !== null && this.Note_InfoRefs !== undefined) {
                let isitemexists = this.Note_InfoRefs.contains(event.target);
                let ToolTipsRefsExists;
                if (isitemexists == undefined || isitemexists == null || isitemexists == false) {
                    // this.setState({ show_P_Overtime_Info: false })
                    let Nav = this.props.NavigationByHeaderSelection;
                    this.props.OpenOrClose_P_OT_Info_Popup(false, Nav)
                }
            }
        } else if (this.props.Sc_StandardPerformance_Overview.openInfoTooltip_in_P_OT_header) {
            if (this.InfoTooltipPopUp !== null && this.InfoTooltipPopUp !== undefined) {
                let isitemexists = this.InfoTooltipPopUp.contains(event.target);
                let is_IExist = this.i_span_tooltip_ref.contains(event.target)
                if ((isitemexists == undefined || isitemexists == null || isitemexists == false) && (is_IExist == undefined || is_IExist == null || is_IExist == false)) {
                    this.props.OpenOrCloseTooltipIn_SC_OT(false, "S_performance")
                }
            }
        }

    }
    /**
     * 
     * @param {String} selectedfiield 
     * @param {boolean} check 
     */
    SelectedCheckBoxOption(selectedfiield, check) {

        let IN_TS_Overview = false;

        this.props.CompareCheckBoxOption_For_School_LC(selectedfiield, check, IN_TS_Overview);
    }

    /**
 * when user click on checbox comp label, then it will execute
 */
    ClickOnLabelName(labelName, checkOrUncheck) {
        this.props.EnableOrDisableLineColorIn_LC_For_STrands_LC(labelName, checkOrUncheck);
    }

    /**
     * 
     * @param {string} ActiveToggle -- selected toggle name. 
     * @returns {JSX Element/null}
     */
    PerformanceOTchart(ActiveToggle, ApiCallReports) {
        let GraphPagination = this.props.Sc_StandardPerformance_Overview.LineChart_Pagination;
        let PerformanceFilter = this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter;
        let selectedTestAssessment;
        let selectedTestGrade;
        selectedTestAssessment = PerformanceFilter.TestAssessment.selectedTestAssessment;
        selectedTestGrade = PerformanceFilter.TestGrade.selectedTestgrade;

        let Nav = this.props.NavigationByHeaderSelection;
        if (ActiveToggle == 'linechart') {
            let ActualListForGraph = JSON.parse(JSON.stringify(this.props.Sc_StandardPerformance_Overview.ActualLineChartData));
            let Pagination_Start = GraphPagination.Chart_Page_Count_Start;
            let Pagination_End = GraphPagination.Chart_Page_Count_End;
            let ToolTipData = this.props.Sc_StandardPerformance_Overview.Strands_ToolTipData;
            let StrandReducer = this.props.Sc_StandardPerformance_Overview;
            let TotalQuestions = ActualListForGraph.reduce((initial, item) => initial + parseInt(item.totalQuestions), 0);
            let Standard_performance_details = this.props.Sc_StandardPerformance_Overview;
            let LastChecked_CB = Standard_performance_details.lastSelectedCheckBox
            const { XAxis_Params, YAxis_Params, DatatPointParams, tooltipParams, data,
                margin, width, height, Ipadwidth, Ipadheight
            } = LineChartInput_Params(ActualListForGraph, Pagination_Start, Pagination_End, 'c_sp_overview')
            let ClassChecked = false; // for class instance we no need this so by default we are sending false.
            let SchoolChecked = Standard_performance_details.checkSchool;
            let DistrictChecked = Standard_performance_details.checkDistrict;


            //IR related stuff
            const { selectedstandardObject, StrandNameOfSelectedStandard } = this.props.Sc_StandardPerformance_Overview ? this.props.Sc_StandardPerformance_Overview : "";
            const setId = (selectedstandardObject !== null) ? selectedstandardObject.setId : "";
            let strandNames = (StrandNameOfSelectedStandard !== null) && StrandNameOfSelectedStandard !== "" ? (setId + "~" + StrandNameOfSelectedStandard) : "";
            let standardNames = (selectedstandardObject !== null) ? selectedstandardObject.standardId : "";
            let Grade = selectedTestGrade ? convertToNumberGrade(selectedTestGrade.grade) : "";
            let loaderStatus = false
            if (ApiCallReports.loading_on_strands_Lc) {
                loaderStatus = true
            } else {
                loaderStatus = false
            }

            let U_Apis = this.props.ApiCalls;
            let Loader = this.props.Sc_ApiCalls.loading_Strands_table ||
                ApiCallReports.loading_on_strands_Lc || U_Apis.loadingFor == "tests" ||
                (U_Apis.loadingFor == "school" && this.props.UniversalFilter == "")

            let need_To_Select_Strad_Or_Standard = strandNames == "" &&
                !(ApiCallReports.Get_OnlyGraphOnCompareInStrandsComp) && !(ApiCallReports.loading_on_strands_Lc)
                && Disable_AutoSelect_Std_Pref_LeftView


            return < div className="widget-base-block mx-auto" >
                {Loader ?
                    <LoadingScreen /> : need_To_Select_Strad_Or_Standard ?
                        <Make_A_Selection_msg
                            message="Make a selection in the table to see details." />
                        : <div className="widget-base-block-inr">
                            <div className="widget-base-title-block">
                                <div className="float-left widget-base-block-title text-center">
                                    <span className="print_pdf_icon">
                                    {ENABLE_SPOT_PDF_DOWNLOAD?<SpotPrint />:<PrintLineChart
                                            data={data} XAxis_Params={XAxis_Params}
                                            Pagination={GraphPagination}
                                            selectedTestAssessment={selectedTestAssessment}
                                            selectedTestGrade={selectedTestGrade}
                                            YAxis_Params={YAxis_Params}
                                            DataSetParam={DatatPointParams}
                                            // TooltipParams={tooltipParams}
                                            TooltipParams={tooltipParams}
                                            ToolTipData={ToolTipData}
                                            ClassChecked={ClassChecked}
                                            SchoolChecked={SchoolChecked}
                                            DistrictChecked={DistrictChecked}
                                            LastChecked_CB={LastChecked_CB}
                                            Navselection={this.props.NavigationByHeaderSelection.class}
                                            TS_Overtime={Standard_performance_details}
                                            CheckeThis={this.SelectedCheckBoxOption}
                                            ClickOnLabel={this.ClickOnLabelName}
                                            standardName={StrandReducer.StrandNameOfSelectedStandard}
                                            strandName={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDef}
                                            strandDetailsDesc={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardName}
                                            strandDescription={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDesc}
                                            totalAverageScore={StrandReducer.selectedStandarAvg}
                                            totalQuestions={TotalQuestions} />}
                                    </span>
                                    <span>{StrandReducer.StrandNameOfSelectedStandard}</span>
                                </div>

                                {StrandReducer.selectedstandardObject == null ? null :
                                    StrandReducer.selectedstandardObject.standardName == undefined ? null :
                                        <div className="float-left widget-base-block-title text-center">
                                            <span style={{ float: "left", textAlign: "left", width: "93%" }}>{StrandReducer.selectedstandardObject.standardName}: {ReactHtmlParser(StrandReducer.selectedstandardObject.standardDesc)}</span>
                                            <span style={{ float: "left", width: "6%", position: "relative", left: "6px" }}><IR_Bulb ir_bulb_icon={this.props.LoginDetails.ReportingAccessParam} display_position="left" view={setId} grade={Grade} strand={strandNames} standard={standardNames} /></span>
                                        </div>}

                                <div className="widget-base-sub-title text-center">
                                    <span>Average Score: {StrandReducer.selectedStandarAvg}% based on {TotalQuestions} questions</span>
                                    <span onClick={() => this.toggleORtoggleIconClick(true, Nav)}
                                        ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                                    >
                                        <span><img src={info_icon} style={{ cursor: "pointer", marginTop: "-3px", marginLeft: "4px" }} /></span>

                                    </span>

                                    {Standard_performance_details.openInfoPopUp_in_P_OT_header ?
                                        <div className="infoIconTooltipBlock">
                                            <div
                                                ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                                                className="infoIconTooltipBlockInr">
                                                <span className="infoIconTooltipBlockArrow"></span>
                                                <b>Note:</b> Average Score for all standards reports equals (earned points/total points)*100
                                                </div>
                                        </div>
                                        : null}
                                </div>
                            </div>
                            <CompareCheckBoxes
                                Navselection={this.props.NavigationByHeaderSelection.class}
                                TS_Overtime={Standard_performance_details}
                                CheckeThis={this.SelectedCheckBoxOption}
                                ClickOnLabel={this.ClickOnLabelName}
                                lastcheckedlabel={LastChecked_CB}
                                loaderStatus={loaderStatus} />
                            {PerformanceOTchartHeader(true, ActualListForGraph, GraphPagination, this.props.UserScreenWidth, ToolTipData, StrandReducer, 'c_sp_overview', ClassChecked, SchoolChecked, DistrictChecked, LastChecked_CB)}
                        </div>}
            </div>
        } else return null;
    }


    toggleORtoggleIconClick(booleanVal, Nav) {
        this.props.OpenOrClose_P_OT_Info_Popup(booleanVal, Nav)
    }
    /**
     * 
     * @param {string} ActiveToggle 
     * @param {Object} ApiCallReports 
     * @returns {JSX Element}
     * 
     * will return class list and header for that class list in the righr side view 
     */

    ClassListView(ActiveToggle, ApiCallReports) {

        if (ActiveToggle == 'classlist') {
            let StrandReducer = this.props.Sc_StandardPerformance_Overview;
            let StandardPerformanceFilter = StrandReducer.StandardPerformanceFilter;
            let selectedTestGrade;
            selectedTestGrade = StandardPerformanceFilter.TestGrade.selectedTestgrade;
            let selectedTestAssessment;
            selectedTestAssessment = StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
            let Test_Scores_Details = StrandReducer.SP_ActualStudentsList;
            let DataToDisplay = StrandReducer.SP_StudentsList;
            let GraphDataForSelectedStrand = this.props.Sc_StandardPerformance_Overview.ActualLineChartData;
            let Standard_performance_details = this.props.Sc_StandardPerformance_Overview;

            let TotalQuestions_At_StudentList = DataToDisplay.length > 0 ? DataToDisplay[0].questionCount : ''

            const { lessthan40Studentcount, l40width, l40to59Studentcount, l40to59width, l60to79Studentcount,
                l60to79width, l80Studentcount, g80width, totalStudentCount, totalAverageScore, testName,
                submittedStartDate, submittedEndDate, sortedValue, pdfl40to50width, pdfl40width, pdfl60to79width, pdfg80width } = ParamsForStudentsListTable(Test_Scores_Details,
                    StrandReducer.SortedArray_SP_StudentsList, this.props.NavigationByHeaderSelection, this.props.AchivementLevels)
            // Standard_performance_details = Standard_performance_details.strands;
            let HeaderDetails = this.props.ContextHeader;

            //IR related stuff

            const { selectedstandardObject, StrandNameOfSelectedStandard } = this.props.Sc_StandardPerformance_Overview ? this.props.Sc_StandardPerformance_Overview : "";
            const setId = (selectedstandardObject !== null) ? selectedstandardObject.setId : "";
            let strandNames = (StrandNameOfSelectedStandard !== null && StrandNameOfSelectedStandard !== '') ? (setId + "~" + StrandNameOfSelectedStandard) : "";
            let standardNames = (selectedstandardObject !== null) ? selectedstandardObject.standardId : "";
            let Grade = selectedTestGrade ? convertToNumberGrade(selectedTestGrade.grade) : "";
            //  let View = this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter?this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter.Taxonomy.selectedTaxonomy:"";
            //  const {SetValues} = this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter?this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter:"";
            //  let Grade = selectedTestGrade?selectedTestGrade.grade:"";
            //  let Set  = Object.values(SetValues)
            //  let SetId = (Set.length>0)?Set.map(setvalues => {
            //     if(setvalues.taxonomy === View){
            //         return setvalues.setId;
            //     }
            //     }):"";

            //  let IR_StrandList= [];
            //  let IR_StandardsList = [];
            //  SetId = (SetId.length>0)?SetId.filter(function( element ) {
            //     return element !== undefined;
            //  }):SetId
            // const { ActualList } = this.props.Sc_StandardPerformance_Overview;
            // let IR_SelectedStrandsList  = ActualList.strands?ActualList.strands:[];
            // if(IR_SelectedStrandsList.length>0){
            // IR_SelectedStrandsList.map(strand => {
            // IR_StrandList.push(strand.strandName)
            // strand.standards.map(standard => {
            // IR_StandardsList.push(standard.standardId)
            //     })
            // })}
            // IR_StrandList = (IR_StrandList.length>0)?IR_StrandList.map(function(e) {return SetId+"~" + e}):[];//to add taxonomy before stands name
            // let strandNames = (IR_StrandList.length>0)?IR_StrandList.join(",,"):"";
            // let standardNames = (IR_StandardsList.length>0)?IR_StandardsList.join(","):"";
            //IR related stuff ends

            let need_To_Select_Strad_Or_Standard = strandNames == "" &&
                !(ApiCallReports.get_classList_and_Graph_ofClassStrand) && !(ApiCallReports.loading_on_strands_stds)
                && Disable_AutoSelect_Std_Pref_LeftView


            return <div className="widget-base-block mx-auto">
                {ApiCallReports.loading_on_strands_stds ? <LoadingScreen /> : need_To_Select_Strad_Or_Standard ? <Make_A_Selection_msg
                    message="Make a selection in the table to see details."
                /> : <div className="widget-base-block-inr">
                        <div className="widget-base-title-block">
                            <div className="float-left widget-base-block-title text-center">
                                <span>{StrandReducer.StrandNameOfSelectedStandard}</span>
                                <span className="print_pdf_icon">
                                    <PrintList totalstudentlist={totalStudentCount} l40studentcount={lessthan40Studentcount} l40to59Studentcount={l40to59Studentcount}
                                        l60to79Studentcount={l60to79Studentcount} l80Studentcount={l80Studentcount}
                                        averageScore={this.props.Sc_StandardPerformance_Overview.selectedStandarAvg} questionCount={TotalQuestions_At_StudentList}
                                        standardName={StrandReducer.StrandNameOfSelectedStandard}
                                        strandName={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDef}
                                        strandDetailsDesc={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardName}
                                        strandDescription={StrandReducer.selectedstandardObject == null ? null : StrandReducer.selectedstandardObject.standardDesc}
                                        DataToDisplay={StrandReducer.SP_StudentsList == null ? null : StrandReducer.SP_StudentsList}
                                        HeaderDetails={HeaderDetails}
                                        pdfl40to50width={pdfl40to50width}
                                        pdfl40width={pdfl40width}
                                        pdfl60to79width={pdfl60to79width}
                                        pdfg80width={pdfg80width}
                                        selectedTestGrade={selectedTestGrade}
                                        selectedTestAssessment={selectedTestAssessment}
                                        Data={this.props.Sc_StandardPerformance_Overview}
                                        pagination={this.props.Sc_StandardPerformance_Overview.StdList_Pagination}
                                    />
                                </span>
                            </div>
                            {StrandReducer.selectedstandardObject == null ? null :
                                StrandReducer.selectedstandardObject.standardName == undefined ? null : <div className="float-left widget-base-block-title text-center">
                                    <span style={{ float: "left", textAlign: "left", width: "93%" }}>{StrandReducer.selectedstandardObject.standardName}: {ReactHtmlParser(StrandReducer.selectedstandardObject.standardDesc)}</span>
                                    <span style={{ float: "left", width: "6%", position: "relative", left: "6px" }}><IR_Bulb ir_bulb_icon={this.props.LoginDetails.ReportingAccessParam} display_position="left" view={setId} grade={Grade} strand={strandNames} standard={standardNames} /></span>

                                </div>}
                            <div className="widget-base-sub-title text-center">
                                <span>Average Score: {this.props.Sc_StandardPerformance_Overview.selectedStandarAvg}% based on {TotalQuestions_At_StudentList} questions</span>
                                {/*  */}
                                <span onClick={() => this.toggleORtoggleIconClick(true, this.props.NavigationByHeaderSelection)}
                                    ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                                >
                                    <span><img src={info_icon} style={{ cursor: "pointer", marginTop: "-3px", marginLeft: "4px" }} /></span>
                                </span>
                                {Standard_performance_details.openInfoPopUp_in_P_OT_header ?
                                    <div className="infoIconTooltipBlock">
                                        <div
                                            ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                                            className="infoIconTooltipBlockInr">
                                            <span className="infoIconTooltipBlockArrow"></span>
                                            <b>Note:</b> Average Score for all standards reports equals (earned points/total points)*100
                                                </div>
                                    </div>
                                    : null}
                            </div>
                        </div>

                        <OverviewDetailHeader
                            fromComp="sc_sp_overview"
                            Data={this.props.Sc_StandardPerformance_Overview}
                            ActualList={this.props.Sc_StandardPerformance_Overview.SP_ActualStudentsList}
                            l40={lessthan40Studentcount} l40width={l40width} g40tol59={l40to59Studentcount}
                            l40to59width={l40to59width} g60tol79={l60to79Studentcount} l60to79width={l60to79width}
                            g80={l80Studentcount} g80width={g80width}
                            studentTotalC={totalStudentCount}
                            averagescore={totalAverageScore}
                            testName={testName}
                            startDate={submittedStartDate}
                            endDate={submittedEndDate} />
                        <OverviewDetailStudentList
                            fromComp="sc_sp_overview"
                            totalstudentcount={totalStudentCount}
                            studentsdata={Test_Scores_Details}
                            sortedValue={sortedValue}
                            Data={this.props.Sc_StandardPerformance_Overview}
                            DataToDisplay={DataToDisplay}
                            pagination={this.props.Sc_StandardPerformance_Overview.StdList_Pagination}
                            sortedArrayData={this.props.Sc_StandardPerformance_Overview.SortedArray} />


                    </div>}
            </div>
        } else return null
    }

    /**
     *
* @param {Object} ref --ref of the element
* @param {String} from  --from toggle ex: student/linechart
* @param {String} ActiveToggle  -- present displaying view student/linechart.
        * before proceed to change  ActiveToggle, will check user click position , if user clicks on info icon then will open note
        */

    ClickOn_Toggles(ref, from, ActiveToggle) {

        let ChangeToggle_To = from == 'linechart' ? ActiveToggle == 'linechart' ? 'classlist' : 'linechart' :
            ActiveToggle == 'classlist' ? 'linechart' : 'classlist';
        if (this.Note_InfoRefs !== undefined) {
            let ClickOnIcon = this.Note_InfoRefs.contains(ref.target);
            let PopOpen = this.props.Sc_StandardPerformance_Overview.openInfoPopUp_in_P_OT_header;
            ClickOnIcon ? PopOpen ? null : this.props.OpenOrClose_P_OT_Info_Popup(true, this.props.NavigationByHeaderSelection) : this.props.ChangeToggleIn_SP_Overview(ChangeToggle_To, 'schoolreport')
        } else {
            this.props.ChangeToggleIn_SP_Overview(ChangeToggle_To, 'schoolreport');
        }
    }

    LineChart_Widget(Standard_performance_details, ActiveToggle, ApiCallReports, U_Apis, Loader) {
        return <div className={ActiveToggle == 'linechart' ? "standard-widget performance_overtime_block active-widget" : "standard-widget performance_overtime_block"}>
            <div onClick={(ref) => {
                this.ClickOn_Toggles(ref, 'linechart', ActiveToggle)
            }
            }
                className="sidewidget-header">
                <span className="sidewidget-header-icon"><i className="material-icons">show_chart </i></span>
                <span className="sidewidget-header-title">Performance Over Time</span>
                <span onClick={() => this.props.OpenOrCloseTooltipIn_SC_OT(true, "S_performance")}
                >
                    <span ref={(refs) => refs == null ? null : this.i_span_tooltip_ref = refs} ><img src={info_icon} style={{ cursor: "pointer", marginTop: "5px", marginLeft: "4px" }} /></span>
                    {Standard_performance_details.openInfoTooltip_in_P_OT_header ?
                        <div className="infoIconTooltipBlock_POT"
                        style={ ActiveToggle == 'linechart' ?{top: 72}: {}}
                        >
                            <div
                                ref={(InfoTooltipPopUp) => InfoTooltipPopUp !== null ? this.InfoTooltipPopUp = InfoTooltipPopUp : null}
                                className="infoIconTooltipBlockInr">
                                <span className="infoIconTooltipBlockArrow_POT"></span>
                                <b>Note:</b> The average score listed in the line graph below is calculated from all data available for each assessment based on the context selected. It does not assume the cohort of students remains the same across the assessments listed.
                    </div>
                        </div>
                        : null}
                </span>
            </div>

            {Loader ? null : this.PerformanceOTchart(ActiveToggle, ApiCallReports)}
        </div>

    }
    classList_Widget(Standard_performance_details, ActiveToggle, ApiCallReports, U_Apis, Loader) {
        return <div className={ActiveToggle == 'classlist' ? "standard-widget active-widget" : "standard-widget"}>
            <div onClick={(ref) => {
                this.ClickOn_Toggles(ref, 'classlist', ActiveToggle)
                // this.setState({ OpenStudentsList: true, OpenPerformanceOT: false })
            }
            }
                className="sidewidget-header">
                <span className="sidewidget-header-icon"><i className="material-icons">view_list</i></span>
                <span className="sidewidget-header-title">Class List</span>
            </div>
            {Loader ?
                <LoadingScreen /> : <div> {this.ClassListView(ActiveToggle, ApiCallReports)} </div>
            }
        </div>

    }


    returnTogglesBasedOnSelection() {

        let Standard_performance_details = this.props.Sc_StandardPerformance_Overview;
        let ActiveToggle = Standard_performance_details.ActiveToggelIn_SP_Overview;
        let ApiCallReports = this.props.Sc_ApiCalls;
        let U_Apis = this.props.ApiCalls;
        let Loader = ApiCallReports.loading_Strands_table || U_Apis.loadingFor == "tests" || (U_Apis.loadingFor == "school" && this.props.UniversalFilter == "")
        return ActiveToggle == 'linechart' ?
            <div className="col-sm-12 float-left m-0 p-0">
                {this.classList_Widget(Standard_performance_details, ActiveToggle, ApiCallReports, U_Apis, Loader)}
                {this.LineChart_Widget(Standard_performance_details, ActiveToggle, ApiCallReports, U_Apis, Loader)}
            </div>
            :
            <div className="col-sm-12 float-left m-0 p-0">
                {this.LineChart_Widget(Standard_performance_details, ActiveToggle, ApiCallReports, U_Apis, Loader)}
                {this.classList_Widget(Standard_performance_details, ActiveToggle, ApiCallReports, U_Apis, Loader)}
            </div >
    }
    render() {

        let Standard_performance_details = this.props.Sc_StandardPerformance_Overview;
        let ActiveToggle = Standard_performance_details.ActiveToggelIn_SP_Overview;
        let ApiCallReports = this.props.Sc_ApiCalls;
        let U_Apis = this.props.ApiCalls;

        // let ActiveToggle = Standard_performance_details.ActiveToggelIn_SP_Overview
        return (
            <div className="main-middle-block">
                {/* { ApiCallReports.loading_Strands_table == false ?  */}

                <div className="main-middle-block-inr">
                    <div className="bec-standards-overview-left">
                        {/* {U_Apis.loadingFor == 'datetab' || U_Apis.loadingFor == "tests" ?
                            <LoadingScreen /> : */}
                        <Strands_Assessment stranddetails={Standard_performance_details} Apicalls={ApiCallReports} U_Apis={U_Apis}
                        />
                        {/* } */}
                    </div>

                    <div className="bec-standards-overview-right">
                        {this.returnTogglesBasedOnSelection()}
                    </div>
                    {/* right block end */}

                </div>
                {/* : <LoadingScreen/> } */}
            </div >
        );
    }
}

const mapStateToProps = ({ StudentReports, Reports, Universal, Authentication, schoolReducer,DateTabReducer }) => {
    const { Class, ToolTipData } = Reports;
    const { } = StudentReports;
    const { LoginDetails } = Authentication;
    const { AchivementLevels, ContextHeader, ApiCalls, UniversalSelecter, NavigationByHeaderSelection,
        UniversalFilter,currentTermID,isPastDistrictTerm } = Universal

    const { Sc_StandardPerformance_Overview, Sc_ApiCalls } = schoolReducer;
    const { Context_DateTab } = DateTabReducer;
    return {
        Class, LoginDetails, AchivementLevels, ContextHeader, ApiCalls, ToolTipData, Sc_ApiCalls,
        UniversalSelecter,
        NavigationByHeaderSelection,
        Sc_StandardPerformance_Overview, UniversalFilter,currentTermID,Context_DateTab,isPastDistrictTerm
    };
}

export default connect(mapStateToProps,{

    ChangeToggleIn_SP_Overview, OpenOrClose_P_OT_Info_Popup, OpenOrCloseTooltipIn_SC_OT,
    CompareCheckBoxOption_For_School_LC,
    EnableOrDisableLineColorIn_LC_For_STrands_LC,

    // getTestAssessmentMaxCountOfClass,
    getTestAssessmentMaxCountOfSchool,
    Get_School_StandardPerformance_Details,
    GetClassDetailsOf_SelectedStrands,
    GetLineChartDetailsofSelected_Standards_OfSchool,
    getGradeListOfSchool,
    trackingUsage,

})(sc_sp_overview);
/**
 * 
 * @param {Boolean} isActive 
 * @param {Array} ActualArrayList 
 * @param {Object} Pagination 
 * @param {Int16Array} UserScreenWidth 
 * @param {Object} ToolTipData 
 * @param {Object} StrandReducer 
 * @param {String} FromComponent 
 * @param {Boolean} SchoolChecked 
 * @param {Boolean} DistrictChecked 
 */
export const PerformanceOTchartHeader = (isActive, ActualArrayList, Pagination, UserScreenWidth, ToolTipData, StrandReducer, FromComponent, ClassChecked, SchoolChecked, DistrictChecked, LastChecked_CB) => {

    let Array = JSON.parse(JSON.stringify(ActualArrayList));
    let Pagination_Start = Pagination.Chart_Page_Count_Start;
    let Pagination_End = Pagination.Chart_Page_Count_End;
    const { XAxis_Params, YAxis_Params, DatatPointParams, tooltipParams, data,
        margin, width, height, Ipadwidth, Ipadheight
    } = LineChartInput_Params(Array, Pagination_Start, Pagination_End, FromComponent)

    // let TotalQuestions = ToolTipData.tooltipData == null ? "" : ToolTipData.tooltipData.totalQuestions

    return <div style={{ width: '100%', float: 'left' }}>
        <Chart margin={margin}
            width={UserScreenWidth < 1230 ? Ipadwidth : width}
            height={UserScreenWidth < 1230 ? Ipadheight : height}
            data={data} XAxis_Params={XAxis_Params}
            YAxis_Params={YAxis_Params}
            DataSetParam={DatatPointParams}
            // TooltipParams={tooltipParams}
            TooltipParams={tooltipParams}
            ToolTipData={ToolTipData}
            ClassChecked={ClassChecked}
            SchoolChecked={SchoolChecked}
            DistrictChecked={DistrictChecked}
            LastChecked_CB={LastChecked_CB}
        // data2={data2} data3={data3}
        />
        <div style={{ 'marginLeft': '70px' }} > {Pagination.Chart_TotalBubbles > 1 ? <ChartPagination
            pagination={Pagination} /> : null}
            <div className="Test_names_label" style={{ float: 'left', paddingTop: 15 }}>Test Names</div>
        </div>
    </div>

}