import React, { Component } from "react";

import Chart from "../../Utils/LineChart/LineChart";
import ChartPagination from "../../Utils/LineChart/LineChartPagination";
import OverviewDetailHeader from "../TestScore/OverView/OverviewDetail/OverviewDetailHeader";
import OverviewDetailStudentList from "../TestScore/OverView/OverviewDetail/OverviewDetailStudentList";
import {
  OpenOrCloseNoteIn_TS_OT,
  CheckCompareTabs,
  EnableOrDisableLineColorIn_LC,
} from "../../Redux_Actions/ReportsActions";
import {
  ParamsForStudentsListTable,
  LineChartInput_Params,
  GetIds_of_Each_Object_In_The_Array,
  GetStudentIdsFor_compare,
  Get_Ids_Of_Student_List,
  convertUTCDateToLocalDate,
} from "./../ReusableComponents/AllReusableFunctions";
import CompareCheckBoxes from "../../Utils/CompareCheckBoxes";
import { connect } from "react-redux";
import "../class/ClassMain.css";
import LoadingScreen from "../../Utils/LoadingScreen/LoadingScreen";
import TestScoreDetailListPDF from "../../Utils/PrintPDF/TestScoreDetailListPDF";
import info_icon from "../../../public/images/info_icon.svg";
import {
  OpenOrCloseTooltipIn_SC_OT,
  Get_school_TestScores_Graph,
  Get_Selected_TS_Details,
  CompareCheckBoxOption_For_School_LC,
} from "../../Redux_Actions/School_Report_Actions";
import TestScoreOverTimePDF from "../../Utils/PrintPDF/TestScoreOverTimePDF";
import {
  ACHIEVEMENT_LEVELS_ENABLE,
  Disable_AutoSelect_TS_Overview_LeftView,
  DISPLAY_LOCAL_TIME_IN_UI,
} from "../../Utils/globalVars";
import Make_A_Selection_msg from "../../Utils/Make_A_Selection";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";
import { EnddateValues, StartdateValues } from "../../Utils/reUsableSnipets";

class sc_ts_overview extends Component {
  constructor(props) {
    super(props);
    (this.InfoPopUp = {}),
      (this.i_span_ref = {}),
      (this.InfoTooltipPopUp = {}),
      (this.i_span_tooltip_ref = {}),
      (this.state = {
        studentsData: [],
      });
    this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
    this.SelectCompareOption = this.SelectCompareOption.bind(this);
    this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
  }

  /**
   * Enable this when we need to show Info Icon At Test Scores Over Time.
   */
  componentDidMount() {
    this.Apicalls(this.props.ApiCalls.get_school_TS_Graph);
    this.GetSelected_Test_Class_List();
    document.addEventListener("mousedown", this.handleClickOutside_info);
    this.props.trackingUsage("assessmentreports_testscoresoverview:school");
  }

  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside_info);
  }

  /**
   *
   * @param {Object} event
   * triggers when click on outside of info div At Test Scores Over Time Info Icon.
   */

  handleClickOutside_info(event) {
    if (event.target == null || event.target == undefined) {
      // this.handleMouseOut(this.props.ToolTipData);
    } else if (this.props.Sc_Test_Scores_OverTime.OpenInfoNote) {
      if (
        this.InfoTooltipPopUp !== null &&
        this.InfoTooltipPopUp !== undefined
      ) {
        let isitemexists = this.InfoTooltipPopUp.contains(event.target);
        let is_IExist = this.i_span_tooltip_ref.contains(event.target);
        if (
          (isitemexists == undefined ||
            isitemexists == null ||
            isitemexists == false) &&
          (is_IExist == undefined || is_IExist == null || is_IExist == false)
        ) {
          // this.setState({ show_P_Overtime_Info: false })
          this.props.OpenOrCloseTooltipIn_SC_OT(false, "T_Scores");
        }
      }
    }
  }

  /**
   *
   * @param {String} SelectedOption
   * this will trigger when  option is selected from CompareCheckBoxes.js component.
   */
  SelectCompareOption(SelectedOption, Check) {
    let SchoolData = this.props.Sc_Test_Scores_OverTime.Actual_School_LC_List;
    let SchoolDataChecked = this.props.Sc_Test_Scores_OverTime.checkSchool;
    let DistrictData =
      this.props.Sc_Test_Scores_OverTime.Actual_District_LC_List;
    let DistrictDataChecked = this.props.Sc_Test_Scores_OverTime.checkDistrict;

    let IN_TS_Overview = true;
    this.props.CompareCheckBoxOption_For_School_LC(
      SelectedOption,
      Check,
      IN_TS_Overview
    );
    // if (SelectedOption == 'School') {
    // SchoolData.length > 1 ? this.props.CheckCompareTabs('School',Check) : this.Apicalls(true,true,false);
    // this.props.CheckCompareTabs(SelectedOption, Check);
    //   // this.props.CheckCompareTabs('School', Check);
    //    } else if (SelectedOption == 'District') {
    //   let DistrictData = this.props.Test_Scores_OverTime.Actual_District_LC_List;
    //   // this.props.CheckCompareTabs('District', Check);
    //   DistrictData.length > 1 ? this.props.CheckCompareTabs('District', Check) : this.Apicalls(true,false,true);
    //   this.props.CheckCompareTabs('District', Check)
    //  }
  }

  /**
   * when user click on checbox comp label, then it will execute
   */
  ClickOnLabelName(labelName, checkOrUncheck) {
    this.props.EnableOrDisableLineColorIn_LC(labelName, checkOrUncheck);
  }

  /**
   *
   * @param {Boolean} shoulddoApiCall
   * @paaram {Boolean} isSchool ,
   * @param {Boolean} isDistrict
   * if param is true then will make api call to
   */
  Apicalls(shoulddoApiCall, isSchool, isDistrict) {
    let TestApiOr_SchoolApi =
      this.props.ApiCalls.getTests ||
      this.props.ApiCalls.Get_Selected_School_Info ||
      this.props.ApiCalls.loadingFor == "tests" ||
      this.props.ApiCalls.loadingFor == "school";

    if (shoulddoApiCall && !TestApiOr_SchoolApi) {
      let AccessToken = this.props.LoginDetails.JWTToken;
      let Context_Header = this.props.ContextHeader;
      // let U_Selector = this.props.UniversalSelecter.TestTab;
      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTests = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );
      if (SelectedTests == undefined || SelectedTests.length == 0) {
        Selected_List = this.props.UniversalSelecter.TestTab.TestList.filter(item => item.check)
        SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
      }
      // let ActualStudents = Context_Header.StudentList_Actual
      // let SelectedStudents = Context_Header.Roster_Tab.;
      // let ClassStrandsObject = this.props.StandardPerformance_Overview
      let ClassList = Context_Header.Roster_Tab.ClassIds;
      let currentTermId = this.props.currentTermID;

      const { UniversalSelecter,Context_DateTab } = this.props;
      let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
      let districtId = Context_Header.DistrictId;
      let startDate = Context_Header.Date_Tab.Report_termStartDate;
      let endDate = Context_Header.Date_Tab.Report_termEndDate;
      let rosterGrade = Context_Header.Roster_Tab.selectedRosterGrade;
      
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(Context_DateTab);
      }
      if (districtId == undefined) {
        districtId = Context_Header.Default_districtID;
      }
      if (rosterGrade == undefined) {
        rosterGrade = Context_Header.Roster_Tab.GradesList[0].grade;
      }
      if (ClassList == undefined) {
        ClassList = UniversalSelecter.Roster_Data.ClassIds;
      }
      

      let ReqPayload = {
        studentIds: Context_Header.Roster_Tab.StudentIds,
        classIds: ClassList,
        schoolId: schoolId,
        componentCodeList: SelectedTests,
        districtId: districtId,
        startDate: startDate,
        endDate: endDate,
        grade: Context_Header.Roster_Tab.selectedRosterGrade,
        rosterGrade: rosterGrade,
        // "isClass": true,
        // "isSchool": true,
        isDistrict: true,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
        isCustomAchievements: ACHIEVEMENT_LEVELS_ENABLE,
        termId: Context_Header.Date_Tab.selectedTermId,
      };
      let Enableload = true;
      if (
        ReqPayload.classIds.length !== 0 &&
        ReqPayload.schoolId !== null &&
        ReqPayload.schoolId !== undefined &&
        ReqPayload.schoolId !== "" &&
        ReqPayload.studentIds.length !== 0
      ) {
        this.props.Get_school_TestScores_Graph(
          AccessToken,
          ReqPayload,
          Enableload
        );
      }
    }
  }
  componentDidUpdate() {
    this.Apicalls(this.props.ApiCalls.get_school_TS_Graph);
    this.GetSelected_Test_Class_List();
  }

  GetSelected_Test_Class_List() {
    let SC_API_ = this.props.Sc_ApiCalls;
    if (SC_API_.get_TS_Details) {
      let AccessToken = this.props.LoginDetails.JWTToken;
      let Context_Header = this.props.ContextHeader;
      // let U_Selector = this.props.UniversalSelecter.TestTab;
      // let Selected_List = Context_Header.Tests_of_PresentSchool.filter(item => item.check)
      // let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
      // let ActualStudents = Context_Header.StudentList_Actual
      // let SelectedStudents = Context_Header.SelectedMultipleStudents;
      // let ClassStrandsObject = this.props.StandardPerformance_Overview
      let ClassList = Context_Header.Roster_Tab.ClassIds;
      let test = this.props.Sc_Test_Scores_OverTime.SelectedTestData;

      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      let Compare_Std_Ids =
        SchoolStds == undefined || SchoolStds == null
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));

      if (Compare_Std_Ids.length == 0) {
        let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }
      let currentTermId = this.props.currentTermID;

      
      let startDate = Context_Header.Date_Tab.Report_termStartDate;
      let endDate = Context_Header.Date_Tab.Report_termEndDate;
      let districtId = Context_Header.DistrictId;
      let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
      const { UniversalSelecter,Context_DateTab } = this.props;
	
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(Context_DateTab);
      }
      if (districtId == undefined) {
        districtId = Context_Header.Default_districtID;
      }
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      if (ClassList == undefined || ClassList == "") {
        ClassList = UniversalSelecter.Roster_Data.ClassIds;
        }
      let reqPayload = {
        schoolId: schoolId,
        studentIds: Context_Header.Roster_Tab.StudentIds,
        districtId: districtId,
        classIds: ClassList,
        componentCode: test.componentCode, //mandatory
        isDistrict: "true",
        termId: Context_Header.Date_Tab.selectedTermId,
        startDate: startDate,
        endDate: endDate,
        compareStudentIds: Compare_Std_Ids,
        rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
        isCustomAchievements: ACHIEVEMENT_LEVELS_ENABLE,
        termId: Context_Header.Date_Tab.selectedTermId,
      };

      let enableLoading = true;
      if (
        reqPayload.classIds.length > 0 &&
        reqPayload.componentCode !== undefined
      ) {
        this.props.Get_Selected_TS_Details(
          AccessToken,
          reqPayload,
          test,
          enableLoading
        );
      }
    }
  }

  render() {
    let Test_Scores_Details = this.props.Sc_TS_Class_ListTable.ActualList;
    let GraphPagination =
      this.props.StandardPerformance_Overview.LineChart_Pagination;
    let PerformanceFilter =
      this.props.StandardPerformance_Overview.StandardPerformanceFilter;
    let selectedTestAssessment;
    let selectedTestGrade;
    selectedTestAssessment =
      PerformanceFilter.TestAssessment.selectedTestAssessment;
    selectedTestGrade =
      PerformanceFilter.TestGrade.selectedTestgrade == "" ||
      PerformanceFilter.TestGrade.selectedTestgrade == null
        ? ""
        : PerformanceFilter.TestGrade.selectedTestgrade.grade;
    let ActualListForGraph = JSON.parse(
      JSON.stringify(
        this.props.StandardPerformance_Overview.ActualLineChartData
      )
    );
    // let Pagination_Start = GraphPagination.Chart_Page_Count_Start;
    // let Pagination_End = GraphPagination.Chart_Page_Count_End;
    let ToolTipData =
      this.props.StandardPerformance_Overview.Strands_ToolTipData;
    let StrandReducer = this.props.StandardPerformance_Overview;
    let TotalQuestions = ActualListForGraph.reduce(
      (initial, item) => initial + parseInt(item.totalQuestions),
      0
    );
    let Standard_performance_details = this.props.StandardPerformance_Overview;
    let ClassChecked = false;
    //API modified changes
    if (Test_Scores_Details.studentTestScoreList != undefined) {
      Test_Scores_Details = Test_Scores_Details.studentTestScoreList;
    }

    let {
      lessthan40Studentcount,
      l40width,
      l40to59Studentcount,
      l40to59width,
      l60to79Studentcount,
      l60to79width,
      l80Studentcount,
      g80width,
      totalStudentCount,
      totalAverageScore,
      testName,
      submittedStartDate,
      submittedEndDate,
      sortedValue,
    } = ParamsForStudentsListTable(
      Test_Scores_Details.testScoreList,
      this.props.Sc_TS_Class_ListTable.SortedArray,
      this.props.NavigationByHeaderSelection,
      this.props.AchivementLevels
    );

    let Ts_Score_Redux_Props = this.props.Sc_Test_Scores_OverTime;
    let Array = JSON.parse(
      JSON.stringify(Ts_Score_Redux_Props.ActualLineChartList)
    );
    let Compare_School_List = [...Ts_Score_Redux_Props.Actual_School_LC_List];
    let Compare_District_List = [
      ...Ts_Score_Redux_Props.Actual_District_LC_List,
    ];
    let Pagination_Start =
      this.props.Sc_LineChart_Pagination.Chart_Page_Count_Start;
    let Pagination_End =
      this.props.Sc_LineChart_Pagination.Chart_Page_Count_End;
    let ApiClassReports = this.props.Sc_ApiCalls;
    const {
      XAxis_Params,
      YAxis_Params,
      DatatPointParams,
      tooltipParams,
      data,
      margin,
      width,
      height,
      Ipadwidth,
      Ipadheight,
      dataset_2,
      dataset_3,
    } = LineChartInput_Params(
      Array,
      Pagination_Start,
      Pagination_End,
      "c_ts_overview",
      Compare_School_List,
      Compare_District_List
    );
    let loaderStatus = false;

    if (
      ApiClassReports.loading_LC_students ||
      ApiClassReports.loading_on_TS_LC
    ) {
      loaderStatus = true;
    } else {
      loaderStatus = false;
    }
    testName = this.props.Sc_Test_Scores_OverTime.SelectedTestData.testName;

    const selectedTest_submitStart =
      DISPLAY_LOCAL_TIME_IN_UI === true
        ? this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitStart !==
          undefined
          ? convertUTCDateToLocalDate(
              this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitStart,
              this.props.Sc_Test_Scores_OverTime.SelectedTestData
                .submitStartTime
            )
          : this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitStart
        : this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitStart;
    const selectedTest_submitEnd =
      DISPLAY_LOCAL_TIME_IN_UI === true
        ? this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitEnd !==
          undefined
          ? convertUTCDateToLocalDate(
              this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitEnd,
              this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitEndTime
            )
          : this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitEnd
        : this.props.Sc_Test_Scores_OverTime.SelectedTestData.submitEnd;

    const Compare_School = [...dataset_2];
    const Compare_District = [...dataset_3];
    const SchoolChecked = Ts_Score_Redux_Props.checkSchool;
    const DistrictChecked = Ts_Score_Redux_Props.checkDistrict;
    const LastChecked_CB = Ts_Score_Redux_Props.lastSelectedCheckBox;
    const DataToDisplayForStudentsList =
      this.props.Sc_TS_Class_ListTable.List.testScoreList;

    let screenLoader =
      ApiClassReports.loading_on_TS_LC ||
      this.props.ApiCalls.loadingFor == "tests" ||
      (this.props.ApiCalls.loadingFor == "school" &&
        this.props.UniversalFilter == "");
    // All related to PDF
    let HeaderDetailsForPrint = this.props.ContextHeader;
    let TestDetailsForPrint = {
      testName,
      submittedStartDate,
      submittedEndDate,
    };
    let CompareOptionsForPrint = {
      TS_Overtime: this.props.Sc_Test_Scores_OverTime,
      LastChecked_CB: LastChecked_CB,
    };
    let MetaDataForPrint = {
      totalListCount: totalStudentCount,
      totalAverageScore: totalAverageScore,
      sortedValue: sortedValue,
      l40: lessthan40Studentcount,
      l40width: l40width,
      g40tol59: l40to59Studentcount,
      l40to59width: l40to59width,
      g60tol79: l60to79Studentcount,
      l60to79width: l60to79width,
      g80: l80Studentcount,
      g80width: g80width,
      Pagination_Start,
      Pagination_End,
    };
    // End of PDF Stuff

    let NoTestSelectedInGraph =
      (testName == undefined || testName == null) &&
      !ApiClassReports.get_TS_Details &&
      !ApiClassReports.loading_on_TS_LC &&
      Disable_AutoSelect_TS_Overview_LeftView;
    return (
      <div className="class_main">
        <div className="class_main_center">
          <div className="class_main_inr">
            <CompareCheckBoxes
              Navselection={this.props.NavigationByHeaderSelection.class}
              CheckeThis={this.SelectCompareOption}
              ClickOnLabel={this.ClickOnLabelName}
              TS_Overtime={this.props.Sc_Test_Scores_OverTime}
              lastcheckedlabel={LastChecked_CB}
              loaderStatus={loaderStatus}
            />
            <div className="class_left_block" style={{ position: "relative" }}>
              <div className="class_widget_title test_score_overtime overrightinfostyle">
                <span className="float-left">Test Scores over Time</span>
                <span
                  onClick={() =>
                    this.props.OpenOrCloseTooltipIn_SC_OT(true, "T_Scores")
                  }
                >
                  <span
                    ref={(refs) =>
                      refs == null ? null : (this.i_span_tooltip_ref = refs)
                    }
                  >
                    <img src={info_icon} style={{ cursor: "pointer" }} />
                  </span>
                  {Ts_Score_Redux_Props.OpenInfoNote ? (
                    <div className="infoIconTooltipBlock_TS">
                      <div
                        ref={(InfoTooltipPopUp) =>
                          InfoTooltipPopUp !== null
                            ? (this.InfoTooltipPopUp = InfoTooltipPopUp)
                            : null
                        }
                        className="infoIconTooltipBlockInr"
                      >
                        <span
                          className="infoIconTooltipBlockArrow_TS"
                          style={{ padding: "0px" }}
                        ></span>
                        <b>Note:</b> The average score listed in the line graph
                        below is calculated from all data available for each
                        assessment based on the context selected. It does not
                        assume the cohort of students remains the same across
                        the assessments listed.
                      </div>
                    </div>
                  ) : null}
                </span>
                {!screenLoader ? (
                  <span className="float-left" style={{ padding: "0px" }}>
                    <TestScoreOverTimePDF
                      data={data}
                      XAxis_Params={XAxis_Params}
                      Pagination={GraphPagination}
                      selectedTestAssessment={selectedTestAssessment}
                      selectedTestGrade={selectedTestGrade}
                      YAxis_Params={YAxis_Params}
                      DataSetParam={DatatPointParams}
                      TooltipParams={tooltipParams}
                      ToolTipData={this.props.Sc_ToolTipData}
                      ClassChecked={ClassChecked}
                      SchoolChecked={SchoolChecked}
                      DistrictChecked={DistrictChecked}
                      LastChecked_CB={LastChecked_CB}
                      Navselection={
                        this.props.NavigationByHeaderSelection.class
                      } //this.props.nav
                      TS_Overtime={this.props.Sc_Test_Scores_OverTime}
                      CheckeThis={this.SelectCompareOption}
                      ClickOnLabel={this.ClickOnLabelName}
                      totalAverageScore={StrandReducer.selectedStandarAvg}
                      totalQuestions={TotalQuestions}
                      standardName={StrandReducer.StrandNameOfSelectedStandard}
                      strandName={
                        StrandReducer.selectedstandardObject == null
                          ? null
                          : StrandReducer.selectedstandardObject.standardDef
                      }
                      strandDetailsDesc={
                        StrandReducer.selectedstandardObject == null
                          ? null
                          : StrandReducer.selectedstandardObject.standardName
                      }
                      strandDescription={
                        StrandReducer.selectedstandardObject == null
                          ? null
                          : StrandReducer.selectedstandardObject.standardDesc
                      }
                    />
                  </span>
                ) : null}
              </div>
              <div>
                {!screenLoader ? (
                  <div style={{ width: "100%", float: "left" }}>
                    <div style={{ width: "100%", float: "left" }}>
                      <Chart
                        margin={margin}
                        width={
                          this.props.UserScreenWidth < 1230 ? Ipadwidth : width
                        }
                        height={
                          this.props.UserScreenWidth < 1230
                            ? Ipadheight
                            : height
                        }
                        data={data}
                        Compare_School={Compare_School}
                        Compare_District={Compare_District}
                        XAxis_Params={XAxis_Params}
                        YAxis_Params={YAxis_Params}
                        DataSetParam={DatatPointParams}
                        SchoolChecked={SchoolChecked}
                        DistrictChecked={DistrictChecked}
                        LastChecked_CB={LastChecked_CB}
                        ToolTipData={this.props.Sc_ToolTipData}
                        TooltipParams={tooltipParams}
                        // data2={data2} data3={data3}
                      />
                    </div>
                    {this.props.Sc_LineChart_Pagination.Chart_TotalBubbles >
                    1 ? (
                      <ChartPagination
                        pagination={this.props.Sc_LineChart_Pagination}
                      />
                    ) : null}
                    <div
                      className="Test_names_label"
                      style={{ float: "left", paddingTop: 15 }}
                    >
                      Test Names
                    </div>
                  </div>
                ) : (
                  <LoadingScreen />
                )}
              </div>
            </div>
            <div className="centre_line"></div>
            <div className="class_right_block" style={{ position: "relative" }}>
              <div className="class_widget_title">
                <span className="float-right">
                  Test Score Detail
                  {ApiClassReports.loading_LC_students == false &&
                  this.props.Sc_TS_Class_ListTable.List_Includes_NullScores
                    .testScoreList !== undefined &&
                  this.props.Sc_TS_Class_ListTable.List_Includes_NullScores
                    .testScoreList.length > 0 ? (
                    <TestScoreDetailListPDF
                      Header={HeaderDetailsForPrint}
                      TestDetails={TestDetailsForPrint}
                      CompareOptions={CompareOptionsForPrint}
                      MetaData={MetaDataForPrint}
                      sortedArrayData={
                        this.props.Sc_TS_Class_ListTable.SortedArray
                      }
                      ActualList={this.props.Sc_TS_Class_ListTable.ActualList}
                      Data={this.props.Sc_TS_Class_ListTable}
                      DataToDisplay={DataToDisplayForStudentsList}
                      PaginationData={this.props.Pagination_For_Remaining}
                      fromComp="sc_ts_overview"
                    />
                  ) : null}
                </span>
              </div>

              {NoTestSelectedInGraph ? (
                <Make_A_Selection_msg message="Make a selection in the graph to see details." />
              ) : ApiClassReports.loading_LC_students == false &&
                !screenLoader ? (
                <div className="standard-widget-class_level">
                  <OverviewDetailHeader
                    fromComp="sc_ts_overview"
                    checkSchool={this.props.Sc_Test_Scores_OverTime.checkSchool}
                    checkDistrict={
                      this.props.Sc_Test_Scores_OverTime.checkDistrict
                    }
                    Data={this.props.Sc_TS_Class_ListTable}
                    ActualList={this.props.Sc_TS_Class_ListTable.ActualList}
                    l40={lessthan40Studentcount}
                    l40width={l40width}
                    g40tol59={l40to59Studentcount}
                    l40to59width={l40to59width}
                    g60tol79={l60to79Studentcount}
                    l60to79width={l60to79width}
                    g80={l80Studentcount}
                    g80width={g80width}
                    studentTotalC={totalStudentCount}
                    averagescore={totalAverageScore}
                    testName={testName}
                    startDate={selectedTest_submitStart}
                    endDate={selectedTest_submitEnd}
                  />

                  <OverviewDetailStudentList
                    totalstudentcount={totalStudentCount}
                    studentsdata={Test_Scores_Details}
                    sortedValue={sortedValue}
                    Data={this.props.Sc_TS_Class_ListTable}
                    pagination={this.props.Sc_Pagination_For_Remaining}
                    DataToDisplay={DataToDisplayForStudentsList}
                    sortedArrayData={
                      this.props.Sc_TS_Class_ListTable.SortedArray
                    }
                  />
                </div>
              ) : (
                <LoadingScreen />
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Reports,
  Universal,
  Authentication,
  schoolReducer,
  LastActiveUniversalProps,DateTabReducer
}) => {
  const { StandardPerformance_Overview } = Reports;
  const { LoginDetails, UserScreenWidth } = Authentication;
  const {
    AchivementLevels,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    UniversalFilter,
    currentTermID,
  } = Universal;
  const {
    Sc_Test_Scores_OverTime,
    Sc_LineChart_Pagination,
    Sc_ApiCalls,
    Sc_TS_Class_ListTable,
    Sc_ToolTipData,
    Sc_Pagination_For_Remaining,
  } = schoolReducer;
  const { Context_DateTab } = DateTabReducer;
  return {
    Sc_Test_Scores_OverTime,
    Sc_LineChart_Pagination,
    LoginDetails,
    AchivementLevels,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    UserScreenWidth,
    Sc_ToolTipData,
    StandardPerformance_Overview,
    Sc_ApiCalls,
    Sc_TS_Class_ListTable,
    Sc_Pagination_For_Remaining,
    LastActiveUniversalProps,
    UniversalFilter,
    currentTermID,Context_DateTab
  };
};

export default connect(mapStateToProps, {
  OpenOrCloseTooltipIn_SC_OT,
  OpenOrCloseNoteIn_TS_OT,
  CheckCompareTabs,
  EnableOrDisableLineColorIn_LC,
  Get_school_TestScores_Graph,
  Get_Selected_TS_Details,
  CompareCheckBoxOption_For_School_LC,
  trackingUsage
})(sc_ts_overview);
