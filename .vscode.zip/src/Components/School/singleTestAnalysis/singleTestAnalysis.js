import React, { Component } from 'react';
import { connect } from 'react-redux';

import ST_analysisPage from "../../../Utils/st_analysis/ST_analysisPage";
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class sc_st_analysis extends Component {
    componentDidMount(){
        this.props.trackingUsage("assessmentreports_singletestanalysis:school");
    }

    render() { 
        let singleTestAnalysisData = this.props.school_TestAnalysis
        let fromContext = 'school'
        return (
            <ST_analysisPage fromContext={fromContext} singleTestData={singleTestAnalysisData} /> 
        );
    }
}

const mapStateToProps = ({ Universal, Authentication, SingleTestAnalysis }) => {

    const { school_TestAnalysis } = SingleTestAnalysis

    return {
        Universal, Authentication, school_TestAnalysis
    }
}

const mapStateToDispatch = {
    trackingUsage
}

export default connect(mapStateToProps,mapStateToDispatch)(sc_st_analysis);
