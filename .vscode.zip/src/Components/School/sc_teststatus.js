import React, { Component } from 'react';
import { connect } from "react-redux";
import { SummaryBlock, DetailsBlock } from '../../Utils/TestStatus/TestScore_Blocks';

import {
    OnTestStatusSelection, SortTestStatusSummaryData, SortTestStatusDetailsData,
    Get_TestStatusSummaryData, Check_ISAssignmentIDAvailable, Get_TestStatusDetailsData, Pagination_Bubble_Selection, Pagination_Navigate_Selection, OpenOrClose_TestStatus_Info_Popup,
    ShowAllResults
} from '../../Redux_Actions/TestStatus.Actions';

import { OnGoTo_ST_Analysis, DrillDownToClass_TestStatus } from '../../Redux_Actions/UniversalSelectorActions_Primary'
import { SaveContextSelection } from '../../Redux_Actions/UniversalSelectorActions';
import ic_print from '../../../public/images/ic_print_new.svg';
import info_icon from '../../../public/images/info_icon.svg';
import { Call_TestStatusSummaryData, Call_TestStatusDetailsData, triggerPdfDownload } from '../../services/testStatus.service';
import { openPopUpInTestStatusPrint, handleApplyFilterInTestStatus } from '../../Redux_Actions/TestStatusPrintActions'
import TestStatusPopup from '../../Utils/TestStatusPrintModel/testStatusPrint';
import SchooltestStatusPDF from '../../Components/ReusableComponents/TestStatusPDF/SchoolTestStatusPDF'
import { trackingUsage } from '../../Redux_Actions/AuthenticationAction';
import ic_test_status from '../../../public/images/ic_test_status.svg';

class sc_TestStatus extends Component {
    constructor(props) {
        super(props);
        this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
        this.P_OT_infoRef = {},
            this.Note_InfoRefs;
        this.InfoTooltipPopUp = {},
            this.i_span_tooltip_ref = {},
            this.SortTableData = this.SortTableData.bind(this);
        this.SortDetailsData = this.SortDetailsData.bind(this);
        this.OnStatusSelection = this.OnStatusSelection.bind(this);
        this.NavToSingleTest = this.NavToSingleTest.bind(this);
        this.OnSelecting_ItemName_InRightSide = this.OnSelecting_ItemName_InRightSide.bind(this)

        // this.OnGoTo_ST_Analysis = this.OnGoTo_ST_Analysis.bind(this)
        this.state = {
            OpenPerformanceOT: false,
            OpenStudentsList: true,
            show_P_Overtime_Info: false
        }
    };

    componentDidMount() {
        Call_TestStatusSummaryData(this.props, "school");
        Call_TestStatusDetailsData(this.props, "school")
        triggerPdfDownload(this.props, "school", this.props.schoolTestStatusPrint.triggerAPI)
        document.addEventListener("mousedown", this.handleClickOutside_info);
        this.props.trackingUsage("assessmentreports_teststatussummary:school");
    }

    componentDidUpdate(prevProps,prevState) {

        Call_TestStatusSummaryData(this.props, "school");
        Call_TestStatusDetailsData(this.props, "school")
        triggerPdfDownload(this.props, "school", this.props.schoolTestStatusPrint.triggerAPI)
        if(prevProps.TestStatusReducer.School.Apicalls.GetDetailsData !== this.props.TestStatusReducer.School.Apicalls.GetDetailsData && this.props.TestStatusReducer.School.Apicalls.GetDetailsData) {
            this.props.trackingUsage("assessmentreports_teststatusdetail:school"); //call usage tracking here for test status details
        }
    }
    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleClickOutside_info);
    }
    handleClickOutside_info(event) {
        if (event.target == null || event.target == undefined) {
        } else if (this.props.TestStatusReducer.School.openInfoPopUp) {
            if (this.Note_InfoRefs !== null && this.Note_InfoRefs !== undefined) {
                let isitemexists = this.Note_InfoRefs.contains(event.target);
                if (isitemexists == undefined || isitemexists == null || isitemexists == false) {
                    this.props.OpenOrClose_TestStatus_Info_Popup(false, this.props.NavigationByHeaderSelection)
                }
            }
        }
    }
    render() {

        let StatusDetails = this.props.TestStatusReducer.School.StatusDetail;
        let TestStatus_Info_Popup = this.props.TestStatusReducer.School.openInfoPopUp;
        const { loadingOnGetSummaryData, loadingOnGetDetailsData } = this.props.TestStatusReducer.School.Apicalls
        let TestApiOr_SchoolApi = this.props.ApiCalls.getTests ||
            this.props.ApiCalls.Get_Selected_School_Info ||
            this.props.ApiCalls.loadingFor == "tests" ||
            this.props.ApiCalls.loadingFor == "school";

        const testSummaryLoading = loadingOnGetSummaryData && !TestApiOr_SchoolApi
        const testDetailLoading = loadingOnGetDetailsData
        const schoolTestStatusPrint = this.props.schoolTestStatusPrint
        const sortingDataPDF = {
            "summaryLevel": {
                "SortStatus": this.props.TestStatusReducer.School.SortStatus,
                "SortStatus_Type": this.props.TestStatusReducer.School.SortStatus_Type
            },
            "detailLevel": {
                "SortStatus": StatusDetails.SortField,
                "SortStatus_Type": StatusDetails.SortType
            }
        }
        const { selectedStatus } = this.props.TestStatusReducer.School.PersistedDataFromSum;
        return (
            <div className="testStatus">
                {schoolTestStatusPrint.triggerPDF ? <SchooltestStatusPDF /> : null}
                {/*  */}
                {schoolTestStatusPrint !== undefined ? schoolTestStatusPrint.popupStatus ? <TestStatusPopup testStatusPrintData={schoolTestStatusPrint} contextSelected="school" /> : null : null}
                {/*  */}
                <div className="testStatusMain">
                    <div className="testStatus_header">
                        <div className="testStatus_summary_head">
                            Summary <span onClick={() => this.props.OpenOrClose_TestStatus_Info_Popup(true, this.props.NavigationByHeaderSelection)}
                                // ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                                className="infoIconBlock">
                                <img src={info_icon} />
                                {TestStatus_Info_Popup ?
                                    <div className="infoIconTooltipBlock_TestStatus">
                                        <div
                                            ref={ref => (ref !== null ? this.Note_InfoRefs = ref : null)}
                                            className="infoIconTooltipBlockInr_TestStatus">
                                            <span className="infoIcon_Tooltip_BlockArrow_Test_Status"></span>
                                            <b>Note:</b> Students who have taken a test more than once will be repeated in the test status results.
                                            </div>
                                    </div>
                                    : null}
                            </span>

                           {!loadingOnGetSummaryData && (selectedStatus != null && selectedStatus != "" && <div className="ts_show_all_result_block"
                            onClick={() => this.props.ShowAllResults("school")}>     
                                <div className="ts_all_result_tooltip">
                                    <span class="ts_all_result_tooltip_arrow"></span>
                                    <span class="ts_show_all_result_tooltip_text">
                                        Shows all tests for Grade 6
                                    </span>
                                </div>                       
                                <img src={ic_test_status} width="17.13px" height="18px" />
                                <span className="ts_show_all_result_txt"> Show All Results
                                </span> 
                                
                            </div>)}

                        </div>
                        <div className="testStatus_detail_head">
                            <span className="testStatus_detail_head_title">Detail</span>
                            {!loadingOnGetSummaryData && <span className="testStatus_detail_print" onClick={() => { this.props.openPopUpInTestStatusPrint("school", sortingDataPDF, StatusDetails) }}><img src={ic_print}/></span>}
                        </div>
                    </div>

                </div>
                <div className="testStatus_mainBlock">

                    {SummaryBlock(this.props.TestStatusReducer.School,
                        this.SortTableData, this.OnStatusSelection,
                        this.props.Pagination_Bubble_Selection,
                        this.props.Pagination_Navigate_Selection,
                        testSummaryLoading,
                        "school",
                        this.props.ApiCalls.loadingFor == "tests"
                    )}
                    {DetailsBlock(testSummaryLoading,StatusDetails, this.SortDetailsData, this.props.Pagination_Bubble_Selection,
                        this.props.Pagination_Navigate_Selection, testDetailLoading,
                        this.props.NavigationByHeaderSelection,
                        this.props.ContextHeader,
                        () => this.props.OnGoTo_ST_Analysis(),
                        this.NavToSingleTest,
                        this.OnSelecting_ItemName_InRightSide,
                        "school",
                        this.props.ApiCalls.loadingFor == "tests"
                    )}

                </div>
            </div>
        );
    }

    NavToSingleTest(option) {
        this.props.SaveContextSelection(option)
    }

    SortTableData(sortType, sortOn) {
        this.props.SortTestStatusSummaryData(sortType, sortOn, 'school')
    }

    OnStatusSelection(selectedItem, selectedStatus) {
        let Nav = this.props.NavigationByHeaderSelection;

        this.props.OnTestStatusSelection(selectedItem, selectedStatus, 'school', Nav)

    }

    SortDetailsData(sortType, sortOn) {
        this.props.SortTestStatusDetailsData(sortType, sortOn, 'school')
    }

    OnSelecting_ItemName_InRightSide(selected) {
        this.props.DrillDownToClass_TestStatus(selected);

    }


}

const mapStateToProps = ({ schoolReducer, Universal, Authentication, TestStatusReducer, DateTabReducer, TestStatusPrintReducer }) => {

    const { LoginDetails } = Authentication;
    const { Sc_ApiCalls, Sc_StandardPerformance_Overview } = schoolReducer;
    const { ContextHeader, ApiCalls, UniversalSelecter, NavigationByHeaderSelection,currentTermID } = Universal;
    const { schoolTestStatusPrint } = TestStatusPrintReducer
    return {
        LoginDetails, ContextHeader, ApiCalls, UniversalSelecter, NavigationByHeaderSelection,
        TestStatusReducer, DateTabReducer, Sc_ApiCalls, Sc_StandardPerformance_Overview, schoolReducer, schoolTestStatusPrint, Universal,currentTermID
    };
}

export default connect(mapStateToProps, {
    OnTestStatusSelection, SortTestStatusSummaryData, SortTestStatusDetailsData,
    Pagination_Bubble_Selection, Pagination_Navigate_Selection, OpenOrClose_TestStatus_Info_Popup,
    Get_TestStatusSummaryData, Check_ISAssignmentIDAvailable,
    Get_TestStatusDetailsData, OnGoTo_ST_Analysis, SaveContextSelection,
    DrillDownToClass_TestStatus, openPopUpInTestStatusPrint, handleApplyFilterInTestStatus,trackingUsage,
    ShowAllResults,
})(sc_TestStatus);