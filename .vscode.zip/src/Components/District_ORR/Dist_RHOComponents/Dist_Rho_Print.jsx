import React, { Component } from 'react';

class DistrictRhoPrint extends Component {

    arrayConstruction(list, endIndex) {
        var arrayConst = list.map((data, index) => {
            return data.classesDetails.map((stuDetails, i) => {
                return {
                    schoolName: data.schoolName, header: stuDetails.className, listItems: this.schoolData(stuDetails.studentDetails, endIndex),
                    count:  stuDetails.studentDetails == null ? 0 : stuDetails.studentDetails.length,
                }
            })
        });
        return arrayConst
    }


    schoolData(list, endIndex) {
        var idx = 0
        var result = []

        if(list == null) {
            return result;
        }

        while (idx < list.length) {
            if (idx % endIndex === 0) result.push([])
            result[result.length - 1].push(list[idx++])

        }
        return result;
    }

    distRhoDataConstruction(list, endIndex) {
        let totalTable = 0;
        let modifiedArray =
            this.arrayConstruction(list, endIndex);

        let total = modifiedArray.map((indArray, mainInd) => {
            return indArray.map((obj, idx) => {
                return obj.listItems.map((list, index) => {
                    totalTable = ++totalTable;
                    return this.printTable(list, obj.schoolName, obj.count, index, obj.header, totalTable)
                })
            })
        })
        return total
    }

    studentCount(list, idx) {
        let start = 1;
        let end = 0;
        if (idx === 0) {
            start = 1;
            end = list.length;
        } else {
            start = idx * 5 - 4;
            end = list.length < 5 ? start + list.length - 1 : idx * list.length
        }
        return `${start} - ${end}`
    }


    printTable(arr, header, count, idx, className, totalTable) {
        const dashSymbol = <span>&mdash;</span>;
        return <React.Fragment>
            <table className={"crho-table-print dist-bg dstrhs-mt" + totalTable}>
                <tr className="dist_rho-heading-left" style={{ border: 'none' }}>
                    <th colSpan="5">{header}</th>
                </tr>
                <tr className="dist_rho-heading-left"><th colSpan="5">{className}</th></tr>
                <tr className="crho-print">
                    <th style={{ height: "20px" }}>Student({this.studentCount(arr, idx + 1)}/ {count})</th>
                    {arr.map((classDetails, i) => {
                        return <React.Fragment>
                            <th style={{ height: "20px" }}>{classDetails.firstName + ' ' + classDetails.lastName}</th>
                        </React.Fragment>
                    })}
                </tr>
                <tr className="crho-print">
                    <th>Date</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }} >{data.assignmentDate}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Level </th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.letterLevel}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Proficiency</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.proficiency}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Passage </th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.lastPassage !== null ? data.lastPassage : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Category</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.category !== null ? data.category : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Accuracy</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.accuracy !== null ? data.accuracy + "%" : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Self-Correction</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>
                                    {data.selfCorrection !== null && data.selfCorrection !== 'NA'
                                        ? data.selfCorrection : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Fluency</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.fluency !== null ? data.fluency + ' wcpm' : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Retell</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.reTelling !== null ? data.reTelling : dashSymbol}</td>
                            </React.Fragment>)
                    })}
                </tr>
                <tr className="crho-print">
                    <th>Comprehension</th>
                    {arr.map((data, value) => {
                        return (
                            <React.Fragment>
                                <td key={value} style={{ textAlign: "left" }}>{data.comprehension !== null ? data.comprehension : dashSymbol}</td>
                            </React.Fragment>)
                    })}
                </tr>
            </table>
        </React.Fragment>
    }

    render() {
        return (
            <React.Fragment>
                {this.distRhoDataConstruction(this.props.districtData.data, 5)}
            </React.Fragment>
        )
    }
}

export default DistrictRhoPrint;
