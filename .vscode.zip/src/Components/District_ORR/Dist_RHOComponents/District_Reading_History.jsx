import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  DISTRICT_READING_HISTORY_DATA,
  DISTRICT_RHO_SCHOOL_NAMES,
  DISTRICT_RHO_SINGLE_SCHOOL,
  DISTRICT_RH_ERRORHANDLING,
  DSTRHO_CSVDATA_DOWNLOAD_APICALL,
  DSTRHO_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/District_ReadingHistoryAction.jsx';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import {
  navigateToStudentRHOReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import DistrictRho from './DistrictRho.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import NoRecordsData from '../../../Utils/No_Data_Found';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import Filter from '../../ORR/FilterComponents/Filter';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import { formatDate, AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from '../../../Utils/globalVars';
import DistrictRhoPrint from './Dist_Rho_Print.jsx'
import PrintDistRho from '../../ReusableComponents/PrintOrrCharts/Dst_RhoPrint.jsx'
import { AGPDistrictCSV } from '../../../Redux_Actions/District_Report_Actions';
import { csvDownload } from '../../../Utils/CSVDownload/AGPReports';
import Confirmation_AgpPopup from '../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';

class District_Reading_History extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false,
      showAgpConfirmationPopup: false,
    };
    this.timeOut = this.timeOut.bind(this);
    this.districtReadingHistoryApi = this.districtReadingHistoryApi.bind(this);
    this.callSchooldetailsApi = this.callSchooldetailsApi.bind(this);
  }

  componentDidMount() {
    this.districtReadingHistoryApi();
  }
  // handle timeout
  timeOut() {
    this.props.DISTRICT_RH_ERRORHANDLING({
      isApiLoading: false,
      isDataNotAvailable: false,
      timeOut: true
    });
    // this.setState({ ...this.state, timeOut: true });
  }

  // Function for district Reading History Api
  districtReadingHistoryApi() {
    // start spinner befor the api call
    this.props.DISTRICT_RH_ERRORHANDLING({
      isApiLoading: true,
      isDataNotAvailable: false,
      timeOut: false
    });
    this.setState({
      timeOut: false
    });

        let termIdVar = "";
      try {
        termIdVar = this.props.ContextHeader.Date_Tab.selectedterm_Obj.termId;
      } catch (error) {

      }

    let externalFilter = {
      districtId: this.props.ContextHeader.Roster_Tab.SelectedDistrict.id,
      selectedStudentsList: this.props.ContextHeader.Roster_Tab.StudentIds,
      // this.props.ContextHeader.Class.districtId,
      // endDate: '01/01/2020',
      // startDate: '01/01/2019'
      endDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termEndDate ?
        this.props.ContextHeader.Date_Tab.Report_termEndDate :
        this.props.ContextHeader.Date_Tab.selectedterm_Obj.termEndDate),
      startDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termStartDate ?
        this.props.ContextHeader.Date_Tab.Report_termStartDate :
        this.props.ContextHeader.Date_Tab.selectedterm_Obj.termStartDate),
      termId : termIdVar,
    };
    let internalFilter = this.props.CommonFilterData;
    this.setState({ externalFilter: externalFilter });
    let data = { externalFilter, internalFilter };
    // this.props.DISTRICT_READING_HISTORY_DATA(
    this.props.DISTRICT_RHO_SCHOOL_NAMES(
      this.props.LoginDetails.JWTToken,
      data
    );
  }

  // calling SchoolDetails APi
// this fn might be obsolete
  handleSchooldetailsApi(schooldetails) {
    this.props.DISTRICT_RHO_SINGLE_SCHOOL (
      this.props.LoginDetails.JWTToken,
      schooldetails
    );
  }

  callSchooldetailsApi(districtDetails, classDetails) {

    let termIdVar = "";
      try {
        termIdVar = this.props.ContextHeader.Date_Tab.selectedterm_Obj.termId;
      } catch (error) {

      }
    // start spinner befor the api call
      this.props.DISTRICT_RH_ERRORHANDLING({
        isApiLoading: true,
        isDataNotAvailable: false,
        timeOut: false
      });
      this.setState({
        timeOut: false
      });

    let externalFilter = {
      districtId: this.props.ContextHeader.Roster_Tab.SelectedDistrict.id,
      schoolId: districtDetails.schoolId,
      classId: classDetails.classId,
      selectedStudentsList: this.props.ContextHeader.Roster_Tab.StudentIds,
      // this.props.ContextHeader.Class.districtId,
      // endDate: '01/01/2020',
      // startDate: '01/01/2019'
      endDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termEndDate ?
        this.props.ContextHeader.Date_Tab.Report_termEndDate :
        this.props.ContextHeader.Date_Tab.selectedterm_Obj.termEndDate),
      startDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termStartDate ?
        this.props.ContextHeader.Date_Tab.Report_termStartDate :
        this.props.ContextHeader.Date_Tab.selectedterm_Obj.termStartDate),
      termId : termIdVar,
    };
    let internalFilter = this.props.CommonFilterData;
    this.setState({ externalFilter: externalFilter });
    let data = { externalFilter, internalFilter };
    this.props.DISTRICT_RHO_SINGLE_SCHOOL (
      this.props.LoginDetails.JWTToken,
      data
    );
  }

  // Download csv data
  downLoadCSVData() {
    const payload = {
      districtChartType: {
        "allGrades": true,
        "chartName": "DRHO",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'district')
    };
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, payload);
    } else {
      this.props.DSTRHO_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.DSTRHO_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, payload);
    }
  }

  render() {
    let Data = this.props.SortData;
    let districtReadingHistoryData = this.props.districtReadingHistoryDetails;
    let errorHandler = this.props.districtReadingHistoryDetails;
    let districtObject = this.props.ContextHeader.District;
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedDistrict.name;
    if (this.props.DstCsvDownload && this.props.DstCsvDownload['downloadInProgress'] && this.props.DstCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.DSTRHO_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }

    return (
      <div>
        {this.props.NavigationByHeaderSelection.district ? (
          <div>
            <Filter externalFilter={this.state.externalFilter} />
            {this.props.districtReadingHistoryDetails.data &&
              !errorHandler.timeOut &&
              !errorHandler.isDataNotAvailable && (
                <React.Fragment>
                  {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                    <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />
                  }
                  <span className="print-icon-class-btn">
                    <PrintDistRho
                      selectedFilter={this.props.CommonFilterData}
                      studentDetails={this.props.ContextHeader}
                      navSelected={this.props.NavigationByHeaderSelection}
                      districtData={districtReadingHistoryData}
                    />
                  </span>
                  <div id="testDst">
                    {this.props.DstCsvDownload && this.props.DstCsvDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.DstCsvDownload['csvData'] && this.props.DstCsvDownload['csvData']['header']}
                        data={this.props.DstCsvDownload['csvData'] && this.props.DstCsvDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        // filename={"DSTRHO_CSV.csv"}
                        filename={`${csvFileName}.csv`}
                      />}
                    <div className="dst-csv-icon-alignment" onClick={() => !this.props.DstCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                      {this.props.DstCsvDownload && this.props.DstCsvDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <DistrictRho
                      districtData={districtReadingHistoryData}
                      CommonFilterData={this.props.CommonFilterData}
                      sortData={this.props.SortData}
                      navigateToStudentRHOReport={this.props.navigateToStudentRHOReport}
                      callSchooldetailsApi={this.callSchooldetailsApi}
                    />
                    {/* <DistrictRhoPrint districtData={districtReadingHistoryData} /> */}
                  </div>
                </React.Fragment>
              )}
            {!this.props.districtReadingHistoryDetails.data &&
              errorHandler.isApiLoading && (
                <Spinner
                  startSpinner={errorHandler.isApiLoading}
                  showTimeOut={this.timeOut}
                />
              )}
            {!errorHandler.isApiLoading && errorHandler.timeOut && (
              <TimeOut tryAgain={this.districtReadingHistoryApi} />
            )}
            {errorHandler.chartLoadFail &&
              !errorHandler.timeOut &&
              !errorHandler.isApiLoading && (
                <ChartNotLoad tryAgain={this.districtReadingHistoryApi} />
              )}
            {districtReadingHistoryData &&
              errorHandler.isDataNotAvailable &&
              !errorHandler.isApiLoading && (
                <NoRecordsData NodataFound={'dataNotAvail'} />
              )}

          </div>
        ) : (
            <div>
              <NoRosterData />
            </div>
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  districtReadingHistory,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const {
    districtReadingHistoryDetails,
    Response,
    SortData,
    isApiLoading,
    isDataNotAvailable,
    DstCsvDownload
  } = districtReadingHistory;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    districtReadingHistoryDetails,
    isApiLoading,
    isDataNotAvailable,
    Response,
    SortData,
    CommonFilterData,
    DstCsvDownload,
    AgpCSV,
  };
};

export default connect(
  mapStateToProps,
  {
    DISTRICT_READING_HISTORY_DATA,
    DISTRICT_RHO_SCHOOL_NAMES,
    DISTRICT_RHO_SINGLE_SCHOOL,
    DISTRICT_RH_ERRORHANDLING,
    navigateToStudentRHOReport,
    DSTRHO_CSVDATA_DOWNLOAD_APICALL,
    DSTRHO_CSVDATA_DOWNLOAD_RESET,
    AGPDistrictCSV,
  }
)(District_Reading_History);
