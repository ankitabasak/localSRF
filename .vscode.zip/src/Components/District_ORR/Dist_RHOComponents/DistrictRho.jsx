import React, { Component } from 'react';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';
import {
  SORT_DRHO_GRID,
  SAVE_SORTED_DRHODATA,
  SHOW_HIDE_BAR
} from '../../../Redux_Actions/District_ReadingHistoryAction.jsx';
import { connect } from 'react-redux';
import './DistrictRho.css';
class DistrictRho extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showDiv: false,
      accordionsState: this.props.districtData.showAccordion
    };
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? 'rt-td-active'
      : '';
  }
  // tooltip for long text
  longTextTooltip(text, name) {
    let len = name ? 20 : 16;
    if (text.length > len) {
      return (
        <React.Fragment>
          {text.substr(0, len)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }

  //to assign color
  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return ' blueColor';
    } else {
      return '';
    }
  }

  //sort district grid on click
  districtRlpSort(sortColumn, sortType, actualArray) {
    document.getElementById('districtRlp').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_DRHO_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map(externalArray => {
      externalArray.classesDetails.map(actualArray => {
        if (actualArray.length != 0) {
          sortedArray = dataSorting(
            actualArray.studentDetails,
            column,
            sortType
          );
          this.props.SAVE_SORTED_DRHODATA(sortedArray);
        }
      });
    });
    this.setState({ ...this.state, sideTableData: stdArray });
  }

  //to collapse district
  showCollapse(classList) {
    this.props.SHOW_HIDE_BAR({
      ...this.props.districtData.showAccordion,
      [classList]: !this.props.districtData.showAccordion[classList]
    });
  }

  callSchoolDetailsApi(districtDetails, classDetails) {
    console.log("h3ll");
    console.log(this.props);
    this.props.callSchooldetailsApi(districtDetails, classDetails)
  }

  // display side table
  displaySideTable(sortData, sideTableData) {
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec sc-rho-header-wrap dst-rho-wrap rhoth"

        >
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'lastName',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              School/Class
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'lastName', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('lastName', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'lastName', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('lastName', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'grade',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Grade
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'grade', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('grade', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'grade', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('grade', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'assignmentDate',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Date
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'assignmentDate', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('assignmentDate', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'assignmentDate', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('assignmentDate', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'letterLevel',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'letterLevel', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('letterLevel', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'letterLevel', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('letterLevel', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>

          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'proficiency',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'proficiency', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('proficiency', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'proficiency', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('proficiency', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'lastPassage',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Passage
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'lastPassage', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('lastPassage', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'lastPassage', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('lastPassage', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'category',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Category
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'category', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('category', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'category', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('category', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'accuracy',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Accuracy
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'accuracy', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('accuracy', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'accuracy', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('accuracy', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>

          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'selfCorrection',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Self-Correction
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'selfCorrection', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('selfCorrection', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'selfCorrection', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('selfCorrection', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'fluency',
                sortData.sortType
              ) + ' ' + 'rho-student'}
            >
              Fluency
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'fluency', 'desc')
                }
                onClick={() =>
                  this.districtRlpSort('fluency', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'fluency', 'asc')
                }
                onClick={() =>
                  this.districtRlpSort('fluency', 'asc', sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span className={this.LineUnderActiveColumnFiled(
              sortData,
              'reTelling',
              sortData.sortType
            ) + ' ' + 'rho-student'}>Retell</span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span className={this.LineUnderActiveColumnFiled(
              sortData,
              'comprehension',
              sortData.sortType
            ) + ' ' + 'rho-student'}>Comprehension</span>
          </div>
        </div>
        <div className="student-list-body scroll-body width-1590" id="districtRlp">
          {sideTableData.map((districtDetails, index) => (
            <div
              className="student-list-row-rhs-sec sc-rlp dst-rho"
              key={index}
            >
              <div
                className={
                  this.props.districtData.showAccordion[
                    districtDetails.schoolName
                  ]
                    ? 'expanded-group cursor-pointer'
                    : 'collapsed-group cursor-pointer'
                }
                style={{ backgroundColor: '#d6dbe5' }}
                onClick={() => {this.showCollapse(districtDetails.schoolName);  }}
              >
                <span>
                  {districtDetails.schoolName}&nbsp;&nbsp;(
                  {districtDetails.classesDetails.length}
                  &nbsp;Classes)
                </span>
              </div>
              {districtDetails.classesDetails.map((classDetails, value) => (
                <div
                  className="class-list-row-rhs-sec sc-rlp"
                  className={
                    'class-list-row-rhs-sec ' +
                    (this.props.districtData.showAccordion[
                      districtDetails.schoolName
                    ]
                      ? 'show'
                      : 'hide')
                  }
                  key={value}
                >
                  <div
                    className={
                      this.props.districtData.showAccordion[
                        classDetails.className
                      ]
                        ? 'expanded-group cursor-pointer'
                        : 'collapsed-group cursor-pointer'
                    }
                    style={{ backgroundColor: '#f3f5fa' }}
                    onClick={() => { this.showCollapse(classDetails.className); this.callSchoolDetailsApi(districtDetails, classDetails);} }
                  >
                    <span>
                      {classDetails.className}&nbsp;&nbsp; {/* (
                      {classDetails.studentDetails.length}
                      &nbsp;Students) */}
                    </span>
                  </div>
                  { (classDetails.studentDetails == null ||
                                      classDetails.studentDetails.length <= 0) &&
                                      this.props.districtData.showAccordion[
                                          classDetails.className
                                        ]
                                      ?
                                     (
                                      <div
                                        className={
                                          'student-list-row-rhs-sec pos-rel show'
                                        }
                                      >
                                        <div className="" >
                                          <span className="no-data-msg wb-break-all long-text-tooltip">
                                          No data for class
                                          </span>
                                        </div>
                                      </div>
                                    ) :
                                    ( classDetails.studentDetails != null &&
                                    classDetails.studentDetails.length > 0 &&
                  classDetails.studentDetails.map((studentList, value) => (
                    <div
                      className={
                        'student-list-row-rhs-sec pos-rel ' +
                        (this.props.districtData.showAccordion[
                          classDetails.className
                        ]
                          ? 'show'
                          : 'hide')
                      }
                      key={value}
                    >
                      <div className="student-column-list-rhs-sec" onClick={() => { this.props.navigateToStudentRHOReport(studentList, classDetails) }}>
                        <span className="cursor-pointer wb-break-all long-text-tooltip">
                          {this.longTextTooltip(studentList.firstName + ' ' + studentList.lastName, true)}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.grade ? studentList.grade : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.assignmentDate
                            ? studentList.assignmentDate
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.letterLevel
                            ? studentList.letterLevel
                            : dashSymbol}
                        </span>
                      </div>

                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.proficiency
                            ? studentList.proficiency
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec long-text-tooltip">
                        <span>
                          {studentList.lastPassage
                            ? this.longTextTooltip(studentList.lastPassage, false)
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.category
                            ? studentList.category
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.accuracy
                            ? studentList.accuracy
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.selfCorrection !== null && studentList.selfCorrection !== 'NA'
                            ? studentList.selfCorrection
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.fluency
                            ? studentList.fluency
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.reTelling
                            ? studentList.reTelling
                            : dashSymbol}
                        </span>
                      </div>
                      <div className="student-column-list-rhs-sec">
                        <span>
                          {studentList.comprehension
                            ? studentList.comprehension
                            : dashSymbol}
                        </span>
                      </div>
                    </div>
                  )))}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }
  render() {
    return (
      <div
        className="container"
      // style={{ width: '431px', paddingLeft: '0px', paddingRight: '0px' }}
      >
        <div className="reading-target-wrap">
          <div className="rhs-wrap sc_rhs_wrap srho-wrap dst-main-wrap">
            <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
              <div className="student-list-table-main">
                <div className="student-list-table-rhs-sec overflow-scroll-crh">
                  {this.displaySideTable(this.props.sortData, this.props.districtData.data)}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { SORT_DRHO_GRID, SAVE_SORTED_DRHODATA, SHOW_HIDE_BAR }
)(DistrictRho);
