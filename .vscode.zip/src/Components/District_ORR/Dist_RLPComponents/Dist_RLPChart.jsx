import '../Dist_RLPComponents/district-rlp.css';

import {
  Chart_loading_Failed,
  DRLP_loading_Icon,
  DSTRLP2_CSVDATA_DOWNLOAD_APICALL,
  DSTRLP2_CSVDATA_DOWNLOAD_RESET,
  DSTRLP_CSVDATA_DOWNLOAD_APICALL,
  DSTRLP_CSVDATA_DOWNLOAD_RESET,
  District_Class_Grid_Chart_Table_API,
  District_Class_Level_RLP_Chart_API,
  District_Level_RLP_Chart_API,
  District_Level_Scroll_Data,
  District_RLP_Grid_Chart_Table_API,
  Selected_Levels,
  toggleDropDown,
  updateAllMonth,
  updateChartDetails,
  updateDropDownData
} from '../../../Redux_Actions/District_RlpActions.jsx';
import React, { Component } from 'react';
import { getCommonHeaders, getDateFormat } from '../../ReusableComponents/OrrReusableComponents';

import { AGPDistrictCSV } from '../../../Redux_Actions/District_Report_Actions';
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from "../../../Utils/globalVars";
import { CSVLink } from "react-csv";
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import Confirmation_AgpPopup from '../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';
import CsvIcon from '../../../../public/images/ic_save.svg';
import DistrictRlpGrade from './District_RLP_Grade_Column/DistrictRLPGradeColumn.jsx';
import Filter from '../../ORR/FilterComponents/Filter';
import NoRecordsData from '../../../Utils/No_Data_Found';
import PrintDstRlp from '../../ReusableComponents/PrintOrrCharts/Dst_RlpPrint.jsx';
import ScSidePanel from './District_RLP_Side_Panel.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import YAxisComponent from './District_RLP_Reading_Level_Component/District_RLP_Reading_Levels.jsx';
import { connect } from 'react-redux';
import { csvDownload } from '../../../Utils/CSVDownload/AGPReports';

class DistrictRLPChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sidepanelApiInRun: false,
      grade: {},
    };
    this.districtRlpGridApi = this.districtRlpGridApi.bind(this);
    this.backToMainChart = this.backToMainChart.bind(this);
    this.chartApiCall = this.chartApiCall.bind(this);
  }

  componentDidMount() {
    this.chartApiCall();
  }

  // initial api call
  chartApiCall() {
    let payLoad = getCommonHeaders(this.props, 'district')
    this.props.District_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  // time out
  timeOut() {
    this.props.Chart_loading_Failed({
      noChartData: false,
      apiLoadFail: false,
      constructedData: null,
      timeout: true
    });
  }
  //DistrictRlp Grid API

  districtRlpGridApi(selectedLevels) {
    let SL;
    let grade = 'grade';
    let recordListType = '';
    let distSl = 'districtRLPChart1SidePanelRequestList';

    if (this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP') {
      grade = 'schoolId';
      distSl = 'districtRLPChart2SidePanelRequestList';
    }
    if (selectedLevels['recentRecord']) {
      recordListType = 'recentRecord';

      SL = selectedLevels['recentRecord'].map(obj => {
        if (grade == 'schoolId') {
          return {
            [grade]: obj[grade],
            readingLevel: obj.readingLevel,
            ['grade']: this.props.DistrictRLPState.districtLevelGrade,
            schoolName: obj.schoolName
          };
        } else {
          return { [grade]: obj[grade], readingLevel: obj.readingLevel };
        }
      });
    } else if (selectedLevels['firstRecord']) {
      recordListType = 'firstRecord';
      SL = selectedLevels['firstRecord'].map(obj => {
        if (grade == 'schoolId') {
          return {
            [grade]: obj[grade],
            readingLevel: obj.readingLevel,
            ['grade']: this.props.DistrictRLPState.districtLevelGrade,
            schoolName: obj.schoolName
          };
        } else {
          return { [grade]: obj[grade], readingLevel: obj.readingLevel };
        }
      });
    } else {
      SL = selectedLevels;
    }

    let Payload = {
      ...getCommonHeaders(this.props, 'district'),
      [distSl]: SL,
      label: recordListType
    };
    if (this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP') {
      if (!this.state.sidepanelApiInRun) {
        this.setState({ ...this.state, sidepanelApiInRun: true });
        setTimeout(() => {
          this.props.District_RLP_Grid_Chart_Table_API(
            this.props.LoginDetails.JWTToken,
            Payload
          );
          this.setState({ ...this.state, sidepanelApiInRun: false });
        }, 1000);
      }
    } else if (this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP') {
      Payload['grade'] = this.props.DistrictRLPState.responseData['grade'];

      if (!this.state.sidepanelApiInRun) {
        this.setState({ ...this.state, sidepanelApiInRun: true });
        setTimeout(() => {
          this.props.District_Class_Grid_Chart_Table_API(
            this.props.LoginDetails.JWTToken,
            Payload
          );
          this.setState({ ...this.state, sidepanelApiInRun: false });
        }, 1000);
      }
    }
  }

  // X axis scroll control
  getGradeArray(listItems, index) {
    return listItems.slice(index, this.props.DistrictRLPState['isMobileView']);
  }
  // check for duplicate value
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          bubble.readingLevel === obj.readingLevel &&
          bubble.grade === obj.grade &&
          obj.schoolName === bubble.schoolName
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  saveSelectedLevels(levels, selLvls) {
    let selectedLevels = selLvls[levels.type];
    if (selectedLevels) {
      let duplicateIndex = this.isDuplicateBubble(levels, selectedLevels);

      if (duplicateIndex != -1) {
        selectedLevels.splice(duplicateIndex, 1);
      } else {
        selectedLevels.push(levels);
      }

      this.props.Selected_Levels({
        ['selectedLevels']: { [levels.type]: selectedLevels }
      });

      this.districtRlpGridApi({ [levels.type]: selectedLevels });
    } else {
      selectedLevels = { [levels.type]: [levels] };

      this.props.Selected_Levels({
        ['selectedLevels']: selectedLevels
      });
      this.districtRlpGridApi(selectedLevels);
    }
  }

  // EXPAND AND COLLAPSE DATA UPDATE
  updateExpandCollapseData(dropDownSelection) {
    Promise.resolve(this.props.updateChartDetails(dropDownSelection)).then((response) => {

      if (this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP') {
        let selectedGrades = this.props.DistrictRLPState.constructedData['xAxisData'];
        let selectedBoxes = {}

        if (selectedGrades && selectedGrades.length > 0) {
          const selectedGrade = selectedGrades[0];

          let firstRecord = Object.keys(selectedGrade['recordDataList']['firstRecord']);
          let recentRecord = Object.keys(selectedGrade['recordDataList']['recentRecord']);

          if (recentRecord && recentRecord.length > 0) {
            selectedBoxes['recentRecord'] = []
            recentRecord.forEach((readingLevel) => {
              selectedBoxes['recentRecord'].push({ readingLevel: readingLevel, grade: selectedGrade['grade'] })

            })

          } else if (firstRecord && firstRecord.length > 0) {
            selectedBoxes['firstRecord'] = []
            firstRecord.forEach((readingLevel) => {
              selectedBoxes['firstRecord'].push({ readingLevel: readingLevel, grade: selectedGrade['grade'] })

            })
          }


          this.props.Selected_Levels({
            ['selectedLevels']: selectedBoxes
          });
          this.districtRlpGridApi(selectedBoxes);
        }

      } else if (this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP') {

        let selectedGrades = this.props.DistrictRLPState.constructedData['xAxisData'];
        let selectedBoxes = {}
        if (selectedGrades && selectedGrades.length > 0) {
          const selectedGrade = selectedGrades[0];

          let firstRecord = Object.keys(selectedGrade['recordDataList']['firstRecord']);
          let recentRecord = Object.keys(selectedGrade['recordDataList']['recentRecord']);
          if (recentRecord && recentRecord.length > 0) {
            selectedBoxes['recentRecord'] = []
            recentRecord.forEach((readingLevel) => {
              selectedBoxes['recentRecord'].push({
                readingLevel: readingLevel,
                schoolId: selectedGrade['schoolId'],
                schoolName: selectedGrade['schoolName'],
                type: 'recentRecord'
              })

            })
          } else if (firstRecord && firstRecord.length > 0) {
            selectedBoxes['firstRecord'] = []
            firstRecord.forEach((readingLevel) => {
              selectedBoxes['firstRecord'].push({
                readingLevel: readingLevel,
                schoolId: selectedGrade['schoolId'],
                schoolName: selectedGrade['schoolName'],
                type: 'firstRecord'
              })
            })
          }
        }

        this.props.Selected_Levels({
          ['selectedLevels']: selectedBoxes
        });
        this.districtRlpGridApi(selectedBoxes);

      }


    });
  }

  getAxisRangeData(dataList, index) {
    let rl = dataList.slice(index, 13);
    return rl.reverse();
  }

  scrollUpDown(dataList, index, scrollType) {
    let rl = [];
    switch (scrollType) {
      case 'up':
        if (index < dataList.length - 13) {
          let scrlIndex = index + 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 13);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'down':
        if (index > 0) {
          let scrlIndex = index - 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 13);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeTop':
        if (index < dataList.length - 13) {
          rl = dataList.slice(dataList.length - 13, dataList.length);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: dataList.length - 13
          });
        }
        return;
      case 'extremeBottom':
        if (index > 0) {
          let scrlIndex = 0;
          rl = dataList.slice(0, 13);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  setDataScrollState(data) {
    this.props.District_Level_Scroll_Data(data);
  }

  scrollRightLeft(dataList, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataList.length - this.props.DistrictRLPState['isMobileView']) {
          let scrlIndex = index + 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + this.props.DistrictRLPState['isMobileView']),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let scrlIndex = index - 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + this.props.DistrictRLPState['isMobileView']),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataList.length - this.props.DistrictRLPState['isMobileView']) {
          let scrlIndex = dataList.length - this.props.DistrictRLPState['isMobileView'];

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, dataList.length),
            xScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let scrlIndex = 0;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(0, this.props.DistrictRLPState['isMobileView']),
            xScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  getClassLevelRLPData(grade) {
    this.props.DRLP_loading_Icon('');
    let payLoad = {
      ...getCommonHeaders(this.props, 'district'),
      grade: grade.districtlGrade,
    };

    this.setState({ grade: grade.districtlGrade });
    this.props.District_Class_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  backToMainChart() {
    this.props.DRLP_loading_Icon('');
    let payLoad = getCommonHeaders(this.props, 'district');
    this.props.District_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  //schoolRlp Grid API
  downLoadCSVDataSlRlp2() {
    this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP' &&
    this.props.DSTRLP2_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let payload = {
      districtChartType: {
        "allGrades": false,
        "chartName": "DRLP2",
        "gradeValue": this.state.grade
      },
      ...getCommonHeaders(this.props, 'district')
    };
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, payload);
    } else {
      this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP' &&
        this.props.DSTRLP2_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.DSTRLP2_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, payload);
    }
  }
  // Download csv data
  downLoadCSVData() {
    let payload = {
      districtChartType: {
        "allGrades": true,
        "chartName": "DRLP1",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'district')
    };
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, payload);
    } else {
      this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP' &&
        this.props.DSTRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.DSTRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, payload);
    }
  }

  render() {
    let chartData = this.props.DistrictRLPState.constructedData;
    let viewSpecificScroll = this.props.DistrictRLPState['isMobileView'];
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedDistrict.name;
    let xAxisName =
      this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP'
        ? 'Grade'
        : 'School';
    if (this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP') {
      if (this.props.dstCsvDownload && this.props.dstCsvDownload['downloadInProgress'] && this.props.dstCsvDownload['csvData']) {
        setTimeout(() => {
          this.refs.groupCSV.link.click();
          this.props.DSTRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
        }, 500)
      }
    }
    if (this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP') {
      if (this.props.dstCsvDownload && this.props.dstCsvDownload['downloadInProgress'] && this.props.dstCsvDownload['csvData']) {
        setTimeout(() => {
          this.refs.groupCSV.link.click();
          this.props.DSTRLP2_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
        }, 500)
      }
    }
    return (
      <div>
        <Filter
          chartDisplay={this.props.DistrictRLPState.currentChartInDisplay}
          gd={this.state.grade}
        />
        <div
          className="container"
          style={{
            maxWidth: '1165px',
            paddingLeft: '0px',
            paddingRight: '0px'
          }}
        >
          {/* {this.props.isApiLoading && <Spinner />} */}
          {!this.props.DistrictRLPState.isApiLoading && chartData && (
            <React.Fragment>
              {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
                <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
              <div className="row mt-10" style={{ marginTop: '7px' }} id="testDst">
                {this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP' &&
                  this.props.dstCsvDownload && this.props.dstCsvDownload['csvData'] &&
                  <CSVLink
                    ref="groupCSV"
                    headers={this.props.dstCsvDownload['csvData'] && this.props.dstCsvDownload['csvData']['header']}
                    data={this.props.dstCsvDownload['csvData'] && this.props.dstCsvDownload['csvData']['data']}
                    style={{ display: 'none' }}
                    filename={`${csvFileName}.csv`}
                  />}
                {this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP' &&
                  this.props.dstCsvDownload && this.props.dstCsvDownload['csvData'] &&
                  <CSVLink
                    ref="groupCSV"
                    headers={this.props.dstCsvDownload['csvData'] && this.props.dstCsvDownload['csvData']['header']}
                    data={this.props.dstCsvDownload['csvData'] && this.props.dstCsvDownload['csvData']['data']}
                    style={{ display: 'none' }}
                    filename={`${csvFileName}.csv`}
                  />}
                <div className="dst-csv-icon-alignment orr-top4"
                  onClick={() =>
                    this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP' && !this.props.dstCsvDownload['downloadInProgress'] ? this.downLoadCSVData()
                      : this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP' && !this.props.dstCsvDownload['downloadInProgress'] ? this.downLoadCSVDataSlRlp2() : ""
                  }>
                  {this.props.dstCsvDownload && this.props.dstCsvDownload['downloadInProgress'] ?
                    <span className="csv_download_icon">
                      <i className="material-icons">autorenew</i>
                    </span> :
                    <span className="csv_download_icon">
                      <img src={CsvIcon} width="20" height="20" />
                    </span>}
                </div>

                <div className="srlp-lhs-wrap sc-rlp-wrap dist-right-chart-alignment">
                  <div className="wrap-srlp pos-rel ">
                    {!this.props.popUp &&
                      <div className="legend_sec">
                        <span>Legend:</span>
                        <div className="gray-rect" />
                        <p>Grade Reading</p>
                        <p>Level Target</p>
                      </div>}
                    <div className="readingLevel-srlp">Reading Level</div>
                    <div className="grade-txt-srlp bt-27">{xAxisName}</div>
                    <div className="rhs-line-srlp" />
                    <div className="rhs-line2-srlp" />
                    <div className="rhs-line-btm-srlp" />
                    <div className="rhs-line-btm1-srlp" />

                    {chartData.yAxisDataRange && (
                      <YAxisComponent
                        axisData={{
                          dataRange: chartData.yAxisDataRange,
                          scrollIndex: chartData.yScrollIndex,
                          xScrollIndex: chartData.xScrollIndex,
                          allReadingLevels: chartData.yAxisData
                        }}
                        scrollReadingLevels={scrollType => {
                          this.scrollUpDown(
                            chartData.yAxisData,
                            chartData.yScrollIndex,
                            scrollType
                          );
                        }}
                        scrollGradeLevels={scrollType => {
                          this.scrollRightLeft(
                            chartData.xAxisData,
                            chartData.xScrollIndex,
                            scrollType
                          );
                        }}
                      />
                    )}

                    {chartData.xAxisGradeRange && (
                      <DistrictRlpGrade
                        updateChartDetails={(data) => this.updateExpandCollapseData(data)}
                        toggleDropDown={(data) => this.props.toggleDropDown(data)}
                        updateAllMonth={(data) => this.props.updateAllMonth(data)}
                        updateDropDownDetails={(data) => this.props.updateDropDownData(data)}
                        monthRangeObj={this.props.monthRangeObj}
                        selAll={this.props.selAll}
                        toggleData={this.props.toggleData}
                        viewSpecificScroll={viewSpecificScroll}
                        backToMainChart={this.backToMainChart}
                        gradesData={chartData.xAxisGradeRange}
                        readingLevels={chartData.yAxisDataRange}
                        selectedClassLevels={selectedLevels => {
                          this.saveSelectedLevels(
                            selectedLevels,
                            this.props.DistrictRLPState.districtsSelected || {}
                          );
                        }}
                        selectedLevels={
                          this.props.DistrictRLPState.districtsSelected
                        }
                        currentChartInDisplay={
                          this.props.DistrictRLPState.currentChartInDisplay
                        }
                        scrollGradeLevels={scrollType => {
                          this.scrollRightLeft(
                            chartData.xAxisData,
                            chartData.xScrollIndex,
                            scrollType
                          );
                        }}
                        totalGradeItems={chartData.xAxisData}
                        scrollIndex={chartData.xScrollIndex}
                        getClassLevelRLPData={grade => {
                          this.getClassLevelRLPData(grade);
                        }}
                      />
                    )}
                  </div>
                </div>
                <div className="wrap2 dist-align-wrap" style={{ float: 'left', width: ' 36%' }}>
                  {this.props.DistrictRLPState.districtsSelected && (
                    <ScSidePanel
                      scrollFlag={false}
                      districtData={this.props.DistrictRlpGridData}
                      sortData={this.props.SortData}
                      currentChartInDisplay={
                        this.props.DistrictRLPState.currentChartInDisplay
                      }
                      selectedLevels={
                        this.props.DistrictRLPState.districtsSelected
                      }
                      sidePanelApiFailed={this.props.sidePanelApiFailed}
                    />
                  )}
                </div>

              </div>
            </React.Fragment>)}
          <div>
            {chartData && this.props.DistrictRlpGridData &&
              <span className="print-icon-class-btn orr-top4">
                <PrintDstRlp
                  monthRangeObj={this.props.monthRangeObj}
                  selAll={this.props.selAll}
                  xAxisName={xAxisName}
                  scrollFlag={true}
                  selectedFilter={this.props.CommonFilterData}
                  studentDetails={this.props.ContextHeader}
                  navSelected={this.props.NavigationByHeaderSelection}

                  axisData={{
                    dataRange: chartData.yAxisDataRange,
                    scrollIndex: chartData.yScrollIndex,
                    xScrollIndex: chartData.xScrollIndex,
                    allReadingLevels: chartData.yAxisData
                  }}

                  backToMainChart={this.backToMainChart}
                  gradesData={chartData.xAxisGradeRange}
                  readingLevels={chartData.yAxisDataRange}
                  selectedLevels={
                    this.props.DistrictRLPState.districtsSelected
                  }
                  currentChartInDisplay={
                    this.props.DistrictRLPState.currentChartInDisplay
                  }
                  totalGradeItems={chartData.xAxisData}
                  scrollIndex={chartData.xScrollIndex}

                  districtData={this.props.DistrictRlpGridData}
                  sortData={this.props.SortData}

                />
              </span>}
          </div>
        </div>
        {this.props.DistrictRLPState.isApiLoading &&
          !chartData && (
            <Spinner
              startSpinner={this.props.isApiLoading}
              showTimeOut={this.timeOut}
            />
          )}
        {!chartData && this.props.DistrictRLPState.timeOut && (
          <TimeOut tryAgain={this.chartApiCall} />
        )}
        {!chartData && this.props.DistrictRLPState.noChartData && (
          <NoRecordsData NodataFound={'dataNotAvail'} />
        )}
        {!chartData && this.props.DistrictRLPState.apiLoadFail && (
          <ChartNotLoad tryAgain={this.chartApiCall} />
        )}
      </div>
    );
  }
}

// export default DistrictRLPChart;
const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  DistrictRlpData1,
  SummaryTabReducer
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const { DistrictRLPState, DistrictRlpGridData, SortData, monthRangeObj,
    selAll,
    toggleData, sidePanelApiFailed, dstCsvDownload } = DistrictRlpData1;
  const { CommonFilterData } = CommonFilterDetails;
  const { popUp } = SummaryTabReducer;
  return {
    LoginDetails,
    DistrictRLPState,
    ContextHeader,
    NavigationByHeaderSelection,
    DistrictRLPState,
    CommonFilterData,
    DistrictRlpGridData,
    sidePanelApiFailed,
    SortData,
    popUp,
    dstCsvDownload,
    monthRangeObj,
    selAll,
    toggleData,
    AgpCSV,
  };
};

export default connect(
  mapStateToProps,
  {
    DRLP_loading_Icon,
    District_RLP_Grid_Chart_Table_API,
    District_Level_RLP_Chart_API,
    District_Level_Scroll_Data,
    District_Class_Level_RLP_Chart_API,
    District_Class_Grid_Chart_Table_API,
    Selected_Levels,
    Chart_loading_Failed,
    DSTRLP_CSVDATA_DOWNLOAD_APICALL,
    DSTRLP_CSVDATA_DOWNLOAD_RESET,
    DSTRLP2_CSVDATA_DOWNLOAD_APICALL,
    DSTRLP2_CSVDATA_DOWNLOAD_RESET,
    updateDropDownData,
    updateAllMonth,
    toggleDropDown,
    updateChartDetails,
    AGPDistrictCSV,
  }
)(DistrictRLPChart);
