import District_RLP_Side_Panel from './District_RLP_Side_Panel';
import React from 'react';
import { shallow } from 'enzyme';

jest.mock('react-redux', () => ({
    connect: jest.fn().mockImplementation(() => (component) => component),
  }));
  function setup(overrides = {}) {
    const props = {
    };
    const finalProps = Object.assign(props, overrides);
    const wrapper = shallow((
        <District_RLP_Side_Panel {...finalProps} />
    ));
    return { wrapper };
  };
  describe('District_RLP_Side_Panel', () => {
    describe('renders properly', () => {
      const { wrapper } = setup();
      it('renders component', () => {
        expect(wrapper).toHaveLength(1);
      });
      it('matches snapshot', () => {
        expect(wrapper).toMatchSnapshot();
      });
    });
    describe('renders properly', () => {
      it('MakeSelectionForORR component not render default', () => {
        const { wrapper } = setup({
          "selectedLevels" : {
            "recentRecord": [{
              "fluencyFrom": 0,
              "fluencyTo": 660,
              "grade": "K",
              "readingLevel": "A",
              "recordType": "recentRecord"
            }]
          }
        });
        expect(wrapper.find('MakeSelectionForORR')).toHaveLength(0);
      });
      it('MakeSelectionForORR component will render', () => {
        const { wrapper } = setup({
          'selectBubblesFromReducer' : { default: [] }
        });
        expect(wrapper.find('MakeSelectionForORR')).toHaveLength(1);
      });
    });
  });
