import React, { Component } from 'react';
import { connect } from 'react-redux';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';
import {
  SORT_SCLRLP_GRID,
  SAVE_SORTED_SCLRLPDATA,
  SHOW_HIDE_BAR
} from '../../../Redux_Actions/District_RlpActions.jsx';
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';
import {
  navigateToClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';

class ScSidePanel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showDiv: false
    };
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text) {
    if (text && text.length > 55) {
      return (
        <React.Fragment>
          {text.substr(0, 55)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text ? text : <span>&mdash;</span>);
    }
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? 'rt-td-active'
      : '';
  }

  //to assign color
  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return ' blueColor';
    } else {
      return '';
    }
  }

  //sort school grid on click
  schoolRlpSort(sortColumn, sortType, actualArray) {
    document.getElementById('schoolRlp').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_SCLRLP_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map((actualArray, value) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(actualArray.classData, column, sortType);
        this.props.SAVE_SORTED_SCLRLPDATA(sortedArray);
      }
    });

    this.setState({ ...this.state, sideTableData: stdArray });
  }

  //to collapse school
  showCollapse(classList) {
    this.props.SHOW_HIDE_BAR({
      ...this.props.districtData.showAccordion,
      [classList]: !this.props.districtData.showAccordion[classList]
    });
  }

  // display side table
  displaySideTable(sortData, sideTableData, selectedGrades) {
    return (
      <div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec pos-rel"
          id="schoolRlp"
        >
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                'name',
                sortData.sortType
              )}
            >
              Name
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'name', 'desc')
                }
                onClick={() =>
                  this.schoolRlpSort('name', 'desc', sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(sortData, 'name', 'asc')
                }
                onClick={() => this.schoolRlpSort('name', 'asc', sideTableData)}
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "dst-rlp-scroll-body")}>
          {sideTableData.map((districtDetails, value) => (
            <div className="student-list-row-rhs-sec sc-rlp" key={value}>
              <div
                className={
                  this.props.scrollFlag ? 'expanded-group' :
                    this.props.districtData.showAccordion[
                      districtDetails.schoolName
                    ]
                      ? 'expanded-group cursor-pointer'
                      : 'collapsed-group cursor-pointer'
                }
                style={{ backgroundColor: '#F3F5FA' }}
                onClick={() => this.showCollapse(districtDetails.schoolName)}
              >
                <span className="wb-break-all">
                  {districtDetails.schoolName}&nbsp;&nbsp;(
                  {districtDetails.classData.length} Classes)
                </span>
              </div>
              {districtDetails.classData.map((studentList, value) => (
                <div
                  className={
                    'student-list-row-rhs-sec ' +
                    (this.props.scrollFlag ? 'show' : this.props.districtData.showAccordion[
                      districtDetails.schoolName
                    ]
                      ? 'show'
                      : 'hide')
                  }
                  key={value}
                >
                  <div
                    className="student-column-list-rhs-sec"
                    style={{ width: '100%' }}
                    onClick={() => { this.props.navigateToClassReport({ ...studentList, grade: 'grade_' + selectedGrades, schoolDetails: { id: districtDetails['schoolId'], name: districtDetails['schoolName'] } }, false) }}
                  >
                    <span className='cursor-pointer long-text-tooltip'>
                      {this.longTextTooltip(studentList.name)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }
  render() {
    let schoolRecords = this.props.districtData;
    let sidePanelData = this.props.districtData && this.props.districtData.districtSidePanelData;
    let sidePanelApiFailed = this.props.sidePanelApiFailed;

    let selLvls = this.props.selectedLevels && (
      this.props.selectedLevels['recentRecord'] ||
      this.props.selectedLevels['firstRecord']
    );

    if (selLvls && selLvls.length > 0) {
      return (
        <div className="container dst-popUp-wdt DistRlpside-21-20">
          {schoolRecords && !sidePanelApiFailed && <React.Fragment>
            <div className="reading-target-wrap">
              <div className="pull-left rt-left-heading">
                {this.props.currentChartInDisplay == 'SLRLP' ? (
                  <span>
                    Grades: {schoolRecords.grade}
                  </span>
                ) : this.props.currentChartInDisplay == 'CLRLP' ? (
                  <span>
                    Schools: {schoolRecords.classes}
                  </span>
                ) : (
                      ''
                    )}
              </div>
              <hr className="clearfix mb-8" />
              <div className="Readingtarget-graph">
                <div className="chart-details mb-10">
                  <div className="reading-level-label mb-8 color-1">
                    First Record Date Range:
                  <span> {schoolRecords.firstRecDR}</span>
                  </div>
                  <div className="reading-level-label color-2">
                    Recent Record Date Range:
                  <span> {schoolRecords.recentRecDR}</span>
                  </div>
                </div>
              </div>
              <div
                className="pull-right clearfix"
                style={{ marginBottom: '4px' }}
              >
                <span style={{ fontSize: '12px', fontWeight: '500' }}>
                  No. of students rostered: {schoolRecords.studentRoster}
                </span>
              </div>
              <div className="rhs-wrap drlp-rhs-wrap dist-rhs-align">
                <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                  <div className="student-list-table-main">
                    <div className="student-list-table-rhs-sec">
                      {sidePanelData && this.displaySideTable(this.props.sortData, sidePanelData, schoolRecords.grade)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </React.Fragment>}
          {!schoolRecords && !sidePanelApiFailed &&
            <React.Fragment>
              <div className="display-msg err-msg-alignment scRlp-err-msg-alignment top-30">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>

          }
          {!schoolRecords && sidePanelApiFailed && <React.Fragment>
            <div className="display-msg err-msg-alignment scRlp-err-msg-alignment top-30">
              The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
            </div>
          </React.Fragment>}
        </div>
      );
    } else {
      return (
        <MakeSelectionForORR />
      );
    }
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  {
    SORT_SCLRLP_GRID,
    SAVE_SORTED_SCLRLPDATA,
    SHOW_HIDE_BAR,
    navigateToClassReport
  }
)(ScSidePanel);
