import React, { Component } from "react";
import { dataSorting } from "../../ReusableComponents/OrrReusableComponents";
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';

class DistrictFASidePanelComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showDiv: false,
      accordionList: {}
    };
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text

  longTextTooltip(text) {
    if (text && text.length > 55) {
      return (
        <React.Fragment>
          {text.substr(0, 55)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text ? text : <span>&mdash;</span>)
    }
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? "rt-td-active"
      : "";
  }

  //to assign color
  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return " blueColor";
    } else {
      return "";
    }
  }

  //sort school grid on click
  schoolRlpSort(sortColumn, sortType, actualArray) {
    document.getElementById("districtFA").scrollTo(0, 0);
    this.sortData(sortColumn, sortType, actualArray);
    this.props.updateSortColumn(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    stdArray.map((actualArray) => {
      if (actualArray.length != 0) {
        sortedArray = dataSorting(
          actualArray.classData,
          column,
          sortType
        );
      }

    });
    this.props.updateSortData(stdArray);
  }

  //to collapse school
  showCollapse(classList) {
    this.setState({
      ...this.state,
      accordionList: {
        ...this.state.accordionList,
        [classList]: !this.state.accordionList[classList]
      }
    });

  }

  // display side table
  displaySideTable(sortData, sideTableData, grade) {
    let accordion = this.props.panelData["accordionList"]
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="districtFA"
        >
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                sortData,
                "name",
                sortData.sortType
              )}
            >
              School/Class
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "name", "desc")
                }
                onClick={() =>
                  this.schoolRlpSort("name", "desc", sideTableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(sortData, "name", "asc")
                }
                onClick={() =>
                  this.schoolRlpSort("name", "asc", sideTableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>

        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "dfa-scroll-body")}>
          {sideTableData.map((schoolDetails, mainIndex) => (
            <div className="student-list-row-rhs-sec sc-rlp" key={mainIndex}>
              <div
                className={
                  this.props.scrollFlag ? 'expanded-group ' : accordion[mainIndex]
                    ? "expanded-group cursor-pointer"
                    : "collapsed-group cursor-pointer"
                }
                style={{ backgroundColor: "#F3F5FA" }}
                onClick={() => { this.props.setAccordionState(mainIndex) }}
              >
                <span>
                  {schoolDetails["schoolName"]}&nbsp;&nbsp;(
                  {schoolDetails["classData"].length}
                  &nbsp;classes)
                </span>
              </div>
              {schoolDetails["classData"].map((studentList, value) => (
                <div
                  className={
                    "student-list-row-rhs-sec " +
                    (this.props.scrollFlag ? 'show' : accordion[mainIndex]
                      ? "show"
                      : "hide")
                  }
                  key={value}
                >
                  <div className="student-column-list-rhs-sec" onClick={() => { this.props.navigateToClassReport({ ...studentList, schoolDetails: {  id: schoolDetails['schoolId'], name: schoolDetails['schoolName'] } , grade: `grade_${(grade || '').toLocaleLowerCase()}` }) }}>
                    <span className='cursor-pointer wb-break-all long-text-tooltip'>
                      {this.longTextTooltip(studentList.name)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }
  render() {
    let sidePanelData;
    let sidePanelApiFailed;
    if (this.props.panelData) {
      sidePanelData = this.props.panelData["tableData"];
      sidePanelApiFailed = this.props.sidePanelApiFailed
    }


    let schoolRecords =
      sidePanelData && sidePanelData["selectedRecordTypeDetails"];
    // let sidePanelData = this.props.schoolData.schoolSidePanelData;

    let key =
      this.props.bubblesSelected && Object.keys(this.props.bubblesSelected)[0];
    let selLvls = key && this.props.bubblesSelected[key];

    if (selLvls && selLvls.length > 0) {
      return (
        <div
          style={{ width: "431px", paddingLeft: "0px", paddingRight: "0px" }}
        >
          {sidePanelData && !sidePanelApiFailed &&
            <React.Fragment>
              <div className="reading-target-wrap">
                <div className="pull-left rt-left-heading">
                  {/* <span>{schoolRecords["recordTitle"]}</span>
                  <br /> */}
                  <span>
                    Grade: {selLvls[0]["grade"]}
                  </span>
                </div>
                <hr className="clearfix mb-8" />
                <div className="Readingtarget-graph">
                  <div className="chart-details mb-10">
                    <div className="reading-level-label mb-8 color-1">
                      First Record Date Range:
                 <span> {schoolRecords["firstRecordDateRange"]}</span>
                    </div>
                    <div className="reading-level-label color-1">
                      Recent Record Date Range:
                 <span> {schoolRecords["recentRecordDateRange"]}</span>
                    </div>
                  </div>
                </div>
                <div
                  className="pull-right clearfix"
                  style={{ marginBottom: "4px" }}
                >
                  <span style={{ fontSize: "12px", fontWeight: "500" }}>
                    No. of students rostered:{" "}
                    {schoolRecords["noOfStudentsRoastered"]}
                  </span>
                </div>
                <div className="rhs-wrap sc_rhs_wrap">
                  <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                    <div className="student-list-table-main scrh-rhs-row">
                      <div className="student-list-table-rhs-sec">
                        {this.displaySideTable(
                          this.props.sortData,
                          sidePanelData["recordData"],
                          selLvls[0]["grade"]
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </React.Fragment>}


          {!sidePanelData && !sidePanelApiFailed &&
            <React.Fragment>
              <div className="display-msg err-msg-alignment cfp-err-msg-alignment top-30">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>

          }
          {!sidePanelData && sidePanelApiFailed && <React.Fragment>
            <div className="display-msg err-msg-alignment cfp-err-msg-alignment top-30">
              The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
            </div>
          </React.Fragment>}
        </div>
      );
    } else {
      return (
        <div
          className="container"
          style={{ width: "431px", paddingLeft: "0px", paddingRight: "0px" }}
        >
          <MakeSelectionForORR />
        </div>
      );
    }
  }
}

export default DistrictFASidePanelComponent;
