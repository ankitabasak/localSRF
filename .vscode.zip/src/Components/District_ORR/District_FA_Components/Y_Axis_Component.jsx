import React, { Component } from 'react';
import { getAxisColor, getAxisBgColor } from './bubbleConfiguration';
import topEnd from '../../../../public/assets/orr/rlp-screen/top-end.svg';
import topEndActive from '../../../../public/assets/orr/rlp-screen/top-end-active.svg';

import topNext from '../../../../public/assets/orr/rlp-screen/top-next-inactive.svg';
import topNextActive from '../../../../public/assets/orr/rlp-screen/top-next.svg';
import belowPrev from '../../../../public/assets/orr/rlp-screen/below-prev.svg';
import belowPrevActive from '../../../../public/assets/orr/rlp-screen/below-prev-active.svg';

import belowEnd from '../../../../public/assets/orr/rlp-screen/below-end.svg';
import belowEndActive from '../../../../public/assets/orr/rlp-screen/below-end-active.svg';
import prevEnd from '../../../../public/assets/orr/rlp-screen/x-prev-end.svg';
import xPrev from '../../../../public/assets/orr/rlp-screen/x-prev.svg';
import prevEndActive from '../../../../public/assets/orr/rlp-screen/x-prev-end-active.svg';
import xPrevActive from '../../../../public/assets/orr/rlp-screen/x-prev-active.svg';

class YAxisComponent extends Component {
  constructor(props) {
    super(props);
  }

  getAxisBorderColor(readingLevel) {
    return {
      borderRight: `4px solid ` + getAxisColor(readingLevel)
    };
  }
  getBgColor(readingLevel) {
    return { backgroundColor: getAxisBgColor(readingLevel) };
  }
  render() {
    let axisData = this.props.axisData;

    return (
      <div>
        <div className="reading-level-section pull-left clearfix printmt-3">
          <div className="mb-2" onClick={this.props.scrollToTop}>
            {axisData['yScrollIndex'] <
              axisData['completeReadingLevels'].length - 5 ? (
                <img src={topEndActive} className="cursor-pointer" />
              ) : (
                <img src={topEnd} className="no-pointer" />
              )}
          </div>
          <div className="mb-3" onClick={this.props.scrollUp}>
            {axisData['yScrollIndex'] <
              axisData['completeReadingLevels'].length - 5 ? (
                <img src={topNextActive} className="cursor-pointer" />
              ) : (
                <img src={topNext} className="no-pointer" />
              )}
          </div>
          <ul>
            {this.props.axisData.YaxisDataRange &&
              this.props.axisData.YaxisDataRange.map((grade, index) => {
                return (
                  <li
                    className="pos-rel"
                    key={index}
                    style={this.getBgColor(grade)}
                  >
                    <div
                      style={this.getAxisBorderColor(grade)}
                      className="reading-level-border"
                    ></div>
                    <span>{grade}</span>
                  </li>
                );
              })}
          </ul>
          <div className="mt-2" onClick={this.props.scrollDown}>
            {axisData['yScrollIndex'] > 0 ? (
              <img className="cursor-pointer" src={belowPrevActive} />
            ) : (
                <img src={belowPrev} className="no-pointer" />
              )}
          </div>
          <div className="mt-2" onClick={this.props.scrollToBottom}>
            {axisData['yScrollIndex'] > 0 ? (
              <img src={belowEndActive} className="cursor-pointer" />
            ) : (
                <img src={belowEnd} className="no-pointer" />
              )}
          </div>
          <div className="btm-arrow-lft">
            <div className="btm-ic-rhs-last" onClick={this.props.scrollExtremeLeft}>
              {axisData['xScrollIndex'] > 0 ? (
                <img src={prevEndActive} className="cursor-pointer" />
              ) : (
                  <img src={prevEnd} className="no-pointer" />
                )}
            </div>
            <div className="btm-ic-rhs-prev" onClick={this.props.scrollLeft}>
              {axisData['xScrollIndex'] > 0 ? (
                <img src={xPrevActive} className="cursor-pointer" />
              ) : (
                  <img src={xPrev} className="no-pointer" />
                )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default YAxisComponent;
