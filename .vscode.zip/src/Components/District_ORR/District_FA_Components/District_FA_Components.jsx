import "./District_FA_Styles.css";

import {
  DISTRICT_FA_CHART_API_CALL,
  DISTRICT_FA_SIDEPANEL_API_CALL,
  DSTFA_CSVDATA_DOWNLOAD_APICALL,
  DSTFA_CSVDATA_DOWNLOAD_RESET,
  SAVE_SORTED_SCFADATA,
  SORT_SCFA_GRID,
  UPDATE_CHARTDATA_FOR_NEWGRADE,
  UPDATE_SCROLL_DATA,
  UPDATE_SELECTED_BUBLIST,
  Update_Accordion_State
} from "../../../Redux_Actions/District_FA_Action.jsx";
import React, { Component } from "react";
import { getCommonHeaders, getDateFormat } from '../../ReusableComponents/OrrReusableComponents';

import { AGPDistrictCSV } from "../../../Redux_Actions/District_Report_Actions";
import { AGP_MODELS, ORR_DISTRICT_AGP_MODELS } from "../../../Utils/globalVars";
import { CSVLink } from "react-csv";
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import Confirmation_AgpPopup from "../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup";
import CsvIcon from '../../../../public/images/ic_save.svg';
import DistrictFAChartComponent from "./District_FA_Chart_Component.jsx";
import DistrictFASidePanelComponent from "./District_FA_SidePanel.jsx";
import Filter from "../../ORR/FilterComponents/Filter";
import NoRecordsData from "../../../Utils/No_Data_Found";
import PrintDstFa from '../../ReusableComponents/PrintOrrCharts/Dst_FaPrint.jsx';
import Spinner from "../../ReusableComponents/Spinner/Spinner.jsx";
import { connect } from "react-redux";
import { csvDownload } from "../../../Utils/CSVDownload/AGPReports";
import {
  navigateToClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";

class DistrictFluencyAnalysisComponent extends Component {
  constructor() {
    super();
    this.state = {
      sidepanelApiInRun: false,
      showAgpConfirmationPopup: false,
    };
  }

  componentDidMount() {
    this.props.DISTRICT_FA_CHART_API_CALL(this.props.LoginDetails["JWTToken"], getCommonHeaders(this.props, 'district'));
  }
  updateChartDataForNewGrade(gradeSelected) {
    let commonHeaders = getCommonHeaders(this.props, 'district');
    if (!this.state.sidepanelApiInRun) {
      this.setState({ ...this.state, sidepanelApiInRun: true });
      setTimeout(() => {
        this.props.UPDATE_CHARTDATA_FOR_NEWGRADE(
          this.props.SFA_Chart_API_Response,
          gradeSelected,
          commonHeaders,
          this.props.LoginDetails["JWTToken"]
        );
        this.setState({ ...this.state, sidepanelApiInRun: false });
      }, 1000);
    }

  }

  updateScrollData(data) {
    this.props.UPDATE_SCROLL_DATA(data);
  }

  updateSelectedBubList(bubList) {
    this.props.UPDATE_SELECTED_BUBLIST(bubList);
    let key = bubList && Object.keys(bubList)[0];
    let payLoadForGrid = {
      grade: "",
      recentRecord: key == "recentRecord" ? true : false,
      selectionList: []
    };
    if (key && bubList[key] && bubList[key].length > 0) {
      payLoadForGrid["grade"] = bubList[key][0]["grade"];
      bubList[key].forEach(obj => {
        payLoadForGrid["selectionList"].push({
          readingLevel: obj["readingLevel"],
          fluencyFrom: obj["fluencyFrom"],
          fluencyTo: obj["fluencyTo"]
        });
      });

      this.props.DISTRICT_FA_SIDEPANEL_API_CALL(
        this.props.LoginDetails["JWTToken"],
        {
          ...getCommonHeaders(this.props, 'district'),
          // externalFilter: externalFilter,
          // internalFilter: this.props.CommonFilterData,
          selectedBubblesCriteria: payLoadForGrid
        }
      );
    }
  }
  // Download csv data
  downLoadCSVData() {
    const payload = {
      districtChartType: {
        "allGrades": true,
        "chartName": "DFA",
        "gradeValue": null
      },
      ...getCommonHeaders(this.props, 'district'),
    };
    if (AGP_MODELS && ORR_DISTRICT_AGP_MODELS) {
      csvDownload(this.props, payload);
    } else {
      this.props.DSTFA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
      this.props.DSTFA_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, payload);
    }
  }

  render() {
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedDistrict.name;
    if (this.props.DstCsvDownload && this.props.DstCsvDownload['downloadInProgress'] && this.props.DstCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.DSTFA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    return (
      <React.Fragment>
        <Filter></Filter>
        {this.props.SFA_Chart_Constructed_Data && (
          <main>
            {AGP_MODELS && ORR_DISTRICT_AGP_MODELS && this.props.AgpCSV.popupConfirmation &&
              <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} />}
            <section>
              <div className="container container-resolution cfa school-fa dist-fa">
                <div className="row mt-10 mt-8 " id="testDst">
                  {this.props.DstCsvDownload && this.props.DstCsvDownload['csvData'] &&
                    <CSVLink
                      ref="groupCSV"
                      headers={this.props.DstCsvDownload['csvData'] && this.props.DstCsvDownload['csvData']['header']}
                      data={this.props.DstCsvDownload['csvData'] && this.props.DstCsvDownload['csvData']['data']}
                      style={{ display: 'none' }}
                      // filename={"DSTFA_CSV.csv"}
                      filename={`${csvFileName}.csv`}
                    />}
                  <div className="dst-csv-icon-alignment" onClick={() => !this.props.DstCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                    {this.props.DstCsvDownload && this.props.DstCsvDownload['downloadInProgress'] ?
                      <span className="csv_download_icon">
                        <i className="material-icons">autorenew</i>
                      </span> :
                      <span className="csv_download_icon">
                        <img src={CsvIcon} width="20" height="20" />
                      </span>}
                  </div>
                  <DistrictFAChartComponent
                    updateGradeSelected={grade =>
                      this.updateChartDataForNewGrade(grade)
                    }
                    data={this.props.SFA_Chart_Constructed_Data}
                    updateSelectedBubble={bubList => {
                      this.updateSelectedBubList(bubList);
                    }}
                    readingLevels={
                      this.props.SFA_Chart_Constructed_Data[
                      "visibleReadingLvls"
                      ]
                    }
                    updateScrollData={scrollData => {
                      this.updateScrollData(scrollData);
                    }}
                    selectedBubsFromReducer={this.props.SFA_Selected_Bubbles}
                  />
                  <DistrictFASidePanelComponent
                    navigateToClassReport={this.props.navigateToClassReport}
                    updateSortData={(array) => { this.props.SAVE_SORTED_SCFADATA(array) }}
                    updateSortColumn={(column, sortType) => { this.props.SORT_SCFA_GRID(column, sortType) }}
                    panelData={this.props.SFA_SidePanelData}
                    bubblesSelected={this.props.SFA_Selected_Bubbles}
                    sortData={this.props.SortData}
                    setAccordionState={(index) => { this.props.Update_Accordion_State(this.props.SFA_SidePanelData["accordionList"], index) }}
                  />

                </div>
                {this.props.SFA_SidePanelData &&
                  <span className="print-icon-class-btn">
                    <PrintDstFa
                      scrollFlag={true}
                      selectedFilter={this.props.CommonFilterData}
                      studentDetails={this.props.ContextHeader}
                      navSelected={this.props.NavigationByHeaderSelection}
                      data={this.props.SFA_Chart_Constructed_Data}
                      readingLevels={
                        this.props.SFA_Chart_Constructed_Data[
                        "visibleReadingLvls"
                        ]
                      }
                      selectedBubsFromReducer={this.props.SFA_Selected_Bubbles}
                      panelData={this.props.SFA_SidePanelData}
                      bubblesSelected={this.props.SFA_Selected_Bubbles}
                      sortData={this.props.SortData}
                    />
                  </span>}
              </div>
            </section>
          </main>
        )}
        {!this.props.SFA_Chart_Constructed_Data && !this.props.apiLoadFail && !this.props.noData && (
          <Spinner startSpinner={true} showTimeOut={this.timeOut} />
        )}
        {/* {!chartData && this.props.DistrictRLPState.timeOut && (
            <TimeOut tryAgain={this.getCFData} />
          )} */}
        {this.props.noData && (
          <NoRecordsData NodataFound={'dataNotAvail'} />
        )}
        {this.props.apiLoadFail && (
          <ChartNotLoad />
        )}
      </React.Fragment>
    );
  }
}

const mapStateToProps = ({
  District_FA_Reducer,
  Universal,
  CommonFilterDetails,
  Authentication
}) => {
  const {
    isApiLoading,
    noChartData,
    apiLoadFail,
    noData,
    apiTimeOut,
    SortData,
    SFA_Chart_API_Response,
    SFA_Chart_Constructed_Data,
    SFA_Selected_Bubbles,
    SFA_SidePanelData,
    DstCsvDownload
  } = District_FA_Reducer;
  const { ContextHeader, NavigationByHeaderSelection, AgpCSV } = Universal;
  const { CommonFilterData } = CommonFilterDetails;
  const { LoginDetails } = Authentication;

  return {
    NavigationByHeaderSelection,
    ContextHeader,
    CommonFilterData,
    isApiLoading,
    apiLoadFail,
    noData,
    noChartData,
    apiTimeOut,
    SFA_Chart_API_Response,
    SFA_Chart_Constructed_Data,
    SFA_Selected_Bubbles,
    SFA_SidePanelData,
    SortData,
    LoginDetails,
    DstCsvDownload,
    AgpCSV,
  };
};

export default connect(mapStateToProps, {
  DISTRICT_FA_CHART_API_CALL,
  UPDATE_SELECTED_BUBLIST,
  UPDATE_CHARTDATA_FOR_NEWGRADE,
  UPDATE_SCROLL_DATA,
  DISTRICT_FA_SIDEPANEL_API_CALL,
  SAVE_SORTED_SCFADATA,
  SORT_SCFA_GRID,
  Update_Accordion_State,
  navigateToClassReport,
  DSTFA_CSVDATA_DOWNLOAD_APICALL,
  DSTFA_CSVDATA_DOWNLOAD_RESET,
  AGPDistrictCSV,
})(DistrictFluencyAnalysisComponent);
