import React, { Component } from "react";
import "../../../../public/css/bootstrap.min.css";
import "./Summary_Filter.css";

import FilterBarComponent from "./Summary_FilterBar";
import { connect } from "react-redux";

import {
  summaryShowPopUpFnt,
  SUMMARY_UPDATE_FILTER,
  SUMMARY_SAVE_SELECTED_FILTER,
  SUMMARY_RESET_FILTER
} from "../../../Redux_Actions/SummaryFilterActions.jsx";
import {
  Sum_Sc_RLP_Chart_API,
  School_Show_loading_Icon
} from "../../../Redux_Actions/School_RlpActions.jsx";
import {
  CLASS_READING_LEVEL_PROGRESS,
  CHART_SPINNER
} from "../../../Redux_Actions/C_ReadingLevelAction.jsx";
import { Sum_Dst_RLP_Chart_API } from "../../../Redux_Actions/District_RlpActions.jsx";
import { S_RLP_API_CALL } from "../../../Redux_Actions/S_ReadingLevelAction.jsx";
import { getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';

class SummaryFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      proficiency: {
        independent: props.SummaryFilterData.proficiency.independent,
        instructional: props.SummaryFilterData.proficiency.instructional,
        frustrational: props.SummaryFilterData.proficiency.frustrational
      },
      language: {
        english: props.SummaryFilterData.language.english,
        spanish: props.SummaryFilterData.language.spanish
      },
      category: {
        fiction: props.SummaryFilterData.category.fiction,
        nonfiction: props.SummaryFilterData.category.nonfiction
      },
      type: {
        unseen: props.SummaryFilterData.type.unseen,
        seen: props.SummaryFilterData.type.seen
      },
      filter: true
    };

    this.ToggleFilter = this.ToggleFilter.bind(this);
    this.OnChange = this.OnChange.bind(this);
    this.OnFilterMultipleUpdate = this.OnFilterMultipleUpdate.bind(this);
  }

  componentWillUnmount(){
    this.setState({ filter: !this.state.filter });
    !this.state.filter && this.props.SUMMARY_RESET_FILTER(this.props.summaryFilterDataSaved)
  }

  enableFilter(flag) {
    this.props.summaryShowPopUpFnt(flag);
  }
  //  Toggle function for filter
  ToggleFilter() {
    this.setState({ filter: !this.state.filter });
    !this.state.filter && this.props.SUMMARY_RESET_FILTER(this.props.summaryFilterDataSaved)
  }

  filterFnc(val) {
    let firstArray = [];
    firstArray = val.splice(0, 4);
    return { firstArray: firstArray, val: val }
  }


  //Function to update the state value based on selection
  OnChange(data, key) {
    if (
      this.props.SummaryFilterData.proficiency.hasOwnProperty(key) &&
      this.props.SummaryFilterData.proficiency[key] === data
    ) {
      this.props.SUMMARY_UPDATE_FILTER({
        proficiency: {
          proficiency: {
            ...this.props.SummaryFilterData.proficiency,
            [key]: !this.props.SummaryFilterData.proficiency[key] //to update the variable keys
          }
        },
        key: 'proficiency'
      })
    }
    if (
      this.props.SummaryFilterData.language.hasOwnProperty(key) &&
      this.props.SummaryFilterData.language[key] === data
    ) {
      this.props.SUMMARY_UPDATE_FILTER({
        language: {
          language: {
            ...this.props.SummaryFilterData.language,
            [key]: !this.props.SummaryFilterData.language[key]
          }
        }, key: 'language'
      });
    }
    if (
      this.props.SummaryFilterData.category.hasOwnProperty(key) &&
      this.props.SummaryFilterData.category[key] === data
    ) {
      this.props.SUMMARY_UPDATE_FILTER({
        category: {
          category: {
            ...this.props.SummaryFilterData.category,
            [key]: !this.props.SummaryFilterData.category[key]
          }
        }, key: 'category'
      });
    }
    if (this.props.SummaryFilterData.type.hasOwnProperty(key) &&
      this.props.SummaryFilterData.type[key] === data) {
      this.props.SUMMARY_UPDATE_FILTER({
        type: {
          type: {
            ...this.props.SummaryFilterData.type,
            [key]: !this.props.SummaryFilterData.type[key]
          }
        }, key: 'type'
      });
    }
  }

  //Function to update the store values and show the filter bar based on api response
  OnFilterMultipleUpdate() {
    this.setState({ filter: !this.state.filter });
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };

    if (this.props.NavigationByHeaderSelection.student) {
      let Req_Payload = getCommonHeaders(summaryFilterData, 'student');
      this.props.S_RLP_API_CALL(
        this.props.LoginDetails.JWTToken,
        Req_Payload,
        "student"
      );
    }
    if (this.props.NavigationByHeaderSelection.class) {
      let payLoad = {
        ...getCommonHeaders(summaryFilterData, 'class'),
        value: "class"
      };
      this.props.CHART_SPINNER();
      this.props.CLASS_READING_LEVEL_PROGRESS(
        this.props.LoginDetails.JWTToken,
        payLoad
      );
    }
    if (this.props.NavigationByHeaderSelection.school) {
      let commonHeaders = getCommonHeaders(summaryFilterData, 'school');
      let payLoad = {
        ...commonHeaders
      };
      this.props.School_Show_loading_Icon();
      this.props.Sum_Sc_RLP_Chart_API(
        this.props.LoginDetails.JWTToken,
        payLoad
      );
    }
    if (this.props.NavigationByHeaderSelection.district) {
      let commonHeaders = getCommonHeaders(summaryFilterData, 'district');
      let payLoad = {
        ...commonHeaders,
      };
      this.props.Sum_Dst_RLP_Chart_API(
        this.props.LoginDetails.JWTToken,
        payLoad
      );
    }
    delete this.state.filter;
    this.props.SUMMARY_SAVE_SELECTED_FILTER(this.props.SummaryFilterData)
  }

  render() {
    let show = this.state.filter ? "" : "show";
    let filterSel = this.props.SummaryFilterData;
    let filterVal = [...this.props.summaryConstructedData]
    return (
      <div className="pos-rel">
        <div>
          <div className="container container-alignment ipad-view-cont">
            <div className="row">
              <div className="col-lg-12 ptop-5 pos-rel">
                <button
                  className={
                    "pull-left filter-btn padt-2 " +
                    (this.state.filter ? "" : "collapsed")
                  }
                  type="button"
                  onClick={this.ToggleFilter}
                  aria-expanded={!this.state.filter}
                >
                  <span
                    className={
                      "close-icon " +
                      (this.state.filter ? "close-filter" : "close-filter-open")
                    }
                  />
                  <span
                    className={
                      this.state.filter ? "close-filter1" : "close-filter-open1"
                    }
                  >
                    Filters
                  </span>
                </button>


                <span className="clearfix" />
                <div className={"collapse slide-shadow pl-25 summary-filter-overlay " + show}>
                  {/* Proficiency section start */}
                  <div className="form-group filter-fg">
                    <div className="pull-left Proficiency-wrap">
                      <p className="filter-category-title">Proficiency</p>
                      <div className="box summary-filter-box">
                        <div
                          className="action-label"
                          onClick={() =>
                            this.OnChange(
                              filterSel.proficiency.independent,
                              "independent"
                            )
                          }
                        >
                          <button
                            className={
                              "btn btn-rounded filter-bg  " +
                              (filterSel.proficiency.independent
                                ? "light-blue-bg"
                                : "filter-hover")
                            }
                          >
                            <i
                              className={
                                "fa circle-res light-blue " +
                                (filterSel.proficiency.independent
                                  ? "check-circle"
                                  : "check-circle-independent")
                              }
                            />
                            Independent
                          </button>
                        </div>
                        <div
                          className="action-label"
                          onClick={() =>
                            this.OnChange(
                              filterSel.proficiency.instructional,
                              "instructional"
                            )
                          }
                        >
                          <button
                            className={
                              "btn btn-rounded filter-bg " +
                              (filterSel.proficiency.instructional
                                ? "instructional-bg"
                                : "filter-hover")
                            }
                          >
                            <i
                              className={
                                "fa circle-res blue " +
                                (filterSel.proficiency.instructional
                                  ? "check-circle"
                                  : "check-circle-instructional")
                              }
                            />
                            Instructional
                          </button>
                        </div>
                        <div
                          className="action-label"
                          onClick={() =>
                            this.OnChange(
                              filterSel.proficiency.frustrational,
                              "frustrational"
                            )
                          }
                        >
                          <button
                            className={
                              "btn btn-rounded filter-bg " +
                              (filterSel.proficiency.frustrational
                                ? "light-yellow-bg"
                                : "filter-hover")
                            }
                          >
                            <i
                              className={
                                "fa circle-res light-yellow  " +
                                (filterSel.proficiency.frustrational
                                  ? "check-circle"
                                  : "check-circle-frustrational")
                              }
                            />
                            Frustrational
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* Proficiency section end */}
                  {/* Language Section start */}
                  <div className="pull-left language-wrap">
                    <p className="filter-category-title">Language</p>
                    <div className="box summary-filter-box">
                      <div
                        className="action-label "
                        onClick={() =>
                          this.OnChange(filterSel.language.english, "english")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterSel.language.english ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa circle-res light-blue " +
                              (filterSel.language.english
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          English
                        </button>
                      </div>
                      <div
                        className="action-label "
                        onClick={() =>
                          this.OnChange(filterSel.language.spanish, "spanish")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterSel.language.spanish ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterSel.language.spanish
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Spanish
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* Language Section end */}

                  {/* <!--Category Section start --> */}
                  <div className="pull-left category-wrap">
                    <p className="filter-category-title">Category</p>
                    <div className="box summary-filter-box">
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(filterSel.category.fiction, "fiction")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterSel.category.fiction ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterSel.category.fiction
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Fiction
                        </button>
                      </div>
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(
                            filterSel.category.nonfiction,
                            "nonfiction"
                          )
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterSel.category.nonfiction
                              ? ""
                              : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa circle-res " +
                              (filterSel.category.nonfiction
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Nonfiction
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* <!-- Category Section End --> */}

                  {/* <!--Type Section start --> */}
                  <div className="pull-left type-wrap">
                    <p className="filter-category-title">Type</p>
                    <div className="box summary-filter-box">
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(filterSel.type.unseen, "unseen")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterSel.type.unseen ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterSel.type.unseen
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Unseen
                        </button>
                      </div>
                      <div
                        className="action-label"
                        onClick={() =>
                          this.OnChange(filterSel.type.seen, "seen")
                        }
                      >
                        <button
                          className={
                            "btn btn-rounded filter-bg " +
                            (filterSel.type.seen ? "" : "filter-hover")
                          }
                        >
                          <i
                            className={
                              "fa  circle-res " +
                              (filterSel.type.seen
                                ? "check-circle"
                                : "uncheck-circle")
                            }
                          />
                          Seen
                        </button>
                      </div>
                    </div>
                  </div>
                  {/* <!-- Type Section End --> */}

                  {/* <!--Type Section start --> */}
                  <div className="pull-left apply-btn-wrap pos-rel">
                    <div
                      className="action-label sum-apply-btn-pos"
                      onClick={() => this.OnFilterMultipleUpdate()}
                    >
                      <a className="btn btn-rounded apply-btn">Apply</a>
                    </div>
                  </div>
                  {/* <!-- Type Section End --> */}
                  <div className="blank-filter clearfix" />
                </div>

                {/* Based on the response from API show the selected filters onclick of apply */}
                <div
                  className={"filter-sel filter-align " + (this.state.filter ? "show" : "hide")}

                >
                  <FilterBarComponent
                    enableFilter={(flag) => this.enableFilter(flag)}
                    showList={this.props.showPopup}
                    summaryTab={true}
                    filterSel={this.filterFnc(filterVal)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  SummaryFilterDetails,
  Authentication
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { SummaryFilterData, summaryShowPopUpFnt, summaryConstructedData, summaryFilterDataSaved } = SummaryFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    SummaryFilterData,
    summaryShowPopUpFnt,
    summaryConstructedData,
    summaryFilterDataSaved
  };
};

export default connect(mapStateToProps, {
  SUMMARY_UPDATE_FILTER,
  S_RLP_API_CALL,
  CLASS_READING_LEVEL_PROGRESS,
  Sum_Sc_RLP_Chart_API,
  School_Show_loading_Icon,
  Sum_Dst_RLP_Chart_API,
  summaryShowPopUpFnt,
  CHART_SPINNER,
  SUMMARY_RESET_FILTER,
  SUMMARY_SAVE_SELECTED_FILTER
})(SummaryFilter);
