import React, { Component } from 'react';
import '../../../../public/css/bootstrap.min.css';
import './Summary_Filter.css';
import 'font-awesome/css/font-awesome.min.css';

class FilterBarComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      backGroundColor: {
        "Independent": "light-blue-bg",
        "Instructional": "instructional-bg",
        "Frustrational": "light-yellow-bg",
        "English": "filter-bg",
        "Spanish": "filter-bg",
        "Fiction": "filter-bg",
        "Nonfiction": "filter-bg",
        "Unseen": "filter-bg",
        "Seen": "filter-bg",
      }
    }
  }


  showBox() {
    this.props.enableFilter(!this.props.showList)
  }

  selFilterColor(obj) {
    return this.state.backGroundColor[obj]
  }
  render() {
    return (
      <React.Fragment>
        <div>
          <ul>
            {this.props.filterSel.firstArray.map((obj) => {
              return (
                <li>
                  <a className={"filter-button " + (this.selFilterColor(obj))}>
                    <i className="fa circle-res light-blue check-circle" />
                    {obj}
                  </a>
                </li>
              )
            })
            }
            {this.props.filterSel.val.length > 0 &&
              <li class="context_header_more_options "
                onClick={() => {
                  this.showBox()
                }}>
                <span className="context-header-title">
                  <i class="material-icons">
                    more_vert
                        </i>
                </span>
                {this.props.showList && this.props.filterSel.val.length > 0 &&
                  <div ref={(node) => this.MoreOptionsRef = node} className="filter-box">
                    {this.props.filterSel.val.map((obj) => {
                      return (
                        <li>
                          <a className={"filter-button " + (this.selFilterColor(obj))}>
                            <i className="fa circle-res light-blue check-circle" />
                            {obj}
                          </a>
                        </li>
                      )
                    })
                    }
                  </div>}
              </li>}
          </ul>
        </div>


      </React.Fragment >

    );
  }
}

export default FilterBarComponent;
