import React, { PureComponent } from 'react';
import './Summary.css';
import { connect } from 'react-redux'
import SummaryFilter from './SummaryFilterComponent/Summary_Filter.js';
import ORR_Summary from './ORR_Summary.jsx';
import { SHOW_SUMMARY_POPUP } from '../../Redux_Actions/SummaryTabAction.jsx';
import ExpandIcon from '../../../public/assets/orr/rlp-screen/ic_extend.svg'
class SummaryTab extends PureComponent {

    constructor(props) {
        super(props);
        this.showSummary = this.showSummary.bind(this);
    }

    showSummary() {
        this.props.SHOW_SUMMARY_POPUP();
    }

    render() {
        const { widgetForSummaryReports } = this.props
        let nav = this.props.NavigationByHeaderSelection;
        console.log(" ORRWidget summary.jsx this.props.widgetForSummaryReports", widgetForSummaryReports, nav)
        return (
            <div className="summary-scroll">
                <div className="container summary-container">
                    {widgetForSummaryReports ? null : <div className="summary-box1 pull-left">
                        {nav.class && <SummaryCRlpChart />}
                    </div>}
                    {widgetForSummaryReports ? null : <div className="summary-box2 pull-left">

                    </div>}
                    {widgetForSummaryReports ? null : <div className="summary-box3 pull-left">

                    </div>}
                    <div className="summary-box4 pull-left">
                        {widgetForSummaryReports ? null : <div className="header-title sum-padding">Oral Reading Records | Reading Level Progress</div>}
                        {widgetForSummaryReports ? null : <div className="group-title-sum expand-img" onClick={this.showSummary}>
                            <img src={ExpandIcon} />
                            <div className="hover-expand">
                                Expand
                                <div className="tooltip-dot-sum" />
                            </div>
                        </div>}

                        {widgetForSummaryReports ? null : <hr className="rectangle mar-0 sum-hr" />}
                        <SummaryFilter summaryEnabled={true} />
                        <ORR_Summary />

                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = ({
    Universal,
    Authentication,
    SummaryFilterDetails
}) => {
    const { LoginDetails } = Authentication;
    const { ContextHeader, NavigationByHeaderSelection } = Universal;
    const { SummaryFilterData } = SummaryFilterDetails;
    return {
        LoginDetails,
        ContextHeader,
        NavigationByHeaderSelection,
        SummaryFilterData
    };
};

export default connect(
    mapStateToProps, { SHOW_SUMMARY_POPUP }
)(SummaryTab);




// export default SummaryTab;
