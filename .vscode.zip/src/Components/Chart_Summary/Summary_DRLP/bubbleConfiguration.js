

// var getHexCode = [];
var setBubbleOject = {
  bubbleSize: '',
  fontSize: ''
};

var axisColorList = {
  A: '#EE3B33',
  B: '#EE3B33',
  C: '#EE3B33',
  D: '#91489d',
  E: '#91489d',
  PreA: '#BDC2CD',
  F: '#007cc3',
  G: '#007cc3',
  H: '#00a48a',
  I: '#00a48a',
  J: '#f9991c',
  K: '#f9991c',
  L: '#1c449c',
  M: '#1c449c',
  N: '#00acd4',
  O: '#00acd4',
  P: '#00acd4',
  Q: '#f57224',
  R: '#f57224',
  S: '#00a48a',
  T: '#00a48a',
  U: '#00a48a',
  V: '#1c449c',
  W: '#1c449c',
  X: '#1c449c',
  Y: '#ee3b33',
  Z: '#ee3b33',
  'Z+': '#ee3b33'
};

var axisBackGroundColor = {
  A: 'rgba(238,59,51,0.1)',
  B: 'rgba(238,59,51,0.1)',
  C: 'rgba(238,59,51,0.1)',
  D: 'rgba(145,72,157,0.1)',
  E: 'rgba(145,72,157,0.1)',
  PreA: 'rgba(189,194,205,0.1)',
  F: 'rgba(0,124,195,0.1)',
  G: 'rgba(0,124,195,0.1)',
  H: 'rgba(0,164,138,0.1)',
  I: 'rgba(0,164,138,0.1)',
  J: 'rgba(249,153,28,0.1)',
  K: 'rgba(249,153,28,0.1)',
  L: 'rgba(28,68,156,0.1)',
  M: 'rgba(28,68,156,0.1)',
  N: 'rgba(0,172,212,0.1)',
  O: 'rgba(0,172,212,0.1)',
  P: 'rgba(0,172,212,0.1)',
  Q: 'rgba(245,114,36,0.1)',
  R: 'rgba(245,114,36,0.1)',
  S: 'rgba(0,164,138,0.1)',
  T: 'rgba(0,164,138,0.1)',
  U: 'rgba(0,164,138,0.1)',
  V: 'rgba(28,68,156,0.1)',
  W: 'rgba(28,68,156,0.1)',
  X: 'rgba(28,68,156,0.1)',
  Y: 'rgba(238,59,51,0.1)',
  Z: 'rgba(238,59,51,0.1)',
  'Z+': 'rgba(238,59,51,0.1)'
};
// var bubbleColorList = [
//   { value: 'Instructional', hexcode: '#32AC41' },
//   { value: 'Independent', hexcode: '#1C449C' },
//   { value: 'Frustrational', hexcode: '#F9991C' }
// ];

var bubbleConfiguration = [
  { valueFrom: 0, valueTo: 9, bubbleSize: '28px', fontSize: '12px' },
  { valueFrom: 10, valueTo: 19, bubbleSize: '32px', fontSize: '12px' },
  { valueFrom: 20, valueTo: 29, bubbleSize: '36px', fontSize: '12px' },
  { valueFrom: 30, valueTo: 39, bubbleSize: '40px', fontSize: '12px' },
  { valueFrom: 40, valueTo: 49, bubbleSize: '44px', fontSize: '12px' },
  { valueFrom: 50, valueTo: 59, bubbleSize: '48px', fontSize: '14px' },
  { valueFrom: 60, valueTo: 69, bubbleSize: '52px', fontSize: '14px' },
  { valueFrom: 70, valueTo: 79, bubbleSize: '56px', fontSize: '14px' },
  { valueFrom: 80, valueTo: 89, bubbleSize: '60px', fontSize: '14px' },
  { valueFrom: 90, valueTo: 100, bubbleSize: '64px', fontSize: '14px' }
];

// export function axisColor(value) {
//   axisColorList.findIndex((item, index) => {
//     if (item.value === value) {
//       getHexCode = axisColorList[index].hexcode.toString();
//     }
//   });
//   return getHexCode;
// }

// export function bubbleColor(value) {
//   bubbleColorList.findIndex((item, index) => {
//     if (item.value === value) {
//       getHexCode = bubbleColorList[index].hexcode.toString();
//     }
//   });
//   return getHexCode;
// }
export function getBubbleConfig(value) {
  bubbleConfiguration.findIndex((item, index) => {
    if (value >= item.valueFrom && value <= item.valueTo) {
      setBubbleOject = {
        bubbleSize: bubbleConfiguration[index].bubbleSize.toString(),
        fontSize: bubbleConfiguration[index].fontSize.toString()
      };
    }
  });
  return setBubbleOject;
}

export function getAxisColor(readingLevel) {
  return axisColorList[readingLevel];
}
export function getAxisBgColor(readingLevel) {
  return axisBackGroundColor[readingLevel];
}
