import React, { Component } from 'react';
import { getAxisColor, getAxisBgColor } from './bubbleConfiguration';
import topEnd from '../../../../public/assets/orr/rlp-screen/top-end.svg';
import topEndActive from '../../../../public/assets/orr/rlp-screen/top-end-active.svg';
import topNext from '../../../../public/assets/orr/rlp-screen/top-next-inactive.svg';
import topNextActive from '../../../../public/assets/orr/rlp-screen/top-next.svg';
import belowPrev from '../../../../public/assets/orr/rlp-screen/below-prev.svg';
import belowPrevActive from '../../../../public/assets/orr/rlp-screen/below-prev-active.svg';

import belowEnd from '../../../../public/assets/orr/rlp-screen/below-end.svg';
import belowEndActive from '../../../../public/assets/orr/rlp-screen/below-end-active.svg';
import prevEnd from '../../../../public/assets/orr/rlp-screen/x-prev-end.svg';
import xPrev from '../../../../public/assets/orr/rlp-screen/x-prev.svg';
import prevEndActive from '../../../../public/assets/orr/rlp-screen/x-prev-end-active.svg';
import xPrevActive from '../../../../public/assets/orr/rlp-screen/x-prev-active.svg';
class YAxisComponent extends Component {
  getAxisBorderColor(readingLevel) {
    return {
      borderRight: `4px solid ` + getAxisColor(readingLevel),
      backgroundColor: getAxisBgColor(readingLevel)
    };
  }

  componentDidMount() { }
  render() {
    return (
      <div className="reading-level-section-srlp pull-left clearfix mt-2">
        {this.props.axisData && (
          <div>
            <div
              className="mb-1"
              onClick={() => {
                this.props.scrollReadingLevels('extremeTop');
              }}
            >
              {this.props.axisData.scrollIndex <
                this.props.axisData.allReadingLevels.length - 13
                ? <img className="cursor-pointer" src={topEndActive} /> : <img src={topEnd} />}

              {/* <img
                src={
                  this.props.axisData.scrollIndex <
                  this.props.axisData.allReadingLevels.length - 12
                    ? topEndActive
                    : topEnd
                }
              /> */}
            </div>
            <div
              className=""
              onClick={() => {
                this.props.scrollReadingLevels('up');
              }}
            >
              {this.props.axisData.scrollIndex <
                this.props.axisData.allReadingLevels.length - 13
                ? <img className="cursor-pointer" src={topNextActive} /> : <img
                  src={topNext} />}
              {/* <img
                src={
                  this.props.axisData.scrollIndex <
                    this.props.axisData.allReadingLevels.length - 12
                    ? topNextActive
                    : topNext
                }
              /> */}
            </div>
            <ul>
              {this.props.axisData.dataRange.map((readingLevel, index) => {
                return (
                  <li
                    className="level3-srlp"
                    key={index}
                    style={this.getAxisBorderColor(readingLevel)}
                  >
                    <span>{readingLevel}</span>
                  </li>
                );
              })}
            </ul>
            <div
              className="mb-1"
              onClick={() => {
                this.props.scrollReadingLevels('down');
              }}
            >
              {this.props.axisData.scrollIndex > 0
                ? <img className="cursor-pointer" src={belowPrevActive} /> : <img
                  src={belowPrev} />}
              {/* <img
                src={
                  this.props.axisData.scrollIndex > 0
                    ? belowPrevActive
                    : belowPrev
                }
              /> */}
            </div>
            <div
              className=""
              onClick={() => {
                this.props.scrollReadingLevels('extremeBottom');
              }}
            >
              {this.props.axisData.scrollIndex > 0
                ? <img className="cursor-pointer" src={belowEndActive} /> : <img
                  src={belowEnd} />}
              {/* <img
                src={
                  this.props.axisData.scrollIndex > 0
                    ? belowEndActive
                    : belowEnd
                }
              /> */}
            </div>
            <div className="btm-arrow-lft-srlp">
              <div
                className="btm-ic-rhs-last-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('extremeLeft');
                }}
              >
                {this.props.axisData.xScrollIndex > 0
                  ? <img className="cursor-pointer" src={prevEndActive} /> : <img
                    src={prevEnd} />}
                {/* <img
                  src={
                    this.props.axisData.xScrollIndex > 0
                      ? prevEndActive
                      : prevEnd
                  }
                /> */}
              </div>
              <div
                className="btm-ic-rhs-prev-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('left');
                }}
              >
                {this.props.axisData.xScrollIndex > 0
                  ? <img className="cursor-pointer" src={xPrevActive} /> : <img
                    src={xPrev} />}
                {/* <img
                  src={
                    this.props.axisData.xScrollIndex > 0 ? xPrevActive : xPrev
                  }
                /> */}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default YAxisComponent;
