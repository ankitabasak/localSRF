import React, { Component } from 'react';
import './district-rlp.css';
import YAxisComponent from './District_RLP_Reading_Levels.jsx';
import DistrictRlpGrade from './DistrictRLPGradeColumn.jsx';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import NoRecordsData from '../../../Utils/No_Data_Found';
import { connect } from 'react-redux';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  Show_loading_Icon,
  Sum_Dst_RLP_Chart_API,
  Sum_Dst_RLP_Scroll_Data,
  Selected_Levels,
  Chart_loading_Failed,
  DSTRLP_CSVDATA_DOWNLOAD_APICALL,
  DSTRLP_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/District_RlpActions.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import PrintDstRlp from '../../ReusableComponents/PrintOrrCharts/Dst_RlpPrint.jsx';

class SummaryDstRlpChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sidepanelApiInRun: false,
      grade: {}
    };
    this.districtRlpGridApi = this.districtRlpGridApi.bind(this);
    this.backToMainChart = this.backToMainChart.bind(this);
  }

  componentDidMount() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let payLoad = getCommonHeaders(summaryFilterData, 'district')
    this.props.Sum_Dst_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  // time out
  timeOut() {
    this.props.Chart_loading_Failed({
      noChartData: false,
      apiLoadFail: false,
      constructedData: null,
      timeout: true
    });
  }
  //DistrictRlp Grid API

  districtRlpGridApi(selectedLevels) {
    let SL;
    let grade = 'grade';
    let recordListType = '';
    let distSl = 'districtRLPChart1SidePanelRequestList';

    if (this.props.DistrictRLPState.currentChartInDisplay == 'CLRLP') {
      grade = 'schoolId';
      distSl = 'districtRLPChart2SidePanelRequestList';
    }

    if (selectedLevels['recentRecord']) {
      recordListType = 'recentRecord';

      SL = selectedLevels['recentRecord'].map(obj => {
        if (grade == 'schoolId') {
          return {
            [grade]: obj[grade],
            readingLevel: obj.readingLevel,
            ['grade']: this.props.DistrictRLPState.districtLevelGrade,
            schoolName: obj.schoolName
          };
        } else {
          return { [grade]: obj[grade], readingLevel: obj.readingLevel };
        }
      });
    } else if (selectedLevels['firstRecord']) {
      recordListType = 'firstRecord';
      SL = selectedLevels['firstRecord'].map(obj => {
        if (grade == 'schoolId') {
          return {
            [grade]: obj[grade],
            readingLevel: obj.readingLevel,
            ['grade']: this.props.DistrictRLPState.districtLevelGrade,
            schoolName: obj.schoolName
          };
        } else {
          return { [grade]: obj[grade], readingLevel: obj.readingLevel };
        }
      });
    } else {
      SL = selectedLevels;
    }
  }

  // X axis scroll control
  getGradeArray(listItems, index) {
    return listItems.slice(index, 3);
  }
  // check for duplicate value
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          bubble.readingLevel === obj.readingLevel &&
          bubble.grade === obj.grade &&
          obj.schoolName === bubble.schoolName
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  saveSelectedLevels(levels, selLvls) {
    let selectedLevels = selLvls[levels.type];
    if (selectedLevels) {
      let duplicateIndex = this.isDuplicateBubble(levels, selectedLevels);

      if (duplicateIndex != -1) {
        selectedLevels.splice(duplicateIndex, 1);
      } else {
        selectedLevels.push(levels);
      }

      this.props.Selected_Levels({
        ['selectedLevels']: { [levels.type]: selectedLevels }
      });

      this.districtRlpGridApi({ [levels.type]: selectedLevels });
    } else {
      selectedLevels = { [levels.type]: [levels] };

      this.props.Selected_Levels({
        ['selectedLevels']: selectedLevels
      });
      this.districtRlpGridApi(selectedLevels);
    }
  }

  getAxisRangeData(dataList, index) {
    let rl = dataList.slice(index, 7);
    return rl.reverse();
  }

  scrollUpDown(dataList, index, scrollType) {
    let rl = [];
    switch (scrollType) {
      case 'up':
        if (index < dataList.length - 7) {
          let scrlIndex = index + 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 7);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'down':
        if (index > 0) {
          let scrlIndex = index - 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 7);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeTop':
        if (index < dataList.length - 7) {
          rl = dataList.slice(dataList.length - 7, dataList.length);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: dataList.length - 7
          });
        }
        return;
      case 'extremeBottom':
        if (index > 0) {
          let scrlIndex = 0;
          rl = dataList.slice(0, 7);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  setDataScrollState(data) {
    this.props.Sum_Dst_RLP_Scroll_Data(data);
  }

  scrollRightLeft(dataList, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataList.length - 3) {
          let scrlIndex = index + 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + 3),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let scrlIndex = index - 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + 3),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataList.length - 3) {
          let scrlIndex = dataList.length - 3;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, dataList.length),
            xScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let scrlIndex = 0;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(0, 3),
            xScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  backToMainChart() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    this.props.Show_loading_Icon('');
    let payLoad = getCommonHeaders(summaryFilterData, 'district');
    this.props.Sum_Dst_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  // Download csv data
  downLoadCSVData() {
    this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP' &&
      this.props.DSTRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let Req_Payload = {
      districtChartType: {
        "allGrades": true,
        "chartName": "DRLP1",
        "gradeValue": null
      },
      ...getCommonHeaders(summaryFilterData, 'district')
    };
    this.props.DSTRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    if (this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP') {
      if (this.props.dstCsvDownload && this.props.dstCsvDownload['downloadInProgress'] && this.props.dstCsvDownload['csvData']) {
        setTimeout(() => {
          this.refs.groupCSV.link.click();
          this.props.DSTRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
        }, 500)
      }
    }
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedDistrict.name;
    let chartData = this.props.DistrictRLPState.sumDistData;
    let printChartData = this.props.DistrictRLPState.constructedData
    let xAxisName =
      this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP'
        ? 'Grade'
        : 'Schools';
    return (
      <div className="sum-error pos-rel">
        <div
          className="container sum-dstrlp"
          style={{
            maxWidth: '1165px',
            paddingLeft: '0px',
            paddingRight: '0px'
          }}
        >
          {/* {this.props.isApiLoading && <Spinner />} */}
          {!this.props.DistrictRLPState.isApiLoading && chartData && (
            <div className="row mt-10" style={{ marginTop: '7px' }}>
              {this.props.DistrictRLPState.currentChartInDisplay == 'SLRLP' &&
                this.props.dstCsvDownload && this.props.dstCsvDownload['csvData'] &&
                <CSVLink
                  ref="groupCSV"
                  headers={this.props.dstCsvDownload['csvData'] && this.props.dstCsvDownload['csvData']['header']}
                  data={this.props.dstCsvDownload['csvData'] && this.props.dstCsvDownload['csvData']['data']}
                  style={{ display: 'none' }}
                  filename={`${csvFileName}.csv`} />}
              <div className="sum-dst-csv-icon-alignment"
                onClick={() =>
                  !this.props.dstCsvDownload['downloadInProgress'] && this.downLoadCSVData()
                }>
                {this.props.dstCsvDownload && this.props.dstCsvDownload['downloadInProgress'] ?
                  <span className="csv_download_icon">
                    <i className="material-icons">autorenew</i>
                  </span> :
                  <span className="csv_download_icon">
                    <img src={CsvIcon} width="20" height="20" />
                  </span>}
              </div>
              <div className="srlp-lhs-wrap sc-rlp-wrap">
                <div className="wrap-srlp pos-rel ">
                  {!this.props.popUp &&
                  <div className="summary_legend">
                    <div className="summary_legend_child">Legend:</div>
                    <div className="summary_legend_child summary_gray_rect" />
                    <div className="summary_legend_child">Grade Reading Level Target</div>
                  </div>}
                  <div className="readingLevel-srlp">Reading Level</div>
                  <div className="grade-txt-srlp bt-27">{xAxisName}</div>
                  <div className="rhs-line-srlp" />
                  <div className="rhs-line2-srlp" />
                  <div className="rhs-line-btm-srlp" />
                  <div className="rhs-line-btm1-srlp" />

                  {chartData.yAxisDataRange && (
                    <YAxisComponent
                      axisData={{
                        dataRange: chartData.yAxisDataRange,
                        scrollIndex: chartData.yScrollIndex,
                        xScrollIndex: chartData.xScrollIndex,
                        allReadingLevels: chartData.yAxisData
                      }}
                      scrollReadingLevels={scrollType => {
                        this.scrollUpDown(
                          chartData.yAxisData,
                          chartData.yScrollIndex,
                          scrollType
                        );
                      }}
                      scrollGradeLevels={scrollType => {
                        this.scrollRightLeft(
                          chartData.xAxisData,
                          chartData.xScrollIndex,
                          scrollType
                        );
                      }}
                    />
                  )}

                  {chartData.xAxisGradeRange && (
                    <DistrictRlpGrade
                      backToMainChart={this.backToMainChart}
                      gradesData={chartData.xAxisGradeRange}
                      readingLevels={chartData.yAxisDataRange}
                      selectedClassLevels={selectedLevels => {
                        this.saveSelectedLevels(
                          selectedLevels,
                          this.props.DistrictRLPState.districtsSelected || {}
                        );
                      }}
                      selectedLevels={
                        this.props.DistrictRLPState.districtsSelected
                      }
                      currentChartInDisplay={
                        this.props.DistrictRLPState.currentChartInDisplay
                      }
                      scrollGradeLevels={scrollType => {
                        this.scrollRightLeft(
                          chartData.xAxisData,
                          chartData.xScrollIndex,
                          scrollType
                        );
                      }}
                      totalGradeItems={chartData.xAxisData}
                      scrollIndex={chartData.xScrollIndex}
                      getClassLevelRLPData={grade => {
                        this.getClassLevelRLPData(grade);
                      }}
                    />
                  )}
                </div>
              </div>
              {chartData && this.props.DistrictRlpGridData &&
                <span className="sum-class-print-btn">
                  <span className="hover-print">
                    Print
                    <span className="tooltip-dot-sum" />
                  </span>
                  <PrintDstRlp
                    summaryFlag={true}
                    xAxisName={xAxisName}
                    scrollFlag={true}
                    selectedFilter={this.props.SummaryFilterData}
                    studentDetails={this.props.ContextHeader}
                    navSelected={this.props.NavigationByHeaderSelection}

                    axisData={{
                      dataRange: printChartData.yAxisDataRange,
                      scrollIndex: printChartData.yScrollIndex,
                      xScrollIndex: printChartData.xScrollIndex,
                      allReadingLevels: printChartData.yAxisData
                    }}

                    backToMainChart={this.backToMainChart}
                    gradesData={printChartData.xAxisGradeRange}
                    readingLevels={printChartData.yAxisDataRange}
                    selectedLevels={
                      this.props.DistrictRLPState.districtsSelected
                    }
                    currentChartInDisplay={
                      this.props.DistrictRLPState.currentChartInDisplay
                    }
                    totalGradeItems={printChartData.xAxisData}
                    scrollIndex={printChartData.xScrollIndex}

                    districtData={this.props.DistrictRlpGridData}
                    sortData={this.props.SortData}

                  />
                </span>}

            </div>
          )}
          {this.props.DistrictRLPState.isApiLoading &&
            !chartData && (
              <Spinner
                startSpinner={this.props.isApiLoading}
                showTimeOut={this.timeOut}
              />
            )}
          {!chartData && this.props.DistrictRLPState.timeOut && (
            <TimeOut tryAgain={this.getCFData} />
          )}
          {!chartData && this.props.DistrictRLPState.noChartData && (
            <NoRecordsData NodataFound={'dataNotAvail'} />
          )}
          {!chartData && this.props.DistrictRLPState.apiLoadFail && (
            <ChartNotLoad />
          )}
        </div>
      </div>
    );
  }
}
const mapStateToProps = ({
  Universal,
  Authentication,
  DistrictRlpData1,
  SummaryFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { DistrictRLPState, DistrictRlpGridData, SortData, dstCsvDownload } = DistrictRlpData1;
  const { SummaryFilterData } = SummaryFilterDetails;
  return {
    LoginDetails,
    DistrictRLPState,
    ContextHeader,
    NavigationByHeaderSelection,
    DistrictRLPState,
    DistrictRlpGridData,
    SortData,
    dstCsvDownload,
    SummaryFilterData
  };
};

export default connect(
  mapStateToProps,
  {
    Show_loading_Icon,
    Sum_Dst_RLP_Chart_API,
    Sum_Dst_RLP_Scroll_Data,
    Selected_Levels,
    Chart_loading_Failed,
    DSTRLP_CSVDATA_DOWNLOAD_APICALL,
    DSTRLP_CSVDATA_DOWNLOAD_RESET
  }
)(SummaryDstRlpChart);
