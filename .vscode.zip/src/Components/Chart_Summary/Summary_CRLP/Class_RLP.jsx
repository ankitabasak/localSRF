import React, { PureComponent } from "react";
import { connect } from "react-redux";
import "../../ORR/FilterComponents/Filter.css";
import {
  backgroundColor,
  axisColor,
  bubbleColor,
  setBubbleConfiguration,
  bubbleBackgroundOnSelection
} from "../../ORR/ChartComponents/Graph_Color";
import "./Class_RLP.css";

class Class_RLP extends PureComponent {
  constructor(props) {
    super(props);
    this.myRef = React.createRef();
    this.state = {
      previousIcon: false,
      firstIcon: false,
      nextIcon: true,
      lastIcon: true,

      bottomIcon: true,
      bottomLastIcon: true,
      topFirstIcon: false,
      topIcon: false,

      sum_crlp_Object: null,
      selectedBubbles: {}
    };
    this.topIndex = 0;
    this.bottomIndex = 3;
    this.leftIndex = 0;
    this.rightIndex = 3;

    this.scrollUp = this.scrollUp.bind(this);
    this.scrollDown = this.scrollDown.bind(this);

    // Horizontal scroll binding
    this.scrollLeft = this.scrollLeft.bind(this); //sliceArray
    this.scrollExtremeLeft = this.scrollExtremeLeft.bind(this);
    this.scrollRight = this.scrollRight.bind(this);
    this.scrollExtremeRight = this.scrollExtremeRight.bind(this);

    this.sliceArray = this.sliceArray.bind(this);
    this.bubblesSelected = this.bubblesSelected.bind(this);
    this.onLoadSelectBubble = this.onLoadSelectBubble.bind(this);
    this.bubblesSelectedForReadingTarget = this.bubblesSelectedForReadingTarget.bind(
      this
    );
    this.getBubbleBackgroundColorOnSelection = this.getBubbleBackgroundColorOnSelection.bind(
      this
    );
  }
  componentDidMount() {
    this.setState({
      ...this.state,
      ["selectedBubbles"]: this.props.selectedBubs || {}
    });
  }
  // return sliced array
  sliceArray(array, arrayIndex) {
    return array.slice(arrayIndex, arrayIndex + 3);
  }
  getBackgroundColorYAxis(value) {
    if (value) {
      var bgColorValue = [];
      bgColorValue = backgroundColor(value);
      return bgColorValue;
    }
  }
  getAxisColorYAxis(value) {
    if (value) {
      var axisColorValue;
      axisColorValue = axisColor(value);
      return axisColorValue;
    }
  }
  getBubbleBackgroundColorOnSelection(value) {

    if (value) {
      var bubbleBackgroundValue;
      bubbleBackgroundValue = bubbleBackgroundOnSelection(value);
      return bubbleBackgroundValue;
    }
  }
  getBubbleColor(value) {
    if (value) {
      var bubbleColorValue;
      bubbleColorValue = bubbleColor(value);
      return bubbleColorValue;
    }
  }
  getBubbleConfiguration(value) {
    if (value) {
      var bubbleConf;
      bubbleConf = setBubbleConfiguration(value);
      return bubbleConf;
    } else {
      return 0;
    }
  }
  // Y axis scroll functionality
  scrollUp() {
    // update state on up scroll
    if (this.props.sum_crlp_Object.scrollIndex > 0) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          YaxisDataRange: this.sliceArray(
            this.props.sum_crlp_Object.YaxisData,
            this.props.sum_crlp_Object.scrollIndex - 1
          ),
          ["scrollIndex"]: this.props.sum_crlp_Object.scrollIndex - 1
        }
      });
    }
  }

  // Scrolling down
  scrollDown() {
    if (
      this.props.sum_crlp_Object.scrollIndex <
      this.props.sum_crlp_Object.YaxisData.length - 3
    ) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          YaxisDataRange: this.sliceArray(
            this.props.sum_crlp_Object.YaxisData,
            this.props.sum_crlp_Object.scrollIndex + 1
          ),
          ["scrollIndex"]: this.props.sum_crlp_Object.scrollIndex + 1
        }
      });
    }
  }

  scrollToBottom() {
    if (
      this.props.sum_crlp_Object.scrollIndex <
      this.props.sum_crlp_Object.YaxisData.length - 3
    ) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          YaxisDataRange: this.sliceArray(
            this.props.sum_crlp_Object.YaxisData,
            this.props.sum_crlp_Object.YaxisData.length - 3
          ),
          ["scrollIndex"]: this.props.sum_crlp_Object.YaxisData.length - 3
        }
      });
    }
  }

  scrollToTop() {
    if (this.props.sum_crlp_Object.scrollIndex > 0) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          YaxisDataRange: this.sliceArray(
            this.props.sum_crlp_Object.YaxisData,
            0
          ),
          ["scrollIndex"]: 0
        }
      });
    }
  }
  // Horizontal scroll
  scrollLeft() {
    if (this.props.sum_crlp_Object.xAxisScrollIndex > 1) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          xAxisScrollIndex: this.props.sum_crlp_Object.xAxisScrollIndex - 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.sum_crlp_Object.monthlyRecordData,
            this.props.sum_crlp_Object.xAxisScrollIndex - 1,
            "left"
          )
        }
      });
    }
  }
  scrollExtremeLeft() {
    if (this.props.sum_crlp_Object.xAxisScrollIndex > 1) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          xAxisScrollIndex: 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.sum_crlp_Object.monthlyRecordData,
            1,
            "exleft"
          )
        }
      });
    }
  }

  scrollRight() {
    if (
      this.props.sum_crlp_Object.xAxisScrollIndex <=
      this.props.sum_crlp_Object.monthlyRecordData.length - 1
    ) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          xAxisScrollIndex: this.props.sum_crlp_Object.xAxisScrollIndex + 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.sum_crlp_Object.monthlyRecordData,
            this.props.sum_crlp_Object.xAxisScrollIndex + 1,
            "right"
          )
        }
      });
    }
  }
  scrollExtremeRight() {
    if (
      this.props.sum_crlp_Object.xAxisScrollIndex <=
      this.props.sum_crlp_Object.monthlyRecordData.length - 1
    ) {
      this.props.updateScrollData({
        ["sum_crlp_Object"]: {
          ...this.props.sum_crlp_Object,
          xAxisScrollIndex:
            this.props.sum_crlp_Object.monthlyRecordData.length - 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.sum_crlp_Object.monthlyRecordData,
            this.props.sum_crlp_Object.monthlyRecordData.length - 1,
            "exright"
          )
        }
      });
    }
  }
  bubblesSelected(bubble) {
    let selectedBubbles = this.state.selectedBubbles;

    if (selectedBubbles[bubble.month]) {
      let dupBubIdx = this.isDuplicateBubble(
        bubble,
        selectedBubbles[bubble.month]
      );
      if (dupBubIdx != -1) {
        selectedBubbles[bubble.month].splice(dupBubIdx, 1);
      } else {
        selectedBubbles[bubble.month].push(bubble);
      }
    } else {
      selectedBubbles = {};
      selectedBubbles[bubble.month] = [bubble];
    }
    this.setState({ ...this.state, ["selectedBubbles"]: selectedBubbles });
    this.props.bubblesSelected(selectedBubbles[bubble.month]);
    //  this.props.getBubbleBackgroundColorOnSelection(selectedBubbles[bubble.month]);
  }
  bubblesSelectedForReadingTarget(bubble) {
    this.setState({ ...this.state, ["selectedBubbles"]: {} });
    this.props.bubblesSelectedForReadingTarget(bubble);
    // this.getBubbleBackgroundColorOnSelection(bubble);
  }

  // contsruct recent records
  getRecentRecorde(arrItems, index, scroll) {
    // need remove after expand collapse implementations
    if (arrItems.length > 0) {
      if (scroll === "right" && index !== 0) {
        return [arrItems[index], arrItems[index + 1]];
      } else if (scroll === "left" && index !== 0) {
        return [arrItems[index - 1], arrItems[index]];
      } else if (scroll === "exright") {
        return [arrItems[index - 1], arrItems[index]];
      } else if (scroll === "exleft") {
        return [arrItems[index - 1], arrItems[index]];
      }
    }
  }
  // check for duplicate bubble
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          obj.type === bubble.type &&
          obj.readingLevel === bubble.readingLevel
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  getBubBackColor(bubble) {
    let listItems = [];// this.state.selectedBubbles[bubble.month];
    let style = { color: "", border: "2px solid", padding: "", boxShadow: "" };
    if (listItems) {
      listItems.forEach(obj => {
        if (
          obj.type === bubble.type &&
          obj.readingLevel === bubble.readingLevel
        ) {
          style = {
            color: this.getBubbleBackgroundColorOnSelection(obj.type),
            border: "none",
            padding: "2px",
            boxShadow: "inset 0 0 2px 1px rgba(0,0,0,0.1)"
          };
          return;
        }
      });
    }
    return style;
  }
  onLoadSelectBubble() {
    let recentRecordExist = this.props.sum_crlp_Object.recentMonthlyRecords.some(
      data => data.recentRecord === true
    );
    this.props.sum_crlp_Object.recentMonthlyRecords.forEach((data, i) => {
      if (recentRecordExist && data.recentRecord) {
        this.props.sum_crlp_Object.recentMonthlyRecords[
          i
        ].totalStudentRecord.forEach((element, index) => {
          let bubbleType;
          if (
            Object.keys(data.frustrationalRecordData).length !== 0 &&
            Object.keys(data.frustrationalRecordData).indexOf(
              element.recordLevel
            ) >= 0
          ) {
            bubbleType = "Frustrational";
          } else if (
            Object.keys(data.independentRecordData).length !== 0 &&
            Object.keys(data.independentRecordData).indexOf(
              element.recordLevel
            ) >= 0
          ) {
            bubbleType = "Independent";
          } else if (
            Object.keys(data.instructionalRecordData).length !== 0 &&
            Object.keys(data.instructionalRecordData).indexOf(
              element.recordLevel
            ) >= 0
          ) {
            bubbleType = "Instructional";
          }
          if (recentRecordExist && data.recentRecord) {
            this.bubblesSelected({
              type: bubbleType,
              readingLevel: element.recordLevel,
              month: data.month,
              monthYear: data.monthYear,
              recentRecord: data["recentRecord"],
              firstRecord: data["firstRecord"]
            });
          } else {
            this.bubblesSelected({
              type: bubbleType,
              readingLevel: element.recordLevel,
              month: data.month,
              monthYear: data.monthYear,
              recentRecord: data["recentRecord"],
              firstRecord: data["firstRecord"]
            });
          }
        });
      }
    });
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.selectedBubs) {
      this.setState({
        ...this.state,
        ["selectedBubbles"]: nextProps.selectedBubs
      });
    }

    if (
      nextProps.sum_crlp_Object.monthlyRecordData !==
      this.props.sum_crlp_Object.monthlyRecordData
    ) {
      // // this.props.clearBubbles();
      // this.setState({
      //   selectedBubbles: {}
      // // });
      // this.setState({
      //   ...this.state,
      //   ['selectedBubbles']: this.props.selectedBubbles
      // });
      // setTimeout(() => {
      //   this.onLoadSelectBubble();
      // }, 1000);
    }
    // if (this.props.sum_crlp_Object) {
    //   this.setState({
    //     ...this.state,
    //      ["sum_crlp_Object"]: getConstructedData(this.props.data)
    //   });
    // }
  }

  render(props) {
    if (this.props.sum_crlp_Object) {
      return (
        <div className="col-lg-12 res-width-8 class_rlp ml-60">
          <p className="reading-level-text-crlp pull-left">Reading Level</p>
          <p className="reading-level-text-crlp pull-left">Reading Level</p>
          <div className="wrap-crlp pos-rel">
            <p className="crlp-chart-btm-heading">Month</p>
            <div className="sum-rhs-line-crlp" />
            <div className="rhs-line1-crlp" />
            <div className="rhs-line2-crlp" />
            <div className="rhs-line3-crlp" />
            <div className="reading-level-section-crlp pull-left clearfix">
              <div
                className={
                  this.props.sum_crlp_Object.scrollIndex > 0
                    ? "y-top-end-active"
                    : "y-top-end"
                }
                onClick={() => this.scrollToTop()}
              />
              <div
                className={
                  this.props.sum_crlp_Object.scrollIndex > 0
                    ? "y-top-active"
                    : "y-top"
                }
                onClick={() => this.scrollUp()}
              />
              <div
                id="yAxis"
                style={{ height: "211px", overflow: "hidden" }}
              >
                <ul>
                  {this.props.sum_crlp_Object.YaxisDataRange.map(
                    (readingLevel, index) => {
                      return (
                        <li
                          className="level3"
                          key={index}
                          style={{
                            backgroundColor: this.getBackgroundColorYAxis(
                              readingLevel
                            ),
                            borderRight:
                              "4px solid" + this.getAxisColorYAxis(readingLevel)
                          }}
                        >
                          <span>{readingLevel}</span>
                        </li>
                      );
                    }
                  )}
                </ul>
              </div>
              <div
                className={
                  this.props.sum_crlp_Object.scrollIndex <
                    this.props.sum_crlp_Object.YaxisData.length - 3
                    ? "y-bottom-active"
                    : "y-bottom"
                }
                onClick={() => this.scrollDown()}
              />
              <div
                className={
                  this.props.sum_crlp_Object.scrollIndex <
                    this.props.sum_crlp_Object.YaxisData.length - 3
                    ? "y-bottom-end-active"
                    : "y-bottom-end"
                }
                onClick={() => this.scrollToBottom()}
              />
              <div>
                <div
                  className={
                    this.props.sum_crlp_Object.xAxisScrollIndex > 1
                      ? "x-prev-end-active pull-left"
                      : "x-prev-end pull-left"
                  }
                  onClick={() => this.scrollExtremeLeft()}
                />
                <div
                  className={
                    this.props.sum_crlp_Object.xAxisScrollIndex > 1
                      ? "x-prev-active pull-left"
                      : "x-prev pull-left"
                  }
                  onClick={() => this.scrollLeft()}
                />
              </div>
            </div>

            <div
              className="graph-content-crlp pull-left pos-rel mleft-1"
              style={{
                border: "none",
                display: "inline-flex"
              }}
            >
              <div className="starting-level-crlp">
                <div className="top-slide-section-crlp-first"></div>
                {this.props.sum_crlp_Object &&
                  this.props.sum_crlp_Object.YaxisDataRange.map(
                    (recordLvl, idx) => {
                      return (
                        <div className="sl-1" key={idx}>
                          <ul>
                            <li
                              className="sum-default-bubble-crlp"
                              // onClick={() => {
                              //   this.bubblesSelected({
                              //     type: "Frustrational",
                              //     readingLevel: recordLvl,
                              //     month: recordDataListValue.month,
                              //     monthYear: recordDataListValue.monthYear,
                              //     recentRecord:
                              //       recordDataListValue.recentRecord,
                              //     firstRecord: recordDataListValue.firstRecord
                              //   });
                              // }}
                              style={{
                                backgroundColor: '#ffffff',
                                width: this.getBubbleConfiguration(
                                  this.props.sum_crlp_Object.startingLevel[
                                  recordLvl
                                  ]
                                ).bubbleSize
                                  ? this.getBubbleConfiguration(
                                    this.props.sum_crlp_Object.startingLevel[
                                    recordLvl
                                    ]
                                  ).bubbleSize
                                  : "",
                                height: this.getBubbleConfiguration(
                                  this.props.sum_crlp_Object.startingLevel[
                                  recordLvl
                                  ]
                                ).bubbleSize
                                  ? this.getBubbleConfiguration(
                                    this.props.sum_crlp_Object.startingLevel[
                                    recordLvl
                                    ]
                                  ).bubbleSize
                                  : "",
                                fontSize: this.getBubbleConfiguration(
                                  this.props.sum_crlp_Object.startingLevel[
                                  recordLvl
                                  ]
                                ).fontSize
                                  ? this.getBubbleConfiguration(
                                    this.props.sum_crlp_Object.startingLevel[
                                    recordLvl
                                    ]
                                  ).fontSize
                                  : "",
                                border: this.props.sum_crlp_Object
                                  .startingLevel[recordLvl]
                                  ? "3px solid" +
                                  this.getBubbleColor("Instructional")
                                  : "",
                                lineHeight: this.getBubbleConfiguration(
                                  this.props.sum_crlp_Object.startingLevel[
                                  recordLvl
                                  ]
                                ).bubbleSize
                                  ? this.getBubbleConfiguration(
                                    this.props.sum_crlp_Object.startingLevel[
                                    recordLvl
                                    ]
                                  ).bubbleSize
                                  : ""
                              }}
                            >
                              <span>
                                {
                                  this.props.sum_crlp_Object.startingLevel[
                                  recordLvl
                                  ]
                                }
                                {this.props.sum_crlp_Object.startingLevel[
                                  recordLvl
                                ]
                                  ? "%"
                                  : ""}
                              </span>
                            </li>
                          </ul>
                        </div>
                      );
                    }
                  )}

                <div className="sl-heading">Starting level</div>
              </div>
              {this.props.sum_crlp_Object &&
                this.props.sum_crlp_Object.recentMonthlyRecords.map(
                  (recordDataListValue, idx) => {
                    if (recordDataListValue) {
                      return (
                        <div
                          className="sum-first-coloumn-crlp pull-left pos-rel ml-68"
                          key={idx}
                        >
                          <div className="sum-sub-rhs-line-crlp">
                            <div className="top-small-strip">
                              <div className="top-lhs-strip-bar"></div>
                              <div className="top-rhs-strip-bar"></div>
                            </div>
                            <div className="chart-line-lhs-adj"></div>
                            <div className="chart-line-rhs-adj"></div>
                          </div>
                          <div className="top-slide-section-crlp">
                            {this.props.sum_crlp_Object.xAxisScrollIndex === 1 && idx === 0 ? (
                              <span>First Record</span>
                            ) : (
                                <span />
                              )}
                            {this.props.sum_crlp_Object.monthlyRecordData.length
                              === (this.props.sum_crlp_Object.xAxisScrollIndex + idx) ? (
                              <span>Recent Record</span>
                            ) : (
                                <span />
                              )}
                          </div>
                          <div className="sum-up-sec-crlp">
                            {/* Total Student Grid */}
                            <div className="sum-sub-first-column-crlp pull-left pos-rel">
                              {this.props.sum_crlp_Object.YaxisDataRange.map(
                                (recordLvl, idx) => {
                                  return (
                                    <div className="block-sec-crlp" key={idx}>
                                      <ul>
                                        <li
                                          style={{
                                            fontSize: this.getBubbleConfiguration(
                                              recordDataListValue
                                                .totalNoOfStudents[recordLvl]
                                            ).fontSize
                                          }}
                                        >
                                          <span>
                                            {
                                              recordDataListValue
                                                .totalNoOfStudents[recordLvl]
                                            }
                                            {recordDataListValue
                                              .totalNoOfStudents[recordLvl]
                                              ? "%"
                                              : ""}
                                          </span>
                                        </li>
                                      </ul>
                                    </div>
                                  );
                                }
                              )}
                            </div>
                            <div className="total-stu-crlp">
                              <p title="Total Students Roastered">
                                Total Students
                              </p>
                            </div>

                            {/* Frustrational Student Grid */}
                            <div
                              className={
                                recordDataListValue.frustrationalRecordDataTotalValue >
                                  0
                                  ? "sum-sub-fourth-column-crlp pull-left pos-rel"
                                  : "hide"
                              }
                            >
                              <div>
                                {this.props.sum_crlp_Object.YaxisDataRange.map(
                                  (recordLvl, idx) => {
                                    return (
                                      <div
                                        className="block-sec-3rd-crlp"
                                        key={idx}
                                      >
                                        <ul>
                                          <li
                                            className={
                                              recordDataListValue
                                                .frustrationalRecordData[
                                                recordLvl
                                              ]
                                                ? "sum-default-bubble-crlp"
                                                : ""
                                            }
                                            // onClick={() => {
                                            //   this.bubblesSelected({
                                            //     type: "Frustrational",
                                            //     readingLevel: recordLvl,
                                            //     month:
                                            //       recordDataListValue.month,
                                            //     monthYear:
                                            //       recordDataListValue.monthYear,
                                            //     recentRecord:
                                            //       recordDataListValue.recentRecord,
                                            //     firstRecord:
                                            //       recordDataListValue.firstRecord
                                            //   });
                                            // }}
                                            style={{
                                              width: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              height: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              fontSize: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).fontSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).fontSize
                                                : "",
                                              border: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).border +
                                                this.getBubbleColor(
                                                  "Frustrational"
                                                )
                                                : "",
                                              lineHeight: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              // backgroundColor: this.getBubbleConfiguration(
                                              //   recordDataListValue
                                              //     .frustrationalRecordData[
                                              //   recordLvl
                                              //   ]
                                              // ).bubbleSize
                                              //   ? this.getBubBackColor({
                                              //     type: "Frustrational",
                                              //     readingLevel: recordLvl,
                                              //     month:
                                              //       recordDataListValue.month
                                              //   }).color
                                              //   : "",
                                              padding: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).padding
                                                : "",
                                              boxShadow: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).boxShadow
                                                : ""
                                            }}
                                          >
                                            <span>
                                              {
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              }
                                              {recordDataListValue
                                                .frustrationalRecordData[
                                                recordLvl
                                              ]
                                                ? "%"
                                                : ""}
                                            </span>
                                          </li>
                                        </ul>
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                              <div
                                className="wcpm-section-crlp"
                                style={{
                                  backgroundColor: "transparent",
                                  borderBottom:
                                    "4px solid" +
                                    this.getBubbleColor("Frustrational")
                                }}
                              >
                                <p>
                                  {
                                    recordDataListValue.frustrationalRecordDataTotalValue
                                  }{" "}
                                  %
                                </p>
                              </div>
                            </div>

                            {/* Instructional Student Grid */}
                            <div
                              className={
                                recordDataListValue.instructionalRecordDataTotalValue >
                                  0
                                  ? "sum-sub-second-column-crlp pull-left pos-rel"
                                  : "hide"
                              }
                            >
                              <div>
                                {this.props.sum_crlp_Object.YaxisDataRange.map(
                                  (recordLvl, idx) => {
                                    return (
                                      <div
                                        className="block-sec-3rd-crlp"
                                        key={idx}
                                      >
                                        <ul>
                                          <li
                                            className={
                                              recordDataListValue
                                                .instructionalRecordData[
                                                recordLvl
                                              ]
                                                ? "sum-default-bubble-crlp"
                                                : ""
                                            }
                                            style={{
                                              width: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              height: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              fontSize: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).fontSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).fontSize
                                                : "",
                                              border: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).border +
                                                this.getBubbleColor(
                                                  "Instructional"
                                                )
                                                : "",
                                              lineHeight: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              // backgroundColor: this.getBubbleConfiguration(
                                              //   recordDataListValue
                                              //     .instructionalRecordData[
                                              //   recordLvl
                                              //   ]
                                              // ).bubbleSize
                                              //   ? this.getBubBackColor({
                                              //     type: "Instructional",
                                              //     readingLevel: recordLvl,
                                              //     month:
                                              //       recordDataListValue.month
                                              //   }).color
                                              //   : "",
                                              padding: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).padding
                                                : "",
                                              boxShadow: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).boxShadow
                                                : ""
                                            }}
                                          // onClick={() => {
                                          //   this.bubblesSelected({
                                          //     type: "Instructional",
                                          //     readingLevel: recordLvl,
                                          //     month:
                                          //       recordDataListValue.month,
                                          //     monthYear:
                                          //       recordDataListValue.monthYear,
                                          //     recentRecord:
                                          //       recordDataListValue.recentRecord,
                                          //     firstRecord:
                                          //       recordDataListValue.firstRecord
                                          //   });
                                          // }}
                                          >
                                            <span>
                                              {
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              }
                                              {recordDataListValue
                                                .instructionalRecordData[
                                                recordLvl
                                              ]
                                                ? "%"
                                                : ""}
                                            </span>
                                          </li>
                                        </ul>
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                              <div
                                className="wcpm-section-crlp"
                                style={{
                                  backgroundColor: "transparent",
                                  borderBottom:
                                    "4px solid" +
                                    this.getBubbleColor("Instructional")
                                }}
                              >
                                <p>
                                  {
                                    recordDataListValue.instructionalRecordDataTotalValue
                                  }{" "}
                                  %
                                </p>
                              </div>
                            </div>

                            {/* Independent Student Grid */}
                            <div
                              className={
                                recordDataListValue.independentRecordDataTotalValue >
                                  0
                                  ? "sum-sub-third-column-crlp pull-left pos-rel"
                                  : "hide"
                              }
                            >
                              <div>
                                {this.props.sum_crlp_Object.YaxisDataRange.map(
                                  (recordLvl, idx) => {
                                    return (
                                      <div
                                        className="block-sec-3rd-crlp"
                                        key={idx}
                                      >
                                        <ul>
                                          <li
                                            className={
                                              recordDataListValue
                                                .independentRecordData[
                                                recordLvl
                                              ]
                                                ? "sum-default-bubble-crlp"
                                                : ""
                                            }
                                            style={{
                                              width: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              height: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              fontSize: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).fontSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).fontSize
                                                : "",
                                              border: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).border +
                                                this.getBubbleColor(
                                                  "Independent"
                                                )
                                                : "",
                                              lineHeight: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              backgroundColor: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).color
                                                : "",
                                              padding: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).padding
                                                : "",
                                              boxShadow: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).boxShadow
                                                : ""
                                            }}
                                          // onClick={() => {
                                          //   this.bubblesSelected({
                                          //     type: "Independent",
                                          //     readingLevel: recordLvl,
                                          //     month:
                                          //       recordDataListValue.month,
                                          //     monthYear:
                                          //       recordDataListValue.monthYear,
                                          //     recentRecord:
                                          //       recordDataListValue.recentRecord,
                                          //     firstRecord:
                                          //       recordDataListValue.firstRecord
                                          //   });
                                          // }}
                                          >
                                            <span>
                                              {
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              }
                                              {recordDataListValue
                                                .independentRecordData[
                                                recordLvl
                                              ]
                                                ? "%"
                                                : ""}
                                            </span>
                                          </li>
                                        </ul>
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                              <div
                                className="wcpm-section-crlp"
                                style={{
                                  backgroundColor: "transparent",
                                  borderBottom:
                                    "4px solid" +
                                    this.getBubbleColor("Independent")
                                }}
                              >
                                <p>
                                  {
                                    recordDataListValue.independentRecordDataTotalValue
                                  }{" "}
                                  %
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="month-section-crlp">
                            <span>{recordDataListValue.month}</span>
                          </div>
                        </div>
                      );
                    }
                  }
                )}
              <div className="last-col-wrap-crlp">
                <div className="reading-level-crlp">
                  <div className="top-slide-section-crlp-last"></div>
                  {this.props.sum_crlp_Object &&
                    this.props.sum_crlp_Object.YaxisDataRange.map(
                      (recordLvl, idx) => {
                        if (recordLvl) {
                          return (
                            <div className="sl-1" key={idx}>
                              <ul>
                                <li
                                  className="sum-default-bubble-crlp"
                                  // onClick={() => {
                                  //   this.bubblesSelectedForReadingTarget({
                                  //     readingLevel: recordLvl
                                  //   });
                                  // }}
                                  style={{
                                    width: this.getBubbleConfiguration(
                                      this.props.sum_crlp_Object.readingTarget[
                                      recordLvl
                                      ]
                                    ).bubbleSize
                                      ? this.getBubbleConfiguration(
                                        this.props.sum_crlp_Object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize
                                      : "",
                                    backgroundColor:
                                      this.getBubbleConfiguration(
                                        this.props.sum_crlp_Object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize &&
                                        Object.keys(this.state.selectedBubbles)
                                          .length === 0
                                        ? this.getBubbleColor("Instructional")
                                        : "",
                                    height: this.getBubbleConfiguration(
                                      this.props.sum_crlp_Object.readingTarget[
                                      recordLvl
                                      ]
                                    ).bubbleSize
                                      ? this.getBubbleConfiguration(
                                        this.props.sum_crlp_Object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize
                                      : "",
                                    fontSize: this.getBubbleConfiguration(
                                      this.props.sum_crlp_Object.readingTarget[
                                      recordLvl
                                      ]
                                    ).fontSize
                                      ? this.getBubbleConfiguration(
                                        this.props.sum_crlp_Object
                                          .readingTarget[recordLvl]
                                      ).fontSize
                                      : "",
                                    border: this.props.sum_crlp_Object
                                      .readingTarget[recordLvl]
                                      ? "3px solid" +
                                      this.getBubbleColor("Instructional")
                                      : "",
                                    lineHeight: this.getBubbleConfiguration(
                                      this.props.sum_crlp_Object.readingTarget[
                                      recordLvl
                                      ]
                                    ).bubbleSize
                                      ? this.getBubbleConfiguration(
                                        this.props.sum_crlp_Object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize
                                      : ""
                                  }}
                                >
                                  <span>
                                    {
                                      this.props.sum_crlp_Object.readingTarget[
                                      recordLvl
                                      ]
                                    }
                                    {this.props.sum_crlp_Object.readingTarget[
                                      recordLvl
                                    ]
                                      ? "%"
                                      : ""}
                                  </span>
                                </li>
                              </ul>
                            </div>
                          );
                        }
                      }
                    )}
                  <div className="sl-heading">Reading Target</div>
                </div>
                <div className="sum-sub-rhs-line-crlp-rl"></div>
                <div className="sum-last-col-crlp">
                  <div className="sum-last-wrap">
                    <div className="sum-grey-header"></div>
                    <p>Reading Level Progress Over Time</p>
                  </div>
                  <div className="btm-arrow-lft-crlp">
                    <div className="btn-wrap-crlp">
                      <div
                        // className={
                        //   this.props.sum_crlp_Object.xAxisScrollIndex >= this.props.sum_crlp_Object.recentMonthlyRecords.length ||
                        //     this.props.sum_crlp_Object.recentMonthlyRecords.length === this.props.sum_crlp_Object.monthlyRecordData.length
                        //     ? "x-next pull-left"
                        //     : "x-next-active pull-left"
                        // }
                        className={
                          // this.props.sum_crlp_Object.xAxisScrollIndex >=
                          //   this.props.sum_crlp_Object.monthlyRecordData.length -
                          //   1
                          this.props.sum_crlp_Object.xAxisScrollIndex <
                            this.props.sum_crlp_Object.monthlyRecordData.length - this.props.sum_crlp_Object.columnToDisp + 1
                            ? "x-next-active pull-left"
                            : "x-next pull-left"
                        }
                        // className="x-next-active pull-left"
                        onClick={() => this.scrollRight()}
                      ></div>
                      <div
                        className={
                          // this.props.sum_crlp_Object.xAxisScrollIndex >=
                          //   this.props.sum_crlp_Object.monthlyRecordData.length -
                          //   1
                          this.props.sum_crlp_Object.xAxisScrollIndex <
                            this.props.sum_crlp_Object.monthlyRecordData.length - this.props.sum_crlp_Object.columnToDisp + 1
                            ? "x-next-end-active pull-left "
                            : "x-next-end pull-left"
                        }
                        // className="x-next-end-active pull-left"
                        onClick={() => this.scrollExtremeRight()}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div style={{ clear: "both" }} />
            </div>
          </div>
        </div>
      );
    } else {
      return <div>No data</div>;
    }
  }
}

export default Class_RLP;
