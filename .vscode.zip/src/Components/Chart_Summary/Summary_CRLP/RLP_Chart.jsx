import React, { PureComponent } from "react";
import { connect } from "react-redux";
import {
  READING_LEVEL_GRID_DATA,
  RLP_DONUT_TARGET_DATA,
  CLASS_READING_LEVEL_PROGRESS,
  RETAIN_BUBBLE_COLOR,
  CLEAR_BUBBLE_COLOR,
  SIDE_PANEL_SPINNER,
  Summary_Scroll_Data,
  SORT_RLP_GRID_COLUMN,
  CLRLP_CSVDATA_DOWNLOAD_APICALL,
  CLRLP_CSVDATA_DOWNLOAD_RESET,
  CHART_SPINNER
} from "../../../Redux_Actions/C_ReadingLevelAction.jsx";
import {
  SHOW_HIDE_GROUPING,
  SAVE_GROUPING_DATA
} from "../../../Redux_Actions/C_GroupingAction.jsx";
import NoRosterData from "../../../Utils/NoRoster.js";
import Class_RLP from "./Class_RLP.jsx";
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import "./Class_RLP.css";
import Spinner from "../../ReusableComponents/Spinner/Spinner.jsx";
import TimeOut from "../../ReusableComponents/Spinner/TimeOut.jsx";
import ChartNotLoad from "../../../Utils/Chart_Not_Load";
import NoRecordsData from "../../../Utils/No_Data_Found";
import { GetCompleteStudentReport } from '../../../Redux_Actions/UniversalSelectorActions'; ''
import PrintCRlp from '../../ReusableComponents/PrintOrrCharts/C_RlpPrint.jsx';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { formatDate } from "../../../Utils/globalVars";

export class SummaryCRlpChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false
    };
    this.constructedSidePanelFilter = {};
    this.readingTargetValue = "";
    this.timeOut = this.timeOut.bind(this);
    this.bubblesSelected = this.bubblesSelected.bind(this);
    this.getClassReadingLevelProgressChartAPI = this.getClassReadingLevelProgressChartAPI.bind(
      this
    );
    this.toggleHidden = this.toggleHidden.bind(this);
  }

  componentDidMount() {
    this.props.CHART_SPINNER();
    this.getClassReadingLevelProgressChartAPI();
    clearInterval(this.interval);
  }

  componentDidUpdate(prevProps) {
    const {Summary_Reports}= this.props.NavigationByHeaderSelection;
    const RosterData =  Summary_Reports ? this.props.ContextHeader.Summary_Roster_Data:  this.props.ContextHeader.Roster_Tab;
    const PreviousRosterData = Summary_Reports ? prevProps.ContextHeader.Summary_Roster_Data:  prevProps.ContextHeader.Roster_Tab;
    if (RosterData.SelectedClass.id !== PreviousRosterData.SelectedClass.id) {
      this.getClassReadingLevelProgressChartAPI();
      clearInterval(this.interval);
    }
  }

  donutApi() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let payLoadData = {
      // classId: this.props.ContextHeader.Roster_Tab.SelectedClass.id.toString(),
      // // endDate: "01/01/2025",
      // // startDate: "01/01/2018",
      // endDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termEndDate ?
      //   this.props.ContextHeader.Date_Tab.Report_termEndDate :
      //   this.props.ContextHeader.Date_Tab.selectedterm_Obj.termEndDate),
      // startDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termStartDate ?
      //   this.props.ContextHeader.Date_Tab.Report_termStartDate :
      //   this.props.ContextHeader.Date_Tab.selectedterm_Obj.termStartDate),
      ...getCommonHeaders(summaryFilterData, 'class'),
      readingLevel: this.readingTargetValue
    };
    this.props.RLP_DONUT_TARGET_DATA(
      this.props.LoginDetails.JWTToken,
      payLoadData
    );
  }
  getClassReadingLevelProgressChartAPI() {
     let externalFilter = {};
    this.setState({
      ...this.state,
      timeOut: false
    });
    if (this.props && !this.state.timeOut) {
      this.setState({ ...this.state, externalFilter: externalFilter });
      const summaryFilterData = {
        ...this.props,
        CommonFilterData: this.props.SummaryFilterData,
      };
      let data = { ...getCommonHeaders(summaryFilterData, 'class') }
      this.props.CLASS_READING_LEVEL_PROGRESS(
        this.props.LoginDetails.JWTToken,
        data
      );
    }
  }

  navigateToStudentOrr(selectedStudent) {
    this.props.GetCompleteStudentReport(selectedStudent, "", {}, this.props.ContextHeader.presentDataForStudentId)
  }
  //Side panel Grid API for Class RLP
  gridApi() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let data = {
      ...getCommonHeaders(summaryFilterData, 'class'),
      sidePanelFilter: this.constructedSidePanelFilter
    };
    this.props.READING_LEVEL_GRID_DATA(this.props.LoginDetails.JWTToken, data);
    this.props.SIDE_PANEL_SPINNER();
  }

  bubblesSelected(bubs) {
    if (bubs.length !== 0) {
      this.readingTargetValue = "";
      var readingLevelList = [];
      for (let i of bubs) {
        readingLevelList.push({
          proficiencyType: i.type,
          readingLevel: i.readingLevel
        });
      }
      this.constructedSidePanelFilter = {
        monthYear: bubs[0].monthYear,
        // monthYear: '09/2018',
        readingLevelList: readingLevelList
      };
      this.gridApi();
    }
    if (bubs && bubs.length > 0) {
      this.props.RETAIN_BUBBLE_COLOR({
        [bubs[0]["month"]]: bubs
      });
    } else {
      this.props.RETAIN_BUBBLE_COLOR({});
    }
  }
  bubblesSelectedForReadingTarget(bubs) {
    this.readingTargetValue = bubs.readingLevel;
    this.donutApi();
    // this.props.RETAIN_BUBBLE_COLOR();
  }
  // handle timeout
  timeOut() {
    this.setState({ ...this.state, timeOut: true });
  }
  // toggle grouping
  toggleHidden() {
    this.props.SHOW_HIDE_GROUPING(false);
  }
  clearBubbleSelection() {
    this.props.CLEAR_BUBBLE_COLOR(null);
  }

  // Download csv data
  downLoadCSVData() {

    this.props.CLRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let Req_Payload = {
      classChartType: {
        "allRecordsAvgFlag": 0,
        "chartName": "CRLP"
      },
      ...getCommonHeaders(summaryFilterData, 'class')
    };
    this.props.CLRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    if (this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] && this.props.ClassCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.CLRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    const {Summary_Reports}= this.props.NavigationByHeaderSelection;
    let RosterData =  Summary_Reports ? this.props.ContextHeader.Summary_Roster_Data:  this.props.ContextHeader.Roster_Tab
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + RosterData.SelectedClass.name;
    return (
      <div className="sum-error pos-rel">
        {this.props.NavigationByHeaderSelection.class &&
          RosterData.SelectedClass.id ? (
            <div>

              {this.props.isApiLoading && !this.state.timeOut && (
                <Spinner
                  startSpinner={this.props.isApiLoading}
                  showTimeOut={this.timeOut}
                />
              )}
              {this.state.timeOut && (
                <TimeOut tryAgain={this.getClassReadingLevelProgressChartAPI} />
              )}
              {this.props.apiLoadFail &&
                this.props.sum_crlp_Object == "" &&
                !this.props.sum_crlp_Object &&
                !this.props.isApiLoading && (
                  <NoRecordsData NodataFound={"dataNotAvail"} />
                )}

              {this.props.apiLoadFail &&
                this.props.sum_crlp_Object !== "" &&
                !this.props.sum_crlp_Object &&
                !this.props.isApiLoading && (
                  <ChartNotLoad
                    tryAgain={this.getClassReadingLevelProgressChartAPI}
                  />
                )}
              {!this.props.isApiLoading &&
                this.props.sum_crlp_Object &&
                !this.props.apiLoadFail && (
                  <div className="container container-resolution sum-modal-crlp sum-crlp">
                    <div className="row mt-10 mt-7">
                      {this.props.sum_crlp_Object && (
                        <React.Fragment>
                          <span className="sum-class-print-btn ">
                            <span className="hover-print">
                              Print
                              <span className="tooltip-dot-sum" />
                            </span>
                            <PrintCRlp
                              summaryFlag={true}
                              monthRangeObj={this.props.monthRangeObj}
                              selAll={this.props.selAll}
                              toggleData={this.props.toggleData}
                              selectedFilter={this.props.SummaryFilterData}
                              studentDetails={this.props.ContextHeader}
                              navSelected={this.props.NavigationByHeaderSelection}
                              Class_RLP_Object={this.props.Class_RLP_Object}
                              selectedBubs={this.props.selectedBubbles}
                              gridData={this.props.RlpGridData.RlpData}
                              Data={this.props.SortData}
                              gridFilterData={
                                this.props.RlpGridData.GridFilterData
                              }
                              rosterCount={this.props.RlpGridData.RosterCount}
                              PieChartData={this.props.PieChartData}
                              DonutFlag={this.props.DonutFlag}
                              gridHeaderData={
                                this.props.Class_RLP_Object.readingTarget
                              }
                              gridTitle={this.props.selectedBubbles}
                            />
                          </span>
                          {this.props.ClassCsvDownload && this.props.ClassCsvDownload['csvData'] &&
                            <CSVLink
                              ref="groupCSV"
                              headers={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['header']}
                              data={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['data']}
                              style={{ display: 'none' }}
                              filename={`${csvFileName}.csv`} />}
                          <div className="sum-class-csv" onClick={() => !this.props.ClassCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                            {this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] ?
                              <span className="csv_download_icon">
                                <i className="material-icons">autorenew</i>
                              </span> :
                              <span className="csv_download_icon">
                                <img src={CsvIcon} width="20" height="20" />
                              </span>}
                          </div>
                          <Class_RLP
                            updateScrollData={data => {
                              this.props.Summary_Scroll_Data(data);
                            }}
                            sum_crlp_Object={this.props.sum_crlp_Object}
                            bubblesSelected={bubs => {
                              this.bubblesSelected(bubs);
                            }}
                            clearBubbles={() => {
                              //this.clearBubbleSelection();
                            }}
                            bubblesSelectedForReadingTarget={bubs => {
                              this.bubblesSelectedForReadingTarget(bubs);
                            }}
                            // getBubbleBackgroundColorOnSelection= {this.props.RETAIN_BUBBLE_COLOR()}
                            selectedBubs={this.props.selectedBubbles}
                          />
                        </React.Fragment>
                      )}



                    </div>
                  </div>
                )}
            </div>
          ) : (
            <NoRosterData />
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  ClassGridRlpData,
  Authentication,
  C_GroupingReducer,
  SummaryFilterDetails
}) => {
  const {
    Class_RLP_Object,
    sum_crlp_Object,
    isApiLoading,
    sidePanelLoad,
    apiLoadFail,
    selectedBubbles,
    RlpGridData,
    SortData,
    PieChartData,
    DonutFlag,
    bubblesSelected,
    bubblesSelectedForReadingTarget,
    getClassReadingLevelProgressChartAPI,
    monthRangeObj,
    selAll,
    toggleData,
    ClassCsvDownload
  } = ClassGridRlpData;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { LoginDetails } = Authentication;
  const { showGrouping } = C_GroupingReducer;
  const { SummaryFilterData } = SummaryFilterDetails;
  return {
    Class_RLP_Object,
    sum_crlp_Object,
    isApiLoading,
    apiLoadFail,
    selectedBubbles,
    RlpGridData,
    SortData,
    ContextHeader,
    NavigationByHeaderSelection,
    PieChartData,
    DonutFlag,
    bubblesSelected,
    bubblesSelectedForReadingTarget,
    getClassReadingLevelProgressChartAPI,
    LoginDetails,
    showGrouping,
    sidePanelLoad,
    monthRangeObj,
    selAll,
    toggleData,
    ClassCsvDownload,
    SummaryFilterData
  };
};

export default connect(mapStateToProps, {
  READING_LEVEL_GRID_DATA,
  GetCompleteStudentReport,
  RETAIN_BUBBLE_COLOR,
  RLP_DONUT_TARGET_DATA,
  CLASS_READING_LEVEL_PROGRESS,
  Summary_Scroll_Data,
  SHOW_HIDE_GROUPING,
  SAVE_GROUPING_DATA,
  SORT_RLP_GRID_COLUMN,
  CLEAR_BUBBLE_COLOR,
  SIDE_PANEL_SPINNER,
  CLRLP_CSVDATA_DOWNLOAD_APICALL,
  CLRLP_CSVDATA_DOWNLOAD_RESET,
  CHART_SPINNER
})(SummaryCRlpChart);
