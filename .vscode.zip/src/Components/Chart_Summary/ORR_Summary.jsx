import React, { Component } from 'react';
import { connect } from 'react-redux';
import S_ReadingLevelProgress from '../ORR/ReadingLevelProgressComponents/S_RLP.jsx'
import Summary_SRLP from './Summary_SRLP/S_RLP.jsx'
import SummaryCRlpChart from './Summary_CRLP/RLP_Chart.jsx'
import SummarySchoolRLPChart from './Summary_ScRlp/Sc_RLPChart.jsx';
import SummaryDstRlpChart from './Summary_DRLP/Dist_RLPChart.jsx';
import { CLOSE_SUMMARY_POPUP } from '../../Redux_Actions/SummaryTabAction.jsx';
import RlpChart from '../Class_ORR/ChartComponents/RLP_Chart.jsx';
import DistrictRLPChart from '../District_ORR/Dist_RLPComponents/Dist_RLPChart.jsx';
import SchoolRLPChart from '../School_ORR/Sc_RLPComponents/Sc_RLPChart.jsx'


class ORR_Summary extends Component {
    constructor(props) {
        super(props);
        this.closePopUp = this.closePopUp.bind(this)
    }


    closePopUp() {
        this.props.CLOSE_SUMMARY_POPUP();
    }

    render() {
        let nav = this.props.NavigationByHeaderSelection;
        return (
            <React.Fragment>
                {!this.props.popUp &&
                    <div>
                        {nav.student && <Summary_SRLP />}
                        {nav.class && <SummaryCRlpChart />}
                        {nav.school && <SummarySchoolRLPChart />}
                        {nav.district && <SummaryDstRlpChart />}
                    </div>}

                {<div id="myModal" className="sum-modal cg-modal"
                    style={{ display: this.props.popUp ? 'block' : 'none' }} >
                    {/* <!-- Modal content --> */}
                    {nav.Summary_Tab && this.props.popUp &&
                        <div className="sum-modal-content-new" >
                            <div onClick={this.closePopUp} className="close-icon-popup">
                                <svg width="24" height="24" viewBox="0 0 24 24" focusable="false" role="presentation"><path d="M12 10.586L6.707 5.293a1 1 0 0 0-1.414 1.414L10.586 12l-5.293 5.293a1 1 0 0 0 1.414 1.414L12 13.414l5.293 5.293a1 1 0 0 0 1.414-1.414L13.414 12l5.293-5.293a1 1 0 1 0-1.414-1.414L12 10.586z" fill="currentColor">
                                </path>
                                </svg>
                                {/* <button onClick={this.closePopUp}>button</button> */}
                            </div>
                            {nav.student && <S_ReadingLevelProgress />}
                            {nav.class && <RlpChart />}
                            {nav.school && <SchoolRLPChart />}
                            {nav.district && <DistrictRLPChart />}
                        </div>}
                </div>
                }
            </React.Fragment>
        );
    }
}

const mapStateToProps = ({ SummaryTabReducer, Universal }) => {
    const { popUp } = SummaryTabReducer;
    const { NavigationByHeaderSelection } = Universal;
    return {
        popUp,
        NavigationByHeaderSelection
    }
}
// export default ORR_Summary;

export default connect(mapStateToProps, { CLOSE_SUMMARY_POPUP })(ORR_Summary);