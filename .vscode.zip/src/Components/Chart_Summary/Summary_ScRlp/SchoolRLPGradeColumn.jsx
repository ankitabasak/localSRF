import React, { Component } from 'react';
import rightScroll from '../../../../public/assets/orr/rlp-screen/x-next.svg';
import rightScrollActive from '../../../../public/assets/orr/rlp-screen/x-next-active.svg';
import rightExtremeScroll from '../../../../public/assets/orr/rlp-screen/x-next-end.svg';
import rightExtremeScrollActive from '../../../../public/assets/orr/rlp-screen/x-next-end-active.svg';
import backArrow from '../../../../public/assets/orr/rlp-screen/top-arrow.svg';
import { constructElipsisText } from '../../../Utils/Text';

class SchoolRlpGrade extends Component {
  getGradeRange(GLRange, level, selectedClassLevels, currentLevelInfo) {
    let bgColor = '';
    let textColor = 'black';

    if (GLRange.indexOf(level) > -1) {
      bgColor = '#d6dbe5';
      textColor = 'black';
    }

    if (selectedClassLevels && selectedClassLevels[currentLevelInfo.type]) {
      selectedClassLevels[currentLevelInfo.type].forEach(obj => {
        if (
          JSON.stringify(currentLevelInfo.orrAssignmentId) ==
          JSON.stringify(obj.orrAssignmentId)
        ) {
          bgColor = '#00539B';
          textColor = 'white';
          return;
        }
      });
    }

    return { backgroundColor: bgColor, color: textColor };
  }
  //to display the last passage
  showToolTip(passage) {
    return (
      <div className="hover-rlp">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }
  render() {
    if (this.props.currentChartInDisplay == 'SLRLP') {
      return (
        <div
          className={this.props.gradesData.length == 1 ? "graph-content pull-left pos-rel single-month" : "graph-content pull-left pos-rel"}
          style={{ border: 'none', marginLeft: '4px' }}
        >
          {this.props.gradesData.map((item, index) => {
            return (
              <div className="first-coloumn-srlp pull-left pos-rel" key={index}>
                <div className="rhs-line3-srlp">
                  <div className="top-small-strip">
                    <div className="top-lhs-strip-bar"></div>
                    <div className="top-rhs-strip-bar"></div>
                  </div>
                  <div className="top-small-strip new-top-small-strip">
                    <div className="btm-lhs-strip-bar"></div>
                    <div className="btm-rhs-strip-bar"></div>
                  </div>
                  <div className="chart-line-lhs-adj"></div>
                  <div className="chart-line-rhs-adj"></div>
                </div>
                <div className="top-slide-section-srlp">

                </div>
                <div className="up-sec-srlp">
                  <div className="sub-first-column-srlp pull-left pos-rel">
                    <div className="block-sec-srlp">
                      <ul>
                        {this.props.readingLevels.map((readingLevel, index) => {
                          if (
                            item.recordDataList['firstRecord'][readingLevel]
                          ) {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel,
                                  this.props.selectedLevels,
                                  {
                                    type: 'firstRecord',
                                    grade: item.grade,
                                    orrAssignmentId:
                                      item.recordDataList['firstRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  }
                                )}
                                // onClick={() => {
                                //   this.props.selectedClassLevels({
                                //     type: 'firstRecord',
                                //     rl: readingLevel,
                                //     grade: item.grade,
                                //     orrAssignmentId:
                                //       item.recordDataList['firstRecord'][
                                //       readingLevel
                                //       ]['orrAssignmentId']
                                //   });
                                // }}
                                className="cursor-pointer"
                              >
                                <span>
                                  {item.recordDataList['firstRecord'][
                                    readingLevel
                                  ]['percentage'] + '%'}
                                </span>
                              </li>
                            );
                          } else {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel
                                )}
                              >
                                <span />
                              </li>
                            );
                          }
                        })}
                      </ul>
                    </div>
                    <div className="wcpm-section-srlp c1-srlp">
                      <p>First</p>
                    </div>
                  </div>
                  <div className="sub-second-column-srlp pull-left pos-rel">
                    <div className="block-sec-2nd-srlp">
                      <ul>
                        {this.props.readingLevels.map((readingLevel, index) => {
                          if (
                            item.recordDataList['recentRecord'][readingLevel]
                          ) {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel,
                                  this.props.selectedLevels,

                                  {
                                    type: 'recentRecord',
                                    grade: item.grade,
                                    orrAssignmentId:
                                      item.recordDataList['recentRecord'][
                                      readingLevel
                                      ]['orrAssignmentId']
                                  }
                                )}
                              // onClick={() => {
                              //   this.props.selectedClassLevels({
                              //     type: 'recentRecord',
                              //     grade: item.grade,
                              //     orrAssignmentId:
                              //       item.recordDataList['recentRecord'][
                              //       readingLevel
                              //       ]['orrAssignmentId']
                              //   });
                              // }}
                              // className="cursor-pointer"
                              >
                                <span>
                                  {item.recordDataList['recentRecord'][
                                    readingLevel
                                  ]['percentage'] + '%'}
                                </span>
                              </li>
                            );
                          } else {
                            return (
                              <li
                                key={index}
                                style={this.getGradeRange(
                                  item.gradeWiseReadingLevelRange,
                                  readingLevel
                                )}
                              >
                                <span />
                              </li>
                            );
                          }
                        })}
                      </ul>
                    </div>
                    <div className="wcpm-section-srlp c2-srlp">
                      <p>Recent</p>
                    </div>
                  </div>
                </div>
                <div
                  className="month-section-srlp"
                // onClick={() => {
                //   this.props.getClassLevelRLPData({
                //     schoolGrade: item.grade
                //   });
                // }}
                >
                  <span>{constructElipsisText(item.grade)}</span>
                  {/* {this.showToolTip('Click here for Grade Level Report')} */}
                </div>
              </div>
            );
          })}

          <div className="last-col-wrap-srlp">
            <div className="last-col-srlp">
              <div className="last-bord">
                <div className="last-line-lhs-adj"></div>
                <div className="last-line-rhs-adj"></div>
                <div className="last-line-top-rhs-adj"></div>
              </div>
              <p>Reading Level Progress</p>
            </div>
            <div className="btm-arrow-lft-srlp">
              <div
                className="btm-ic-rhs-last-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('right');
                }}
              >
                {this.props.scrollIndex <
                  this.props.totalGradeItems.length - 3 ? <img src={rightScrollActive} className="cursor-pointer" /> : <img src={rightScroll} />
                }

              </div>
              <div
                className="btm-ic-rhs-prev-srlp"
                onClick={() => {
                  this.props.scrollGradeLevels('extremeRight');
                }}
              >
                {this.props.scrollIndex <
                  this.props.totalGradeItems.length - 3 ? <img src={rightExtremeScrollActive} className="cursor-pointer" /> : <img src={rightExtremeScroll} />
                }
              </div>
            </div>
          </div>

          <div style={{ clear: 'both' }} />
        </div>
      );
    } else {
      return <div />;
    }
  }
}

export default SchoolRlpGrade;
