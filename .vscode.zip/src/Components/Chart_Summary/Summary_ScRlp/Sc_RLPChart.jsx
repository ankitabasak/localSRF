import React, { Component } from 'react';
import './school-rlp.css';
import YAxisComponent from './School_RLP_Reading_Levels.jsx';
import SchoolRlpGrade from './SchoolRLPGradeColumn.jsx';
import { connect } from 'react-redux';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  Show_loading_Icon,
  School_RLP_Grid_Chart_Table_API,
  School_Class_Grid_Chart_Table_API,
  Sum_Sc_RLP_Chart_API,
  Sum_ScRlp_Scroll_Data,
  School_Class_Level_RLP_Chart_API,
  Selected_Levels,
  Chart_loading_Failed,
  SCHRLP_CSVDATA_DOWNLOAD_APICALL,
  SCHRLP_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/School_RlpActions.jsx';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import PrintScRlp from '../../ReusableComponents/PrintOrrCharts/Sc_RlpPrint.jsx';
import NoRecordsData from '../../../Utils/No_Data_Found';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';

class SummarySchoolRLPChart extends Component {
  constructor(props) {
    super(props);
    this.schoolRlpGridApi = this.schoolRlpGridApi.bind(this);
    this.backToMainChart = this.backToMainChart.bind(this);
    this.tryAgainFunction = this.tryAgainFunction.bind(this);
  }

  componentDidMount() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let payLoad = getCommonHeaders(summaryFilterData, 'school')
    this.props.Sum_Sc_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  componentDidUpdate(prevProps) {
    if (this.props.ContextHeader.Roster_Tab.SelectedSchool.id !== prevProps.ContextHeader.Roster_Tab.SelectedSchool.id) {
      const summaryFilterData = {
        ...this.props,
        CommonFilterData: this.props.SummaryFilterData,
      };
      let payLoad = getCommonHeaders(summaryFilterData, 'school');
      this.props.Sum_Sc_RLP_Chart_API(
        this.props.LoginDetails.JWTToken,
        payLoad
      );
    }
  }

  // time out
  timeOut() {
    this.props.Chart_loading_Failed({ timeOut: true });
  }
  //schoolRlp Grid API

  schoolRlpGridApi(selectedLevels) {
    let SL;
    let grade = 'grade';

    if (this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP') {
      grade = 'className';
    }

    if (selectedLevels['recentRecord']) {
      SL = selectedLevels['recentRecord'].map(obj => {
        if (grade == 'className') {
          return {
            [grade]: obj[grade],
            classId: obj['classId'],
            orrAssignmentId: obj.orrAssignmentId,
            ['grade']: this.props.SchoolRLPState.schoolLevelGrade
          };
        } else {
          return { [grade]: obj[grade], orrAssignmentId: obj.orrAssignmentId };
        }
      });
    } else if (selectedLevels['firstRecord']) {
      SL = selectedLevels['firstRecord'].map(obj => {
        if (grade == 'className') {
          return {
            [grade]: obj[grade],
            classId: obj['classId'],
            orrAssignmentId: obj.orrAssignmentId,
            ['grade']: this.props.SchoolRLPState.schoolLevelGrade
          };
        } else {
          return { [grade]: obj[grade], orrAssignmentId: obj.orrAssignmentId };
        }
      });
    } else {
      SL = selectedLevels;
    }

    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };

    let Payload = {
      ...getCommonHeaders(summaryFilterData, 'school'),
      selectedLevels: SL
    };

    if (this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP') {
      this.props.School_RLP_Grid_Chart_Table_API(
        this.props.LoginDetails.JWTToken,
        Payload
      );
    } else if (this.props.SchoolRLPState.currentChartInDisplay == 'CLRLP') {
      this.props.School_Class_Grid_Chart_Table_API(
        this.props.LoginDetails.JWTToken,
        Payload
      );
    }
  }

  // X axis scroll control
  getGradeArray(listItems, index) {
    return listItems.slice(index, 3);
  }
  // check for duplicate value
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          JSON.stringify(bubble.orrAssignmentId) ==
          JSON.stringify(obj.orrAssignmentId)
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  saveSelectedLevels(levels, selLvls) {
    let selectedLevels = selLvls[levels.type];
    if (selectedLevels) {
      let duplicateIndex = this.isDuplicateBubble(levels, selectedLevels);

      if (duplicateIndex != -1) {
        selectedLevels.splice(duplicateIndex, 1);
      } else {
        selectedLevels.push(levels);
      }

      this.props.Selected_Levels({
        ['selectedLevels']: { [levels.type]: selectedLevels }
      });

      this.schoolRlpGridApi({ [levels.type]: selectedLevels });
    } else {
      selectedLevels = { [levels.type]: [levels] };

      this.props.Selected_Levels({
        ['selectedLevels']: selectedLevels
      });
      this.schoolRlpGridApi(selectedLevels);
    }
  }

  getAxisRangeData(dataList, index) {
    let rl = dataList.slice(index, 7);
    return rl.reverse();
  }

  scrollUpDown(dataList, index, scrollType) {
    let rl = [];
    switch (scrollType) {
      case 'up':
        if (index < dataList.length - 7) {
          let scrlIndex = index + 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 7);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'down':
        if (index > 0) {
          let scrlIndex = index - 1;
          rl = dataList.slice(scrlIndex, scrlIndex + 7);
          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeTop':
        if (index < dataList.length - 7) {
          rl = dataList.slice(dataList.length - 7, dataList.length);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: dataList.length - 7
          });
        }
        return;
      case 'extremeBottom':
        if (index > 0) {
          let scrlIndex = 0;
          rl = dataList.slice(0, 7);

          this.setDataScrollState({
            yAxisDataRange: rl.reverse(),
            yScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  setDataScrollState(data) {
    this.props.Sum_ScRlp_Scroll_Data(data);
  }

  scrollRightLeft(dataList, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataList.length - 3) {
          let scrlIndex = index + 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + 3),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let scrlIndex = index - 1;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, scrlIndex + 3),
            xScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataList.length - 3) {
          let scrlIndex = dataList.length - 3;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(scrlIndex, dataList.length),
            xScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let scrlIndex = 0;

          this.setDataScrollState({
            xAxisGradeRange: dataList.slice(0, 3),
            xScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  getClassLevelRLPData(grade) {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    this.props.Show_loading_Icon('');
    let payLoad = {
      ...getCommonHeaders(summaryFilterData, 'school'),
      grade: grade.schoolGrade,
    };

    this.props.School_Class_Level_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  tryAgainFunction() {
    this.backToMainChart()
  }

  backToMainChart() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    this.props.Show_loading_Icon('');
    let payLoad = getCommonHeaders(summaryFilterData, 'school');
    this.props.Sum_Sc_RLP_Chart_API(
      this.props.LoginDetails.JWTToken,
      payLoad
    );
  }

  // Download csv data
  downLoadCSVData() {
    this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP' &&
      this.props.SCHRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let Req_Payload = {
      schoolChartType: {
        "allGrades": true,
        "allRecordsAvgFlag": 0,
        "chartName": "ScRLP1",
        "gradeValue": null
      },
      ...getCommonHeaders(summaryFilterData, 'school')
    };
    this.props.SCHRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    if (this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP') {
      if (this.props.schoolCsvDownload && this.props.schoolCsvDownload['downloadInProgress'] && this.props.schoolCsvDownload['csvData']) {
        setTimeout(() => {
          this.refs.groupCSV.link.click();
          this.props.SCHRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
        }, 500)
      }
    }
    let chartData = this.props.SchoolRLPState.sumScRlpData;
    let gradeSelected = this.props.SchoolRLPState['schoolLevelGrade'];
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedSchool.name;
    return (
      <div className="sum-error pos-rel">
        <div
          className="container sum-scrlp"
          style={{
            maxWidth: '1165px',
            paddingLeft: '0px',
            paddingRight: '0px'
          }}
        >
          {/* {this.props.isApiLoading && <Spinner />} */}
          {!this.props.SchoolRLPState.isApiLoading && chartData && (
            <React.Fragment>

              <div className="row mt-10" style={{ marginTop: '7px' }}>
                {chartData.xAxisGradeRange && this.props.SchoolRlpGridData &&
                  <span className="sum-school-print-btn">
                    <span className="hover-print">
                      Print
                      <span className="tooltip-dot-sum" />
                    </span>
                    <PrintScRlp
                      summaryFlag={true}
                      scrollFlag={true}
                      gradeSelected={gradeSelected}
                      selectedFilter={this.props.SummaryFilterData}
                      studentDetails={this.props.ContextHeader}
                      navSelected={this.props.NavigationByHeaderSelection}
                      axisData={{
                        dataRange: chartData.yAxisDataRange,
                        scrollIndex: chartData.yScrollIndex,
                        xScrollIndex: chartData.xScrollIndex,
                        allReadingLevels: chartData.yAxisData
                      }}
                      gradesData={chartData.xAxisGradeRange}
                      readingLevels={chartData.yAxisDataRange}
                      selectedLevels={this.props.SchoolRLPState.schoolsSelected}
                      currentChartInDisplay={
                        this.props.SchoolRLPState.currentChartInDisplay
                      }
                      totalGradeItems={chartData.xAxisData}
                      scrollIndex={chartData.xScrollIndex}
                      schoolData={this.props.SchoolRlpGridData}
                      sortData={this.props.SortData}
                    />
                  </span>
                }
                {this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP' &&
                  this.props.schoolCsvDownload && this.props.schoolCsvDownload['csvData'] &&
                  <CSVLink
                    ref="groupCSV"
                    headers={this.props.schoolCsvDownload['csvData'] && this.props.schoolCsvDownload['csvData']['header']}
                    data={this.props.schoolCsvDownload['csvData'] && this.props.schoolCsvDownload['csvData']['data']}
                    style={{ display: 'none' }}
                    filename={`${csvFileName}.csv`} />}
                <div className="sum-dst-csv-icon-alignment"
                  onClick={() => !this.props.schoolCsvDownload['downloadInProgress'] && this.downLoadCSVData()

                  }>
                  {this.props.schoolCsvDownload && this.props.schoolCsvDownload['downloadInProgress'] ?
                    <span className="csv_download_icon">
                      <i className="material-icons">autorenew</i>
                    </span> :
                    <span className="csv_download_icon">
                      <img src={CsvIcon} width="20" height="20" />
                    </span>}
                </div>
                <div className="srlp-lhs-wrap sc-rlp-wrap">
                  <div className="wrap-srlp pos-rel ">
                    {!this.props.popUp &&
                    <div className="summary_legend">
                      <div className="summary_legend_child">Legend:</div>
                      <div className="summary_legend_child summary_gray_rect" />
                      <div className="summary_legend_child">Grade Reading Level Target</div>
                    </div>}
                    <div className="readingLevel-srlp">Reading Level</div>
                    <div className="grade-txt-srlp bt-27">
                      {this.props.SchoolRLPState.currentChartInDisplay == 'SLRLP'
                        ? 'Grade'
                        : 'Classes'}
                    </div>
                    <div className="rhs-line-srlp" />
                    <div className="rhs-line2-srlp" />
                    <div className="rhs-line-btm-srlp" />
                    <div className="rhs-line-btm1-srlp" />

                    {chartData.yAxisDataRange && (
                      <YAxisComponent
                        axisData={{
                          dataRange: chartData.yAxisDataRange,
                          scrollIndex: chartData.yScrollIndex,
                          xScrollIndex: chartData.xScrollIndex,
                          allReadingLevels: chartData.yAxisData
                        }}
                        scrollReadingLevels={scrollType => {
                          this.scrollUpDown(
                            chartData.yAxisData,
                            chartData.yScrollIndex,
                            scrollType
                          );
                        }}
                        scrollGradeLevels={scrollType => {
                          this.scrollRightLeft(
                            chartData.xAxisData,
                            chartData.xScrollIndex,
                            scrollType
                          );
                        }}
                      />
                    )}

                    {chartData.xAxisGradeRange && (
                      <SchoolRlpGrade
                        gradesData={chartData.xAxisGradeRange}
                        readingLevels={chartData.yAxisDataRange}
                        selectedClassLevels={selectedLevels => {
                          this.saveSelectedLevels(
                            selectedLevels,
                            this.props.SchoolRLPState.schoolsSelected || {}
                          );
                        }}
                        selectedLevels={this.props.SchoolRLPState.schoolsSelected}
                        currentChartInDisplay={
                          this.props.SchoolRLPState.currentChartInDisplay
                        }
                        scrollGradeLevels={scrollType => {
                          this.scrollRightLeft(
                            chartData.xAxisData,
                            chartData.xScrollIndex,
                            scrollType
                          );
                        }}
                        totalGradeItems={chartData.xAxisData}
                        scrollIndex={chartData.xScrollIndex}
                        getClassLevelRLPData={grade => {
                          this.getClassLevelRLPData(grade);
                        }}
                      />
                    )}
                    {/* <div className="rhs-line4-srlp" /> */}
                  </div>
                </div>

              </div>

            </React.Fragment>)}
          {this.props.SchoolRLPState.isApiLoading && !this.props.chartData && (
            <Spinner
              startSpinner={this.props.isApiLoading}
              showTimeOut={this.timeOut}
            />
          )}
          {!chartData && this.props.SchoolRLPState.timeOut && (
            <TimeOut tryAgain={() => this.tryAgainFunction()} />
          )}
          {!chartData && this.props.SchoolRLPState.apiLoadFail && (
            <ChartNotLoad tryAgain={() => this.tryAgainFunction()} />
          )}
          {!chartData && this.props.SchoolRLPState.noChartData && (
            <NoRecordsData NodataFound={'dataNotAvail'} />)}
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  SchoolRlpData,
  SummaryFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { SchoolRLPState, SchoolRlpGridData, SortData, schoolCsvDownload } = SchoolRlpData;
  const { SummaryFilterData } = SummaryFilterDetails;
  return {
    LoginDetails,
    SchoolRLPState,
    ContextHeader,
    NavigationByHeaderSelection,
    SchoolRLPState,
    SchoolRlpGridData,
    SortData,
    schoolCsvDownload,
    SummaryFilterData
  };
};

export default connect(
  mapStateToProps,
  {
    Show_loading_Icon,
    School_RLP_Grid_Chart_Table_API,
    Sum_Sc_RLP_Chart_API,
    Sum_ScRlp_Scroll_Data,
    School_Class_Level_RLP_Chart_API,
    School_Class_Grid_Chart_Table_API,
    Selected_Levels,
    Chart_loading_Failed,
    SCHRLP_CSVDATA_DOWNLOAD_APICALL,
    SCHRLP_CSVDATA_DOWNLOAD_RESET,
  }
)(SummarySchoolRLPChart);
