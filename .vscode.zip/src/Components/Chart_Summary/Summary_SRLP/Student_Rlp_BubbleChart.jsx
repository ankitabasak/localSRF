import React, { Component } from 'react';
import * as d3 from 'd3';
import { connect } from 'react-redux';
import { show_pop_update, Update_Tooltip_data } from '../../../Redux_Actions/S_ReadingLevelAction.jsx';

class StudentRlpBubbleChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedBubId: null,
      showTooltip: false,
      toolTipData: null,
      isHovered: false,
      hoverBubId: null
    };
    this.onMouseOver = this.onMouseOver.bind(this);
    this.onMouseOut = this.onMouseOut.bind(this);
    this.popCircle = this.popCircle.bind(this);
  }

  onMouseOver(i) {
    this.setState({ isHovered: true, hoverBubId: i });
  }

  onMouseOut() {
    this.setState({ isHovered: false, hoverBubId: null });
  }

  //onclick set the radius of the bubble
  popCircle(d, i, cx, cy) {
    if (this.state.selectedBubId === i) {
      this.setState({
        selectedBubId: null,
        showTooltip: false,
        toolTipData: null
      });
      this.props.show_pop_update('false');
      this.showTooltipFn(null);
    } else {
      this.setState({ selectedBubId: i, showTooltip: true, toolTipData: d });
      this.props.show_pop_update('true');
      this.showTooltipFn(d, cx, cy);
    }
  }

  //tooltip code
  showTooltipFn(d, xPoint, yPoint) {
    this.props.getToolTipData(d, xPoint, yPoint);
    this.props.Update_Tooltip_data({ d: d, xPoint: xPoint, yPoint: yPoint })
  }
  render() {
    const chartData = this.props.chartData;

    const circleColor = {
      Instructional: '#32ac41',
      Independent: '#008ad9',
      Frustrational: '#ffc52d'
    };

    const circleFillColor = {
      Instructional: '#178e26',
      Independent: '#0872ae',
      Frustrational: '#d7aa35'
    };
    const margin = 10;
    const chartHeight = this.props.svgHeight;
    const chartWidth = this.props.svgWidth - 50;

    const xScale = d3
      .scaleLinear()
      .domain([0, 6])
      .range([0, chartWidth]);

    const yScale = d3
      .scaleLinear()
      .domain([0, 6])
      .range([0, chartHeight - 30]);

    const xTicks = xScale.ticks(6).map((d, index) => {
      return xScale(d) > 0 ? (
        <g key={index}>
          <g transform={`translate(${xScale(d) + 30.000000429},${chartHeight - margin - 28})`}>

          </g>
          <g
            textAnchor="middle"
            transform={`translate(${(xScale(d) - 38) - 31.999999571},${254})`}
          >
            <text className="date-name" transform="translate(6,24)">
              {chartData.modifiedSumAssDate[d - 1]
                ? chartData.modifiedSumAssDate[d - 1]['assignmentDate']
                : ''}
            </text>
            <polygon
              className="poly-fill"
              fill="#bdc2cd"
              stroke="#bdc2cd"
              points="6.5,0 1,6 6.5,12 12,6"
            />
          </g>
        </g>
      ) : null;
    });

    const yTicks = yScale.ticks(6).map((d, index) =>
      yScale(d) > margin && yScale(d) < chartHeight ? (
        <g
          transform={`translate(${margin},${chartHeight - 28 - yScale(d)})`}
          key={index}
        >
          {/* <text x="-12" y="5">{xFormat(d)}</text> */}
          {/* <line x1="0" x1="5" y1="0" y2="0" transform="translate(-5,0)" /> */}
          {/* <line className='gridline' x1='0' x1={w - margin} y1='0' y2='0' transform="translate(-5,0)"/>  */}
        </g>
      ) : null
    );
    const bubbles = yScale.ticks(6).map((d, i) => {
      return yScale(d) > 0 && yScale(d) < chartHeight ? (
        chartData.modifiedSumAssDate[d - 1] ? (
          <g
            onMouseOver={() => this.onMouseOver(i)}
            onMouseOut={this.onMouseOut}
            key={i}
            transform={`translate(${xScale(d) +
              5 -
              (xScale(2) - xScale(1)) / 2}, 
              ${chartHeight + 20 -
              yScale(
                chartData.modifiedSumAssDate[d - 1]
                  ? chartData.modifiedSumAssDate[d - 1]['a']
                  : 0
              ) -
              (yScale(2) - yScale(1)) / 2})`}
            className="bubbles"
            onClick={() =>
              this.popCircle(
                chartData.modifiedSumAssDate[d - 1],
                d,
                xScale(d) + 5 - (xScale(2) - xScale(1)) / 2,
                chartHeight +
                20 -
                yScale(
                  chartData.modifiedSumAssDate[d - 1]
                    ? chartData.modifiedSumAssDate[d - 1]['a']
                    : -1
                ) -
                (yScale(2) - yScale(1)) / 2
              )
            }
          >
            <circle
              className={
                this.state.selectedBubId === i ||
                  (this.state.hoverBubId === i && this.state.isHovered)
                  ? 'drop-shadow'
                  : ''
              }
              // cx={xScale(d) - (xScale(2) - xScale(1)) / 2}
              // cy={yScale(d) - (yScale(2) - yScale(1)) / 2}
              r={
                this.state.selectedBubId === i ||
                  (this.state.hoverBubId === i && this.state.isHovered)
                  ? '16'
                  : '15'
              }
              strokeWidth="2px"
              stroke={
                this.state.selectedBubId === i ||
                  (this.state.hoverBubId === i && this.state.isHovered)
                  ? circleFillColor[
                  chartData.modifiedSumAssDate[d - 1]
                    ? chartData.modifiedSumAssDate[d - 1]['proficiency']
                    : ''
                  ]
                  : circleColor[
                  chartData.modifiedSumAssDate[d - 1]
                    ? chartData.modifiedSumAssDate[d - 1]['proficiency']
                    : ''
                  ]
              }
              fill={
                this.state.selectedBubId === i ||
                  (this.state.hoverBubId === i && this.state.isHovered)
                  ? '#F9FAFC;'
                  : '#fff'
              }
              cursor="pointer"
              fillOpacity={
                this.state.selectedBubId === i ||
                  (this.state.hoverBubId === i && this.state.isHovered)
                  ? '0.025'
                  : '0.6'
              }
            />
            <text
              // transform="translate(-6, 6)"
              fontFamily="Quicksand"
              stroke="#000000"
              fontSize="12"
              cursor="pointer"
              className="svg-txt-alignment"
            >
              {chartData.modifiedSumAssDate[d - 1]
                ? chartData.modifiedSumAssDate[d - 1]['b']
                : ''}
            </text>
            {/* <circle
            cx={xScale(d) - (xScale(2) - xScale(1)) / 2}
            cy={yScale(d) - (yScale(2) - yScale(1)) / 2}
            r=""
          /> */}
          </g>
        ) : (
            ''
          )
      ) : null;
    });

    return (
      <g>
        {/* <line
          transform={'translate(0, 12)'}
          className="x-axis"
          x1="0"
          x2="700"
          y1="420"
          y2="420"
          stroke="#000"
        /> */}
        <g className="axis-labels" transform={'translate(39,-13)'}>
          {xTicks}
        </g>
        <g className="axis-labels">{yTicks}</g>
        <g className="circles"> {bubbles}</g>
      </g>
    );
  }
}

// export default StudentRlpBubbleChart;

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { show_pop_update, Update_Tooltip_data }
)(StudentRlpBubbleChart);
