import React, { Component } from 'react';
// import Filter from '../FilterComponents/Filter';
import { connect } from 'react-redux';
import {
  S_RLP_API_CALL,
  SUMMARY_SRL_CHART_YAXIS_SCROLL,
  SUMMARY_SRL_CHART_XAXIS_SCROLL,
  Chart_Enabled,
  SRLP_CSVDATA_DOWNLOAD_APICALL,
  SRLP_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import StudentRlpChart from './S_RlpChart.jsx';
import NoRecordsData from '../../../Utils/No_Data_Found';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import PrintS_RLP from '../../ReusableComponents/PrintOrrCharts/S_RlpPrint.jsx';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';

class Summary_SRLP extends Component {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false
    };
    this.timeOut = this.timeOut.bind(this);
    this.studentReadingLevelApi = this.studentReadingLevelApi.bind(this);
    this.showChart = this.showChart.bind(this);
  }

  componentDidMount() {
    this.studentReadingLevelApi();
  }

  showChart(chartEnabled) {
    this.props.Chart_Enabled(chartEnabled)
  }
  // handle timeout
  timeOut() {
    this.setState({ ...this.state, timeOut: true });
  }
  //  Y Scroll
  updateYScrolledData(chartData) {
    this.props.SUMMARY_SRL_CHART_YAXIS_SCROLL(chartData);
  }
  updateXScrolledData(chartData) {
    this.props.SUMMARY_SRL_CHART_XAXIS_SCROLL(chartData);
  }
  studentReadingLevelApi() {
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let Req_Payload = getCommonHeaders(summaryFilterData, 'student');
    this.setState({
      ...this.state,
      timeOut: false
    });

    this.setState({ externalFilter: Req_Payload.externalFilter });
    this.props.S_RLP_API_CALL(
      this.props.LoginDetails.JWTToken,
      Req_Payload,
      'student'
    );
  }

  // Download csv data
  downLoadCSVData() {

    this.props.SRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    const summaryFilterData = {
      ...this.props,
      CommonFilterData: this.props.SummaryFilterData,
    };
    let Req_Payload = getCommonHeaders(summaryFilterData, 'student');
    this.props.SRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    if (this.props.SRLPCSVDownload && this.props.SRLPCSVDownload['downloadInProgress'] && this.props.SRLPCSVDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.SRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedStudent.name;
    return (
      <div className="sum-error pos-rel">
        {this.props.NavigationByHeaderSelection.student &&
          this.props.ContextHeader.Roster_Tab.SelectedStudent.id ? (
            <div>
              {this.props.StudentRlpChartData.sRlpResponse &&
                !this.props.isDataAvailable && (
                  <React.Fragment>
                    <span className="sum-class-print-btn top-63">
                      <span className="hover-print">
                        Print
                          <span className="tooltip-dot-sum" />
                      </span>
                      <PrintS_RLP
                        summaryFlag={true}
                        selectedFilter={this.props.SummaryFilterData}
                        studentDetails={this.props.ContextHeader}
                        navSelected={this.props.NavigationByHeaderSelection}
                        StudentRlpChartData={this.props.StudentRlpChartData}
                      />
                    </span>
                    {this.props.SRLPCSVDownload && this.props.SRLPCSVDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.SRLPCSVDownload['csvData'] && this.props.SRLPCSVDownload['csvData']['header']}
                        data={this.props.SRLPCSVDownload['csvData'] && this.props.SRLPCSVDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        filename={`${csvFileName}.csv`} />}
                    <div className="sum-stu-csv" onClick={() => !this.props.SRLPCSVDownload['downloadInProgress'] && this.downLoadCSVData()}>
                      {this.props.SRLPCSVDownload && this.props.SRLPCSVDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <StudentRlpChart
                      sRlpChart={this.props.StudentRlpChartData}
                      initiateXScroll={cData => {
                        this.updateXScrolledData(cData);
                      }}
                      initiateYScroll={cData => {
                        this.updateYScrolledData(cData);
                      }}

                      UpdateSrlpChart={chartEnabled => {
                        this.showChart(chartEnabled)
                      }}
                    />


                  </React.Fragment>
                )}
              {!this.props.StudentRlpChartData.sRlpResponse &&
                !this.state.timeOut &&
                this.props.isApiLoading && (
                  <Spinner
                    startSpinner={!this.props.StudentRlpChartData.sRlpResponse}
                    showTimeOut={this.timeOut}
                  />
                )}
              {!this.props.StudentRlpChartData.sRlpResponse &&
                this.state.timeOut &&
                !this.props.responseErrCode && (
                  <TimeOut tryAgain={this.studentReadingLevelApi} />
                )}
              {!this.props.StudentRlpChartData.sRlpResponse &&
                this.props.responseErrCode &&
                !this.props.isApiLoading && (
                  <ChartNotLoad tryAgain={this.studentReadingLevelApi} />
                )}
              {this.props.StudentRlpChartData.sRlpResponse &&
                this.props.isDataAvailable && (
                  <NoRecordsData NodataFound={'dataNotAvail'} />
                )}
            </div>
          ) : (
            <NoRosterData />
          )}
      </div>
    );
  }
}
const mapStateToProps = ({
  StudentRlpData,
  SummaryFilterDetails,
  Authentication,
  Universal,
  SummaryTabReducer
}) => {
  const { popUp } = SummaryTabReducer;
  const {
    StudentRlpChartData,
    isApiLoading,
    isDataAvailable,
    responseErrCode,
    SRLPCSVDownload
  } = StudentRlpData;
  const { SummaryFilterData } = SummaryFilterDetails;
  const { LoginDetails } = Authentication;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection
  } = Universal;
  return {
    popUp,
    SummaryFilterData,
    StudentRlpChartData,
    LoginDetails,
    ContextHeader,
    ApiCalls,
    isApiLoading,
    isDataAvailable,
    UniversalSelecter,
    NavigationByHeaderSelection,
    responseErrCode,
    SRLPCSVDownload
  };
};

export default connect(
  mapStateToProps,
  {
    S_RLP_API_CALL, SUMMARY_SRL_CHART_YAXIS_SCROLL,
    SUMMARY_SRL_CHART_XAXIS_SCROLL, Chart_Enabled,
    SRLP_CSVDATA_DOWNLOAD_APICALL,
    SRLP_CSVDATA_DOWNLOAD_RESET
  }
)(Summary_SRLP);
