import React, { Component } from 'react';
import * as d3 from 'd3';
// import '../S_FluencyComponents/Fluency.css';

class FluencyRlpChart extends Component {
  constructor(props) {
    super(props);
    this.state = { isClicked: false, radius: '3' };
  }

  render() {
    const width = 410,
      height = 270,
      margin = 10;
    const { fluencyAxis, fValue } = this.props;

    const h = height,
      w = width - 2 * margin;

    //x scale
    const x = d3
      .scaleLinear()
      .domain([0, 7])
      .range([0, 700]);

    //y scale
    const y = d3
      .scaleLinear()
      .domain([0, d3.max(fValue, d => d)])
      .range([h, 0]);

    const line = d3
      .line()
      .x(d => x(d.a) - ((d.a - 1) * 40 + 20))
      .y(d => y(d.b));

    var circles =
      fluencyAxis &&
      fluencyAxis.map((d, i) => {
        return (
          <g transform={`translate(-46, 5)`} key={i}>
            <circle
              className="dot"
              r={'4'}
              cx={x(d.a) - ((d.a - 1) * 40 + 20)}
              cy={y(d.b)}
              fill="#BDC2CD"
              id={i}
              key={i}
            />
          </g>
        );
      });

    const yTicks = y.ticks(11).map((d, i) =>
      y(d) > -1 && y(d) < h ? (
        <g transform={`translate(${0},${y(d)})`} key={i}>
          <text x="-12" y="5" transform={`translate(${w},${i * 1 - 5})`}>
            {d}
          </text>

          <line
            className="gridline-yxs"
            x1="0"
            x1={w - 30}
            y1={margin + 36}
            y2={margin + 36}
            transform={`translate(${0},${i + 25 * -2})`}
          />
        </g>
      ) : null
    );

    return (
      <g>
        <path
          transform={`translate(-46, 5)`}
          className="path-class"
          d={line(
            fluencyAxis.filter((obj, i) => {
              if (obj.b > 0 || obj.b !== null) {
                return obj;
              }
            })
          )}
        />
        {circles}
        <g className="axis-labels">{yTicks}</g>
        {/* chart section ends */}
      </g>
    );
  }
}

export default FluencyRlpChart;
