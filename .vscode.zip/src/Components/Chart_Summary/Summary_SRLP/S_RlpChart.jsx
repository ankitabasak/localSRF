import React, { Component } from 'react';
import FluencyRlpChart from './Fluency_RlpChart.jsx';
import StudentRlpBubbleChart from './Student_Rlp_BubbleChart.jsx';
import AccuracyRlpChart from './Accuracy_RlpChart.jsx';
import { getAxisColor, getAxisBgColor } from './bubbleConfiguration';
import './S_Rlp.css';
import XprevEnd from '../../../../public/assets/orr/rlp-screen/x-prev-end.svg';
import Xprev from '../../../../public/assets/orr/rlp-screen/x-prev.svg';
import XprevEndActive from '../../../../public/assets/orr/rlp-screen/x-prev-end-active.svg';
import XprevActive from '../../../../public/assets/orr/rlp-screen/x-prev-active.svg';
import XnextEndActive from '../../../../public/assets/orr/rlp-screen/x-next-end-active.svg';
import XnextEnd from '../../../../public/assets/orr/rlp-screen/x-next-end.svg';
import XnextActive from '../../../../public/assets/orr/rlp-screen/x-next-active.svg';
import Xnext from '../../../../public/assets/orr/rlp-screen/x-next.svg';
import BelowEnd from '../../../../public/assets/orr/rlp-screen/srlp-below-end.svg';
import BelowEndActive from '../../../../public/assets/orr/rlp-screen/srlp-below-end-active.svg';
import BelowPrev from '../../../../public/assets/orr/rlp-screen/srlp-below-prev.svg';
import BelowPrevActive from '../../../../public/assets/orr/rlp-screen/srlp-below-prev-active.svg';
import TopEnd from '../../../../public/assets/orr/rlp-screen/srlp-top-end.svg';
import TopEndActive from '../../../../public/assets/orr/rlp-screen/srlp-top-end-active.svg';
import TopNextInactive from '../../../../public/assets/orr/rlp-screen/srlp-top-next-inactive.svg';
import TopNext from '../../../../public/assets/orr/rlp-screen/srlp-top-next.svg';

class StudentRlpChart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showFluency: false,
      showAccuracy: false,
      toolTip: null,
      xPoint: '',
      yPoint: '',
      circleColor: {
        Instructional: '#2b9638',
        Independent: '#008ad9',
        Frustrational: '#ffc52d'
      }
    };
    this.toggleY1 = this.toggleY1.bind(this);
    this.toggleY2 = this.toggleY2.bind(this);
    this.showToolTip = this.showToolTip.bind(this);
    this.scrollUpDown = this.scrollUpDown.bind(this);
    this.scrollRightLeft = this.scrollRightLeft.bind(this);
  }

  toggleY1() {
    if (this.state.showAccuracy !== true || this.state.showAccuracy) {
      this.setState({
        showFluency: !this.state.showFluency,
        showAccuracy: false
      });
      this.props.UpdateSrlpChart({
        showFluency: !this.state.showFluency,
        showAccuracy: false
      })
    }
  }

  toggleY2() {
    if (this.state.showFluency !== true || this.state.showFluency) {
      this.setState({
        showAccuracy: !this.state.showAccuracy,
        showFluency: false
      });
      this.props.UpdateSrlpChart({
        showAccuracy: !this.state.showAccuracy,
        showFluency: false
      })
    }
  }

  showToolTip(data, cx, cy) {
    this.setState({
      ...this.state,
      toolTip: data,
      xPoint: cx,
      yPoint: cy
    });
  }

  sliceData(dataList, startIdx, endIdex) {
    return dataList.slice(startIdx, endIdex);
  }
  // scroll methods
  scrollRightLeft(dataList, index, scrollType) {
    switch (scrollType) {
      case 'right':
        if (index < dataList.length - 6) {
          let scrlIndex = index + 1;

          this.props.initiateXScroll({
            ['modifiedSumAssDate']: dataList.slice(
              scrlIndex,
              scrlIndex + 6
            ),
            SumXScrollIndex: scrlIndex
          });
        }
        return;

      case 'left':
        if (index > 0) {
          let scrlIndex = index - 1;
          this.props.initiateXScroll({
            ['modifiedSumAssDate']: dataList.slice(
              scrlIndex,
              scrlIndex + 6
            ),
            SumXScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeRight':
        if (index < dataList.length - 6) {
          let scrlIndex = dataList.length - 6;

          this.props.initiateXScroll({
            ['modifiedSumAssDate']: dataList.slice(
              scrlIndex,
              scrlIndex + 5
            ),
            SumXScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeLeft':
        if (index > 0) {
          let scrlIndex = 0;

          this.props.initiateXScroll({
            ['modifiedSumAssDate']: dataList.slice(0, 6),
            SumXScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  // UP and Down
  scrollUpDown(dataList, index, scrollType) {
    let scrlIndex;
    switch (scrollType) {
      case 'top':
        if (index > 5) {
          scrlIndex = index - 1;

          this.props.initiateYScroll({
            modifiedSumRlp: dataList.slice(scrlIndex - 5, scrlIndex),
            SumYScrollIndex: scrlIndex
          });
        }
        return;

      case 'bottom':
        if (index < dataList.length) {
          scrlIndex = index + 1;

          this.props.initiateYScroll({
            modifiedSumRlp: dataList.slice(scrlIndex - 5, scrlIndex),
            SumYScrollIndex: scrlIndex
          });
        }
        return;

      case 'extremeTop':
        if (index > 5) {
          scrlIndex = 5;

          this.props.initiateYScroll({
            modifiedSumRlp: dataList.slice(0, 5),
            SumYScrollIndex: scrlIndex
          });
        }
        return;
      case 'extremeBottom':
        if (index < dataList.length) {
          scrlIndex = dataList.length;

          this.props.initiateYScroll({
            modifiedSumRlp: dataList.slice(
              dataList.length - 5,
              dataList.length
            ),
            SumYScrollIndex: scrlIndex
          });
        }
        return;
    }
  }

  getAxisBorderColor(readingLevel) {
    return {
      borderRight: `4px solid ` + getAxisColor(readingLevel),
      backgroundColor: getAxisBgColor(readingLevel)
    };
  }

  render() {
    let toolTip = this.props.sRlpChart.updateToolTip;
    let apiResponse = this.props.sRlpChart.sRlpResponse;
    const dashSymbol = <span>&mdash;</span>;
    const width = 410,
      height = 270;//250

    return (
      <div className="sum-rlpchart-border ">
        <div className="sum-std-rb-btm-border" />
        <div className="show-radio-btn">
          <div className="check-box-heading pull-left">Show:</div>
          <div onClick={this.toggleY1} className="round pull-left">
            <input type="checkbox" />
            <label
              className={this.props.sRlpChart.showFluency ? ' check-btn' : 'uncheck-btn'}
            >
              <span>Fluency</span>
            </label>
          </div>
          <div onClick={this.toggleY2} className="round pull-left ml-14">
            <input type="checkbox" />
            <label
              style={{ marginLeft: '19px' }}
              className={this.props.sRlpChart.showAccuracy ? ' check-btn' : 'uncheck-btn'}
            >
              <span>Accuracy</span>
            </label>
          </div>
          {this.props.sRlpChart.showFluency && (
            <span
              className="y-label"
              style={{
                float: 'right',
                color: '#00539b'
              }}
            >
              Fluency
              <br /> (wcpm)
            </span>
          )}
          {this.props.sRlpChart.showAccuracy && (
            <span
              className="y-label"
              style={{
                float: 'right',
                color: '#00539b'
              }}
            >
              Accuracy
            </span>
          )}
        </div>
        {/* <div className="hor-line1" /> */}
        <div>
          {/* 19-08-2019 */}
          <div className="pull-left scroll-lhs pos-rel">
            <div className="sum-chart-lhs-bor" />
            <div
              className="top-arrow-sec"
              style={
                this.props.sRlpChart.SumYScrollIndex > 5
                  ? { cursor: 'pointer' }
                  : { cursor: 'default' }
              }
              onClick={() => {
                this.scrollUpDown(
                  apiResponse['readingLevelAxis'],
                  this.props.sRlpChart.SumYScrollIndex,
                  'extremeTop'
                );
              }}
            >
              {this.props.sRlpChart.SumYScrollIndex > 5 ? (
                <img src={TopEndActive} height="26px" />
              ) : (
                  <img src={TopEnd} height="26px" />
                )}
            </div>
            <div
              className="top-arrow-sec"
              style={
                this.props.sRlpChart.SumYScrollIndex > 5
                  ? { cursor: 'pointer' }
                  : { cursor: 'default' }
              }
              onClick={() => {
                this.scrollUpDown(
                  apiResponse['readingLevelAxis'],
                  this.props.sRlpChart.SumYScrollIndex,
                  'top'
                );
              }}
            >
              {this.props.sRlpChart.SumYScrollIndex > 5 ? (
                <img src={TopNext} />
              ) : (
                  <img src={TopNextInactive} />
                )}
            </div>
            <div className="summary-mid-sec">
              {this.props.sRlpChart.modifiedSumRlp.map(
                (readingLevel, index) => {
                  return (
                    <div
                      className="vert-scroll-block1"
                      key={index}
                      style={this.getAxisBorderColor(readingLevel)}
                    >
                      <div className="rhs-small-bor" />
                      <span>{readingLevel}</span>
                    </div>
                  );
                }
              )}
            </div>
            <div className="bottom-arrow-sec">
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.SumYScrollIndex <
                    apiResponse.readingLevelAxis.length
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollUpDown(
                    apiResponse['readingLevelAxis'],
                    this.props.sRlpChart.SumYScrollIndex,
                    'bottom'
                  );
                }}
              >
                {this.props.sRlpChart.SumYScrollIndex <
                  apiResponse.readingLevelAxis.length ? (
                    <img src={BelowPrevActive} />
                  ) : (
                    <img src={BelowPrev} />
                  )}
              </div>
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.SumYScrollIndex <
                    apiResponse.readingLevelAxis.length
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollUpDown(
                    apiResponse['readingLevelAxis'],
                    this.props.sRlpChart.SumYScrollIndex,
                    'extremeBottom'
                  );
                }}
              >
                {this.props.sRlpChart.SumYScrollIndex <
                  apiResponse.readingLevelAxis.length ? (
                    <img src={BelowEndActive} />
                  ) : (
                    <img src={BelowEnd} />
                  )}
              </div>
            </div>
            <div className="bottom-xaxis-sec m-t-3">
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.SumXScrollIndex > 0
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.SumXScrollIndex,
                    'extremeLeft'
                  );
                }}
              >
                {this.props.sRlpChart.SumXScrollIndex > 0 ? (
                  <img src={XprevEndActive} />
                ) : (
                    <img src={XprevEnd} />
                  )}
              </div>
              <div
                className="top-arrow-sec m-r-1"
                style={
                  this.props.sRlpChart.SumXScrollIndex > 0
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.SumXScrollIndex,
                    'left'
                  );
                }}
              >
                {this.props.sRlpChart.SumXScrollIndex > 0 ? (
                  <img src={XprevActive} />
                ) : (
                    <img src={Xprev} />
                  )}
              </div>
            </div>
          </div>
          <div className="pull-left sum-svg-wrap pos-rel">
            {/* <div className="wpcm_name">
              <p>
                Fluency <br />
                (wcpm)
              </p>
            </div> */}

            <svg
              // style={{ border: '1px solid black' }}
              className="svg-class"
              width={width}
              height="270" //1000
              transform={`translate(0,0)`}
            >
              {this.props.sRlpChart.modifiedSumFluencyData.length !== 0 &&
                this.props.sRlpChart.showFluency && (
                  <FluencyRlpChart
                    fluencyAxis={this.props.sRlpChart.modifiedSumFluencyData}
                    fValue={this.props.sRlpChart.sRlpResponse.fluencyAxis}
                  />
                )}

              {this.props.sRlpChart.modifiedSumAccuracyData.length !== 0 &&
                this.props.sRlpChart.showAccuracy && (
                  <AccuracyRlpChart
                    accuracyAxis={this.props.sRlpChart.modifiedSumAccuracyData}
                    aValue={this.props.sRlpChart.sRlpResponse.accuracyAxis}
                  />
                )}
              {this.props.sRlpChart.modifiedSumAssDate.length !== 0 && (
                <StudentRlpBubbleChart
                  chartData={this.props.sRlpChart}
                  svgWidth={width}
                  svgHeight={height}
                  getToolTipData={this.showToolTip}
                />
              )}
            </svg>
          </div>

          {/* 19-08-2019 */}
          <div className="pull-left scroll-lhs pos-rel right-4">
            <div className="sum-chart-lhs-bor-stroke"></div>
            <div className="sum-rhs-mid-sec">
              <p>Reading Level Progress Over Time</p>
            </div>

            <div className="bottom-xaxis-sec m-t-3 m-t-4">
              <div
                className="top-arrow-sec"
                style={
                  this.props.sRlpChart.SumXScrollIndex <
                    apiResponse.assignmentDataList.length - 6
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.SumXScrollIndex,
                    'right'
                  );
                }}
              >
                {this.props.sRlpChart.SumXScrollIndex <
                  apiResponse.assignmentDataList.length - 6 ? (
                    <img src={XnextActive} />
                  ) : (
                    <img src={Xnext} />
                  )}
              </div>
              <div
                className="top-arrow-sec m-r-1"
                style={
                  this.props.sRlpChart.SumXScrollIndex <
                    apiResponse.assignmentDataList.length - 6
                    ? { cursor: 'pointer' }
                    : { cursor: 'default' }
                }
                onClick={() => {
                  this.scrollRightLeft(
                    apiResponse['assignmentDataList'],
                    this.props.sRlpChart.SumXScrollIndex,
                    'extremeRight'
                  );
                }}
              >
                {this.props.sRlpChart.SumXScrollIndex <
                  apiResponse.assignmentDataList.length - 6 ? (
                    <img src={XnextEndActive} />
                  ) : (
                    <img src={XnextEnd} />
                  )}
              </div>
            </div>
          </div>
        </div>
        {this.props.sRlpChart.showStuToolTip && toolTip && toolTip.d && (
          <div>
            <div
              className="inner-popup pos-rel popup-wh"
              style={{
                transform: `translate(${toolTip.xPoint - 190}px,${toolTip
                  .yPoint - 63}px)`
              }}
            >
              <div
                className="small-circle"
                style={{
                  backgroundColor: this.state.circleColor[
                    toolTip.d['proficiency']
                  ]
                }}
              />
              <div className="first-ul stRlp-ul sRlp-overlay-box">
                <li>
                  <span>Reading Level: </span>
                  {toolTip.d.overlayData.readingLevel}
                </li>
                <li>
                  <span>Assignment: </span>
                  {toolTip.d.overlayData.assignmentTitle}
                </li>
                <li>
                  <span>Category: </span>
                  {toolTip.d.overlayData.category}
                </li>
                <li>
                  <span>Proficiency: </span>
                  {toolTip.d.overlayData.proficiency}
                </li>
                <li>
                  <span>Accuracy: </span>
                  {toolTip.d.overlayData.accuracy}%
                </li>
                <li>
                  <span>Fluency: </span>
                  {toolTip.d.overlayData.fluency !== null
                    ? toolTip.d.overlayData.fluency + ' wcpm'
                    : dashSymbol}
                </li>
              </div>
            </div>
          </div>
        )}
        <div className="readingLevel">Reading Level</div>
        <div className="readingLevel-date sRlp-date">Date</div>
      </div>
    );
  }
}

export default StudentRlpChart;
