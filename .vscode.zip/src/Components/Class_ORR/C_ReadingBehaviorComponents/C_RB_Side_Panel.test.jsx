import React from 'react';
import { shallow } from 'enzyme';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import Class_RB_SidePanel from '../../../Components/Class_ORR/C_ReadingBehaviorComponents/C_RB_Side_Panel';

function setup(overrides = {}) {
  const props = {
  };
  const finalProps = Object.assign(props, overrides);
  const wrapper = shallow(( <Class_RB_SidePanel {...finalProps} /> ));
  return { wrapper };
};

describe('Class_RB_SidePanel', () => {
  describe('renders properly', () => {
    const { wrapper } = setup();
    it('renders component', () => {
      expect(wrapper).toHaveLength(1);
    });

    it('matches snapshot', () => {
      expect(wrapper).toMatchSnapshot();
    });
  });
  describe('renders properly', () => {
    it('MakeSelectionForORR component not render default', () => {
      const { wrapper } = setup({
        selectedRB: ['first_record']
      });
      expect(wrapper.find('MakeSelectionForORR')).toHaveLength(0);
    });

    it('MakeSelectionForORR component will render', () => {
      const { wrapper } = setup({
        selectedRB: []
      });
      expect(wrapper.find('MakeSelectionForORR')).toHaveLength(1);
    });
  });
});
