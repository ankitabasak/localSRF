import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import './C_RB.css';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents'
import {
  CRB_Chart_API_Call,
  CRB_SidePanel_API_Call,
  Chart_loading_Failed,
  updateSelectedItems,
  CLASS_RB_SORT_COLUMN,
  SAVE_SORTED_GRID_DATA,
  Update_Accordion_State,
  CRB_CSVDATA_DOWNLOAD_APICALL,
  CRB_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/CRB_Actions.jsx';
import {
  navigateToStudentReportFromClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import { SHOW_HIDE_GROUPING } from "../../../Redux_Actions/C_GroupingAction.jsx";
import Class_RB_SidePanel from './C_RB_Side_Panel.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import NoRecordsData from '../../../Utils/No_Data_Found';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import Filter from '../../ORR/FilterComponents/Filter';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import ClassReadingBehaviourChart from './C_RB_Chart.jsx';
import Group from '../Grouping_ORR/C_Grouping.jsx'
import PrintCRB from '../../ReusableComponents/PrintOrrCharts/C_RbPrint.jsx'
import NoFluencyData from '../../../Utils/No_Data.js'
import titleImg from "../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg";

class C_Reading_Behavior extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      internalFilter: {},
      sidepanelApiInRun: false
    };
    this.toggleHidden = this.toggleHidden.bind(this);
    this.timeOut = this.timeOut.bind(this);
  }

  componentDidMount() {
    this.getCRBChartData();
  }
  // initiate chart api call
  getCRBChartData() {
    let payLoad = getCommonHeaders(this.props, 'class');
    this.props.CRB_Chart_API_Call(this.props.LoginDetails.JWTToken, payLoad);
  }

  // toggle grouping
  toggleHidden(flag) {
    this.props.SHOW_HIDE_GROUPING(flag);
  }
  // Side panel API call for selcted boxes
  updateSelectedItems(listItems) {
    let payLoad = getCommonHeaders(this.props, 'class');
    this.props.updateSelectedItems(
      listItems,
      payLoad,
      this.props.LoginDetails.JWTToken
    );

    // calling side panel API
    let labelType = Object.keys(listItems)[0];
    let panelApiData = listItems[labelType];
    let cpbSidePanelRequestList = [];

    if (panelApiData && panelApiData.length > 0) {
      panelApiData.forEach(item => {

        cpbSidePanelRequestList.push({
          sourceCriteriaId: item['sourceCriteriaId'],
          sourceRubricId: item['rubricId'],
          selectedRanges: item['selectedRanges']

        });
      });
    }
    if (cpbSidePanelRequestList && cpbSidePanelRequestList.length > 0) {

      if (!this.state.sidepanelApiInRun) {
        this.setState({ ...this.state, sidepanelApiInRun: true });
        setTimeout(() => {
          this.props.CRB_SidePanel_API_Call(this.props.LoginDetails.JWTToken, {
            ...payLoad,
            ['cpbSidePanelRequestList']: cpbSidePanelRequestList,
            label: labelType.replace('Count', '')
          });
          this.setState({ ...this.state, sidepanelApiInRun: false });
        }, 1000);
      }

    }

  }

  // handle timeout
  timeOut() {
    this.props.Chart_loading_Failed({
      noChartData: false,
      apiLoadFail: false,
      timeout: true,
      isApiLoading: false
    });
  }

  updateSortColumn(sortColumn, sortType) {
    this.props.CLASS_RB_SORT_COLUMN(sortColumn, sortType);
  }

  updateSortData(data) {
    this.props.SAVE_SORTED_GRID_DATA(data);
  }
  // Download csv data
  downLoadCSVData() {
    this.props.CRB_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = {
      classChartType: {
        "allRecordsAvgFlag": '1',
        "chartName": "CRB"
      },
      ...getCommonHeaders(this.props, 'class')
    };
    this.props.CRB_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }
  render() {
    let chartData = this.props.CRB_State.chartData;
    let sidePanelData = this.props.CRB_State.sidePanelData;
    let selectedItems = this.props.CRB_State.selectedBoxes;
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedClass.name;
    if (this.props.CRB_State.ClassCsvDownload && this.props.CRB_State.ClassCsvDownload['downloadInProgress'] && this.props.CRB_State.ClassCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.CRB_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    return (

      <React.Fragment>
        {this.props.NavigationByHeaderSelection.class && this.props.ContextHeader.Roster_Tab.SelectedClass.id ? (
          <div>
            <Filter sidePanelData={sidePanelData} />
            {this.props.CRB_State.isApiLoading && (
              <Spinner
                startSpinner={this.props.CRB_State.isApiLoading}
                showTimeOut={this.timeOut}
              />
            )}
            {!this.props.CRB_State.isApiLoading &&
              !this.props.CRB_State.apiLoadFail &&
              !this.props.CRB_State.noData && !this.props.CRB_State.noChartData && this.props.CRB_State.rubricDataMsg === null && (
                <main>
                  <section>
                    <div
                      className="container class-RB-container"
                      style={{
                        maxWidth: '1165px',
                        paddingLeft: '0px',
                        paddingRight: '0px'
                      }}
                    >
                      <div className="tabs">
                        <div className="tab full-width">
                          <React.Fragment>
                            {this.props.CRB_State.ClassCsvDownload && this.props.CRB_State.ClassCsvDownload['csvData'] &&
                              <CSVLink
                                ref="groupCSV"
                                headers={this.props.CRB_State.ClassCsvDownload['csvData'] && this.props.CRB_State.ClassCsvDownload['csvData']['header']}
                                data={this.props.CRB_State.ClassCsvDownload['csvData'] && this.props.CRB_State.ClassCsvDownload['csvData']['data']}
                                style={{ display: 'none' }}
                                // filename={"CRB_CSV.csv"}
                                filename={`${csvFileName}.csv`}
                              />}
                            <div className="cls-csv-icon-alignment"
                              onClick={() => !this.props.CRB_State.ClassCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                              {this.props.CRB_State.ClassCsvDownload && this.props.CRB_State.ClassCsvDownload['downloadInProgress'] ?
                                <span className="csv_download_icon">
                                  <i className="material-icons">autorenew</i>
                                </span> :
                                <span className="csv_download_icon">
                                  <img src={CsvIcon} width="20" height="20" />
                                </span>}
                            </div>
                            <span className="class-rb-print-btn">
                              {chartData &&
                                <PrintCRB
                                  scrollFlag={false}
                                  selectedFilter={this.props.CommonFilterData}
                                  studentDetails={this.props.ContextHeader}
                                  navSelected={this.props.NavigationByHeaderSelection}
                                  data={chartData}
                                  accordionState={this.props.CRB_State.accordionsState}
                                  selectedRB={selectedItems}
                                  sidePanelData={sidePanelData}
                                  sortData={this.props.CRB_State.SortData}
                                />}
                            </span>
                            {this.props.NavigationByHeaderSelection.class && !this.props.CRB_State.hideCreateGroup &&
                              !this.props.NavigationByHeaderSelection.readingHistory ? (
                                <div className="group-title" onClick={() => this.toggleHidden(true)}>
                                  <img src={titleImg} className="pull-left mlr-9" />
                                  <span>
                                    <b>Create Groups</b>
                                  </span>
                                </div>
                              ) : (
                                ""
                              )}
                            <div
                              className="sea-wrapper pos-rel crb-wrap"
                              style={{ width: '100%' }}
                            >
                              <div className="row" id="testClass">
                                <div className="col-lg-7 res-width-8 cfa-lft-box crb-accor crb-ipad-view classRb-wrapper">
                                  {chartData && (
                                    <ClassReadingBehaviourChart
                                      scroll={true}
                                      setAccordionState={(index) => { this.props.Update_Accordion_State(this.props.CRB_State.accordionsState, index) }}
                                      data={chartData}
                                      accordionState={this.props.CRB_State.accordionsState}
                                      selectedRB={selectedItems}
                                      updateSelctedItems={selectedObj => {
                                        this.updateSelectedItems(selectedObj);
                                      }}
                                    />
                                  )}
                                </div>
                                <div className="col-md-4 res-width cea-rhs-rel mt-6 crb-ipad-grid-view-rhs mtop-10 classRb-view-wrap crb-ipad-algn ">
                                  {chartData && (<Class_RB_SidePanel
                                    navigateToStudent={(studentDetails) => { this.props.navigateToStudentReportFromClassReport(studentDetails, false) }}
                                    scrollFlag={false}
                                    data={sidePanelData}
                                    selectedRB={selectedItems}
                                    updateSortColumn={(sortColumn, sortType) => {
                                      this.updateSortColumn(sortColumn, sortType);
                                    }}
                                    sidePanelApiFailed={this.props.CRB_State.sidePanelApiFailed}
                                    updateSortData={data => {
                                      this.updateSortData(data);
                                    }}
                                    sortData={this.props.CRB_State.SortData}
                                  />)}
                                </div>

                                {this.props.showGrouping && this.props.CRB_State.sidePanelData && chartData && (
                                  <Group
                                    cancelModal={this.toggleHidden}
                                    showGrouping={this.props.showGrouping}
                                    gridData={this.props.CRB_State.sidePanelData.cpbGridDataResponseList}
                                    Data={this.props.CRB_State.SortData}
                                  />
                                )}
                              </div>
                            </div>
                          </React.Fragment>

                        </div>
                      </div>
                    </div>
                  </section>
                </main>

              )}

            {this.props.CRB_State.timeout && !chartData && (
              <TimeOut tryAgain={() => this.getCRBChartData} />
            )}
            {this.props.CRB_State.apiLoadFail && !this.props.CRB_State.isApiLoading && <ChartNotLoad tryAgain={() => this.getCRBChartData} />}
            {this.props.CRB_State.noChartData && (
              <NoRecordsData NodataFound={'dataNotAvail'} />
            )}
            {this.props.CRB_State.rubricDataMsg &&
              <div>
                <NoFluencyData NoFluencyData={this.props.CRB_State.rubricDataMsg} />
              </div>
            }
          </div>
        ) :
          <div>
            <NoRosterData />
          </div>
        } </React.Fragment>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  CRB_State,
  C_GroupingReducer
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { showGrouping } = C_GroupingReducer;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    CommonFilterData,
    CRB_State,
    showGrouping
  };
};

export default connect(
  mapStateToProps,
  {
    CRB_Chart_API_Call,
    Chart_loading_Failed,
    CRB_SidePanel_API_Call,
    updateSelectedItems,
    CLASS_RB_SORT_COLUMN,
    SAVE_SORTED_GRID_DATA,
    Update_Accordion_State,
    navigateToStudentReportFromClassReport,
    SHOW_HIDE_GROUPING,
    CRB_CSVDATA_DOWNLOAD_APICALL,
    CRB_CSVDATA_DOWNLOAD_RESET
  }
)(C_Reading_Behavior);
