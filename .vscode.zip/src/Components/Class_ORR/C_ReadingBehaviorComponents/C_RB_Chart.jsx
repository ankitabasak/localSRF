import React, { Component } from "react";

class ClassReadingBehaviourChart extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount(props) {
    if (this.props.data && this.props.data.length > 0) {
      let id = this.props.data[0]["sourceRubricId"];

      this.setState({
        ...this.state,
        // accordionSelected: this.props.data.length - 1
      });
    }
  }

  isSelected(item) {
    let listItems = this.props.selectedRB[item["rbType"]];
    let style = { color: "#333333" };
    if (listItems && listItems.length > 0) {
      listItems.forEach((obj, idx) => {
        if (
          obj.sourceCriteriaId == item.sourceCriteriaId &&
          obj.criteriaName == item.criteriaName &&
          obj.selectedRanges == item.selectedRanges
        ) {
          style = { color: "white", backgroundColor: "rgb(0, 83, 155)" };
        }
      });
    }
    return style;
  }
  // Save selcted boxes
  saveSelectedBoxes(obj) {
    let listItems = this.props.selectedRB[obj["rbType"]];
    let duplicateIdx = -1;
    if (listItems && listItems.length > 0) {
      listItems.forEach((item, idx) => {
        if (
          obj.sourceCriteriaId == item.sourceCriteriaId &&
          obj.criteriaName == item.criteriaName &&
          obj.selectedRanges == item.selectedRanges
        ) {
          duplicateIdx = idx;
        }
      });

      if (duplicateIdx > -1) {
        listItems.splice(duplicateIdx, 1);
      } else {
        listItems.push(obj);
      }
      this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
    } else {
      listItems = [obj];
      this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
    }
  }

  // setAccordionState(id) {
  //   if (id == this.state["accordionSelected"]) {
  //     this.setState({ ...this.state, accordionSelected: null });
  //     this.props.updateIds({ accordionSelected: null})
  //   } else {
  //     this.setState({ ...this.state, accordionSelected: id });
  //     this.props.updateIds({ accordionSelected: id })
  //   }
  // }

  //to display the last passage
  showToolTip(passage) {
    let crbHover = false;
    if (passage.length > 28) {
      crbHover = true;
    }
    if (crbHover) {
      return (
        <div className="hover-crb word-bk">
          {passage}
          <div className="tooltip-dot" />
        </div>
      );
    }

  }

  showCriteriaName(cName) {
    let criteriaName = "";
    if (cName.length > 28) {
      criteriaName = cName.substring(0, 22) + "...";
    } else {
      criteriaName = cName;
    }
    return criteriaName;
  }

  render() {
    let chartAccordion = this.props.accordionState
    if (this.props.data) {
      return (
        <React.Fragment>
          {/* <!-- Left Chart Table Start --> */}

          <div className="panel-group panel-width pt-20" id="accordion">
            <div className="crb-top-bor4"></div>
            <div className="crb-top-bor5"></div>
            <p className="crb-first-heading">Reading Behavior</p>
            <p className="crb-first-record lft-4">First Record</p>
            <p className="crb-first-record">Recent Record</p>
            <p className="all-crb-first-record">All Records' Average</p>
            <div className="class-reading-behaviors">
              <p>Processing Behaviors &amp; Strategies</p>
            </div>
            <div className={this.props.scroll ? "crb-inner-wrap" : "print-body"}>
              <div className="divider-line-grey-left class-rb-lft-bor"></div>
              {this.props.data.map((crbMainCategory, index) => {
                return (
                  <div className="panel panel-default" key={index}>
                    <div
                      className={
                        chartAccordion[index]
                          ? "panel-heading mb-6 cursor-pointer expanded-accord"
                          : "panel-heading mb-6 cursor-pointer collapsed-accord"
                      }
                    >
                      <h4
                        className="panel-title mt-2 pos-rel"
                        onClick={() => { this.props.setAccordionState(index) }}
                      >{
                          chartAccordion[index] ? <div class="tab-left-border"></div> : <div className="tabs-bord"></div>
                        }


                        <a >{crbMainCategory["sourceRubricName"]}</a>
                      </h4>
                    </div>
                    <div
                      id="collapseOne"
                      className="panel-collapse collapse in"
                      className={
                        chartAccordion[index]
                          ? "panel-collapse collapse in show"
                          : "panel-collapse collapse in"
                      }
                    >
                      <div className="panel-body">
                        <div className="container">
                          <div className="row pmb-5 pos-rel">
                            <div className="sc_rb_inner-bor"></div>
                            <div className="class-rb-col pos-rel pull-left">
                              <div className="crb-left-color-strip"></div>
                              <div className="crb-new-bord-strip"></div>
                              <ul>
                                {crbMainCategory["resultList"].map(
                                  (crbListItem, index) => {
                                    return (
                                      <li
                                        className="pos-rel crb-hover-container"
                                        key={index}
                                      >
                                        <div class="left-border"></div>
                                        <span>
                                          {this.showCriteriaName(
                                            crbListItem["sourceCriteriaName"]
                                          )}
                                        </span>
                                        {this.showToolTip(
                                          crbListItem["sourceCriteriaName"]
                                        )}
                                      </li>
                                    );
                                  }
                                )}
                              </ul>
                            </div>

                            <div
                              className="crb-first-record-error pos-rel"
                              id="firstRecord"
                            >
                              <div className="class-rb-table">
                                <div className="crb-first-error-col pos-rel ClassRb-08-20">
                                  <div className="crb-bor-1"></div>
                                  <div className="crb-bor-11"></div>
                                  <div className="crb-bor-12"></div>
                                  <div className="test">
                                    <ul>
                                      {crbMainCategory["resultList"].map(
                                        (crbListItem, index) => {
                                          return crbListItem[
                                            "firstRecordCount"
                                          ] ? (
                                              <li
                                                key={index}
                                                className="cursor-pointer crb-default-bgcolor"
                                                style={this.isSelected({
                                                  rbType: "firstRecordCount",
                                                  sourceCriteriaId:
                                                    crbListItem[
                                                    "sourceCriteriaId"
                                                    ],
                                                  criteriaName:
                                                    crbListItem[
                                                    "sourceCriteriaName"
                                                    ]
                                                })}
                                                onClick={() => {
                                                  this.saveSelectedBoxes({
                                                    rbType: "firstRecordCount",
                                                    sourceCriteriaId:
                                                      crbListItem[
                                                      "sourceCriteriaId"
                                                      ],
                                                    criteriaName:
                                                      crbListItem[
                                                      "sourceCriteriaName"
                                                      ],
                                                    rubricId:
                                                      crbMainCategory[
                                                      "sourceRubricId"
                                                      ],
                                                    selectedRanges: null
                                                  });
                                                }}
                                              >
                                                {crbListItem["firstRecordCount"]}
                                              </li>
                                            ) : (
                                              <li key={index}>{crbListItem[
                                                "firstRecordCount"
                                              ] === null ? 0 : 0}</li>
                                            );
                                        }
                                      )}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="crb-first-record-error pos-rel">
                              <div className="class-rb-table">
                                <div className="crb-first-error-col pos-rel ClassRb-08-20">
                                  <div className="crb-bor-1"></div>
                                  <div className="crb-bor-11"></div>
                                  <div className="crb-bor-12"></div>
                                  <div className="test">
                                    <ul>
                                      {crbMainCategory["resultList"].map(
                                        (crbListItem, index) => {
                                          return crbListItem[
                                            "recentRecordCount"
                                          ] ? (
                                              <li
                                                key={index}
                                                className="cursor-pointer crb-default-bgcolor"
                                                style={this.isSelected({
                                                  rbType: "recentRecordCount",
                                                  sourceCriteriaId:
                                                    crbListItem[
                                                    "sourceCriteriaId"
                                                    ],
                                                  criteriaName:
                                                    crbListItem[
                                                    "sourceCriteriaName"
                                                    ],
                                                  selectedRanges: null
                                                })}
                                                onClick={() => {
                                                  this.saveSelectedBoxes({
                                                    rbType: "recentRecordCount",
                                                    sourceCriteriaId:
                                                      crbListItem[
                                                      "sourceCriteriaId"
                                                      ],
                                                    criteriaName:
                                                      crbListItem[
                                                      "sourceCriteriaName"
                                                      ],
                                                    rubricId:
                                                      crbMainCategory[
                                                      "sourceRubricId"
                                                      ],
                                                    selectedRanges: null
                                                  });
                                                }}
                                              >
                                                {crbListItem["recentRecordCount"]}
                                              </li>
                                            ) : (
                                              <li key={index}>{crbListItem[
                                                "recentRecordCount"
                                              ] === null ? 0 : 0}</li>
                                            );
                                        }
                                      )}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="crb-first-record-error pos-rel">
                              <div className="class-rb-table">
                                <div className="crb-all-records-col pos-rel">
                                  <div className="crb-bor-1"></div>
                                  <div className="crb-bor-12"></div>
                                  <div className="test">
                                    <ul>
                                      {crbMainCategory["resultList"].map(
                                        (crbListItem, index) => {
                                          return crbListItem[
                                            'range0_25'
                                          ] ? (
                                              <li
                                                key={index}
                                                className="cursor-pointer crb-default-bgcolor"
                                                style={this.isSelected({
                                                  rbType: "allRecordRange",
                                                  sourceCriteriaId:
                                                    crbListItem[
                                                    "sourceCriteriaId"
                                                    ],
                                                  criteriaName:
                                                    crbListItem[
                                                    "sourceCriteriaName"
                                                    ],
                                                  selectedRanges: '0-25'
                                                })}
                                                onClick={() => {
                                                  this.saveSelectedBoxes({
                                                    rbType: "allRecordRange",
                                                    sourceCriteriaId:
                                                      crbListItem[
                                                      "sourceCriteriaId"
                                                      ],
                                                    criteriaName:
                                                      crbListItem[
                                                      "sourceCriteriaName"
                                                      ],
                                                    rubricId:
                                                      crbMainCategory[
                                                      "sourceRubricId"
                                                      ],
                                                    selectedRanges: '0-25'
                                                  });
                                                }}
                                              >
                                                {crbListItem["range0_25"]}
                                              </li>
                                            ) : (
                                              <li key={index}>{crbListItem[
                                                "range0_25"
                                              ] === null ? 0 : 0}</li>
                                            );
                                        }
                                      )}
                                    </ul>
                                  </div>
                                </div>

                                <div className="crb-all-records-col pos-rel">
                                  <div className="crb-bor-1"></div>
                                  <div className="test">
                                    <ul>
                                      {crbMainCategory["resultList"].map(
                                        (crbListItem, index) => {
                                          return crbListItem[
                                            "range26_50"
                                          ] ? (
                                              <li
                                                key={index}
                                                className="cursor-pointer crb-default-bgcolor"
                                                style={this.isSelected({
                                                  rbType: "allRecordRange",
                                                  sourceCriteriaId:
                                                    crbListItem[
                                                    "sourceCriteriaId"
                                                    ],
                                                  criteriaName:
                                                    crbListItem[
                                                    "sourceCriteriaName"
                                                    ],
                                                  selectedRanges: '26-50'
                                                })}
                                                onClick={() => {
                                                  this.saveSelectedBoxes({
                                                    rbType: "allRecordRange",
                                                    sourceCriteriaId:
                                                      crbListItem[
                                                      "sourceCriteriaId"
                                                      ],
                                                    criteriaName:
                                                      crbListItem[
                                                      "sourceCriteriaName"
                                                      ],
                                                    rubricId:
                                                      crbMainCategory[
                                                      "sourceRubricId"
                                                      ],
                                                    selectedRanges: '26-50'
                                                  });
                                                }}
                                              >
                                                {crbListItem["range26_50"]}
                                              </li>
                                            ) : (
                                              <li key={index}>{crbListItem[
                                                "range26_50"
                                              ] === null ? 0 : 0}</li>
                                            );
                                        }
                                      )}
                                    </ul>
                                  </div>
                                </div>

                                <div className="crb-all-records-col pos-rel">
                                  <div className="crb-bor-1"></div>
                                  <div className="test">
                                    <ul>
                                      {crbMainCategory["resultList"].map(
                                        (crbListItem, index) => {
                                          return crbListItem[
                                            "range51_75"
                                          ] ? (
                                              <li
                                                key={index}
                                                className="cursor-pointer crb-default-bgcolor"
                                                style={this.isSelected({
                                                  rbType: "allRecordRange",
                                                  sourceCriteriaId:
                                                    crbListItem[
                                                    "sourceCriteriaId"
                                                    ],
                                                  criteriaName:
                                                    crbListItem[
                                                    "sourceCriteriaName"
                                                    ],
                                                  selectedRanges: '51-75'
                                                })}
                                                onClick={() => {
                                                  this.saveSelectedBoxes({
                                                    rbType: "allRecordRange",
                                                    sourceCriteriaId:
                                                      crbListItem[
                                                      "sourceCriteriaId"
                                                      ],
                                                    criteriaName:
                                                      crbListItem[
                                                      "sourceCriteriaName"
                                                      ],
                                                    rubricId:
                                                      crbMainCategory[
                                                      "sourceRubricId"
                                                      ],
                                                    selectedRanges: '51-75'
                                                  });
                                                }}
                                              >
                                                {crbListItem["range51_75"]}
                                              </li>
                                            ) : (
                                              <li key={index}>{crbListItem[
                                                "range51_75"
                                              ] === null ? 0 : 0}</li>
                                            );
                                        }
                                      )}
                                    </ul>
                                  </div>
                                </div>

                                <div className="crb-all-records-col pos-rel">
                                  <div className="crb-bor-1"></div>
                                  <div className="test">
                                    <ul>
                                      {crbMainCategory["resultList"].map(
                                        (crbListItem, index) => {
                                          return crbListItem[
                                            "range76_100"
                                          ] ? (
                                              <li
                                                key={index}
                                                className="cursor-pointer crb-default-bgcolor"
                                                style={this.isSelected({
                                                  rbType: "allRecordRange",
                                                  sourceCriteriaId:
                                                    crbListItem[
                                                    "sourceCriteriaId"
                                                    ],
                                                  criteriaName:
                                                    crbListItem[
                                                    "sourceCriteriaName"
                                                    ],
                                                  selectedRanges: '76-100'
                                                })}
                                                onClick={() => {
                                                  this.saveSelectedBoxes({
                                                    rbType: "allRecordRange",
                                                    sourceCriteriaId:
                                                      crbListItem[
                                                      "sourceCriteriaId"
                                                      ],
                                                    criteriaName:
                                                      crbListItem[
                                                      "sourceCriteriaName"
                                                      ],
                                                    rubricId:
                                                      crbMainCategory[
                                                      "sourceRubricId"
                                                      ],
                                                    selectedRanges: '76-100'
                                                  });
                                                }}
                                              >
                                                {crbListItem["range76_100"]}
                                              </li>
                                            ) : (
                                              <li key={index}>{crbListItem[
                                                "range76_100"
                                              ] === null ? 0 : 0}</li>
                                            );
                                        }
                                      )}
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            {this.props.scroll &&
              <div className="crb-perct-analysis pos-rel ">
                <div className="crb-btm-bor"></div>
                <div className="crb-btm-border"></div>
                <ul>
                  <li>
                    <span className="arrow_box-crb">% of Analysis</span>
                  </li>
                  <li style={{ borderBottom: " 4px solid rgb(213, 234, 242" }}>
                    0-25
                </li>
                  <li style={{ borderBottom: " 4px solid rgb(191, 224, 235" }}>
                    26-50
                </li>
                  <li style={{ borderBottom: " 4px solid rgb(170, 214, 229" }}>
                    51-75
                </li>
                  <li style={{ borderBottom: "4px solid rgb(128, 195, 218)" }}>
                    76-100
                </li>
                </ul>
              </div>
            }
          </div>
        </React.Fragment>
      );
    } else {
      return <div></div>;
    }
  }
}

export default ClassReadingBehaviourChart;
