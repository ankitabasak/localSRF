import React, { PureComponent } from 'react';

import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';

class Class_RB_SidePanel extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      SortData: {
        sortColumn: 'date',
        sortType: 'desc'
      }
    };
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text) {

    if (text.length > 14) {
      return (
        <React.Fragment>
          {text.substr(0, 14)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }

  classRbGridData(Data, tableData) {
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div className="class_ea-inner-wrap">
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="crb"
        >
          <div className="student-column-list-rhs-sec classRbCol-08-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'lastName',
                Data.sortType
              )}
            >
              Students ({tableData.length})
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'lastName', 'desc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('lastName', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'lastName', 'asc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('lastName', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec classRbCol-08-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'level',
                Data.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'level', 'desc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('level', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'level', 'asc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('level', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec classRbCol-08-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'proficiency',
                Data.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'proficiency', 'desc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('proficiency', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'proficiency', 'asc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('proficiency', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec classRbCol-08-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'date',
                Data.sortType
              )}
            >
              Date
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'date', 'desc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('date', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'date', 'asc')
                }
                onClick={() =>
                  this.readingBehaviorGrid('date', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "cea-scroll")}>
          {tableData.map((tableDetails, value) => (
            <div className="pos-rel student-list-row-rhs-sec" key={value}>
              <div className="student-column-list-rhs-sec cursor-pointer classRbCol-08-20" onClick={() => { this.props.navigateToStudent(tableDetails) }} >
                <span className="wb-break-all long-text-tooltip">
                  {this.longTextTooltip(tableDetails.firstName + ' ' + tableDetails.lastName)}
                </span>
              </div>
              <div className="student-column-list-rhs-sec classRbCol-08-20">
                <span>
                  {tableDetails.level ? tableDetails.level : dashSymbol}
                </span>
              </div>

              <div className="student-column-list-rhs-sec classRbCol-08-20">
                <span>
                  {tableDetails.proficiency
                    ? tableDetails.proficiency
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list-rhs-sec classRbCol-08-20">
                <span>
                  {tableDetails.date ? tableDetails.date : dashSymbol}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? 'rt-td-active'
      : '';
  }

  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return ' blueColor';
    } else {
      return '';
    }
  }

  //Onclick calling sort function and update the sort type and column in store
  readingBehaviorGrid(sortColumn, sortType, actualArray) {
    document.getElementById('crb').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.updateSortColumn(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);
      this.props.updateSortData(sortedArray);
    }
  }
  render() {
    let panelData = this.props.data;
    let sidePanelApiFailed = this.props.sidePanelApiFailed;
    let errorList = null;
    let key = this.props.selectedRB && Object.keys(this.props.selectedRB);
    if (this.props.selectedRB && key) {
      errorList = this.props.selectedRB[key];
    }

    if (errorList && errorList.length > 0) {
      return (
        <div>
          {panelData && (
            <React.Fragment>
              <div>
                {/* onclick and on load main api should send the Reading target */}
                <div className="pull-left rt-left-heading">
                  {panelData['recordType']}
                </div>
                <div className="pos-rel">
                  <div className="rt-rhs-strip"></div>
                  <hr className="clearfix mb-8" />
                </div>
                <div className="mb-10">
                  <div className="reading-level-label mb-8 color-1">
                    First Record Date Range:
                    <span> {panelData.firstRecordDateRange}</span>
                  </div>
                  <div className="reading-level-label color-2">
                    Recent Record Date Range:
                    <span> {panelData.recentRecordDateRange}</span>
                  </div>
                </div>
                <div className="pull-right clearfix new-mb-4 rt-label-txt crb-roster-alignmnt classRb-roseter-txt">
                  <span className="rt-label">
                    No. of students rostered:
                    <span> {panelData.noOfStudentsRostered}</span>
                  </span>
                </div>
                <div className="rhs-wrap class-rb-wrapper crb-ipad-wrap-view">
                  <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                    <div className="student-list-table-main">
                      <div className="student-list-table-rhs-sec">
                        {this.classRbGridData(
                          this.props.sortData,
                          panelData.cpbGridDataResponseList
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </React.Fragment>
          )}
          {!panelData && !sidePanelApiFailed && (
            <React.Fragment>
              <div className="display-msg err-msg-alignment cfp-err-msg-alignment top-30">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>

          )}
          {!panelData && sidePanelApiFailed && <React.Fragment>
            <div className="display-msg err-msg-alignment cfp-err-msg-alignment top-30">
              The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
            </div>
          </React.Fragment>}
        </div>
      );
    } else {
      return <MakeSelectionForORR />;
    }
  }
}

export default Class_RB_SidePanel;
