import React, { PureComponent } from "react";
import { dataSorting } from "../../ReusableComponents/OrrReusableComponents";
import "../class-common.css";
import { connect } from "react-redux";
import {
  SAVE_SORTED_CFPO,
  SORT_CFPO_GRID
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import {
  navigateToStudentReportFromClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import {
  Chart_Enabled
} from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import spinner from "../../../../public/assets/orr/rlp-screen/loader-white-bg.gif";

class ClassFluencyProgress extends PureComponent {

  constructor(props) {
    super(props);
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }
  // tooltip for long text
  longTextTooltip(text) {
    if (text.length > 14) {
      return (
        <React.Fragment>
          {text.substr(0, 14)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }
  classFpoGridData(Data, tableData) {
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div className="class_ea-inner-wrap class-fa-1st-tab">
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "
          id="cfpo"
        >
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "lastName",
                Data.sortType
              )}
            >
              Students ({tableData.length})
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "lastName", "desc")
                }
                onClick={() => this.fpoGrid("lastName", "desc", tableData)}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "lastName", "asc")
                }
                onClick={() => this.fpoGrid("lastName", "asc", tableData)}
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "readingLevel",
                Data.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "readingLevel", "desc")
                }
                onClick={() => this.fpoGrid("readingLevel", "desc", tableData)}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "readingLevel", "asc")
                }
                onClick={() => this.fpoGrid("readingLevel", "asc", tableData)}
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "proficiency",
                Data.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "proficiency", "desc")
                }
                onClick={() => this.fpoGrid("proficiency", "desc", tableData)}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "proficiency", "asc")
                }
                onClick={() => this.fpoGrid("proficiency", "asc", tableData)}
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "assignmentDate",
                Data.sortType
              )}
            >
              Date
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "assignmentDate", "desc")
                }
                onClick={() =>
                  this.fpoGrid("assignmentDate", "desc", tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "assignmentDate", "asc")
                }
                onClick={() => this.fpoGrid("assignmentDate", "asc", tableData)}
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "cea-scroll")}>
          {tableData.map((tableDetails, value) => (
            <div className="pos-rel student-list-row-rhs-sec" key={value}>
              <div className="student-column-list-rhs-sec cursor-pointer" onClick={() => {
                this.props.navigateToStudentReportFromClassReport(tableDetails, true)
              }} >
                <span className="wb-break-all long-text-tooltip">
                  {this.longTextTooltip(tableDetails.firstName + ' ' + tableDetails.lastName)}
                </span>
              </div>
              <div className="student-column-list-rhs-sec">
                <span>
                  {tableDetails.readingLevel
                    ? tableDetails.readingLevel
                    : dashSymbol}
                </span>
              </div>

              <div className="student-column-list-rhs-sec">
                <span>
                  {tableDetails.proficiency
                    ? tableDetails.proficiency
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list-rhs-sec">
                <span>
                  {tableDetails.assignmentDate
                    ? tableDetails.assignmentDate
                    : dashSymbol}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? "rt-td-active"
      : "";
  }

  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return " blueColor";
    } else {
      return "";
    }
  }

  //Onclick calling sort function and update the sort type and column in store
  fpoGrid(sortColumn, sortType, actualArray) {
    document.getElementById("cfpo").scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_CFPO_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);
      this.props.SAVE_SORTED_CFPO(sortedArray);
    }
  }

  render() {
    let recordType = this.props.selectedErrors &&
      Object.keys(this.props.selectedErrors);
    let errorList = recordType
      ? this.props.selectedErrors[recordType] &&
      this.props.selectedErrors[recordType].length > 0
      : false;

    if (errorList) {
      return (
        <div className="col-md-4 res-width cea-rhs-rel mt-6 cfp-chart-rhs-wrap">
          {this.props.fpoGridData && (
            <React.Fragment>
              <div>
                {/* onclick and on load main api should send the Reading target */}
                <div className="pull-left rt-left-heading">
                  {
                    this.props.fpoGridResponse.selectedRecordTypeDetails
                      .recordTitle
                  }
                </div>
                <hr className="clearfix mb-8" />
                <div className="mb-10">
                  <div className="reading-level-label mb-8 color-1">
                    First Record Date Range:
                    <span> {
                      this.props.fpoGridResponse.selectedRecordTypeDetails
                        .firstRecordDateRange
                    }
                    </span>
                  </div>
                  <div className="reading-level-label color-2">
                    Recent Record Date Range:
                    <span> {
                      this.props.fpoGridResponse.selectedRecordTypeDetails
                        .recentRecordDateRange
                    }
                    </span>
                  </div>
                </div>
                <div className="pull-right clearfix new-mb-4 rt-label-txt">
                  <span className="rt-label">
                    No. of students rostered:
                    <span> {
                      this.props.fpoGridResponse.selectedRecordTypeDetails
                        .noOfStudentsRoastered
                    }
                    </span>
                  </span>
                </div>
                <div className="rhs-wrap">
                  <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                    <div className="student-list-table-main">
                      <div className="student-list-table-rhs-sec cfa-06-20">
                        {this.classFpoGridData(
                          this.props.Data,
                          this.props.fpoGridData
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </React.Fragment>
          )}
          {!this.props.fpoGridData && (
            <React.Fragment>
              <div className="display-msg err-msg-alignment cfp-err-msg-alignment">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>
          )}
        </div>
      );
    } else {
      return (
        <div className="col-lg-4 res-width err-msg-alignment">
          <MakeSelectionForORR />
        </div>
      );
    }
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(mapStateToProps, { SAVE_SORTED_CFPO, SORT_CFPO_GRID, navigateToStudentReportFromClassReport, Chart_Enabled })(
  ClassFluencyProgress
);
// export default Ea_Table;
