import ClassFluencyProgress from './class-fluency-progress';
import React from 'react';
import { shallow } from 'enzyme';

jest.mock('react-redux', () => ({
    connect: jest.fn().mockImplementation(() => (component) => component),
  }));
  function setup(overrides = {}) {
    const props = {
    };
    const finalProps = Object.assign(props, overrides);
    const wrapper = shallow((
        <ClassFluencyProgress {...finalProps} />
    ));
    return { wrapper };
  };
  describe('ClassFluencyProgress', () => {
    describe('renders properly', () => {
      const { wrapper } = setup();
      it('renders component', () => {
        expect(wrapper).toHaveLength(1);
      });
      it('matches snapshot', () => {
        expect(wrapper).toMatchSnapshot();
      });
    });
    describe('renders properly', () => {
      it('MakeSelectionForORR component not render default', () => {
        const { wrapper } = setup({
          'selectedErrors' : {
            "firstRecord": [
              {
                "criteriaId": 16,
                "errorName": "phrasing",
                "recordType": "firstRecord",
                "rubrixScore": 2
              },
              {
                "criteriaId": 18,
                "errorName": "pace",
                "recordType": "firstRecord",
                "rubrixScore": 2
              },
            ]
          }
        });
        expect(wrapper.find('MakeSelectionForORR')).toHaveLength(0);
      });
      it('MakeSelectionForORR component will render', () => {
        const { wrapper } = setup();
        expect(wrapper.find('MakeSelectionForORR')).toHaveLength(1);
      });
    });
  });
