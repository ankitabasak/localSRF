import React, { PureComponent } from "react";
import "../FluencyProgressComponents/class-fluency-prorgress.css";
import ClassFluencyProgressChart from "./class-fluency-prorgress-chart.jsx";
import { CLASS_FPO_API } from "../../../Redux_Actions/C_ErrorAnalysisAction.jsx";
import { connect } from "react-redux";
import ClassFluencyProgress from "./class-fluency-progress.jsx";
import NoRecordsData from "../../../Utils/No_Data_Found";
import { getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';

class ClassFluencyProgressContainer extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      sidePanelPayload: {},
      errorRecordType: {},
      timeOut: false,
      defaultFilterRecType: {
        allRecords: false,
        recentRecord: true
      }
    };
    this.timeOut = this.timeOut.bind(this);
  }

  componentDidMount() {
    this.callCfpotApi("rec");
  }

  // handle timeout
  timeOut() {
    this.setState({ ...this.state, timeOut: true });
  }

  //make api call
  callCfpotApi(type) {
    let Token = this.props.LoginDetails.JWTToken;

    this.setState({
      ...this.state,
      timeOut: false
    });
    let sidePanelPayload = getCommonHeaders(this.props, 'class');
    let errorRecordType = {
      allRecords: type === "all" ? true : false,
      recentRecord: type === "rec" ? true : false
    };
    this.setState({
      sidePanelPayload: sidePanelPayload,
      errorRecordType: errorRecordType
    });
  }


  render() {
    let classObject = this.props.ContextHeader.Class;
    let fpoData = this.props;

    if (!this.props.fpoData.noRecordFound) {
      return (
        <main>
          {this.props.NavigationByHeaderSelection.class && this.props.ContextHeader.Roster_Tab["SelectedClass"]["id"] ? (
            <section>
              {this.props.fpoData.firstRecordObj && (
                <div className="container container-resolution cfa classFaFpot-03-20">
                  <div className="row">
                    <ClassFluencyProgressChart
                      firstRecord={this.props.fpoData.firstRecordObj}
                      allRecord={this.props.fpoData.allRecordObj}
                      recentRecord={this.props.fpoData.recentRecordObj}
                      makeApiCall={x => this.callCfpotApi(x)}
                      errorRange={this.props.fpoData.errorRange}
                      showHideRecentRecord={
                        this.props.fpoData.showHideRecentRecord
                      }
                      showHideFirstRecord={this.props.fpoData.showHideFirstRecord}
                      showHideAllRecord={this.props.fpoData.showHideAllRecord}
                      SelectedErr={this.props.fpoData.SelectedErr}
                      internalFilter={this.props.CommonFilterData}
                      sidePanelPayload={this.state.sidePanelPayload}
                      showRecord={this.props.fpoData.showRecord}
                      token={this.props.LoginDetails.JWTToken}
                    />

                    {this.props.fpoData.firstRecordObj && !this.props.fpoData.sidePanelAPIFail && (
                      <ClassFluencyProgress
                        scrollFlag={false}
                        fpoGridResponse={this.props.fpoData.fpoGridResponse}
                        fpoGridData={this.props.fpoData.fpoGridData}
                        Data={this.props.fpoData.SortData}
                        selectedErrors={this.props.fpoData["SelectedErr"]}
                      />
                    )}
                    {/* {this.props.sideTableData && (
                      <ClassFluencyProgress
                        sideTableData={this.props.sideTableData}
                        Data={this.props.SortData}
                      />
                    )} */}

                    {this.props.fpoData.sidePanelAPIFail && (
                      <div class="col-md-4 res-width cea-rhs-rel mt-6">
                        <div class=" res-width display-msg err-msg-alignment top-30 ">
                          <span>The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
                            </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </section>
          ) : (
              ""
            )}
        </main>
      );
    } else {
      return (
        <NoRecordsData NodataFound={"dataNotAvail"} />
      )
    }
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  ClassEaData
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const {
    firstRecordObj,
    allRecordObj,
    recentRecordObj,
    sideTableData,
    errorRange,
    msvErrorRange,
    SortData,
    showHideRecentRecord,
    SelectedErr,
    ErrorCode,
    apiLoadFail,
    isDataAvailable,
    showRecord
  } = ClassEaData;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    CommonFilterData,
    firstRecordObj,
    allRecordObj,
    recentRecordObj,
    sideTableData,
    errorRange,
    msvErrorRange,
    SortData,
    showHideRecentRecord,
    SelectedErr,
    ErrorCode,
    apiLoadFail,
    isDataAvailable,
    showRecord
  };
};

export default connect(mapStateToProps, { CLASS_FPO_API })(
  ClassFluencyProgressContainer
);
