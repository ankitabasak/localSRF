import React, { PureComponent } from "react";
import { connect } from "react-redux";
import ClassFluencyProgressContainer from "../FluencyProgressComponents/CFP-Chart-Container.jsx";
import ChartNotLoad from "../../../Utils/Chart_Not_Load";
import NoRecordsData from "../../../Utils/No_Data_Found";
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents'
import {
    API_LOADER,
    CLASS_FPO_API,
    SIDE_PANEL_API_LOADER,
    C_FPO_Grid_Api,
    updateDropDownData,
    updateAllMonth,
    toggleDropDown,
    updateChartDetails,
    CFR_CSVDATA_DOWNLOAD_APICALL,
    CFR_CSVDATA_DOWNLOAD_RESET
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import { SHOW_HIDE_GROUPING } from "../../../Redux_Actions/C_GroupingAction.jsx";
import Spinner from "../../ReusableComponents/Spinner/Spinner.jsx";
import TimeOut from "../../ReusableComponents/Spinner/TimeOut.jsx";
import NoRosterData from "../../../Utils/NoRoster.js";
import Group from '../Grouping_ORR/C_Grouping.jsx';
import PrintCfaFpot from '../../ReusableComponents/PrintOrrCharts/C_FaFpotPrint.jsx'
import NoFluencyData from '../../../Utils/No_Data.js'
import titleImg from "../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg";

class FluencyFpotChart extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            externalFilter: {},
            internalFilter: {},
            timeOut: false,
            sidepanelApiInRun: false
        };

        this.timeOut = this.timeOut.bind(this);
        this.getCFData = this.getCFData.bind(this);
        this.toggleHidden = this.toggleHidden.bind(this);
    }

    componentDidMount() {
        this.getCFData();
    }

    getCFData() {
        this.setState({
            ...this.state,
            timeOut: false
        });
        if (this.props && !this.state.timeOut) {
            let dataRecordType = {
                allRecords: false,
                recentRecord: true
            };
            let data = {
                dataRecordType,
                ...getCommonHeaders(this.props, 'class'),
                value: "class"
            };
            this.props.CLASS_FPO_API(this.props.LoginDetails.JWTToken, data);
        }
    }

    // Download csv data
    downLoadCSVData() {
        if (this.props.FluencyTabSelection["fpot"]) {
            this.props.CFR_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
            let Req_Payload = {
                classChartType: {
                    "allRecordsAvgFlag": this.props.progressOverTime.showRecord === 'rec' ? '2' :
                        this.props.progressOverTime.showRecord === 'all' ? '1' : '',
                    "chartName": "CFR"
                },
                ...getCommonHeaders(this.props, 'class')
            };
            this.props.CFR_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
        }

    }

    // handle timeout
    timeOut() {
        this.props.API_LOADER({
            isApiLoading: false,
            apiLoadFail: false,
            apiTimeOut: true
        });
    }

    // toggle grouping
    toggleHidden(flag) {
        this.props.SHOW_HIDE_GROUPING(flag);
    }
    render() {
        let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedClass.name;
        if (this.props.FluencyTabSelection["fpot"] &&
            this.props.progressOverTime.CfrCsvDownload &&
            this.props.progressOverTime.CfrCsvDownload['downloadInProgress'] &&
            this.props.progressOverTime.CfrCsvDownload['csvData']) {
            setTimeout(() => {
                this.refs.groupCSV.link.click();
                this.props.CFR_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
            }, 500)
        }
        return (
            <div>
                {this.props.NavigationByHeaderSelection.class && this.props.ContextHeader.Roster_Tab.SelectedClass.id ? (
                    <div>
                        {/* Class Fluency Progress Over Time Chart */}
                        {this.props.progressOverTime.firstRecordObj &&
                            this.props.FluencyTabSelection["fpot"] && !this.props.isApiLoading && !this.props.noChartData && (
                                <React.Fragment>
                                    <div id="testClass">
                                        {this.props.progressOverTime.CfrCsvDownload && this.props.progressOverTime.CfrCsvDownload['csvData'] &&
                                            <CSVLink
                                                ref="groupCSV"
                                                headers={this.props.progressOverTime.CfrCsvDownload['csvData'] && this.props.progressOverTime.CfrCsvDownload['csvData']['header']}
                                                data={this.props.progressOverTime.CfrCsvDownload['csvData'] && this.props.progressOverTime.CfrCsvDownload['csvData']['data']}
                                                style={{ display: 'none' }}
                                                // filename={"CFR_CSV.csv"}
                                                filename={`${csvFileName}.csv`}
                                            />}
                                        <div className="cls-csv-icon-alignment" onClick={() => !this.props.progressOverTime.CfrCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                                            {this.props.progressOverTime.CfrCsvDownload && this.props.progressOverTime.CfrCsvDownload['downloadInProgress'] ?
                                                <span className="csv_download_icon">
                                                    <i className="material-icons">autorenew</i>
                                                </span> :
                                                <span className="csv_download_icon">
                                                    <img src={CsvIcon} width="20" height="20" />
                                                </span>}
                                        </div>
                                        <ClassFluencyProgressContainer
                                            fpoData={this.props.progressOverTime}
                                        />
                                    </div>
                                    {/* {!this.props.progressOverTime.sidePanelAPIFail && this.props.progressOverTime.fpoGridData &&  */}
                                    {this.props.progressOverTime.fpoGridData && <span className="class-cfafpot-print-btn ">
                                        <PrintCfaFpot
                                            selectedFilter={this.props.CommonFilterData}
                                            studentDetails={this.props.ContextHeader}
                                            navSelected={this.props.NavigationByHeaderSelection}
                                            fpoData={this.props.progressOverTime}
                                        />
                                    </span>}
                                    {/* } */}
                                    {this.props.NavigationByHeaderSelection.class && !this.props.progressOverTime.hideCreateGroup &&
                                        !this.props.NavigationByHeaderSelection.readingHistory ? (
                                            <div className="group-title" onClick={() => this.toggleHidden(true)}>
                                                <img src={titleImg} className="pull-left mlr-9" />
                                                <span>
                                                    <b>Create Groups</b>
                                                </span>
                                            </div>
                                        ) : (
                                            ""
                                        )}
                                </React.Fragment>
                            )}
                        {this.props.showGrouping &&
                            this.props.progressOverTime.fpoGridData &&
                            this.props.FluencyTabSelection["fpot"] && (
                                <Group
                                    cancelModal={this.toggleHidden}
                                    showGrouping={this.props.showGrouping}
                                    gridData={this.props.progressOverTime.fpoGridData}
                                    Data={this.props.progressOverTime.SortData}
                                />
                            )}
                        {this.props.isApiLoading && (
                            <Spinner
                                startSpinner={this.props.isApiLoading}
                                showTimeOut={this.timeOut}
                            />
                        )}
                        {this.props.apiTimeOut && (
                            <TimeOut
                                tryAgain={() => {
                                    this.getCFData();


                                }}
                            />
                        )}
                        {!this.props.CF_Chart_Response && this.props.apiLoadFail && (
                            <ChartNotLoad
                                tryAgain={() => {
                                    this.getCFData();
                                }}
                            />
                        )}
                        {this.props.noChartData && (
                            <NoRecordsData NodataFound={"dataNotAvail"} />
                        )}

                        {this.props.progressOverTime.rubricDataMsg &&
                            <div>
                                <NoFluencyData NoFluencyData={this.props.progressOverTime.rubricDataMsg} />
                            </div>
                        }
                    </div>
                ) : (
                        <NoRosterData />
                    )}
            </div>
        );
    }
}

const mapStateToProps = ({
    classFluency,
    Universal,
    CommonFilterDetails,
    Authentication,
    C_GroupingReducer
}) => {
    const {
        FluencyTabSelection,
        CF_Chart_Response,
        progressOverTime,
        sidePanelApiLoader,
        classFluencyChartData,
        monthRangeObj,
        selAll,
        toggleData,
        updateDropDownData,
        updateAllMonth,
        toggleDropDown,
        updateChartDetails,
        isApiLoading,
        noChartData,
        apiLoadFail,
        apiTimeOut,
        SortData,
        hideCreateGroup,
        CfaCsvDownload
    } = classFluency;
    const { ContextHeader, NavigationByHeaderSelection } = Universal;
    const { CommonFilterData } = CommonFilterDetails;
    const { LoginDetails } = Authentication;
    const { showGrouping } = C_GroupingReducer;
    return {
        FluencyTabSelection,
        NavigationByHeaderSelection,
        ContextHeader,
        CommonFilterData,
        CF_Chart_Response,
        progressOverTime,
        sidePanelApiLoader,
        classFluencyChartData,
        monthRangeObj,
        selAll,
        toggleData,
        updateDropDownData,
        updateAllMonth,
        toggleDropDown,
        updateChartDetails,
        isApiLoading,
        apiLoadFail,
        noChartData,
        apiTimeOut,
        SortData,
        LoginDetails,
        showGrouping,
        hideCreateGroup,
        CfaCsvDownload
    };
};

export default connect(mapStateToProps, {
    SIDE_PANEL_API_LOADER,
    API_LOADER,
    CLASS_FPO_API,
    C_FPO_Grid_Api,
    SHOW_HIDE_GROUPING,
    updateDropDownData,
    updateAllMonth,
    toggleDropDown,
    updateChartDetails,
    CFR_CSVDATA_DOWNLOAD_APICALL,
    CFR_CSVDATA_DOWNLOAD_RESET

})(FluencyFpotChart);
