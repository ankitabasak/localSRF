
import React, { PureComponent } from "react";
import "../FluencyProgressComponents/class-fluency-prorgress.css";
import "../Class_Error_Analysis/class-error-analysis.css";
import {
  Selected_Errors,
  Update_RecordType,
  API_LOADER,
  UPDATE_SELECTED_BOXES,
  C_FPO_Grid_Api,
  UPDATE_ALL_RECORDS_TYPE,
  CLASS_FPO_API,
  CLASS_FPO_SIDEPANEL_SPINNER
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import { connect } from "react-redux";

class ClassFluencyProgressChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      sidepanelApiInRun: false,
      ErrorList: ["phrasing", "intonation", "pace", "accuracy"],
      xAxis: ["Phrasing", "Intonation", "Pace", "Accuracy"],

      colorBar: [
        "4px solid rgb(255, 142, 45)",
        "4px solid rgb(255, 197, 45)",
        "4px solid rgb(50, 172, 65)",
        "4px solid rgb(7, 156, 207)"
      ],

      isHovered: false,
      outerIndex: "",
      error: "",
      recordType: ""
    };

    this.showRecord = this.showRecord.bind(this);
    this.onMouseOver = this.onMouseOver.bind(this);
    this.onMouseOut = this.onMouseOut.bind(this);
  }

  //to display the last passage
  showToolTip(passage) {
    let key = ["Phrasing", "Intonation", "Pace", "Accuracy"];
    let obj = [];
    let pasVal = Object.keys(passage);
    pasVal.map((val, inx) => {
      if (val !== "score") {
        obj.push(passage[val]);
      }
    });

    return (
      <div className="hover-rlp school-tooltip-wrap">
        <ul>
          {key.map((keyName, i) => {
            return (
              <React.Fragment>
                <li>
                  <span className="scfr-tooltip"> {keyName}</span> -
                  <span>{obj[i]}</span>
                </li>
              </React.Fragment>
            );
          })}
        </ul>
        <div className="tooltip-dot" />
      </div>
    );
  }

  onMouseOver(i, errType, recordType) {
    this.setState({
      isHovered: true,
      outerIndex: i,
      error: errType,
      recordType: recordType
    });
  }

  onMouseOut() {
    this.setState({
      isHovered: false,
      outerIndex: "",
      error: "",
      recordType: ""
    });
  }

  //onclick select error
  selectedErrors(errorSel, selError) {
    var errList = selError[errorSel.recordType] || [];
    if (errList) {
      let duplicateIndex = this.isDuplicateBox(errorSel, errList);
      if (duplicateIndex != -1) {
        errList.splice(duplicateIndex, 1);
      } else {
        errList.push(errorSel);
      }
      this.props.Selected_Errors({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });
      this.classErrGridApi({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });
    } else {
      errList = { [errorSel.recordType]: [errorSel] };
      this.props.Selected_Errors({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });

      // update the selected boxes
      // this.props.UPDATE_SELECTED_BOXES({ ['selectedErrors']: errList });
      this.classErrGridApi({
        ["selectedErrors"]: { [errorSel.recordType]: errList }
      });
    }
  }

  // // check for duplicate value
  isDuplicateBox(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          bubble.errorName == obj.errorName &&
          bubble.recordType == obj.recordType &&
          bubble.rubrixScore == obj.rubrixScore
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }

  classErrGridApi(selErrList) {
    let key = Object.keys(selErrList["selectedErrors"]);
    let dataForApi = [];
    if (key && key.length > 0) {
      selErrList["selectedErrors"][key[0]].forEach(item => {
        dataForApi.push({
          criteriaId: item.criteriaId,
          score: item.rubrixScore
        });
      });
    }

    this.props.CLASS_FPO_SIDEPANEL_SPINNER({ showSpinner: true });
    if (dataForApi.length > 0) {
      if (!this.state.sidepanelApiInRun) {
        this.setState({ ...this.state, sidepanelApiInRun: true });
        setTimeout(() => {
          this.props.C_FPO_Grid_Api(this.props.token, {
            ...this.props.sidePanelPayload,
            listItems: dataForApi,
            recordType: key[0],
            allRecors: this.props.showRecord
          });
          this.setState({ ...this.state, sidepanelApiInRun: false });
        }, 1000);
      }
    }
  }

  //adding background color
  getOnClickColor(selectedErrors, currentLevelInfo) {
    let applyColor = "";
    if (selectedErrors) {
      if (
        selectedErrors[currentLevelInfo.recordType] &&
        selectedErrors[currentLevelInfo.recordType].length < 1
      ) {
        applyColor = " ";
        return applyColor;
      } else {
        if (selectedErrors[currentLevelInfo.recordType]) {
          selectedErrors[currentLevelInfo.recordType].forEach(obj => {
            if (
              obj.errorName == currentLevelInfo.errorName &&
              obj.recordType == currentLevelInfo.recordType &&
              obj.rubrixScore == currentLevelInfo.rubrixScore
            ) {
              applyColor = "select-color ";
              return;
            }
          });
        } else {
          // applyColor = "default-color ";
        }
      }
    }

    return applyColor;
    // if (errorNames.indexOf(level) > -1) {
    //   applyColor = 'default-color';
    // }
    // if (
    //   selectedClassLevels &&
    //   selectedClassLevels[currentLevelInfo.recordType]
    // ) {
    //   selectedClassLevels[currentLevelInfo.recordType].forEach(obj => {
    //     if (
    //       currentLevelInfo.errorName == obj.errorName &&
    //       currentLevelInfo.range == obj.range
    //     ) {
    //       applyColor = 'select-color';
    //       return;
    //     }
    //   });
    // }
    // return applyColor;
  }

  //apply hover color
  bgColorHover(i) {
    if (
      this.state.recordType === "firstRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "errR"
    ) {
      return "firstRec";
    }
    if (
      this.state.recordType === "firstRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "msvErr"
    ) {
      return "firstRecMsv";
    }
    if (
      this.state.recordType === "recentRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "errR"
    ) {
      return "firstRecErr";
    }
    if (
      this.state.recordType === "recentRecord" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "msvErr"
    ) {
      return "firstRecErrMsv";
    }
    if (
      this.state.recordType === "allRecordsAverage" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "errR"
    ) {
      return "allRecErr";
    }
    if (
      this.state.recordType === "allRecordsAverage" &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === "msvErr"
    ) {
      return "allRecErrMsv";
    }
  }

  displayRecords(record, errorList, errorRange, recordType, errType) {
    return (
      <div>
        {errorRange.map((valueRange, i) => {
          return (
            <div
              className="first-error-col cfpot"
              id={
                errType === "msvErr" && recordType === "firstRecord"
                  ? "msvAvg" + i
                  : recordType === "firstRecord" && errType == "errR"
                    ? "errAvg" + i
                    : recordType === "recentRecord" && errType == "errR"
                      ? "errAvg1" + i
                      : recordType === "recentRecord" && errType == "msvErr"
                        ? "msvAvg1" + i
                        : recordType === "allRecordsAverage" && errType == "errR"
                          ? "allErrAvg" + i
                          : recordType === "allRecordsAverage" && errType == "msvErr"
                            ? "allMsvAvg" + i
                            : ""
              }
            >
              <div className="bor-1" />

              <ul className={this.bgColorHover(i)}>
                {errorList.map((value, index) => {

                  let rubrixScore = errorRange[i]["score"];
                  return (
                    <li
                      key={index}
                      className={
                        (record[recordType][value][rubrixScore].value === 0
                          ? " no-color "
                          : "cursor-pointer ") +
                        this.getOnClickColor(this.props.SelectedErr, {
                          rubrixScore: rubrixScore,
                          errorName: value,
                          recordType: recordType
                        })
                      }
                      onClick={() => {
                        record[recordType][value][rubrixScore].value === 0
                          ? ""
                          : this.selectedErrors(
                            {
                              recordType: recordType,
                              rubrixScore: rubrixScore,
                              errorName: value,
                              criteriaId:
                                record[recordType][value][rubrixScore][
                                "criteriaId"
                                ]
                            },
                            this.props.SelectedErr
                          );
                      }}
                    >
                      {record[recordType][value][rubrixScore].value}
                    </li>
                  );
                })}
                <li
                  key={i}
                  className="btm-line cfpot-tooltip"
                  style={{
                    borderBottom:
                      errType === "msvErr"
                        ? this.state.msvBar[i]
                        : this.state.colorBar[i]
                  }}
                  onMouseOver={() =>
                    !errType
                      ? this.onMouseOver(i, "errR", recordType)
                      : this.onMouseOver(i, errType, recordType)
                  }
                  onMouseOut={() =>
                    !errType ? this.onMouseOut(i) : this.onMouseOut(i, errType)
                  }
                >
                  <span> {valueRange["score"]}</span>

                  <span> {this.showToolTip(valueRange)}</span>
                </li>
              </ul>
            </div>
          );
        })}
      </div>
    );
  }

  callChartApi(data) {
    let payLoad = {
      dataRecordType: {
        allRecords: data == "all" ? true : false,
        recentRecord: data == "rec" ? true : false
      },
      ...this.props.sidePanelPayload
    };
    this.props.CLASS_FPO_API(this.props.token, payLoad);
  }
  //show selected record
  showRecord(e) {
    // this.props.API_LOADER({
    //   isApiLoading: true,
    //   apiLoadFail: false,
    //   apiTimeOut: false
    // });
    this.props.UPDATE_ALL_RECORDS_TYPE(e.currentTarget.value);

    this.callChartApi(e.currentTarget.value);
  }

  render() {
    return (
      <div className="col-lg-7 res-width-8 class_ea cfac-lft">
        {/* Radio button start */}
        {
          //!this.props.showHideRecentRecord &&
          (
          <div className="show-radio-btn radio_btn_wrap cfa-print-radio">
            <div className="check-box-heading pull-left no-pointer">
              Compare No. of Students with:
            </div>
            <div className="round pull-left class_ea_radio">
              <input
                id="allRecAvg"
                type="radio"
                value="all"
                checked={this.props.showRecord === "all"}
                onChange={this.showRecord}
                disabled={this.props.showHideRecentRecord}
              />
              <span className={this.props.showRecord === 'all' ? " checkmark-sel" : "checkmark"} />
              <span
                className="cur-default"
              // className={this.props.showRecord === 'all' ? 'blueColor' : ''}
              >
                <label for="allRecAvg" className="radio-label">  All Records' Average</label>
              </span>
            </div>

            <div className="round pull-left class_ea_radio">
              <input
                id="recentRec"
                type="radio"
                value="rec"
                checked={this.props.showRecord === "rec"}
                onChange={this.showRecord}
                disabled={this.props.showHideRecentRecord}
              />
              <span className={this.props.showRecord === 'rec' ? " checkmark-sel" : "checkmark"} />
              <span
                className="cur-default"
              // className={this.props.showRecord === 'rec' ? 'blueColor' : ''}
              >
                <label for="recentRec" className="radio-label">Recent Record</label>
              </span>
            </div>
          </div>
        )}
        {/* Radio button end */}

        {/* Left Chart Table Start */}
        <div
          className="sea-wrapper pos-rel class_fa-fpot-wrap"
          style={{ width: "auto" }}
        >
          <div className="error-analysis-section-cea">
            <p>
              Fluency Progress<br></br>(By No. of Students)
            </p>
          </div>

          <div className="sea-scroller-cea">
            <div
              className="bor-bottom"
              style={{ position: "relative", top: "-10px", left: "-19px" }}
            >
              <hr className="cea-hr-top" />
            </div>
            <div className="cfr-bottom cFr-btm-15-20">
              <hr className="cea-hr-top" />
            </div>
            <div className="row">
              <div className="error-col-cea pos-rel" style={{ float: "left" }}>
                <p
                  className="col-name print-top3"
                  style={{
                    position: "absolute",
                    top: "-21px",
                    left: "0px",
                    fontSize: "14px",
                    fontWeight: "500",
                    whiteSpace: "nowrap",
                    width: "100%",
                    textAlign: "center"
                  }}
                >
                  Fluency
                </p>
                <ul className="cfr-strip cFpc-15-20">
                  {this.state.xAxis.map((value, i) => {
                    return (
                      <li
                        className="top-bor pos-rel"
                        className={i == 0 ? "top-bor" : ""}
                        key={i}
                      >
                        <span>{value}</span>
                        <div className={"row-strip-1 strip-bg-" + i + 1} />
                      </li>
                    );
                  })}
                  <li
                    className="pos-rel end-row"
                    style={{ borderBottom: "none", paddingLeft: "0px" }}
                  >
                    <div className="cea-no-of-error"></div>
                    <span className="arrow_box-cea size-box">Rubric Score</span>
                  </li>
                </ul>
              </div>
              {Object.keys(this.props.firstRecord.firstRecord).length !== 0 &&
                <div
                  className="first-record-error pos-rel"
                  style={{ float: "left", width: "auto", marginLeft: "5px" }}
                >
                  <div className="box-top-bor" />
                  <div className="td-devider1" />
                  <div className="td-devider2" />
                  <div className="td-devider3" />
                  <p
                    className="col-name print-top3"
                    style={{
                      position: "absolute",
                      top: "-21px",
                      left: "0px",
                      fontSize: "14px",
                      fontWeight: "500",
                      whiteSpace: "nowrap",
                      width: "100%",
                      textAlign: "center"
                    }}
                  >
                    First Record
                </p>

                  <div
                    className="sea-table"
                    style={{
                      borderLeft: "none",
                      borderRight: "none"
                    }}
                  >
                    {this.props.firstRecord && Object.keys(this.props.firstRecord.firstRecord).length !== 0 && !this.props.showHideFirstRecord &&
                      this.displayRecords(
                        this.props.firstRecord,
                        this.state.ErrorList,
                        this.props.errorRange,
                        "firstRecord",
                        "errR"
                      )}
                  </div>
                </div>
              }
              <div
                className="first-record-error pos-rel"
                style={{ float: "left", width: "auto", marginLeft: "5px" }}
              >
                <p
                  className="col-name print-top3"
                  style={{
                    position: "absolute",
                    top: "-21px",
                    left: "0px",
                    fontSize: "14px",
                    fontWeight: "500",
                    whiteSpace: "nowrap",
                    width: "100%",
                    textAlign: "center"
                  }}
                >
                  {/* {!(this.props.showHideRecentRecord || this.props.showHideAllRecord)
                    ? this.props.allRecord
                      ? `All Records' Average`
                      : this.props.recentRecord
                        ? "Recent Record"
                        : ""
                    : ""} */}

                  { this.props.allRecord
                    ? `All Records' Average`
                    : this.props.recentRecord
                      ? "Recent Record"
                      : "Recent Record"
                  }
                  {/* {!(this.props.showHideRecentRecord || this.props.showHideAllRecord)
                    ? this.props.allRecord
                      ? `All Records' Average`
                      : this.props.recentRecord
                        ? "Recent Record"
                        : ""
                    : ""} */}
                </p>
                <div className="box-top-bor" />
                <div className="td-devider1" />
                <div className="td-devider2" />
                <div className="td-devider3" />

                <div className="bor-1 bor-length" />

                {this.props.recentRecord &&
                this.props.showHideRecentRecord &&
                <div className="width256 model_center_no_data_line">
                  No Fluency analysis tracked in most recent record.
                </div>
                }

                {/* --all record code start */}
                {this.props.allRecord &&
                  !this.props.showHideAllRecord &&
                  this.displayRecords(
                    this.props.allRecord,
                    this.state.ErrorList,
                    this.props.errorRange,
                    "allRecordsAverage",
                    "errR"
                  )}
                {/* --all record code end */}
                {/* { recentRecord start} */}
                {this.props.recentRecord &&
                  !this.props.showHideRecentRecord &&
                  this.displayRecords(
                    this.props.recentRecord,
                    this.state.ErrorList,
                    this.props.errorRange,
                    "recentRecord",
                    "errR"
                  )}
                {/* recent record end */}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = () => {
  return {};
};

export default connect(mapStateToProps, {
  Selected_Errors,
  UPDATE_ALL_RECORDS_TYPE,
  Update_RecordType,
  API_LOADER,
  UPDATE_SELECTED_BOXES,
  C_FPO_Grid_Api,
  CLASS_FPO_API,
  CLASS_FPO_SIDEPANEL_SPINNER
})(ClassFluencyProgressChart);