export function getTotalNoOfStudent(listItems) {
  let totalStudents = {};
  listItems.forEach(item => {
    totalStudents[item.recordLevel] = item.recordLevelValue;
  });
  return totalStudents;
}
export function getStartingLevel(listItems) {
  let startingLevel = [];
  listItems.forEach(item => {
    startingLevel[item.startingLevel] = item.startingLevelValue;
  });
  return startingLevel;
}
export function getReadingTarget(listItems) {
  let readingTarget = {};
  listItems.forEach(item => {
    readingTarget[item.readingTarget] = item.targetLevelValue;
  });
  return readingTarget;
}

export function getConstructedData(data, yAxisLength) {
  let YaxisData = data.readingLevelAxis;
  let startingLevel = getStartingLevel(data.classStartingLevel);

  let readingTarget = getReadingTarget(data.classReadingTarget);
  let filterCount = 0;
  Object.keys(data.internalFilter.proficiency).forEach(key => {
    filterCount = data.internalFilter.proficiency[key] ? filterCount + 1 : filterCount;
  })
  let noOfCol = filterCount == 3 ? 2 : filterCount == 2 ? 3 : 4;

  let monthlyRecordData = [];

  data.recordDataList.map(individualData => {
    //let wcpmList = this.combineMonthData(individualData.wcpmList);
    let totalStudents = getTotalNoOfStudent(individualData.totalStudentRecord);
    let frustrationalRecordData = getTotalNoOfStudent(
      individualData.frustrationalRecordData.recordList
    );
    let independentRecordData = getTotalNoOfStudent(
      individualData.independentRecordData.recordList
    );
    let instructionalRecordData = getTotalNoOfStudent(
      individualData.instructionalRecordData.recordList
    );
    let independentRecordDataTotalValue =
      individualData.independentRecordData.totalStudentValue;
    let instructionalRecordDataTotalValue =
      individualData.instructionalRecordData.totalStudentValue;
    let frustrationalRecordDataTotalValue =
      individualData.frustrationalRecordData.totalStudentValue;
    // Push computed data
    monthlyRecordData.push({
      ...individualData,
      ['frustrationalRecordData']: frustrationalRecordData,
      ['independentRecordData']: independentRecordData,
      ['instructionalRecordData']: instructionalRecordData,
      ['totalNoOfStudents']: totalStudents,
      ['independentRecordDataTotalValue']: independentRecordDataTotalValue,
      ['instructionalRecordDataTotalValue']: instructionalRecordDataTotalValue,
      ['frustrationalRecordDataTotalValue']: frustrationalRecordDataTotalValue,
      yAxisLevels: YaxisData
    });
  });

  return {
    YaxisData: YaxisData,
    YaxisDataRange: YaxisData.slice(YaxisData.length - yAxisLength, YaxisData.length),
    xAxisScrollIndex: monthlyRecordData.length - noOfCol + 1,
    scrollIndex: YaxisData.length - yAxisLength,
    monthlyRecordData: monthlyRecordData,
    allRecordData: monthlyRecordData,
    columnToDisp: noOfCol,
    recentMonthlyRecords: getRecentMonthData(monthlyRecordData, noOfCol),
    startingLevel: startingLevel,
    readingTarget: readingTarget,
    selectedProficiency: data.internalFilter.proficiency
  };
}

export function getRecentMonthData(dataList, noOfCol) {
  let dataLen = dataList.length;
  let dataArray = [];
  if (dataLen > noOfCol) {
    for (let loop = noOfCol; loop > 0; loop--) {
      dataArray.push(dataList[dataLen - loop])
    }
    return dataArray;
    //   return [dataList[dataList.length - 2], dataList[dataList.length - 1]];
    //   // return [
    //   //   dataList[0],
    //   //   dataList[dataList.length - 2],
    //   //   dataList[dataList.length - 1]
    //   // ];
    // } else if (dataList.length == 2) {
    //   return [dataList[0], dataList[1]];
    // } else if (dataList.length == 1) {
    //   return dataList;
    // }
  } else {
    for (let loop = dataLen; loop > 0; loop--) {
      dataArray.push(dataList[dataLen - loop])
    }
    return dataArray;
  }
}

export function getModifiedData(data, yAxisLength) {
  let YaxisData = data.readingLevelAxis;
  let startingLevel = getStartingLevel(data.classStartingLevel);

  let readingTarget = getReadingTarget(data.classReadingTarget);

  let monthlyRecordData = [];

  data.recordDataList.map(individualData => {
    //let wcpmList = this.combineMonthData(individualData.wcpmList);
    let totalStudents = getTotalNoOfStudent(individualData.totalStudentRecord);
    let frustrationalRecordData = getTotalNoOfStudent(
      individualData.frustrationalRecordData.recordList
    );
    let independentRecordData = getTotalNoOfStudent(
      individualData.independentRecordData.recordList
    );
    let instructionalRecordData = getTotalNoOfStudent(
      individualData.instructionalRecordData.recordList
    );
    let independentRecordDataTotalValue =
      individualData.independentRecordData.totalStudentValue;
    let instructionalRecordDataTotalValue =
      individualData.instructionalRecordData.totalStudentValue;
    let frustrationalRecordDataTotalValue =
      individualData.frustrationalRecordData.totalStudentValue;
    // Push computed data
    monthlyRecordData.push({
      ...individualData,
      ['frustrationalRecordData']: frustrationalRecordData,
      ['independentRecordData']: independentRecordData,
      ['instructionalRecordData']: instructionalRecordData,
      ['totalNoOfStudents']: totalStudents,
      ['independentRecordDataTotalValue']: independentRecordDataTotalValue,
      ['instructionalRecordDataTotalValue']: instructionalRecordDataTotalValue,
      ['frustrationalRecordDataTotalValue']: frustrationalRecordDataTotalValue,
      yAxisLevels: YaxisData
    });
  });

  return {
    YaxisData: YaxisData,
    YaxisDataRange: YaxisData.slice(YaxisData.length - yAxisLength, YaxisData.length),
    xAxisScrollIndex: monthlyRecordData.length - 1,
    scrollIndex: YaxisData.length - yAxisLength,
    monthlyRecordData: monthlyRecordData,
    allRecordData: monthlyRecordData,
    recentMonthlyRecords: getRecentMonthData(monthlyRecordData),
    startingLevel: startingLevel,
    readingTarget: readingTarget
  };
}