import React, { PureComponent } from 'react';
import * as d3 from 'd3';
import {
  achieved_target_data,
  not_achieved_target_data,
  default_target_data
} from '../../../Redux_Actions/C_ReadingLevelAction.jsx';
import { connect } from 'react-redux';

class PieChart extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isHovered: false,
      isAchievedFlag: false
    };

    this.color = this.color.bind(this);
  }

  color(val) {
    const color = ['#606060', '#ff8c40'];
    return color[val.index];
  }

  arcPoint(arc, outerArc, value) {
    var posA = arc.centroid(value);
    var posB = outerArc.centroid(value);
    var posC = outerArc.centroid(value);
    var midAngle = value.startAngle + (value.endAngle - value.startAngle) / 2;

    posC[0] = 100 * 1.2 * (midAngle < Math.PI ? 1 : -1);

    return [posA, posB, posC];
  }

  textPosition(outerArc, value) {
    var pos = outerArc.centroid(value);
    var midangle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    pos[0] = 100 * 1.0 * (midangle < Math.PI ? 1 : -1);
    return 'translate(' + pos + ')';
  }

  lableNamePosition(outerArc, value) {
    var pos = outerArc.centroid(value);
    var midangle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    pos[0] = 100 * 1.0 * (midangle < Math.PI ? 1 : -1);
    // pos[1] = 100 * 0.51 * (pos[1] > 1 ? 1 : -1);
    return 'translate(' + pos + ')';
  }

  textAlignment(value) {
    var midangle = value.startAngle + (value.endAngle - value.startAngle) / 2;
    return midangle < Math.PI ? 'start' : 'end';
  }

  lableName(value) {
    let lableName = ['Achieved', 'Not Achieved'];
    return lableName[value.index];
  }

  //function to handle the arc click
  donutPopUp(d, flag) {
    switch (d.index) {
      case 0:
        if (flag.isAchievedFlag === null) {
          this.setState({
            isAchievedFlag: !this.state.isAchievedFlag,
            isHovered: false
          });
          this.props.achieved_target_data();
        }
        if (flag.isAchievedFlag === true) {
          this.setState({
            isAchievedFlag: !this.state.isAchievedFlag,
            isHovered: false
          });
          this.props.default_target_data();
        }
        break;
      case 1:
        if (flag.isNotAchievedFlag === null) {
          this.setState({
            isHovered: !this.state.isHovered,
            isAchievedFlag: false
          });
          this.props.not_achieved_target_data();
        }
        if (flag.isNotAchievedFlag === true) {
          this.setState({
            isHovered: !this.state.isHovered,
            isAchievedFlag: false
          });
          this.props.default_target_data();
        }
        break;
    }
  }

  render() {
    let {
      value,
      label,
      innerRadius = 0,
      outerRadius,
      cornerRadius,
      padAngle,
      flag
    } = this.props;

    let hover = false;

    if (this.state.isHovered) {
      outerRadius *= 1.05;
      innerRadius *= 0.9;
      padAngle *= -1;
      hover = true;
    }

    if (this.state.isAchievedFlag) {
      outerRadius *= 1.05;
      innerRadius *= 0.9;
      padAngle *= -1;
      hover = true;
    }

    let arc = d3
      .arc()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius)
      .cornerRadius(cornerRadius)
      .padAngle(padAngle);

    let outerArc = d3
      .arc()
      .innerRadius(innerRadius * 1.5) //1.5
      .outerRadius(outerRadius * 1.5); //1.5
    return (
      <g
        className={hover ? 'cursor-pointer' : ''}
        onMouseOver={this.onMouseOver}
        onMouseOut={this.onMouseOut}
        {...this.props}
        onClick={() => this.donutPopUp(value, flag)}
      >
        <path d={arc(value)} fill={this.color(value)} />
        {value.data !== 0 || hover ? (
          <polyline
            stroke={hover ? '#00539b' : '#606060'}
            // stroke={this.strokeColor(value)}
            fill="none"
            strokeWidth="1px"
            points={this.arcPoint(arc, outerArc, value)}
          />
        ) : (
          ''
        )}

        {value.data !== 0 && hover ? (
          <circle
            transform={`translate(${arc.centroid(value)})`}
            r="4"
            cx="0"
            cy="0"
            fill="#00539b"
          />
        ) : (
          ''
        )}
        <text
          font-family="Questrial"
          transform={this.textPosition(outerArc, value)}
          dy="-.25em"
          textAnchor={this.textAlignment(value)}
          fill={hover ? '#00539b' : 'black'}
          font-size={'14px'}
        >
          {value.data != 0 ? label + '%' : ''}
        </text>
        <text
          font-family="Questrial"
          transform={this.lableNamePosition(outerArc, value)}
          dy="1em"
          textAnchor={this.textAlignment(value)}
          fill={hover ? '#00539b' : '#3333333'}
          font-size={'14px'}
        >
          {value.data != 0 ? this.lableName(value) : ''}
        </text>
      </g>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { achieved_target_data, not_achieved_target_data, default_target_data }
)(PieChart);
