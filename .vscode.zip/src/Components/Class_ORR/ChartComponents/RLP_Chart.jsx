import React, { PureComponent } from "react";
import { connect } from "react-redux";
import { formatDate } from "../../../Utils/globalVars";
import {
  READING_LEVEL_GRID_DATA,
  RLP_DONUT_TARGET_DATA,
  CLASS_READING_LEVEL_PROGRESS,
  RETAIN_BUBBLE_COLOR,
  CLEAR_BUBBLE_COLOR,
  SIDE_PANEL_SPINNER,
  CHART_SPINNER,
  Update_Scroll_Data,
  SORT_RLP_GRID_COLUMN,
  updateDropDownData,
  updateAllMonth,
  toggleDropDown,
  updateChartDetails,
  CLRLP_CSVDATA_DOWNLOAD_APICALL,
  CLRLP_CSVDATA_DOWNLOAD_RESET
} from "../../../Redux_Actions/C_ReadingLevelAction.jsx";
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import titleImg from "../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg";
import {
  SHOW_HIDE_GROUPING,
  SAVE_GROUPING_DATA
} from "../../../Redux_Actions/C_GroupingAction.jsx";
import RlpGrid from "./RLP_Grid.jsx";
import NoRosterData from "../../../Utils/NoRoster.js";
import Class_RLP from "./Class_RLP.jsx";
import Filter from "../../ORR/FilterComponents/Filter";
import "./Class_RLP.css";
import Spinner from "../../ReusableComponents/Spinner/Spinner.jsx";
import TimeOut from "../../ReusableComponents/Spinner/TimeOut.jsx";
import ChartNotLoad from "../../../Utils/Chart_Not_Load";
import NoRecordsData from "../../../Utils/No_Data_Found";
import Group from "../Grouping_ORR/C_Grouping.jsx";
import PrintCRlp from '../../ReusableComponents/PrintOrrCharts/C_RlpPrint.jsx';
import { GetCompleteStudentReport } from '../../../Redux_Actions/UniversalSelectorActions';
import {
  Chart_Enabled
} from '../../../Redux_Actions/S_ReadingLevelAction.jsx';


export class RlpChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      timeOut: false
    };
    this.constructedSidePanelFilter = {};
    this.readingTargetValue = "";
    this.timeOut = this.timeOut.bind(this);
    this.bubblesSelected = this.bubblesSelected.bind(this);
    this.getClassReadingLevelProgressChartAPI = this.getClassReadingLevelProgressChartAPI.bind(
      this
    );
    this.toggleHidden = this.toggleHidden.bind(this);
    this.reLoadChartData = this.reLoadChartData.bind(this);
  }

  componentDidMount() {
    this.props.CHART_SPINNER();
    if (this.props.ContextHeader.Roster_Tab.SelectedClass.id) {
      this.getClassReadingLevelProgressChartAPI();
    }
  }


  donutApi() {
    let payLoadData = {
      ...getCommonHeaders(this.props, 'class'),
      // classId: this.props.ContextHeader.Roster_Tab.SelectedClass.id,
      // grade: this.props.ContextHeader.Roster_Tab.selectedRosterGrade,
      // // endDate: "01/01/2025",
      // // startDate: "01/01/2018",
      // endDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termEndDate ?
      //   this.props.ContextHeader.Date_Tab.Report_termEndDate :
      //   this.props.ContextHeader.Date_Tab.selectedterm_Obj.termEndDate),
      // startDate: formatDate(this.props.ContextHeader.Date_Tab.Report_termStartDate ?
      //   this.props.ContextHeader.Date_Tab.Report_termStartDate :
      //   this.props.ContextHeader.Date_Tab.selectedterm_Obj.termStartDate),
      readingLevel: this.readingTargetValue
    };
    this.props.RLP_DONUT_TARGET_DATA(
      this.props.LoginDetails.JWTToken,
      payLoadData
    );
  }
  getClassReadingLevelProgressChartAPI() {
    this.setState({
      ...this.state,
      timeOut: false
    });
    if (this.props) {
      let data = { ...getCommonHeaders(this.props, 'class') }
      this.props.CLASS_READING_LEVEL_PROGRESS(
        this.props.LoginDetails.JWTToken,
        data
      );
    }
  }

  navigateToStudentOrr(selectedStudent) {
    this.props.Chart_Enabled({
      showFluency: false,
      showAccuracy: false
    });
    this.props.GetCompleteStudentReport(selectedStudent, "", {}, this.props.ContextHeader.presentDataForStudentId)
  }
  //Side panel Grid API for Class RLP
  gridApi() {
    let data = {
      ...getCommonHeaders(this.props, 'class'),
      sidePanelFilter: this.constructedSidePanelFilter
    };
    this.props.READING_LEVEL_GRID_DATA(this.props.LoginDetails.JWTToken, data);
    this.props.SIDE_PANEL_SPINNER();
  }

  bubblesSelected(bubs) {
    if (bubs.length !== 0) {
      this.readingTargetValue = "";
      var readingLevelList = [];
      for (let i of bubs) {
        readingLevelList.push({
          proficiencyType: i.type,
          readingLevel: i.readingLevel
        });
      }
      this.constructedSidePanelFilter = {
        monthYear: bubs[0].monthYear,
        // monthYear: '09/2018',
        readingLevelList: readingLevelList
      };
      this.gridApi();
    }
    if (bubs && bubs.length > 0) {
      this.props.RETAIN_BUBBLE_COLOR({
        [bubs[0]["month"]]: bubs
      });
    } else {
      this.props.RETAIN_BUBBLE_COLOR({});
    }
  }
  bubblesSelectedForReadingTarget(bubs) {
    this.readingTargetValue = bubs.readingLevel;
    this.donutApi();
    // this.props.RETAIN_BUBBLE_COLOR();
  }
  // handle timeout
  timeOut() {
    this.setState({ ...this.state, timeOut: true });
  }
  // toggle grouping
  toggleHidden(flag) {
    this.props.SHOW_HIDE_GROUPING(flag);
  }
  clearBubbleSelection() {
    this.props.CLEAR_BUBBLE_COLOR(null);
  }

  reLoadChartData() {
    this.setState({
      ...this.state,
      timeOut: false
    });
    this.props.CHART_SPINNER();
    this.getClassReadingLevelProgressChartAPI();

  }
  // EXPAND AND COLLAPSE DATA UPDATE
  updateExpandCollapseData(dropDownSelection) {
    Promise.resolve(this.props.updateChartDetails(dropDownSelection)).then((response) => {
      let filterDataTypes = ['frustrationalRecordData', 'independentRecordData', 'instructionalRecordData']
      let dataListForGrid = {}
      const prop = this.props;
      const resp = this.props.Class_RLP_Object;
      const selectedMonths = dropDownSelection.filter((obj) => { return obj.checked });
      const selectedMonth = resp.monthlyRecordData[selectedMonths.length - 1];
      const recordType = selectedMonth['recentRecord'] ? 'recentRecord' : selectedMonth['firstRecord'] ? 'firstRecord' : '';

      dataListForGrid[selectedMonth['month']] = []
      filterDataTypes.forEach(filterType => {
        let tempName;

        if (filterType == "frustrationalRecordData") {
          tempName = "Frustrational";
        } else if (filterType == "independentRecordData") {
          tempName = "Independent";
        } else if (filterType == "instructionalRecordData") {
          tempName = "Instructional";
        }

        const bubList = Object.keys(selectedMonth[filterType]);

        if (bubList && bubList.length > 0) {
          bubList.forEach((readingLevel) => {
            dataListForGrid[selectedMonth['month']].push({
              month: selectedMonth['month'],
              monthYear: selectedMonth['monthYear'],
              readingLevel: readingLevel,
              [recordType]: true,
              type: tempName
            })
          })
        }
      })

      this.bubblesSelected(dataListForGrid[selectedMonth['month']]);
    });

  }
  // Download csv data
  downLoadCSVData() {
    this.props.CLRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = {
      classChartType: {
        "allRecordsAvgFlag": 0,
        "chartName": "CRLP"
      },
      ...getCommonHeaders(this.props, 'class')
    };
    this.props.CLRLP_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    if (this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] && this.props.ClassCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.CLRLP_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedClass.name;
    return (
      <div>
        {this.props.NavigationByHeaderSelection.class &&
          this.props.ContextHeader.Roster_Tab.SelectedClass.id ? (
            <div>
              <Filter
                sidePanelData={this.props.RlpGridData.RlpData}
              />
              {this.props.isApiLoading && !this.state.timeOut && (
                <Spinner
                  startSpinner={this.props.isApiLoading}
                  showTimeOut={this.timeOut}
                />
              )}
              {this.state.timeOut && (
                <TimeOut tryAgain={this.reLoadChartData} />
              )}
              {this.props.apiLoadFail &&
                this.props.Class_RLP_Object == "" &&
                !this.props.Class_RLP_Object &&
                !this.props.isApiLoading && (
                  <NoRecordsData NodataFound={"dataNotAvail"} />
                )}

              {this.props.apiLoadFail &&
                this.props.Class_RLP_Object !== "" &&
                !this.props.Class_RLP_Object &&
                !this.props.isApiLoading && (
                  <ChartNotLoad
                    tryAgain={this.reLoadChartData}
                  />
                )}
              {!this.props.isApiLoading &&
                this.props.Class_RLP_Object &&
                !this.props.apiLoadFail && (
                  <main>
                    <section>
                      <div className="container container-resolution sum-modal-crlp">
                        <div className="row mt-10 mt-7" id="testClass">
                          {this.props.ClassCsvDownload && this.props.ClassCsvDownload['csvData'] &&
                            <CSVLink
                              ref="groupCSV"
                              headers={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['header']}
                              data={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['data']}
                              style={{ display: 'none' }}
                              // filename={"CLRLP_CSV.csv"} 
                              filename={`${csvFileName}.csv`}
                            />}
                          <div className="cls-csv-icon-alignment" onClick={() => !this.props.ClassCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                            {this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] ?
                              <span className="csv_download_icon">
                                <i className="material-icons">autorenew</i>
                              </span> :
                              <span className="csv_download_icon">
                                <img src={CsvIcon} width="20" height="20" />
                              </span>}
                          </div>
                          {this.props.Class_RLP_Object && (
                            <React.Fragment>
                              <Class_RLP
                                updateChartDetails={(dropDownSelection) => this.updateExpandCollapseData(dropDownSelection)}
                                toggleDropDown={(data) => this.props.toggleDropDown(data)}
                                updateAllMonth={(data) => this.props.updateAllMonth(data)}
                                updateDropDownDetails={(data) => this.props.updateDropDownData(data)}
                                monthRangeObj={this.props.monthRangeObj}
                                selAll={this.props.selAll}
                                selectedProficiency={this.props.CommonFilterData}
                                toggleData={this.props.toggleData}
                                updateScrollData={data => {
                                  this.props.Update_Scroll_Data(data);
                                }}
                                class_rlp_object={this.props.Class_RLP_Object}
                                bubblesSelected={bubs => {
                                  this.bubblesSelected(bubs);
                                }}
                                clearBubbles={() => {
                                  //this.clearBubbleSelection();
                                }}
                                bubblesSelectedForReadingTarget={bubs => {
                                  this.bubblesSelectedForReadingTarget(bubs);
                                }}
                                // getBubbleBackgroundColorOnSelection= {this.props.RETAIN_BUBBLE_COLOR()}
                                selectedBubs={this.props.selectedBubbles}
                              />
                            </React.Fragment>
                          )}
                          {this.props.Class_RLP_Object && (
                            <RlpGrid
                              scrollFlag={false}
                              gridData={this.props.RlpGridData.RlpData}
                              Data={this.props.SortData}
                              gridFilterData={
                                this.props.RlpGridData.GridFilterData
                              }
                              rosterCount={this.props.RlpGridData.RosterCount}
                              PieChartData={this.props.PieChartData}
                              DonutFlag={this.props.DonutFlag}
                              gridHeaderData={
                                this.props.Class_RLP_Object.readingTarget
                              }
                              gridTitle={this.props.selectedBubbles}
                              sidePanelLoad={this.props.sidePanelLoad}
                              sidePanelApiFail={this.props.sidePanelApiFail}
                              routeToStudent={(student) => { this.navigateToStudentOrr(student) }}
                            />
                          )}

                          {this.props.showGrouping &&
                            !this.props.sidePanelLoad && (
                              <Group
                                cancelModal={(flag) => this.toggleHidden(flag)}
                                showGrouping={this.props.showGrouping}
                                gridData={this.props.RlpGridData.RlpData}
                                Data={this.props.SortData}
                              />
                            )}
                        </div>
                        {this.props.Class_RLP_Object && this.props.RlpGridData.RlpData && (
                          <span className="class-rlp-print-btn r-67">
                            <PrintCRlp
                              monthRangeObj={this.props.monthRangeObj}
                              selAll={this.props.selAll}
                              toggleData={this.props.toggleData}
                              selectedFilter={this.props.CommonFilterData}
                              studentDetails={this.props.ContextHeader}
                              navSelected={this.props.NavigationByHeaderSelection}
                              Class_RLP_Object={this.props.Class_RLP_Object}
                              selectedBubs={this.props.selectedBubbles}
                              gridData={this.props.RlpGridData.RlpData}
                              Data={this.props.SortData}
                              gridFilterData={
                                this.props.RlpGridData.GridFilterData
                              }
                              rosterCount={this.props.RlpGridData.RosterCount}
                              PieChartData={this.props.PieChartData}
                              DonutFlag={this.props.DonutFlag}
                              gridHeaderData={
                                this.props.Class_RLP_Object.readingTarget
                              }
                              gridTitle={this.props.selectedBubbles}
                            />
                          </span>
                        )}
                        {this.props.NavigationByHeaderSelection.class && !this.props.hideCreateGroup &&
                          !this.props.NavigationByHeaderSelection.readingHistory && !this.props.NavigationByHeaderSelection.Summary_Tab ? (
                            <div className="group-title crlp-cg-txt-pos" onClick={() => this.toggleHidden(true)}>
                              <img src={titleImg} className="pull-left mlr-9" />
                              <span>
                                <b>Create Groups</b>
                              </span>
                            </div>
                          ) : (
                            ""
                          )}
                      </div>
                    </section>
                  </main>
                )}
            </div>
          ) : (
            <NoRosterData />
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  CommonFilterDetails,
  ClassGridRlpData,
  Authentication,
  C_GroupingReducer
}) => {
  const {
    sidePanelApiFail,
    Class_RLP_Object,
    isApiLoading,
    sidePanelLoad,
    apiLoadFail,
    selectedBubbles,
    RlpGridData,
    SortData,
    PieChartData,
    DonutFlag,
    bubblesSelected,
    bubblesSelectedForReadingTarget,
    getClassReadingLevelProgressChartAPI,
    hideCreateGroup,
    monthRangeObj,
    selAll,
    toggleData,
    ClassCsvDownload
  } = ClassGridRlpData;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const { CommonFilterData } = CommonFilterDetails;
  const { LoginDetails } = Authentication;
  const { showGrouping } = C_GroupingReducer;
  return {
    sidePanelApiFail,
    Class_RLP_Object,
    isApiLoading,
    apiLoadFail,
    selectedBubbles,
    RlpGridData,
    SortData,
    ContextHeader,
    NavigationByHeaderSelection,
    CommonFilterData,
    PieChartData,
    DonutFlag,
    bubblesSelected,
    bubblesSelectedForReadingTarget,
    getClassReadingLevelProgressChartAPI,
    LoginDetails,
    showGrouping,
    sidePanelLoad,
    hideCreateGroup,
    monthRangeObj,
    selAll,
    toggleData,
    ClassCsvDownload
  };
};

export default connect(mapStateToProps, {
  READING_LEVEL_GRID_DATA,
  GetCompleteStudentReport,
  Chart_Enabled,
  RETAIN_BUBBLE_COLOR,
  RLP_DONUT_TARGET_DATA,
  CLASS_READING_LEVEL_PROGRESS,
  Update_Scroll_Data,
  SHOW_HIDE_GROUPING,
  SAVE_GROUPING_DATA,
  SORT_RLP_GRID_COLUMN,
  CLEAR_BUBBLE_COLOR,
  SIDE_PANEL_SPINNER,
  CHART_SPINNER,
  updateDropDownData,
  updateAllMonth,
  toggleDropDown,
  updateChartDetails,
  CLRLP_CSVDATA_DOWNLOAD_APICALL,
  CLRLP_CSVDATA_DOWNLOAD_RESET
})(RlpChart);
