import React, { PureComponent } from 'react';
import * as d3 from 'd3';
import PieChart from './c_Piechart.jsx';

class DonutChart extends PureComponent {
  constructor(props) {
    super(props);
    this.renderSlice = this.renderSlice.bind(this);
  }

  render() {
    const average = this.props.data;
    const targetLabel = [
      average.chartData.achievedTargetValue,
      average.chartData.notAchievedValue
    ];
    // average.chartData.achievedTargetValue, average.chartData.notAchievedValue
    let width = 400;
    let height = 148;
    let x = width / 2;
    let y = height / 2;
    let pie = d3.pie().sort(null);

    return (
      <div className="donut-chart-wrap">
        {this.props.data.chartData.achievedTargetValue !== '' && (
          <svg width="500" height="150">
            <g transform={`translate(${x}, ${y})`}>
              {pie(targetLabel).map(this.renderSlice)}
            </g>
          </svg>
        )}
      </div>
    );
  }

  renderSlice(value, i) {
    let radius = 50;

    return (
      <PieChart
        key={i}
        innerRadius={radius * 0.55}
        outerRadius={radius}
        cornerRadius={0}
        padAngle={0.01}
        value={value}
        label={value.data}
        flag={this.props.setFlag}
      />
    );
  }
}

export default DonutChart;
