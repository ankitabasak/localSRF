import React, { PureComponent } from "react";
import spinner from "../../../../public/assets/orr/rlp-screen/loader-white-bg.gif";
import {
  SORT_RLP_GRID_COLUMN,
  SORT_C_RLP_DATA
} from "../../../Redux_Actions/C_ReadingLevelAction.jsx";

import {
  navigateToStudentReportFromClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import { connect } from "react-redux";
import { dataSorting } from "../../ReusableComponents/OrrReusableComponents";
import "../../ORR/ReadingHistoryComponents/ReadingHistory.css";
import DonutChart from "./c_targetPieChart.jsx";
import ClassSidePanelPrint from '../../ReusableComponents/PrintOrrCharts/Class_SidePanel.jsx'
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';

export class RlpGrid extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      gridHeaderData: this.props.gridHeaderData
    };

    this.rlpGrid = this.rlpGrid.bind(this);
    this.sortData = this.sortData.bind(this);
    // this.naviGateToStudent = this.naviGateToStudent.bind(this);
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? " border-btm"
      : "";
  }

  // tooltip for long text
  longTextTooltip(text) {
    if (text.length > 14) {
      return (
        <React.Fragment>
          {text.substr(0, 14)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }

  returnBasedOnStudentName(Data, gridArray) {
    return (
      <div className="student-column-list-rhs-sec">
        <span
          className={this.LineUnderActiveColumnFiled(
            Data,
            "lastName",
            Data.sortType
          )}
        >
          Students ({gridArray.length})
        </span>
        <span className="togglers">
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "lastName" && Data.sortType === "desc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("lastName", "desc", gridArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "lastName" && Data.sortType === "asc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("lastName", "asc", gridArray)}
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  returnBasedOnLevel(Data, gridArray) {
    return (
      <div className="student-column-list-rhs-sec">
        <span
          className={this.LineUnderActiveColumnFiled(
            Data,
            "letterLevel",
            Data.sortType
          )}
        >
          Level
        </span>
        <span className="togglers">
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "letterLevel" && Data.sortType === "desc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("letterLevel", "desc", gridArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "letterLevel" && Data.sortType === "asc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("letterLevel", "asc", gridArray)}
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  returnBasedOnProficiency(Data, gridArray) {
    return (
      <div className="student-column-list-rhs-sec">
        <span
          className={this.LineUnderActiveColumnFiled(
            Data,
            "proficiency",
            Data.sortType
          )}
        >
          Proficiency
        </span>
        <span className="togglers">
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "proficiency" && Data.sortType === "desc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("proficiency", "desc", gridArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "proficiency" && Data.sortType === "asc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("proficiency", "asc", gridArray)}
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  returnBasedOnDate(Data, gridArray) {
    return (
      <div className="student-column-list-rhs-sec">
        <span
          className={this.LineUnderActiveColumnFiled(
            Data,
            "assignmentDate",
            Data.sortType
          )}
        >
          Date
        </span>
        <span className="togglers">
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "assignmentDate" && Data.sortType === "desc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("assignmentDate", "desc", gridArray)}
          >
            expand_more
          </i>
          <i
            style={{ cursor: "pointer" }}
            className={
              Data.sortColumn === "assignmentDate" && Data.sortType === "asc"
                ? "material-icons blueColor"
                : "material-icons"
            }
            onClick={() => this.rlpGrid("assignmentDate", "asc", gridArray)}
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //Onclick calling sort function and update the sort type and column in store
  rlpGrid(sortColumn, sortType, actualArray) {
    document.getElementById("crlp").scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_RLP_GRID_COLUMN(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);
      this.props.SORT_C_RLP_DATA(sortedArray, column, sortType);
    }
  }

  classRlpGridData(Data, gridArray) {
    return (
      <div>
        <div className="student-list-header-rhs-sec rho-header-rhs-sec ">
          {this.returnBasedOnStudentName(Data, gridArray)}
          {this.returnBasedOnLevel(Data, gridArray)}
          {this.returnBasedOnProficiency(Data, gridArray)}
          {this.returnBasedOnDate(Data, gridArray)}
        </div>
        <div className={"student-list-body " + (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "scroll-body")} id="crlp">
          {gridArray.map((gridDetails, value) => (
            <div className="pos-rel student-list-row-rhs-sec" key={value} onClick={() => { this.props.routeToStudent({ id: gridDetails.studentId, name: gridDetails.firstName + gridDetails.lastName }) }}>
              <div className="student-column-list-rhs-sec cursor-pointer" onClick={() => {
                this.props.navigateToStudentReportFromClassReport(gridDetails, false);
              }}>
                <span className="wb-break-all long-text-tooltip">
                  {this.longTextTooltip(gridDetails.firstName + ' ' + gridDetails.lastName)}
                </span>
              </div>
              <div className="student-column-list-rhs-sec">
                <span>{gridDetails.letterLevel}</span>
              </div>
              <div className="student-column-list-rhs-sec">
                <span>{gridDetails.proficiency}</span>
              </div>
              <div className="student-column-list-rhs-sec">
                <span>{gridDetails.assignmentDate}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  //to dispaly header section of grid part
  gridHeaderData(headerData) {
    let rlpLevel = [];
    let proficiencyType = [];
    let levelObject = new Set();
    let typeObject = new Set();

    headerData && headerData.map(
      (headerDetails, value) => (
        levelObject.add(headerDetails.readingLevel),
        typeObject.add(headerDetails.proficiencyType)
      )
    );

    rlpLevel = this.displayHeader(Array.from(levelObject).sort());
    proficiencyType = this.displayHeader(Array.from(typeObject));

    return (
      <div>
        <div className="reading-level-label mb-8 color-1">
          Reading Level: <span>{rlpLevel}</span>
        </div>
        <div className="reading-level-label color-2">
          Proficiency: <span>{proficiencyType}</span>
        </div>
        {this.props.PieChartData && (
          <DonutChart
            data={this.props.PieChartData}
            setFlag={this.props.DonutFlag}
          />
        )}
      </div>
    );
  }

  //to display header data properly
  displayHeader(dataArray) {
    let array = [];
    dataArray
      // .reverse()
      .map((level, value) =>
        value < dataArray.length - 1
          ? array.push(level + ", ")
          : array.push(level + "")
      );
    return array;
  }
  render() {
    let classDataArray = this.props.gridData;
    let gridHeaderData = this.props.gridFilterData;
    let bubsList = this.props.gridTitle &&
      this.props.gridTitle[Object.keys(this.props.gridTitle)[0]];
    let Data = this.props.Data;
    return (
      <div className="col-lg-4 res-width class-rlp-rhs-chart classRlp-rhs-wrap" >
        {/* onclick and on load main api should send the Reading target */}
        {bubsList && bubsList.length > 0 ? (
          <div><React.Fragment>
            {this.props.sidePanelLoad && (
              <div className="col-md-4 res-width display-msg err-msg-alignment top-pos-100">
                <img src={spinner} alt="spinner" />
              </div>
            )}
          </React.Fragment>
            <React.Fragment>
              {!this.props.sidePanelLoad && (
                <div>
                  <div className="pull-left rt-left-heading">
                    {bubsList
                      ? bubsList[0].recentRecord
                        ? "Recent Record:" +
                        " " +
                        " " +
                        bubsList[0].month +
                        "," +
                        " " +
                        bubsList[0].monthYear.split("/")[1]
                        : bubsList[0].firstRecord
                          ? "First Record:" +
                          " " +
                          bubsList[0].month +
                          "," +
                          " " +
                          bubsList[0].monthYear.split("/")[1]
                          : bubsList[0].month +
                          "," +
                          " " +
                          bubsList[0].monthYear.split("/")[1]
                      : "Record Target"}
                  </div>
                  <div class="pos-rel"><div class="rt-rhs-strip"></div><hr class="clearfix mb-8 cRlp-mb8-14-20"></hr></div>
                  <div className="print-clear">{this.gridHeaderData(gridHeaderData)}</div>
                  <div className="pull-right clearfix new-mb-4 rt-label-txt cRlp-rostered-txt-14-20">
                    <span className="rt-label">
                      No. of students rostered: {this.props.rosterCount}
                    </span>
                  </div>
                  {this.props.scrollFlag && !this.props.sidePanelLoad && classDataArray &&
                    <ClassSidePanelPrint
                      Data={Data}
                      sideTableData={classDataArray}
                      chartName={"cRlp"}
                    />}
                  {!this.props.scrollFlag &&
                    <div className="rhs-wrap crlp-rhs class-rhs-chart cRlp-rhs-21-20">
                      <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                        <div className="student-list-table-main">
                          <div className="student-list-table-rhs-sec">
                            {classDataArray ? this.classRlpGridData(Data, classDataArray) : ''}
                          </div>
                        </div>
                      </div>
                    </div>
                  }
                </div>
              )}
            </React.Fragment></div>
        ) : (
          <MakeSelectionForORR />
        )}
      </div>
    );
  }
}
const mapStateToProps = () => {
  return {};
};

export default connect(mapStateToProps, {
  SORT_RLP_GRID_COLUMN,
  SORT_C_RLP_DATA,
  navigateToStudentReportFromClassReport

})(RlpGrid);