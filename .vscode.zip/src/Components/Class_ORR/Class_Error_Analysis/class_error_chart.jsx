import React, { PureComponent } from "react";
import Filter from "../../ORR/FilterComponents/Filter";
import ClassErrorAnalysisChart from "./class-error-analysis-chart.jsx";
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  CLASS_EA_API,
  LOAD_STATUS_ICON,
  Chart_loading_Failed,
  Class_EA_Grid_Table,
  CEA_CSVDATA_DOWNLOAD_APICALL,
  CEA_CSVDATA_DOWNLOAD_RESET
} from "../../../Redux_Actions/C_ErrorAnalysisAction.jsx";
import { SHOW_HIDE_GROUPING } from "../../../Redux_Actions/C_GroupingAction.jsx";
import { connect } from "react-redux";
import Ea_Table from "./class-error-grid.jsx";
import NoRosterData from "../../../Utils/NoRoster.js";
import Spinner from "../../ReusableComponents/Spinner/Spinner.jsx";
import TimeOut from "../../ReusableComponents/Spinner/TimeOut.jsx";
import ChartNotLoad from "../../../Utils/Chart_Not_Load";
import NoRecordsData from "../../../Utils/No_Data_Found";
import Group from '../Grouping_ORR/C_Grouping.jsx';
import PrintCEa from '../../ReusableComponents/PrintOrrCharts/C_EaPrint.jsx';
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';
import titleImg from "../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg";
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';

class C_ErrorChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {},
      errorRecordType: {},
      timeOut: false,
      defaultFilterRecType: {
        allRecords: false,
        recentRecord: true
      }
    };
    this.timeOut = this.timeOut.bind(this);
    this.toggleHidden = this.toggleHidden.bind(this);
  }

  componentDidMount() {
    this.callErrorAnalysisApi("rec");
  }

  // handle timeout
  timeOut() {
    this.props.Chart_loading_Failed({
      isDataAvailable: false,
      isApiLoading: false,
      timeOut: true,
      apiLoadFail: false
    });
  }
  // toggle grouping
  toggleHidden(flag) {
    this.props.SHOW_HIDE_GROUPING(flag);
  }

  // Download csv data
  downLoadCSVData() {
    this.props.CEA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = {
      classChartType: {
        "allRecordsAvgFlag": this.props.showRecord === 'rec' ? '2' :
          this.props.showRecord === 'all' ? '1' : '',
        "chartName": "CEA"
      },
      ...getCommonHeaders(this.props, 'class')
    };
    this.props.CEA_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  //make api call
  callErrorAnalysisApi(type) {
    this.props.LOAD_STATUS_ICON();
    let Token = this.props.LoginDetails.JWTToken;
    this.setState({
      ...this.state,
      timeOut: false
    });

    if (this.props.ContextHeader.Roster_Tab.SelectedClass.id) {
      let errorRecordType = {
        allRecords: type === "all" ? true : false,
        recentRecord: type === "rec" ? true : false
      };
      this.setState({
        errorRecordType: errorRecordType
      });

      let Req_Payload = {
        errorRecordType,
        ...getCommonHeaders(this.props, 'class'),
        value: "class"
      };
      this.props.CLASS_EA_API(Token, Req_Payload);
    }
  }

  render() {
    let classObject = this.props.ContextHeader &&
      this.props.ContextHeader.Roster_Tab.SelectedClass;
    let selErrors = {};
    if (this.props.SelectedErr && Object.keys(this.props.SelectedErr).length > 0) {
      selErrors = (
        this.props.SelectedErr['recentRecord'] ||
        this.props.SelectedErr['firstRecord'] ||
        this.props.SelectedErr['allRecordsAverage']
      );
    }
    let loggedInUserName = '';
    let selectedClass = '';
    if (this.props.ContextHeader) {
      loggedInUserName = this.props.ContextHeader.loggedInUserName;
      selectedClass  = this.props.ContextHeader.Roster_Tab.SelectedClass.name;
    }

    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + loggedInUserName + " for " + selectedClass;
    if (this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] && this.props.ClassCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.CEA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)
    }
    return (
      <div>
        {this.props.NavigationByHeaderSelection && this.props.NavigationByHeaderSelection.class && classObject.id ? (
          <div>
            <Filter
              errorRecordType={this.props.showRecord}
              sidePanelData={this.props.sideTableData}
            />
            {this.props.firstRecordObj && (
              <React.Fragment>
                <div className="container container-resolution cfa">
                  <div className="row" id="testClass">
                    {this.props.ClassCsvDownload && this.props.ClassCsvDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['header']}
                        data={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        // filename={"CEA_CSV.csv"}
                        filename={`${csvFileName}.csv`}
                      />}
                    <div className="cls-csv-icon-alignment" onClick={() => !this.props.ClassCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                      {this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <ClassErrorAnalysisChart
                      firstRecord={this.props.firstRecordObj}
                      allRecord={this.props.allRecordObj}
                      recentRecord={this.props.recentRecordObj}
                      makeApiCall={x => this.callErrorAnalysisApi(x)}
                      errorRange={this.props.errorRange}
                      msvErrorRange={this.props.msvErrorRange}
                      showHideRecentRecord={this.props.showHideRecentRecord}
                      SelectedErr={this.props.SelectedErr}
                      CommonFilterData={this.props.CommonFilterData}
                      showRecord={this.props.showRecord}
                      token={this.props.LoginDetails.JWTToken}
                      disableDiv={this.props.disableDiv}
                      isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                      classId={this.props.ContextHeader.Roster_Tab.SelectedClass.id.toString()}
                      grade={this.props.ContextHeader.Roster_Tab.selectedRosterGrade}
                      ContextHeader={this.props.ContextHeader}
                    />
                    {Object.keys(selErrors).length > 0 && <Ea_Table
                      scrollFlag={false}
                      sideTableData={this.props.sideTableData}
                      Data={this.props.SortData}
                      disableDiv={this.props.disableDiv}
                      showSpinner={this.props.showSpinner}
                    />}
                    {
                      this.props.showSpinner && <div className="col-md-4 res-width display-msg err-msg-alignment">
                        <img src={spinner} alt="spinner" />
                      </div>
                    }

                    {this.props.showGrouping && this.props.sideTableData && (
                      <Group
                        cancelModal={this.toggleHidden}
                        showGrouping={this.props.showGrouping}
                        gridData={this.props.sideTableData.tableData}
                        Data={this.props.SortData}
                      />
                    )}
                    {this.props.NavigationByHeaderSelection.class && !this.props.hideCreateGroup &&
                      !this.props.NavigationByHeaderSelection.readingHistory ? (
                        <div className="group-title crlp-cg-txt-pos" onClick={() => this.toggleHidden(true)}>
                          <img src={titleImg} className="pull-left mlr-9" />
                          <span>
                            <b>Create Groups</b>
                          </span>
                        </div>
                      ) : (
                        ""
                      )}
                    {Object.keys(selErrors).length === 0 && (
                      <div class="col-md-4 res-width cea-rhs-rel mt-6 cea-dup-scea">
                        <MakeSelectionForORR />
                      </div>
                    )}
                  </div>
                </div>

                <span className="class-ea-print-btn">
                  <PrintCEa
                    scrollFlag={false}
                    selectedFilter={this.props.CommonFilterData}
                    studentDetails={this.props.ContextHeader}
                    navSelected={this.props.NavigationByHeaderSelection}
                    firstRecord={this.props.firstRecordObj}
                    allRecord={this.props.allRecordObj}
                    recentRecord={this.props.recentRecordObj}
                    errorRange={this.props.errorRange}
                    msvErrorRange={this.props.msvErrorRange}
                    showHideRecentRecord={this.props.showHideRecentRecord}
                    SelectedErr={this.props.SelectedErr}
                    internalFilter={this.props.CommonFilterData}
                    showRecord={this.props.showRecord}
                    token={this.props.LoginDetails.JWTToken}
                    sideTableData={this.props.sideTableData}
                    Data={this.props.SortData}
                    disableDiv={this.props.disableDiv}
                    isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                  />
                </span>

              </React.Fragment>)}
            {!this.props.firstRecordObj &&
              !this.props.timeOut &&
              this.props.ErrorCode !== 500 && !this.props.noDataAvail && (
                <Spinner
                  startSpinner={!this.props.firstRecordObj}
                  showTimeOut={this.timeOut}
                />
              )}
            {!this.props.firstRecordObj && this.props.timeOut && !this.props.noDataAvail && (
              <TimeOut
                tryAgain={() => this.callErrorAnalysisApi(this.props.showRecord)}
              />
            )}
            {!this.props.firstRecordObj && this.props.ErrorCode === 500 && !this.props.noDataAvail && (
              <ChartNotLoad
                tryAgain={() => this.callErrorAnalysisApi(this.props.showRecord)}
              />
            )}
            {(this.props.noDataAvail) && (
              <NoRecordsData NodataFound={"dataNotAvail"} />
            )}
          </div>
        ) : (
            <NoRosterData />
          )
        }
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  CommonFilterDetails,
  ClassEaData,
  C_GroupingReducer
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const {
    firstRecordObj,
    allRecordObj,
    recentRecordObj,
    sideTableData,
    errorRange,
    msvErrorRange,
    SortData,
    showHideRecentRecord,
    SelectedErr,
    ErrorCode,
    apiLoadFail,
    isDataAvailable,
    showRecord,
    disableDiv,
    timeOut,
    showSpinner,
    noDataAvail,
    errRes,
    hideCreateGroup,
    isAllThreeMsvValuesNull,
    ClassCsvDownload
  } = ClassEaData;
  const { CommonFilterData } = CommonFilterDetails;
  const { showGrouping } = C_GroupingReducer;
  return {
    showSpinner,
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    CommonFilterData,
    firstRecordObj,
    allRecordObj,
    recentRecordObj,
    sideTableData,
    errorRange,
    msvErrorRange,
    SortData,
    showHideRecentRecord,
    SelectedErr,
    ErrorCode,
    apiLoadFail,
    isDataAvailable,
    showRecord,
    showGrouping,
    disableDiv,
    timeOut,
    noDataAvail,
    errRes,
    hideCreateGroup,
    isAllThreeMsvValuesNull,
    Class_EA_Grid_Table,
    ClassCsvDownload
  };
};

export default connect(mapStateToProps, {
  CLASS_EA_API,
  LOAD_STATUS_ICON,
  SHOW_HIDE_GROUPING,
  Chart_loading_Failed,
  CEA_CSVDATA_DOWNLOAD_APICALL,
  CEA_CSVDATA_DOWNLOAD_RESET
})(C_ErrorChart);
