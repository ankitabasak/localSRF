import React, { PureComponent } from 'react';
import '../Class_Error_Analysis/class-error-analysis.css';
import { getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
  Selected_Errors,
  Class_EA_Grid_Table,
  Update_RecordType,
  LOAD_STATUS_ICON,
  LOAD_ICON
} from '../../../Redux_Actions/C_ErrorAnalysisAction.jsx';
import { connect } from 'react-redux';

class ClassErrorAnalysisChart extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      ErrorList: [
        'substitution',
        'omission',
        'insertion',
        'told',
        'repetation',
        'selfCorrection'
      ],
      ErrorCues: [
        'meaningCues',
        'structuralCues',
        'visualCues',
        'omissionsTolds'
      ],
      colorBar: [
        '4px solid rgb(255, 142, 45)',
        '4px solid rgb(255, 197, 45)',
        '4px solid rgb(50, 172, 65)',
        '4px solid rgb(7, 156, 207)'
      ],
      msvBar: [
        ' 4px solid rgb(213, 234, 242)',
        ' 4px solid rgb(191, 224, 235)',
        '4px solid rgb(170, 214, 229)',
        ' 4px solid rgb(128, 195, 218)'
      ],
      isHovered: false,
      outerIndex: '',
      error: '',
      recordType: '',
      timerVal: null
    };

    this.showRecord = this.showRecord.bind(this);
    this.onMouseOver = this.onMouseOver.bind(this);
    this.onMouseOut = this.onMouseOut.bind(this);
    this.showErrRecords = this.showErrRecords.bind(this);
    this.multipleCellSelection = this.multipleCellSelection.bind(this);
    this.clEavalues = this.clEavalues.bind(this)
  }

  onMouseOver(i, errType, recordType) {
    this.setState({
      isHovered: true,
      outerIndex: i,
      error: errType,
      recordType: recordType
    });
  }

  onMouseOut() {
    this.setState({
      isHovered: false,
      outerIndex: '',
      error: '',
      recordType: ''
    });
  }

  //onclick select error
  selectedErrors(errorSel, selError) {
    this.props.LOAD_ICON();
    var errList = selError[errorSel.recordType];
    if (errList) {
      let duplicateIndex = this.isDuplicateBox(errorSel, errList);
      if (duplicateIndex != -1) {
        errList.splice(duplicateIndex, 1);
      } else {
        errList.push(errorSel);
      }
      this.props.Selected_Errors({
        ['selectedErrors']: { [errorSel.recordType]: errList }
      });

      this.classErrGridApi({
        ['selectedErrors']: { [errorSel.recordType]: errList }
      });
    } else {
      errList = { [errorSel.recordType]: [errorSel] };
      this.props.Selected_Errors({
        ['selectedErrors']: errList
      });
      this.classErrGridApi({ ['selectedErrors']: errList });
    }
  }

  //api call on multiple cell selection
  multipleCellSelection(delay, token, payLoad) {
    let timerId;
    if (this.state.timerVal) {
      clearTimeout(this.state.timerVal);
    }
    timerId = setTimeout(() => {
      this.props.Class_EA_Grid_Table(token, payLoad);
      timerId = null;
    }, delay);
    this.setState({ ...this.state, timerVal: timerId });
  }

  //check for duplicate value
  isDuplicateBox(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (bubble.errorName == obj.errorName && bubble.range == obj.range) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }

  classErrGridApi(selErrList) {
    let ErrList;
    let errRange;
    if (selErrList['selectedErrors']['recentRecord']) {
      ErrList = selErrList['selectedErrors']['recentRecord'].map(obj => {
        errRange = obj.range.split('-');
        return {
          errorName: obj.errorName,
          fromRange: errRange[0],
          toRange: errRange[1]
        };
      });
    } else if (selErrList['selectedErrors']['firstRecord']) {
      ErrList = selErrList['selectedErrors']['firstRecord'].map(obj => {
        errRange = obj.range.split('-');
        return {
          errorName: obj.errorName,
          fromRange: errRange[0],
          toRange: errRange[1]
        };
      });
    } else if (selErrList['selectedErrors']['allRecordsAverage']) {
      ErrList = selErrList['selectedErrors']['allRecordsAverage'].map(obj => {
        errRange = obj.range.split('-');
        return {
          errorName: obj.errorName,
          fromRange: errRange[0],
          toRange: errRange[1]
        };
      });
    } else {
      ErrList = selErrList;
    }
    let payLoad = {
      ...getCommonHeaders(this.props, 'class'),
      selectedErrorRanges: {
        errorRangesList: ErrList,
        allRecordsAverage: selErrList['selectedErrors']['allRecordsAverage']
          ? true
          : false,
        firstRecord: selErrList['selectedErrors']['firstRecord'] ? true : false,
        recentRecord: selErrList['selectedErrors']['recentRecord']
          ? true
          : false
      }
    };

    let selErr = selErrList.selectedErrors['recentRecord'] || selErrList.selectedErrors['firstRecord'] || selErrList.selectedErrors['allRecordsAverage'];
    if (selErr && selErr.length > 0) {
      this.multipleCellSelection(1000, this.props.token, payLoad);
    }
  }

  //adding background color
  getOnClickColor(errorNames, level, selectedClassLevels, currentLevelInfo) {
    let applyColor = '';
    if (errorNames.indexOf(level) > -1) {
      if (currentLevelInfo.val === 0) {
        applyColor = 'default-color-hover';
      } else {
        applyColor = 'default-color';
      }
    }
    if (
      selectedClassLevels &&
      selectedClassLevels[currentLevelInfo.recordType]
    ) {
      selectedClassLevels[currentLevelInfo.recordType].forEach(obj => {
        if (
          currentLevelInfo.errorName == obj.errorName &&
          currentLevelInfo.range == obj.range
        ) {
          applyColor = 'select-color';
          return;
        }
      });
    }
    return applyColor;
  }

  //apply hover color
  bgColorHover(i) {
    if (
      this.state.recordType === 'firstRecord' &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === 'errR'
    ) {
      return 'firstRec';
    }
    if (
      this.state.recordType === 'firstRecord' &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === 'msvErr'
    ) {
      return 'firstRecMsv';
    }
    if (
      this.state.recordType === 'recentRecord' &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === 'errR'
    ) {
      return 'firstRecErr';
    }
    if (
      this.state.recordType === 'recentRecord' &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === 'msvErr'
    ) {
      return 'firstRecErrMsv';
    }
    if (
      this.state.recordType === 'allRecordsAverage' &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === 'errR'
    ) {
      return 'allRecErr';
    }
    if (
      this.state.recordType === 'allRecordsAverage' &&
      this.state.isHovered &&
      this.state.outerIndex === i &&
      this.state.error === 'msvErr'
    ) {
      return 'allRecErrMsv';
    }
  }

  clEavalues(errVal, errType, isMsvValuesNull) {

    if (errType === 'errR') {
      return errVal;
    } else if (errType === 'msvErr') {
      if (isMsvValuesNull) {
        return <span>&mdash;</span>;
      } else {
        return errVal;
      }
    }

  }
  displayRecords(record, errorList, errorRange, recordType, errType, isMsvValuesNull) {
    return (
      <div>
        {errorRange.map((valueRange, i) => {
          return (
            <div
              className="first-error-col"
              id={
                errType === 'msvErr' && recordType === 'firstRecord'
                  ? 'msvAvg' + i
                  : recordType === 'firstRecord' && errType == 'errR'
                    ? 'errAvg' + i
                    : recordType === 'recentRecord' && errType == 'errR'
                      ? 'errAvg1' + i
                      : recordType === 'recentRecord' && errType == 'msvErr'
                        ? 'msvAvg1' + i
                        : recordType === 'allRecordsAverage' && errType == 'errR'
                          ? 'allErrAvg' + i
                          : recordType === 'allRecordsAverage' && errType == 'msvErr'
                            ? 'allMsvAvg' + i
                            : ''
              }
            >
              <div className="bor-1" />

              <ul
                className={this.bgColorHover(i)}
              >
                {errorList.map((value, index) => {
                  let fluencyRate = errorRange[i];
                  return (
                    <React.Fragment>
                      {process.env.ORR_SHOW_REPETITION_BEHAVIOR_MARKUP === 'false' && 
                      value === 'repetation' ? (
                        ''
                      ) : (
                        <li
                          key={index}
                          className={
                            (record[recordType][value][fluencyRate] === 0
                              ? ''
                              : 'cursor-pointer hover-cea ') +
                            this.getOnClickColor(
                              errorList,
                              value,
                              this.props.SelectedErr,
                              {
                                val: record[recordType][value][fluencyRate],
                                range: errorRange[i],
                                errorName: value,
                                recordType: recordType
                              }
                            )
                          }
                          onClick={() =>
                            record[recordType][value][fluencyRate] === 0
                              ? ''
                              : this.selectedErrors(
                                {
                                  // val: record[recordType][value][fluencyRate],
                                  range: errorRange[i],
                                  errorName: value,
                                  recordType: recordType
                                },
                                this.props.SelectedErr
                              )
                          }
                        >
                          {this.clEavalues(record[recordType][value][fluencyRate], errType, isMsvValuesNull)}
                          {/* {record[recordType][value][fluencyRate]}
                          {errType === 'msvErr' && firstRecordMsvNull ?"" :  record[recordType][value][fluencyRate]  } */}
                        </li>
                      )}
                    </React.Fragment>
                  );
                })}
                <li
                  key={i}
                  className={` cea-btm-size btm-line ${errType === 'msvErr' ? 'ipad-btm-line1 lh-23' : ''}`}
                  style={{
                    borderBottom:
                      errType === 'msvErr'
                        ? this.state.msvBar[i]
                        : this.state.colorBar[i]
                  }}
                  onMouseOver={() =>
                    !errType
                      ? this.onMouseOver(i, 'errR', recordType)
                      : this.onMouseOver(i, errType, recordType)
                  }
                  onMouseOut={() =>
                    !errType ? this.onMouseOut(i) : this.onMouseOut(i, errType)
                  }
                >
                  {errType === 'msvErr' ?
                    <React.Fragment>
                      <div className="mob-lhs-val desk-hide">{valueRange.split('-')[0] + '-'}</div>
                      <div className="mob-rhs-val desk-hide">{valueRange.split('-')[1] + '%'}</div>
                    </React.Fragment> :
                    <React.Fragment>
                      <span className="desk-hide">{valueRange}</span>
                    </React.Fragment>
                  }

                  <span className="mob-hide">{valueRange}</span>

                </li>
              </ul>
            </div>
          );
        })}
      </div>
    );
  }

  //show selected record
  showRecord(e) {
    this.props.LOAD_STATUS_ICON();
    this.props.Update_RecordType(e.currentTarget.value);
    this.props.makeApiCall(e.currentTarget.value);
  }

  showErrRecords(recType) {
    this.props.LOAD_STATUS_ICON();
    this.props.Update_RecordType(recType);
    this.props.makeApiCall(recType);
  }
  render() {
    return (
      <div className="col-lg-7 res-width-8 class_ea cea-orgZ">
        {/* Radio button start */}
        {!this.props.showHideRecentRecord && (
          <div className="show-radio-btn radio_btn_wrap cfa-print-radio cea-top-header">
            <div className="check-box-heading pull-left">
              Compare No. of students with:
            </div>
            <div className="round pull-left class_ea_radio">
              <input
                type="radio"
                value="all"
                checked={this.props.showRecord === 'all'}
                onChange={this.showRecord}
              />
              <span className={this.props.showRecord === 'all' ? " checkmark-sel" : "checkmark"} />
              <span
                className="cursor-pointer"
                onClick={() => this.showErrRecords('all')}
              // className={this.props.showRecord === 'all' ? 'blueColor' : ''}
              >
                All Records' Average
              </span>
            </div>

            <div className="round pull-left class_ea_radio">
              <input
                type="radio"
                value="rec"
                checked={this.props.showRecord === 'rec'}
                onChange={this.showRecord}
              />
              <span className={this.props.showRecord === 'rec' ? " checkmark-sel" : "checkmark"} />
              <span
                className="cursor-pointer"
                onClick={() => this.showErrRecords('rec')}
              // className={this.props.showRecord === 'rec' ? 'blueColor' : ''}
              >
                Recent Record
              </span>
            </div>
          </div>
        )}
        {/* Radio button end */}

        {/* Left Chart Table Start */}
        <div
          className="sea-wrapper pos-rel class_ea-wrap sc-ea-ipad-wrap class-ea-ipad-wrap cea-mt0"
          style={{ width: 'auto' }}
        >
          <div className="error-analysis-section-cea cEa-cea-03-20">
            <p>Error Analysis (By No. of Students)</p>
          </div>

          <div className="sea-scroller-cea">
            <div
              className="bor-bottom"
              style={{ position: 'relative', top: '-10px', left: '-19px' }}
            >
              <hr className="cea-hr-top" />
            </div>
            <div className="row">
              <div className="error-col-cea pos-rel sc-ea-ul" style={{ float: 'left' }}>
                <div class="scea-bor"></div>
                <p
                  className="col-name print-top3"
                  style={{
                    position: 'absolute',
                    top: '-21px',
                    left: '0px',
                    fontSize: '14px',
                    fontWeight: '500',
                    whiteSpace: 'nowrap',
                    width: '100%',
                    textAlign: 'center'
                  }}
                >
                  Error
                </p>
                <ul>
                  <li className="top-bor pos-rel">
                    <span>Substitution</span>
                    <div className="row-strip-1 strip-bg-1" />
                  </li>
                  <li className="pos-rel">
                    <span>Omission</span>
                    <div className="row-strip-1 strip-bg-2" />
                  </li>
                  <li className="pos-rel">
                    <span>Insertion</span>
                    <div className="row-strip-1 strip-bg-3" />
                  </li>
                  <li className="pos-rel">
                    <span>Told</span>
                    <div className="row-strip-1 strip-bg-4" />
                  </li>
                  {process.env.ORR_SHOW_REPETITION_BEHAVIOR_MARKUP === 'true' &&
                  <li className="pos-rel">
                    <span>Repetition</span>
                    <div className="row-strip-1 strip-bg-5" />
                  </li> }
                  <li className="pos-rel">
                    <span>Self-Correction</span>
                    <div className="row-strip-1 strip-bg-6" />
                  </li>

                  <li
                    className="pos-rel end-row cea-arrow"
                    style={{ borderBottom: 'none', paddingLeft: '0px' }}
                  >
                    <div className="cea-no-of-error"></div>
                    <span className="arrow_box-cea size-box-cea">
                      No. of Errors
                    </span>
                  </li>
                </ul>
              </div>

              <div
                className="first-record-error pos-rel"
                style={{ float: 'left', width: 'auto', marginLeft: '5px' }}
              >
                <div className="scea-bor-first-record-lft"></div>
                <div className="scea-bor-first-record"></div>
                <div className="scea-bor-first-record-bottom"></div>
                <div className="box-top-bor" />
                <div className="td-devider1" />
                <div className="td-devider2" />
                <div className="td-devider3" />
                <p
                  className="col-name print-top3"
                  style={{
                    position: 'absolute',
                    top: '-21px',
                    left: '0px',
                    fontSize: '14px',
                    fontWeight: '500',
                    whiteSpace: 'nowrap',
                    width: '100%',
                    textAlign: 'center'
                  }}
                >
                  First Record
                </p>

                <div
                  className="sea-table"
                  style={{
                    borderLeft: 'none',
                    borderRight: 'none',
                    overflow: 'hidden'
                  }}
                >
                  {this.props.firstRecord &&
                    this.displayRecords(
                      this.props.firstRecord,
                      this.state.ErrorList,
                      this.props.errorRange,
                      'firstRecord',
                      'errR'
                    )}
                </div>
              </div>
              <div
                className="first-record-error pos-rel"
                style={{ float: 'left', width: 'auto', marginLeft: '5px' }}
              >
                {this.props.allRecord &&
                  !this.props.showHideRecentRecord &&
                  <React.Fragment>
                    <div class="scea-bor-first-record-lft"></div>
                    <div class="scea-bor-first-record"></div>
                    <div className="scea-bor-first-record-bottom"></div>
                  </React.Fragment>}
                {this.props.recentRecord &&
                  !this.props.showHideRecentRecord &&
                  <React.Fragment>
                    <div class="scea-bor-first-record-lft"></div>
                    <div class="scea-bor-first-record"></div>
                    <div className="scea-bor-first-record-bottom"></div>
                  </React.Fragment>}
                <p
                  className="col-name print-top3"
                  style={{
                    position: 'absolute',
                    top: '-21px',
                    left: '0px',
                    fontSize: '14px',
                    fontWeight: '500',
                    whiteSpace: 'nowrap',
                    width: '100%',
                    textAlign: 'center'
                  }}
                >
                  {!this.props.showHideRecentRecord
                    ? this.props.allRecord
                      ? "All Records' Average"
                      : this.props.recentRecord
                        ? 'Recent Record'
                        : ''
                    : ''}
                </p>
                <div className="box-top-bor" />
                <div className="td-devider1" />
                <div className="td-devider2" />
                <div className="td-devider3" />
                {/* --all record code start */}
                {this.props.allRecord &&
                  !this.props.showHideRecentRecord &&
                  this.displayRecords(
                    this.props.allRecord,
                    this.state.ErrorList,
                    this.props.errorRange,
                    'allRecordsAverage',
                    'errR'
                  )}
                {/* --all record code end */}
                {/* { recentRecord start} */}
                {this.props.recentRecord &&
                  !this.props.showHideRecentRecord &&
                  this.displayRecords(
                    this.props.recentRecord,
                    this.state.ErrorList,
                    this.props.errorRange,
                    'recentRecord',
                    'errR'
                  )}
                {/* recent record end */}
              </div>
            </div>
          </div>

          <div className="sea-scroller-cea">
            <div className="row">
              <div className="error-col-cea sc-ea-ul pos-rel" style={{ float: 'left' }}>
                <div className="cea-2nd-btm-bor"></div>
                <ul>
                  <li className="top-bor pos-rel">
                    <span>Meaning</span>
                    <div className="row-strip-1 strip-bg-7" />
                  </li>
                  <li className="pos-rel">
                    <span> Structural</span>
                    <div className="row-strip-1 strip-bg-7" />
                  </li>
                  <li className="pos-rel">
                    <span> Visual</span>
                    <div className="row-strip-1 strip-bg-7" />
                  </li>

                  <li className="pos-rel">
                    <span>MSV Not Scored</span>
                    <div className="row-strip-1 strip-bg-7" />
                  </li>
                  <li
                    className="pos-rel end-row cea-arrow"
                    style={{ borderBottom: 'none', paddingLeft: '0px' }}
                  >
                    <div className="cea-no-of-error h-45"></div>
                    <span className="arrow_box-cea size-box-cea">No. of MSV &nbsp;&nbsp;&nbsp;</span>
                  </li>
                </ul>
              </div>
              <div
                className="first-record-error pos-rel cea-msv-strip"
                style={{ float: 'left', width: 'auto', marginLeft: '5px' }}
              >
                <div className="box-top-bor" />
                <div
                  className="sea-table"
                  style={{
                    borderLeft: 'none',
                    borderRight: 'none',
                    overflow: 'hidden'
                  }}
                >
                  <div className="cea-2nd-btm-bor-lhs"></div>
                  <div className="cea-2nd-btm-bor-rhs"></div>
                  <div className="cea-2nd-btm-bor-btm"></div>
                  {this.props.firstRecord &&
                    this.displayRecords(
                      this.props.firstRecord,
                      this.state.ErrorCues,
                      this.props.msvErrorRange,
                      'firstRecord',
                      'msvErr',

                      this.props.isAllThreeMsvValuesNull.firstRecordMsvNull ? this.props.isAllThreeMsvValuesNull.firstRecordMsvNull : ''
                    )}
                </div>
              </div>
              <div
                className="first-record-error pos-rel btm-rhs-box cea-msv-strip"
                style={{ float: 'left', width: 'auto', marginLeft: '5px' }}
              >
                {this.props.recentRecord &&
                  !this.props.showHideRecentRecord &&
                  <React.Fragment>
                    <div className="cea-2nd-btm-bor-lhs"></div>
                    <div className="cea-2nd-btm-bor-rhs"></div>
                    <div className="cea-2nd-btm-bor-btm"></div>
                  </React.Fragment>}
                {this.props.allRecord &&
                  !this.props.showHideRecentRecord &&
                  <React.Fragment>
                    <div className="cea-2nd-btm-bor-lhs"></div>
                    <div className="cea-2nd-btm-bor-rhs"></div>
                    <div className="cea-2nd-btm-bor-btm"></div>
                  </React.Fragment>}

                <div className="box-top-bor" />
                <div className="td-devider1" />
                <div className="td-devider2" />
                <div className="td-devider3" />
                {/* --all record code start */}
                {this.props.allRecord &&
                  !this.props.showHideRecentRecord &&
                  this.displayRecords(
                    this.props.allRecord,
                    this.state.ErrorCues,
                    this.props.msvErrorRange,
                    'allRecordsAverage',
                    'msvErr',
                    this.props.isAllThreeMsvValuesNull.allRecordsAverageMsvNull ? this.props.isAllThreeMsvValuesNull.allRecordsAverageMsvNull : ''
                  )}
                {/* --all record code end */}
                {/* { recentRecord start} */}
                {this.props.recentRecord &&
                  !this.props.showHideRecentRecord &&
                  this.displayRecords(
                    this.props.recentRecord,
                    this.state.ErrorCues,
                    this.props.msvErrorRange,
                    'recentRecord',
                    'msvErr',
                    this.props.isAllThreeMsvValuesNull.recentRecordMsvNull ? this.props.isAllThreeMsvValuesNull.recentRecordMsvNull : ''
                  )}
                {/* recent record end */}
              </div>
            </div>

            <div
              className="bor-bottom cea-print"
              style={{ position: 'relative', top: '-14px', left: '-19px' }}
            >
              <hr className="cea-hr-bottom" />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ Universal }) => {
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  return {
    ContextHeader,
    NavigationByHeaderSelection,
  };
};

export default connect(
  mapStateToProps,
  { Selected_Errors, Class_EA_Grid_Table, Update_RecordType, LOAD_STATUS_ICON, LOAD_ICON }
)(ClassErrorAnalysisChart);