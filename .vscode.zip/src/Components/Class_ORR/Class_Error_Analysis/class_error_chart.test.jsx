import React from 'react';
import { shallow } from 'enzyme';
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import C_ErrorChart from './class_error_chart';

jest.mock('react-redux', () => ({
  connect: jest.fn().mockImplementation(() => (component) => component),
}));
function setup(overrides = {}) {
  const props = {
    LOAD_STATUS_ICON: jest.fn(),
    CLASS_EA_API: jest.fn(),
    LoginDetails: { JWTToken: 'test token'},
    ContextHeader: {
      Date_Tab: {
        Report_termEndDate: '2015-07-01 00:00:00',
        selectedterm_Obj: {
          termStartDate: '2015-07-01 00:00:00',
        },
      },
      Roster_Tab: {
        SelectedClass: { id: 123 },
        SelectedSchool: { id: 123 },
      }
    }
  };
  const finalProps = Object.assign(props, overrides);
  const wrapper = shallow(( <C_ErrorChart {...finalProps} /> ));
  return { wrapper };
};

describe('C_ErrorChart', () => {
  describe('renders properly', () => {
    const { wrapper } = setup();
    it('renders component', () => {
      expect(wrapper).toHaveLength(1);
    });

    it('matches snapshot', () => {
      expect(wrapper).toMatchSnapshot();
    });
  });
});
