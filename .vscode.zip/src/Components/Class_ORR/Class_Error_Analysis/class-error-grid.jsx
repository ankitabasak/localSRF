import React, { PureComponent } from 'react';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';
import '../class-common.css';
import { connect } from 'react-redux';
import {
  SAVE_SORTED_EA,
  SORT_EA_GRID
} from '../../../Redux_Actions/C_ErrorAnalysisAction.jsx';
import {
  navigateToStudentReportFromClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';

class Ea_Table extends PureComponent {
  showToolTip(firstName, lastName) {
    let name = firstName + ' ' + lastName;

    if (name && name.length > 16) {
      let dispname = name.substring(0, 15) + '...'
      return (
        <React.Fragment>
          <span>{dispname}</span>
          <div className=" cfa-hover table-tooltip word-bk">
            {name}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      );
    } else {
      return (<span>{name}</span>)
    }

  }
  classEaGridData(Data, tableData) {
    return (
      <div className="class_ea-inner-wrap">
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec "

        >
          <div className="student-column-list-rhs-sec" >
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'lastName',
                Data.sortType
              )}
            >
              Students ({tableData.length})
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'lastName', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('lastName', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'lastName', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('lastName', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'readingLevel',
                Data.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'readingLevel', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('readingLevel', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'readingLevel', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('readingLevel', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'proficiency',
                Data.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'proficiency', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('proficiency', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'proficiency', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('proficiency', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                'assignmentDate',
                Data.sortType
              )}
            >
              Date
            </span>
            <span className="togglers">
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'assignmentDate', 'desc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('assignmentDate', 'desc', tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  'cursor-pointer material-icons ' +
                  this.assignClasses(Data, 'assignmentDate', 'asc')
                }
                onClick={() =>
                  this.errorAnalysisGrid('assignmentDate', 'asc', tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        <div id="classEa" className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "cea-scroll")}>
          {tableData.map((tableDetails, value) => (
            <div className="pos-rel student-list-row-rhs-sec" key={value}>
              <div className="student-column-list-rhs-sec cursor-pointer crb-hover-container cfa-hover" onClick={() => { this.props.navigateToStudentReportFromClassReport(tableDetails, false) }}>
                {this.showToolTip(tableDetails.firstName, tableDetails.lastName)}
              </div>
              <div className="student-column-list-rhs-sec">
                <span>
                  {tableDetails.readingLevel
                    ? tableDetails.readingLevel
                    : dashSymbol}
                </span>
              </div>

              <div className="student-column-list-rhs-sec">
                <span>
                  {tableDetails.proficiency
                    ? tableDetails.proficiency
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list-rhs-sec">
                <span>
                  {tableDetails.assignmentDate
                    ? tableDetails.assignmentDate
                    : dashSymbol}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? 'rt-td-active'
      : '';
  }

  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return ' blueColor';
    } else {
      return '';
    }
  }

  //Onclick calling sort function and update the sort type and column in store
  errorAnalysisGrid(sortColumn, sortType, actualArray) {
    document.getElementById('classEa').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_EA_GRID(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);
      this.props.SAVE_SORTED_EA(sortedArray);
    }
  }

  render() {
    return (
      <React.Fragment>
        {/* {!this.props.disableDiv && ( */}

        {this.props.sideTableData && (
          <div className="col-md-4 res-width cea-rhs-rel mt-6 cea-dup-scea">
            <div>
              {/* onclick and on load main api should send the Reading target */}
              <div className="pull-left rt-left-heading">
                {this.props.sideTableData.selectedRecordDetails
                  .recordTitle === "All Record's Average"
                  ? "All Records' Average"
                  : this.props.sideTableData.selectedRecordDetails
                    .recordTitle}
              </div>
              <div className="pos-rel">
                <div className="rt-rhs-strip"></div>
                <hr className="clearfix mb-8" />
              </div>
              <div className="mb-10">
                <div className="reading-level-label mb-8 color-1">
                  First Record Date Range:
                    <span> {
                    this.props.sideTableData.selectedRecordDetails
                      .firstRecordDateRange
                  }
                  </span>
                </div>
                <div className="reading-level-label color-2">
                  Recent Record Date Range:
                    <span> {
                    this.props.sideTableData.selectedRecordDetails
                      .recentRecordDateRange
                  }
                  </span>
                </div>
              </div>
              <div className="pull-right clearfix new-mb-4 rt-label-txt">
                <span className="rt-label">
                  No. of students rostered:
                    <span> {
                    this.props.sideTableData.selectedRecordDetails
                      .noOfStudentsRoastered
                  }
                  </span>
                </span>
              </div>
              <div className="rhs-wrap class-ea school-ea-wrap classEaWrap-03-20">
                <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                  <div className="student-list-table-main">
                    <div className="student-list-table-rhs-sec">
                      {this.classEaGridData(
                        this.props.Data,
                        this.props.sideTableData.tableData || []
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        {/* // this.props.SelectedErr.length > 0 ? <div className="col-md-4 res-width display-msg err-msg-alignment">
            //   <img src={spinner} alt="spinner" />
            // </div> : <div></div> */}
        {this.props.disableDiv &&
          <div className="col-md-4 res-width display-msg err-msg-alignment">
            <img src={spinner} alt="spinner" />
          </div>
        }
      </React.Fragment>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { SAVE_SORTED_EA, SORT_EA_GRID, navigateToStudentReportFromClassReport }
)(Ea_Table);
// export default Ea_Table;
