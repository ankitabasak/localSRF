import ClassErrorAnalysisChart from './class-error-analysis-chart';
import React from 'react';
import { shallow } from 'enzyme';

jest.mock('react-redux', () => ({
    connect: jest.fn().mockImplementation(() => (component) => component),
  }));
  function setup(overrides = {}) {
    const props = {
    };
    const finalProps = Object.assign(props, overrides);
    const wrapper = shallow((
        <ClassErrorAnalysisChart {...finalProps} />
    ));
    return { wrapper };
  };
  describe('ClassErrorAnalysisChart', () => {
    describe('renders properly', () => {
      const { wrapper } = setup();
      it('renders component', () => {
        expect(wrapper).toHaveLength(1);
      });
      it('matches snapshot', () => {
        expect(wrapper).toMatchSnapshot();
      });
    });
  });
