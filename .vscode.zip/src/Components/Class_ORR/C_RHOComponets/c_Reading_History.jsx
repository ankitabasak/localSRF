import React, { PureComponent } from 'react';
import { connect } from 'react-redux';
import {
  CLASS_READING_HISTORY_DATA,
  CLASS_RH_ERRORHANDLING,
  CRH_CSVDATA_DOWNLOAD_APICALL,
  CRH_CSVDATA_DOWNLOAD_RESET
} from '../../../Redux_Actions/C_ReadingHistoryActions.jsx';
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import ClassReadingHistory from './class_rh.jsx';
import NoRosterData from '../../../Utils/NoRoster.js';
import NoRecordsData from '../../../Utils/No_Data_Found';
import Spinner from '../../ReusableComponents/Spinner/Spinner.jsx';
import Filter from '../../ORR/FilterComponents/Filter';
import TimeOut from '../../ReusableComponents/Spinner/TimeOut.jsx';
import ChartNotLoad from '../../../Utils/Chart_Not_Load';
import PrintCRho from '../../ReusableComponents/PrintOrrCharts/C_RhoPrint.jsx';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';

class c_Reading_History extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      externalFilter: {}
    };
    this.timeOut = this.timeOut.bind(this);
    this.classReadingHistoryApi = this.classReadingHistoryApi.bind(this);
  }

  componentDidMount() {
    this.classReadingHistoryApi();
  }
  // handle timeout
  timeOut() {
    this.props.CLASS_RH_ERRORHANDLING({
      isApiLoading: false,
      isDataNotAvailable: false,
      timeOut: true
    });
  }

  // Function for Class Reading History Api
  classReadingHistoryApi() {
    // start spinner befor the api call
    this.props.CLASS_RH_ERRORHANDLING({
      isApiLoading: true,
      isDataNotAvailable: false,
      timeOut: false
    });
    let data = { ...getCommonHeaders(this.props, 'class'), value: 'class' };
    this.props.CLASS_READING_HISTORY_DATA(
      this.props.LoginDetails.JWTToken,
      data
    );
  }

  // Download csv data
  downLoadCSVData() {
    this.props.CRH_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
    let Req_Payload = {
      classChartType: {
        "allRecordsAvgFlag": '1',
        "chartName": "CRHO"
      },
      ...getCommonHeaders(this.props, 'class')
    };
    this.props.CRH_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
  }

  render() {
    let Data = this.props.SortData;
    let classReadingHistoryData = this.props.ClassReadingHistoryDetails.data;
    let errorHandler = this.props.ClassReadingHistoryDetails;
    let classObject = this.props.ContextHeader.Roster_Tab.SelectedClass;
    let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedClass.name;
    if (this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] && this.props.ClassCsvDownload['csvData']) {
      setTimeout(() => {
        this.refs.groupCSV.link.click();
        this.props.CRH_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
      }, 500)

    }
    return (
      <div>
        {this.props.NavigationByHeaderSelection.class && classObject.id ? (
          <div>
            <Filter />
            {this.props.ClassReadingHistoryDetails.data &&
              !errorHandler.timeOut &&
              !errorHandler.isDataNotAvailable && (
                <React.Fragment>
                  <span className="printicon-btn">
                    <PrintCRho
                      selectedFilter={this.props.CommonFilterData}
                      studentDetails={this.props.ContextHeader}
                      navSelected={this.props.NavigationByHeaderSelection}
                      classReadingHistoryData={classReadingHistoryData}
                    />
                  </span>
                  <div id="testClass">
                    {this.props.ClassCsvDownload && this.props.ClassCsvDownload['csvData'] &&
                      <CSVLink
                        ref="groupCSV"
                        headers={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['header']}
                        data={this.props.ClassCsvDownload['csvData'] && this.props.ClassCsvDownload['csvData']['data']}
                        style={{ display: 'none' }}
                        // filename={"CRH_CSV.csv"} 
                        filename={`${csvFileName}.csv`}
                      />}
                    <div className="cls-crho-csv-icon-alignment" onClick={() => !this.props.ClassCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                      {this.props.ClassCsvDownload && this.props.ClassCsvDownload['downloadInProgress'] ?
                        <span className="csv_download_icon">
                          <i className="material-icons">autorenew</i>
                        </span> :
                        <span className="csv_download_icon">
                          <img src={CsvIcon} width="20" height="20" />
                        </span>}
                    </div>
                    <ClassReadingHistory
                      classReadingHistoryData={classReadingHistoryData}
                      Data={Data}
                      print={false}
                    />
                  </div>
                </React.Fragment>
              )}
            {!this.props.ClassReadingHistoryDetails.data &&
              errorHandler.isApiLoading && (
                <Spinner
                  startSpinner={errorHandler.isApiLoading}
                  showTimeOut={this.timeOut}
                />
              )}
            {!errorHandler.isApiLoading && errorHandler.timeOut && (
              <TimeOut tryAgain={this.classReadingHistoryApi} />
            )}
            {errorHandler.chartLoadFail &&
              !errorHandler.timeOut &&
              !errorHandler.isApiLoading && (
                <ChartNotLoad tryAgain={this.classReadingHistoryApi} />
              )}
            {errorHandler.isDataNotAvailable && (
              <NoRecordsData NodataFound={'dataNotAvail'} />
            )}
          </div>
        ) : (
            <div>
              <NoRosterData />
            </div>
          )}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  classReadingHistory,
  CommonFilterDetails
}) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection } = Universal;
  const {
    ClassReadingHistoryDetails,
    Response,
    SortData,
    isApiLoading,
    isDataNotAvailable,
    ClassCsvDownload
  } = classReadingHistory;
  const { CommonFilterData } = CommonFilterDetails;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    ClassReadingHistoryDetails,
    isApiLoading,
    isDataNotAvailable,
    Response,
    SortData,
    CommonFilterData,
    ClassCsvDownload
  };
};

export default connect(
  mapStateToProps,
  {
    CLASS_READING_HISTORY_DATA, CLASS_RH_ERRORHANDLING,
    CRH_CSVDATA_DOWNLOAD_APICALL,
    CRH_CSVDATA_DOWNLOAD_RESET
  }
)(c_Reading_History);
