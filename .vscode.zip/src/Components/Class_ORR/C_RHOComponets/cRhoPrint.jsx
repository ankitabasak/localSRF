import React, { Component } from 'react';

class ClassRhoPrint extends Component {
    arrayConstruction(list, endIndex) {
        var idx = 0
        var result = []
        while (idx < list.length) {
            if (idx % endIndex === 0) result.push([])
            result[result.length - 1].push(list[idx++])
        }
        return result
    }

    crhoDataConstruction(list, endIndex) {
        let count = 0;
        let start = 1;
        let modifiedArray = this.arrayConstruction(list, endIndex);
        let total = modifiedArray.map((indArray, index) => {
            start = 1 + count;
            count = count + indArray.length;
            return this.printTable(indArray, list, start, count, index)
        })
        return total

    }

    printTable(arr, list, start, count, index) {
        const dashSymbol = <span>&mdash;</span>;
        return <React.Fragment>
            <table className={"cRhlft-bor-wrap-15-20 crho-table-print crhs-mt" + index}>
                <tr className="crho-print">
                    <th>Student({start} -  {count}/ {list.length})</th>
                    {arr.map((classDetails, val) => {
                        return <React.Fragment>
                            <th style={{ textAlign: "left" }}>{classDetails.firstName + ' ' + classDetails.lastName}</th>
                        </React.Fragment>
                    })}
                </tr>
                <tr className="crho-print">
                    <th>Date</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }} >{data.assignmentDate}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Level </th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.letterLevel}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Proficiency</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.proficiency}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Passage </th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.lastPassage !== null ? data.lastPassage : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Category</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }} >{data.category !== null ? data.category : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Accuracy</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.accuracy !== null ? data.accuracy + "%" : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Self-Correction</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>
                                    {data.selfCorrection !== null && data.selfCorrection !== 'NA' ?
                                        data.selfCorrection : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Fluency</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.fluency !== null ? data.fluency + ' wcpm' : dashSymbol}</td>
                            </React.Fragment>)

                    })}
                </tr>
                <tr className="crho-print">
                    <th>Retell</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.reTelling !== null ? data.reTelling : dashSymbol}</td>
                            </React.Fragment>)
                    })}
                </tr>
                <tr className="crho-print">
                    <th>Comprehension</th>
                    {arr.map((data, val) => {
                        return (
                            <React.Fragment>
                                <td style={{ textAlign: "left" }}>{data.comprehension !== null ? data.comprehension : dashSymbol}</td>
                            </React.Fragment>)
                    })}
                </tr>
            </table>
            <div className="pagebreak"> </div>
        </React.Fragment>
    }

    render() {
        return (
            <React.Fragment>
                {this.crhoDataConstruction(this.props.classReadingHistoryData, 5)}
            </React.Fragment>
        )
    }
}

export default ClassRhoPrint;