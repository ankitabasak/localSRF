import React, { PureComponent } from 'react';
import {
  SORT_COLUMN,
  SORTED_CLASS_READING_HISTORY_DATA
} from '../../../Redux_Actions/C_ReadingHistoryActions.jsx';
import {
  navigateToStudentReportFromClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import { connect } from 'react-redux';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';
import './classRho.css';

class ClassReadingHistory extends PureComponent {
  constructor(props) {
    super(props);
    this.classHistoryApiCall = this.classHistoryApiCall.bind(this);
    this.sortData = this.sortData.bind(this);
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text, passage) {
    let len = passage ? 18 : 16;
    if (text.length > len) {
      return (
        <React.Fragment>
          {text.substr(0, len)}...
          <div className="tooltip-container ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }
  //Onclick calling sort function and update the sort type and column in store
  classHistoryApiCall(sortColumn, sortType, actualArray) {
    document.getElementById('crho').scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_COLUMN(sortColumn, sortType);
  }
  // navigation to student
  startNavigation(student) {
    this.props.navigateToStudentReportFromClassReport(student, false);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);

      let currentNav = this.props.NavigationByHeaderSelection;
      this.props.SORTED_CLASS_READING_HISTORY_DATA(
        sortedArray,
        column,
        sortType,
        currentNav
      );
    }
  }

  //Return based on Date
  returnBasedOnDate(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'assignmentDate'
            ? "rho-student border-btm" : "rho-student "}>Date</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'assignmentDate' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('assignmentDate', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'assignmentDate' && Data.sortType === 'asc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('assignmentDate', 'asc', classDataArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //based on student name
  returnBasedOnTargetLevel(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'readingTarget'
            ? 'rho-student border-btm'
            : 'rho-student'
        }>Target Level</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'readingTarget' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('readingTarget', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'readingTarget' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('readingTarget', 'asc', classDataArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //based on student name
  returnBasedOnStartingLevel(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'startingLevel'
            ? 'rho-student border-btm'
            : 'rho-student'
        } >Starting Level</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'startingLevel' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('startingLevel', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'startingLevel' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('startingLevel', 'asc', classDataArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //based on student name
  returnBasedOnStudentName(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'lastName'
            ? 'rho-student border-btm'
            : 'rho-student'
        } >Student</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'lastName' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('lastName', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'lastName' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('lastName', 'asc', classDataArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //based on reading level
  returnBasedOnReadingLevel(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'letterLevel'
            ? 'rho-student border-btm'
            : 'rho-student'
        } >Level</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'letterLevel' && Data.sortType === 'desc'
                ? 'material-icons blueColor'
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('letterLevel', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'letterLevel' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('letterLevel', 'asc', classDataArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //based on proficieny
  returnBasedOnProficiency(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'proficiency'
            ? 'rho-student border-btm'
            : 'rho-student'
        } >Proficiency</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'proficiency' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('proficiency', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'proficiency' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('proficiency', 'asc', classDataArray)
            }
          >
            expand_less
          </i>
        </span>
      </div>
    );
  }

  //last passage
  returnBasedOnLastPassage(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'lastPassage'
            ? 'rho-student border-btm'
            : 'rho-student'
        }>Passage</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'lastPassage' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('lastPassage', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'lastPassage' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('lastPassage', 'asc', classDataArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //based on category
  returnBasedOnCategory(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'category'
            ? 'rho-student border-btm'
            : 'rho-student'
        }>Category</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'category' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('category', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'category' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('category', 'asc', classDataArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //based on accuracy
  returnBasedOnAccuracy(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'accuracy'
            ? 'rho-student border-btm'
            : 'rho-student'
        }>Accuracy</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'accuracy' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('accuracy', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'accuracy' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('accuracy', 'asc', classDataArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //function for Self Correction
  returnBasedOnSelfCorrection(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className="rho-student">Self-Correction</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'selfCorrection' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('selfCorrection', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'selfCorrection' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('selfCorrection', 'asc', classDataArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //based on Fluency
  returnBasedOnFluency(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className={
          Data.sortColumn === 'fluency'
            ? 'rho-student border-btm'
            : 'rho-student'
        } >Fluency</span>
        <span className="togglers">
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'fluency' && Data.sortType === 'desc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('fluency', 'desc', classDataArray)
            }
          >
            expand_more
          </i>
          <i
            style={{ cursor: 'pointer' }}
            className={
              Data.sortColumn === 'fluency' && Data.sortType === 'asc'
                ? 'material-icons blueColor '
                : 'material-icons'
            }
            onClick={() =>
              this.classHistoryApiCall('fluency', 'asc', classDataArray)
            }
          >
            expand_less
          </i>{' '}
        </span>
      </div>
    );
  }

  //Function for Retelling
  returnBasedOnRetelling() {
    return (
      <div className="student-column-list">
        <span className="rho-student">Retell</span>
      </div>
    );
  }

  //Function for Comprehension
  returnBasedOnComprehension(Data, classDataArray) {
    return (
      <div className="student-column-list">
        <span className="rho-student">Comprehension</span>
        {/* OR-1499 bug fix */}
        {/* <span className="togglers">
          <i style={{ cursor: 'default' }} className={'material-icons'}>
            expand_more
          </i>
          <i
            style={{ cursor: 'default' }}
            className={'material-icons'}
            onClick={() =>
              this.classHistoryApiCall('Comprehension', 'asc', classDataArray)
            }
          >
            expand_less
          </i>{' '}
        </span> */}
      </div>
    );
  }
  //class reading history data fetching
  ClassReadingHistoryHeaderAndData(Data, classDataArray, print) {
    const dashSymbol = <span>&mdash;</span>;
    return (
      <div>
        <div className="student-list-header rho-header-crh w-1700-crh crho-th">
          {this.returnBasedOnStudentName(Data, classDataArray)}
          {this.returnBasedOnDate(Data, classDataArray)}
          {this.returnBasedOnReadingLevel(Data, classDataArray)}
          {this.returnBasedOnProficiency(Data, classDataArray)}
          {this.returnBasedOnLastPassage(Data, classDataArray)}
          {this.returnBasedOnCategory(Data, classDataArray)}
          {this.returnBasedOnAccuracy(Data, classDataArray)}
          {this.returnBasedOnSelfCorrection(Data, classDataArray)}
          {this.returnBasedOnFluency(Data, classDataArray)}
          {this.returnBasedOnRetelling()}
          {this.returnBasedOnComprehension(Data, classDataArray)}
          {/* {this.returnBasedOnStartingLevel(Data, classDataArray)}
          {this.returnBasedOnTargetLevel(Data, classDataArray)} */}
        </div>
        <div
          className={
            'student-list-body ipad-scroll ' + (!print ? 'scroll-body w-1700-crh ' : '')
          }
          id="crho"
        >
          {classDataArray.map((classDetails, value) => (
            <div className="student-list-row pos-rel" key={value}>
              <div className="student-column-list" onClick={() => { this.startNavigation(classDetails) }}>
                <span className="cursor-pointer wb-break-all long-text-tooltip">
                  {this.longTextTooltip(classDetails.firstName + ' ' + classDetails.lastName, false)}
                </span>
              </div>
              <div className="student-column-list">
                <span> {classDetails.assignmentDate}</span>
              </div>
              <div className="student-column-list">
                <span>{classDetails.letterLevel}</span>
              </div>
              <div className="student-column-list">
                <span>{classDetails.proficiency}</span>
              </div>
              <div className="student-column-list long-text-tooltip">
                <span>
                  {classDetails.lastPassage !== null
                    ? this.longTextTooltip(classDetails.lastPassage, true)
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list">
                <span className="">
                  {classDetails.category !== null
                    ? classDetails.category
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list">
                <span>
                  {classDetails.accuracy !== null
                    ? classDetails.accuracy + '%'
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list">
                <span className="">
                  {classDetails.selfCorrection !== null && classDetails.selfCorrection !== 'NA'
                    ? classDetails.selfCorrection
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list">
                <span>
                  {classDetails.fluency !== null
                    ? classDetails.fluency + ' wcpm'
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list">
                <span>
                  {classDetails.reTelling !== null
                    ? classDetails.reTelling
                    : dashSymbol}
                </span>
              </div>
              <div className="student-column-list">
                <span>
                  {classDetails.comprehension !== null
                    ? classDetails.comprehension
                    : dashSymbol}
                </span>
              </div>
              {/* commenting as per OR-1189 */}
              {/* <div className="student-column-list">
                <span className="">
                  {classDetails.startingLevel
                    ? classDetails.startingLevel
                    : dashSymbol}
                </span>
              </div> */}
              {/* <div className="student-column-list">
                <span className="">
                  {classDetails.readingTarget
                    ? classDetails.readingTarget
                    : dashSymbol}
                </span>
              </div> */}
            </div>
          ))}
        </div>
      </div>
    );
  }

  render() {
    let classDataArray = this.props.classReadingHistoryData;
    const Data = this.props.Data;
    const print = this.props.print;

    return (
      <div className="container container-alignment">
        <div className="row">
          <div className="col-lg-12 float-left class_test_overview_table_list">
            {/* <div className="student-list-table"> */}
            <div className="student-list-table-main  student-table pos-rel">
              <div className="crh-hide-line" />
              <div className="student-list-table-crh overflow-scroll-crh">
                {this.ClassReadingHistoryHeaderAndData(
                  Data,
                  classDataArray,
                  print
                )}
              </div>
            </div>
            {/* </div> */}
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = () => {
  return {};
};

export default connect(
  mapStateToProps,
  { SORT_COLUMN, SORTED_CLASS_READING_HISTORY_DATA, navigateToStudentReportFromClassReport }
)(ClassReadingHistory);