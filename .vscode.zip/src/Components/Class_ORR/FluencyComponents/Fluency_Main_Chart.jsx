import React, { Component } from 'react';
import { connect } from 'react-redux';
import Filter from '../../ORR/FilterComponents/Filter';
import Switch_Fluency_Tab from "./Switch_Fluency_Tab.jsx";
import FluencyWcpmChart from './CfaWcpmChart.jsx';
import FluencyFpotChart from '../FluencyProgressComponents/CfaFpotChart.jsx'
// import SchoolFluencyAnalysisComponent from '../School_FA_Components/School_FA_Components.jsx'
import {
    UpDateFluencySubTab
} from "../../../Redux_Actions/C_FlunecyActions.jsx";

class CFAMainChart extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <React.Fragment>
                <Filter
                    recType={this.props.progressOverTime.showRecord}
                ></Filter>
                <Switch_Fluency_Tab
                    tabName={this.props.ScFTabSelection}
                >
                </Switch_Fluency_Tab>
                {this.props.FluencyTabSelection["wcpm"] &&
                    <FluencyWcpmChart></FluencyWcpmChart>
                }
                {this.props.FluencyTabSelection["fpot"] &&
                    <FluencyFpotChart></FluencyFpotChart>
                }
            </React.Fragment>
        );
    }
}

const mapStateToProps = ({ School_FA_Reducer, classFluency, Authentication, Universal, CommonFilterDetails }) => {
    const { ContextHeader, NavigationByHeaderSelection } = Universal;
    const { LoginDetails } = Authentication;
    const { CommonFilterData } = CommonFilterDetails;
    const { progressOverTime, FluencyTabSelection } = classFluency
    const { ScFTabSelection } = School_FA_Reducer;
    return {
        ScFTabSelection,
        progressOverTime,
        FluencyTabSelection,
        ContextHeader,
        NavigationByHeaderSelection,
        LoginDetails,
        CommonFilterData
    };
};

export default connect(
    mapStateToProps,
    { UpDateFluencySubTab }
)(CFAMainChart);
