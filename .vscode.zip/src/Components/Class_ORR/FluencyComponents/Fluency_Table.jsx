import React, { PureComponent } from "react";
import { connect } from "react-redux";
import {
  SORT_FLUENCY_GRID_COLUMN,
  SORT_C_FLUENCY_DATA
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import {
  navigateToStudentReportFromClassReport
} from "../../../Redux_Actions/UniversalSelectorActions";
import {
  Chart_Enabled
} from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import { dataSorting } from "../../ReusableComponents/OrrReusableComponents";
import MakeSelectionForORR from '../../../Utils/MakeSelectionForORR';
import "../class-common.css";
import spinner from "../../../../public/assets/orr/rlp-screen/loader-white-bg.gif";
import ClassSidePanelPrint from '../../ReusableComponents/PrintOrrCharts/Class_SidePanel.jsx';

class FluencyTable extends PureComponent {
  constructor(props) {
    super(props);
    this.longTextTooltip = this.longTextTooltip.bind(this);
  }

  // tooltip for long text
  longTextTooltip(text) {
    if (text.length > 20) {
      return (
        <React.Fragment>
          {text.substr(0, 20)}...
          <div className="tooltip-container word-bk ">
            {text}
            <div className="tooltip-dot" />
          </div>
        </React.Fragment>
      )
    } else {
      return (text)
    }
  }
  assignClasses(Data, column, type) {
    if (Data.sortColumn === column && Data.sortType === type) {
      return " blueColor";
    } else {
      return "";
    }
  }

  //Onclick calling sort function and update the sort type and column in store
  fluencyGrid(sortColumn, sortType, actualArray) {
    document.getElementById("cfa").scrollTop = 0;
    this.sortData(sortColumn, sortType, actualArray);
    this.props.SORT_FLUENCY_GRID_COLUMN(sortColumn, sortType);
  }

  //function to sort array of data
  sortData(column, sortType, stdArray) {
    let sortedArray = [];
    if (stdArray.length != 0) {
      sortedArray = dataSorting(stdArray, column, sortType);
      this.props.SORT_C_FLUENCY_DATA(sortedArray);
    }
  }

  LineUnderActiveColumnFiled(Data, columnName, SortType) {
    return Data.sortColumn == columnName && Data.sortType == SortType
      ? "rt-td-active"
      : "";
  }

  classFluencyGridData(Data, tableData) {
    return (
      <div>
        <div
          className="student-list-header-rhs-sec rho-header-rhs-sec cFa-header-15-20"
          id="cfa"
        >
          <div className="student-column-list-rhs-sec cFa-header-15-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "lastName",
                Data.sortType
              )}
            >
              Students ({tableData && tableData.length})
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "lastName", "desc")
                }
                onClick={() => this.fluencyGrid("lastName", "desc", tableData)}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "lastName", "asc")
                }
                onClick={() => this.fluencyGrid("lastName", "asc", tableData)}
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec cFa-header-15-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "readingLevel",
                Data.sortType
              )}
            >
              Level
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "readingLevel", "desc")
                }
                onClick={() =>
                  this.fluencyGrid("readingLevel", "desc", tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "readingLevel", "asc")
                }
                onClick={() =>
                  this.fluencyGrid("readingLevel", "asc", tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec cFa-header-15-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "fluency",
                Data.sortType
              )}
            >
              Fluency
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "fluency", "desc")
                }
                onClick={() => this.fluencyGrid("fluency", "desc", tableData)}
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "fluency", "asc")
                }
                onClick={() => this.fluencyGrid("fluency", "asc", tableData)}
              >
                expand_less
              </i>
            </span>
          </div>
          <div className="student-column-list-rhs-sec cFa-header-15-20">
            <span
              className={this.LineUnderActiveColumnFiled(
                Data,
                "proficiency",
                Data.sortType
              )}
            >
              Proficiency
            </span>
            <span className="togglers">
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "proficiency", "desc")
                }
                onClick={() =>
                  this.fluencyGrid("proficiency", "desc", tableData)
                }
              >
                expand_more
              </i>
              <i
                className={
                  "cursor-pointer material-icons " +
                  this.assignClasses(Data, "proficiency", "asc")
                }
                onClick={() =>
                  this.fluencyGrid("proficiency", "asc", tableData)
                }
              >
                expand_less
              </i>
            </span>
          </div>
        </div>
        {/* <div className="student-list-body scroll-body cfa-scroll"> */}
        <div className={"student-list-body " +
          (this.props.scrollFlag && this.props.scrollFlag ? "print-body" : "cfa-scroll")}>
          {tableData &&
            tableData.map((tableDetails, value) => (
              <div className="pos-rel student-list-row-rhs-sec" key={value}>
                <div className="student-column-list-rhs-sec cursor-pointer cFa-header-15-20" onClick={() => {
                  this.props.Chart_Enabled({
                    showFluency: true,
                    showAccuracy: false
                  });
                  this.props.navigateToStudentReportFromClassReport(tableDetails, false)
                }} >
                  <span className="wb-break-all long-text-tooltip">
                    {this.longTextTooltip(tableDetails.firstName + ' ' + tableDetails.lastName)}
                  </span>
                </div>
                <div className="student-column-list-rhs-sec cFa-header-15-20">
                  <span>{tableDetails.readingLevel}</span>
                </div>
                <div className="student-column-list-rhs-sec cFa-header-15-20">
                  <span>{tableDetails.fluency} wcpm</span>
                </div>
                <div className="student-column-list-rhs-sec cFa-header-15-20">
                  <span>{tableDetails.proficiency}</span>
                </div>
              </div>
            ))}
        </div>
      </div>
    );
  }

  //to dispaly header section of grid part
  gridHeaderData(headerData) {
    let fluencyLevel = '';
    let readingLevel = [];
    let fluencyRanges = { '0-20': '≤20%', '21-80': '21-80%', '81-100': '>80%' }
    let fluencyLevelObject = new Set();
    let readingLevelObject = new Set();
    let record = [];
    let recordObject = new Set();

    if (headerData && headerData.length > 0) {
      headerData.map(
        (headerDetails, value) => (
          fluencyLevelObject.add(fluencyRanges[headerDetails.wcpmRange]),
          readingLevelObject.add(headerDetails.readingLevel),
          recordObject.add(headerDetails.monthName)
        )
      );

      let selectedFluency = Array.from(fluencyLevelObject);
      Object.keys(fluencyRanges).forEach((value, index) => {
        if (selectedFluency.indexOf(fluencyRanges[value]) > -1) {
          fluencyLevel = index > 0 ? fluencyLevel + ', ' + fluencyRanges[value] : fluencyLevel + fluencyRanges[value];
        }

      })

      readingLevel = this.displayHeader(Array.from(readingLevelObject).sort());
      record = Array.from(recordObject)
        .toString()
        .split("-")
        .reverse();
      return (
        <div>
          <div className="pull-left rt-left-heading">
            {/* onclick and on load main api should send the Reading target and Recent record*/}
            {this.props.cfaData.recentRecord
              ? "Recent Record: "
              : this.props.cfaData.firstRecord
                ? "First Record: "
                : ""}
            {this.props.cfaData.monthSelected}
          </div>
          <hr className="clearfix mb-12 cFa-clear-02-20" />
          <div className="reading-level-label mb-8 color-1">
            Fluency: <span>{fluencyLevel}</span>
          </div>
          <div className="reading-level-label color-2">
            Reading Level: <span>{readingLevel}</span>
          </div>
        </div>
      );
    }
  }

  //to display header data properly
  displayHeader(dataArray) {
    let array = [];

    dataArray.map((level, value) =>
      value < dataArray.length - 1
        ? array.push(level + ", ")
        : array.push(level + "")
    );

    return array;
  }

  render() {
    let classFluencyDataArray =  this.props.cfaData && this.props.cfaData.studentList;
    let Data = this.props.Data;
    let noData = this.props.selectBubblesFromReducer &&
      this.props.selectBubblesFromReducer["default"];

    if (!noData) {
      return (
        <div className="col-md-4 res-width cfa-right-chart cFa-chart-15-20">
          {this.props.apiLoader && this.props.apiLoader.apiLoading && (
            <React.Fragment>
              <div className="display-msg err-msg-alignment">
                <img src={spinner} alt="spinner" />
              </div>
            </React.Fragment>
          )}
          {this.props.apiLoader && !this.props.apiLoader.apiLoading && !this.props.apiLoader.apiError && this.props.cfaData.gridData && classFluencyDataArray && classFluencyDataArray.length !== 0 && (
            <React.Fragment>
              <div>
                <div>{this.gridHeaderData(this.props.cfaData.gridData)}</div>
              </div>

              <div className="pull-right clearfix new-mb-4 rt-label-txt rostered-txt-15-20">
                <span className="rt-label">
                  No. of students rostered: {this.props.cfaData.rosterCount}
                </span>
              </div>
              {this.props.scrollFlag && classFluencyDataArray && classFluencyDataArray.length > 0 &&
                <ClassSidePanelPrint
                  sideTableData={classFluencyDataArray}
                  Data={Data}
                  chartName={'cfa'}
                />}
              {!this.props.scrollFlag &&
                <div className="rhs-wrap">
                  <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                    <div className="student-list-table-main">
                      <div className="student-list-table-rhs-sec">
                        {classFluencyDataArray && this.classFluencyGridData(Data, classFluencyDataArray)}
                      </div>
                    </div>
                  </div>
                </div>}
            </React.Fragment>
          )}
          {this.props.apiLoader && this.props.apiLoader.apiError && (
            <React.Fragment>
              <div className="display-msg err-msg-alignment">
                <span>
                  The table did not load. Please select another choice from the chart on the left or try refreshing your screen.
                </span>
              </div>
            </React.Fragment>
          )}
          {classFluencyDataArray && classFluencyDataArray.length == 0 && (
            <MakeSelectionForORR />
          )}
        </div>
      );
    } else {
      return (
        <MakeSelectionForORR />
      );
    }
  }
}

const mapStateToProps = CommonFilterDetails => {
  const { CommonFilterData } = CommonFilterDetails;
  return { CommonFilterData };
};

export default connect(mapStateToProps, {
  SORT_FLUENCY_GRID_COLUMN,
  SORT_C_FLUENCY_DATA,
  navigateToStudentReportFromClassReport,
  Chart_Enabled
})(FluencyTable);