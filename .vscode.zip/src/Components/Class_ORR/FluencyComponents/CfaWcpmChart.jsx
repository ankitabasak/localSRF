import React, { PureComponent } from "react";
import { connect } from "react-redux";
import FluencyTable from "./Fluency_Table.jsx";
import ChartNotLoad from "../../../Utils/Chart_Not_Load";
import NoRecordsData from "../../../Utils/No_Data_Found";
import { CSVLink } from "react-csv";
import CsvIcon from '../../../../public/images/ic_save.svg';
import { getDateFormat, getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents'
import {
    Fluency_Chart_Table_API,
    Fluency_Chart_Api_Request,
    Update_Scroll_Data,
    API_LOADER,
    UPDATE_SELECTED_BOXES,
    SIDE_PANEL_API_LOADER,
    updateDropDownData,
    updateAllMonth,
    toggleDropDown,
    updateChartDetails,
    CFA_CSVDATA_DOWNLOAD_APICALL,
    CFA_CSVDATA_DOWNLOAD_RESET
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import { SHOW_HIDE_GROUPING } from "../../../Redux_Actions/C_GroupingAction.jsx";
import Spinner from "../../ReusableComponents/Spinner/Spinner.jsx";
import TimeOut from "../../ReusableComponents/Spinner/TimeOut.jsx";
import ClassFluencyChartComponent from "./ClassFluencyChartComponent/ClassFluencyChartComponent.jsx";
import NoRosterData from "../../../Utils/NoRoster.js";
import Group from '../Grouping_ORR/C_Grouping.jsx';
import PrintCfaWcpm from '../../ReusableComponents/PrintOrrCharts/C_FaWcpmPrint.jsx';
import titleImg from "../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg";

class FluencyWcpmChart extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            externalFilter: {},
            internalFilter: {},
            timeOut: false,
            sidepanelApiInRun: false
        };

        this.timeOut = this.timeOut.bind(this);
        this.getCFData = this.getCFData.bind(this);
        this.toggleHidden = this.toggleHidden.bind(this);
    }

    componentDidMount() {
        this.getCFData();
    }

    getCFData() {
        let ContextHeader = this.props.ContextHeader;
        this.setState({
            ...this.state,
            timeOut: false
        });
        if (this.props && !this.state.timeOut) {
            let dataRecordType = {
                allRecords: false,
                recentRecord: true
            };

            let data = {
                dataRecordType,
                ...getCommonHeaders(this.props, 'class'),
                value: "class"
            };
            this.props.Fluency_Chart_Api_Request(
                this.props.LoginDetails.JWTToken,
                data
            );
        }
    }

    getTableData(gridData) {
        let GD_Data = [];
        let gdFilter = [];
        if (gridData && gridData.length > 0) {
            if (gridData) {
                gridData.forEach(obj => {
                    GD_Data.push({
                        monthName: obj.monthName,
                        monthYear: obj.monthYear,
                        readingLevel: obj.readingLevel,
                        value: obj.value,
                        wcpmRange: obj.wcpmRange,
                        fluencyFrom: obj.fluencyFrom,
                        fluencyTo: obj.fluencyTo,
                        firstRecord: obj.firstRecord,
                        recentRecord: obj.recentRecord
                    });
                    gdFilter.push({
                        "fluencyFrom": obj.fluencyFrom,
                        "fluencyTo": obj.fluencyTo,
                        "readingLevel": obj.readingLevel,
                        "wcpmRange": obj.wcpmRange,
                        firstRecord: obj.firstRecord,
                        recentRecord: obj.recentRecord
                    })
                });
            }

            this.props.UPDATE_SELECTED_BOXES(GD_Data);
            let monthYear = GD_Data[0].monthName + ' ' + GD_Data[0].monthYear.substr(0, 4);
            let payLoad = {
                ...getCommonHeaders(this.props, 'class'),
                month_YYYY: monthYear,
                date_YYYY_MM: GD_Data[0].monthYear,
                gridFilter: gdFilter
            };
            // start side table spinner
            this.props.SIDE_PANEL_API_LOADER({ apiLoading: true, apiError: false, hideCreateGroup: true });

            if (!this.state.sidepanelApiInRun) {
                this.setState({ ...this.state, sidepanelApiInRun: true });
                clearTimeout(timeout);
                let timeout = setTimeout(() => {
                    this.props.Fluency_Chart_Table_API(
                        this.props.LoginDetails.JWTToken,
                        payLoad
                    );
                    this.setState({ ...this.state, sidepanelApiInRun: false });
                }, 1000);
            }
        } else {
            this.props.UPDATE_SELECTED_BOXES(GD_Data);
        }

    }

    // Download csv data
    downLoadCSVData() {
        if (this.props.FluencyTabSelection["wcpm"]) {
            this.props.CFA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: true } })
            let Req_Payload = {
                classChartType: {
                    "allRecordsAvgFlag": 0,
                    "chartName": "CFA"
                },
                ...getCommonHeaders(this.props, 'class')
            };
            this.props.CFA_CSVDATA_DOWNLOAD_APICALL(this.props.LoginDetails.JWTToken, Req_Payload);
        }
    }

    // handle timeout
    timeOut() {
        this.props.API_LOADER({
            isApiLoading: false,
            apiLoadFail: false,
            apiTimeOut: true
        });
    }
    // EXPAND AND COLLAPSE DATA UPDATE
    updateExpandCollapseData(dropDownSelection) {
        let dataListForGrid = {};
        Promise.resolve(this.props.updateChartDetails(dropDownSelection)).then((response) => {
            const cfaData = this.props.classFluencyChartData['recentMonthlyRecords'];
            const len = cfaData && cfaData.length;
            const selectedMonth = cfaData[len - 1];
            dataListForGrid[selectedMonth['monthName']] = []
            const bubList = Object.keys(selectedMonth['wcpmList']);
            if (bubList && bubList.length > 0) {
                bubList.forEach((xisRange) => {
                    let selctedMon = selectedMonth;
                    let bubbles = Object.keys(selctedMon['wcpmList'][xisRange]);
                    if (bubbles && bubbles.length > 0) {
                        bubbles.forEach((recordLevel) => {
                            dataListForGrid[selctedMon['monthName']].push({
                                firstRecord: selctedMon.firstRecord,
                                recentRecord: selctedMon.recentRecord,
                                monthYear: selctedMon['monthYear'],
                                wcpmRange: xisRange,
                                fluencyFrom: selctedMon['wcpmList'][xisRange][recordLevel].fluencyFrom,
                                fluencyTo: selctedMon['wcpmList'][xisRange][recordLevel].fluencyTo,
                                value: selctedMon['wcpmList'][xisRange][recordLevel].value,
                                firstRecord: selctedMon['firstRecord'],
                                recentRecord: selctedMon['recentRecord'],
                                monthName: selctedMon['monthName'],
                                readingLevel: recordLevel
                            })
                        })
                    }

                })
            }
            this.getTableData(dataListForGrid[selectedMonth['monthName']]);
        })

    }
    // toggle grouping
    toggleHidden(flag) {
        this.props.SHOW_HIDE_GROUPING(flag);
    }
    render() {
        if (this.props.FluencyTabSelection["wcpm"] &&
            this.props.CfaCsvDownload &&
            this.props.CfaCsvDownload['downloadInProgress'] &&
            this.props.CfaCsvDownload['csvData']) {
            setTimeout(() => {
                this.refs.groupCSV.link.click();
                this.props.CFA_CSVDATA_DOWNLOAD_RESET({ payLoad: { csvData: null, downloadInProgress: false } })
            }, 500)
        }
        let csvFileName = "ORR Data Generated " + getDateFormat() + " by " + this.props.ContextHeader.LoggedInUserName + " for " + this.props.ContextHeader.Roster_Tab.SelectedClass.name;

        return (
            <div>
                {this.props.NavigationByHeaderSelection.class && this.props.ContextHeader.Roster_Tab.SelectedClass.id ? (
                    <div>
                        {/* Class Fluency analysis chart */}
                        {this.props.classFluencyChartData &&
                            this.props.FluencyTabSelection["wcpm"] && !this.props.isApiLoading && (
                                <main>
                                    <section>
                                        <div className="container container-resolution cfa">
                                            <div className="row mt-10 mt-8 " id="testClass">
                                                {this.props.CfaCsvDownload && this.props.CfaCsvDownload['csvData'] &&
                                                    <CSVLink
                                                        ref="groupCSV"
                                                        headers={this.props.CfaCsvDownload['csvData'] && this.props.CfaCsvDownload['csvData']['header']}
                                                        data={this.props.CfaCsvDownload['csvData'] && this.props.CfaCsvDownload['csvData']['data']}
                                                        style={{ display: 'none' }}
                                                        // filename={"CFA_CSV.csv"}
                                                        filename={`${csvFileName}.csv`}
                                                    />}
                                                <div className="cls-csv-icon-alignment" onClick={() => !this.props.CfaCsvDownload['downloadInProgress'] && this.downLoadCSVData()}>
                                                    {this.props.CfaCsvDownload && this.props.CfaCsvDownload['downloadInProgress'] ?
                                                        <span className="csv_download_icon">
                                                            <i className="material-icons">autorenew</i>
                                                        </span> :
                                                        <span className="csv_download_icon">
                                                            <img src={CsvIcon} width="20" height="20" />
                                                        </span>}
                                                </div>
                                                {this.props.classFluencyChartData && (
                                                    <React.Fragment>
                                                        <ClassFluencyChartComponent
                                                            updateChartDetails={(dropDownSelection) => this.updateExpandCollapseData(dropDownSelection)}
                                                            monthRangeObj={this.props.monthRangeObj}
                                                            selAll={this.props.selAll}
                                                            toggleData={this.props.toggleData}
                                                            updateDetails={(data) => {
                                                                this.props.updateDropDownData(data)
                                                            }}
                                                            updateAllMonth={(data) => this.props.updateAllMonth(data)}
                                                            toggleDropDown={(data) => this.props.toggleDropDown(data)}
                                                            updateScrollData={data => {
                                                                this.props.Update_Scroll_Data(data);
                                                            }}
                                                            selectBubblesFromReducer={
                                                                this.props.classFluencySelectedBubbles
                                                            }
                                                            chartData={this.props.CF_Chart_Response}
                                                            CH_Data={this.props.classFluencyChartData}
                                                            getTableData={payload => {
                                                                this.getTableData(payload);
                                                            }}

                                                        />

                                                    </React.Fragment>
                                                )}
                                                {/* <FluencyTable cfaData={this.props.cfaGridData} /> */}
                                                {this.props.CF_Chart_Response && (
                                                    <FluencyTable
                                                        scrollFlag={false}
                                                        cfaData={this.props.cfaGridData}
                                                        Data={this.props.SortData}
                                                        chartData={this.props.CF_Chart_Response}
                                                        apiLoader={this.props.sidePanelApiLoader}
                                                        selectBubblesFromReducer={
                                                            this.props.classFluencySelectedBubbles
                                                        }
                                                    />
                                                )}


                                                {this.props.showGrouping &&
                                                    this.props.cfaGridData &&
                                                    this.props.FluencyTabSelection["wcpm"] && (
                                                        <Group
                                                            cancelModal={this.toggleHidden}
                                                            showGrouping={this.props.showGrouping}
                                                            gridData={this.props.cfaGridData.studentList}
                                                            Data={this.props.SortData}
                                                            subFluencyTab={this.props.FluencyTabSelection["wcpm"]}
                                                        />
                                                    )}
                                            </div>

                                            {this.props.CF_Chart_Response && this.props.classFluencyChartData &&
                                                this.props.cfaGridData.studentList && !this.props.sidePanelApiLoader.apiLoading &&
                                                <span className="class-cfawcpm-print-btn">
                                                    <PrintCfaWcpm
                                                        scrollFlag={false}
                                                        selectedFilter={this.props.CommonFilterData}
                                                        studentDetails={this.props.ContextHeader}
                                                        navSelected={this.props.NavigationByHeaderSelection}

                                                        selectBubblesFromReducer={
                                                            this.props.classFluencySelectedBubbles
                                                        }
                                                        chartData={this.props.CF_Chart_Response}
                                                        CH_Data={this.props.classFluencyChartData}
                                                        cfaData={this.props.cfaGridData}
                                                        Data={this.props.SortData}
                                                        apiLoader={this.props.sidePanelApiLoader}
                                                        monthRangeObj={this.props.monthRangeObj}
                                                        selAll={this.props.selAll}
                                                        toggleData={this.props.toggleData}
                                                    />
                                                </span>}
                                            {this.props.NavigationByHeaderSelection.class && !this.props.hideCreateGroup &&
                                                !this.props.NavigationByHeaderSelection.readingHistory ? (
                                                    <div className="group-title" onClick={() => this.toggleHidden(true)}>
                                                        <img src={titleImg} className="pull-left mlr-9" />
                                                        <span>
                                                            <b>Create Groups</b>
                                                        </span>
                                                    </div>
                                                ) : (
                                                    ""
                                                )}
                                        </div>
                                    </section>
                                </main>
                            )}
                        {this.props.isApiLoading && (
                            <Spinner
                                startSpinner={this.props.isApiLoading}
                                showTimeOut={this.timeOut}
                            />
                        )}
                        {this.props.apiTimeOut && (
                            <TimeOut
                                tryAgain={() => {
                                    this.getCFData();
                                }}
                            />
                        )}
                        {!this.props.CF_Chart_Response && this.props.apiLoadFail && (
                            <ChartNotLoad
                                tryAgain={() => {
                                    this.getCFData();
                                }}
                            />
                        )}
                        {this.props.noChartData && this.props.FluencyTabSelection["wcpm"] && (
                            <NoRecordsData NodataFound={"dataNotAvail"} />
                        )}
                    </div>
                ) : (
                        <NoRosterData />
                    )}
            </div>
        );
    }
}

const mapStateToProps = ({
    classFluency,
    Universal,
    CommonFilterDetails,
    Authentication,
    C_GroupingReducer
}) => {
    const {
        FluencyTabSelection,
        cfaGridData,
        CF_Chart_Response,
        classFluencySelectedBubbles,
        sidePanelApiLoader,
        classFluencyChartData,
        monthRangeObj,
        selAll,
        toggleData,
        updateDropDownData,
        updateAllMonth,
        toggleDropDown,
        updateChartDetails,
        isApiLoading,
        noChartData,
        apiLoadFail,
        apiTimeOut,
        SortData,
        hideCreateGroup,
        CfaCsvDownload
    } = classFluency;
    const { ContextHeader, NavigationByHeaderSelection } = Universal;
    const { CommonFilterData } = CommonFilterDetails;
    const { LoginDetails } = Authentication;
    const { showGrouping } = C_GroupingReducer;
    return {
        FluencyTabSelection,
        NavigationByHeaderSelection,
        ContextHeader,
        cfaGridData,
        CommonFilterData,
        CF_Chart_Response,
        classFluencySelectedBubbles,
        sidePanelApiLoader,
        classFluencyChartData,
        monthRangeObj,
        selAll,
        toggleData,
        updateDropDownData,
        updateAllMonth,
        toggleDropDown,
        updateChartDetails,
        isApiLoading,
        apiLoadFail,
        noChartData,
        apiTimeOut,
        SortData,
        LoginDetails,
        showGrouping,
        hideCreateGroup,
        CfaCsvDownload
    };
};

export default connect(mapStateToProps, {
    Fluency_Chart_Table_API,
    SIDE_PANEL_API_LOADER,
    Fluency_Chart_Api_Request,
    Update_Scroll_Data,
    API_LOADER,
    UPDATE_SELECTED_BOXES,
    SHOW_HIDE_GROUPING,
    updateDropDownData,
    updateAllMonth,
    toggleDropDown,
    updateChartDetails,
    CFA_CSVDATA_DOWNLOAD_APICALL,
    CFA_CSVDATA_DOWNLOAD_RESET,

})(FluencyWcpmChart);
