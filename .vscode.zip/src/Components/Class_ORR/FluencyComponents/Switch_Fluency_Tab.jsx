import React, { PureComponent } from "react";
import "../../../../public/css/style.css";
import { connect } from "react-redux";

import {
  SelectFluencyTab,
  Fluency_Chart_Api_Request,
  UpDateFluencySubTab
} from "../../../Redux_Actions/C_FlunecyActions.jsx";
import activeFpotIcon from "../../../../public/assets/orr/rlp-screen/Line-chart-tab_unselected.svg";
import InActiveFpotIcon from "../../../../public/assets/orr/rlp-screen/Line-chart-tab_selected.svg";
import activeCFA from "../../../../public/assets/orr/rlp-screen/ic_bubble-chart_unselected.svg";
import InActiveCFA from "../../../../public/assets/orr/rlp-screen/ic_bubble-chart_selected.svg";

class Switch_Fluency_Tab extends PureComponent {

  componentDidMount() {
    if (this.props.tabName['wcpm']) {
      this.props.UpDateFluencySubTab('wcpm');
    } else if (this.props.tabName['fpot']) {
      this.props.UpDateFluencySubTab('fpot');
    }
  }

  updateTabData(tabName) {
    this.props.SelectFluencyTab(tabName);
    if (tabName == "fpot") {
      if (!this.props.FluencyState.progressOverTime.firstRecordObj) {
        this.props.UpDateFluencySubTab("fpot");
      }
    } else if (tabName == "wcpm") {
      if (!this.props.FluencyState.CF_Chart_Response) {
        this.props.UpDateFluencySubTab("wcpm");
      }
    }
  }
  render() {
    let Nav = this.props.NavigationByHeaderSelection;
    let fluencytab = this.props.FluencyTabSelection;

    return (
      <div>
        <div className="container  switching-tabs fa-switch-tab cfa-switcing">
          <div className="row m-0 p-0">
            <div className="col-sm-12 tab-mid text-center tab-btm-bor pos-rel">
              <ul className="p-0 max-1020 tab-mb-0">
                {Nav.O_R_R !== "hide" && Nav.fluencyAnalysis === true ? (
                  <ul className="p-0 mx-auto max-1020 ipadTab-align">
                    <li
                      onClick={() =>
                        fluencytab.fpot ? null : this.updateTabData("fpot")
                      }
                      className={
                        fluencytab.fpot ? "active_tab" : "inactive_tab"
                      }
                    >
                      <img
                        className="mr-10"
                        src={
                          fluencytab.fpot ? activeFpotIcon : InActiveFpotIcon
                        }
                      />
                      Fluency Progress Over Time
                    </li>
                    <li
                      className={
                        fluencytab.wcpm ? "active_tab" : "inactive_tab"
                      }
                      onClick={() =>
                        fluencytab.wcpm ? null : this.updateTabData("wcpm")
                      }
                    >
                      <img
                        className="mr-10"
                        src={fluencytab.wcpm ? activeCFA : InActiveCFA}
                      />
                      Words Correct per Minute Progress
                    </li>
                  </ul>
                ) : null}
              </ul>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ Universal, classFluency }) => {
  const { NavigationByHeaderSelection } = Universal;
  const { FluencyTabSelection } = classFluency;
  const FluencyState = classFluency;
  return { NavigationByHeaderSelection, FluencyTabSelection, FluencyState };
};

export default connect(mapStateToProps, {
  SelectFluencyTab, UpDateFluencySubTab
})(Switch_Fluency_Tab);
