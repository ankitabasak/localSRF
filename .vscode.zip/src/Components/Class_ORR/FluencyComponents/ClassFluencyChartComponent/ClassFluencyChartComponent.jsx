import React, { PureComponent } from 'react';
import YAxisComponent from './Y_Axis_Component.jsx';
import ClassFluencyMonthChart from './ClassFluencyMonthChart.jsx';
import '../ClassFluencyChartComponent/ClassFluencyStyles.css';

class ClassFluencyChartComponent extends PureComponent {
  constructor(props) {
    super(props);

    this.scrollUp = this.scrollUp.bind(this); //sliceArray
    this.scrollDown = this.scrollDown.bind(this);
    this.scrollToBottom = this.scrollToBottom.bind(this);
    this.scrollToTop = this.scrollToTop.bind(this);
    // Horizontal scroll binding
    this.scrollLeft = this.scrollLeft.bind(this); //sliceArray
    this.scrollExtremeLeft = this.scrollExtremeLeft.bind(this);
    this.scrollRight = this.scrollRight.bind(this);
    this.scrollExtremeRight = this.scrollExtremeRight.bind(this);
    this.sliceArray = this.sliceArray.bind(this);
  }

  // fetch table data for selected bubble

  bubblesSelected(bubble) {
    this.props.getTableData(bubble);
  }

  // contsruct recent records
  getRecentRecorde(arrItems, index) {
    if (arrItems.length > 0) {
      if (this.props.CH_Data.mobileViewLength == 1) {
        return [arrItems[index], arrItems[index + 1]];
      } else {
        return [arrItems[index - 1], arrItems[index], arrItems[index + 1]];
      }

    }
  }

  // return sliced array
  sliceArray(array, arrayIndex) {
    return array.slice(arrayIndex, arrayIndex + 5);
  }
  // Y axis scroll functionality
  scrollUp() {
    // update state on up scroll
    if (this.props.CH_Data.scrollIndex > 0) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          YaxisDataRange: this.sliceArray(
            this.props.CH_Data.YaxisData,
            this.props.CH_Data.scrollIndex - 1
          ),
          ['scrollIndex']: this.props.CH_Data.scrollIndex - 1
        }
      });
    }
  }

  // Scrolling down

  scrollDown() {
    if (
      this.props.CH_Data.scrollIndex <
      this.props.CH_Data.YaxisData.length - 5
    ) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          YaxisDataRange: this.sliceArray(
            this.props.CH_Data.YaxisData,
            this.props.CH_Data.scrollIndex + 1
          ),
          ['scrollIndex']: this.props.CH_Data.scrollIndex + 1
        }
      });
    }
  }

  scrollToBottom() {
    if (
      this.props.CH_Data.scrollIndex <
      this.props.CH_Data.YaxisData.length - 5
    ) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          YaxisDataRange: this.sliceArray(
            this.props.CH_Data.YaxisData,
            this.props.CH_Data.YaxisData.length - 5
          ),
          ['scrollIndex']: this.props.CH_Data.YaxisData.length - 5
        }
      });
    }
  }
  scrollToTop() {
    if (this.props.CH_Data.scrollIndex > 0) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          YaxisDataRange: this.sliceArray(this.props.CH_Data.YaxisData, 0),
          ['scrollIndex']: 0
        }
      });
    }
  }
  // Horizontal scroll
  scrollLeft() {
    if (this.props.CH_Data.xAxisScrollIndex > 1) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          xAxisScrollIndex: this.props.CH_Data.xAxisScrollIndex - 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.CH_Data.monthlyRecordData,
            this.props.CH_Data.xAxisScrollIndex - (this.props.CH_Data.mobileViewLength == 1 ? 2 : 1)
          )
        }
      });
    }
  }
  scrollExtremeLeft() {
    if (this.props.CH_Data.xAxisScrollIndex > 1) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          xAxisScrollIndex: 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.CH_Data.monthlyRecordData,
            1
          )
        }
      });
    }
  }

  scrollRight() {
    if (
      this.props.CH_Data.xAxisScrollIndex <
      this.props.CH_Data.monthlyRecordData.length - this.props.CH_Data.mobileViewLength
    ) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          xAxisScrollIndex: this.props.CH_Data.xAxisScrollIndex + 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.CH_Data.monthlyRecordData,
            this.props.CH_Data.xAxisScrollIndex + this.props.CH_Data.mobileViewLength - 1
          )
        }
      });
    }
  }
  scrollExtremeRight() {
    if (
      this.props.CH_Data.xAxisScrollIndex <
      this.props.CH_Data.monthlyRecordData.length - this.props.CH_Data.mobileViewLength
    ) {
      this.props.updateScrollData({
        ['classFluencyChartData']: {
          ...this.props.CH_Data,
          xAxisScrollIndex: this.props.CH_Data.monthlyRecordData.length - this.props.CH_Data.mobileViewLength,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.CH_Data.monthlyRecordData,
            this.props.CH_Data.monthlyRecordData.length - this.props.CH_Data.mobileViewLength
          )
        }
      });
    }
  }

  render() {


    return (
      <div className="col-lg-7 res-width-8 cfa-lft-box cFa-res-width-15-20">
        <p className="reading-level-text pull-left print-cfwcpm-rl">Reading Level</p>

        <div className="wrap pos-rel">
          <div className="rhs-line" />
          <div className="rhs-line1" />
          <div className="rhs-line2" />
          <div className="rhs-line3" />
          <YAxisComponent
            axisData={this.props.CH_Data}
            scrollUp={this.scrollUp}
            scrollDown={this.scrollDown}
            scrollToBottom={this.scrollToBottom}
            scrollToTop={this.scrollToTop}
            scrollLeft={this.scrollLeft}
            scrollExtremeLeft={this.scrollExtremeLeft}
          />

          <ClassFluencyMonthChart
            updateChartDetails={(data) => this.props.updateChartDetails(data)}
            monthRangeObj={this.props.monthRangeObj}
            selAll={this.props.selAll}
            toggleData={this.props.toggleData}
            updateDetails={(data) => { this.props.updateDetails(data) }}
            updateAllMonth={(data) => this.props.updateAllMonth(data)}
            toggleDropDown={(data) => this.props.toggleDropDown(data)}
            monthData={this.props.CH_Data}
            bubblesSelected={selectedBubble => {
              this.bubblesSelected(selectedBubble);
            }}
            bubsFromReducer={this.props.selectBubblesFromReducer}
            scrollRight={this.scrollRight}
            scrollExtremeRight={this.scrollExtremeRight}
          />
        </div>
      </div>
    );
  }
}

export default ClassFluencyChartComponent;
