import React, { PureComponent } from 'react';
import { getBubbleConfig } from './../bubbleConfiguration';
import rightScroll from '../../../../../public/assets/orr/rlp-screen/x-next.svg';
import rightScrollActive from '../../../../../public/assets/orr/rlp-screen/x-next-active.svg';
import rightExtremeScroll from '../../../../../public/assets/orr/rlp-screen/x-next-end.svg';
import rightExtremeScrollActive from '../../../../../public/assets/orr/rlp-screen/x-next-end-active.svg';
import Compare_Chart_Data from '../../../ORR_DropDown/Compare_Data.jsx'
class ClassFluencyMonthChart extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      selectedBubbles: {},
      apiPayload: {},
      bgColor: { '0-20': '#d5eaf2', '21-80': '#bfe0eb', '81-100': '#aad6e5' }
    };

    this.getBubbleSize = this.getBubbleSize.bind(this);
    this.bubblesSelected = this.bubblesSelected.bind(this);
    this.showToolTip = this.showToolTip.bind(this);
  }

  getBubbleSize(value) {
    if (value) {
      let data = getBubbleConfig(value);
      return {
        height: data.bubbleSize,
        width: data.bubbleSize,
        lineHeight: data.bubbleSize,
        fontSize: data.fontSize
      };
    }
  }

  bubblesSelected(bubble) {
    let selectedBubbles = this.props.bubsFromReducer;
    //let selectedBubbles = this.state.selectedBubbles;

    // this.props.bubsFromReducer;

    if (selectedBubbles[bubble.monthName]) {
      let dupBubIdx = this.isDuplicateBubble(
        bubble,
        selectedBubbles[bubble.monthName]
      );
      if (dupBubIdx != -1) {
        selectedBubbles[bubble.monthName].splice(dupBubIdx, 1);
      } else {
        selectedBubbles[bubble.monthName].push(bubble);
      }
    } else {
      selectedBubbles = {};
      selectedBubbles[bubble.monthName] = [bubble];
    }

    this.setState({ ...this.state, ['selectedBubbles']: selectedBubbles });

    this.props.bubblesSelected(selectedBubbles[bubble.monthName]);
  }

  // check for duplicate bubble
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          obj.wcpmRange === bubble.wcpmRange &&
          obj.readingLevel === bubble.readingLevel
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  getBubBackColor(bubble) {
    ;
    let listItems = this.props.bubsFromReducer[bubble.month];
    //  let listItems = this.state.selectedBubbles[bubble.month];
    let style = this.getBubbleSize(bubble.value);

    if (listItems) {
      listItems.forEach(obj => {
        if (
          obj.wcpmRange === bubble.wcpmRange &&
          obj.readingLevel === bubble.readingLevel
        ) {
          style = {
            ...style,
            ['backgroundColor']: this.state.bgColor[bubble.wcpmRange],
            border: 'none',
            boxShadow: 'inset 0 0 6px -1px rgba(0,0,0,0.5)'
          };
          return;
        }
      });
    }
    return style;
  }
  showToolTip_ttl(passage) {
    return (
      <div className="hover-crb cfa-hover ttl-std word-bk">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }

  showToolTip(passage) {
    return (
      <div className="hover-crb cfa-hover word-bk">
        {passage}
        <div className="tooltip-dot" />
      </div>
    );
  }
  render() {

    if (this.props.monthData && this.props.monthData.monthlyRecordData) {

      return (
        <div className="graph-content  pull-left pos-rel no-bord ml-6 cfa-month cFa-graph-content-15-20">
          <Compare_Chart_Data
            summaryFlag={this.props.summaryFlag}
            updateChartDetails={(data) => this.props.updateChartDetails(data)}
            monthRangeObj={this.props.monthRangeObj}
            selAll={this.props.selAll}
            toggleData={this.props.toggleData}
            updateDetails={(data) => {
              this.props.updateDetails(data)
            }}
            updateAllMonth={(data) => this.props.updateAllMonth(data)}
            toggleDropDown={(data) => this.props.toggleDropDown(data)}
          />
          <p className="date-txt pull-left">Month</p>
          {this.props.monthData &&
            this.props.monthData.recentMonthlyRecords.map((data, index) => {
              return (
                <div className="first-coloumn pull-left colm-fm" key={index}>
                  <div className="top-slide-section">
                    <span>
                      {data.firstRecord
                        ? 'First Record'
                        : data.recentRecord
                          ? 'Recent Record'
                          : ''}
                    </span>
                  </div>
                  <div className="up-sec">
                    <div className="sub-first-column pull-left pos-rel cFmc-15-20">
                      <div className="block-sec">
                        <ul>
                          {this.props.monthData.YaxisDataRange.map(
                            (readingLevel, lvlIndex) => {
                              return (
                                <li key={lvlIndex}>
                                  <span>
                                    {data.totalNoOfStudents[readingLevel]
                                      ? data.totalNoOfStudents[readingLevel] +
                                      '%'
                                      : ''}
                                  </span>
                                </li>
                              );
                            }
                          )}
                        </ul>
                      </div>
                      <div className="total-stu crb-hover-container">
                        <p>Total Students</p>
                        {this.showToolTip_ttl(
                          "Total Students Rostered"
                        )}
                      </div>
                      <div className="wcpm-section wcpm-bg">
                        <p>%</p>
                      </div>
                    </div>
                    <div className="sub-second-column pull-left pos-rel">
                      <div className="block-sec-2nd">
                        <ul>
                          {this.props.monthData.YaxisDataRange.map(
                            (readingLevel, lvlIndex) => {
                              if (data.wcpmList['0-20']) {
                                return (
                                  <li key={lvlIndex}>
                                    <span
                                      onClick={() => {

                                        this.bubblesSelected({
                                          wcpmRange: '0-20',
                                          monthYear: data.monthYear,
                                          readingLevel: readingLevel,
                                          fluencyFrom: data.wcpmList['0-20'][readingLevel]['fluencyFrom'],
                                          fluencyTo: data.wcpmList['0-20'][readingLevel]['fluencyTo'],
                                          value:
                                            data.wcpmList['0-20'][readingLevel]['value'],
                                          monthName: data.monthName,
                                          recentRecord: data.recentRecord,
                                          firstRecord: data.firstRecord
                                        });
                                      }}
                                      className={
                                        data.wcpmList['0-20'][readingLevel]
                                          ? 'default-bubble first-bubble '
                                          : ''
                                      }
                                      style={this.getBubBackColor({
                                        wcpmRange: '0-20',
                                        readingLevel: readingLevel,
                                        value:
                                          data.wcpmList['0-20'][readingLevel] && data.wcpmList['0-20'][readingLevel]['value'],
                                        month: data.monthName
                                      })}
                                    >
                                      {/* <span>
                                          {this.showCriteriaName(
                                            crbListItem["sourceCriteriaName"]
                                          )}
                                        </span> */}
                                      {data.wcpmList['0-20'][readingLevel]
                                        ? data.wcpmList['0-20'][readingLevel]['value'] +
                                        '%'
                                        : ''}
                                    </span>
                                  </li>
                                );
                              } else {
                                return (
                                  <li key={lvlIndex}>
                                    <span />
                                  </li>
                                );
                              }
                            }
                          )}
                        </ul>
                      </div>

                      <div className="wcpm-section wcpm-bg1 crb-hover-container ">
                        <p>{'≤20%'}</p>
                        {this.showToolTip(
                          "bottom 20th percentile"
                        )}
                      </div>
                    </div>
                    <div className="sub-third-column pull-left pos-rel">
                      <div className="block-sec-3rd">
                        <ul>
                          {this.props.monthData.YaxisDataRange.map(
                            (readingLevel, lvlIndex) => {
                              if (data.wcpmList['21-80']) {
                                return (
                                  <li key={lvlIndex}>
                                    <span
                                      onClick={() => {

                                        this.bubblesSelected({
                                          wcpmRange: '21-80',
                                          monthYear: data.monthYear,
                                          readingLevel: readingLevel,
                                          fluencyFrom: data.wcpmList['21-80'][readingLevel]['fluencyFrom'],
                                          fluencyTo: data.wcpmList['21-80'][readingLevel]['fluencyTo'],
                                          value:
                                            data.wcpmList['21-80'][readingLevel]['value'],
                                          monthName: data.monthName,
                                          recentRecord: data.recentRecord,
                                          firstRecord: data.firstRecord
                                        });
                                      }}
                                      className={
                                        data.wcpmList['21-80'][readingLevel]
                                          ? 'default-bubble second-bubble '
                                          : ''
                                      }
                                      style={this.getBubBackColor({
                                        wcpmRange: '21-80',
                                        readingLevel: readingLevel,
                                        value:
                                          data.wcpmList['21-80'][readingLevel] && data.wcpmList['21-80'][readingLevel]['value'],
                                        month: data.monthName
                                      })}
                                    >
                                      {data.wcpmList['21-80'][readingLevel]
                                        ? data.wcpmList['21-80'][
                                        readingLevel
                                        ]['value'] + '%'
                                        : ''}
                                    </span>
                                  </li>
                                );
                              } else {
                                return (
                                  <li key={lvlIndex}>
                                    <span />
                                  </li>
                                );
                              }
                            }
                          )}
                        </ul>
                      </div>
                      <div className="wcpm-section wcpm-bg2 crb-hover-container cfa-hover">
                        <p>{'21-80%'}</p>
                        {this.showToolTip(
                          "majority percentile"
                        )}
                      </div>
                    </div>
                    <div className="sub-fourth-column pull-left pos-rel">
                      <div className="fourth-line">
                        <div className="top-small-strip">
                          <div className="top-lhs-strip-bar"></div>
                          <div className="top-rhs-strip-bar"></div>
                        </div>
                        <div className="chart-line-lhs-adj"></div>
                        <div className="chart-line-rhs-adj"></div>
                      </div>
                      <div className="block-sec-4th">
                        <ul>
                          {this.props.monthData.YaxisDataRange.map(
                            (readingLevel, lvlIndex) => {
                              if (data.wcpmList['81-100']) {
                                return (
                                  <li key={lvlIndex}>
                                    <span
                                      onClick={() => {

                                        this.bubblesSelected({
                                          wcpmRange: '81-100',
                                          monthYear: data.monthYear,
                                          readingLevel: readingLevel,
                                          fluencyFrom: data.wcpmList['81-100'][readingLevel]['fluencyFrom'],
                                          fluencyTo: data.wcpmList['81-100'][readingLevel]['fluencyFrom'],
                                          value:
                                            data.wcpmList['81-100'][readingLevel]['value'],
                                          monthName: data.monthName,
                                          recentRecord: data.recentRecord,
                                          firstRecord: data.firstRecord
                                        });
                                      }}
                                      className={
                                        data.wcpmList['81-100'][readingLevel]
                                          ? 'default-bubble last-bubble'
                                          : ''
                                      }
                                      style={this.getBubBackColor({
                                        wcpmRange: '81-100',
                                        value:
                                          data.wcpmList['81-100'][readingLevel] && data.wcpmList['81-100'][readingLevel]['value'],
                                        readingLevel: readingLevel,
                                        month: data.monthName
                                      })}
                                    >
                                      {data.wcpmList['81-100'][readingLevel]
                                        ? data.wcpmList['81-100'][readingLevel]['value'] +
                                        '%'
                                        : ''}
                                    </span>
                                  </li>
                                );
                              } else {
                                return (
                                  <li key={lvlIndex}>
                                    <span />
                                  </li>
                                );
                              }
                            }
                          )}
                        </ul>
                      </div>
                      <div className="wcpm-section wcpm-bg3 crb-hover-container cfa-hover">
                        <p>{'>80%'}</p>
                        {this.showToolTip(
                          "top 20th percentile"
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="month-section">
                    <span>{data.monthName}</span>
                  </div>
                </div>
              );
            })}
          <div className="last-col-wrap">
            <div className="last-col-lft-bor">
              <div className="last-line-lhs-adj"></div>
              <div className="last-line-rhs-adj"></div>
              <div className="last-line-top-rhs-adj"></div>
            </div>
            <div className="last-col">
              <p>Fluency (wcpm) Progress Over Time</p>
            </div>
            <div className="btm-arrow-lft">
              <div className="btm-ic-rhs-last" onClick={this.props.scrollRight}>
                {this.props.monthData.xAxisScrollIndex <
                  this.props.monthData.monthlyRecordData.length - this.props.monthData.mobileViewLength ? (
                    <img src={rightScrollActive} className="cursor-pointer" />
                  ) : (
                    <img src={rightScroll} className="no-pointer" />
                  )}
              </div>
              <div
                className="btm-ic-rhs-prev"
                onClick={this.props.scrollExtremeRight}
              >
                {this.props.monthData.xAxisScrollIndex <
                  this.props.monthData.monthlyRecordData.length - this.props.monthData.mobileViewLength ? (
                    <img
                      src={rightExtremeScrollActive}
                      className="cursor-pointer"
                    />
                  ) : (
                    <img src={rightExtremeScroll} className="no-pointer" />
                  )}
              </div>
            </div>
          </div>

          <div className="clearfix" />
        </div>
      );
    } else {
      return <div>No Data Found</div>;
    }
  }
}

export default ClassFluencyMonthChart;
