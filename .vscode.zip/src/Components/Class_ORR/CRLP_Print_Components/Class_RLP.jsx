import React, { PureComponent } from "react";
import "../../ORR/FilterComponents/Filter.css";
import {
  backgroundColor,
  axisColor,
  bubbleColor,
  setBubbleConfiguration,
  bubbleBackgroundOnSelection
} from "./Graph_Color";
import "../ChartComponents/Class_RLP.css";
import Compare_Chart_Data from '../../ORR_DropDown/Compare_Data.jsx'

class Class_RLP extends PureComponent {
  constructor(props) {
    super(props);
    this.myRef = React.createRef();
    this.state = {
      previousIcon: false,
      firstIcon: false,
      nextIcon: true,
      lastIcon: true,

      bottomIcon: true,
      bottomLastIcon: true,
      topFirstIcon: false,
      topIcon: false,

      class_rlp_object: null,
      selectedBubbles: {}
    };
    this.topIndex = 0;
    this.bottomIndex = 5;
    this.leftIndex = 0;
    this.rightIndex = 5;

    this.scrollUp = this.scrollUp.bind(this);
    this.scrollDown = this.scrollDown.bind(this);

    // Horizontal scroll binding
    this.scrollLeft = this.scrollLeft.bind(this); //sliceArray
    this.scrollExtremeLeft = this.scrollExtremeLeft.bind(this);
    this.scrollRight = this.scrollRight.bind(this);
    this.scrollExtremeRight = this.scrollExtremeRight.bind(this);

    this.sliceArray = this.sliceArray.bind(this);
    this.bubblesSelected = this.bubblesSelected.bind(this);
    this.onLoadSelectBubble = this.onLoadSelectBubble.bind(this);
    this.bubblesSelectedForReadingTarget = this.bubblesSelectedForReadingTarget.bind(
      this
    );
    this.getBubbleBackgroundColorOnSelection = this.getBubbleBackgroundColorOnSelection.bind(
      this
    );
  }
  componentDidMount() {
    this.setState({
      ...this.state,
      ["selectedBubbles"]: this.props.selectedBubs || {}
    });
  }
  // return sliced array
  sliceArray(array, arrayIndex) {
    return array.slice(arrayIndex, arrayIndex + 5);
  }
  getBackgroundColorYAxis(value) {
    if (value) {
      var bgColorValue = [];
      bgColorValue = backgroundColor(value);
      return bgColorValue;
    }
  }
  getAxisColorYAxis(value) {
    if (value) {
      var axisColorValue;
      axisColorValue = axisColor(value);
      return axisColorValue;
    }
  }
  getBubbleBackgroundColorOnSelection(value) {
    if (value) {
      var bubbleBackgroundValue;
      bubbleBackgroundValue = bubbleBackgroundOnSelection(value);
      return bubbleBackgroundValue;
    }
  }
  getBubbleColor(value) {
    if (value) {
      var bubbleColorValue;
      bubbleColorValue = bubbleColor(value);
      return bubbleColorValue;
    }
  }
  getBubbleConfiguration(value) {
    if (value) {
      var bubbleConf;
      bubbleConf = setBubbleConfiguration(value);
      return bubbleConf;
    } else {
      return 0;
    }
  }
  // Y axis scroll functionality
  scrollUp() {
    // update state on up scroll
    if (this.props.class_rlp_object.scrollIndex > 0) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          YaxisDataRange: this.sliceArray(
            this.props.class_rlp_object.YaxisData,
            this.props.class_rlp_object.scrollIndex - 1
          ),
          ["scrollIndex"]: this.props.class_rlp_object.scrollIndex - 1
        }
      });
    }
  }

  // Scrolling down
  scrollDown() {
    if (
      this.props.class_rlp_object.scrollIndex <
      this.props.class_rlp_object.YaxisData.length - 5
    ) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          YaxisDataRange: this.sliceArray(
            this.props.class_rlp_object.YaxisData,
            this.props.class_rlp_object.scrollIndex + 1
          ),
          ["scrollIndex"]: this.props.class_rlp_object.scrollIndex + 1
        }
      });
    }
  }

  scrollToBottom() {
    if (
      this.props.class_rlp_object.scrollIndex <
      this.props.class_rlp_object.YaxisData.length - 5
    ) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          YaxisDataRange: this.sliceArray(
            this.props.class_rlp_object.YaxisData,
            this.props.class_rlp_object.YaxisData.length - 5
          ),
          ["scrollIndex"]: this.props.class_rlp_object.YaxisData.length - 5
        }
      });
    }
  }

  scrollToTop() {
    if (this.props.class_rlp_object.scrollIndex > 0) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          YaxisDataRange: this.sliceArray(
            this.props.class_rlp_object.YaxisData,
            0
          ),
          ["scrollIndex"]: 0
        }
      });
    }
  }
  // Horizontal scroll
  scrollLeft() {
    if (this.props.class_rlp_object.xAxisScrollIndex > 1) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          xAxisScrollIndex: this.props.class_rlp_object.xAxisScrollIndex - 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.class_rlp_object.monthlyRecordData,
            this.props.class_rlp_object.xAxisScrollIndex - 1,
            "left"
          )
        }
      });
    }
  }
  scrollExtremeLeft() {
    if (this.props.class_rlp_object.xAxisScrollIndex > 1) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          xAxisScrollIndex: 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.class_rlp_object.monthlyRecordData,
            1,
            "exleft"
          )
        }
      });
    }
  }

  scrollRight() {
    if (
      this.props.class_rlp_object.xAxisScrollIndex <
      this.props.class_rlp_object.monthlyRecordData.length - 1
    ) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          xAxisScrollIndex: this.props.class_rlp_object.xAxisScrollIndex + 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.class_rlp_object.monthlyRecordData,
            this.props.class_rlp_object.xAxisScrollIndex,
            "right"
          )
        }
      });
    }
  }
  scrollExtremeRight() {
    if (
      this.props.class_rlp_object.xAxisScrollIndex <
      this.props.class_rlp_object.monthlyRecordData.length - 1
    ) {
      this.props.updateScrollData({
        ["class_rlp_object"]: {
          ...this.props.class_rlp_object,
          xAxisScrollIndex:
            this.props.class_rlp_object.monthlyRecordData.length - 1,
          recentMonthlyRecords: this.getRecentRecorde(
            this.props.class_rlp_object.monthlyRecordData,
            this.props.class_rlp_object.monthlyRecordData.length - 1,
            "exright"
          )
        }
      });
    }
  }
  bubblesSelected(bubble) {
    let selectedBubbles = this.state.selectedBubbles;

    if (selectedBubbles[bubble.month]) {
      let dupBubIdx = this.isDuplicateBubble(
        bubble,
        selectedBubbles[bubble.month]
      );
      if (dupBubIdx != -1) {
        selectedBubbles[bubble.month].splice(dupBubIdx, 1);
      } else {
        selectedBubbles[bubble.month].push(bubble);
      }
    } else {
      selectedBubbles = {};
      selectedBubbles[bubble.month] = [bubble];
    }
    this.setState({ ...this.state, ["selectedBubbles"]: selectedBubbles });
    this.props.bubblesSelected(selectedBubbles[bubble.month]);
    //  this.props.getBubbleBackgroundColorOnSelection(selectedBubbles[bubble.month]);
  }
  bubblesSelectedForReadingTarget(bubble) {
    this.setState({ ...this.state, ["selectedBubbles"]: {} });
    this.props.bubblesSelectedForReadingTarget(bubble);
    // this.getBubbleBackgroundColorOnSelection(bubble);
  }

  // contsruct recent records
  getRecentRecorde(arrItems, index, scroll) {
    // need remove after expand collapse implementations
    if (arrItems.length > 0) {
      if (scroll === "right" && index !== 0) {
        return [arrItems[index], arrItems[index + 1]];
      } else if (scroll === "left" && index !== 0) {
        return [arrItems[index - 1], arrItems[index]];
      } else if (scroll === "exright") {
        return [arrItems[index - 1], arrItems[index]];
      } else if (scroll === "exleft") {
        return [arrItems[index - 1], arrItems[index]];
      }
    }
  }
  // check for duplicate bubble
  isDuplicateBubble(bubble, bubList) {
    let duplicateBubIdx = -1;
    if (bubList) {
      bubList.forEach((obj, index) => {
        if (
          obj.type === bubble.type &&
          obj.readingLevel === bubble.readingLevel
        ) {
          return (duplicateBubIdx = index);
        }
      });
    }
    return duplicateBubIdx;
  }
  getBubBackColor(bubble) {
    let listItems = this.state.selectedBubbles[bubble.month];
    let style = { color: "", border: "2px solid", padding: "", boxShadow: "" };
    if (listItems) {
      listItems.forEach(obj => {
        if (
          obj.type === bubble.type &&
          obj.readingLevel === bubble.readingLevel
        ) {
          style = {
            color: this.getBubbleBackgroundColorOnSelection(obj.type),
            border: "none",
            padding: "2px",
            boxShadow: "inset 0 0 2px 1px rgba(0,0,0,0.1)"
          };
          return;
        }
      });
    }
    return style;
  }
  onLoadSelectBubble() {
    let recentRecordExist = this.props.class_rlp_object.recentMonthlyRecords.some(
      data => data.recentRecord === true
    );
    this.props.class_rlp_object.recentMonthlyRecords.forEach((data, i) => {
      if (recentRecordExist && data.recentRecord) {
        this.props.class_rlp_object.recentMonthlyRecords[
          i
        ].totalStudentRecord.forEach((element, index) => {
          let bubbleType;
          if (
            Object.keys(data.frustrationalRecordData).length !== 0 &&
            Object.keys(data.frustrationalRecordData).indexOf(
              element.recordLevel
            ) >= 0
          ) {
            bubbleType = "Frustrational";
          } else if (
            Object.keys(data.independentRecordData).length !== 0 &&
            Object.keys(data.independentRecordData).indexOf(
              element.recordLevel
            ) >= 0
          ) {
            bubbleType = "Independent";
          } else if (
            Object.keys(data.instructionalRecordData).length !== 0 &&
            Object.keys(data.instructionalRecordData).indexOf(
              element.recordLevel
            ) >= 0
          ) {
            bubbleType = "Instructional";
          }
          if (recentRecordExist && data.recentRecord) {
            this.bubblesSelected({
              type: bubbleType,
              readingLevel: element.recordLevel,
              month: data.month,
              monthYear: data.monthYear,
              recentRecord: data["recentRecord"],
              firstRecord: data["firstRecord"]
            });
          } else {
            this.bubblesSelected({
              type: bubbleType,
              readingLevel: element.recordLevel,
              month: data.month,
              monthYear: data.monthYear,
              recentRecord: data["recentRecord"],
              firstRecord: data["firstRecord"]
            });
          }
        });
      }
    });
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.selectedBubs) {
      this.setState({
        ...this.state,
        ["selectedBubbles"]: nextProps.selectedBubs
      });
    }

    if (
      nextProps.class_rlp_object.monthlyRecordData !==
      this.props.class_rlp_object.monthlyRecordData
    ) {
      // // this.props.clearBubbles();
      // this.setState({
      //   selectedBubbles: {}
      // // });
      // this.setState({
      //   ...this.state,
      //   ['selectedBubbles']: this.props.selectedBubbles
      // });
      // setTimeout(() => {
      //   this.onLoadSelectBubble();
      // }, 1000);
    }
    // if (this.props.class_rlp_object) {
    //   this.setState({
    //     ...this.state,
    //      ["class_rlp_object"]: getConstructedData(this.props.data)
    //   });
    // }
  }

  render(props) {
    if (this.props.class_rlp_object) {
      return (
        <div className="col-lg-7 res-width-8 class_rlp cRlp-width-21-20">
          <p className="reading-level-text-crlp pull-left print-align-rl">Reading Level</p>
          <div className="wrap-crlp pos-rel popup-crlp-wdt cRlp-popup-21-20">
            <p className="crlp-chart-btm-heading cRlp-month-05-20">Month</p>
            <div className="rhs-line-crlp cRlp-line-21-20" />
            <div className="rhs-line1-crlp" />
            <div className="rhs-line2-crlp" />
            <div className="rhs-line3-crlp" />
            <div>
              <Compare_Chart_Data
                updateChartDetails={(data) => this.props.updateChartDetails(data)}
                monthRangeObj={this.props.monthRangeObj}
                selAll={this.props.selAll}
                toggleData={this.props.toggleData}
                updateDetails={(data) => this.props.updateDropDownDetails(data)}
                updateAllMonth={(data) => this.props.updateAllMonth(data)}
                toggleDropDown={(data) => this.props.toggleDropDown(data)}
              />
            </div>
            <div className="cRlp-21-20 reading-level-section-crlp pull-left clearfix">
              <div
                className={
                  this.props.class_rlp_object.scrollIndex > 0
                    ? "y-top-end-active"
                    : "y-top-end"
                }
                onClick={() => this.scrollToTop()}
              />
              <div
                className={
                  this.props.class_rlp_object.scrollIndex > 0
                    ? "y-top-active"
                    : "y-top"
                }
                onClick={() => this.scrollUp()}
              />
              <div
                id="yAxis" className="cRlp-yaxis-21-20"
                style={{ maxHeight: "302px", overflow: "hidden" }}
              >
                <ul>
                  {this.props.class_rlp_object.YaxisDataRange.map(
                    (readingLevel, index) => {
                      return (
                        <li
                          className="level3"
                          key={index}
                          style={{
                            backgroundColor: this.getBackgroundColorYAxis(
                              readingLevel
                            ),
                            borderRight:
                              "4px solid" + this.getAxisColorYAxis(readingLevel)
                          }}
                        >
                          <span>{readingLevel}</span>
                        </li>
                      );
                    }
                  )}
                </ul>
              </div>
              <div
                className={
                  this.props.class_rlp_object.scrollIndex <
                    this.props.class_rlp_object.YaxisData.length - 5
                    ? "y-bottom-active"
                    : "y-bottom"
                }
                onClick={() => this.scrollDown()}
              />
              <div
                className={
                  this.props.class_rlp_object.scrollIndex <
                    this.props.class_rlp_object.YaxisData.length - 5
                    ? "y-bottom-end-active"
                    : "y-bottom-end"
                }
                onClick={() => this.scrollToBottom()}
              />
              <div>
                <div
                  className={
                    this.props.class_rlp_object.xAxisScrollIndex > 1
                      ? "x-prev-end-active pull-left"
                      : "x-prev-end pull-left"
                  }
                  onClick={() => this.scrollExtremeLeft()}
                />
                <div
                  className={
                    this.props.class_rlp_object.xAxisScrollIndex > 1
                      ? "x-prev-active pull-left"
                      : "x-prev pull-left"
                  }
                  onClick={() => this.scrollLeft()}
                />
              </div>
            </div>

            <div
              className={this.props.class_rlp_object && this.props.class_rlp_object.recentMonthlyRecords.length == 1 ? "graph-content-crlp pull-left pos-rel crlp-single-month " : "graph-content-crlp pull-left pos-rel "}
              style={{
                border: "none",
                display: "inline-flex"
              }}
            >
              <div className="starting-level-crlp">
                <div className="top-slide-section-crlp-first"></div>
                {this.props.class_rlp_object &&
                  this.props.class_rlp_object.YaxisDataRange.map(
                    (recordLvl, idx) => {
                      return (
                        <div className="sl-1" key={idx}>
                          <ul>
                            <li
                              className="default-bubble-crlp"
                              onClick={() => {
                                this.bubblesSelected({
                                  type: "Frustrational",
                                  readingLevel: recordLvl,
                                  month: recordDataListValue.month,
                                  monthYear: recordDataListValue.monthYear,
                                  recentRecord:
                                    recordDataListValue.recentRecord,
                                  firstRecord: recordDataListValue.firstRecord
                                });
                              }}
                              style={{
                                // backgroundColor: '#ffffff',
                                width: this.getBubbleConfiguration(
                                  this.props.class_rlp_object.startingLevel[
                                  recordLvl
                                  ]
                                ).bubbleSize
                                  ? this.getBubbleConfiguration(
                                    this.props.class_rlp_object.startingLevel[
                                    recordLvl
                                    ]
                                  ).bubbleSize
                                  : "",
                                height: this.getBubbleConfiguration(
                                  this.props.class_rlp_object.startingLevel[
                                  recordLvl
                                  ]
                                ).bubbleSize
                                  ? this.getBubbleConfiguration(
                                    this.props.class_rlp_object.startingLevel[
                                    recordLvl
                                    ]
                                  ).bubbleSize
                                  : "",
                                fontSize: this.getBubbleConfiguration(
                                  this.props.class_rlp_object.startingLevel[
                                  recordLvl
                                  ]
                                ).fontSize
                                  ? this.getBubbleConfiguration(
                                    this.props.class_rlp_object.startingLevel[
                                    recordLvl
                                    ]
                                  ).fontSize
                                  : "",
                                border: this.props.class_rlp_object
                                  .startingLevel[recordLvl]
                                  ? "3px solid" +
                                  this.getBubbleColor("Instructional")
                                  : "",
                                lineHeight: this.getBubbleConfiguration(
                                  this.props.class_rlp_object.startingLevel[
                                  recordLvl
                                  ]
                                ).bubbleSize
                                  ? this.getBubbleConfiguration(
                                    this.props.class_rlp_object.startingLevel[
                                    recordLvl
                                    ]
                                  ).bubbleSize
                                  : ""
                              }}
                            >
                              <span>
                                {
                                  this.props.class_rlp_object.startingLevel[
                                  recordLvl
                                  ]
                                }
                                {this.props.class_rlp_object.startingLevel[
                                  recordLvl
                                ]
                                  ? "%"
                                  : ""}
                              </span>
                            </li>
                          </ul>
                        </div>
                      );
                    }
                  )}

                <div className="sl-heading">Starting level</div>
              </div>
              {this.props.class_rlp_object &&
                this.props.class_rlp_object.recentMonthlyRecords.map(
                  (recordDataListValue, idx) => {
                    if (recordDataListValue) {
                      return (
                        <div
                          className="first-coloumn-crlp pull-left pos-rel ml-68"
                          key={idx}
                        >
                          <div className="sub-rhs-line-crlp cRlp-rhs-line-21-20">
                            <div className="top-small-strip">
                              <div className="top-lhs-strip-bar"></div>
                              <div className="top-rhs-strip-bar"></div>
                            </div>

                            <div className="chart-line-lhs-adj crlp-mid-lhs-col"></div>
                            <div className="chart-line-rhs-adj crlp-mid-rhs-col"></div>
                          </div>
                          <div className="top-slide-section-crlp">
                            {this.props.class_rlp_object.xAxisScrollIndex === 1 && idx === 0 ? (
                              <span>First Record</span>
                            ) : (
                                <span />
                              )}
                            {this.props.class_rlp_object.monthlyRecordData.length
                              === (this.props.class_rlp_object.xAxisScrollIndex + idx) ? (
                              <span>Recent Record</span>
                            ) : (
                                <span />
                              )}
                          </div>
                          <div className="up-sec-crlp cRlpup-21-20">
                            {/* Total Student Grid */}
                            <div className="sub-first-column-crlp pull-left pos-rel">
                              {this.props.class_rlp_object.YaxisDataRange.map(
                                (recordLvl, idx) => {
                                  return (
                                    <div className="blockcRlp-21-20 block-sec-crlp" key={idx}>
                                      <ul>
                                        <li
                                          style={{
                                            fontSize: this.getBubbleConfiguration(
                                              recordDataListValue
                                                .totalNoOfStudents[recordLvl]
                                            ).fontSize
                                          }}
                                        >
                                          <span>
                                            {
                                              recordDataListValue
                                                .totalNoOfStudents[recordLvl]
                                            }
                                            {recordDataListValue
                                              .totalNoOfStudents[recordLvl]
                                              ? "%"
                                              : ""}
                                          </span>
                                        </li>
                                      </ul>
                                    </div>
                                  );
                                }
                              )}
                            </div>
                            <div className="total-stu-crlp">
                              <p title="Total Students Roastered">
                                Total Students
                              </p>
                            </div>

                            {/* Frustrational Student Grid */}
                            <div
                              className={
                                recordDataListValue.frustrationalRecordDataTotalValue >
                                  0
                                  ? "sub-fourth-column-crlp pull-left pos-rel"
                                  : "hide"
                              }
                            >
                              <div>
                                {this.props.class_rlp_object.YaxisDataRange.map(
                                  (recordLvl, idx) => {
                                    return (
                                      <div
                                        className="block-sec-3rd-crlp"
                                        key={idx}
                                      >
                                        <ul>
                                          <li
                                            className={
                                              recordDataListValue
                                                .frustrationalRecordData[
                                                recordLvl
                                              ]
                                                ? "default-bubble-crlp"
                                                : ""
                                            }
                                            onClick={() => {
                                              this.bubblesSelected({
                                                type: "Frustrational",
                                                readingLevel: recordLvl,
                                                month:
                                                  recordDataListValue.month,
                                                monthYear:
                                                  recordDataListValue.monthYear,
                                                recentRecord:
                                                  recordDataListValue.recentRecord,
                                                firstRecord:
                                                  recordDataListValue.firstRecord
                                              });
                                            }}
                                            style={{
                                              width: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              height: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              fontSize: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).fontSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).fontSize
                                                : "",
                                              border: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).border +
                                                this.getBubbleColor(
                                                  "Frustrational"
                                                )
                                                : "",
                                              lineHeight: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .frustrationalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              backgroundColor: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).color
                                                : "",
                                              padding: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).padding
                                                : "",
                                              boxShadow: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Frustrational",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).boxShadow
                                                : ""
                                            }}
                                          >
                                            <span>
                                              {
                                                recordDataListValue
                                                  .frustrationalRecordData[
                                                recordLvl
                                                ]
                                              }
                                              {recordDataListValue
                                                .frustrationalRecordData[
                                                recordLvl
                                              ]
                                                ? "%"
                                                : ""}
                                            </span>
                                          </li>
                                        </ul>
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                              <div
                                className="wcpm-section-crlp"
                                style={{
                                  backgroundColor: "transparent",
                                  borderBottom:
                                    "4px solid" +
                                    this.getBubbleColor("Frustrational")
                                }}
                              >
                                <p>
                                  {
                                    recordDataListValue.frustrationalRecordDataTotalValue
                                  }%
                                </p>
                              </div>
                            </div>

                            {/* Instructional Student Grid */}
                            <div
                              className={
                                recordDataListValue.instructionalRecordDataTotalValue >
                                  0
                                  ? "sub-second-column-crlp pull-left pos-rel"
                                  : "hide"
                              }
                            >
                              <div>
                                {this.props.class_rlp_object.YaxisDataRange.map(
                                  (recordLvl, idx) => {
                                    return (
                                      <div
                                        className="block-sec-3rd-crlp"
                                        key={idx}
                                      >
                                        <ul>
                                          <li
                                            className={
                                              recordDataListValue
                                                .instructionalRecordData[
                                                recordLvl
                                              ]
                                                ? "default-bubble-crlp"
                                                : ""
                                            }
                                            style={{
                                              width: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              height: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              fontSize: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).fontSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).fontSize
                                                : "",
                                              border: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).border +
                                                this.getBubbleColor(
                                                  "Instructional"
                                                )
                                                : "",
                                              lineHeight: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .instructionalRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              backgroundColor: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).color
                                                : "",
                                              padding: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).padding
                                                : "",
                                              boxShadow: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Instructional",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).boxShadow
                                                : ""
                                            }}
                                            onClick={() => {
                                              this.bubblesSelected({
                                                type: "Instructional",
                                                readingLevel: recordLvl,
                                                month:
                                                  recordDataListValue.month,
                                                monthYear:
                                                  recordDataListValue.monthYear,
                                                recentRecord:
                                                  recordDataListValue.recentRecord,
                                                firstRecord:
                                                  recordDataListValue.firstRecord
                                              });
                                            }}
                                          >
                                            <span>
                                              {
                                                recordDataListValue
                                                  .instructionalRecordData[
                                                recordLvl
                                                ]
                                              }
                                              {recordDataListValue
                                                .instructionalRecordData[
                                                recordLvl
                                              ]
                                                ? "%"
                                                : ""}
                                            </span>
                                          </li>
                                        </ul>
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                              <div
                                className="wcpm-section-crlp"
                                style={{
                                  backgroundColor: "transparent",
                                  borderBottom:
                                    "4px solid" +
                                    this.getBubbleColor("Instructional")
                                }}
                              >
                                <p>
                                  {
                                    recordDataListValue.instructionalRecordDataTotalValue
                                  }%
                                </p>
                              </div>
                            </div>

                            {/* Independent Student Grid */}
                            <div
                              className={
                                recordDataListValue.independentRecordDataTotalValue >
                                  0
                                  ? "sub-third-column-crlp pull-left pos-rel"
                                  : "hide"
                              }
                            >
                              <div>
                                {this.props.class_rlp_object.YaxisDataRange.map(
                                  (recordLvl, idx) => {
                                    return (
                                      <div
                                        className="block-sec-3rd-crlp"
                                        key={idx}
                                      >
                                        <ul>
                                          <li
                                            className={
                                              recordDataListValue
                                                .independentRecordData[
                                                recordLvl
                                              ]
                                                ? "default-bubble-crlp"
                                                : ""
                                            }
                                            style={{
                                              width: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              height: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              fontSize: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).fontSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).fontSize
                                                : "",
                                              border: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).border +
                                                this.getBubbleColor(
                                                  "Independent"
                                                )
                                                : "",
                                              lineHeight: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubbleConfiguration(
                                                  recordDataListValue
                                                    .independentRecordData[
                                                  recordLvl
                                                  ]
                                                ).bubbleSize
                                                : "",
                                              backgroundColor: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).color
                                                : "",
                                              padding: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).padding
                                                : "",
                                              boxShadow: this.getBubbleConfiguration(
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              ).bubbleSize
                                                ? this.getBubBackColor({
                                                  type: "Independent",
                                                  readingLevel: recordLvl,
                                                  month:
                                                    recordDataListValue.month
                                                }).boxShadow
                                                : ""
                                            }}
                                            onClick={() => {
                                              this.bubblesSelected({
                                                type: "Independent",
                                                readingLevel: recordLvl,
                                                month:
                                                  recordDataListValue.month,
                                                monthYear:
                                                  recordDataListValue.monthYear,
                                                recentRecord:
                                                  recordDataListValue.recentRecord,
                                                firstRecord:
                                                  recordDataListValue.firstRecord
                                              });
                                            }}
                                          >
                                            <span>
                                              {
                                                recordDataListValue
                                                  .independentRecordData[
                                                recordLvl
                                                ]
                                              }
                                              {recordDataListValue
                                                .independentRecordData[
                                                recordLvl
                                              ]
                                                ? "%"
                                                : ""}
                                            </span>
                                          </li>
                                        </ul>
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                              <div
                                className="wcpm-section-crlp"
                                style={{
                                  backgroundColor: "transparent",
                                  borderBottom:
                                    "4px solid" +
                                    this.getBubbleColor("Independent")
                                }}
                              >
                                <p>
                                  {
                                    recordDataListValue.independentRecordDataTotalValue
                                  }%
                                </p>
                              </div>
                            </div>
                          </div>

                          <div className="month-section-crlp cRlpms-21-20">
                            <span>{recordDataListValue.month}</span>
                          </div>
                        </div>
                      );
                    }
                  }
                )}
              <div className="last-col-wrap-crlp">
                <div className="reading-level-crlp">
                  <div className="top-slide-section-crlp-last"></div>
                  {this.props.class_rlp_object &&
                    this.props.class_rlp_object.YaxisDataRange.map(
                      (recordLvl, idx) => {
                        if (recordLvl) {
                          return (
                            <div className="sl-1" key={idx}>
                              <ul>
                                <li
                                  className="default-bubble-crlp"
                                  onClick={() => {
                                    this.bubblesSelectedForReadingTarget({
                                      readingLevel: recordLvl
                                    });
                                  }}
                                  style={{
                                    width: this.getBubbleConfiguration(
                                      this.props.class_rlp_object.readingTarget[
                                      recordLvl
                                      ]
                                    ).bubbleSize
                                      ? this.getBubbleConfiguration(
                                        this.props.class_rlp_object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize
                                      : "",
                                    backgroundColor:
                                      this.getBubbleConfiguration(
                                        this.props.class_rlp_object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize &&
                                        Object.keys(this.state.selectedBubbles)
                                          .length === 0
                                        ? this.getBubbleColor("Instructional")
                                        : "",
                                    height: this.getBubbleConfiguration(
                                      this.props.class_rlp_object.readingTarget[
                                      recordLvl
                                      ]
                                    ).bubbleSize
                                      ? this.getBubbleConfiguration(
                                        this.props.class_rlp_object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize
                                      : "",
                                    fontSize: this.getBubbleConfiguration(
                                      this.props.class_rlp_object.readingTarget[
                                      recordLvl
                                      ]
                                    ).fontSize
                                      ? this.getBubbleConfiguration(
                                        this.props.class_rlp_object
                                          .readingTarget[recordLvl]
                                      ).fontSize
                                      : "",
                                    border: this.props.class_rlp_object
                                      .readingTarget[recordLvl]
                                      ? "3px solid" +
                                      this.getBubbleColor("Instructional")
                                      : "",
                                    lineHeight: this.getBubbleConfiguration(
                                      this.props.class_rlp_object.readingTarget[
                                      recordLvl
                                      ]
                                    ).bubbleSize
                                      ? this.getBubbleConfiguration(
                                        this.props.class_rlp_object
                                          .readingTarget[recordLvl]
                                      ).bubbleSize
                                      : ""
                                  }}
                                >
                                  <span>
                                    {
                                      this.props.class_rlp_object.readingTarget[
                                      recordLvl
                                      ]
                                    }
                                    {this.props.class_rlp_object.readingTarget[
                                      recordLvl
                                    ]
                                      ? "%"
                                      : ""}
                                  </span>
                                </li>
                              </ul>
                            </div>
                          );
                        }
                      }
                    )}
                  <div className="sl-heading">Reading Target</div>
                </div>
                <div className="sub-rhs-line-crlp-rl"></div>
                <div className="last-col-crlp">
                  <div class="last-col-lft-bor class-rlp-last-col-bor cRlp-last-col-16-20">
                    <div class="last-line-top-rhs-adj crlp-only-lhs-bor"></div>
                    <div class="last-line-top-rhs-adj crlp-only-rhs-bor"></div>
                    <div class="last-line-top-rhs-adj"></div>
                  </div>
                  <div className="last-wrap cRlp-last-wrap-21-20">
                    <div className="grey-header"></div>
                    <p>Reading Level Progress Over Time</p>
                  </div>
                  <div className="btm-arrow-lft-crlp cRlp-btm-arrow-21-20">
                    <div className="btn-wrap-crlp">
                      <div
                        // className={
                        //   this.props.class_rlp_object.xAxisScrollIndex >= this.props.class_rlp_object.recentMonthlyRecords.length ||
                        //     this.props.class_rlp_object.recentMonthlyRecords.length === this.props.class_rlp_object.monthlyRecordData.length
                        //     ? "x-next pull-left"
                        //     : "x-next-active pull-left"
                        // }
                        className={
                          // this.props.class_rlp_object.xAxisScrollIndex >=
                          //   this.props.class_rlp_object.monthlyRecordData.length -
                          //   1
                          this.props.class_rlp_object.xAxisScrollIndex <
                            this.props.class_rlp_object.monthlyRecordData.length - 1
                            ? "x-next-active pull-left"

                            : "x-next pull-left"
                        }
                        // className="x-next-active pull-left"
                        onClick={() => this.scrollRight()}
                      ></div>
                      <div
                        className={
                          // this.props.class_rlp_object.xAxisScrollIndex >=
                          //   this.props.class_rlp_object.monthlyRecordData.length -
                          //   1
                          this.props.class_rlp_object.xAxisScrollIndex <
                            this.props.class_rlp_object.monthlyRecordData.length - 1
                            ? "x-next-end-active pull-left "
                            : "x-next-end pull-left"
                        }
                        // className="x-next-end-active pull-left"
                        onClick={() => this.scrollExtremeRight()}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
              <div style={{ clear: "both" }} />
            </div>
          </div>
        </div>
      );
    } else {
      return <div>No data</div>;
    }
  }
}

export default Class_RLP;