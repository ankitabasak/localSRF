import React, { Component } from 'react';
import { SHOW_HIDE_GROUPING, SORT_GROUPING_GRID_COLUMN, SAVE_GROUPING_DATA, SHOW_SPINNER } from '../../../Redux_Actions/C_GroupingAction.jsx';
import { connect } from 'react-redux';
import titleImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/class_grouping.svg';
import minusImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/minus_circle_ic.svg';
import plusImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/plus_circle_ic.svg';
import editImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/edit_ic.svg';
import dragCrossImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/drag-cross.svg';
import saveImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/save_ic.svg';
import disableImg from '../../../../public/assets/orr/rlp-screen/C_grouping_imgs/disable.svg';
import spinner from "../../../../public/assets/orr/rlp-screen/loader-white-bg.gif";
import disabledPlusIcon1 from '../../../../public/assets/orr/rlp-screen/disable_plus_circle_ic.svg';
import disabledMinusIcon1 from '../../../../public/assets/orr/rlp-screen/disable_minus_circle_ic.svg';
import './C_Grouping.css';

import '../../ORR/ReadingHistoryComponents/ReadingHistory.css';
import { dataSorting } from '../../ReusableComponents/OrrReusableComponents';

class Group extends Component {
    constructor(props) {
        super(props);
        // Create the ref
        this.exampleRef = React.createRef();
        this.inputRef = React.createRef();
        this.state = {
            hideGroup: false,
            existingGroup: [{ groupName: 'Group 1', items: [], savedName: 'Group 1' }],
            gridData: this.props.gridData,
            currentGroupIndex: null,
            groupListItem: false,
            dataSort: {
                sortColumn: '',
                sortType: ''
            }
        };
        this.rlpGrid = this.rlpGrid.bind(this);
        this.saveGroupDetails = this.saveGroupDetails.bind(this);
        this.sortData = this.sortData.bind(this);
        this.drag = this.drag.bind(this);
        this.dragItem = this.dragItem.bind(this);
        this.drop = this.drop.bind(this);
        this.allowDrop = this.allowDrop.bind(this);
        this.addOrRemoveGroup = this.addOrRemoveGroup.bind(this);
        this.disableSelectedStudent = this.disableSelectedStudent.bind(this);
        this.editGroupName = this.editGroupName.bind(this);
        this.getBackgroundColor = this.getBackgroundColor.bind(this);
        this.toggleHidden = this.toggleHidden.bind(this);
        this.setDraggableitem = this.setDraggableitem.bind(this);
        this.toggleGroupName = this.toggleGroupName.bind(this);
        this.disableSaveButton = this.disableSaveButton.bind(this);
        this.add = this.add.bind(this);
        this.addelipsisToGroupName = this.addelipsisToGroupName.bind(this);
    }



    componentDidMount() {
        this.setState({ ...this.state, dataSort: this.props.Data })
    }
    componentWillMount() {
        this.setDraggableitem(this.props.gridData);
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.gridData !== this.props.gridData) {
            this.setDraggableitem(nextProps.gridData)
        }
    }
    setDraggableitem(gridArray) {
        let tempArray = gridArray.map((item) => {
            item.draggable = true;
            item.addedGroup = null;
            return item;
        })
        let groupArray = [{ groupName: 'Group 1', items: [], savedName: 'Group 1' }];
        this.setState({ ...this.state, existingGroup: groupArray });
        this.setState({ ...this.state, gridData: tempArray });
    }
    drag(ev, item, index) {
        item.draggedGroupIndex = index;
        ev.dataTransfer.setData("text", JSON.stringify(item));
    }
    dragItem(ev, item, index) {
        item.draggedGroupIndex = index;
        ev.dataTransfer.setData("tex", JSON.stringify(item));
    }
    disableActive(ev) {
        ev.preventDefault();
        ev.currentTarget.children[1].firstElementChild.style.border = '1px solid rgb(189, 194, 205)';
    }
    drop(ev, i) {
        ev.preventDefault();
        ev.currentTarget.children[1].firstElementChild.style.border = '1px solid rgb(189, 194, 205)';
        let data = ev.dataTransfer.getData('text');
        data = JSON.parse(data);
        if (data.draggedGroupIndex !== null) {
            let temparray = this.state.existingGroup[data.draggedGroupIndex].items.filter(value => value.studentId != data.studentId);
            this.state.existingGroup[data.draggedGroupIndex].items = temparray;
            this.state.existingGroup[i].items.push(data);
        } else {
            this.state.existingGroup[i].items.push(data);
        }
        this.setState({ ...this.state, existingGroup: this.state.existingGroup });
        this.disableSelectedStudent(data, true, i);
        this.disableSaveButton();
    }
    allowDrop(ev) {
        ev.preventDefault();
        ev.currentTarget.children[1].firstElementChild.style.border = '1px solid rgb(0, 83, 155)';
    }
    addOrRemoveGroup(type, index) {
        if (type == 'push') {
            this.state.existingGroup.push({ groupName: 'Group' + ' ' + (index + 1), items: [], savedName: 'Group' + ' ' + (index + 1) })
        } else {
            this.state.existingGroup[index - 1].items.forEach(element => {
                let tempArray = this.state.gridData.map((item) => {
                    if (item.studentId == element.studentId) {
                        item.dragged = false;
                        item.draggable = true;
                        item.addedGroup = null;
                    }
                    return item;
                })
                this.setState({ ...this.state, gridData: tempArray });
            });
            this.state.existingGroup.pop();
        }
        this.setState({ ...this.state, existingGroup: this.state.existingGroup });
        this.disableSaveButton();
    }
    removeStudent(student, index) {
        let temparray = this.state.existingGroup[index].items.filter(value => value.studentId != student.studentId);
        this.state.existingGroup[index].items = temparray;
        this.setState({ ...this.state, existingGroup: this.state.existingGroup });
        this.disableSelectedStudent(student, false);
        this.disableSaveButton();
    }
    disableSelectedStudent(student, status, i) {
        let tempArray = this.state.gridData.map((item) => {
            if (item.studentId == student.studentId && status) {
                item.dragged = true;
                item.draggable = false;
                item.addedGroup = i;
            } else if (item.studentId == student.studentId && !status) {
                item.dragged = false;
                item.draggable = true;
                item.addedGroup = null;
            }
            return item;
        })
        this.setState({ ...this.state, gridData: tempArray });
    }
    editGroupName(e, i) {
        this.state.existingGroup[i].groupName = e.target.value;
        this.state.existingGroup[i].savedName = e.target.value;
        this.setState({ ...this.state, existingGroup: this.state.existingGroup });
    }
    getBackgroundColor(index) {
        let bgColors = ['#063bd1', '#ffe000', '#ff000c', '#62c600', '#b300b2', '#b300b2', '#fa5aa1', '#25dacb', '#0099f4', '#8c00dc'];
        return bgColors[index];
    }

    disableSaveButton() {
        for (let i = 0; i < this.state.existingGroup.length; i++) {
            if (this.state.existingGroup[i].items.length > 0) {
                this.setState({ ...this.state, groupListItem: true });

            } else {
                this.setState({ ...this.state, groupListItem: false });
            }
        }
    }

    rlpGrid(sortColumn, sortType, actualArray) {
        document.getElementById('crlp').scrollTop = 0;
        this.sortData(sortColumn, sortType, actualArray);
        this.setState({ ...this.state, dataSort: { ...this.state.dataSort, sortColumn: sortColumn, sortType: sortType } })
    }

    //function to sort array of data
    sortData(column, sortType, stdArray) {
        let sortedArray = [];
        if (stdArray.length != 0) {
            sortedArray = dataSorting(stdArray, column, sortType);
            // this.props.SORT_C_RLP_DATA(sortedArray, column, sortType);
            this.setState({ ...this.state, gridData: sortedArray });
        }
    }
    LineUnderActiveColumnFiled(Data, columnName, SortType) {
        return Data.sortColumn == columnName && Data.sortType == SortType
            ? ' border-btm'
            : '';
    }
    returnBasedOnStudentName(Data, gridArray) {
        return (
            <div className="student-column-list-rhs-sec">
                <span
                    className={this.LineUnderActiveColumnFiled(
                        Data,
                        'lastName',
                        Data.sortType
                    )}
                >
                    Students ({gridArray.length})
            </span>
                <span className="togglers">
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === 'lastName' && Data.sortType === 'desc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid('lastName', 'desc', gridArray)}
                    >
                        expand_more
              </i>
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === 'lastName' && Data.sortType === 'asc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid('lastName', 'asc', gridArray)}
                    >
                        expand_less
              </i>
                </span>
            </div>
        );
    }

    returnBasedOnLevel(Data, gridArray) {
        let colName;
        if (this.props.NavigationByHeaderSelection.class) {
            if (this.props.NavigationByHeaderSelection.errorAnalysis || this.props.NavigationByHeaderSelection.fluencyAnalysis) {
                colName = 'readingLevel';
            }
            if (this.props.NavigationByHeaderSelection.rlp) {
                colName = 'letterLevel';
            }
            if (this.props.NavigationByHeaderSelection.readingBehaviors) {
                colName = 'level';
            }
        }

        return (
            <div className="student-column-list-rhs-sec">
                <span
                    className={this.LineUnderActiveColumnFiled(
                        Data,
                        colName,
                        Data.sortType
                    )}
                >
                    Level
            </span>
                <span className="togglers">
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === colName && Data.sortType === 'desc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid(colName, 'desc', gridArray)}
                    >
                        expand_more
              </i>
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === colName && Data.sortType === 'asc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid(colName, 'asc', gridArray)}
                    >
                        expand_less
              </i>
                </span>
            </div>
        );
    }

    returnBasedOnProficiency(Data, gridArray) {
        return (
            <div className={this.props.subFluencyTab ? "cg-col" : "student-column-list-rhs-sec"}>
                <span
                    className={this.LineUnderActiveColumnFiled(
                        Data,
                        'proficiency',
                        Data.sortType
                    )}
                >
                    Proficiency
            </span>
                <span className="togglers">
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === 'proficiency' && Data.sortType === 'desc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid('proficiency', 'desc', gridArray)}
                    >
                        expand_more
              </i>
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === 'proficiency' && Data.sortType === 'asc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid('proficiency', 'asc', gridArray)}
                    >
                        expand_less
              </i>
                </span>
            </div>
        );
    }

    returnBasedOnFluency(Data, gridArray) {
        return (
            <div className="student-column-list-rhs-sec">
                <span
                    className={this.LineUnderActiveColumnFiled(
                        Data,
                        'fluency',
                        Data.sortType
                    )}
                >
                    Fluency
            </span>
                <span className="togglers">
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === 'fluency' && Data.sortType === 'desc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid('fluency', 'desc', gridArray)}
                    >
                        expand_more
              </i>
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === 'fluency' && Data.sortType === 'asc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid('fluency', 'asc', gridArray)}
                    >
                        expand_less
              </i>
                </span>
            </div>
        );
    }

    returnBasedOnDate(Data, gridArray) {
        let colName;
        if (this.props.NavigationByHeaderSelection.class) {
            if (this.props.NavigationByHeaderSelection.readingBehaviors) {
                colName = 'date';
            } else {
                colName = 'assignmentDate';
            }
        }
        return (
            <div className="student-column-list-rhs-sec">
                <span
                    className={this.LineUnderActiveColumnFiled(
                        Data,
                        colName,
                        Data.sortType
                    )}
                >
                    Date
            </span>
                <span className="togglers">
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === colName && Data.sortType === 'desc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid(colName, 'desc', gridArray)}
                    >
                        expand_more
              </i>
                    <i
                        style={{ cursor: 'pointer' }}
                        className={
                            Data.sortColumn === colName && Data.sortType === 'asc'
                                ? 'material-icons blueColor'
                                : 'material-icons'
                        }
                        onClick={() => this.rlpGrid(colName, 'asc', gridArray)}
                    >
                        expand_less
              </i>
                </span>
            </div>
        );
    }
    classRlpGridData(Data, gridArray) {
        const dashSymbol = <span>&mdash;</span>;
        return (
            <div>
                <div className="student-list-header-rhs-sec rho-header-rhs-sec pos-rel">
                    <div className="hide-header"></div>
                    {this.returnBasedOnStudentName(Data, gridArray)}
                    {this.returnBasedOnLevel(Data, gridArray)}
                    {this.props.NavigationByHeaderSelection.fluencyAnalysis &&
                        this.props.subFluencyTab && this.returnBasedOnFluency(Data, gridArray)}
                    {this.returnBasedOnProficiency(Data, gridArray)}
                    {!this.props.subFluencyTab && this.returnBasedOnDate(Data, gridArray)}
                </div>
                <div className="student-list-body scroll-body" id="crlp" >

                    {gridArray.map((gridDetails, value) => (


                        <div className={gridDetails.draggable ? "student-list-row-rhs-sec pos-rel" : "student-list-row-rhs-sec pos-rel no-hover-state "} style={{ color: gridDetails.draggable ? "black" : "#CFD0D1", cursor: gridDetails.draggable ? 'grab' : 'auto' }} key={value} draggable={gridDetails.draggable} onDragStart={(e) => this.drag(e, gridDetails, null)}>

                            {gridDetails.addedGroup != null ? (
                                <div className="group-lhs" style={{ backgroundColor: this.getBackgroundColor(gridDetails.addedGroup) }}>
                                    <div className={'lft-' + 'g' + (gridDetails.addedGroup + 1) + '-stick'}></div>
                                    <div className="white-curve-img"></div>
                                </div>
                            ) : (
                                    ''
                                )}
                            <div className="student-column-list-rhs-sec">
                                <span className="wb-break-all">
                                    {gridDetails.firstName} {gridDetails.lastName}
                                </span>
                            </div>
                            <div className="student-column-list-rhs-sec">
                                <span>
                                    {gridDetails.letterLevel || gridDetails.readingLevel || gridDetails.level
                                        ? gridDetails.letterLevel || gridDetails.readingLevel || gridDetails.level
                                        : dashSymbol}
                                </span>
                            </div>
                            {this.props.NavigationByHeaderSelection.fluencyAnalysis &&
                                this.props.subFluencyTab &&
                                <div className="student-column-list-rhs-sec">
                                    <span>
                                        {gridDetails.fluency
                                            ? gridDetails.fluency
                                            : dashSymbol}
                                    </span>
                                </div>}
                            <div className={this.props.subFluencyTab ? "cg-col" : "student-column-list-rhs-sec"}>
                                <span>
                                    {gridDetails.proficiency
                                        ? gridDetails.proficiency
                                        : dashSymbol}
                                </span>
                            </div>
                            {!this.props.subFluencyTab &&
                                <div className="student-column-list-rhs-sec">
                                    <span>
                                        {gridDetails.assignmentDate || gridDetails.date
                                            ? gridDetails.assignmentDate || gridDetails.date
                                            : dashSymbol}
                                    </span>
                                </div>}
                        </div>
                    ))}
                </div>
            </div>
        );
    }
    //to display header data properly
    displayHeader(dataArray) {
        let array = [];
        dataArray.map((level, value) =>
            value < dataArray.length - 1
                ? array.push(level + ', ')
                : array.push(level + '')
        );

        return array;
    }
    // toggle grouping
    toggleHidden() {
        this.setState({ ...this.state, hideGroup: true });
        setTimeout(() => this.props.cancelModal(false), 1000);


    }
    toggleGroupName(index) {

        if (index == this.state.currentGroupIndex) {
            this.setState({ ...this.state, currentGroupIndex: null });
        } else {
            this.setState({ ...this.state, currentGroupIndex: index });
        }
    }


    saveGroupDetails() {
        if (this.state.existingGroup && this.state.existingGroup.length > 0) {
            this.props.SHOW_SPINNER();
            // let groupObj = this.state.existingGroup[0];
            // let groupName = groupObj['groupName'];
            let payLoadForAPI = []
            this.state.existingGroup.forEach((groupObj) => {
                let groupName = groupObj['groupName'];
                let userIds = [];
                if (groupObj.items && groupObj.items.length > 0) {
                    groupObj.items.forEach((obj) => {
                        userIds.push(obj.studentId)
                    })
                }
                payLoadForAPI.push({
                    "classId": this.props.ContextHeader.Roster_Tab.SelectedClass['id'],
                    "userIds": userIds,
                    "groupSource": 3,
                    "groupName": groupName
                })

            })
            this.props.SAVE_GROUPING_DATA(this.props.LoginDetails['JWTToken'], payLoadForAPI);
        }

    }
    addelipsisToGroupName(txt) {
        if (txt.length > 40) {
            return txt.substring(0, 40) + "...";
        } else {
            return txt;
        }
    }
    // group name logic
    updateGroupDetails(e, index) {
        e.target.scrollIntoView();
        if (this.state.existingGroup[index].groupName == `Group ${index + 1}`) {
            this.state.existingGroup[index].groupName = '';
            this.setState({ ...this.state, existingGroup: this.state.existingGroup });
        } else {
            let gpName = this.state.existingGroup[index].groupName
            setTimeout(() => {
                let inputElem = document.getElementById('ip' + index);
                inputElem.value = '';
                inputElem.value = gpName;
            }, 100)
        }

    }

    updateGpNameOnblur(e, index) {
        if (!e.target.value.length) {
            this.state.existingGroup[index].groupName = this.state.existingGroup[index].savedName;
            //this.state.existingGroup[index].savedName = `Group ${index + 1}`;
            this.setState({ ...this.state, existingGroup: this.state.existingGroup });
        }
        if (index == this.state.currentGroupIndex) {
            this.setState({ ...this.state, currentGroupIndex: null });
        } else {
            this.setState({ ...this.state, currentGroupIndex: index });
        }

    }
    add(event, index) {
        if (event.which === 13) {
            this.updateGpNameOnblur(event, index)
        }
    }
    render() {
        let classDataArray = this.state.gridData;
        let Data = this.props.Data;
        return (
            /* <!-- The Modal --> */
            < div id="myModal" className={!this.state.hideGroup ? 'modal cg-modal show-group-modal cg_animated fadeInCg ' : 'modal cg-modal show-group-modal cg_animatedout fadeInCgout '}  >

                {/* <!-- Modal content --> */}
                < div className="modal-content-new " >
                    {/* <span className="close">&times;</span> */}
                    {/* <!-- Left Chart Table Start --> */}

                    <div className="sea-wrapper pos-rel cg-wrapper">
                        {this.props.showSpinner && (
                            <React.Fragment>
                                <div className="display-msg " style={{ position: 'absolute', left: '0px', zIndex: '999', width: '100%', background: 'rgb(255, 255, 255, 0.5)', height: '100%' }}>
                                    <img src={spinner} alt="spinner" />
                                </div>
                            </React.Fragment>
                        )}

                        {/* <!-- Create Group UI Start --> */}

                        <div className="cg-title">
                            <img src={titleImg} className="pull-left mlr-9" />
                            <span><b>Create Groups</b></span>
                        </div>


                        <div className="content-wrapper cg-content-wrap">
                            {/* <!-- left-side table section Start  --> */}
                            <div className="cg-lhs-wrap">
                                <div className="rhs-wrap crlp-rhs cg-modal-lhs-chart">
                                    <div className="col-sm-12 float-left m-0 p-0 class_test_overview_table_list">
                                        <div className="student-list-table-main">
                                            <div className="student-list-table-rhs-sec">
                                                {this.classRlpGridData(this.state.dataSort, classDataArray)}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* <!-- left-side table section End  --> */}

                            {/* <!-- Right-side table section Start  --> */}
                            <div className="cg-rhs-wrap pos-rel">
                                {this.props.groupUpdateFailed && <div className="mb-10"><p className="msg-pos-red" >There was an issue in saving. Please try again later or create these groups in the Manage Students section.</p></div>}
                                {this.props.groupUpdateSuccess && <div><p className="msg-pos-green" >Success! groups detail updated.</p></div>}
                                <div className="cg-top-section">
                                    <div className="pull-left"><h2>Number of Groups</h2></div>
                                    <div className="pull-left">
                                        <React.Fragment>
                                            {this.state.existingGroup.length <= 1 ? <img src={disabledMinusIcon1} width="22px" style={{ pointerEvents: 'none' }} className="minus_ic mlr-12 pull-left" /> : <img src={minusImg} width="22px" style={{ pointerEvents: 'auto' }} className="minus_ic mlr-12 pull-left cursor-pointer" onClick={() => this.addOrRemoveGroup('slice', this.state.existingGroup.length)} />}
                                        </React.Fragment>

                                        <input type="text" maxLength="128" className="num-input pull-left cg-pos-rel" value={this.state.existingGroup.length} disabled />
                                        <React.Fragment>
                                            {this.state.existingGroup.length >= 10 ? <img src={disabledPlusIcon1} width="22px" style={{ pointerEvents: 'none' }} className="plus_ic mlr-12 pull-left " /> : <img src={plusImg} width="22px" style={{ pointerEvents: 'auto' }} className="plus_ic mlr-12 pull-left cursor-pointer" onClick={() => this.addOrRemoveGroup('push', this.state.existingGroup.length)} />}
                                        </React.Fragment>

                                    </div>
                                </div>

                                {/* <!-- First Create Group Start --> */}
                                <div className="mid-group-wrap">
                                    {this.state.existingGroup.map((group, index) => (
                                        <div className="draggable-wrapper pos-rel pull-left" ref={this.exampleRef} key={index} onDragLeave={(e) => { this.disableActive(e) }} onDrop={(e) => this.drop(e, index)} onDragOver={(e, item) => this.allowDrop(e, item)}>
                                            {this.state.currentGroupIndex != index ? <div title={group.groupName} className="group-name-span">{this.addelipsisToGroupName(group.groupName)}
                                                <label htmlFor={`ip${index}`} className="cg-pd-2"> <img width="28px" height="14px" src={editImg} className={this.state.currentGroupIndex != index ? 'cursor-pointer edit_ic' : 'cursor-pointer edit_ic-input'} onClick={() => this.toggleGroupName(index)} /></label>
                                            </div> :
                                                <div className="cg-pos-abs">
                                                    <input ref={this.inputRef} type="text" maxLength="128" onKeyPress={(e) => { this.add(e, index) }} onFocus={(e) => { this.updateGroupDetails(e, index) }} onBlur={(e) => { this.updateGpNameOnblur(e, index) }} id={`ip${index}`} className="group-name-input" onChange={(e) => { this.editGroupName(e, index) }} value={group.groupName} />
                                                    <label className="cg-label-bg" htmlFor={`ip${index}`}> <img className="cursor-pointer edit_ic new-cg-cur" width="28px" height="14px" src={editImg} onClick={() => this.toggleGroupName(index)} /></label>
                                                </div>
                                            }

                                            <div className="abc">
                                                <div className="draggable-parent" style={{ border: this.state.currentGroupIndex != index ? '1px solid #bdc2cd' : '1px solid #00539b' }} >
                                                    <div className="group" style={{ backgroundColor: this.getBackgroundColor(index) }}>
                                                        <div className={'lft-' + 'g' + (index + 1) + '-stick'}></div>
                                                        <div className="white-curve-img"></div>
                                                    </div>
                                                    {group.items.map((student, i) => (
                                                        <div className="draggable-item pos-rel cursor-pointer" key={i} draggable="true" onDragStart={(e) => this.drag(e, student, index)}>
                                                            <img src={dragCrossImg} width="12px" className="drag-cross" onClick={() => this.removeStudent(student, index)} />
                                                            <span>{student.firstName} {student.lastName}</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>

                                    ))}
                                </div>

                                {/* <!-- First Create Group End --> */}


                                {/* <!-- Bottom button action section Start --> */}

                                <div className="bottom-btn-wrapper clearfix btn-alignment">
                                    <div className="cancel-btn pull-left">
                                        <span onClick={() => { this.toggleHidden(false) }}>Cancel</span>
                                    </div>
                                    {this.state.groupListItem ?
                                        (<div class="save-btn pull-left cg-save-btn-align cursor-pointer" onClick={this.saveGroupDetails}>
                                            <div class=" save-cg-active">
                                                <img src={saveImg} className="pull-left" />
                                                <span>Save</span>
                                                <div></div>
                                            </div>
                                        </div>
                                        ) :
                                        (
                                            <div class="save-btn pull-left cg-save-btn-align inactive-btn">
                                                <div class=" save-cg-inactive">
                                                    <img src={disableImg} className="pull-left" />
                                                    <span>Save</span>
                                                    <div></div>
                                                </div>
                                            </div>
                                        )}



                                </div>

                                {/* <!-- Bottom button action section End --> */}

                            </div>
                            {/* <!-- Right-side table section End  --> */}
                        </div>

                        {/* <!-- Create Group UI End --> */}
                    </div>

                </div >
            </div >
        );

    }
}



const mapStateToProps = ({ Universal, Authentication, C_GroupingReducer }) => {
    const { LoginDetails } = Authentication;
    const { ContextHeader, ApiCalls, UniversalSelecter, UserScreenWidth, NavigationByHeaderSelection } = Universal
    const { showGrouping, groupUpdateFailed, groupUpdateSuccess, showSpinner } = C_GroupingReducer;
    return {
        LoginDetails, UserScreenWidth,
        ContextHeader, ApiCalls, UniversalSelecter,
        NavigationByHeaderSelection, showGrouping, groupUpdateFailed, groupUpdateSuccess, showSpinner
    };
}

export default connect(mapStateToProps, {
    SORT_GROUPING_GRID_COLUMN, SHOW_HIDE_GROUPING, SAVE_GROUPING_DATA, SHOW_SPINNER
})(Group);