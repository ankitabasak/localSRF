import {
  GetBrowserName,
  Get_Ids_Of_Student_List,
} from "./AllReusableFunctions";

/**
 *
 * @param {Object} LastReportIs
 * @param {Object} state
 * @returns Object of context and universal roster props.
 * it will take last active report props and returns the objects by setting Context and Universal roster tab data.
 */
export function SetRosterDataWithLast_Active_Report_PropValues(
  LastReportIs,
  state,
  LastActiveUniversalProps
) {
  let Last_Report = LastActiveUniversalProps;
  let LastActive_Nav = Last_Report.NaviGation;

  let contextRosterPropName = LastActive_Nav.Summary_Reports
    ? "Summary_Roster_Data"
    : "Roster_Tab";
  let U_RosterPropName = LastActive_Nav.Summary_Reports
    ? "Summary_Roster_Data"
    : "Roster_Data";

  let CheckedSTdLIst = LastActive_Nav.Summary_Reports
    ? LastReportIs.StudentList
    : LastReportIs.StudentList.filter((item) => item.check);
  let stdids = Get_Ids_Of_Student_List(CheckedSTdLIst);
  let clsids =
    LastReportIs.selectedClass && LastReportIs.selectedClass.id
      ? [LastReportIs.selectedClass.id]
      : Get_Ids_Of_Student_List(
          LastReportIs.classList.filter((item) => item.check)
        );
  let Teachids =
    LastReportIs.selectedTeacher && LastReportIs.selectedTeacher.id
      ? [LastReportIs.selectedTeacher.id]
      : Get_Ids_Of_Student_List(
          LastReportIs.TeachersList.filter((item) => item.check)
        );

  let Schoolids =
    LastReportIs.SchoolList.length == 1
      ? [LastReportIs.SchoolList[0].id]
      : Get_Ids_Of_Student_List(
          LastReportIs.SchoolList.filter((item) => item.check)
        );

  let SelectedStudent = LastReportIs.selectedStudent;

  if (!LastActiveUniversalProps.NaviGation.student) {
    SelectedStudent =
      stdids.length !== 0 && LastReportIs.StudentList.length == stdids.length
        ? "All"
        : "Custom (" + stdids.length + ")";
  }

  let LastActiveStd_Data_List = LastReportIs.StudentData_cls;
  LastActiveStd_Data_List =
    LastActiveStd_Data_List == undefined || LastActiveStd_Data_List == null
      ? []
      : LastActiveStd_Data_List;

  let Std_Data_Ids =
    LastActive_Nav.student && LastActiveStd_Data_List.length > 0
      ? Get_Ids_Of_Student_List(
          LastActiveStd_Data_List.filter((item) => !item.check)
        )
      : [];

  let UniversalRoster = {
    ...state.UniversalSelecter[`${U_RosterPropName}`],

    ActualClasses: JSON.parse(JSON.stringify(LastReportIs.classList)),
    ActualGrades: JSON.parse(JSON.stringify(LastReportIs.RosterGradeList)),
    ActualSchools: JSON.parse(JSON.stringify(LastReportIs.SchoolList)),
    ActualStudents: JSON.parse(JSON.stringify(LastReportIs.StudentList)),
    ActualTeachers: JSON.parse(JSON.stringify(LastReportIs.TeachersList)),
    ClassIds: clsids,
    ClassList: JSON.parse(JSON.stringify(LastReportIs.classList)),
    // GradeIds: []
    GradesList: JSON.parse(JSON.stringify(LastReportIs.RosterGradeList)),
    SchoolIds: Schoolids,
    SelectedClass: LastReportIs.selectedClass,
    SelectedGrade: LastReportIs.selectedRosterGrade,
    SelectedSchool: LastReportIs.selectedSchool,
    SelectedStudent: SelectedStudent,
    SelectedTeacher: LastReportIs.selectedTeacher,
    StudentIds: stdids,
    StudentsList: JSON.parse(JSON.stringify(LastReportIs.StudentList)),
    TeacherIds: Teachids,
    TeachersList: JSON.parse(JSON.stringify(LastReportIs.TeachersList)),
    schoolsList: JSON.parse(JSON.stringify(LastReportIs.SchoolList)),
    StudentData_cls: LastActive_Nav.student
      ? LastActiveStd_Data_List
      : state.UniversalSelecter.Roster_Data.StudentData_cls,
    StudentData_cls_ids: LastActive_Nav.student
      ? Std_Data_Ids
      : state.UniversalSelecter.Roster_Data.StudentData_cls_ids,
    SelectedStudentData: LastActive_Nav.student
      ? LastReportIs.SelectedStudentData
      : state.UniversalSelecter.Roster_Data.SelectedStudentData,
    SelectedStudentDataList: LastActive_Nav.student
      ? LastReportIs.SelectedStudentData
      : state.UniversalSelecter.Roster_Data.SelectedStudentData,
    StudentsDataList: LastActive_Nav.student
      ? LastActiveStd_Data_List
      : state.UniversalSelecter.Roster_Data.StudentData_cls,
  };

  let ContextRoster = {
    ...state.ContextHeader[`${contextRosterPropName}`],
    ClassIds: clsids,
    ClassList: JSON.parse(JSON.stringify(LastReportIs.classList)),
    // GradeIds: []
    GradesList: JSON.parse(JSON.stringify(LastReportIs.RosterGradeList)),

    SchoolIds: Schoolids,
    SelectedClass: LastReportIs.selectedClass,
    SelectedDistrict: LastReportIs.selectedDistrict,
    SelectedSchool: LastReportIs.selectedSchool,
    SelectedStudent: SelectedStudent,
    SelectedTeacher: LastReportIs.selectedTeacher,
    StudentIds: stdids,
    StudentsList: JSON.parse(JSON.stringify(LastReportIs.StudentList)),
    TeacherIds: Teachids,
    TeachersList: JSON.parse(JSON.stringify(LastReportIs.TeachersList)),
    schoolsList: JSON.parse(JSON.stringify(LastReportIs.SchoolList)),
    selectedRosterGrade: LastReportIs.selectedRosterGrade,
    StudentData_cls: LastActive_Nav.student
      ? LastActiveStd_Data_List
      : state.ContextHeader[`${contextRosterPropName}`].StudentData_cls,
    StudentData_cls_ids: LastActive_Nav.student
      ? Std_Data_Ids
      : state.ContextHeader[`${contextRosterPropName}`].StudentData_cls_ids,
    SelectedStudentData: LastActive_Nav.student
      ? LastReportIs.SelectedStudentData
      : state.ContextHeader[`${contextRosterPropName}`].SelectedStudentData,
  };

  return { UniversalRoster, ContextRoster };
}

export const isUniversalApIsActive = (props) => {
  let { student, school, district } = props.NavigationByHeaderSelection;
  let apisActive =
    props.lazyLoadingScreenInUniversal ||
    props.loadingScreenInUniversal ||
    props.ApiCalls.getTests ||
    props.ApiCalls.Get_Selected_School_Info ||
    props.ApiCalls.loadingFor == "tests" ||
    (props.ApiCalls.loadingFor == "school" && props.UniversalFilter == "");
  if (student) {
    apisActive =
      apisActive ||
      (props.ApiCalls.getStudentData_cls &&
        props.ApiCalls.STUDENT_OBJ_API == false) ||
      props.ApiCalls.loadingFor == "studentData";
  }
  return apisActive;
};

/* this function will handle new Date in diff browsers*/
/**
 * 
 * @param {string} dateInput  // format should be "12-13-2021 10:00:00" or "10 aug 2020"
 * @returns 
 */
 export const newDateHandling = (dateInput) => {
  const browserName = GetBrowserName(navigator);
  if (browserName && browserName == "safari" && typeof dateInput === "string") {
    let endDatesArray = dateInput && dateInput.split(" ");
    if (
      endDatesArray &&
      endDatesArray.length > 0 &&
      endDatesArray.length !== 3
    ) {
      dateInput = new Date(endDatesArray[0]);
    } else if (endDatesArray.length === 3) {
      dateInput = new Date(dateInput);
    }
  } else {
    dateInput = new Date(dateInput); // for  non safari
  }

  return dateInput;
};
export const getCusrrentDistrictTerm = (DatesList) => {
  let DistrictTerm;
  let highestTermObj;
  if (DatesList && Array.isArray(DatesList)) {
    DatesList.forEach((item, index) => {
      const startDate = getOnlyDateValue(item.termStartDate);
      const endDate = getOnlyDateValue(item.termEndDate);
      if (
        new Date(startDate) <= new Date() &&
        new Date(endDate) >= new Date()
      ) {
        if (DistrictTerm) {
          DistrictTerm =
            DistrictTerm.termId > item.termId ? DistrictTerm : item;
        } else {
          DistrictTerm = item;
        }
      }
      if (highestTermObj == undefined || highestTermObj.termId < item.termId) {
        highestTermObj = item;
      }
    });
    if (DistrictTerm == undefined || DistrictTerm == null) {
      DistrictTerm = DatesList[0];
    }
  }

  return DistrictTerm;
};
const getOnlyDateValue = (fullDateFormat) => {
  const DateArraySplit = fullDateFormat && fullDateFormat.split(" ");
  return DateArraySplit && DateArraySplit[0];
};
export const getGradesListIfNoTeachersFindInside = (
  GradeList,
  ContextHeader
) => {
  let GradesTOReplace = GradeList;
  if (GradeList && Array.isArray(GradeList) && GradeList[0]) {
    if (
      (GradeList[0].teachers == undefined || GradeList[0].teachers == null) &&
      ContextHeader
    ) {
      const { Roster_Tab, Summary_Roster_Data } = ContextHeader;
      if (
        Array.isArray(Roster_Tab.GradesList) &&
        Roster_Tab.GradesList[0] &&
        Roster_Tab.GradesList[0].teachers
      ) {
        GradesTOReplace = Roster_Tab.GradesList;
      } else if (
        Array.isArray(Summary_Roster_Data.GradesList) &&
        Summary_Roster_Data.GradesList[0] &&
        Summary_Roster_Data.GradesList[0].teachers
      ) {
        GradesTOReplace = Summary_Roster_Data.GradesList;
      }
    }
  }

  return GradesTOReplace;
};

export function CodeAndTestNameReuseble(content,action){
  let cond = false;
  let componentCode = action.payload.Element.componentCode;
  if(content.componentCode === componentCode && content.testName == action.payload.Element.testName){
    cond = true;
  }
   return cond;
}
export function rosterClassWhichHasData(state) {
  let cond = false;
  if (state.ContextHeader.User_Role !== "TEACHER" && state.NavigationByHeaderSelection.class ? true : state.ApiCalls.getRosterClassWhichHasData) {
    cond = true;
  }
  return cond;
}
export function studentIdsCond(ActualStudents, StudentIds) {
  let Ids = StudentIds;
  if (ActualStudents.length == StudentIds.length) {
    Ids = [];
  }
  return Ids;
}
/* this function will handle new Date in diff browsers*/
export const newDateHandlingwithMonthAndDate = (
  dateInput,
  month,
  date,
  DateTabHelper
) => {
  const browserName = GetBrowserName(navigator);
  if (browserName && browserName == "safari" && typeof dateInput === "string") {
    let endDatesArray = dateInput && dateInput.split(" ");
    if (endDatesArray && endDatesArray.length > 0) {
      dateInput = new Date(endDatesArray[0], month, date);
    } else if (DateTabHelper) {
      dateInput = new Date(dateInput, month, date);
    }
  } else {
    dateInput = new Date(dateInput, month, date); // for  non safari
  }

  return dateInput;
};

export const colorCodes = (score, AchivementLevels) => {
  if (AchivementLevels && AchivementLevels.length > 0) {
  switch (true) {
      case (score <= AchivementLevels[0]['max']):
        return "color_circle_avaerage_red";
      case (score <= AchivementLevels[1]['max']):
        return "color_circle_avaerage_orange";
      case (score <= AchivementLevels[2]['max']):
        return "color_circle_avaerage_yellow";
      case (score <= AchivementLevels[3]['max']):
        return "color_circle_avaerage_green"
      default:
        return "color_circle_avaerage_grey";
    }
  }else{
      return "color_circle_avaerage_grey";
  }
}