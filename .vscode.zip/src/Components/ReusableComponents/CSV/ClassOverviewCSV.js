
import { CSVDownload, CSVLink } from "react-csv";
import { connect } from "react-redux";
import React, { Component } from 'react';
import { SetDownloadCsvToFalse } from '../../../Redux_Actions/ReportsActions';
import CsvIcon from '../../../../public/images/ic_save.svg';

class ClassOverviewCSV extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    let NavigationHeader = this.props.Navigation;
    let CSVData = this.props.Class_CSV_details;
    if (CSVData.CSVDataArray.ResPayload != undefined) {
      CSVData = CSVData.CSVDataArray.ResPayload;
    }
    let arr = [];
    if (CSVData.length > 0) {
      var key = 0;
      for (key in CSVData) {
        if (CSVData[key].skills == "null" || CSVData[key].skills == "NA") {
          CSVData[key].skills = "";
        }
        if (CSVData[key].topics == "null" || CSVData[key].topics == "NA") {
          CSVData[key].topics = "";
        }
        if (CSVData[key].claimsAndTargets == "null" || CSVData[key].claimsAndTargets == "NA") {
          CSVData[key].claimsAndTargets = "";
        }
        if (CSVData[key].dok == "null" || CSVData[key].dok == "NA") {
          CSVData[key].dok = "";
        }
        if (CSVData[key].testSubmitted == "null" || CSVData[key].dok == "NA") {
          CSVData[key].testSubmitted = "";
        }
        if (CSVData[key].studentId == "null" || CSVData[key].studentId == null) {
          CSVData[key].studentId = "";
        }
        arr.push(CSVData[key]);
        key++;
      }
    }

    this.props.Class_CSV_details.downloadedcsvdata && arr.length > 0 ? setTimeout(() => {
      this.refs.csv.link.click()
    }, 1000) : null

    return (
      <div style={{ marginTop: '-10px' }}>
        {NavigationHeader.S_performance == true ?
          <span>
            {/* <i className="material-icons" style={{cursor: 'pointer'}} onClick={
             this.props.GetCSVData
            } >
               <img src={CsvIcon} width="20" height="20" />
          </i> */}
            {this.props.Class_CSV_details.downloadedcsvdata && arr.length > 0 ? <CSVLink textColor={'#333'}
              ref="csv"
              data={arr.length == 0 ? csvData : arr}
              headers={standardperformanceheaders}
              filename={"standard_performance.csv"}
              style={{ display: 'none' }}
            >{this.setbackdownlloadcsvtofalse()}</CSVLink>
              : <CSVLink textColor={'#333'}
                ref="csv"
                data={arr.length == 0 ? csvData : arr}
                headers={standardperformanceheaders}
                filename={"standard_performance.csv"}
                style={{ display: 'none' }}
              >{this.setbackdownlloadcsvtofalse()}</CSVLink>
            }

          </span>
          : null}

        {/* For TestScores */}
        {NavigationHeader.T_scores == true ?
          <span>
            {/* <i className="material-icons" style={{cursor: 'pointer'}} onClick={
             this.props.GetCSVData
            } >
             <img src={CsvIcon} width="20" height="20" />
          </i> */}
            {/* { this.props.Class_CSV_details.downloadedcsvdata ? 
         <CSVDownload textColor={'#333'}
          data={ arr.length == 0 ? csvTestScoresData : arr}
           headers={testscoresheaders}
          filename={"test_scores.csv"}>
          {this.setbackdownlloadcsvtofalse()}
           </CSVDownload> 
        : null }  */}

            {this.props.Class_CSV_details.downloadedcsvdata && arr.length > 0 ? <CSVLink textColor={'#333'}
              ref="csv"
              data={arr.length == 0 ? csvTestScoresData : arr}
              headers={testscoresheaders}
              filename={"test_scores.csv"}
              style={{ display: 'none' }}
            >{this.setbackdownlloadcsvtofalse()}</CSVLink>
              : <CSVLink textColor={'#333'}
                ref="csv"
                data={arr.length == 0 ? csvTestScoresData : arr}
                headers={testscoresheaders}
                filename={"test_scores.csv"}
                style={{ display: 'none' }}
              >{this.setbackdownlloadcsvtofalse()}</CSVLink>
            }

          </span>
          : null}
      </div>
    )

  }

  setbackdownlloadcsvtofalse() {
    if (this.props.Class_CSV_details.downloadedcsvdata) {
      this.props.SetDownloadCsvToFalse()
    }
  }
}

const standardperformanceheaders = [
  { label: "District Name", key: "districtName" },
  { label: "School Name", key: "schoolName" },
  { label: "Grade", key: "grade" },
  { label: "Teacher Name", key: "teacherName" },
  { label: "Class Name", key: "className" },
  { label: "Student Name", key: "studentName" },
  { label: "Student ID(SIS) ", key: "studentId" },
  // { label: "Product Name", key: "prodName" },
  { label: "Test Type", key: "testType" },
  { label: "Test Name", key: "testName" },
  { label: "Test Submitted", key: "testSubmitted" },
  { label: "Test Graded", key: "testGraded" },
  // { label: "Test Shared with Student", key: "testSharedWithStudent" },
  { label: "Question Numbers", key: "questionNumber" },
  { label: "Points Earned", key: "pointsEarned" },
  { label: "Total Points", key: "totalPoints" },
  { label: "Strand", key: "strand" },
  { label: "Standard", key: "standard" },
  { label: "DOK", key: "dok" },
  { label: "Claims & Targets", key: "claimsAndTargets" },
  { label: "Topics", key: "topics" },
  { label: "Skills", key: "skills" }
];

const testscoresheaders = [
  { label: "District Name", key: "districtName" },
  { label: "School Name", key: "schoolName" },
  { label: "Grade", key: "grade" },
  { label: "Teacher Name", key: "teacherName" },
  { label: "Class Name", key: "className" },
  { label: "Student Name", key: "studentName" },
  { label: "Student ID(SIS) ", key: "studentId" },
  // { label: "Product Name", key: "prodName" },
  { label: "Test Type", key: "testType" },
  { label: "Test Name", key: "testName" },
  { label: "Test Submitted", key: "testSubmitted" },
  { label: "Test Graded", key: "testGraded" },
  // { label: "Test Shared", key: "testShared" },
  { label: "Percent Score", key: "presentScore" }
]



const csvData = [
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", questionNumber: "", pointsEarned: "", totalPoints: "", strand: "", standard: "", dok: "" },
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", questionNumber: "", pointsEarned: "", totalPoints: "", strand: "", standard: "", dok: "" },
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", questionNumber: "", pointsEarned: "", totalPoints: "", strand: "", standard: "", dok: "" },
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", questionNumber: "", pointsEarned: "", totalPoints: "", strand: "", standard: "", dok: "" }
];
// { districtName: "", schoolName: "", grade: "",teacherName: "",className: "",studentName: "",studentId: "",prodName: "",testType: "", testName: "",testSubmitted: "",testGraded: "",testSharedWithStudent:"",questionNumber:"",pointsEarned: "",totalPoints:"",strand:"",standard:"",dok:""}
const csvTestScoresData = [
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", presentScore: "", pointsEarned: "" },
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", presentScore: "", pointsEarned: "" },
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", presentScore: "", pointsEarned: "" },
  { districtName: "", schoolName: "", grade: "", teacherName: "", className: "", studentName: "", studentId: "", prodName: "", testType: "", testName: "", testSubmitted: "", testGraded: "", presentScore: "", pointsEarned: "" }
]
// { districtName: "", schoolName: "", grade: "",teacherName: "",className: "",studentName: "",studentId: "",prodName: "",testType: "", testName: "",testSubmitted: "",testGraded: "",testShared:"",presentScore:"",pointsEarned: ""}
const mapStateToProps = ({ Reports }) => {
  const { Class_CSV_details } = Reports;
  return {
    Class_CSV_details
  };
}


export default connect(mapStateToProps, {
  SetDownloadCsvToFalse
})(ClassOverviewCSV);
