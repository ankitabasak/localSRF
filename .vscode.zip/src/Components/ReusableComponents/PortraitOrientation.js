import React from 'react'
export const PortraitOrientation = () => (
    <style type="text/css">
      {"@media print{@page {size: portrait !important;}* { overflow: visible !important; }}"}
      {"html, body, #appServerContainer{background:#fff !important;}"}
      {"html, body, #appServerContainer{background-image:none !important;}"}
      {"html.reporting body #appServerContainer{background-image:none !important;}"}
    </style>
);