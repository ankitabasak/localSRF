import React, { Component } from "react";
import { AxisLeft, AxisBottom } from "@vx/axis";
import { scaleLinear, scaleBand } from "@vx/scale";
import { LinePath } from "@vx/shape";
import { Group } from "@vx/group";
import { GridRows } from "@vx/grid";
import * as Curve from "@vx/curve";
import { localPoint } from '@vx/event';
// import BarLine from "../../../Utils/LineChart/Bar/Bar";
import "./LineChartUI.css";

import { Get_Class_TestScores_Details, SetToolTipAndBarValues, CloseToolTip } from "../../../Redux_Actions/ReportsActions";

import { Set_Student_ToolTipAndBarValues } from '../../../Redux_Actions/Student_ReportsAction';

import { connect } from "react-redux";
var ToolTipData = {};
var xpoint = [];
var Xpoint_i = 0;
class LineChartUI extends Component {
  constructor(props) {
    super(props);
    // this.xpoint = [];
    this.X_AxisLabel = [];
    this.setWrapperRef = this.setWrapperRef.bind(this);
    this.handleClickOutside = this.handleClickOutside.bind(this);
    this.ChartBubbleRefs = [];
    this.LinechartDivRef = "";
    this.ToolTipRefs = null;
    this.state = {
      xpoint: 0,
      x_coords: 0,
      y_coords: 0,
      tooltipData: null,
      tooltipDisplay: false,
      activatedTickLabelIndex: 0,
      popupVisible: false,
      X_axisLabelToolTip: '',
      X_LableToolTipName: '',
      Y_axisLabelToolTip: '',
      ToolTipData: null
    };
  }

  componentDidMount() {
    document.addEventListener("mousedown", this.handleClickOutside);
  }

  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside);
  }

  /**
   *
   * @param {JSON element } node -- Storing Element reference.
   */
  setWrapperRef(node) {
    this.wrapperRef = node;
  }
  shouldComponentUpdate(nextProps, nextState) {
    /**
     * if the url is same then will allow to render the component.
     */
    return nextProps.NavigationByHeaderSelection === this.props.NavigationByHeaderSelection
  }

  /**
   *
   * @param {JSX element constex} event --jsx element context at mousedown area.
   * this is to close tooltip pop when out side click.
   *
   */

  handleClickOutside(event) {

    let clickWithinthe_Graph = this.LinechartDivRef.contains(event.target);
    if (clickWithinthe_Graph) {

      if (event.target == null || event.target == undefined) {
        this.handleMouseOut(this.props.ToolTipData);
      } else {
        let isitemexists = this.ChartBubbleRefs.find(item => {
          if (item !== null) {
            return item.contains(event.target) ? true : false;
          } else return false;
        });

        let ToolTipsRefsExists;

        if (this.ToolTipRefs == null) {
          ToolTipsRefsExists = null;
        } else {
          ToolTipsRefsExists = this.ToolTipRefs.contains(event.target);
        }
        if (
          isitemexists == undefined &&
          (ToolTipsRefsExists == null || !ToolTipsRefsExists)
        ) {
          this.handleMouseOut(this.props.ToolTipData);
        }
      }
    }
  }

  handleClick() {

    if (!this.state.popupVisible) {
      // attach/remove event handler
      document.addEventListener("click", this.handleOutsideClick, false);
    } else {
      document.removeEventListener("click", this.handleOutsideClick, false);
      this.setState({ tooltipData: null });
    }

    this.setState(prevState => ({
      popupVisible: !prevState.popupVisible
    }));
  }

  handleOutsideClick(e) {
    // ignore clicks on the component itself
    if (this.node.contains(e.target)) {
      return;
    }
    this.handleClick();
  }

  handlemousehover(xU, yU, test, index) {

    let Nav = this.props.NavigationByHeaderSelection;
    let ClassStrandsObject = this.props.StandardPerformance_Overview
    if (Nav.class && Nav.T_scores) {
      let ContextHeader = this.props.ContextHeader;
      let Token = this.props.LoginDetails.JWTToken;
      let currentTermId = this.props.currentTermID;

      let Req_Payload = {
        // studentId: "",
        classId: ContextHeader.Roster_Tab.SelectedClass.id,
        schoolId: ContextHeader.Roster_Tab.SelectedSchool.id,
        componentCode: test.componentCode,
        districtId: ContextHeader.DistrictId,
        studentIds: ContextHeader.Roster_Tab.StudentIds,
        startDate: ContextHeader.Date_Tab.Report_termStartDate,
        endDate: ContextHeader.Date_Tab.Report_termEndDate,
        isClass: true,
        isSchool: true,
        isDistrict: true,
        grade: ContextHeader.Roster_Tab.selectedRosterGrade,
        rosterGrade: ContextHeader.Roster_Tab.selectedRosterGrade,
        isPastDistrictTerm: ContextHeader.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId // datetab api response first alpha term_id
      };

      Req_Payload.grade = ClassStrandsObject.StandardPerformanceFilter.TestGrade.selectedTestgrade;
      let enableLoading = true;
      let dontPersistforStudent = false;

      this.props.Get_Class_TestScores_Details(Token, Req_Payload, test, enableLoading, dontPersistforStudent);
    }

    let ShowTollTipPopUp = Nav.student;
    if (Nav.class) {
      let ShowTollTipPopUp = Nav.class && Nav.S_performance;
      this.props.SetToolTipAndBarValues(xU, yU, test, true, index, ShowTollTipPopUp, Nav);
    } else if (Nav.student) {
      let updateinclass = true;
      this.props.Set_Student_ToolTipAndBarValues(xU, yU, test, true, index, ShowTollTipPopUp, Nav, updateinclass);
    }
  }
  /**
   * When click on outside of Chart Bubble it will trigger.
   */
  handleMouseOut(ToolTipdata) {
    ToolTipdata.tooltipDisplay ? this.props.CloseToolTip(this.props.NavigationByHeaderSelection) : null
  }

  /**
  * 
  * @param {index} color appending to the polygon 
  * @returns {CSS className} --indicates active label
  */

  polygoncolor(index, ToolTipData) {
    return ToolTipData.activatedTickLabelIndex == index ? "#606060" : "#00539B"
  }
  /**
   * 
   * @param {object} value 
   * @param {int} index  
   *  @param {int} ToolTipData  
   *  @param {int} data  
   * @returns {CSS className} --indicates active label
   */
  TickLableIsActiveORNot(value, index, ToolTipData, data, formattedValue) {
    let DATA;
    let Nav = this.props.NavigationByHeaderSelection;
    let PresentList = data;
    if (ToolTipData.tooltipData !== undefined && ToolTipData.tooltipData !== null) {
      let ToolTipExistBar = PresentList.find(item => item.componentCode == ToolTipData.tooltipData.componentCode);
      if (value == undefined) {
        let comp_code = this.conflictRemover(formattedValue, 'frompolygon')
        if (Nav.student && ToolTipData.activatedTickLabelIndex == null) {
          return "#606060";
        }

        return comp_code == ToolTipData.tooltipData.componentCode ? "#00539B" : "#606060"
      } else {
        return ToolTipExistBar == undefined ? "" : ToolTipData.activatedTickLabelIndex == index ? "activatedLabel" : ""
      }
    } else {
      return value === undefined ? "#606060" : "";
    }
  }

  /**
   * 
   * @param {String} formattedValue  -- X-lable name and componentCode(testId)
   * @returns {String}  -- Will Split int name and componentCode And Returning only TestName for View. 
   */
  conflictRemover(formattedValue, from) {
    let actualValue = formattedValue.split("%%%@%%%");
    actualValue = from == 'frompolygon' ? actualValue[1] : actualValue[0];

    return actualValue;
  }



  /**
   * 
   * @param {Array} data -- which is displaying the graph details. 
   * @param {*} ExistingToolTip  --tooltip data which is current instance at reducer.
   * @param {*} cx -- x_axis of a record
   * @param {*} cy --Y_axis of a record
   * @param {*} test  -- current test 
   * @param {*} i 
   */

  SetLatParamBarOnLastRecord(data, ExistingToolTip, cx, cy, test, i) {
    let Nav = this.props.NavigationByHeaderSelection;

    if (Nav.student) {

      if (ExistingToolTip.tooltipData !== null && ExistingToolTip.tooltipData !== undefined) {

        if (ExistingToolTip.tooltipData.componentCode == test.componentCode && ExistingToolTip.activatedTickLabelIndex == undefined) {
          let updateinclass = false
          this.props.Set_Student_ToolTipAndBarValues(cx, cy, test, true, i, true, Nav, updateinclass)
        }
      }
    } else {


      if (ExistingToolTip.tooltipData !== null && ExistingToolTip.activatedTickLabelIndex === undefined && test && ExistingToolTip.tooltipData) {
   ExistingToolTip.tooltipData.componentCode == test.componentCode ? this.props.SetToolTipAndBarValues(cx, cy, test, true, i, false, Nav) : null

      } else if (data.length === i + 1 && ExistingToolTip.activatedTickLabelIndex == null) {
        /**
         * this case when left most test recored score is 100 then both x and y axis will be 0.
         * if both is 0 then will set right most test score bubble is selected.
         * 
         */
        // if (ToolTipData.tooltipData == null || ToolTipData.tooltipData == undefined) {
        Nav.class ? null
          //  this.props.SetToolTipAndBarValues(cx, cy, test, true, i, false, Nav)
          :
          // Nav.student ? this.props.Set_Student_ToolTipAndBarValues(cx, cy, test, true, i, false, Nav) : 
          null
        // }
      }
    }
  }

  render(props) {
    let { data, margin, width, height, ClassChecked, SchoolChecked,
      DistrictChecked, LastChecked_CB } = this.props;
    //  SchoolChecked = true;
    //  DistrictChecked = true;
    let ClassData = [...data];
    let SchoolData = [...data];
    let DistrictData = [...data];

    ToolTipData = this.props.ToolTipData;
    let Nav = this.props.NavigationByHeaderSelection;
    // bounds
    const xMax = width - margin.left;
    const yMax = height - margin.top - margin.bottom;
    const i_repeater = 0;
    const name = test => (test.buAssignmentId != null ? test.testName + "%%%@%%%" + test.buAssignmentId : test.testName + "%%%@%%%" + test.componentCode);
    const score = test => Nav.district ? test.districtScore : Nav.school ? test.schoolScore : Nav.class ? test.classScore : test.testScore;
    const score_c = test => test.classScore;
    const score_s = test => test.schoolScore;
    const score_d = test => test.districtScore;
    // scales
    const xScale = scaleBand({
      range: [0, xMax],
      domain: data.map(name)
    });

    const yScale = scaleLinear({
      range: [yMax, 0],
      domain: [-10, 100]
    });

    // positions
    const x = test => xScale(name(test));
    const y = test => yScale(score(test));
    const y_c = test => yScale(score_c(test));
    const y_s = test => yScale(score_s(test));
    const y_d = test => yScale(score_d(test));
    // colors
    const primary = "#606060";
    const transparent = "transparent";

    const RedColor = "#FF5B5B";
    const OrangeColor = "#FF8E2D";
    const YellowColor = "#FFC52D";
    const GreenColor = "#32AC41";
    const RedColorBorder = "#FF5B5B";
    const OrangeColorBorder = "#FF8E2D";
    const YellowColorBorder = "#FFC52D";
    const GreenColorBorder = "#32AC41";

    let X_Axis = this.props.XAxis_Params;
    let Y_Axis = this.props.YAxis_Params;
    let DataSet = this.props.DataSetParam;

    return (
      <div className="line_chart_graph" style={{ padding: '10px' }} ref={(node) => this.LinechartDivRef = node}>
        <div className="ForIpad">
          <svg width={width} height={this.props.height}>
            <rect
              x={0}
              y={0}
              width="940"
              height="300"
              fill={transparent}
              rx={14}
            />

            <Group top={margin.top} left={margin.left + 20}>
              <GridRows
                scale={yScale}
                stroke="#D6DBE5"
                width={xMax}
                tickValues={[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]}
                numTicks={11}
              />

              <AxisLeft
                scale={yScale}
                top={0}
                tickValues={[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]}
                left={-30}
                label={Y_Axis.LabelName}
                stroke={"#D6DBE5"}
                tickTextFill={"#606060"}
                tickStroke={"#fff"}
                labelClassName="y---axis"
                labelOffset={Y_Axis.LabelOffset}
                hideAxisLine={true}
                tickLabelProps={({ value, index }) => ({
                  dx: "0.25em",
                  dy: "0.25em",
                  fill: "black",
                  fontSize: 12,
                  fontWeight: 500
                })}
              />
              <Group left={1} top={0}>
                <AxisBottom
                  scale={xScale}
                  top={yMax}
                  label={X_Axis.LabelName}
                  stroke={"#606060"}
                  tickTextFill={"#606060"}
                  tickStroke={"#fff"}
                  labelClassName="x---axis"
                  labelOffset={X_Axis.LabelOffSet}
                  labelProps={{
                    textAnchor: "middle",
                    fontSize: X_Axis.LabelFontSize,
                    fill: "#333"
                  }}
                  tickClassName="custom_tick"
                  tickLabelProps={(value, index) => ({
                    class: this.TickLableIsActiveORNot(value, index, ToolTipData, data)
                  })}

                  tickComponent={({ formattedValue, x, y, ...tickProps }, i) => (
                    <g
                      transform={`translate(${xpoint[Xpoint_i] - 7}, ${y - 24})`}
                      {...tickProps}
                      onMouseEnter={(event) => {
                        const coords = localPoint(event.target.ownerSVGElement, event);

                        this.conflictRemover(formattedValue).length > 12 ?
                          this.setState({
                            X_axisLabelToolTip: coords.x,
                            Y_axisLabelToolTip: coords.y,
                            X_LableToolTipName: this.conflictRemover(formattedValue),
                            DisplayX_AxisToolTip: true
                          }) : null
                      }}
                      onMouseOut={() => {
                        formattedValue.length > 12 ?
                          this.setState({
                            X_axisLabelToolTip: '',
                            X_LableToolTipName: '',
                            Y_axisLabelToolTip: '',
                            DisplayX_AxisToolTip: false
                          }) : null
                      }}
                    >
                      {(Xpoint_i += 1)}
                      <path
                        className="rhombus"
                        x={0}
                        y={0}
                        fill="#606060"
                        test="M5.9,1.2L0.7,6.5l5.2,5.4l5.2-5.4L5.9,1.2z"
                      />
                      <polygon
                        fill={this.TickLableIsActiveORNot(undefined, i, ToolTipData, data, formattedValue)}
                        points='6.5,0 1,6 6.5,12 12,6' />
                      <foreignObject x="-25" y="15" width="60" height="60">
                        <p style={{
                          lineHeight: '1.2',
                          fontSize: '10px',
                          marginBottom: '0'
                        }} xmlns="http://www.w3.org/1999/xhtml">{this.conflictRemover(formattedValue)}</p>
                      </foreignObject>
                    </g>
                  )} />
              </Group>
              {/* <BarLine width={1} height={yMax} ToolTipData={ToolTipData} DisplayingData={data} /> */}
              <LinePath
                data={data}
                x={x}
                y={y}
                stroke={primary}
                strokeWidth={DataSet.LinePathWidth}
                curve={Curve.curveLinear}
              />


              {ClassData.length > 0 && ClassChecked && ClassData[0].classScore !== undefined && ClassData[0].classScore !== null ?

                <LinePath
                  data={ClassData}
                  x={x}
                  y={y_c}
                  stroke={ColorForGraphLine('Class', LastChecked_CB)}
                  strokeWidth={2}
                  strokeDasharray="2,2"
                  curve={Curve.curveLinear}
                /> : null
              }

              {(SchoolData.length > 0 && SchoolChecked && SchoolData[0].schoolScore !== undefined && SchoolChecked && SchoolData[0].schoolScore !== null) ?

                <LinePath
                  data={SchoolData}
                  x={x}
                  y={y_s}
                  stroke={ColorForGraphLine('School', LastChecked_CB)}
                  strokeWidth={2}
                  strokeDasharray="2,2"
                  curve={Curve.curveLinear}
                /> : null
              }

              {
                DistrictChecked && DistrictData.length > 0 ? DistrictData[0].districtScore !== null && DistrictData[0].districtScore !== undefined ?
                  <LinePath
                    data={DistrictData}
                    x={x}
                    y={y_d}
                    stroke={ColorForGraphLine('District', LastChecked_CB)}
                    strokeWidth={2}
                    strokeDasharray="4,4"
                    curve={Curve.curveLinear}
                  /> : null : null
              }
              {ClassData.length > 0 && ClassChecked && ClassData[0].classScore !== undefined && ClassData[0].classScore !== null ? ClassData.map((test, i) => {

                const cx = x(test);
                const cy = y_c(test);

                return (
                  <g
                    key={i}
                    transform={`translate(${cx}, ${cy})`}
                    style={{
                      cursor: "pointer"
                    }}
                    key={`line-point-${i}`}
                    xindex={i}
                    yindex={i}>
                    {/* <circle r={0} strokeWidth="1.5" stroke="#000" fill="#fff" /> */}
                    <rect width="6" height="6" strokeWidth='2' stroke={ColorForGraphLine('Class', LastChecked_CB)} fill={FillOutColor('Class', LastChecked_CB)} transform="translate(-4 -4)" />
                  </g>
                );
              }) : null}

              {(SchoolData.length > 0 && SchoolChecked && SchoolData[0].schoolScore !== undefined && SchoolChecked && SchoolData[0].schoolScore !== null) ? SchoolData.map((test, i) => {

                const cx = x(test);
                const cy = y_s(test);

                return (
                  <g
                    key={i}
                    transform={`translate(${cx}, ${cy})`}
                    style={{
                      cursor: "pointer"
                    }}
                    key={`line-point-${i}`}
                    xindex={i}
                    yindex={i}>
                    <circle r={3} strokeWidth="1.5" stroke={ColorForGraphLine('School', LastChecked_CB)} fill={FillOutColor('School', LastChecked_CB)} />
                  </g>
                );
              }) : null}

              {/* kjsdc */}

              {DistrictChecked && DistrictData.length > 0 ? DistrictData[0].districtScore !== null && DistrictData[0].districtScore !== undefined ? DistrictData.map((test, i) => {

                const cx = x(test);
                const cy = y_d(test);

                return (
                  <g
                    key={i}
                    transform={`translate(${cx}, ${cy})`}
                    style={{
                      cursor: "pointer"
                    }}
                    key={`line-point-${i}`}
                    xindex={i}
                    yindex={i}>
                    <path stroke={ColorForGraphLine('District', LastChecked_CB)} fill={FillOutColor('District', LastChecked_CB)} strokeWidth="2" transform="translate(-4 -4)" d="m0,6l4,-6l4,6l-4,0z" id="svg_16" />
                  </g>
                );
              }) : null : null}

              {data.map((test, i) => {

                const cx = x(test);
                xpoint.push(cx);
                const cy = y(test);
                const point_data = Nav.school ? parseInt(test.schoolScore) :
                  Nav.district ? parseInt(test.districtScore) :
                    Nav.class ? parseInt(test.classScore) : parseInt(test.testScore);;
                const testId = parseInt(test.componentCode);
                let color = "";
                if (point_data <= this.props.AchivementLevels[0]['max']) {
                  color = RedColor;
                } else if (point_data <= this.props.AchivementLevels[1]['max']) {
                  color = OrangeColor;
                } else if (point_data <= this.props.AchivementLevels[2]['max']) {
                  color = YellowColor;
                } else {
                  color = GreenColor;
                }

                return (
                  <g
                    ref={ref => (ref !== null ? this.ChartBubbleRefs[i] = ref : null)}
                    key={i}
                    transform={`translate(${cx}, ${cy})`}
                    style={{
                      cursor: "pointer",
                      margin: 20,
                      marginTop: 50,
                      marginLeft: 50
                    }}
                    key={`line-point-${i}`}
                    // onClick={() =>
                    //   this.handlemousehover(cx, cy, test, i)
                    // }
                    xindex={i}
                    yindex={i}>
                    {!(Nav.S_performance) ? this.SetLatParamBarOnLastRecord(data, ToolTipData, cx, cy, test, i) : null}

                    <circle r={DataSet.DotRadius} stroke={color} strokeWidth="2" fill="#fff" />
                    <text x={point_data < 100 ? point_data < 10 ? -5 : -7 : -8} y={4} fill="#000" fontSize={12} fontWeight={500}>
                      {point_data}
                    </text>
                  </g>
                );
              })}
            </Group>
          </svg>
          {/* {this.X_LabelCustomToolTip(ToolTipParams)} */}
          {/* {ToolTipParams.TooltipDisplayVisible &&
          this.ReturnToolTip_POPUp(tooltipDisplay, x_axis_coords, y_axis_coords, tooltipData, ToolTipParams, ToolTipData, SchoolChecked, DistrictChecked, ClassChecked)} */}
        </div></div>
    );
  }

  /**
   * @param  {object} ToolTipParams --X and Y CO-ordinates 
   */
  // X_LabelCustomToolTip(ToolTipParams) {
  //   let state = this.state;
  //   let Nav = this.props.NavigationByHeaderSelection;
  //   let arrowDirection = 'graph_tooltip_arrow_left';

  //   if (state.DisplayX_AxisToolTip) {
  //     let Top = state.Y_axisLabelToolTip + ToolTipParams.TooltipXcoordsPad;
  //     let Left = state.X_axisLabelToolTip + ToolTipParams.TooltipYcoordsPad;

  //     // Top = Nav.class ? Top + 310 : Top + 520;
  //     /**
  //      * In Student, X-axis Lable Position is exceeds 550 then setting x-axis co-ors tooltip to displat at left side.
  //      * likewise for class bit lable position should exceed 250 for class graph. then will display tooltip at left.  
  //      */
  //     Left = Nav.S_performance ? Left - 80 : Nav.class ? Left : state.X_axisLabelToolTip + 25;
  //     Top = Nav.T_scores ? Nav.class ? Top - 15 : Top - 15 : Top - 55;
  //     let halfWayForToolTip = Nav.S_performance ? 250 : Nav.class ? 330 : 650

  //     // arrowDirection = Left >= halfWayForToolTip ? 'graph_tooltip_arrow_right' : 'graph_tooltip_arrow_left';
  //     // Left = Left >= halfWayForToolTip ? Nav.S_performance ? Left - 210 : Nav.class ? Left - 190 : Left - 205 : Left;
  //     // Left = Nav.class ? Left > 300 ? Left - 120 : Left : Left > 650 ? Left - 150 : Left;
  //     return <div className="graph_tooltip" style={{
  //       display: "block",
  //       position: 'absolute',
  //       opacity: 1,
  //       top: Top, //
  //       left: Left //
  //     }}>
  //       <div className={arrowDirection}></div>
  //       <div className="graph_tooltip_content">{state.X_LableToolTipName}</div>
  //     </div>
  //   }
  // }

  /**
   * 
   * @param {object} tooltip_data  
   * @param {int} x_axis_coords 
   * @param {int} y_axis_coords 
   * @param {object} tooltipData 
   * @param {*} ToolTipParams 
   */

  // ReturnToolTip_POPUp(tooltip_data, x_axis_coords, y_axis_coords, tooltipData, ToolTipParams, ToolTipData, SchoolChecked, DistrictChecked, ClassChecked) {

  //   if (ToolTipData.tooltipDisplay && ToolTipData.popupVisible && ToolTipParams !== undefined && ToolTipData.tooltipData !== null && ToolTipData.activatedTickLabelIndex !== undefined) {

  //     let questionsList = ToolTipData.tooltipData.questionsList;
  //     let QuestionsAreThere = questionsList !== undefined && questionsList !== null ? questionsList.length !== 0 : false

  //     let Nav = this.props.NavigationByHeaderSelection
  //     let halfWayForToolTip = Nav.S_performance ? 150 : 600

  //     let X_coords = ToolTipData.x_coords > halfWayForToolTip ? ToolTipData.x_coords - 300 : ToolTipData.x_coords;
  //     let Tooltip_appended_class = ToolTipData.x_coords > halfWayForToolTip ? 'TooltipAppendedClass' : null;
  //     let Top = Nav.S_performance ? ToolTipData.y_coords - 20 : ToolTipData.y_coords;
  //     // Predict Height of Tooltip In Before
  //     if (QuestionsAreThere) {
  //       let questionsPredict = Math.ceil(questionsList.length / 5);
  //       Top = Top - questionsPredict * 48;
  //     }

  //     let numberOfChecks = [ClassChecked, SchoolChecked, DistrictChecked].filter(item => item === true).length;
  //     Top = numberOfChecks > 2 ? (Top - 93) : numberOfChecks > 1 ? (Top - 57) : numberOfChecks > 0 ? (Top - 30) : Top;

  //     // + ToolTipParams.TooltipXcoordsPad;
  //     let startSubmitDate = ToolTipData.tooltipData.startDate == undefined || ToolTipData.tooltipData.startDate == null || ToolTipData.tooltipData.startDate == '' ? ToolTipData.tooltipData.submitStart : ToolTipData.tooltipData.startDate;

  //     let SubmitDate = ToolTipData.tooltipData.endDate == undefined || ToolTipData.tooltipData.endDate == null || ToolTipData.tooltipData.endDate == '' ? ToolTipData.tooltipData.submitEnd : ToolTipData.tooltipData.endDate;

  //     return (
  //       <div
  //         ref={ref => (this.ToolTipRefs = ref)}
  //         className="bectooltip"
  //         style={{
  //           display: ToolTipData.tooltipDisplay ? "block" : "none",
  //           opacity: ToolTipData.tooltipDisplay ? 1 : 0,
  //           top: Top, //
  //           left: X_coords + ToolTipParams.TooltipYcoordsPad //
  //         }}>
  //         <div className={Tooltip_appended_class !== null ? 'tooltipInr TooltipAppendedClass' : 'tooltipInr'}>
  //           {/* {this.props.children} */}
  //           <div className="tooltip_main">
  //             <div className="tooltip_title">
  //               {ToolTipData.tooltipData === null || ToolTipData.tooltipData === undefined
  //                 ? ""
  //                 : ToolTipData.tooltipData.testName}
  //             </div>
  //             <div className="tooltip_submitted_date">
  //               Submitted :{" "}
  //               {Nav.class ? (startSubmitDate == SubmitDate) ? startSubmitDate : startSubmitDate + '- ' + SubmitDate : (ToolTipData.tooltipData === null || ToolTipData.tooltipData === undefined) ? "" : SubmitDate}
  //             </div>

  //             {questionsList !== null && questionsList !== undefined ? this.ReturnQuestiosInToolTip(questionsList) : null}

  //             {questionsList !== null && !Nav.class ? <div className="tooltip_rows">
  //               <div className="tooltip_row_inr">
  //                 <div className="tooltip_row_lelft">
  //                   <div className="tooltip_row_cmp_name">
  //                     Student Score
  //                   </div>
  //                 </div>
  //                 <div className="tooltip_row_right">
  //                   <div className="tooltip_row_cmp_percentage">{ToolTipData.tooltipData === null || ToolTipData.tooltipData === undefined
  //                     ? ""
  //                     : ToolTipData.tooltipData.testScore}%</div>
  //                 </div>
  //               </div>
  //             </div> : null}
  //             {Nav.class ? <ReturnScoresBasedOnCheckBox_Selection RowName="Class Score" ResultCount={ToolTipData.tooltipData.classResults}
  //               QuestionCount={ToolTipData.tooltipData.totalQuestions} Score={ToolTipData.tooltipData.testScore} /> : null}
  //             {ClassChecked ? <ReturnScoresBasedOnCheckBox_Selection RowName="Class Score" ResultCount={ToolTipData.tooltipData.classResults}
  //               QuestionCount={ToolTipData.tooltipData.totalQuestions} Score={ToolTipData.tooltipData.classScore} /> : null}
  //             {SchoolChecked ? <ReturnScoresBasedOnCheckBox_Selection RowName="School Score" ResultCount={ToolTipData.tooltipData.schoolResults}
  //               QuestionCount={ToolTipData.tooltipData.totalQuestions} Score={ToolTipData.tooltipData.schoolScore} /> : null}
  //             {DistrictChecked ? <ReturnScoresBasedOnCheckBox_Selection RowName="District Score" ResultCount={ToolTipData.tooltipData.districtResults}
  //               QuestionCount={ToolTipData.tooltipData.totalQuestions} Score={ToolTipData.tooltipData.districtScore} /> : null}
  //           </div>
  //         </div>
  //       </div>
  //     );
  //   }
  // }


  ReturnQuestiosInToolTip(questionsList) {
    if (questionsList.length != 0) {
      return <div className="tooltip_questions">
        <div className="tooltip_questions_left">Questions:  {" "}</div>
        <div
          className="tooltip_questions_right">
          {questionsList.sort((a, b) => a - b).map(item =>
            <span
            // Don't Delete it will be in milestone2
            // style={{ cursor: "pointer" }}
            // onClick={() => window.open('_blanQuestion Number is ${item}')}
            ><a target="_blank" href={process.env.LMS2_BASE_URL + 'grading/student-view/'} className="">{item}</a></span>
          )}
        </div>
      </div >
    }
  }
  //   Return_X_Y_axis(x, y) {
  //     // return `translate(${xpoint[xpoint_i]}, ${y - 24})`);
  //   }
}

const mapStateToProps = ({ Authentication, Reports, StudentReports, Universal }) => {
  let { LoginDetails } = Authentication;
  const { Class, Student, LineChart_Pagination, Test_Scores_OverTime, StandardPerformance_Overview } = Reports;
  const { AchivementLevels, NavigationByHeaderSelection, ContextHeader,currentTermID } = Universal;
  // const { S_Test_Scores_OverView,S_StandardPerformance_Overview } = StudentReports
  return {
    AchivementLevels, LoginDetails, Class, NavigationByHeaderSelection, Test_Scores_OverTime, ContextHeader,
    LineChart_Pagination, Student, StandardPerformance_Overview,currentTermID
  };
};

export default connect(
  mapStateToProps,
  {
    Get_Class_TestScores_Details, SetToolTipAndBarValues, CloseToolTip,
    Set_Student_ToolTipAndBarValues
  }
)(LineChartUI);

export const ReturnScoresBasedOnCheckBox_Selection = (Props) => {
  return (
    <div className="tooltip_row_inr">
      <div className="tooltip_row_lelft">
        <div className="tooltip_row_cmp_name">
          {Props.RowName}
        </div>
        <div className="tooltip_row_cmp_res_list">{Props.QuestionCount} questions, {Props.ResultCount} results</div>
      </div>
      <div className="tooltip_row_right">
        <div className="tooltip_row_cmp_percentage">
          {Props.Score}%</div>
      </div>
    </div>
  )
}


/**
 * 
 * @param {String} from 
 * @param {String} LastChecked_CB 
 */
function ColorForGraphLine(from, LastChecked_CB) {

  return from == LastChecked_CB ? '#00539b' : '#606060'

}

function FillOutColor(from, LastChecked_CB) {
  return from == LastChecked_CB ? '#00539b' : '#ffffff'
}