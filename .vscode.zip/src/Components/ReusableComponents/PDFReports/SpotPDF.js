import React from 'react';
import ReactToPrint from 'react-to-print';
import './SpotPDF.css';
import './SpotPDFTablePart.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import Chart from '../PDFReports/SpotReusable';
import ReactHtmlParser from 'react-html-parser';
import CompareCheckBoxesForPDF from '../PDFReports/CompareCheckBoxesPDF';
import { connect } from "react-redux";
import { convertUTCDateToLocalDate, displayLocalTimeInPDFContextHeaderBasedOnFlag, Sort_ApiResponse_Payload_Array } from '../AllReusableFunctions';
import { resetTriggerPDF } from "../../../Redux_Actions/SpotPrintAction";
import { PortraitOrientation } from '../PortraitOrientation';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../Utils/globalVars';
class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
        
    }

  getCurrentDate(separator='/'){

      let newDate = new Date()
      let date = newDate.getDate();
      let month = newDate.getMonth() + 1;
      let year = newDate.getFullYear();
      
      return `${month<10?`0${month}`:`${month}`}${separator}${date}${separator}${year}`
  }

   colorCodes(score,AchivementLevels) {
        switch (true) {
            case (score == null):
                return "spot_pdf_avgscore_student spot_pdf_grey";
            case (score  <= AchivementLevels[0]['max']):
                return "spot_pdf_avgscore_student spot_pdf_red";
            case (score <= AchivementLevels[1]['max']):
                return "spot_pdf_avgscore_student spot_pdf_orange";
            case (score <= AchivementLevels[2]['max']):
                return "spot_pdf_avgscore_student spot_pdf_yellow";
            case (score <= AchivementLevels[3]['max']):
                return "spot_pdf_avgscore_student spot_pdf_green"
            default:
                return "spot_pdf_avgscore_student spot_pdf_grey";
        }
    }
    ReusableChart(data,XAxis_Params,YAxis_Params,DataSetParam,TooltipParams,ToolTipData,ClassChecked,SchoolChecked,DistrictChecked,LastChecked_CB){
        let rows = [];
        let row;
        let unit = 10;

        let data_length = Math.ceil(data.length / unit);
        for (let i = 0; i < data_length; i++) {
          row = '';
                  row = (
            
              <span key={i}>
<Chart margin={{ left: 60, right: 0, bottom: 37, top: 30 }} width={980}
                                height={400} data={data.slice(unit * i, unit * (i + 1))}
                                XAxis_Params={XAxis_Params} 
                                YAxis_Params={YAxis_Params}
                                DataSetParam={DataSetParam}
                                TooltipParams={TooltipParams}
                                ToolTipData={ToolTipData}
                                ClassChecked={ClassChecked}
                                SchoolChecked={SchoolChecked}
                                DistrictChecked={DistrictChecked}
                                LastChecked_CB={LastChecked_CB}/>
                                

<div class="Test_names_label" style={{float:"left"}}>Test Name</div>
              </span>

           
          );
            rows.push(row);
           
        }
        return rows
      }
      ReturnTestItems(tests) {
        return tests.length>0?tests.map(item =>
          <span>
            <b>{item.testDUPName}:</b> {item.testName}
            </span>
                  ).reduce((prev, curr) => [prev, ', ', curr]):null;
    }

    TestScores(test_data,selectedOverallAvg,selectedStdDef){
      let test_rows = [];
      let test_row;
      let test_unit = (selectedOverallAvg || selectedStdDef)?6:10;
      let test_data_length = Math.ceil(test_data.length / test_unit);
      let DivSizeTenPercent = (test_unit === 10)? true:false;
      for (let j = 0; j < test_data_length; j++) {
        let new_test_data = test_data.slice(test_unit * j, test_unit * (j + 1));
          test_row = '';
          test_row = (
            <div className="spot_pdf_table_single_row">
{this.ReturnTestScores(new_test_data,DivSizeTenPercent)}
            </div>
      );
      test_rows.push(test_row);
         
      }
      return test_rows
    }
    ReturnTestScores(score,DivSizeTenPercent){
      return score.length>0?score.map(score =>
       <div className={DivSizeTenPercent?"spot_pdf_table_field spot_pdf_table_field_width":"spot_pdf_table_field"}>
        <div className="spot_pdf_table_field_score">
      <span className={"spot_pdf_table_field_score_unit "+this.colorCodes(score.totalScore,this.props.AchivementLevels)} >{score.totalScore != null?score.score +" / "+score.maxScore:" - "}</span>
        </div>
      <div className="spot_pdf_table_field_meta">{score.totalScore != null?score.totalScore+"%"+" | ":null}{score.totalScore != null?score.overallQuestions:null}</div>
      </div>
             ):null;
  }
  ReturnHeaderDate(testEndDate, testEndTime){
      let dates =  null;
      dates =  DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(testEndDate, testEndTime):testEndDate;
      return dates;

  }
    ReturnHeaderTestNames(tests,DivSizeTenPercent){
      return tests.length>0?tests.map(item =>
        <div className={DivSizeTenPercent?"spot_pdf_table_field spot_pdf_table_field_width":"spot_pdf_table_field"}>
              <div className="spot_pdf_table_field_name">{item.testDUPName}</div>
              <div className="spot_pdf_table_field_date">{(item.testEndDate != null && item.testEndDate != undefined && item.testEndTime != null && item.testEndTime != undefined)? "("+this.ReturnHeaderDate(item.testEndDate,item.testEndTime)+")":null}</div>
            </div>
             ):null;
  }
  StandardTestNames(head_data,selectedOverallAvg,selectedStdDef){
    let head_rows = [];
    let head_row;
    let head_unit = (selectedOverallAvg || selectedStdDef)?6:10;
    let head_data_length = Math.ceil(head_data.length / head_unit);
    let DivSizeTenPercent = (head_unit === 10)? true:false;
    for (let j = 0; j < head_data_length; j++) {
      let new_head_data = head_data.slice(head_unit * j, head_unit * (j + 1));
        head_row = '';
      head_row = (
        
<div className="spot_pdf_table_single_row">
            {this.ReturnHeaderTestNames(new_head_data,DivSizeTenPercent)}
          </div>
          

     
    );
      head_rows.push(head_row);
       
    }
    return head_rows
  }
  StandarsDataBlock(standardsData,selectedOverallAvg,selectedStdDef){
       return standardsData.length>0?standardsData.map(item =>
      <div className="spot_pdf_table_singleData_blk">
         <div className="spot_pdf_table_standard spot_pdf_table_align_left">{item.standardShortValue}</div>
          {selectedStdDef?<div className="spot_pdf_table_def spot_pdf_table_align_left">
          {item.standardDef != null ? item.standardDef:"-"}
          </div>:null}
          {selectedOverallAvg?<div className="spot_pdf_table_score spot_makeItVerticallyAlign">
            <div className="spot_pdf_avg_field">
              <div className="spot_pdf_table_field_score">
                <span className={"spot_pdf_table_field_score_unit "+this.colorCodes(item.totalPercentage.totalScore,this.props.AchivementLevels)}>
    {item.totalPercentage.totalScore != null?item.totalPercentage.score +" / "+item.totalPercentage.maxScore:" - "}
                </span>
              </div>
              <div className="spot_pdf_table_field_meta">{item.totalPercentage.totalScore != null?item.totalPercentage.totalScore+"%"+" | ":null}{item.totalPercentage.totalScore != null?item.totalPercentage.totalNoofQuestions:null} </div>
            </div>
          </div>:null}
          <div className="spot_pdf_table_tests_scores_block">
            {this.TestScores(item.totalData,selectedOverallAvg,selectedStdDef)}
            
            </div>
        </div>
 
      
 
           ):null;
     }
       
  
  standardsBlock(testStandardsList,selectedOverallAvg,selectedStdDef,StandardFlag){
    return ((testStandardsList !== undefined && testStandardsList !== null) && (testStandardsList.length>0))?testStandardsList.map(item =>
      <div className="spot_pdf_table_singleBodyBlock">
        <div className="spot_pdf_table_singleViewRow">
         {item.viewName} {(StandardFlag === true)?item.standardsData.length>0?"("+item.standardsData.length+")":null:null}
        </div>
        { this.StandarsDataBlock(item.standardsData,selectedOverallAvg,selectedStdDef)}
       </div>
      ):null;
     }
    render() {

        let TestNamesList = this.props.linechartprops;
        let ContextDetails = this.props.contextheaderprops.Roster_Tab;
        let TestDetails = this.props.contextheaderprops;
        let ProductDetails = this.props.contextheaderprops;
        let NewClassChecked = this.props.ClassChecked;
        if (ProductDetails.Tests_of_PresentClass.length > 0) {
            ProductDetails = ProductDetails.Tests_of_PresentClass[0].productName;
        } else {
            ProductDetails = "";
        }

        let LineChartData;
        let Pagination_StartCount = this.props.Pagination.Chart_Page_Count_Start + 1;
        let Pagination_EndCount = this.props.Pagination.Chart_Page_Count_End;
        if (Pagination_EndCount > TestNamesList.ActualLineChartData.length) {
            Pagination_EndCount = TestNamesList.ActualLineChartData.length;
        }
        if (TestNamesList.ActualLineChartData != undefined) {
            LineChartData = TestNamesList.ActualLineChartData
        }
        let dataArray = Sort_ApiResponse_Payload_Array(JSON.parse(JSON.stringify(this.props.data)), 'linechartlist');
        dataArray.reverse();
        let page_rows = [];
        let responseData = this.props.responseData;
        let selectedOverallAvg = this.props.studentSPOTPrint.performanceOvertimeData.showSelection.selectedOverallAvg_temp;
        let selectedStdDef = this.props.studentSPOTPrint.performanceOvertimeData.showSelection.selectedStdDef_temp;
        const {StrandNameOfSelectedStandard,selectedstandardObject} = this.props
        let StandardFlag = (this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== undefined && this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== null) ? this.props.studentSPOTPrint.performanceOvertimeData.viewSelection.selectedView != "strand"?true:false: null;
        //let addExtraTestsBasedonCheckboxesSelection =  (selectedOverallAvg == false && selectedStdDef == false)?false:true;

             for (let k = 0; k < Math.floor(responseData.studentList.length);  k++) {
            let studentName = (responseData.studentList[k].studentName !== undefined && responseData.studentList[k].studentName !== null )?responseData.studentList[k].studentName:null;
            let testHeadersList = (responseData.studentList[k].testMainHeaders !== undefined && responseData.studentList[k].testMainHeaders !== null )?responseData.studentList[k].testMainHeaders:[];
            let standardsHeadersList = (responseData.studentList[k].testStandardsListHeaders !== undefined && responseData.studentList[k].testStandardsListHeaders !== null )?responseData.studentList[k].testStandardsListHeaders:null;
            let graphData = (responseData.studentList[k].testOvertimeGraph.testGraph !== undefined && responseData.studentList[k].testOvertimeGraph.testGraph !== null )?responseData.studentList[k].testOvertimeGraph.testGraph:null;
            let averageScore = (responseData.studentList[k].testOvertimeGraph.testScoreCal !== undefined && responseData.studentList[k].testOvertimeGraph.testScoreCal !== null )?responseData.studentList[k].testOvertimeGraph.testScoreCal:null;
            let testStandardsList = (responseData.studentList[k].testStandardsList !== undefined && responseData.studentList[k].testStandardsList !== null )?responseData.studentList[k].testStandardsList:null;
     

            const page_row = (
                <div className="spot_pdf" key={(k+1)} id={"reporting_spot_pdfid"+(k+1)}>
                <div className="spot_pdf_inr">
                    <div className="spot_pdf_header">
                        <div className="spot_pdf_logo">
                            <img src={beclogo} width="105" height="28" />
                        </div>
                        <div className="spot_pdfHeaderRight">
                                <div className="spot_pdf_header_right_top">
                                  <span>Standards Performance Over Time | Student Achievement Level</span>
                                </div>
                                <div>
                                  <div className="spot_pdf_header_right_bottom_createdBy">
                                    <b>Created by:</b> {TestDetails.LoggedInUserName}
                                  </div>
                                  <div className="spot_pdf_header_right_bottom_Date">
                                    <b>Date:</b> {this.getCurrentDate()}
                                  </div>
                                </div>
                        </div>
                        <div className="spot_pdf_head_text">
                            {ProductDetails}
                        </div>
                    </div>
                    <div className="spot_pdf_context_header">
                        <div className="spot_pdf_header_row">
                            <ul>
                            {ContextDetails.SelectedStudent != "All" && this.props.nav.student ? <li className="pdf_class_name">
                                    <span>
                                        <b>Student</b>: <span className={this.props.nav.student?"spot_pdf_current_context_color":""}>{studentName}</span>
                                    </span>
                                </li> : null}

                                {this.props.nav.class && ContextDetails.SelectedStudent != "All" && (ContextDetails.SelectedStudent.length != ContextDetails.StudentsList.length) ?
                                    <li className="pdf_class_name">
                                        <span>
                                            <b>Student</b>: Custom ({ContextDetails.SelectedStudent.length})
                                        </span>
                                    </li>
                                    : null}

{this.props.nav.student || this.props.nav.class? <li className="pdf_class_name">
                                    <span>
                                        <b>Class Name</b>: <span className={this.props.nav.class?"spot_pdf_current_context_color":""}>{ContextDetails.SelectedClass.name}</span>
                                    </span>
                                </li>:null }
                              {!this.props.nav.district?<li className="pdf_teacher_name">
                        <span>
                            <b>Teacher</b>:  {ContextDetails.SelectedTeacher == "All" ? "All":ContextDetails.TeacherIds.length > 1 ?"Custom("+ContextDetails.TeacherIds.length+")": ContextDetails.SelectedTeacher.name}
                        </span>
                    </li>:null}
                    <li className="pdf_grade">
                                    <span>
                                        <b>Grade</b>: {convertGrade(ContextDetails.selectedRosterGrade)}
                                    </span>
                                </li>
                                {((ContextDetails.SelectedStudent === "All" && this.props.nav.class)|| this.props.nav.school)?<li className="pdf_school_name">
                                    <span>
                                        <b>School</b>: <span className={this.props.nav.school?"spot_pdf_current_context_color":""}>{ContextDetails.SelectedSchool.name}</span>
                                    </span>
                                </li>:null}
                                {(this.props.nav.school || this.props.nav.district)?<li className="pdf_district_name">
                                    <span>
                                        <b>District</b>: <span className={this.props.nav.district?"spot_pdf_current_context_color":""}>{ContextDetails.SelectedDistrict.name}</span>
                                    </span>
                                </li>:null}
                                {(this.props.nav.district)?<li className="pdf_tests_name">
                                    <span>
                                        <b>Tests</b>: {TestDetails.tests}
                                    </span>
                                </li>:null}
                                {(this.props.nav.district)?<li className="pdf_dates">
                                    <span>
                                        <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                    </span>
                                </li>:null}
                                {(this.props.nav.student )?<li className="pdf_school_name">
                                    <span>
                                        <b>School</b>: {ContextDetails.SelectedSchool.name}
                                    </span>
                                </li>:null}
                                </ul>
            </div>
            <div className={`spot_pdf_header_row spot_pdf_PO ${(this.props.nav.school || this.props.nav.district)?"spot_pdf_header_row_last_header_border":(this.props.nav.student || this.props.nav.class)?"spot_pdf_header_row_required_border":""}`}>
                <ul>
                
                                {(this.props.nav.student || this.props.nav.class)?<li className="pdf_district_name">
                                    <span>
                                        <b>District</b>: {ContextDetails.SelectedDistrict.name}
                                    </span>
                                </li>:null}
                                {(!this.props.nav.district)?<li className="pdf_tests_name">
                                    <span>
                                        <b>Test</b>: {TestDetails.tests}
                                    </span>
                                </li>:null}
                                {(!this.props.nav.district)?<li className="pdf_dates">
                                    <span>
            <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                    </span>
                                </li>:null}
                                {(this.props.nav.school || this.props.nav.district)?<li className="pdf_assessed_dates">
                                    <span>
                                        <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                                    </span>
                                </li>:null}
                                {(this.props.nav.school || this.props.nav.district) && (ContextDetails.selectedRosterGrade != this.props.selectedTestGrade) ? <li className="pdf_testdata_assessed_for">
                                    <span>
                                        <b>Test Data Assessed For Grade </b>:  {typeof this.props.selectedTestGrade === 'object' && this.props.selectedTestGrade !== null?convertGrade(this.props.selectedTestGrade.grade):convertGrade(this.props.selectedTestGrade)}
                                    </span>
                                </li>:null}
                                {ContextDetails.selectedRosterGrade != this.props.selectedTestGrade ?<li className="pdf_testdata_assessed_for">
                                    <span>
                                        <b>Test Data Assessed For Grade</b>:  {typeof this.props.selectedTestGrade === 'object' && this.props.selectedTestGrade !== null?convertGrade(this.props.selectedTestGrade.grade):convertGrade(this.props.selectedTestGrade)}
                                    </span>
                                </li>:null}
                            </ul>
                        </div>
                        {(this.props.nav.student || this.props.nav.class)?<div className="spot_pdf_header_row spot_pdf_border_none">
                <ul>
                <li className="pdf_assessed_dates">
                                    <span>
                                        <b>Assessed With </b>: {this.props.selectedTestAssessment}+ Questions
                                    </span>
                                </li>
                               
                    </ul>
                    </div>:null}
                    </div>
                    <div className="spot_pdf_body">
                        <div className="spot_pdf_middle">

                        <div className={StandardFlag?"spot_pdf_test_renames spot_header_condition_margin":"spot_pdf_test_renames"}>
          <div className="spot_pdf_test_renames_inr">
            <div className="spot_pdf_test_renames_centerBox">
        <p>{this.ReturnTestItems(testHeadersList)}</p>
            </div>
          </div>
        </div>
        {(selectedstandardObject !== null) && (Object.keys(selectedstandardObject).length !== 0) && (this.props.studentSPOTPrint.performanceOvertimeData.viewSelection.selectedView_temp == "strand") ? (this.props.studentSPOTPrint.performanceOvertimeData.isStrand === false)?<div className="spot_pdf_stand_defination">
        <b>{StrandNameOfSelectedStandard}  |  {selectedstandardObject.standardDef}  |  {selectedstandardObject.standardName}:</b> {ReactHtmlParser(selectedstandardObject.standardDesc)}
         </div>:null:null}
         {(this.props.studentSPOTPrint.performanceOvertimeData.isStrand === true && (this.props.studentSPOTPrint.performanceOvertimeData.viewSelection.selectedView_temp === "strand"))?<div className="spot_pdf_stand_defination" style={{textAlign:"center"}}><b>{StrandNameOfSelectedStandard}</b></div>:null}

        {(this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== undefined && this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== null) ? this.props.studentSPOTPrint.performanceOvertimeData.viewSelection.selectedView === "strand"?<div style={{ marginTop: "8px" }}>
                                <div className="spot_pdf_student_list_block_head_title">
                                    Average Score {averageScore.testAvg}% based on {averageScore.totalQuestions} questions
                            </div>
                              
                                 {!this.props.nav.district?<CompareCheckBoxesForPDF
                                    Navselection={this.props.nav}
                                    TS_Overtime={this.props.TS_Overtime}
                                    CheckeThis={this.props.CheckeThis}
                                    ClickOnLabel={this.props.ClickOnLabel}
                                    lastcheckedlabel={this.props.LastChecked_CB} />:null}
                            </div>:null:null}
                            {(this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== undefined && this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== null)?this.props.studentSPOTPrint.performanceOvertimeData.viewSelection.selectedView === "strand"?this.ReusableChart(graphData,this.props.XAxis_Params,this.props.YAxis_Params,this.props.DataSetParam,this.props.TooltipParams,this.props.ToolTipData,NewClassChecked,this.props.SchoolChecked,this.props.DistrictChecked,this.props.LastChecked_CB):null:null}
                            

                            
                        </div>
                    </div>
                    {(this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== undefined && this.props.studentSPOTPrint.performanceOvertimeData.viewSelection !== null)?this.props.studentSPOTPrint.performanceOvertimeData.viewSelection.selectedView === "strand"?<div className="spot_pdf_note"><b>Note:</b> The Average Score for all standards reports equals (earned points/total points)*100. The Average Score listed in the line graph above is calculated from all data available for each assessment based on the context selected. It does not assume the cohort of students remains the same across the assessments listed.</div>:null:null}
                    <div className="spot_pdf_achivement_levels_footer">
          <div className="spot_pdf_achivement_levels_footer_inr">
            <div className="spot_pdf_achivement_levels_footer_centerBox">
              <div className="achivement_level_left">
            <ul>
                        <li>
                        <b style={{fontFamily:"Quicksand"}}>Achievement Levels:</b>
                            </li>
                        <li>
                            <div className="spot_pdf_color_stripe_block">
                                <div className="spot_pdf_color_stripe_bar"></div>
                                <div className="spot_pdf_color_stripe_text">
                                    &lt; {this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="spot_pdf_color_stripe_block">
                                <div className="spot_pdf_color_stripe_bar"></div>
                                <div className="spot_pdf_color_stripe_text">
                                {this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="spot_pdf_color_stripe_block">
                                <div className="spot_pdf_color_stripe_bar"></div>
                                <div className="spot_pdf_color_stripe_text">
                                {this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="spot_pdf_color_stripe_block">
                                <div className="spot_pdf_color_stripe_bar"></div>
                                <div className="spot_pdf_color_stripe_text">
                                    &ge; {this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="spot_pdf_color_stripe_block">
                                <div className="spot_pdf_color_stripe_bar"></div>
                                <div className="spot_pdf_color_stripe_text">
                                   No Data Available 
                                    </div>
                            </div>
                        </li>
                    </ul>
                    </div>   
                    <div className="achivement_level_right">
                      <span>
                      Avg. Score % | No. of Questions Assessed
                      </span>
                      </div>  
            </div>
          </div>
        </div>
                    <div className="spot_pdf_table">
  <div className="spot_pdf_table_inr">
    {/* header */}
    <div className="spot_pdf_table_header">
      <div className="spot_pdf_table_header_inr">
        <div className="spot_pdf_table_standard spotMarginAuto"><b>Standard</b></div>
        {selectedStdDef?<div className="spot_pdf_table_def spotMarginAuto"  style={{textAlign:"center"}}><b>Definition</b></div>:null}
        {selectedOverallAvg?<div className="spot_pdf_table_score spotMarginAuto"><b>Overall Score</b></div>:null}
        <div className="spot_pdf_table_tests_scores_block">
        
          {this.StandardTestNames(standardsHeadersList,selectedOverallAvg,selectedStdDef)}
</div>
      </div>
    </div>
    {/* header */}
    {/* body */}
    <div className="spot_pdf_table_body">
      {this.standardsBlock(testStandardsList,selectedOverallAvg,selectedStdDef,StandardFlag)}
      
      </div>
    {/* body */}
  </div>
</div>




                </div>
                <div class="page-break-after">&nbsp;</div>
            </div>
        
                )
                page_rows.push(page_row);
    
    
            }
        return (
            <div>
            {page_rows}
            </div>
            );
    }
}

class SpotPDF extends React.Component {
    constructor(props) {
        super(props);
        this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
    }
    componentDidMount(){
        this.autoTriggerFunction()
      }
      componentDidUpdate(){
        this.autoTriggerFunction()
      }
  
      autoTriggerFunction(e){
        let Nav = this.props.NavigationByHeaderSelection
        let selectedData = this.props.studentSPOTPrint;
        if((Nav.student) &&(selectedData.performanceOvertimeData.triggerPDF === true)){
            document.getElementById('printIcon').click();
          this.props.resetTriggerPDF()
        }
      }
    render() {
        let conditionalRender = false;
        const conditionalData = this.props.ContextHeader.Roster_Tab;

        if(conditionalData.StudentIds.length > 0 && conditionalData.TeacherIds.length > 0 && conditionalData.schoolsList.length > 0){
            conditionalRender = true
        }
        if(this.props.NavigationByHeaderSelection.district){
            conditionalRender = true
        }
        const {StrandNameOfSelectedStandard,selectedstandardObject} = this.props
        return (
            <div>
                {conditionalRender ? <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon" id="printIcon"><img src={printIco} width="21" /></span>}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                    <PortraitOrientation />
                    <ComponentToPrint
                        nav={this.props.NavigationByHeaderSelection}
                        ferppaCoppaEnable={this.props.ferppaCoppaEnable}
                        linechartprops={this.props.StandardPerformance_Overview}
                        contextheaderprops={this.props.ContextHeader}
                        data={this.props.data} XAxis_Params={this.props.XAxis_Params}
                        YAxis_Params={this.props.YAxis_Params}
                        DataSetParam={this.props.DataSetParam}
                        selectedTestAssessment={this.props.selectedTestAssessment}
                        selectedTestGrade={this.props.selectedTestGrade}
                        // TooltipParams={tooltipParams}
                        TooltipParams={this.props.TooltipParams}
                        ToolTipData={this.props.ToolTipData}
                        ClassChecked={this.props.ClassChecked}
                        SchoolChecked={this.props.SchoolChecked}
                        DistrictChecked={this.props.DistrictChecked}
                        LastChecked_CB={this.props.LastChecked_CB}
                        standardName={this.props.standardName}
                        strandName={this.props.strandName}
                        strandDetailsDesc={this.props.strandDetailsDesc}
                        strandDescription={this.props.strandDescription}
                        Navselection={this.props.Navselection}
                        TS_Overtime={this.props.TS_Overtime}
                        CheckeThis={this.props.CheckeThis}
                        Pagination={this.props.Pagination}
                        totalAverageScore={this.props.totalAverageScore}
                        totalQuestions={this.props.totalQuestions}
                        studentSPOTPrint={this.props.studentSPOTPrint}
                        responseData =  {this.props.responseData}
                        ref={el => (this.componentRef = el)}
                        StrandNameOfSelectedStandard = {StrandNameOfSelectedStandard}
                        selectedstandardObject={selectedstandardObject}
                        AchivementLevels= {this.props.AchivementLevels}
                        from="SpotPDF.js"
                    />
                </div>
                </div> : null}
            </div>
        );
    }
}

const mapStateToProps = ({ Universal, Reports, SpotPrintReducer,StudentReports }) => {
    const { AchivementLevels, ContextHeader, NavigationByHeaderSelection,ferppaCoppaEnable } = Universal
    const { StandardPerformance_Overview } = Reports;
    const { studentSPOTPrint } = SpotPrintReducer;
    const {S_StandardPerformance_Overview} = StudentReports
    const {StandardPerformanceFilter,StrandNameOfSelectedStandard,selectedstandardObject} = S_StandardPerformance_Overview
    return {
        AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview, ferppaCoppaEnable, studentSPOTPrint,
        StandardPerformanceFilter,StrandNameOfSelectedStandard,selectedstandardObject,S_StandardPerformance_Overview
    };
}

export default connect(mapStateToProps, {
  resetTriggerPDF
})(SpotPDF);

function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }

}

