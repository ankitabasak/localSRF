import React, { Component } from 'react';
import './ST_AnalysisCheckBoxesForPDF.css'
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
class ST_AnalysisCheckBoxesForPDF extends Component {

    constructor() {
        super();
        this.state = {
            CompareActiveFor: '',
            updatedCompareActive: false
        }
        this.addClass = this.addClass.bind(this);
    }

    updateCompareActive() {
        this.setState({
            updatedCompareActive: true
        });
    }

    addClass(compareActiveFor) {
        this.setState({ compareActiveFor });
    }

    render() {

        let NavigationSelection = this.props.Navselection;
        let BatchPrint = (this.props.BatchPrint !== undefined && this.props.BatchPrint == null)?this.props.BatchPrint:false;
   
        return (
            
            <div className="compare_pdf_singletest_block text-center">
                <ul className="summary_pdf_singletest_block-ul-list">

                    <li className="compare_pdf_singletest_title">Compare:</li>
                    {
                        NavigationSelection.student || BatchPrint  ?<li className={this.props.lastcheckedlabel === "Class" ?  "compare_pdf_compareCheckBoxesSingleUI pdf_class-compare compare_pdf_activeCompare" : "compare_pdf_compareCheckBoxesSingleUI compare_pdf_class-compare"}>
                    
                   {this.props.ST_Compare.checkClass?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                    
                    {/* <label className={this.props.ST_Compare.checkClass ? "compare_pdf_compare-checkbox summary_activeComparePDF" : "compare_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className="compare_pdf_compare_title">Class</span>
                        </li>
                        :null
                    }

                    {
                        NavigationSelection.student || NavigationSelection.class  ? <li className={this.props.lastcheckedlabel === "School" ? "compare_pdf_compareCheckBoxesSingleUI compare_pdf_school-compare compare_pdf_activeCompare" : "compare_pdf_compareCheckBoxesSingleUI compare_pdf_school-compare"}>
                        {this.props.ST_Compare.checkSchool?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        
                        {/* <label className={this.props.ST_Compare.checkSchool ? "compare_pdf_compare-checkbox summary_activeComparePDF" : "compare_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className="compare_pdf_compare_title">School</span>
                    </li>:null
                    }

                    {
                        NavigationSelection.student || NavigationSelection.class || NavigationSelection.school || NavigationSelection.district ?<li className={this.props.lastcheckedlabel === "District" ? "compare_pdf_compareCheckBoxesSingleUI compare_pdf_district-compare compare_pdf_activeCompare" : "compare_pdf_compareCheckBoxesSingleUI compare_district-compare"}>
                        {this.props.ST_Compare.checkDistrict?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        {/* <label className={this.props.ST_Compare.checkDistrict ? "compare_pdf_compare-checkbox summary_activeComparePDF" : "compare_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className="compare_pdf_compare_title">District</span>
                    </li>:null
                    }

                </ul>
            </div >
        );
    }
}

export default ST_AnalysisCheckBoxesForPDF;