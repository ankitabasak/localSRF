import React, { Component } from 'react';
import './NewComparisonCheckBoxesForPDF.css'
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
class NewComparisonCheckBoxesForPDF extends Component {

    constructor() {
        super();
        this.state = {
            CompareActiveFor: '',
            updatedCompareActive: false
        }
        this.addClass = this.addClass.bind(this);
    }

    updateCompareActive() {
        this.setState({
            updatedCompareActive: true
        });
    }

    addClass(compareActiveFor) {
        this.setState({ compareActiveFor });
    }

    render() {

        let NavigationSelection = this.props.Navselection;
   
        return (
            
            <div className="compare_pdf_comparison_block text-center">
                <ul className="compare_pdf_comparison_block-ul-list">

                    <li className="compare_pdf_comparison_title">Compare:</li>
                    {
                        NavigationSelection.student || NavigationSelection.class ?<li className={this.props.lastcheckedlabel === "Class" ?  "compare_pdf_compareCheckBoxesSingleUI pdf_class-compare compare_pdf_activeCompare" : "compare_pdf_compareCheckBoxesSingleUI compare_pdf_class-compare"}>
                    {/* <label className={this.props.TS_Overtime.checkClass ? "compare_pdf_compare-checkbox compare_activeComparePDF" : "compare_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        {this.props.TS_Overtime.checkClass?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        <span className="compare_pdf_compare_title">Class</span>
                        </li>
                        :null
                    }

                    {
                        NavigationSelection.student || NavigationSelection.class || NavigationSelection.school ? <li className={this.props.lastcheckedlabel === "School" ? "compare_pdf_compareCheckBoxesSingleUI compare_pdf_school-compare compare_pdf_activeCompare" : "compare_pdf_compareCheckBoxesSingleUI compare_pdf_school-compare"}>
                        {/* <label className={this.props.TS_Overtime.checkSchool ? "compare_pdf_compare-checkbox compare_activeComparePDF" : "compare_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        {this.props.TS_Overtime.checkSchool?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        <span className="compare_pdf_compare_title">School</span>
                    </li>:null
                    }

                    {
                        NavigationSelection.student || NavigationSelection.class || NavigationSelection.school || NavigationSelection.district ?<li className={this.props.lastcheckedlabel === "District" ? "compare_pdf_compareCheckBoxesSingleUI compare_pdf_district-compare compare_pdf_activeCompare" : "compare_pdf_compareCheckBoxesSingleUI compare_district-compare"}>
                        {/* <label className={this.props.TS_Overtime.checkDistrict ? "compare_pdf_compare-checkbox compare_activeComparePDF" : "compare_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        {this.props.TS_Overtime.checkDistrict?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        <span className="compare_pdf_compare_title">District</span>
                    </li>:null
                    }

                </ul>
            </div >
        );
    }
}

export default NewComparisonCheckBoxesForPDF;