import React, { Component } from 'react';
import './Print.css'
import spot_uncheck from '../../../../public/images/spot_uncheck.svg';
import spot_check from '../../../../public/images/spot_check.svg';
class CompareCheckBoxesForPDF extends Component {

    constructor() {
        super();
        this.state = {
            CompareActiveFor: '',
            updatedCompareActive: false
        }
        this.addClass = this.addClass.bind(this);
    }

    updateCompareActive() {
        this.setState({
            updatedCompareActive: true
        });
    }

    addClass(compareActiveFor) {
        this.setState({ compareActiveFor });
    }

    render() {

        let NavigationSelection = this.props.Navselection;
   
        return (
            
            <div className="pdf_comparison_block text-center">
                <ul className="pdf_comparison_block-ul-list">

                    <li className="pdf_comparison_title">Compare:</li>
                    {
                        NavigationSelection.school || NavigationSelection.class ? null: <li className={this.props.lastcheckedlabel === "Class" ?  "pdf_compareCheckBoxesSingleUI pdf_class-compare pdf_activeCompare" : "pdf_compareCheckBoxesSingleUI pdf_class-compare"}>
                    
                    {this.props.TS_Overtime.checkClass?<img src={spot_check} className="compare_img_sizes"/>:<img src={spot_uncheck} className="compare_img_sizes"/>}
                    
                    
                    {/* <label className={this.props.TS_Overtime.checkClass ? "pdf_compare-checkbox activeComparePDF" : "pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className={this.props.lastcheckedlabel === "Class" ? "pdf_class_compare activeCompare" : "pdf_class_compare"}>Class</span>
                        </li>
                    }

                    {
                        NavigationSelection.school == false ? <li className={this.props.lastcheckedlabel === "School" ? "pdf_compareCheckBoxesSingleUI pdf_school-compare pdf_activeCompare" : "pdf_compareCheckBoxesSingleUI pdf_school-compare"}>
                        
                        {this.props.TS_Overtime.checkSchool?<img src={spot_check} className="compare_img_sizes"/>:<img src={spot_uncheck} className="compare_img_sizes"/>}
                        {/* <label className={this.props.TS_Overtime.checkSchool ? "pdf_compare-checkbox activeComparePDF" : "pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className={this.props.lastcheckedlabel === "School" ? "pdf_school_compare activeCompare" : "pdf_school_compare"}>School</span>
                    </li>:null
                    }

                    <li className={this.props.lastcheckedlabel === "District" ? "pdf_compareCheckBoxesSingleUI pdf_district-compare pdf_activeCompare" : "pdf_compareCheckBoxesSingleUI district-compare"}>
                        
                    {this.props.TS_Overtime.checkDistrict?<img src={spot_check} className="compare_img_sizes"/>:<img src={spot_uncheck} className="compare_img_sizes"/>}
                        {/* <label className={this.props.TS_Overtime.checkDistrict ? "pdf_compare-checkbox activeComparePDF" : "pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className={this.props.lastcheckedlabel === "District" ? "pdf_district_compare activeCompare" : "pdf_district_compare" }>District</span>
                    </li>

                </ul>
            </div >
        );
    }
}

export default CompareCheckBoxesForPDF;