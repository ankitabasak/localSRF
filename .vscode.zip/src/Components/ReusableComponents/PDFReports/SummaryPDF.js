import React from 'react';
import ReactToPrint from 'react-to-print';
import './SummaryPDF.css';
import ReactHtmlParser from 'react-html-parser';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import SummaryCheckboxesPDF from './SummaryCheckboxesPDF';
import NewComparisonCheckBoxesForPDF from './NewComparisonCheckBoxesForPDF';
import { resetTriggerPDF } from "../../../Redux_Actions/BatchPrintAction";
import { LandscapeOrientation } from '../LandscapeOrientation';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class ComponentToPrint extends React.Component {
  constructor(props) {
    super(props);
  }
  getCurrentDate(separator = '/') {

    let newDate = new Date()
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();

    return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
  }
  colorCodes(score, AchivementLevels) {
    switch (true) {
      case (score <= AchivementLevels[0]['max']):
        return "bec_Summary_pdf_redBorderColor";
      case (score <= AchivementLevels[1]['max']):
        return "bec_Summary_pdf_orangeBorderColor";
      case (score <= AchivementLevels[2]['max']):
        return "bec_Summary_pdf_yellowBorderColor";
      case (score <= AchivementLevels[3]['max']):
        return "bec_Summary_pdf_greenBorderColor"
      default:
        return "";
    }
  }
  ReturnRowItems(List, CheckBox) {
    return List.map(item =>
      <div className="bec_Summary_pdf_multi_liSummary_Data_row">
        <div className="bec_Summary_pdf_multi_liSummary_row bec_Summary_pdf_multi_liSummary_grid_block" style={{ display: 'flex', alignItems: 'center' }}>
          <div className="bec_Summary_pdf_multi_liSummary_single_label Summary_fontstyle Summary_fontstyleflotleft" style={{ position: "relative", left: "49px" }}>
            {item.ShortValue}
          </div>
          <div className="bec_Summary_pdf_multi_liSummary_single_grid">
            <div className="bec_Summary_pdf_multi_liSummary_single_compareBox">
              <div className="bec_Summary_pdf_multi_liSummary_single_data_score">
                <div className={item.studentAvg != null ? ("bec_Summary_pdf_multi_liSummary_single_data_score_inr " + this.colorCodes(item.studentAvg, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>
                  {(item.studentAvg !== null) ? item.studentAvg : "-"}
                </div>
              </div>
              <div className="bec_Summary_pdf_multi_liSummary_single_data_score_q_count">
                {item.noOfQuestions != null ? "No.QA:" : null} {(item.noOfQuestions != null) ? item.noOfQuestions : "No Data"}
              </div>
            </div>
            {CheckBox.class ? <div className="bec_Summary_pdf_multi_liSummary_single_compareBox" style={{ display: 'flex', alignItems: 'center' }}>
              <div className="bec_Summary_pdf_multi_liSummary_single_data_score">
                <div className="bec_Summary_pdf_multi_liSummary_single_data_score_inr">
                  {item.classAvg != null ? item.classAvg : '-'}
                </div>
              </div>
            </div> : null}
            {CheckBox.school ? <div className="bec_Summary_pdf_multi_liSummary_single_compareBox" style={{ display: 'flex', alignItems: 'center' }}>
              <div className="bec_Summary_pdf_multi_liSummary_single_data_score">
                <div className="bec_Summary_pdf_multi_liSummary_single_data_score_inr">
                  {item.schoolAvg != null ? item.schoolAvg : '-'}
                </div>
              </div>
            </div> : null}
            {CheckBox.district ? <div className="bec_Summary_pdf_multi_liSummary_single_compareBox" style={{ display: 'flex', alignItems: 'center' }}>
              <div className="bec_Summary_pdf_multi_liSummary_single_data_score">
                <div className="bec_Summary_pdf_multi_liSummary_single_data_score_inr">
                  {item.districtAvg != null ? item.districtAvg : '-'}
                </div>
              </div>
            </div> : null}
          </div>
          <div className="bec_Summary_pdf_multi_liSummary_single_description">
            <div className="bec_Summary_pdf_multi_single_standard_desc">
              {item.description != null ? ReactHtmlParser(item.description) : '-'}
            </div>
          </div>
        </div>
      </div>
    )
  }
  render() {
    let pdf_array = [];
    let Nav = this.props.Navigation;
    let Summary_Prop = this.props.SummaryDataProp;
    let Strad = Summary_Prop.List.summaryList;
    let ContextHeader = this.props.ContextHeader
    var ContextHeaderDetails = this.props.ContextHeader.Roster_Tab;
    //  let arr = {class:true,school:true,district:true}
    Strad[0].standardAndStrandVODetails.map((innderdata, index) =>

      pdf_array.push({ ShortValue: innderdata.standardShortValue, studentAvg: Math.round((innderdata.score / innderdata.maxScore) * 100), classAvg: Summary_Prop.List.scoreAndMaxScoreForClass.length > 0 ? Summary_Prop.List.scoreAndMaxScoreForClass[index][2] : null, schoolAvg: Summary_Prop.List.scoreAndMaxScoreForSchool.length > 0 ? Summary_Prop.List.scoreAndMaxScoreForSchool[index][2] : null, districtAvg: Summary_Prop.List.scoreAndMaxScoreForDistrict.length > 0 ? Summary_Prop.List.scoreAndMaxScoreForDistrict[index][2] : null, description: innderdata.standardDescription, noOfQuestions: innderdata.noOfQuestions })
    )
    // Strad.standardAndStrandVODetails.map(innderdata=>
    //     // pdf_array.push({ShortValue: innderdata.standardShortValue, studentAvg: Math.round((innderdata.score/innderdata.maxScore)*100),classAvg:Math.round((Strad.scoreAndMaxScoreForClass[innderdata.standardAndStrandName][0]/Strad.scoreAndMaxScoreForClass[innderdata.standardAndStrandName][1])*100),schoolAvg:Math.round((Strad.scoreAndMaxScoreForSchool[innderdata.standardAndStrandName][0]/Strad.scoreAndMaxScoreForSchool[innderdata.standardAndStrandName][1])*100),districtAvg:Math.round((Strad.scoreAndMaxScoreForDistrict[innderdata.standardAndStrandName][0]/Strad.scoreAndMaxScoreForDistrict[innderdata.standardAndStrandName][1])*100),description:innderdata.standardDescription,noOfQuestions:innderdata.noOfQuestions})


    // )
    return (
      <div className="Summary_print_pdf">
        <div className="Summary_print_pdf_inr">
          <div className="Summary_print_pdf_header">
            <div className="Summary_print_pdf_logo">
              <img src={beclogo} width="105" height="28" />
            </div>
          </div>
          {/* context header */}
          <div className="Summary_print_pdf_context_header">
            <div className="Summary_print_pdf_header_row">
              <ul>
                <li className="pdf_class_name">
                  <span>
                    <b>Student</b> : <span className={Nav.student ? "print_pdf_current_context_color" : ""}>{(ContextHeaderDetails.SelectedStudent.name !== undefined ? ContextHeaderDetails.SelectedStudent.name : null)}</span>
                  </span>
                </li>
                <li className="pdf_class_name">
                  <span>
                    <b>Class</b> : {ContextHeaderDetails.SelectedClass.name}
                  </span>
                </li>
                <li className="pdf_grade">
                  <span>
                    <b>Teacher</b> : {ContextHeaderDetails.SelectedTeacher == "All" ? "All" : ContextHeaderDetails.TeacherIds.length > 1 ? "Custom(" + ContextHeaderDetails.TeacherIds.length + ")" : ContextHeaderDetails.SelectedTeacher.name}
                  </span>
                </li>
                <li className="pdf_class_name">
                  <span>
                    <b>Grade</b> : {convertGrade(ContextHeaderDetails.selectedRosterGrade)}
                  </span>
                </li>
                <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}
                  </span>
                </li>

              </ul>
            </div>
            <div className="Summary_print_pdf_header_row">
              <ul>
                <li className="pdf_district_name">
                  <span>
                    <b>District</b> : {ContextHeaderDetails.SelectedDistrict.name}
                  </span>
                </li>
                <li className="pdf_tests_name">
                  <span>
                    <b>Test</b> : {ContextHeader.tests}
                  </span>
                </li>
                <li className="pdf_dates">
                  <span>
                <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(ContextHeader)}
                  </span>
                </li>

                <li className="pdf_testdata_assessed_for">
                  <span>
                    <b>Test Data Assessed for Grade </b> :  {convertGrade(this.props.TestGrade)}
                  </span>
                </li>

              </ul>
            </div>
            <div className="Summary_print_pdf_header_row">
              <ul>
                <li className="pdf_class_name">
                  <span>
                    <b>View</b> : {this.props.View}
                  </span>
                </li>
              </ul>
            </div>
          </div>
          {/* context header */}
          <div className="Summary_print_pdf_body">
            <div className="Summary_print_pdf_body_middle">
              <div className="Summary_print_pdf_header_title">
                <div className="Summary_print_pdf_header_title_block">
                  <div className="Summary_print_pdf_header_title_block_left">
                    <span className="Summary_print_pdf_dimond_symbol" />
                Average
              </div>
                  <div className="Summary_print_pdf_header_title_block_createdBy createdByCenter">
                    <b>Created by:</b> {ContextHeader.LoggedInUserName}
                  </div>
                  <div className="Summary_print_pdf_header_title_block_right">
                    <b>Date Created:</b> <span className="getDateFont"> {this.getCurrentDate()}</span>
                  </div>
                </div>
              </div>
              {/* <NewComparisonCheckBoxesForPDF TS_Overtime={arr} Navselection={Nav} /> */}
              {/* comparison start */}
              <SummaryCheckboxesPDF SCheckbox={Summary_Prop.CheckBox} Navselection={Nav} />
              {/* comparison end */}
              {/* body Starts from here */}
              <div className="bec_Summary_pdf_multi_list">
                <div className="bec_Summary_pdf_multi_liSummary_inr">
                  <div className="bec_Summary_pdf_multi_liSummary_main">
                    <div className="bec_Summary_pdf_multi_liSummary_header bec_Summary_multi_liSummary_grid_block">
                      <div className="bec_Summary_pdf_multi_liSummary_single_label">
                        Standards ({pdf_array.length > 0 ? pdf_array.length : null})
                  </div>
                      <div className="bec_Summary_pdf_multi_liSummary_single_grid">
                        <div className="bec_Summary_pdf_multi_liSummary_single_taxonomy">
                          Student
                    </div>
                        {Summary_Prop.CheckBox.class ? <div className="bec_Summary_pdf_multi_liSummary_single_taxonomy">
                          Class
                    </div> : null}
                        {Summary_Prop.CheckBox.school ? <div className="bec_Summary_pdf_multi_liSummary_single_taxonomy">
                          School
                    </div> : null}
                        {Summary_Prop.CheckBox.district ? <div className="bec_Summary_pdf_multi_liSummary_single_taxonomy">
                          District
                    </div> : null}
                      </div>
                      <div className="bec_Summary_pdf_multi_liSummary_single_description" style={{ textAlign: "center" }}>
                        <span className="bec_Summary_pdf_multi_liSummary_name">
                          Description
                    </span>
                      </div>
                    </div>
                    {/* sub header */}
                    <div className="bec_Summary_pdf_multi_liSummary_subheader bec_Summary_pdf_multi_liSummary_grid_block">
                      <div
                        className="bec_Summary_pdf_multi_liSummary_single_label" style={{ fontWeight: 700, fontSize: 12 }}
                      >
                        Test Average Score:
                  </div>
                      {/* <div class="bec_Summary_multi_liSummary_single_question">Question</div> */}
                      <div className="bec_Summary_pdf_multi_liSummary_single_grid">
                        <div className="bec_Summary_pdf_multi_liSummary_single_compareBox">
                          <div className="bec_Summary_pdf_multi_liSummary_single_score">
                            <div className={Strad[0].studentPercentage != null ? ("bec_Summary_pdf_multi_liSummary_single_score_inr " + this.colorCodes(Strad[0].studentPercentage, this.props.AchivementLevels)) : "bec_Summary_pdf_multi_liSummary_single_score_inr"}>
                              {Strad[0].studentPercentage ? Strad[0].studentPercentage : null}
                            </div>
                          </div>
                        </div>
                        {Summary_Prop.CheckBox.class ? <div className="bec_Summary_pdf_multi_liSummary_single_compareBox">
                          <div className="bec_Summary_pdf_multi_liSummary_single_score">
                            <div className={this.props.ClassAvg != null ? ("bec_Summary_pdf_multi_liSummary_single_score_inr " + this.colorCodes(this.props.ClassAvg, this.props.AchivementLevels)) : "bec_Summary_pdf_multi_liSummary_single_score_inr"}>
                              {this.props.ClassAvg}
                            </div>
                          </div>
                        </div> : null}
                        {Summary_Prop.CheckBox.school ? <div className="bec_Summary_pdf_multi_liSummary_single_compareBox">
                          <div className="bec_Summary_pdf_multi_liSummary_single_score">
                            <div className={this.props.SchoolAvg != null ? ("bec_Summary_pdf_multi_liSummary_single_score_inr " + this.colorCodes(this.props.SchoolAvg, this.props.AchivementLevels)) : "bec_Summary_pdf_multi_liSummary_single_score_inr"}>
                              {this.props.SchoolAvg}
                            </div>
                          </div>
                        </div> : null}
                        {Summary_Prop.CheckBox.district ? <div className="bec_Summary_pdf_multi_liSummary_single_compareBox">
                          <div className="bec_Summary_pdf_multi_liSummary_single_score">
                            <div className={this.props.DistrictAvg != null ? ("bec_Summary_pdf_multi_liSummary_single_score_inr " + this.colorCodes(this.props.DistrictAvg, this.props.AchivementLevels)) : "bec_Summary_pdf_multi_liSummary_single_score_inr"}>
                              {this.props.DistrictAvg}
                            </div>
                          </div>
                        </div> : null}
                      </div>
                    </div>
                    {/* sub header end */}
                    <div className="bec_Summary_pdf_multi_liSummary_singleData">
                      {/* title header */}
                      {/* Data row */}
                      {this.ReturnRowItems(pdf_array, Summary_Prop.CheckBox)}
                      {/* Data row end */}

                    </div>
                  </div>
                </div>
              </div>
              {/* body ends here */}
            </div>
          </div>
          <div className="Summary_print_footer">
            <div className="Summary_print_footer_inr">
              <div className="Summary_print_footer_left">
                <div className="Summary_print_footer_left_title">
                  Achievement Levels:
            </div>
                <div className="Summary_print_footer_left_color_blocks">
                  <ul>
                    <li>
                      <div className="Summary_print_footer_color_single_block">
                        <div className="Summary_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                        <div className="Summary_print_footer_color_text ">
                          &lt;{this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%
                    </div>
                      </div>
                    </li>
                    <li>
                      <div className="Summary_print_footer_color_single_block">
                        <div className="Summary_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                        <div className="Summary_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                      </div>
                    </li>
                    <li>
                      <div className="Summary_print_footer_color_single_block">
                        <div className="Summary_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                        <div className="Summary_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                      </div>
                    </li>
                    <li>
                      <div className="Summary_print_footer_color_single_block">
                        <div className="Summary_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                        <div className="Summary_print_footer_color_text">&ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="Summary_print_footer_right">
                <div className="Summary_print_footer_na_block">
                  <span style={{ float: "left", padding: "5px 4px", border: "1px solid #ccc", borderRadius: 4 }}>No.QA</span>
                  <span style={{ float: "right", textAlign: "left" }}>
                    Number of <br /> Questions Assessed
              </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    )
  }
}

class SummaryPDF extends React.Component {
  constructor(props) {
    super(props);
    this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
  }

  componentDidMount() {
    this.autoTriggerFunction()
  }
  componentDidUpdate() {
    this.autoTriggerFunction()
  }

  autoTriggerFunction(e) {
    let Nav = this.props.NavigationByHeaderSelection
    let selectedContextData = Nav.class ? this.props.classBatchPrint : Nav.student ? this.props.studentBatchPrint : null
    let selectedData = selectedContextData != null ? Nav.summary ? selectedContextData.summaryData : null : null;
    if ((Nav.student || Nav.class) && (selectedData != null) && (selectedData.triggerPDF === true)) {
      document.getElementById('printIcon').click();
      this.props.resetTriggerPDF()
      let context = Nav.student? "student":"class";
      this.props.trackingUsage(`assessmentreports_standardperformanceaveragepdf:${context}`)    
    }
  }
  render() {

    return (
      <div>
        <ReactToPrint
          trigger={() => <span className="printIcon" id="printIcon"><img src={printIco} width="21" /></span>}
          content={() => this.componentRef}
        />
        <div style={{ display: "none" }}>
          <LandscapeOrientation />
          <ComponentToPrint
            SummaryDataProp={this.props.SummaryDataProp}
            Navigation={this.props.Navigation}
            ContextHeader={this.props.ContextHeader}
            DistrictAvg={this.props.DistrictAvg} SchoolAvg={this.props.SchoolAvg} ClassAvg={this.props.ClassAvg}
            ref={el => (this.componentRef = el)}
            View={this.props.View}
            TestGrade={this.props.TestGrade}
            AchivementLevels={this.props.AchivementLevels}
          />
        </div>
      </div>
    )
  }
}


const mapStateToProps = ({ Universal, Reports, ClassGroupingReducer, BatchPrintReducer }) => {
  const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
  const { StandardPerformance_Overview } = Reports;
  const { classBatchPrint, studentBatchPrint } = BatchPrintReducer
  return {
    AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview, ClassGroupingReducer, classBatchPrint, studentBatchPrint
  };
}

export default connect(mapStateToProps, {
  resetTriggerPDF,trackingUsage
})(SummaryPDF);
function convertGrade(grade) {
  if (grade == "null" || grade == null) {
    return ``
  } else {
    const value = grade.toString()
    const value2 = value.split("_")[1]
    return `${value2}`
  }

}