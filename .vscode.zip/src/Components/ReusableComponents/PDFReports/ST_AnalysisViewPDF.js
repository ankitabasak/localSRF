import React from 'react';
import ReactToPrint from 'react-to-print';
import './singleTestAnalysisViewPDF.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import sta_xmark from '../../../../public/images/sta_xmark.svg';
import sta_tickmark from '../../../../public/images/sta_tickmark.svg';
import sta_partial from '../../../../public/images/sta_partial.svg';
import sta_in_correct from '../../../../public/images/sta_in_correct.svg';
import sta_correct from '../../../../public/images/sta_correct.svg';
import sta_not_ans from '../../../../public/images/sta_not_ans.svg';
import sta_partial_footer from '../../../../public/images/sta_partial_footer.svg';
import { connect } from "react-redux";
import ST_AnalysisCheckBoxesForPDF from './ST_AnalysisCheckBoxesForPDF';
import { resetTriggerPDF } from "../../../Redux_Actions/BatchPrintAction";
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
import { LandscapeOrientation } from '../LandscapeOrientation';
import { toFixedDecimalValue, denaminatorDecimalCheck } from '../../../Utils/st_analysis/st_analysis_reusables';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';
class ComponentToPrint extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      bubbleLeft: 0,
      bubbleRight: 3,
    }
    this.returnDataViewList = this.returnDataViewList.bind(this)
    // this.getStandardsFooterData = this.getStandardsFooterData.bind(this)
    // this.getFooterData = this.getFooterData.bind(this)
  }

  getCurrentDate(separator = '/') {

    let newDate = new Date()
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();

    return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
  }

  getStandardsFooterData(products) {
    let rows = [];
    let row;
    for (let i = 0; i < Math.floor(products.length); i++) {
      row = '';
      row = (

        <ul key={i}>
          <div className="ST_print_strands_standards_list_ul_row">
            <Row products={products.slice(4 * i, 4 * (i + 1))} key={i} />
          </div>
        </ul>


      );
      rows.push(row);

    }
    return rows
  }
  removeDeletedQuestiononCheckbox(contextSelected, question){
   
    let flag1 = false;
    flag1 = ((contextSelected == "student" && question.standardScore == 0 && question.standardMaxScore == 0) || (contextSelected == "class" && question.standardClassScore == 0 && question.standardClassMaxScore == 0) || (contextSelected == "school" && question.standardSchoolScore == 0 && question.standardSchoolMaxScore == 0) || (contextSelected == "district" && question.standardDistrictScore == 0 && question.standardDistrictMaxScore == 0) );
    return flag1

  }
  getFooterData(footerObject, displaySelectedTaxonomyList) {

    return footerObject.map(viewLevel => displaySelectedTaxonomyList.includes(viewLevel.viewName) ? <div className="ST_print_strands_standards_list_main">
      <div className="ST_print_strands_standards_list_title">
        {viewLevel.viewName}
      </div>
      <div className="ST_print_strands_standards_list_inr_block">
        <div className="ST_print_strands_standards_list_ul">


          {this.getStandardsFooterData(viewLevel.standards)}


        </div>
      </div>
    </div> : null)

  }
  colorCodes(score) {
    switch (true) {
      case (score < 40):
        return "color_circle_avaerage_red";
      case (score >= 40 && score <= 59):
        return "color_circle_avaerage_orange";
      case (score >= 60 && score <= 79):
        return "color_circle_avaerage_yellow";
      case (score >= 80):
        return "color_circle_avaerage_green"
      default:
        return "color_circle_avaerage_grey";
    }
  }
  removeDeletedQuestion(contextSelected, question){

    let flag = false;
    flag = ((contextSelected == "student" && question.score == 0 && question.maxScore == 0) || (contextSelected == "class" && question.classScore == 0 && question.classMaxScore == 0) || (contextSelected == "school" && question.schoolScore == 0 && question.schoolMaxScore == 0) || (contextSelected == "district" && question.districtScore == 0 && question.districtMaxScore == 0) );
    return flag

  }
  returnDataViewList(viewDetails, avgType, contextSelected, compareOptions, nodata) {
    return viewDetails.map(SingleStrandStandardData =>
      <div className="bec_singleTest_view_pdf_multi_list_row bec_singleTest_pdf_multi_list_grid_block avoidbreak">
        <div className="bec_singleTest_view_pdf_multi_list_single_label ST_view_pdf_text-left">
          {SingleStrandStandardData.standardShortValue}
        </div>
        <div className="bec_singleTest_view_pdf_multi_list_single_question ST_view_pdf_text-left">
          <div className={contextSelected == 'student' ? "bec_singleTest_questionList bec_singleTest_StudentView" : "bec_singleTest_questionList"}>
            {/* bec_singleTest_StudentView */}
            {SingleStrandStandardData.questions.map((question, index) => <span className={this.removeDeletedQuestion(contextSelected,question)?(contextSelected == "student"?"bec_singleTest_view_student_Deleted":"bec_singleTest_view_Deleted"):(colorBgForQuestion(contextSelected == 'district'? question.districtScore:contextSelected == 'school' ? question.schoolScore:contextSelected == 'class' ? question.classScore:question.score,contextSelected == 'district'? question.districtMaxScore:contextSelected == 'school' ? question.schoolMaxScore:contextSelected == 'class' ? question.classMaxScore:question.maxScore,contextSelected))}>
              {contextSelected == 'student' ?<span className={this.removeDeletedQuestion(contextSelected,question)?"bec_singleTest_singleQuestion_status_view":"bec_singleTest_singleQuestion_status"}>
                {this.removeDeletedQuestion(contextSelected,question) ? <span>&mdash;</span>:question.score == 0 ? <img src={sta_xmark} width="10px" style={{ marginTop: "8px" }} /> : (question.score == question.maxScore) ? <img src={sta_tickmark} width="12px" style={{ marginTop: "8px" }} /> : <img src={sta_partial} width="15px" style={{ marginTop: "15px" }} />}
              </span> : null}
              {<span className="bec_singleTest_singleQuestion_Number">{question.questionNo}</span>}
              {contextSelected != 'student' ? ((index < (SingleStrandStandardData.questions.length - 1)) ?",":null):null}
            </span>)}
          </div>
        </div>
        <div className="bec_singleTest_view_pdf_multi_list_single_grid">
          {compareOptions.checkStudent || contextSelected == 'student' ?
            <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
              <div className="bec_singleTest_view_pdf_multi_list_single_score">
                <div className={returnBgColorOnValue(SingleStrandStandardData.standardAvg, this.props.AchivementLevels)}>
                  {this.removeDeletedQuestiononCheckbox(contextSelected,SingleStrandStandardData)?<ColoredLine />:returnBasedOnAvgType(SingleStrandStandardData.standardScore, SingleStrandStandardData.standardMaxScore, SingleStrandStandardData.standardAvg, nodata, avgType) + (avgType == "percentage" ? "%" : '')}
                </div>
                {/* <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                        {returnWrappedValue(SingleStrandStandardData.standardResultNo)}
                        </div> */}
              </div>
              {/* */}

            </div> : null}
          {compareOptions.checkClass || contextSelected == 'class' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
            <div className="bec_singleTest_view_pdf_multi_list_single_score">
              <div className={returnBgColorOnValue(SingleStrandStandardData.standardClassAvg, this.props.AchivementLevels)}>
                {this.removeDeletedQuestiononCheckbox(contextSelected,SingleStrandStandardData)?<ColoredLine />:returnBasedOnAvgType(SingleStrandStandardData.standardClassScore, SingleStrandStandardData.standardClassMaxScore, SingleStrandStandardData.standardClassAvg, nodata, avgType) + (avgType == "percentage" ? "%" : '')}
              </div>
              <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                {returnWrappedValue(SingleStrandStandardData.standardClassResultNo)}
              </div>
            </div>
          </div> : null}
          {compareOptions.checkSchool || contextSelected == 'school' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
            <div className="bec_singleTest_view_pdf_multi_list_single_score">
              <div className={returnBgColorOnValue(SingleStrandStandardData.standardSchoolAvg, this.props.AchivementLevels)}>
                {this.removeDeletedQuestiononCheckbox(contextSelected,SingleStrandStandardData)?<ColoredLine />:returnBasedOnAvgType(SingleStrandStandardData.standardSchoolScore, SingleStrandStandardData.standardSchoolMaxScore, SingleStrandStandardData.standardSchoolAvg, nodata, avgType) + (avgType == "percentage" ? "%" : '')}
              </div>
              <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                {returnWrappedValue(SingleStrandStandardData.standardSchoolResultNo)}
              </div>
            </div>

          </div> : null}
          {compareOptions.checkDistrict || contextSelected == 'district' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
            <div className="bec_singleTest_view_pdf_multi_list_single_score">
              <div className={returnBgColorOnValue(SingleStrandStandardData.standardDistrictAvg, this.props.AchivementLevels)}>
                {this.removeDeletedQuestiononCheckbox(contextSelected,SingleStrandStandardData)?<ColoredLine />:returnBasedOnAvgType(SingleStrandStandardData.standardDistrictScore, SingleStrandStandardData.standardDistrictMaxScore, SingleStrandStandardData.standardDistrictAvg, nodata, avgType) + (avgType == "percentage" ? "%" : '')}
              </div>
              <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                {returnWrappedValue(SingleStrandStandardData.standardDistrictResultNo)}
              </div>
            </div>
          </div> : null}
        </div>
      </div>

    )

  }
  render() {
    const Nav = this.props.NavigationByHeaderSelection;
    const fromContext = this.props.fromContext;
    let ContextHeader = this.props.ContextHeader.Roster_Tab;
    let HeaderDetails = this.props.ContextHeader;
    //let { class_TestAnalysis, } = this.props.SingleTestAnalysis
    const { AnalysisData, ApiCalls, Filter } = this.props.singleTestData;
    const { OrginalData, Operational_Data, navigation, pagination, compareOptions, sortOptions } = AnalysisData
    const { sortByParams, TaxonomyParams, AverageScoreParams } = Filter;
    let SelectedTaxonomyList = TaxonomyParams.selectedTaxonomyList_temp.filter(item => item.check === true);
    let AverageScoreParam = AverageScoreParams.selectedAverageScore_temp;
    let footerObject = this.props.footerObject
    //footer data

    let displaySelectedTaxonomyList = arrayListOfSelectedTaxonomies(TaxonomyParams.selectedTaxonomyList)
    displaySelectedTaxonomyList.sort()
    let navSelectedTaxonomyList = displaySelectedTaxonomyList.slice(navigation.navigationLeft, navigation.navigationRight)// for display selected taxonomies in nav based view
    const testByViewList = Operational_Data.testByViewList;
    let nodata = null;
    return (
      <table className="STAV_table" style={{ borderSpacing: 0, width: '100%', maxWidth: 1020, margin: '0 auto', minHeight: "823px" }}>
        <thead>
          <tr>
            <td>
              <div className="STAV_print_header-space">&nbsp;</div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <div className="content">
                <div className="ST_view_print_pdf">
                  <div className="ST_view_print_pdf_inr">
                    <div className="ST_view_print_pdf_header">
                      <div className="ST_view_print_pdf_logo">
                        <img src={beclogo} width={105} height={28} />
                      </div>
                    </div>
                    {/* context header */}
                    <div className="ST_view_print_pdf_context_header">
                      <div className="ST_view_print_pdf_header_row">
                        <ul>
                          {Nav.student ? <li className="pdf_class_name">
                            <span>
                              <b>Student</b> : <span className={Nav.student ? "print_pdf_current_context_color" : ""}>{(ContextHeader.SelectedStudent.name !== undefined) ? ContextHeader.SelectedStudent.name : ""}</span>
                            </span>
                          </li> : ""}
                          {Nav.class && (ContextHeader.StudentsList.length != ContextHeader.StudentIds.length) && ContextHeader.StudentsList.length > 1 ? <li className="pdf_class_name">
                            <span>
                              <b>Students</b> : Custom({(ContextHeader.StudentIds.length !== undefined) ? ContextHeader.StudentIds.length : ""})
                        </span>
                          </li> : ""}
                          {(Nav.student || Nav.class) ? <li className="pdf_class_name">
                            <span>
                              <b>Class</b> : <span className={Nav.class ? "print_pdf_current_context_color" : ""}>{ContextHeader.SelectedClass.name}</span>
                            </span>
                          </li> : null}
                          {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_grade">
                            <span>
                              <b>Teacher</b> : {ContextHeader.SelectedTeacher == "All" ? "All" : ContextHeader.TeacherIds.length > 1 ? "Custom(" + ContextHeader.TeacherIds.length + ")" : ContextHeader.SelectedTeacher.name}
                            </span>
                          </li> : null}
                          {Nav.district && (ContextHeader.SchoolIds.length !== ContextHeader.schoolsList.length) ? <li className="pdf_teacher_name">
                            <span>
                              <b>School</b> : <span>Custom ({ContextHeader.SchoolIds.length})</span>
                            </span>
                          </li> : null}
                          <li className="pdf_class_name">
                            <span>
                              <b>Grade</b> : {convertGrade(ContextHeader.selectedRosterGrade)}
                            </span>
                          </li>
                          {(Nav.district === false) ? <li className="pdf_teacher_name">
                            <span>
                              <b>School</b> : <span className={Nav.school ? "print_pdf_current_context_color" : ""}>{ContextHeader.SelectedSchool.name}</span>
                            </span>
                          </li> : null}
                          {(Nav.school || Nav.district) ? <li className="pdf_district_name">
                            <span>
                              <b>District</b> : <span className={Nav.district ? "print_pdf_current_context_color" : ""}>{ContextHeader.SelectedDistrict.name}</span>
                            </span>
                          </li> : null}
                          {(Nav.district) ? <li className="pdf_tests_name">
                            <span>
                              <b>Tests</b> : {HeaderDetails.tests}
                            </span>
                          </li> : null}
                          {Nav.district && (ContextHeader.SchoolIds.length === ContextHeader.schoolsList.length) ? <li className="pdf_dates">
                            <span>
                              <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                            </span>
                          </li> : null}


                        </ul>
                      </div>
                      {(!Nav.district) ? <div className="ST_view_print_pdf_header_row">
                        <ul>
                          {(Nav.student || Nav.class) ? <li className="pdf_district_name">
                            <span>
                              <b>District</b> : {ContextHeader.SelectedDistrict.name}
                            </span>
                          </li> : null}
                          {(Nav.class || Nav.school) ? <li className="pdf_tests_name">
                            <span>
                              <b>Tests</b> : {HeaderDetails.tests}
                            </span>
                          </li> : null}
                          {(Nav.student) ? <li className="pdf_tests_name">
                            <span>
                              <b>Test</b> : {HeaderDetails.tests}
                            </span>
                          </li> : null}
                          {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_dates">
                            <span>
                         <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                            </span>
                          </li> : null}
                        </ul>
                      </div> : null}
                      {Nav.district && (ContextHeader.SchoolIds.length != ContextHeader.schoolsList.length) ? <div className="ST_view_print_pdf_header_row">
                        <ul>
                          <li className="pdf_dates">
                            <span>
                              <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                            </span>
                          </li>
                        </ul>
                      </div> : null}
                      <div className="ST_view_print_pdf_header_row_filter">
                        <ul>
                          <li style={{ marginBottom: "20px" }}>
                            <b>Filters:</b>
                          </li>
                          <li>
                            <span className="bec_singleTest_view_pdf_filter_Selected_radio">
                              <div className="bec_singleTest_view_pdf_filter_Selected_radio_inr" />
                            </span>
                            Standards
            </li>
                          {SelectedTaxonomyList.map((taxonomy, key) =>
                            <li key={key} style={{ display: "flex" }}>
                              <span>
                                <div>
                                  <img src={print_checkbox_selected} className="compare_img_sizes" />
                                </div>
                              </span>
                              {taxonomy.taxonomy_Name}
                            </li>
                          )}


                          <li>
                            <span className="bec_singleTest_view_pdf_filter_Selected_radio">
                              <div className="bec_singleTest_view_pdf_filter_Selected_radio_inr" />
                            </span>
                            {jsUcfirst(AverageScoreParam)}
                          </li>
                        </ul>
                      </div>
                    </div>
                    {/* context header */}
                    <div className="ST_view_print_pdf_body">
                      <div className="ST_view_print_pdf_body_middle">
                        <div className="ST_view_print_pdf_header_title">
                          <div className="ST_view_print_pdf_header_title_block">
                            <div className="ST_view_print_pdf_header_title_block_left">
                              <span className="ST_view_print_pdf_dimond_symbol" />
                              <span style={{ fontWeight: "500" }}>Single Test Analysis</span>
                            </div>
                            <div className="ST_view_print_pdf_header_title_block_createdBy STV_createdByCenter">
                              <b>Created by:</b> {HeaderDetails.LoggedInUserName}
                            </div>
                            <div className="ST_view_print_pdf_header_title_block_right">

                              <b>Date Created:</b> {this.getCurrentDate()}
                            </div>
                          </div>
                        </div>
                        {/* comparison start */}
                        <div className="singleTest_pdf_Comparison_print_main">
                          <div className="singleTest_pdf_comparison_main_Center">
                            <div className="singleTest_pdf_Select_levels">
                              <div className="singleTest_pdf_compare_tab_compare_label">
                                {!Nav.district ? <ST_AnalysisCheckBoxesForPDF ST_Compare={compareOptions} Navselection={Nav} /> : null}
                              </div>
                            </div>
                          </div>
                        </div>
                        {/* comparison end */}
                        {/* body Starts from here */}
                        <div className="bec_singleTest_view_pdf_multi_list">
                          <div className="bec_singleTest_view_pdf_multi_list_inr">
                            <div className="bec_singleTest_view_pdf_multi_list_main">
                              <div className="bec_singleTest_view_pdf_multi_list_header bec_singleTest_multi_list_grid_block">
                                <div className="bec_singleTest_view_pdf_multi_list_single_label stav_title_font_weight">
                                  <span><b>Standards</b></span>
                                </div>
                                <div className="bec_singleTest_view_pdf_multi_list_single_question stav_title_font_weight" style={{ textAlign: "center" }}>
                                  <span><b>Question</b></span>
                                </div>
                                <div className="bec_singleTest_view_pdf_multi_list_single_grid">
                                  {compareOptions.checkStudent || fromContext == 'student' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <span className="bec_singleTest_view_pdf_multi_list_name">
                                      <b>Student</b>
                                    </span>
                                    <span className="bec_singleTest_view_pdf_multi_list_togglers">
                                      {sortOptions.fromSortOn == 'student' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                                      {sortOptions.fromSortOn == 'student' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                                    </span>
                                  </div> : null}
                                  {compareOptions.checkClass || fromContext == 'class' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <span className="bec_singleTest_multi_list_name"><b>Class</b></span>
                                    <span className="bec_singleTest_view_pdf_multi_list_togglers">
                                      {sortOptions.fromSortOn == 'class' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                                      {sortOptions.fromSortOn == 'class' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                                    </span>
                                  </div> : null}
                                  {compareOptions.checkSchool || fromContext == 'school' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <span className="bec_singleTest_multi_list_name"><b>School</b></span>
                                    <span className="bec_singleTest_view_pdf_multi_list_togglers">
                                      {sortOptions.fromSortOn == 'school' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                                      {sortOptions.fromSortOn == 'school' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                                    </span>
                                  </div> : null}
                                  {compareOptions.checkDistrict || fromContext == 'district' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <span className="bec_singleTest_multi_list_name"><b>District</b></span>
                                    <span className="bec_singleTest_view_pdf_multi_list_togglers">
                                      {sortOptions.fromSortOn == 'district' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                                      {sortOptions.fromSortOn == 'district' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                                    </span>
                                  </div> : null}
                                </div>
                              </div>
                              {/* sub header */}
                              <div className="bec_singleTest_view_pdf_multi_list_subheader bec_singleTest_pdf_multi_list_grid_block">
                                <div
                                  className="bec_singleTest_view_pdf_multi_list_single_label text-left"
                                  style={{ fontWeight: 700, padding: "5px 0" }}
                                >
                                  Test Average Score:
              </div>
                                {/* <div class="bec_singleTest_multi_list_single_question">Question</div> */}
                                <div className="bec_singleTest_view_pdf_multi_list_single_grid">

                                  {compareOptions.checkStudent || fromContext == 'student' ?
                                    <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                      <div className="bec_singleTest_view_pdf_multi_list_single_score">
                                        <div className={returnBgColorOnValue(Operational_Data.testAvg, this.props.AchivementLevels)}>
                                          {returnBasedOnAvgType(Operational_Data.testScore, Operational_Data.testMaxScore, Operational_Data.testAvg, nodata, AverageScoreParams.selectedAverageScore) + (AverageScoreParams.selectedAverageScore == "percentage" ? "%" : '')}
                                        </div>
                                        {/* <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                        {returnWrappedValue(Operational_Data.testResultNo)}
                        </div> */}
                                      </div>
                                      {/* */}

                                    </div> : null}
                                  {compareOptions.checkClass || fromContext == 'class' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <div className="bec_singleTest_view_pdf_multi_list_single_score">
                                      <div className={returnBgColorOnValue(Operational_Data.testClassAvg, this.props.AchivementLevels)}>
                                        {returnBasedOnAvgType(Operational_Data.testClassScore, Operational_Data.testClassMaxScore, Operational_Data.testClassAvg, nodata, AverageScoreParams.selectedAverageScore) + (AverageScoreParams.selectedAverageScore == "percentage" ? "%" : '')}
                                      </div>
                                      <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                                        {returnWrappedValue(Operational_Data.testClassResultNo)}
                                      </div>
                                    </div>
                                  </div> : null}
                                  {compareOptions.checkSchool || fromContext == 'school' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <div className="bec_singleTest_view_pdf_multi_list_single_score">
                                      <div className={returnBgColorOnValue(Operational_Data.testSchoolAvg, this.props.AchivementLevels)}>
                                        {returnBasedOnAvgType(Operational_Data.testSchoolScore, Operational_Data.testSchoolMaxScore, Operational_Data.testSchoolAvg, nodata, AverageScoreParams.selectedAverageScore) + (AverageScoreParams.selectedAverageScore == "percentage" ? "%" : '')}
                                      </div>
                                      <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                                        {returnWrappedValue(Operational_Data.testSchoolResultNo)}
                                      </div>
                                    </div>

                                  </div> : null}
                                  {compareOptions.checkDistrict || fromContext == 'district' ? <div className="bec_singleTest_view_pdf_multi_list_single_compareBox">
                                    <div className="bec_singleTest_view_pdf_multi_list_single_score">
                                      <div className={returnBgColorOnValue(Operational_Data.testDistrictAvg, this.props.AchivementLevels)}>
                                        {returnBasedOnAvgType(Operational_Data.testDistrictScore, Operational_Data.testDistrictMaxScore, Operational_Data.testDistrictAvg, nodata, AverageScoreParams.selectedAverageScore) + (AverageScoreParams.selectedAverageScore == "percentage" ? "%" : '')}
                                      </div>
                                      <div className="bec_singleTest_view_pdf_multi_list_single_score_q_count">
                                        {returnWrappedValue(Operational_Data.testDistrictResultNo)}
                                      </div>
                                    </div>
                                  </div> : null}
                                </div>
                              </div>
                              {/* sub header end */}
                              <div className="bec_singleTest_view_pdf_multi_list_singleData">
                                {/* title header */}
                                {/* <div class="bec_singleTest_multi_list_sub_block_title">
                            <div class="bec_singleTest_multi_list_sub_block_title_label">CaCCSS English Language Arts</div>
                    </div> */}
                                {/* title header end */}
                                {/* Data row */}



                                {testByViewList.map(views => <div className="bec_singleTest_view_pdf_multi_list_Data_row">
                                  <div className="bec_singleTest_view_pdf_multi_list_sub_block_title">
                                    <div className="bec_singleTest_view_pdfmulti_list_sub_block_title_label">
                                      {views.view}
                                    </div>
                                  </div>
                                  {this.returnDataViewList(views.viewDetailsList, AverageScoreParams.selectedAverageScore, fromContext, compareOptions, nodata)}
                                </div>
                                )}{/* Data row end */}

                              </div>
                            </div>
                          </div>
                        </div>
                        {/* body ends here */}
                      </div>
                    </div>

                    {(footerObject.length > 0 && displaySelectedTaxonomyList.length > 0 && this.props.StandardsDefinition) ? <div className="ST_print_strands_standards_list" style={{ marginBottom: "3px" }}>
                      <div className="ST_print_strands_standards_list_inr">
                        {this.getFooterData(footerObject, displaySelectedTaxonomyList)}
                      </div>
                    </div> : null}
                    <div className="ST_view_print_footer">
                      <div className="ST_view_print_footer_inr">
                        <div className="ST_view_print_footer_left" style={{ width: "36%" }}>
                          <div className="ST_view_print_footer_left_title" style={{ width: "75%", borderBottom: "2px solid #F3F5FA", paddingBottom: "3px" }}>
                            Achievement Levels:
            </div>
                          <div className="ST_view_print_footer_left_color_blocks" style={{ marginTop: "9px", float: "left" }}>
                            <ul>
                              <li>
                                <div className="ST_view_print_footer_color_single_block">
                                  <div className="ST_view_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                                  <div className="ST_view_print_footer_color_text ">
                                    &lt;{this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%
                    </div>
                                </div>
                              </li>
                              <li>
                                <div className="ST_view_print_footer_color_single_block">
                                  <div className="ST_view_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                                  <div className="ST_view_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                                </div>
                              </li>
                              <li>
                                <div className="ST_view_print_footer_color_single_block">
                                  <div className="ST_view_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                                  <div className="ST_view_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                                </div>
                              </li>
                              <li>
                                <div className="ST_view_print_footer_color_single_block">
                                  <div className="ST_view_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                                  <div className="ST_view_print_footer_color_text">&ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                        <div className="ST_view_print_footer_right" style={{ width: "64%" }}>
                          <div className="ST_view_print_footer_left_title" style={{ float: "right" }}>
                            Based on No. of results: (##)
            </div>
                          {(fromContext == 'student') ? <div className="footer-indicators-singletest-analysis" style={{ float: "left", width: "68%" }}>
                            <span className="ST_view_print_footer_left_title" style={{ float: "left", textAlign: "left", fontWeight: "600", width: "96%", borderBottom: "2px solid #F3F5FA", paddingBottom: "3px" }}>Question Status</span>
                            <br />
                            <div className="footer-indicators-singletest-analysis-inr">
                              {/* <div className="footer-indicate-title">Questions Status </div> */}
                              <div className="footer-st_analysis-indicators-list stv_footer_margin">
                                <ul style={{ marginBottom: "0px" }}>

                                  <li style={{ width: "23%" }}>
                                    <div className="footer-st_analysis-single-indicator" style={{ width: "72%" }}>

                                      <img src={sta_correct} width="18" />

                                      <span className="footer-st_analysis-single-indicator-title">Correct</span>
                                    </div>
                                  </li>
                                  <li style={{ width: "23%" }}>
                                    <div className="footer-st_analysis-single-indicator" style={{ width: "90%" }}>

                                      <img src={sta_in_correct} width="18" />

                                      <span className="footer-st_analysis-single-indicator-title">Incorrect</span>
                                    </div>
                                  </li>
                                  <li style={{ width: "23%" }}>
                                    <div className="footer-st_analysis-single-indicator" style={{ width: "80%" }}>

                                      <img src={sta_partial_footer} width="18" />


                                      <span className="footer-st_analysis-single-indicator-title">Partial</span>
                                    </div>
                                  </li>
                                  <li style={{ width: "27%" }}>
                                    <div className="footer-st_analysis-single-indicator" style={{ width: "100%" }}>

                                      <img src={sta_not_ans} width="18" />

                                      <span className="footer-st_analysis-single-indicator-title">Not Answered</span>
                                    </div>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </div> : null}

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <div className="STAV_print_footer-space">&nbsp;</div>
            </td>
          </tr>
        </tfoot>
      </table>)
  }
}

class ST_AnalysisViewPDF extends React.Component {
  constructor(props) {
    super(props);
    this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
  }
  componentDidMount(){
    this.autoTriggerFunction()
  }
  componentDidUpdate() {
    this.autoTriggerFunction()
  }

  autoTriggerFunction(e) {
    let Nav = this.props.NavigationByHeaderSelection
    let selectedContextData = Nav.class ? this.props.classBatchPrint : Nav.student ? this.props.studentBatchPrint : null
    let selectedData = selectedContextData != null ? Nav.st_analysis ? selectedContextData.singleTestData : null : null;
    if ((Nav.student || Nav.class) && (selectedData != null) && (selectedData.triggerPDF === true)) {
      let context = Nav.student? "student":"class";
      document.getElementById('printIcon').click();
      this.props.resetTriggerPDF()
      this.props.trackingUsage(`assessmentreports_singletestanalysisstandardpdf:${context}`)
    }
  }

  render() {
    let {NavigationByHeaderSelection}= this.props;
    let context= "district";
    if(NavigationByHeaderSelection.school)
    {
    context = "school";
    } 

    let footer_objectList = structured_pdf_footer(this.props.singleTestData.AnalysisData.Operational_Data.testByViewList)

    return (
      <div>
        <ReactToPrint
          trigger={() => <span className="printIcon" id="printIcon"><img src={printIco} onClick={()=>this.props.trackingUsage(`assessmentreports_singletestanalysisstandardpdf:${context}`)} width="21" /></span>}
          content={() => this.componentRef}
        />
        <div style={{ display: "none" }}>
          <LandscapeOrientation />
          <ComponentToPrint
            ContextHeader={this.props.ContextHeader}
            singleTestData={this.props.singleTestData}
            NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
            fromContext={this.props.fromContext}
            footerObject={footer_objectList}
            StandardsDefinition={this.props.StandardsDefinition}
            AchivementLevels={this.props.AchivementLevels}
            ref={el => (this.componentRef = el)} />
        </div>
      </div>
    )
  }
}


const mapStateToProps = ({ Universal, Reports, SingleTestAnalysis, BatchPrintReducer }) => {
  const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
  const { StandardPerformance_Overview } = Reports;
  const { classBatchPrint, studentBatchPrint } = BatchPrintReducer
  return {
    AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview, SingleTestAnalysis,
    classBatchPrint, studentBatchPrint
  };
}

export default connect(mapStateToProps, {
  resetTriggerPDF,trackingUsage
})(ST_AnalysisViewPDF);

function convertGrade(grade) {

  if (grade == "null" || grade == null) {
    return ``
  } else {
    const value = grade.toString()
    const value2 = value.split("_")[1]
    return `${value2}`
  }

}
export function arrayListOfSelectedTaxonomies(selectedTaxonomyList) {

  let selectedTaxArray = []

  let selectedTaxonomyList_test = selectedTaxonomyList.filter(taxonomy => taxonomy.check == true)

  selectedTaxonomyList_test.map(item => selectedTaxArray.push(item.taxonomy_Name))

  return selectedTaxArray

}
// export function returnBasedOnAvgType(startData,endData,avgScore,avgType){
//   if(avgType == "percentage"){
//     return avgScore
//   }else{
//     return startData+"/"+endData
//   }
// }
export function returnBgColorOnValue(value, AchivementLevels) {

  let returnedResult = ''

  if (value <= AchivementLevels[0]['max']) {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_redBgColor"
  } else if (value <= AchivementLevels[1]['max']) {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_orangeBgColor"
  } else if (value <= AchivementLevels[2]['max']) {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_yellowBgColor"
  } else {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_greenBgColor"
  }

  return returnedResult

}
export function colorBgForQuestion(score, MaxScore, contextSelected) {

  if (contextSelected == 'student') {

    if (score == 0) {
      return "bec_singleTest_singleQuestion STV_bec_singleTest_redBgColor"
    } else if (score == MaxScore) {
      return "bec_singleTest_singleQuestion STV_bec_singleTest_greenBgColor"
    } else { // if((score > 0) && (score < MaxScore))
      return "bec_singleTest_singleQuestion STV_bec_singleTest_yellowBgColor"
    }

  } else {

    return "bec_singleTest_singleQuestion bec_singleTest_noBorderColor"

  }

}
export function returnWrappedValue(value) {
  let returnedResult = ''
  if (value === null) {
    returnedResult = ""
  }
  else {
    returnedResult = "(" + value + ")"
  }
  return returnedResult

}
export function returnBasedOnAvgType(startData, endData, avgScore, testResultNo, avgType) {
  if (avgType == "percentage") {
    return avgScore
  } else {
    return toFixedDecimalValue(startData)+"/"+denaminatorDecimalCheck(endData)
    //return (Math.round((startData) * 10) / 10) + "/" + (Math.round((endData) * 10) / 10)
  }
}
//To Group all the footer elements as group to display in pdf footer

export function structured_pdf_footer(testByQuestionList) {

  let tempArrayForList = []
  let finalArrayForList = []
  let singleRow = {}

  testByQuestionList.map(viewDetail => {
    viewDetail.viewDetailsList.map(singleview => {
      singleRow = {}
      singleRow.view = viewDetail.view
      //singleview.viewDetails.map(singleStandard => {
      singleRow.standardShortValue = singleview.standardShortValue
      singleRow.standardDesc = singleview.standardDesc
      singleRow.standardName = singleview.standardName
      tempArrayForList.push(singleRow)
      //})

    })

  })

  const groupBy = (array, key) => {
    return array.reduce((result, currentValue) => {
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      );
      return result;
    }, {});
  };

  let UniqueArrayList = tempArrayForList
    .map(e => e['standardShortValue'])
    .map((e, i, final) => final.indexOf(e) === i && i)
    .filter(e => tempArrayForList[e]).map(e => tempArrayForList[e]);

  let viewGroup = groupBy(UniqueArrayList, 'view');
  let objectKeys = Object.keys(viewGroup)
  for (let i = 0; i < objectKeys.length; i++) {
    singleRow = {}
    singleRow.viewName = objectKeys[i]
    singleRow.standards = viewGroup[objectKeys[i]];
    finalArrayForList.push(singleRow)
  }
  return finalArrayForList
}
export function jsUcfirst(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}
export function Row({ products }) {

  const renderedProducts = products.map((p, index) => (

    <Product
      standard={p}
      index={index}
    />


  ));


  return (renderedProducts);
}
export function Product({ standard, index }) {
  return (
    <li key={index}>
      <span className="ST_print_strands_standards_list_ul_strandard">
        {standard.standardShortValue}
      </span>
      <span className="ST_print_strands_standards_list_ul_strandard_desc">
        {standard.standardDesc}
      </span>
    </li>

  );
}
const ColoredLine = () => (
  <hr
      style={{
          backgroundColor: "#000000",
          height: 2,
          margin:"7px auto",
          width:"15px",
          border:0
      }}
  />
); 