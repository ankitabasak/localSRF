import React from 'react';
import ReactToPrint from 'react-to-print';
import './TestScoresComparisonPDF.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import {
    Comparison_Popup,
    EditComparison_Popup,
    SortComparisonBasedOnParam,
    navigationArrowsStandardComparison,
    comparisonCurrentPageClick
} from '../../../Redux_Actions/ComparisonActions';
import NewComparisonCheckBoxesForPDF from './NewComparisonCheckBoxesForPDF';
import { LandscapeOrientation } from '../LandscapeOrientation';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
    }
    getCurrentDate(separator = '/') {

        let newDate = new Date()
        let date = newDate.getDate();
        let month = newDate.getMonth() + 1;
        let year = newDate.getFullYear();

        return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
    }
    colorCodes(score, AchivementLevels) {
        switch (true) {
            case (score <= AchivementLevels[0]['max']):
                return "color_circle_avaerage_red";
            case (score <= AchivementLevels[1]['max']):
                return "color_circle_avaerage_orange";
            case (score <= AchivementLevels[2]['max']):
                return "color_circle_avaerage_yellow";
            case (score <= AchivementLevels[3]['max']):
                return "color_circle_avaerage_green"
            default:
                return "color_circle_avaerage_grey";
        }
    }
    /**
     * 
     * @param {* String} ParamOnwhichScore 
     * @param {* String with 'ASC OR DSC'} orderOfSort 
     */
    handleSortingGroups(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
        this.props.SortGroupsBasedOnParam(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
    }
    handleSortingComparison(fromContext, fromtab, ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
        this.props.SortComparisonBasedOnParam(fromContext, fromtab, ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
    }
    checkTestData(singleTest, studentTests) {

        let checkedData = studentTests.filter(test => test.componentCode == singleTest.componentCode)
        let returnedData = ''
        if (checkedData.length > 0) {

            returnedData = <div className="student_standard_strand">
                <div class={`standard_strand_score ${checkedData[0].componentAvg != null ? this.colorCodes(checkedData[0].componentAvg, this.props.AchivementLevels) : "color_circle_avaerage_grey"}`}>{checkedData[0].componentAvg}</div>
                <div className="Question_number">No.QA: {checkedData[0].questionCount}</div>


            </div>
        } else {

            returnedData = <div className="student_standard_strand">
                <div class="standard_strand_score color_circle_avaerage_grey">-</div>
                <div className="Question_number">No Data</div>
            </div>
        }

        return returnedData;
    }

    render() {
        var StrandsorStrandardsList = this.props.StrandsorStrandardsList;
        var standardsList = this.props.standardsList;
        var ShowStrandsorStandards = this.props.StrandsorStrandardsList;
        var TotalGroupingList = this.props.TotalGroupingList;
        var HeaderDetails = this.props.HeaderDetails;
        var ContextHeaderDetails = this.props.HeaderDetails.Roster_Tab;
        // var GroupBy = this.props.AppliedChanges;
        // let products= this.props.ShowStrandsorStandards;
        let HeaderNamesList = this.props.HeaderNamesList;
        // let rows = [];
        let sortingOptions = this.props.sortingOptions;
        let compareOptions = this.props.compareOptions;
        const Nav = this.props.NavigationByHeaderSelection;
        let fromContext = this.props.fromContext
        let fromtab = this.props.fromtab
        let ShowTests = this.props.ShowTests;
        let Selected_Tests = (HeaderDetails !== undefined) ? HeaderDetails.TestTab.TestList.filter(item => item.check) : [];
        let totalClassScore = (this.props.totalClassScore > 0) ? this.props.totalClassScore : 0;
        let totalSchoolScore = (this.props.totalSchoolScore > 0) ? this.props.totalSchoolScore : 0;
        let totalDistrictScore = (this.props.totalDistrictScore > 0) ? this.props.totalDistrictScore : 0;

        //var result = TotalGroupingList.filter(function(e) {return ()    });
        // let filtered = TotalGroupingList.map((student1,index) => {

        // });
        // let filtered = TotalGroupingList['standardAndStrandVODetails'].filter(function (el) {
        //   return el.standardAndStrandAvg != null;
        // });
        //for filter no data and with data starts
        // let filtered = TotalGroupingList.standardAndStrandVODetails.filter(function (el) {
        //   return el.standardAndStrandAvg != null;
        // });
        // let filteredNA = TotalGroupingList.standardAndStrandVODetails.filter(function (el) {
        //   return el.standardAndStrandAvg === null;
        // });
        //start dates
        let startDateString = HeaderDetails.Date_Tab.Report_termStartDate.substring(0, 11);
        let startDateStringArray = startDateString.split(" ");
        let startDateStringArray2 = startDateStringArray[0].split("-");

        //end dates
        let endDateString = HeaderDetails.Date_Tab.Report_termEndDate.substring(0, 11);
        let endDateStringArray = endDateString.split(" ");
        let endDateStringArray2 = endDateStringArray[0].split("-");

        let classComparison = TotalGroupingList.classAvg != undefined ? TotalGroupingList.classAvg : null
        let schoolComparison = TotalGroupingList.schoolAvg != undefined ? TotalGroupingList.schoolAvg : null
        let districtComparison = TotalGroupingList.districtAvg != undefined ? TotalGroupingList.districtAvg : null
        let currentPageData = this.props.currentPageData;

        return (
            <div className="Testscore_GP_print_pdf">
                <div className="Testscore_GP_print_pdf_inr">
                    <div className="studentts_contex_comparison_print_header1" style={{ width: "100%" }}>
                        <div className="Testscore_GP_print_pdf_header">
                            <div className="Testscore_GP_print_pdf_logo">
                                <img src={beclogo} width="105" height="28" />
                            </div>
                            <div className="Testscore_GP_print_pdf_head_text">

                            </div>
                        </div>
                        <div className="Testscore_GP_print_pdf_context_header">
                            <div className={Nav.district ? "Testscore_GP_print_pdf_header_row border_bottom_none_for_dist" : "Testscore_GP_print_pdf_header_row"}>
                                <ul>
                                    {Nav.student ? <li className="pdf_class_name">
                                        <span>
                                            <b>Student</b> : {(ContextHeaderDetails.SelectedStudent.name !== undefined) ? ContextHeaderDetails.SelectedStudent.name : ""}
                                        </span>
                                    </li> : null}
                                    {/* {Nav.class &&ContextHeaderDetails.SelectedStudent !== "All"?<li className="pdf_class_name">
                        <span>
                            <b>Students</b> : {(ContextHeaderDetails.SelectedStudent !== undefined)?ContextHeaderDetails.SelectedStudent:null}
                        </span>
                    </li>:null} */}
                                    {(Nav.student || Nav.class) ? <li className="pdf_class_name">
                                        <span>
                                            <b>Class</b> : {ContextHeaderDetails.SelectedClass.name}
                                        </span>
                                    </li>
                                        : null}
                                    {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_grade">
                                        <span>
                                            <b>Teacher</b> : {ContextHeaderDetails.SelectedTeacher == "All" ? "All" : ContextHeaderDetails.TeacherIds.length > 1 ? "Custom(" + ContextHeaderDetails.TeacherIds.length + ")" : ContextHeaderDetails.SelectedTeacher.name}
                                        </span>
                                    </li> : null}
                                    {Nav.district && (ContextHeaderDetails.SchoolIds.length !== ContextHeaderDetails.schoolsList.length) ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : Custom ({ContextHeaderDetails.SchoolIds.length})

                        </span>
                                    </li> : null}
                                    <li className="pdf_class_name">
                                        <span>
                                            <b>Grade</b> :{convertGrade(ContextHeaderDetails.selectedRosterGrade)}
                                        </span>
                                    </li>
                                    {(Nav.school) ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                                        </span>
                                    </li> : null}
                                    {Nav.class && ContextHeaderDetails.SelectedStudent === "All" ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}
                                        </span>
                                    </li> : null}

                                    {(Nav.school || Nav.district) ? <li className="pdf_district_name">
                                        <span>
                                            <b>District</b> : {Nav.district ? (ContextHeaderDetails.SelectedDistrict.name) : ContextHeaderDetails.SelectedDistrict.name}
                                        </span>
                                    </li> : null}
                                    {Nav.district ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Tests</b> : {HeaderDetails.tests}
                                        </span>
                                    </li> : null}
                                    {Nav.district && (ContextHeaderDetails.SchoolIds.length === ContextHeaderDetails.schoolsList.length) ? <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                                        </span>
                                    </li> : null}
                                </ul>
                            </div>
                            {(Nav.district === false) ? <div className="Testscore_GP_print_pdf_header_row">
                                <ul>

                                    {(Nav.student) ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                                        </span>
                                    </li> : null}
                                    {Nav.class && ContextHeaderDetails.SelectedStudent !== "All" ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}
                                        </span>
                                    </li> : null}
                                    {(Nav.student || Nav.class) ? <li className="pdf_district_name">
                                        <span>
                                            <b>District</b> : {ContextHeaderDetails.SelectedDistrict.name}
                                        </span>
                                    </li> : null}
                                    {(Nav.school || Nav.class) ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Tests</b> : {HeaderDetails.tests}
                                        </span>
                                    </li> : null}
                                    {Nav.student ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Test</b> : {HeaderDetails.tests}
                                        </span>
                                    </li> : null}

                                    {(Nav.class || Nav.school) ? <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                                            {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                                        </span>
                                    </li> : null}

                                </ul>
                            </div> : null}
                            {(Nav.student) ? <div className="Testscore_GP_print_pdf_header_row">
                                <ul><li className="pdf_dates">
                                    <span>
                                        <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                                        {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                                    </span>
                                </li></ul>
                            </div> : null}
                            {Nav.district && (ContextHeaderDetails.SchoolIds.length !== ContextHeaderDetails.schoolsList.length) ? <div className="Testscore_GP_print_pdf_header_row print_pdf_district_add_border_top">
                                <ul><li className="pdf_dates">
                                    <span>
                                <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                                        {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                                    </span>
                                </li></ul>
                            </div> : null}
                        </div>
                    </div>

                    <div className="Testscore_GP_print_pdf_body">
                        <div className="Testscore_GP_print_pdf_body_middle">
                            <div className="Testscore_GP_print_pdf_header_title">
                                <div className="Testscore_GP_print_pdf_header_title_block">
                                    <div className="Testscore_GP_print_pdf_header_title_block_left"><span className="GP_print_pdf_dimond_symbol"></span>Comparison</div>
                                    <div className="Testscore_GP_print_pdf_header_title_block_right">Date Created: {this.getCurrentDate()}</div>
                                </div>
                            </div>
                            <div className="Testscore_Comparison_print_main">
                                <div className="Testscore_GP_GroupingBy_main_Center">
                                    <div className="Testscore_Comparison_print_Select_levels">
                                        <div style={{ width: '100%', margin: '0 auto', maxWidth: '1037px' }}>
                                            <div className="bec_compare_tab_compare_label">
                                                <NewComparisonCheckBoxesForPDF TS_Overtime={compareOptions} Navselection={Nav} />
                                            </div>
                                        </div>
                                    </div>


                                </div>


                            </div>
                            {/* strt */}
                            <div className="Testscore_Strands_Standards_header">
                                <div className="Testscore_GP_strandName">
                                    Tests
                    </div>
                                <div style={{ float: 'right', width: '660px', display: 'flex' }}>
                                    {HeaderNamesList.map((singleTest, index) => {
                                        return <div className="bec_compare_multi_list_header_strands_single" key={index}>{singleTest.testName}</div>
                                    })}
                                </div>

                            </div>
                            <div className="bec_compare_multi_list_sub_block_compare">
                                {districtComparison != null && (Nav.student || Nav.class || Nav.school || Nav.district) && compareOptions.checkDistrict ? <div className="TS_Comparison_print_bec_compare_multi_list_sub_block_compare_row">
                                    <div className="bec_compare_multi_list_sub_block_compare_label">District Average </div>
                                    <div className="ts_compare_pdf_student_average_score">
                                        <span className={totalDistrictScore != null ? ("color_circle_avaerage compare_col_pdf_padding " + this.colorCodes(totalDistrictScore, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                                            {totalDistrictScore}
                                        </span>
                                    </div>
                                    <div className="bec_compare_multi_list_sub_block_compare_strands_list">
                                        {HeaderNamesList.map((singleTest, index) => {
                                            return <div className="bec_compare_multi_list_header_strands_single" key={index}>
                                                {districtComparison[singleTest.componentCode] != undefined ? `${districtComparison[singleTest.componentCode][0]}` : null}
                                            </div>
                                        })}
                                    </div>
                                </div> : null}
                                {schoolComparison != null && (Nav.student || Nav.class || Nav.school) && compareOptions.checkSchool ? <div className="TS_Comparison_print_bec_compare_multi_list_sub_block_compare_row">
                                    <div className="bec_compare_multi_list_sub_block_compare_label">School Average</div>
                                    <div className="ts_compare_pdf_student_average_score">
                                        <span className={totalSchoolScore != null ? ("color_circle_avaerage compare_col_pdf_padding " + this.colorCodes(totalSchoolScore, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                                            {totalSchoolScore}
                                        </span>
                                    </div>
                                    <div className="bec_compare_multi_list_sub_block_compare_strands_list">
                                        {
                                            HeaderNamesList.map((singleTest, index) => <div className="bec_compare_multi_list_header_strands_single" key={index}>
                                                {schoolComparison[singleTest.componentCode] != undefined ? `${schoolComparison[singleTest.componentCode][0]}` : null}
                                            </div>
                                            )
                                        }
                                    </div>
                                </div> : null}
                                {classComparison != null && (Nav.student || Nav.class) && compareOptions.checkClass ? <div className="TS_Comparison_print_bec_compare_multi_list_sub_block_compare_row">
                                    <div className="bec_compare_multi_list_sub_block_compare_label">Class Average</div>
                                    <div className="ts_compare_pdf_student_average_score">
                                        <span className={totalClassScore != null ? ("color_circle_avaerage compare_col_pdf_padding " + this.colorCodes(totalClassScore, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                                            {totalClassScore}
                                        </span>
                                    </div>
                                    <div className="bec_compare_multi_list_sub_block_compare_strands_list">
                                        {HeaderNamesList.map((singleTest, index) => {
                                            return <div className="bec_compare_multi_list_header_strands_single" key={index}>
                                                {classComparison[singleTest.componentCode] != undefined ? classComparison[singleTest.componentCode][0] : null}
                                            </div>
                                        })}
                                    </div>
                                </div> : null}
                            </div>

                            <div className="Testscore_Comparison_print_Main_Table_Header_middle">
                                <div className="Testscore_GP_serialNumb">
                                    S.No.
                    </div>
                                <div className="Testscore_GP_NumberOFStudents_Groups">
                                    <span className="bec_group_multi_list_sub_header_label_title" style={{ float: "left" }}>
                                        {Nav.student ? "Student" : null}
                                        {Nav.class ? `Students (${currentPageData.length > 0 ? currentPageData.length + "/" + (HeaderDetails ? HeaderDetails.Roster_Tab.StudentsList.length : "") : ""})` : null}
                                        {Nav.school ? `Class (${currentPageData.length > 0 ? currentPageData.length + "/" + (HeaderDetails ? HeaderDetails.Roster_Tab.ClassList.length : "") : ""})` : null}
                                        {Nav.district ? `Schools (${currentPageData.length > 0 ? currentPageData.length + "/" + (HeaderDetails ? HeaderDetails.Roster_Tab.schoolsList.length : "") : ""})` : null}
                                    </span>
                                    <span className="bec_compare_multi_list_toggler" style={{ position: "relative", top: "8px" }}>
                                        {(Nav.student == false) ? (sortingOptions.sortBy == "lastName" && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null) : null}
                                        {(Nav.student == false) ? (sortingOptions.sortBy == "lastName" && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null) : null}

                                    </span>

                                </div>
                                <div className="Testscore_GP_avaerageScore">
                                    <span className="bec_group_multi_list_sub_header_avg_score_label" style={{ float: "left" }}>
                                        <div>
                                            <b>Average % Score</b>

                                        </div>
                                        <div style={{ fontSize: '8px' }}>
                                            (based on tests selected)
                        </div>
                                    </span>
                                    <span className="bec_compare_multi_list_toggler" style={{ position: "relative", left: "4px", top: "8px" }}>
                                        {sortingOptions.sortBy == "studentAvg" && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null}
                                        {sortingOptions.sortBy == "studentAvg" && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null}

                                    </span>
                                </div>
                                <div className="bec_compare_multi_list_sub_header_strands_list" style={{ width: "646px" }}>
                                    {HeaderNamesList.map((vals, index) => {
                                        return <div className="bec_compare_multi_list_sub_header_strands_single">
                                            <div className="bec_compare_multi_list_sub_header_strands_single_sort" style={{ position: "relative", top: "8px", left: "4px" }}>
                                                {sortingOptions.sortOn == vals.componentCode && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null}
                                                {sortingOptions.sortOn == vals.componentCode && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null}
                                            </div>
                                        </div>
                                    })}

                                </div>
                            </div>

                            {/* end */}
                        </div>

                    </div>



                    <div style={{ width: '100%', maxWidth: '1037px', margin: '0 auto' }}>
                        <table cellPadding="0" style={{ border: "none" }}>
                            {/* <thead>
      <tr>
        <td>
          <div className="ts-compare-header-space">&nbsp;</div>
        </td>
      </tr>
    </thead> */}
                            <tbody>
                                <tr>
                                    <td>

                                        <div className={Nav.class ? "content" : "studentts_context_content"}>
                                            <div className="print_pdf_body">
                                                {currentPageData.map((Values, i) => (

                                                    <div className="Testscore_GP_groups">


                                                        <div className="Testscore_student_list">
                                                            <div className="Testscore_serial_num"> {i + 1} </div>
                                                            <div className="Testscore_student_name">{(fromContext == 'district') ? Values.schoolName : (fromContext == 'school' ? Values.className : (Values.firstName + " " + Values.lastName))} </div>
                                                            <div className="Testscore_student_average_score">
                                                                <div className={`color_circle_avaerage ${(((fromContext == 'district')) ? Values.schoolAvg : (fromContext == 'school' ? Values.classAvg : Values.studentAvg)) != null ? this.colorCodes((fromContext == 'district') ? Values.schoolAvg : (fromContext == 'school' ? Values.classAvg : Values.studentAvg), this.props.AchivementLevels) : "bec_group_multi_list_grey"}`}>{(fromContext == 'district') ? Values.schoolAvg : (fromContext == 'school' ? Values.classAvg : Values.studentAvg)}</div>
                                                            </div>
                                                            <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                                                                {HeaderNamesList.map((singleTest, index) => (

                                                                    this.checkTestData(singleTest, Values.tests)


                                                                ))}
                                                            </div>
                                                        </div>
                                                    </div>
                                                ))}

                                            </div>

                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td>
                                        <div className="ts-compare-footer-space">&nbsp;</div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div className={Nav.student ? "Ts_Comparison_fixed_footer" : "Ts_Comparison_print_footer1"}> <div className="gp_print_footer" style={{ padding: "10px 0px 0px 0px" }}>
                        <div className="gp_print_footer_inr">
                            <div className="gp_print_footer_left">
                                <div className="gp_print_footer_left_title">Achievement Levels:</div>
                                <div className="gp_print_footer_left_color_blocks">
                                    <ul>
                                        <li>
                                            <div className="gp_print_footer_color_single_block">
                                                <div className="gp_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                                                <div className="gp_print_footer_color_text ">&lt;{this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%</div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="gp_print_footer_color_single_block">
                                                <div className="gp_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                                                <div className="gp_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="gp_print_footer_color_single_block">
                                                <div className="gp_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                                                <div className="gp_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="gp_print_footer_color_single_block">
                                                <div className="gp_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                                                <div className="gp_print_footer_color_text">&ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="gp_print_footer_right">
                                <div className="gp_print_footer_flag_block">

                                </div>
                                <div className="gp_print_footer_na_block" style={{ float: "right" }}>
                                    <span className="gp_print_footer_na_img">No. QA</span>
                                    <span className="gp_print_footer_na_text">
                                        Number of Questions Assessed
        </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        )
    }
}

class TestScoresComparisonPDF extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        let {NavigationByHeaderSelection}= this.props;

        let context= "district";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        }  else if(NavigationByHeaderSelection.class)
        {
        context = "class";
        } else if(NavigationByHeaderSelection.student)
        {
        context = "student";
        }       

        let compareOptions = this.props.compareOptions;


        return (
            <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon"><img src={printIco} onClick={()=> this.props.trackingUsage(`assessmentreports_testscorescomparisonpdf:${context}`)} width="21" /></span>}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        StrandsorStrandardsList={this.props.StrandsorStrandardsList}
                        standardsList={this.props.standardsList}
                        HeaderNamesList={this.props.HeaderNamesList}
                        ShowTests={this.props.ShowTests}
                        ShowStrandsorStandards={this.props.ShowStrandsorStandards}
                        TotalGroupingList={this.props.TotalGroupingList}
                        currentPageData={this.props.currentPageData}
                        HeaderDetails={this.props.HeaderDetails}
                        sortingOptions={this.props.sortingOptions}
                        ref={el => (this.componentRef = el)}
                        fromContext={this.props.fromContext}
                        fromtab={this.props.fromtab}
                        compareOptions={compareOptions}
                        NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
                        totalClassScore={this.props.totalClassScore}
                        totalSchoolScore={this.props.totalSchoolScore}
                        totalDistrictScore={this.props.totalDistrictScore}
                        AchivementLevels={this.props.AchivementLevels}
                    />
                </div>
            </div>
        )
    }
}


const mapStateToProps = ({ Universal, Reports }) => {
    const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
    const { StandardPerformance_Overview } = Reports;
    return {
        AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview
    };
}

const MapActionToProps = {
    Comparison_Popup,
    EditComparison_Popup,
    SortComparisonBasedOnParam,
    navigationArrowsStandardComparison,
    comparisonCurrentPageClick,
    trackingUsage
}

export default connect(mapStateToProps, MapActionToProps)(TestScoresComparisonPDF);

function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }

}
function sum(obj) {
    var sum = 0;
    for (var el in obj) {
        if (obj.hasOwnProperty(el)) {
            sum += parseFloat(obj[el]);
        }
    }
    return sum;
}