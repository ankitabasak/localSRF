import React from 'react';
import ReactToPrint from 'react-to-print';
import './SingleTestAnalysisPDF.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import ST_AnalysisCheckBoxesForPDF from './ST_AnalysisCheckBoxesForPDF';
import { resetTriggerPDF } from "../../../Redux_Actions/BatchPrintAction";
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
import { LandscapeOrientation } from '../LandscapeOrientation';
import { toFixedDecimalValue, denaminatorDecimalCheck } from '../../../Utils/st_analysis/st_analysis_reusables';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';
class ComponentToPrint extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      bubbleLeft: 0,
      bubbleRight: 3,
    }
  }
  getStandardsFooterData(products) {
    let rows = [];
    let row;
    for (let i = 0; i < Math.floor(products.length); i++) {
      row = '';
      row = (

        <ul key={i}>
          <div className="ST_print_strands_standards_list_ul_row">
            <Row products={products.slice(4 * i, 4 * (i + 1))} key={i} />
          </div>
        </ul>


      );
      rows.push(row);

    }
    return rows
  }
  getFooterData(footerObject, displaySelectedTaxonomyList) {

    return footerObject.map(viewLevel => displaySelectedTaxonomyList.includes(viewLevel.viewName) ? <div className="ST_print_strands_standards_list_main">
      <div className="ST_print_strands_standards_list_title">
        {viewLevel.viewName}
      </div>
      <div className="ST_print_strands_standards_list_inr_block">
        <div className="ST_print_strands_standards_list_ul">


          {this.getStandardsFooterData(viewLevel.standards)}


        </div>
      </div>
    </div> : null)

  }
  getCurrentDate(separator = '/') {

    let newDate = new Date()
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();

    return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
  }
  deletedQuestionTooltip(Nav, singleViewData){

    let flag = false;
    flag = (Nav.student && singleViewData.questionMaxScore == 0 && singleViewData.questionScore == 0) || (Nav.class && singleViewData.questionClassMaxScore == 0 && singleViewData.questionClassScore == 0) || (Nav.school && singleViewData.questionSchoolMaxScore == 0 && singleViewData.questionSchoolScore == 0) || (Nav.district && singleViewData.questionDistrictMaxScore == 0 && singleViewData.questionDistrictScore == 0);
    return flag

  }
  render() {
    const Nav = this.props.NavigationByHeaderSelection;
    const fromContext = this.props.fromContext;
    let ContextHeader = this.props.ContextHeader.Roster_Tab;
    let HeaderDetails = this.props.ContextHeader;
    const { AnalysisData, ApiCalls, Filter } = this.props.singleTestData;
    const { OrginalData, Operational_Data, navigation, pagination, compareOptions, sortOptions } = AnalysisData
    const { sortByParams, TaxonomyParams, AverageScoreParams } = Filter;
    let SelectedTaxonomyList = TaxonomyParams.selectedTaxonomyList_temp.filter(item => item.check === true);
    let AverageScoreParam = AverageScoreParams.selectedAverageScore_temp;

    let displaySelectedTaxonomyList = arrayListOfSelectedTaxonomies(TaxonomyParams.selectedTaxonomyList)
    displaySelectedTaxonomyList.sort()
    let navSelectedTaxonomyList = displaySelectedTaxonomyList.slice(navigation.navigationLeft, navigation.navigationRight)// for display selected taxonomies in nav based view
    const testByQuestionList = Operational_Data.testByQuestionList;

    let currentPageData = testByQuestionList
    let footerObject = this.props.footerObject
    let nodata = "";
    let rows = [];
    let showQuestinDeletedTooltip = false;
    for (let i = 0; i < Math.floor(displaySelectedTaxonomyList.length); i = i + 3) {
      let sliced_taxonomy_data = displaySelectedTaxonomyList.slice(i, i + 3)
      const row = (


        <div className="ST_print_pdf">
          <div className="ST_print_pdf_inr">
            <div className="ST_print_pdf_header">
              <div className="ST_print_pdf_logo">
                <img src={beclogo} width={105} height={28} />
              </div>
            </div>
            {/* context header */}
            <div className="ST_print_pdf_context_header">
              <div className="ST_print_pdf_header_row">
                <ul>
                  {Nav.student ? <li className="pdf_class_name">
                    <span>
                      <b>Student</b> : <span className={Nav.student ? "print_pdf_current_context_color" : ""}>{(ContextHeader.SelectedStudent.name !== undefined) ? ContextHeader.SelectedStudent.name : ""}</span>
                    </span>
                  </li> : ""}
                  {Nav.class && (ContextHeader.StudentsList.length != ContextHeader.StudentIds.length) && ContextHeader.StudentsList.length > 1 ? <li className="pdf_class_name">
                    <span>
                      <b>Students</b> : Custom({(ContextHeader.StudentIds.length !== undefined) ? ContextHeader.StudentIds.length : ""})
                        </span>
                  </li> : ""}
                  {(Nav.student || Nav.class) ? <li className="pdf_class_name">
                    <span>
                      <b>Class</b> : <span className={Nav.class ? "print_pdf_current_context_color" : ""}>{ContextHeader.SelectedClass.name}</span>
                    </span>
                  </li> : null}
                  {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_grade">
                    <span>
                      <b>Teacher</b> : {ContextHeader.SelectedTeacher == "All" ? "All" : ContextHeader.TeacherIds.length > 1 ? "Custom(" + ContextHeader.TeacherIds.length + ")" : ContextHeader.SelectedTeacher.name}
                    </span>
                  </li> : null}
                  {Nav.district && (ContextHeader.SchoolIds.length !== ContextHeader.schoolsList.length) ? <li className="pdf_teacher_name">
                    <span>
                      <b>School</b> : <span>Custom ({ContextHeader.SchoolIds.length})</span>
                    </span>
                  </li> : null}
                  <li className="pdf_class_name">
                    <span>
                      <b>Grade</b> : {convertGrade(ContextHeader.selectedRosterGrade)}
                    </span>
                  </li>
                  {(Nav.district === false) ? <li className="pdf_teacher_name">
                    <span>
                      <b>School</b> : <span className={Nav.school ? "print_pdf_current_context_color" : ""}>{ContextHeader.SelectedSchool.name}</span>
                    </span>
                  </li> : null}
                  {(Nav.school || Nav.district) ? <li className="pdf_district_name">
                    <span>
                      <b>District</b> : <span className={Nav.district ? "print_pdf_current_context_color" : ""}>{ContextHeader.SelectedDistrict.name}</span>
                    </span>
                  </li> : null}
                  {(Nav.district) ? <li className="pdf_tests_name">
                    <span>
                      <b>Tests</b> : {HeaderDetails.tests}
                    </span>
                  </li> : null}
                  {Nav.district && (ContextHeader.SchoolIds.length === ContextHeader.schoolsList.length) ? <li className="pdf_dates">
                    <span>
                      <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                    </span>
                  </li> : null}
                </ul>
              </div>
              {(!Nav.district) ? <div className="ST_print_pdf_header_row">
                <ul>
                  {(Nav.student || Nav.class) ? <li className="pdf_district_name">
                    <span>
                      <b>District</b> : {ContextHeader.SelectedDistrict.name}
                    </span>
                  </li> : null}
                  {(Nav.class || Nav.school) ? <li className="pdf_tests_name">
                    <span>
                      <b>Tests</b> : {HeaderDetails.tests}
                    </span>
                  </li> : null}
                  {(Nav.student) ? <li className="pdf_tests_name">
                    <span>
                      <b>Test</b> : {HeaderDetails.tests}
                    </span>
                  </li> : null}
                  {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_dates">
                    <span>
                      <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                    </span>
                  </li> : null}
                </ul>
              </div> : null}
              {Nav.district && (ContextHeader.SchoolIds.length != ContextHeader.schoolsList.length) ? <div className="ST_print_pdf_header_row">
                <ul>

                  <li className="pdf_dates">
                    <span>
                  <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                    </span>
                  </li>
                </ul>
              </div> : null}
              <div className="ST_print_pdf_header_row_filter">
                <b style={{ float: 'left' }}>Filters:</b>
                <ul style={{ float: 'right', width: 'calc(100% - 60px)' }}>
                  <li>
                    <span className="bec_singleTest_pdf_filter_Selected_radio">
                      <div className="bec_singleTest_pdf_filter_Selected_radio_inr" />
                    </span>
                    Question
                  </li>
                  {SelectedTaxonomyList.map((taxonomy, key) =>
                    <li key={key} style={{ display: "flex" }}>
                      <span>
                        <div>
                          <img src={print_checkbox_selected} className="compare_img_sizes" />
                        </div>
                      </span>
                      {taxonomy.taxonomy_Name}
                    </li>
                  )}

                  <li>
                    <span className="bec_singleTest_pdf_filter_Selected_radio">
                      <div className="bec_singleTest_pdf_filter_Selected_radio_inr" />
                    </span>
                    {AverageScoreParam}
                  </li>
                </ul>
              </div>
            </div>
            {/* context header */}
            <div className="ST_print_pdf_body">
              <div className="ST_print_pdf_body_middle">
                <div className="ST_print_pdf_header_title">
                  <div className="ST_print_pdf_header_title_block">
                    <div className="ST_print_pdf_header_title_block_left">
                      <span className="ST_print_pdf_dimond_symbol" />
                      <span style={{ fontWeight: "500" }}>Single Test Analysis</span>
                    </div>
                    <div className="ST_print_pdf_header_title_block_createdBy STQ_createdByCenter">
                      <b>Created by:</b> {HeaderDetails.LoggedInUserName}
                    </div>
                    <div className="ST_print_pdf_header_title_block_right">

                      <b>Date Created:</b> {this.getCurrentDate()}
                    </div>
                  </div>
                </div>
                {/* comparison start */}
                <div className="singleTest_pdf_Comparison_print_main">
                  <div className="singleTest_pdf_comparison_main_Center">
                    <div className="singleTest_pdf_Select_levels">
                      <div className="singleTest_pdf_compare_tab_compare_label">
                        {!Nav.district ? <ST_AnalysisCheckBoxesForPDF ST_Compare={compareOptions} Navselection={Nav} /> : null}
                      </div>
                    </div>
                  </div>
                </div>
                {/* comparison end */}
                <div className="bec_singleTest_pdf_multi_list">
                  <div className="bec_singleTest_pdf_multi_list_inr">

                    <div className="bec_singleTest_pdf_multi_list_main">
                      <div className="bec_singleTest_pdf_multi_list_header bec_singleTest_multi_list_grid_block">
                        <div className="bec_singleTest_pdf_multi_list_single_label staq_title_font_weight">
                          <span><b>Question</b></span>
                        </div>
                        <div className="bec_singleTest_pdf_multi_list_single_grid">
                          {sliced_taxonomy_data.map((taxonomyheader, key) =>
                            <div className="bec_singleTest_pdf_multi_list_single_taxonomy staq_title_font_weight">
                              <span><b>{taxonomyheader}</b></span>
                            </div>
                          )}
                        </div>
                        <div className="bec_singleTest_pdf_multi_list_single_grid">
                          {compareOptions.checkStudent || fromContext == 'student' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_name bec_singleTest_pdf_multi_list_single_score_headers">
                              <b>Student</b>
                            </div>
                            <span className="bec_singleTest_pdf_multi_list_togglers">
                              {sortOptions.fromSortOn == 'student' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                              {sortOptions.fromSortOn == 'student' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                            </span>
                          </div> : null}
                          {(compareOptions.checkClass && fromContext != 'school') || fromContext == 'class' ? ((compareOptions.checkClass && fromContext != 'district' || fromContext == 'class') ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_name bec_singleTest_pdf_multi_list_single_score_headers"><b>Class</b></div>
                            <span className="bec_singleTest_pdf_multi_list_togglers">

                              {sortOptions.fromSortOn == 'class' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                              {sortOptions.fromSortOn == 'class' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                            </span>
                          </div> : null) : null}
                          {(compareOptions.checkSchool && fromContext != 'district') || fromContext == 'school' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_name bec_singleTest_pdf_multi_list_single_score_headers"><b>School</b></div>
                            <span className="bec_singleTest_pdf_multi_list_togglers">
                              {sortOptions.fromSortOn == 'school' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                              {sortOptions.fromSortOn == 'school' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                            </span>
                          </div> : null}
                          {compareOptions.checkDistrict || fromContext == 'district' ?
                            <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                              <div className="bec_singleTest_pdf_multi_list_name bec_singleTest_pdf_multi_list_single_score_headers"><b>District</b></div>
                              <span className="bec_singleTest_pdf_multi_list_togglers">
                                {sortOptions.fromSortOn == 'district' && sortOptions.orderOfSort == 'DSC' ? <i className="material-icons">expand_more</i> : null}
                                {sortOptions.fromSortOn == 'district' && sortOptions.orderOfSort == 'ASC' ? <i className="material-icons">expand_less</i> : null}
                              </span>
                            </div> : null}
                        </div>
                      </div>
                      {/* sub header */}
                      <div className="bec_singleTest_pdf_multi_list_subheader bec_singleTest_pdf_multi_list_grid_block" style={{ lineHeight: "30px", height: "30px" }}>
                        <div
                          className="bec_singleTest_pdf_multi_list_single_label text-left" style={{ fontWeight: 700, maxWidth: 160 }}>
                          Test Average Score:
                    </div>
                        {/* <div class="bec_singleTest_multi_list_single_question">Question</div> */}
                        <div className="bec_singleTest_pdf_multi_list_single_grid">
                          {compareOptions.checkStudent || fromContext == 'student' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_single_score">
                              <div className={returnBgColorOnValue(Operational_Data.testAvg, this.props.AchivementLevels)}>
                                {returnBasedOnAvgType(Operational_Data.testScore, Operational_Data.testMaxScore, Operational_Data.testAvg, nodata, AverageScoreParams.selectedAverageScore)}
                              </div>
                              {/* <div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                {returnWrappedValue(Operational_Data.testResultNo)}
                              </div> */}
                            </div>
                          </div> : null}
                          {(compareOptions.checkClass && fromContext != 'school') || fromContext == 'class' ? ((compareOptions.checkClass && fromContext != 'district' || fromContext == 'class') ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_single_score">
                              <div className={returnBgColorOnValue(Operational_Data.testClassAvg, this.props.AchivementLevels)}>
                                {returnBasedOnAvgType(Operational_Data.testClassScore, Operational_Data.testClassMaxScore, Operational_Data.testClassAvg, nodata, AverageScoreParams.selectedAverageScore)}
                              </div>
                              <div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                {returnWrappedValue(Operational_Data.testClassResultNo)}
                              </div>
                            </div>
                          </div> : null) : null}
                          {(compareOptions.checkSchool && fromContext != 'district') || fromContext == 'school' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_single_score">
                              <div className={returnBgColorOnValue(Operational_Data.testSchoolAvg, this.props.AchivementLevels)}>
                                {returnBasedOnAvgType(Operational_Data.testSchoolScore, Operational_Data.testSchoolMaxScore, Operational_Data.testSchoolAvg, nodata, AverageScoreParams.selectedAverageScore)}
                              </div>
                              <div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                {returnWrappedValue(Operational_Data.testSchoolResultNo)}
                              </div>
                            </div>
                          </div> : null}
                          {compareOptions.checkDistrict || fromContext == 'district' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                            <div className="bec_singleTest_pdf_multi_list_single_score">
                              <div className={returnBgColorOnValue(Operational_Data.testDistrictAvg, this.props.AchivementLevels)}>
                                {returnBasedOnAvgType(Operational_Data.testDistrictScore, Operational_Data.testDistrictMaxScore, Operational_Data.testDistrictAvg, nodata, AverageScoreParams.selectedAverageScore)}
                              </div>
                              <div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                {returnWrappedValue(Operational_Data.testDistrictResultNo)}
                              </div>
                            </div>
                          </div> : null}
                        </div>
                      </div>
                      {/* sub header end */}
                      <div className="bec_singleTest_pdf_multi_list_singleData">
                        {/* title header */}
                        {/* <div class="bec_singleTest_multi_list_sub_block_title">
                                          <div class="bec_singleTest_multi_list_sub_block_title_label">CaCCSS English Language Arts</div>
                                  </div> */}
                        {/* title header end */}
                        {/* Data row */}
                        <div className="bec_singleTest_pdf_multi_list_Data_row">

                          {currentPageData.map(singleViewData =>
                            <div className="bec_singleTest_pdf_multi_list_row bec_singleTest_pdf_multi_list_grid_block">
                              {showQuestinDeletedTooltip = this.deletedQuestionTooltip(Nav, singleViewData)}
                              <div className={(showQuestinDeletedTooltip == true)?"bec_singleTest_pdf_multi_list_single_q_number bec_singleTest_multi_list_deletedQuestion_opacity_color":((sliced_taxonomy_data.length==1)?"bec_singleTest_pdf_multi_list_single_q_number":"bec_singleTest_pdf_multi_list_single_q_number")}>
                                {singleViewData.questionNo}
                              </div>
                              <div className={(showQuestinDeletedTooltip == true)?"bec_singleTest_pdf_multi_list_single_grid bec_singleTest_multi_list_deletedQuestion_opacity_color":"bec_singleTest_pdf_multi_list_single_grid"}>
                                {sliced_taxonomy_data.map(view =>
                                  <div className={(sliced_taxonomy_data.length == 1) ? "signgletest_onestrand" : "bec_singleTest_pdf_multi_list_single_strand_standards"}>
                                    <div className="bec_singleTest_pdf_multi_list_single_standards_list">
                                      {singleViewData.views.map(innerdata =>

                                        innerdata.viewDetails.map((deepinnerdata, index) =>
                                          (view == innerdata.view) ?
                                            <span className="bec_singleTest_pdf_multi_list_single_standard">
                                              <span className={fromContext == 'student' ? colorBorderForQuestion(deepinnerdata.standardScore, deepinnerdata.standardMaxScore, fromContext) : ""}>
                                                {deepinnerdata.standardShortValue ?
                                                  <React.Fragment>
                                                    {deepinnerdata.standardShortValue}
                                                    {(index < (innerdata.viewDetails.length - 1)) ? "," : null}</React.Fragment> : null}
                                              </span>
                                            </span>
                                            : null
                                        )

                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                              <div className="bec_singleTest_pdf_multi_list_single_grid">
                                {compareOptions.checkStudent || fromContext == 'student' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                                  <div className="bec_singleTest_pdf_multi_list_single_score">
                                    <div className={(showQuestinDeletedTooltip == false)?returnBgColorOnValue(singleViewData.questionAvg, this.props.AchivementLevels):"bec_singleTest_pdf_grayColor"}>
                                      {(showQuestinDeletedTooltip == false)?returnBasedOnAvgType(singleViewData.questionScore, singleViewData.questionMaxScore, singleViewData.questionAvg, nodata, AverageScoreParams.selectedAverageScore):<ColoredLine/>}
                                    </div>
                                    {/* <div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                      {returnWrappedValue(singleViewData.questionNo)}
                                    </div> */}
                                  </div>
                                </div> : null}
                                {(compareOptions.checkClass && fromContext != 'school') || fromContext == 'class' ? ((compareOptions.checkClass && fromContext != 'district' || fromContext == 'class') ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                                  <div className="bec_singleTest_pdf_multi_list_single_score">
                                    <div className={(showQuestinDeletedTooltip == false)?returnBgColorOnValue(singleViewData.questionClassAvg, this.props.AchivementLevels):"bec_singleTest_pdf_grayColor"}>
                                      {(showQuestinDeletedTooltip == false)?returnBasedOnAvgType(singleViewData.questionClassScore, singleViewData.questionClassMaxScore, singleViewData.questionClassAvg, nodata, AverageScoreParams.selectedAverageScore):<ColoredLine/>}
                                    </div>
                                    {(showQuestinDeletedTooltip == false)?<div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                      {returnWrappedValue(singleViewData.questionClassResultNo)}
                                    </div>:null}
                                  </div>
                                </div> : null) : null}
                                {(compareOptions.checkSchool && fromContext != 'district') || fromContext == 'school' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                                  <div className="bec_singleTest_pdf_multi_list_single_score">
                                    <div className={(showQuestinDeletedTooltip == false)?returnBgColorOnValue(singleViewData.questionSchoolAvg, this.props.AchivementLevels):"bec_singleTest_pdf_grayColor"}>
                                      {(showQuestinDeletedTooltip == false)?returnBasedOnAvgType(singleViewData.questionSchoolScore, singleViewData.questionSchoolMaxScore, singleViewData.questionSchoolAvg, nodata, AverageScoreParams.selectedAverageScore):<ColoredLine/>}
                                    </div>
                                    {(showQuestinDeletedTooltip == false)?<div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                      {returnWrappedValue(singleViewData.questionSchoolResultNo)}
                                    </div>:null}
                                  </div>
                                </div> : null}
                                {compareOptions.checkDistrict || fromContext == 'district' ? <div className="bec_singleTest_pdf_multi_list_single_compareBox">
                                  <div className="bec_singleTest_pdf_multi_list_single_score">
                                    <div className={(showQuestinDeletedTooltip == false)?returnBgColorOnValue(singleViewData.questionDistrictAvg, this.props.AchivementLevels):"bec_singleTest_pdf_grayColor"}>
                                      {(showQuestinDeletedTooltip == false)?returnBasedOnAvgType(singleViewData.questionDistrictScore, singleViewData.questionDistrictMaxScore, singleViewData.questionDistrictAvg, nodata, AverageScoreParams.selectedAverageScore):<ColoredLine/>}
                                    </div>
                                    {(showQuestinDeletedTooltip == false)?<div className="bec_singleTest_pdf_multi_list_single_score_q_count">
                                      {returnWrappedValue(singleViewData.questionDistrictResultNo)}
                                    </div>: null}
                                  </div>
                                </div> : null}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Data row end */}
                      </div>
                    </div>


                  </div>
                </div>

              </div>
            </div>
            {/* body ends here */}
            {(footerObject.length > 0 && displaySelectedTaxonomyList.length > 0 && this.props.StandardsDefinition) ? <div className="ST_print_strands_standards_list" style={{ marginBottom: "3px" }}>
              <div className="ST_print_strands_standards_list_inr">
                {this.getFooterData(footerObject, displaySelectedTaxonomyList)}
              </div>
            </div> : null}
            {/* {footerObject.length > 0 ? <div className="ST_print_strands_standards_list" style={{marginBottom:"3px"}}>
              <div className="ST_print_strands_standards_list_inr">
                {footerObject.map(viewLevel => <div className="ST_print_strands_standards_list_main">
                  <div className="ST_print_strands_standards_list_title">
                   {viewLevel.viewName}
                  </div>
                  <div className="ST_print_strands_standards_list_inr_block">
                    <div className="ST_print_strands_standards_list_ul">
                      <ul>
                        <div className="ST_print_strands_standards_list_ul_row">
                          {viewLevel.standards.map((standard, index) => <li className="avoidbreak">
                            <span className="ST_print_strands_standards_list_ul_strandard">
                              {standard.standardShortValue}
                            </span>
                            <span className="ST_print_strands_standards_list_ul_strandard_desc">
                              {standard.standardDesc}
                            </span>
                          </li>)}
                        </div>
                      </ul>
                    </div>
                  </div>
                </div>)}
              </div>
            </div> : null} */}

            <div className="ST_print_footer">
              <div className="ST_print_footer_inr">
                <div className="ST_print_footer_left">
                  <div className="ST_print_footer_left_title">Achievement Levels:</div>
                  <div className="ST_print_footer_left_color_blocks">
                    <ul>
                      <li>
                        <div className="ST_print_footer_color_single_block">
                          <div className="ST_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                          <div className="ST_print_footer_color_text ">&lt;{this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%</div>
                        </div>
                      </li>
                      <li>
                        <div className="ST_print_footer_color_single_block">
                          <div className="ST_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                          <div className="ST_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                        </div>
                      </li>
                      <li>
                        <div className="ST_print_footer_color_single_block">
                          <div className="ST_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                          <div className="ST_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                        </div>
                      </li>
                      <li>
                        <div className="ST_print_footer_color_single_block">
                          <div className="ST_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                          <div className="ST_print_footer_color_text">&ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="ST_print_footer_right">
                  <div className="ST_print_footer_na_block">
                    Based on No. of results: (##)
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="page-break">&nbsp;</div>
        </div>

      );

      rows.push(row);


    }

    return (
      <table className="STAQ_table" style={{ borderSpacing: 0, width: '100%', maxWidth: 1036, margin: '0 auto' }}>
        <thead>
          <tr>
            <td>
              <div className="STAQ_print_header-space">&nbsp;</div>
            </td>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <div className="content_sta">{rows}</div>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <div className="STAQ_print_footer-space">&nbsp;</div>
            </td>
          </tr>
        </tfoot>
      </table>)
  }
}
export function colorBorderForQuestion(score, MaxScore, contextSelected) {

  if (contextSelected == 'student') {

    if (score == 0) {
      return "bec_singleTest_pdf_multi_list_single_standard_id bec_singleTest_pdf_redBorderColor"
    } else if (score == MaxScore) {
      return "bec_singleTest_pdf_multi_list_single_standard_id bec_singleTest_pdf_greenBorderColor"
    } else { // if((score > 0) && (score < MaxScore))
      return "bec_singleTest_pdf_multi_list_single_standard_id bec_singleTest_pdf_yellowBorderColor"
    }

  } else {

    // if(score == 0){
    //   return "bec_singleTest_singleQuestion bec_singleTest_redBorderColor"
    // }else if(score == MaxScore){
    //   return "bec_singleTest_singleQuestion bec_singleTest_greenBorderColor"
    // }else{ // if((score > 0) && (score < MaxScore))
    //   return "bec_singleTest_singleQuestion bec_singleTest_yellowBorderColor"
    // }

    return "bec_singleTest_singleQuestion bec_singleTest_noBorderColor"

  }

}

class ST_AnalysisQuestionsPDF extends React.Component {
  constructor(props) {
    super(props);
    this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
  }

  componentDidMount() {
    this.autoTriggerFunction()  
  }
  componentDidUpdate() {
    this.autoTriggerFunction()
  }

  autoTriggerFunction(e) {
    let Nav = this.props.NavigationByHeaderSelection
    let selectedContextData = Nav.class ? this.props.classBatchPrint : Nav.student ? this.props.studentBatchPrint : null
    let selectedData = selectedContextData != null ? Nav.st_analysis ? selectedContextData.singleTestData : null : null;
    if ((Nav.student || Nav.class) && (selectedData != null) && (selectedData.triggerPDF === true)) {
      let context = Nav.student? "student":"class";
      document.getElementById('printIcon').click();
      this.props.resetTriggerPDF()
      this.props.trackingUsage(`assessmentreports_singletestanalysisquestionpdf:${context}`)
    }
  }
  render() {

    let {NavigationByHeaderSelection}= this.props;

        let context= "district";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        } 

    let testByQuestionList = this.props.singleTestData.AnalysisData.Operational_Data.testByQuestionList;
    testByQuestionList = testByQuestionList == null || testByQuestionList == undefined ? [] : testByQuestionList

    let footer_objectList = structured_pdf_footer(testByQuestionList)
    return (
      <div>
        <ReactToPrint
          trigger={() => <span className="printIcon" id="printIcon"><img src={printIco} onClick={()=>this.props.trackingUsage(`assessmentreports_singletestanalysisquestionspdf:${context}`)} width="21" /></span>}
          content={() => this.componentRef}
        />
        <div style={{ display: "none" }}>
          <LandscapeOrientation />
          <ComponentToPrint
            ContextHeader={this.props.ContextHeader}
            singleTestData={this.props.singleTestData}
            NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
            fromContext={this.props.fromContext}
            footerObject={footer_objectList}
            StandardsDefinition={this.props.StandardsDefinition}
            AchivementLevels={this.props.AchivementLevels}
            ref={el => (this.componentRef = el)} />
        </div>
      </div>
    )
  }
}

const mapStateToProps = ({ Universal, Reports, SingleTestAnalysis, BatchPrintReducer }) => {
  const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
  const { StandardPerformance_Overview } = Reports;
  const { classBatchPrint, studentBatchPrint } = BatchPrintReducer
  return {
    AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview, SingleTestAnalysis, classBatchPrint, studentBatchPrint
  };
}

export default connect(mapStateToProps, {
  resetTriggerPDF,trackingUsage
})(ST_AnalysisQuestionsPDF);
function convertGrade(grade) {

  if (grade == "null" || grade == null) {
    return ``
  } else {
    const value = grade.toString()
    const value2 = value.split("_")[1]
    return `${value2}`
  }

}
export function arrayListOfSelectedTaxonomies(selectedTaxonomyList) {

  let selectedTaxArray = []

  let selectedTaxonomyList_test = selectedTaxonomyList.filter(taxonomy => taxonomy.check == true)

  selectedTaxonomyList_test.map(item => selectedTaxArray.push(item.taxonomy_Name))

  return selectedTaxArray

}
export function returnWrappedValue(value) {
  let returnedResult = ''
  if (value === null) {
    returnedResult = ""
  }
  else {
    returnedResult = "(" + value + ")"
  }
  return returnedResult

}
export function returnBasedOnAvgType(startData, endData, avgScore, nodata, avgType) {
  if (avgType == "percentage") {
    return avgScore + "%"
  } else {
    return toFixedDecimalValue(startData)+"/"+denaminatorDecimalCheck(endData)
    //return (Math.round((startData) * 10) / 10) + "/" + (Math.round((endData) * 10) / 10)
  }
}

export function returnBgColorOnValue(value, AchivementLevels) {

  let returnedResult = ''

  if (value <= AchivementLevels[0]['max']) {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_redBgColor"
  } else if (value <= AchivementLevels[1]['max']) {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_orangeBgColor"
  } else if (value <= AchivementLevels[2]['max']) {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_yellowBgColor"
  } else {
    returnedResult = "bec_singleTest_pdf_multi_list_single_score_inr bec_singleTest_pdf_greenBgColor"
  }

  return returnedResult

}

//To Group all the footer elements as group to display in pdf footer

export function structured_pdf_footer(testByQuestionList) {

  let tempArrayForList = []
  let finalArrayForList = []
  let singleRow = {}
  let instanceRow = null

  testByQuestionList.map(viewDetail => {
    viewDetail.views.map(singleview => {
      singleRow = {}
      singleRow.view = singleview.view
      singleview.viewDetails.map(singleStandard => {
        instanceRow = {}
        instanceRow = {
          "view": singleRow.view,
          "standardShortValue": singleStandard.standardShortValue,
          "standardDesc": singleStandard.standardDesc,
          "standardName": singleStandard.standardName
        }
        tempArrayForList.push(instanceRow)
      })

    })

  })

  const groupBy = (array, key) => {
    return array.reduce((result, currentValue) => {
      (result[currentValue[key]] = result[currentValue[key]] || []).push(
        currentValue
      );
      return result;
    }, {});
  };

  let UniqueArrayList = tempArrayForList
    .map(e => e['standardShortValue'])
    .map((e, i, final) => final.indexOf(e) === i && i)
    .filter(e => tempArrayForList[e]).map(e => tempArrayForList[e]);

  let viewGroup = groupBy(UniqueArrayList, 'view');
  let objectKeys = Object.keys(viewGroup)
  for (let i = 0; i < objectKeys.length; i++) {
    singleRow = {}
    singleRow.viewName = objectKeys[i]
    singleRow.standards = viewGroup[objectKeys[i]];
    finalArrayForList.push(singleRow)
  }
  finalArrayForList.map(singleViewD => {
    singleViewD.standards.sort(function (a, b) {
      if (a.standardShortValue < b.standardShortValue) { return -1; }
      if (a.standardShortValue > b.standardShortValue) { return 1; }
      return 0;
    })
  })

  return finalArrayForList
}
export function Row({ products }) {

  const renderedProducts = products.map((p, index) => (

    <Product
      standard={p}
      index={index}
    />


  ));


  return (renderedProducts);
}
export function Product({ standard, index }) {
  return (
    <li key={index}>
      <span className="ST_print_strands_standards_list_ul_strandard">
        {standard.standardShortValue}
      </span>
      <span className="ST_print_strands_standards_list_ul_strandard_desc">
        {standard.standardDesc}
      </span>
    </li>

  );
}
const ColoredLine = () => (
  <hr
      style={{
          backgroundColor: "#000000",
          height: 1,
          margin:"7px auto",
          width:"15px",
          border:0
      }}
  />
);