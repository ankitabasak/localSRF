import React from 'react';
import ReactToPrint from 'react-to-print';
import './ComparisonPDF.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import {
  Comparison_Popup,
  EditComparison_Popup,
  SortComparisonBasedOnParam,
  navigationArrowsStandardComparison,
  comparisonCurrentPageClick
} from '../../../Redux_Actions/ComparisonActions';
import NewComparisonCheckBoxesForPDF from './NewComparisonCheckBoxesForPDF';
import { LandscapeOrientation } from '../LandscapeOrientation';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class ComponentToPrint extends React.Component {
  constructor(props) {
    super(props);
  }
  getCurrentDate(separator = '/') {

    let newDate = new Date()
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();

    return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
  }
  colorCodes(score, AchivementLevels) {
    switch (true) {
      case (score <= AchivementLevels[0]['max']):
        return "color_circle_avaerage_red";
      case (score <= AchivementLevels[1]['max']):
        return "color_circle_avaerage_orange";
      case (score <= AchivementLevels[2]['max']):
        return "color_circle_avaerage_yellow";
      case (score <= AchivementLevels[3]['max']):
        return "color_circle_avaerage_green"
      default:
        return "color_circle_avaerage_grey";
    }
  }
  /**
   * 
   * @param {* String} ParamOnwhichScore 
   * @param {* String with 'ASC OR DSC'} orderOfSort 
   */
  handleSortingGroups(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
    this.props.SortGroupsBasedOnParam(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
  }
  handleSortingComparison(fromContext, fromtab, ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
    this.props.SortComparisonBasedOnParam(fromContext, fromtab, ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
  }

  render() {
    var StrandsorStrandardsList = this.props.StrandsorStrandardsList;
    var standardsList = this.props.standardsList;
    var ShowStrandsorStandards = this.props.ShowStrandsorStandards;
    var TotalGroupingList = this.props.TotalGroupingList;
    var HeaderDetails = this.props.HeaderDetails;
    var ContextHeaderDetails = this.props.HeaderDetails.Roster_Tab;
    var GroupBy = this.props.AppliedChanges;
    let products = this.props.StrandsorStrandardsList;
    let HeaderNamesList = this.props.HeaderNamesList;
    let rows = [];
    let sortingOptions = this.props.sortingOptions;
    let compareOptions = this.props.compareOptions;
    const Nav = this.props.NavigationByHeaderSelection;
    let fromContext = this.props.fromContext
    let fromtab = this.props.fromtab
    let selectedForStrand = this.props.selectedForStrand
    let totalClassScore = (this.props.totalClassScore > 0) ? this.props.totalClassScore : 0;
    let totalSchoolScore = (this.props.totalSchoolScore > 0) ? this.props.totalSchoolScore : 0;
    let totalDistrictScore = (this.props.totalDistrictScore > 0) ? this.props.totalDistrictScore : 0;
    for (let i = 0; i < Math.floor(products.length); i++) {
      const row = (
        <React.Fragment>
          <div className="c_Cmp_print_strands_standards_list_ul_row">
            <Row
              products={products.slice(4 * i, 4 * (i + 1))}
              selectedForStrand={selectedForStrand}
            />
          </div>

        </React.Fragment>
      );

      rows.push(row);


    }
    //var result = TotalGroupingList.filter(function(e) {return ()    });
    // let filtered = TotalGroupingList.map((student1,index) => {

    // });
    // let filtered = TotalGroupingList['standardAndStrandVODetails'].filter(function (el) {
    //   return el.standardAndStrandAvg != null;
    // });
    //for filter no data and with data starts
    // let filtered = TotalGroupingList.standardAndStrandVODetails.filter(function (el) {
    //   return el.standardAndStrandAvg != null;
    // });
    // let filteredNA = TotalGroupingList.standardAndStrandVODetails.filter(function (el) {
    //   return el.standardAndStrandAvg === null;
    // });
    //start dates
    let startDateString = HeaderDetails.Date_Tab.Report_termStartDate.substring(0, 11);
    let startDateStringArray = startDateString.split(" ");
    let startDateStringArray2 = startDateStringArray[0].split("-");

    //end dates
    let endDateString = HeaderDetails.Date_Tab.Report_termEndDate.substring(0, 11);
    let endDateStringArray = endDateString.split(" ");
    let endDateStringArray2 = endDateStringArray[0].split("-");
    let classComparison = TotalGroupingList.length > 0 ? TotalGroupingList[0].stdAvgForClass : null
    let schoolComparison = TotalGroupingList.length > 0 ? TotalGroupingList[0].stdAvgForSchool : null
    let districtComparison = TotalGroupingList.length > 0 ? TotalGroupingList[0].stdAvgForDistrict : null


    return (
      <div className="Cmp_print_pdf">
        <div className="student_contex_comparison_print_header1">
          <div className="Cmp_print_pdf_header">
            <div className="Cmp_print_pdf_logo">
              <img src={beclogo} width="105" height="28" />
            </div>
            <div className="Cmp_print_pdf_head_text">

            </div>
          </div>
          <div className="Cmp_print_pdf_context_header">
            <div className="Cmp_print_pdf_header_row">
              <ul>
                {Nav.student ? <li className="pdf_class_name">
                  <span>
                    <b>Student</b> : {(ContextHeaderDetails.SelectedStudent.name !== undefined) ? ContextHeaderDetails.SelectedStudent.name : ""}
                  </span>
                </li> : null}
                {/* {Nav.class &&(ContextHeaderDetails.SelectedStudent !== "All")?<li className="pdf_class_name">
                        <span>
                            <b>Students</b> : {(ContextHeaderDetails.SelectedStudent !== undefined)?ContextHeaderDetails.SelectedStudent:null}
                        </span>
                    </li>:null} */}
                {(Nav.student || Nav.class) ? <li className="pdf_class_name">
                  <span>
                    <b>Class</b> : {ContextHeaderDetails.SelectedClass.name}
                  </span>
                </li> : null}
                {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_grade">
                  <span>
                    <b>Teacher</b> : {ContextHeaderDetails.SelectedTeacher == "All" ? "All" : ContextHeaderDetails.TeacherIds.length > 1 ? "Custom(" + ContextHeaderDetails.TeacherIds.length + ")" : ContextHeaderDetails.SelectedTeacher.name}
                  </span>
                </li> : null}
                {Nav.district && (ContextHeaderDetails.SchoolIds.length !== ContextHeaderDetails.schoolsList.length) ? <li className="pdf_school_name">
                  <span>
                    <b>School</b>: <span>Custom ({ContextHeaderDetails.SchoolIds.length})</span>
                  </span>
                </li> : null}
                <li className="pdf_class_name">
                  <span>
                    <b>Grade</b> : {convertGrade(ContextHeaderDetails.selectedRosterGrade)}
                  </span>
                </li>
                {(Nav.school) ? <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                  </span>
                </li> : null}
                {Nav.class && ContextHeaderDetails.SelectedStudent === "All" ? <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                  </span>
                </li> : null}


                {(Nav.school || Nav.district) ? <li className="pdf_district_name topdistrict_name">
                  <span>
                    <b>District</b> : {Nav.district ? (ContextHeaderDetails.SelectedDistrict.name) : ContextHeaderDetails.SelectedDistrict.name}
                  </span>
                </li> : null}
                {(Nav.district) ? <li className="pdf_tests_name">
                  <span>
                    <b>Tests</b> : {HeaderDetails.tests}
                  </span>
                </li> : null}
                {Nav.district && (ContextHeaderDetails.SchoolIds.length === ContextHeaderDetails.schoolsList.length) ? <li className="pdf_dates">
                  <span>
                    <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}

                    {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                  </span>
                </li> : null}
              </ul>
            </div>
            <div className="Cmp_print_pdf_header_row" style={{ borderBottom: "1px solid #9B9B9B" }}>
              <ul>
                {(Nav.student) ? <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                  </span>
                </li> : null}
                {Nav.class && ContextHeaderDetails.SelectedStudent !== "All" ? <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                  </span>
                </li> : null}
                {(Nav.student || Nav.class) ? <li className="pdf_district_name">
                  <span>
                    <b>District</b> : {ContextHeaderDetails.SelectedDistrict.name}
                  </span>
                </li> : null}
                {(Nav.class || Nav.school) ? <li className="pdf_tests_name">
                  <span>
                    <b>Tests</b> : {HeaderDetails.tests}
                  </span>
                </li> : null}
                {Nav.student ? <li className="pdf_tests_name">
                  <span>
                    <b>Test</b> : {HeaderDetails.tests}
                  </span>
                </li> : null}
                {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_dates">
                  <span>
                    <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}

                    {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                  </span>
                </li> : null}
                {Nav.district && (ContextHeaderDetails.SchoolIds.length != ContextHeaderDetails.schoolsList.length) ? <li className="pdf_dates">
                  <span>
                    <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}

                    {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                  </span>
                </li> : null}
                {(Nav.school || Nav.district) ? <li className="pdf_assessed_dates">
                  <span>
                    <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                  </span>
                </li> : null}
                {(Nav.school || Nav.district) ? <li className="pdf_testdata_assessed_for">
                  <span>
                    <b>Test Data Assessed For Grade </b> : {convertGrade(this.props.selectedTestGrade)}
                  </span>
                </li> : null}
              </ul>
            </div>
            {(Nav.student || Nav.class) ? <div className="Cmp_print_pdf_header_row">
              <ul>
                <li className="pdf_assessed_dates">
                  <span>
                    <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                  </span>
                </li>
                <li className="pdf_testdata_assessed_for">
                  <span>
                    <b>Test Data Assessed For Grade </b> : {convertGrade(this.props.selectedTestGrade)}
                  </span>
                </li>
              </ul>
            </div> : null}
          </div>
        </div>

        {/* body start */}

        <div className="Cmp_print_pdf_body">
          <div className="Cmp_print_pdf_body_middle">
            <div className="Cmp_print_pdf_header_title">
              <div className="Cmp_print_pdf_header_title_block">
                <div className="Cmp_print_pdf_header_title_block_left"><span className="Cmp_print_pdf_dimond_symbol"></span>Comparison</div>
                <div className="Cmp_print_pdf_header_title_block_right">Date Created: {this.getCurrentDate()}</div>
              </div>
            </div>
            <div className="Comparison_print_main">
              <div className="Cmp_GroupingBy_main_Center">
                <div className="Comparison_print_Select_levels">
                  <div style={{ width: '100%', margin: '0 auto', maxWidth: '1037px' }}>
                    <div className="bec_compare_tab_compare_label">
                      <NewComparisonCheckBoxesForPDF TS_Overtime={compareOptions} Navselection={Nav} />
                    </div>
                  </div>
                </div>


              </div>


            </div>
            {/* start */}
            <div className="Strands_Standards_header">
              <div className="Cmp_strandName">
                {(this.props.selectedForStrand == true) ? "Strands" : (ShowStrandsorStandards.length != 0 ? ((ShowStrandsorStandards[0].strandName !== null) ? ShowStrandsorStandards[0].strandName : "") : null)}
              </div>
              <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                {HeaderNamesList.map((vals, index) => {

                  return <div className="bec_compare_multi_list_header_strands_single" key={index}>{vals.strandOrStandardName}
                    {this.props.selectedForStrand == false ? <span className="bec_group_multi_list_sub_header_strands_single_sort1" style={{ position: "relative", top: "2px" }}>


                      {(Nav.student == false) ? (sortingOptions.sortOn == vals.strandOrStandardName && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null) : null}
                      {(Nav.student == false) ? (sortingOptions.sortOn == vals.strandOrStandardName && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null) : null}


                    </span> : null}

                  </div>
                })}
              </div>

            </div>
            {/* Strands Comparison start */}
            <div className="bec_compare_multi_list_sub_block_compare">

              {TotalGroupingList.length > 0 && (Nav.student || Nav.class || Nav.school || Nav.district) && compareOptions.checkDistrict ? <div className="Comparison_print_bec_compare_multi_list_sub_block_compare_row">
                <div className="bec_compare_multi_list_sub_block_compare_label">District Average</div>
                <div className="compare_pdf_student_average_score">
                  <span className={totalDistrictScore != null ? ("color_circle_avaerage compare_col_pdf_padding " + this.colorCodes(totalDistrictScore, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                    {totalDistrictScore}
                  </span>
                </div>
                <div className="bec_compare_multi_list_sub_block_compare_strands_list">
                  {HeaderNamesList.map((strandOrstandard, index) => {
                    return <div className="bec_compare_multi_list_header_strands_single" key={index}>
                      {districtComparison !== null ? (districtComparison[strandOrstandard.strandOrStandardVal] != undefined ? (districtComparison[strandOrstandard.strandOrStandardVal]) : null) : null}
                    </div>
                  })}
                </div>
              </div> : null}
              {TotalGroupingList.length > 0 && (Nav.student || Nav.class || Nav.school) && compareOptions.checkSchool ? <div className="Comparison_print_bec_compare_multi_list_sub_block_compare_row">
                <div className="bec_compare_multi_list_sub_block_compare_label">School Average</div>
                <div className="compare_pdf_student_average_score">
                  <span className={totalSchoolScore != null ? ("color_circle_avaerage compare_col_pdf_padding " + this.colorCodes(totalSchoolScore, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                    {totalSchoolScore}
                  </span>
                </div>
                <div className="bec_compare_multi_list_sub_block_compare_strands_list">
                  {
                    HeaderNamesList.map((strandOrstandard, index) => <div className="bec_compare_multi_list_header_strands_single" key={index}>
                      {schoolComparison !== null ? (schoolComparison[strandOrstandard.strandOrStandardVal] != undefined ? (schoolComparison[strandOrstandard.strandOrStandardVal]) : null) : null}
                    </div>
                    )
                  }
                </div>
              </div> : null}
              {TotalGroupingList.length > 0 && (Nav.student || Nav.class) && compareOptions.checkClass ? <div className="Comparison_print_bec_compare_multi_list_sub_block_compare_row">
                <div className="bec_compare_multi_list_sub_block_compare_label">Class Average</div>
                <div className="compare_pdf_student_average_score">
                  <span className={totalClassScore != null ? ("color_circle_avaerage compare_col_pdf_padding " + this.colorCodes(totalClassScore, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                    {totalClassScore}
                  </span>
                </div>
                <div className="bec_compare_multi_list_sub_block_compare_strands_list">
                  {HeaderNamesList.map((strandOrstandard, index) => {
                    return <div className="bec_compare_multi_list_header_strands_single" key={index}>
                      {classComparison !== null ? (classComparison[strandOrstandard.strandOrStandardVal] != undefined ? (classComparison[strandOrstandard.strandOrStandardVal]) : null) : null}
                    </div>
                  })}
                </div>
              </div> : null}


            </div>
            {/* Strands Comparson end */}


            <div className="Comparison_print_Main_Table_Header_middle">
              <div className="Cmp_serialNumb">
                S.No.
              </div>
              <div className="Cmp_NumberOFStudents_Groups">
                <span className="bec_group_multi_list_sub_header_label_title" style={{ float: "left" }}>
                  {Nav.student ? "Student" : null}
                  {Nav.class ? `Students (${TotalGroupingList.length + "/" + (HeaderDetails ? HeaderDetails.Roster_Tab.StudentsList.length : "")})` : null}
                  {Nav.school ? `Class (${TotalGroupingList.length + "/" + (HeaderDetails ? HeaderDetails.Roster_Tab.ClassList.length : "")})` : null}
                  {Nav.district ? `Schools (${TotalGroupingList.length + "/" + (HeaderDetails ? HeaderDetails.Roster_Tab.schoolsList.length : "")})` : null}
                </span>
                <span className="bec_compare_multi_list_toggler" style={{ position: "relative", top: "8px" }}>
                  {(Nav.student == false) ? (sortingOptions.sortBy == "lastName" && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null) : null}
                  {(Nav.student == false) ? (sortingOptions.sortBy == "lastName" && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null) : null}

                </span>

              </div>
              <div className="Cmp_avaerageScore">
                <span className="bec_group_multi_list_sub_header_avg_score_label" style={{ float: "left" }}>
                  <div>
                    <b>Average % Score</b>

                  </div>
                  <div style={{ fontSize: '7px' }}>
                    {(this.props.selectedForStrand == true) ? "(based on strands selected)" : "(based on standards selected)"}
                  </div>
                </span>
                <span className="bec_compare_multi_list_toggler" style={{ position: "relative", left: "4px", top: "8px" }}>
                  {sortingOptions.sortBy == "studentPercentage" && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null}
                  {sortingOptions.sortBy == "studentPercentage" && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null}

                </span>
              </div>
              <div className="bec_compare_multi_list_sub_header_strands_list" style={{ width: "646px" }}>

                {HeaderNamesList.map((vals, index) => {
                  return <div className="bec_compare_multi_list_sub_header_strands_single">
                    <div className="bec_compare_multi_list_sub_header_strands_single_sort" style={{ position: "relative", top: "8px", left: "4px" }}>
                      {sortingOptions.sortOn == vals.strandOrStandardName && sortingOptions.SortOrder == "ASC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null}
                      {sortingOptions.sortOn == vals.strandOrStandardName && sortingOptions.SortOrder == "DSC" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null}
                    </div>
                  </div>
                })}
              </div>
            </div>

            {/* end */}
          </div>
        </div>

        {/* body end */}

        <div style={{ width: '100%', maxWidth: '1037px', margin: '0 auto' }}>
          <table style={{ border: "none" }}>
            {/* <thead>
        <tr>
          <td>
            <div className="Comparison_print_header-space">&nbsp;</div>
          </td>
        </tr>
      </thead> */}
            <tbody>
              <tr>
                <td>

                  <div className="student_context_content">

                    {TotalGroupingList.map((Values, i) => (

                      <div className="Cmp_groups">


                        <div className="cmp_student_list">
                          <div className="serial_num"> {i + 1} </div>
                          <div className="student_name" style={{ textAlign: "left" }}>{(fromContext == 'district') ? (Values.schoolName) : (fromContext == 'school' ? Values.className : Values.firstName + " " + Values.lastName)}</div>
                          <div className="student_average_score">
                            <div className={`color_circle_avaerage ${((fromContext == 'district') ? Values.schoolPercentage : (fromContext == 'school' ? Values.classPercentage : Values.studentPercentage)) != null ? this.colorCodes((fromContext == 'district') ? Values.schoolPercentage : (fromContext == 'school' ? Values.classPercentage : Values.studentPercentage), this.props.AchivementLevels) : "bec_group_multi_list_grey"}`}>{fromContext == 'district' ? Values.schoolPercentage : (fromContext == 'school' ? Values.classPercentage : Values.studentPercentage)}</div></div>
                          <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                            {/* Start */}
                            {
                              HeaderNamesList.map((strandOrStandardName, index) => {
                                return <div className="bec_compare_multi_list_Single_compare_body_row_strand_score">
                                  <div className="bec_compare_single_score_inr_middle">

                                    {
                                      Values.standardAndStrandVODetails.map((strandOrstandard, index) => {
                                        if (this.props.selectedForStrand && strandOrstandard.standardAndStrandName == strandOrStandardName.strandOrStandardName) {
                                          return <div className="student_standard_strand">
                                            <div class={`standard_strand_score ${strandOrstandard.standardAndStrandAvg != null ? this.colorCodes(strandOrstandard.standardAndStrandAvg, this.props.AchivementLevels) : "color_circle_avaerage_grey"}`}>{strandOrstandard.standardAndStrandAvg != null ? strandOrstandard.standardAndStrandAvg : '-'}</div>
                                            <div className="Question_number">No.QA: {strandOrstandard.noOfQuestions}</div>
                                          </div>
                                        }

                                        if (!this.props.selectedForStrand && (strandOrstandard.standardAndStrandName == strandOrStandardName.standardId)) {
                                          return <div className="student_standard_strand">
                                            <div class={`standard_strand_score ${strandOrstandard.standardAndStrandAvg != null ? this.colorCodes(strandOrstandard.standardAndStrandAvg, this.props.AchivementLevels) : "color_circle_avaerage_grey"}`}>{strandOrstandard.standardAndStrandAvg != null ? strandOrstandard.standardAndStrandAvg : '-'}</div>
                                            <div className="Question_number">No.QA: {strandOrstandard.noOfQuestions}</div>
                                          </div>
                                        }
                                      })
                                    }

                                  </div>
                                </div>
                              })}
                            {/* End */}
                          </div>
                        </div>
                      </div>
                    ))}

                    <div className="Cmp_print_strands_standards_list">
                      <div className="Cmp_print_strands_standards_list_inr">
                        <div className="Cmp_print_strands_standards_list_main">
                          <div className="Cmp_print_strands_standards_list_title">
                            {Nav.class ? "Strands/Standards Selected for " + `${this.props.Taxonomy_name}` : "Strands Selected for " + `${this.props.Taxonomy_name}`}

                          </div>
                          <div className="Cmp_print_strands_standards_list_inr_block">
                            <div className="Cmp_print_strands_standards_list_inr_block_title">
                              {(this.props.selectedForStrand == true) ? "Strands" : (ShowStrandsorStandards.length != 0 ? ((ShowStrandsorStandards[0].strandName !== null) ? ShowStrandsorStandards[0].strandName : "") : null)}
                            </div>
                            <div className="c_Cmp_print_strands_standards_list_ul">
                              <ul className={selectedForStrand ? "Removeborderright" : ""}>
                                {selectedForStrand ?
                                  this.props.ShowStrandsorStandards.map((value1, index) => (
                                    <li>
                                      <span className="">
                                        {value1.strandName}
                                      </span>
                                    </li>)) : rows}

                              </ul>


                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td>
                  <div className="Comparison_print_footer-space">&nbsp;</div>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
        <div className={Nav.student ? "Sp_Comparison_print_footer1" : "Sp_Comparison_footer_relative"}> <div className="Cmp_print_footer">
          <div className="Cmp_print_footer_inr">
            <div className="Cmp_print_footer_left">
              <div className="Cmp_print_footer_left_title">Achievement Levels:</div>
              <div className="Cmp_print_footer_left_color_blocks">
                <ul>
                  <li>
                    <div className="Cmp_print_footer_color_single_block">
                      <div className="Cmp_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                      <div className="Cmp_print_footer_color_text ">&lt;{this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%</div>
                    </div>
                  </li>
                  <li>
                    <div className="Cmp_print_footer_color_single_block">
                      <div className="Cmp_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                      <div className="Cmp_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                    </div>
                  </li>
                  <li>
                    <div className="Cmp_print_footer_color_single_block">
                      <div className="Cmp_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                      <div className="Cmp_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                    </div>
                  </li>
                  <li>
                    <div className="Cmp_print_footer_color_single_block">
                      <div className="Cmp_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                      <div className="Cmp_print_footer_color_text">&ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div className="Cmp_print_footer_right">
              <div className="Cmp_print_footer_flag_block">

              </div>
              <div className="Cmp_print_footer_na_block" style={{ float: "right" }}>
                <span className="Cmp_print_footer_na_img">No. QA</span>
                <span className="Cmp_print_footer_na_text" style={{ fontSize: "12px" }}>
                  Number of Questions Assessed
                </span>
              </div>
            </div>
          </div>
        </div>
        </div>

      </div>
    )
  }
}

class ComparisonPDF extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    let {NavigationByHeaderSelection}= this.props;

    let context= "district";
    if(NavigationByHeaderSelection.school)
    {
      context = "school";
    }  else if(NavigationByHeaderSelection.class)
    {
      context = "class";
    } else if(NavigationByHeaderSelection.student)
    {
      context = "student";
    }
     

    var PerformanceFilter = this.props.PopupFilter;
    var selectedTestAssessment;
    var selectedTestGrade;
    selectedTestAssessment = PerformanceFilter.QuestionParams.selectedTestAssessment;
    selectedTestGrade = PerformanceFilter.GradeParams.selectedGrade == '' ||
      PerformanceFilter.GradeParams.selectedGrade == null ? '' :
      PerformanceFilter.GradeParams.selectedGrade.grade;
    let compareOptions = this.props.compareOptions;
    let Taxonomy_name = this.props.PopupFilter.TaxonomyParams.selectedTaxonomy !== undefined ? this.props.PopupFilter.TaxonomyParams.selectedTaxonomy : "";

    return (
      <div>
        <ReactToPrint
          trigger={() => <span className="printIcon"><img src={printIco} onClick={()=> this.props.trackingUsage(`assessmentreports_standardperformancecomparisonpdf:${context}`)} width="21" /></span>}
          content={() => this.componentRef}
        />
        <div style={{ display: "none" }}>
          <LandscapeOrientation />
          <ComponentToPrint
            StrandsorStrandardsList={this.props.StrandsorStrandardsList}
            standardsList={this.props.standardsList}
            HeaderNamesList={this.props.HeaderNamesList}
            ShowStrandsorStandards={this.props.ShowStrandsorStandards}
            TotalGroupingList={this.props.TotalGroupingList}
            HeaderDetails={this.props.HeaderDetails}
            selectedTestGrade={selectedTestGrade}
            selectedTestAssessment={selectedTestAssessment}
            AppliedChanges={this.props.AppliedChanges}
            sortingOptions={this.props.sortingOptions}
            ref={el => (this.componentRef = el)}
            fromContext={this.props.fromContext}
            fromtab={this.props.fromtab}
            compareOptions={compareOptions}
            NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
            Taxonomy_name={Taxonomy_name}
            selectedForStrand={this.props.selectedForStrand}
            totalClassScore={this.props.totalClassScore}
            totalSchoolScore={this.props.totalSchoolScore}
            totalDistrictScore={this.props.totalDistrictScore}
            AchivementLevels={this.props.AchivementLevels}
          />
        </div>
      </div>
    )
  }
}
function Row({ products, selectedForStrand }) {

  const renderedProducts = products.map((p, index) => (

    <Product
      product={p}
      selectedForStrand={selectedForStrand}
      index={index}
    />


  ));


  return (
    <React.Fragment>
      {renderedProducts}

    </React.Fragment>
  );
}
function Product({ product, selectedForStrand, index }) {
  return (

    <li className={selectedForStrand ? "Removeborderright" : "cmp_removemargin"} key={index}>
      <span className={(product.standardDesc != undefined) ? "c_Cmp_print_strands_standards_list_ul_strandard" : ""}>
        {product.strandOrStandardName ? product.strandOrStandardName : ""}
      </span>
      <span className={(product.standardDesc != undefined) ? "c_Cmp_print_strands_standards_list_ul_strandard_desc" : ""}>
        {product.standardDesc ? product.standardDesc : ''}
      </span>
    </li>


  );
}
const mapStateToProps = ({ Universal, Reports }) => {
  const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
  const { StandardPerformance_Overview } = Reports;
  return {
    AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview
  };
}

const MapActionToProps = {
  Comparison_Popup,
  EditComparison_Popup,
  SortComparisonBasedOnParam,
  navigationArrowsStandardComparison,
  comparisonCurrentPageClick,
  trackingUsage
}

export default connect(mapStateToProps, MapActionToProps)(ComparisonPDF);

function convertGrade(grade) {

  if (grade == "null" || grade == null) {
    return ``
  } else {
    const value = grade.toString()
    const value2 = value.split("_")[1]
    return `${value2}`
  }

}
function sum(obj) {
  var sum = 0;
  for (var el in obj) {
    if (obj.hasOwnProperty(el)) {
      sum += parseFloat(obj[el]);
    }
  }
  return sum;
}