import React from 'react';
import ReactToPrint from 'react-to-print';
import './Print.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import ascending from '../../../../public/images/ascending.svg';
import descending from '../../../../public/images/descending.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import { LandscapeOrientation } from '../LandscapeOrientation';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag, SortArray,SortArrayTestScore } from '../AllReusableFunctions';
// import CompareCheckBoxes from '../../../Utils/CompareCheckBoxes';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

function ArrowDisplay(props) {
    const Sorting_Column = props.Sorting_Column;
    const Sorting_Type = props.Sorting_Type;
    const column = props.column;
    if (((Sorting_Column === "lastName" || Sorting_Column === "className" || Sorting_Column === "schoolName") && Sorting_Type === "asc") && (column === "students")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={descending} width="10" height="16" /></span>;

    }
    if (((Sorting_Column === "lastName" || Sorting_Column === "className" || Sorting_Column === "schoolName") && Sorting_Type === "desc") && (column === "students")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={ascending} width="10" height="16" /></span>;
    }
    if ((Sorting_Column === "totalQuestions" && Sorting_Type === "asc") && (column === "questions")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={descending} width="10" height="16" /></span>;

    }
    if (((Sorting_Column === "% Students Complete" || Sorting_Column === "studentPectgComplete") && Sorting_Type === "desc") && (column === "percentage")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={ascending} width="10" height="16" /></span>;
    }
    if (((Sorting_Column === "% Students Complete" || Sorting_Column === "studentPectgComplete") && Sorting_Type === "asc") && (column === "percentage")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={descending} width="10" height="16" /></span>;

    }
    if ((Sorting_Column === "totalQuestions" && Sorting_Type === "desc") && (column === "questions")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={ascending} width="10" height="16" /></span>;
    }
    if (((Sorting_Column === "testScore" || Sorting_Column === "classScore" || Sorting_Column === "schoolScore") && Sorting_Type === "asc") && (column === "score")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={descending} width="10" height="16" /></span>;

    }
    if (((Sorting_Column === "testScore" || Sorting_Column === "classScore" || Sorting_Column === "schoolScore") && Sorting_Type === "desc") && (column === "score")) {
        return <span className="print_pdf_printlist_sorting_img"><img src={ascending} width="10" height="16" /></span>;
    }
    else {
        return "";
    }
}

class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props)
    }



    colorCodes(score) {
        switch (true) {
            case (score < 40):
                return "student_list_red";
            case (score >= 40 && score <= 59):
                return "student_list_orange";
            case (score >= 60 && score <= 79):
                return "student_list_yellow";
            case (score >= 80):
                return "student_list_green"
            default:
                return "bec_group_multi_list_grey";
        }
    }
    render() {
        let ActualArray = this.props.DataToDisplay;
        let pdfl40width = this.props.pdfl40width;
        let pdfl40to50width = this.props.pdfl40to50width;
        let pdfl60to79width = this.props.pdfl60to79width;
        let pdfg80width = this.props.pdfg80width;
        let Pagination = this.props.Pagination;
        if (ActualArray.studentTestScoreList != undefined) {
            ActualArray = ActualArray.studentTestScoreList;
        }
        let ArrayToDisplay = ActualArray;
        let HeaderDetails = this.props.HeaderDetails.Roster_Tab;
        let TestDetails = this.props.HeaderDetails;
        let ProductName = this.props.HeaderDetails;
        if (ProductName.Tests_of_PresentClass.length > 0) {
            ProductName = ProductName.Tests_of_PresentClass[0].productName;
        } else {
            ProductName = "";
        }
        let TS_Details = this.props.Data;
        return (
            <React.Fragment>
                <Page startpagecnt={"1"} endpagecnt={"15"} totalstudentcount={this.props.totalstudentlist} l40studentcount={this.props.l40studentcount}
                    l40to59Studentcount={this.props.l40to59Studentcount} l60to79Studentcount={this.props.l60to79Studentcount}
                    nav={this.props.NavigationByHeaderSelection}
                    l80Studentcount={this.props.l80Studentcount} averageScore={this.props.averageScore} questionCount={this.props.questionCount}
                    standardName={this.props.standardName} strandName={this.props.strandName} strandDescription={this.props.strandDescription}
                    strandDetailsDesc={this.props.strandDetailsDesc}
                    ref={el => (this.componentRef = el)}
                    DataToDisplay={this.props.DataToDisplay}
                    HeaderDetails={this.props.HeaderDetails}
                    pdfl40to50width={this.props.pdfl40to50width}
                    pdfl40width={this.props.pdfl40width}
                    pdfl60to79width={this.props.pdfl60to79width}
                    pdfg80width={this.props.pdfg80width}
                    selectedTestGrade={this.props.selectedTestGrade}
                    selectedTestAssessment={this.props.selectedTestAssessment}
                    Data={this.props.Data}
                    ContextDetails={this.props.ContextHeader}
                    Pagination={this.props.pagination}
                    ContextHeader={this.props.ContextHeader}
                    AchivementLevels= {this.props.AchivementLevels}

                />


            </React.Fragment>
        );
    }
}
class Page extends React.Component {
    constructor(props) {
        super(props)
    }



    colorCodes(score,AchivementLevels) {
        switch (true) {
            case (score <= AchivementLevels[0]['max']):
                return "student_list_red";
            case (score <= AchivementLevels[1]['max']):
                return "student_list_orange";
            case (score <= AchivementLevels[2]['max']):
                return "student_list_yellow";
            case (score <= AchivementLevels[3]['max']):
                return "student_list_green"
            default:
                return "bec_group_multi_list_grey";
        }
    }
    render() {
        let ActualArray = this.props.DataToDisplay;
        let SchoolList_Includes_NullScores = this.props.Data.SchoolList_Includes_NullScores;
        let ClassList_Includes_NullScores = this.props.Data.List_Includes_NullScores;
        let StudentsList_Includes_NullScores = this.props.Data.List_Includes_NullScore;
        let SchoolsList = (this.props.nav.district)?((this.props.ContextHeader.Roster_Tab.schoolsList !== undefined)?this.props.ContextHeader.Roster_Tab.schoolsList:[]):[];
        let ClasessList = (this.props.nav.school)?((this.props.ContextHeader.Roster_Tab.ClassList !== undefined && this.props.ContextHeader.Roster_Tab.ClassList.length>0)?this.props.ContextHeader.Roster_Tab.ClassList:[]):[];
        let StudentsList = (this.props.nav.class)?((this.props.ContextHeader.Roster_Tab.StudentsList !== undefined && this.props.ContextHeader.Roster_Tab.StudentsList.length>0)?this.props.ContextHeader.Roster_Tab.StudentsList:[]):[];

        //getting only selected schools, classes and students from Roster
        let SchoolsArray = (this.props.nav.district)?getCheckedArray(SchoolsList):[];
        let ClassesArray = (this.props.nav.school)?getCheckedArray(ClasessList):[];
        let StudentsArray = (this.props.nav.class)?getCheckedArray(StudentsList):[];

        //Filtering array based on selected roaster schools , classes and students
        let FinalFilteredSchools = (this.props.nav.district)?(SchoolList_Includes_NullScores === undefined?[]: SchoolList_Includes_NullScores.filter(val => SchoolsArray.includes(val.schoolName))):[];
        let FinalFilteredClasses = (this.props.nav.school)?(ClassList_Includes_NullScores === undefined?[]: ClassList_Includes_NullScores.filter(val => ClassesArray.includes(val.className))):[];
        let FinalFilteredStudents = (this.props.nav.class)?(StudentsList_Includes_NullScores === undefined?[]: StudentsList_Includes_NullScores.filter(val => StudentsArray.includes(val.studentName))):[];

        let List_Includes_NullScore = (this.props.nav.class !== undefined && this.props.nav.class) ? FinalFilteredStudents : ((this.props.nav.school !== undefined && this.props.nav.school) ? FinalFilteredClasses : FinalFilteredSchools);
        let sortedData = SortList(this.props.Data.Sorting_Column, this.props.Data.Sorting_Type, List_Includes_NullScore,this.props.nav);
        let pdfl40width = this.props.pdfl40width;
        let pdfl40to50width = this.props.pdfl40to50width;
        let pdfl60to79width = this.props.pdfl60to79width;
        let pdfg80width = this.props.pdfg80width;
        let selectedTestGrade = this.props.selectedTestGrade == undefined || this.props.selectedTestGrade == null ? "" : this.props.selectedTestGrade;
        let Pagination = this.props.Pagination;
        if (ActualArray.studentTestScoreList != undefined) {
            ActualArray = ActualArray.studentTestScoreList;
        }
        let ArrayToDisplay = ActualArray;
        let HeaderDetails = this.props.HeaderDetails.Roster_Tab;
        let TestDetails = this.props.HeaderDetails;
        let ProductName = this.props.HeaderDetails;
        if (ProductName.Tests_of_PresentClass.length > 0) {
            ProductName = ProductName.Tests_of_PresentClass[0].productName;
        } else {
            ProductName = "";
        }
        let TS_Details = this.props.Data;
        let Nav = this.props.nav;
        let filtered = (ArrayToDisplay !== undefined && ArrayToDisplay.length > 0) ? ArrayToDisplay.filter(function (el) {
            if (Nav.district !== undefined && Nav.district) {
                return el.schoolScore != null;
            }
            else if (Nav.school !== undefined && Nav.school) {
                return el.classScore != null;
            }
            else {
                return el.testScore != null;
            }
        }) : [];
        let filteredNA = (sortedData !== undefined && sortedData.length > 0) ? sortedData.filter(function (el) {
            if (Nav.district !== undefined && Nav.district) {
                return el.schoolScore === null;
            }
            else if (Nav.school !== undefined && Nav.school) {
                return el.classScore === null;
            }
            else {
                return el.testScore === null;
            }
        }) : [];

        // let selectedTestGrade = this.props.selectedTestGrade;
        selectedTestGrade = selectedTestGrade.grade == undefined || selectedTestGrade.grade == null ?
            selectedTestGrade : selectedTestGrade.grade
        let row1 = (filtered !== undefined && filtered.length > 0) ? filtered.map((student, index) => {
            let Name = Nav.class ? student.studentName : Nav.school ? student.className : student.schoolName;
            let Score = Nav.class ? student.testScore : Nav.school ? student.classScore : student.schoolScore
            let Id = Nav.class ? student.studentId : Nav.school ? student.classId : student.schoolId
            if (student.testScore !== null || student.classScore !== null || student.schoolScore !== null) {
                return <tr className="print_pdf_student" key={index}>
                    <td className={Nav.class ? "padding_adjustment_printlist": ""}>
                        {index + 1}
                    </td>
                    <td className={Nav.class ? "student-list-col print_list_name padding_adjustment_printlist": "student-list-col print_list_name"}>{Name}</td>
                    {Nav.class ? <td>{Id}</td> : null}
                    <td className="student-list-col">
                        {student.totalQuestions}</td>
                    {(Nav.school || Nav.district) ? <td>{student.studentPectgComplete}</td> : null}
                    <td className="student-list-col" >
                        <div className="score_border"><div className={this.colorCodes(Score,this.props.AchivementLevels)} style={{ padding: "4px 2px", height: "22px !important" }} >{Score}</div></div>
                    </td>
                </tr>;
            }
        }) : null;
        let row2 = (filteredNA !== undefined && filteredNA.length > 0) ? filteredNA.map((student, index1) => {
            let Name = Nav.class ? student.studentName : Nav.school ? student.className : student.schoolName;
            let Id = Nav.class ? student.studentId : Nav.school ? student.classId : student.schoolId
            if (student.testScore === null || student.classScore === null || student.schoolScore === null) {
                return <tr className="print_pdf_student" key={index1}>
                    <td className={Nav.class ? "padding_adjustment_printlist": ""}>
                        {(filtered.length) + index1 + 1}
                    </td>
                    <td className={Nav.class ? "student-list-col print_list_name padding_adjustment_printlist": "student-list-col print_list_name"}>{Name}</td>
                    {Nav.class ? <td>{Id}</td> : null}
                    <td className="student-list-col">
                        NA</td>
                    {(Nav.school || Nav.district) ? <td>NA</td> : null}
                    <td className="student-list-col" >
                        NA
              </td>
                </tr>;
            }
        }) : null;

        return (
            <div className="print_pdf">
                <div className="print_pdf_inr sp_studentlist">
                    <div className="printlist_header1">
                        <div className="print_pdf_header">
                            <div className="print_pdf_logo">
                                <img src={beclogo} width="105" height="28" />
                            </div>
                            <div className="print_pdf_head_text">
                                <span>Benchmark Advance</span>
                            </div>
                        </div>
                      

                        <div className="print_pdf_context_header" >
                            <div className="print_pdf_header_row">
                                <ul>
                                    {HeaderDetails.SelectedStudent != "All" && this.props.nav.student ? <li className="pdf_class_name">
                                        <span>
                                            <b>Student</b> : {HeaderDetails.SelectedStudent.name}
                                        </span>
                                    </li> : null}
                                    {this.props.nav.class && HeaderDetails.SelectedStudent != "All" && (HeaderDetails.SelectedStudent.length != HeaderDetails.StudentsList.length) ?
                                        <li className="pdf_class_name">
                                            <span>
                                                <b>Student</b> : {typeof HeaderDetails.SelectedStudent == "object" ? HeaderDetails.SelectedStudent.name : HeaderDetails.SelectedStudent}
                                            </span>
                                        </li>
                                        : null}

                                    {this.props.nav.student || this.props.nav.class ? <li className="pdf_class_name">
                                        <span>
                                            <b>Class Name</b> : <span className={this.props.nav.class ? "print_pdf_current_context_color" : ""}>{HeaderDetails.SelectedClass.name}</span>
                                        </span>
                                    </li> : null}
                                    {!this.props.nav.district ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>Teacher</b> : {HeaderDetails.SelectedTeacher == "All" ? "All" : HeaderDetails.TeacherIds.length > 1 ? "Custom(" + HeaderDetails.TeacherIds.length + ")" : HeaderDetails.SelectedTeacher.name}
                                        </span>
                                    </li> : null}
                                    {this.props.nav.district && (HeaderDetails.SchoolIds.length !== HeaderDetails.schoolsList.length) ? <li className="pdf_school_name">
                                        <span>
                                            <b>School</b> : <span>Custom ({HeaderDetails.SchoolIds.length})</span>
                                        </span>
                                    </li> : null}
                                    <li className="pdf_grade">
                                        <span>
                                            <b>Grade</b> : {(HeaderDetails.selectedRosterGrade !== undefined && HeaderDetails.selectedRosterGrade !== null) ? convertGrade(HeaderDetails.selectedRosterGrade) : null}
                                        </span>
                                    </li>

                                    {this.props.nav.school ? <li className="pdf_school_name">
                                        <span>
                                            <b>School</b> : <span className={this.props.nav.school ? "print_pdf_current_context_color" : ""}>{HeaderDetails.SelectedSchool.name}</span>
                                        </span>
                                    </li> : null}
                                    {this.props.nav.class && HeaderDetails.SelectedStudent == "All" && (HeaderDetails.StudentsList.length > 0) ? <li className="pdf_district_name">
                                        <span>
                                            <b>School</b> : {HeaderDetails.SelectedSchool.name}
                                        </span>
                                    </li> : null}
                                    {this.props.nav.school || this.props.nav.district ? <li className="pdf_district_name">
                                        <span>
                                            <b>District</b> : <span className={this.props.nav.district ? "print_pdf_current_context_color" : ""}>{HeaderDetails.SelectedDistrict.name}</span>
                                        </span>
                                    </li> : null}
                                    {this.props.nav.district ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Tests</b> : {TestDetails.tests}
                                        </span>
                                    </li> : null}
                                </ul>
                            </div>
                            {!this.props.nav.district ? <div className={`print_pdf_header_row ${(this.props.nav.class) ? "print_pdf_header_row_required_border" : ""}`}>
                                <ul>
                                    {this.props.nav.class && HeaderDetails.SelectedStudent != "All" && (HeaderDetails.SelectedStudent.length != HeaderDetails.StudentsList.length) ? <li className="pdf_district_name">
                                        <span>
                                            <b>School</b> : <span className={this.props.nav.school ? "print_pdf_current_context_color" : ""}>{HeaderDetails.SelectedSchool.name}</span>
                                        </span>
                                    </li> : null}
                                    {(this.props.nav.class) ? <li className="pdf_district_name">
                                        <span>
                                            <b>District</b> : <span className={this.props.nav.district ? "print_pdf_current_context_color" : ""}>{HeaderDetails.SelectedDistrict.name}</span>
                                        </span>
                                    </li> : null}
                                    {!this.props.nav.district ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Tests</b> : {TestDetails.tests}
                                        </span>
                                    </li> : null}
                                    {this.props.nav.school ? <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                        </span>
                                    </li> : null}
                                    {this.props.nav.school ? <li className="pdf_assessed_dates">
                                        <span>
                                            <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                    </span>
                                    </li> : null}
                                    {this.props.nav.school ? <li className="pdf_testdata_assessed_for">
                                        <span>
                                            <b>Test Data Assessed For Grade </b> : {(selectedTestGrade !== undefined && selectedTestGrade !== null) ? convertGrade(selectedTestGrade) : null}
                                        </span>
                                    </li> : null}
                                </ul>

                            </div> : null}
                            {!this.props.nav.school ? <div className="print_pdf_header_row" style={{ borderBottom: "0px" }}>
                                <ul>
                                    <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                        </span>
                                    </li>
                                    <li className="pdf_assessed_dates">
                                        <span>
                                            <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                    </span>
                                    </li>
                                    {this.props.nav.district ? <li className="pdf_testdata_assessed_for">
                                        <span>
                                            <b>Test Data Assessed For Grade </b> : {(selectedTestGrade !== undefined && selectedTestGrade !== null) ? convertGrade(selectedTestGrade) : null}
                                        </span>
                                    </li> : null}
                                    {(this.props.nav.student || this.props.nav.class) ? <li className="pdf_testdata_assessed_for">
                                        <span>
                                            <b>Test Data Assessed For Grade </b> : {(selectedTestGrade !== undefined && selectedTestGrade !== null) ? convertGrade(selectedTestGrade) : null}
                                        </span>
                                    </li> : null}
                                </ul>
                            </div> : null}
                        </div>
                        <div className="print_pdf_header_title_block">
                            <span><span className="print_pdf_dimond_symbol"></span>{Nav.class ? "Student List" : Nav.school ? "Class List" : "School List"}</span>
                        </div>
                    </div>

                    <table cellPadding="0" style={{ border: "none" }} className="">
           
                        <tbody>
                            <tr>
                                <td>
                                    <div className="content">
                                        <div className="print_pdf_body">
                                            <div className="print_pdf_body_middle">
                                                <div className="print_pdf_header_title">

                                                    <div className="print_pdf_header_strand_name">{this.props.standardName}</div>
                                                    {(this.props.strandName != null || undefined) ? <div className="print_pdf_header_standard_name">{this.props.strandName}</div> : null}
                                                    {(this.props.strandDetailsDesc != null || undefined) ? <div className="print_pdf_header_description">
                                                        <b>{this.props.strandDetailsDesc}:</b>{this.props.strandDescription}
                                                    </div> : null}
                                                </div>

                                                <div className="print_pdf_student_list_block">
                                                    <div className="print_pdf_student_list_block_title">
                                                        <div className="print_pdf_student_list_block_head_title">
                                                            Average Score {this.props.averageScore}% based on {this.props.questionCount} questions
                    </div>
                                                        <div className="print_pdf_student_list_block_head_subtitle">
                                                            Note: Average Score for all standards reports equals (earned points/total points)*100
                    </div>
                                                        <div className="print_pdf_student_list_grid_block">
                                                            <div className="print_pdf_student_list_inrgrid">
                                                                <ul>
                                                                    <li style={{ width: "134px" }}>
                                                                        <div className="print_pdf_student_list_grid_single" >
                                                                            <div className="print_pdf_student_list_grid_single_number">{this.props.totalstudentcount}</div>
                                                                            <div className={TS_Details.ActiveHeaderColumn == 'all' ? "print_pdf_student_list_grid_single_text print_pdf_active_range" : "print_pdf_student_list_grid_single_text"}>All</div>
                                                                        </div>
                                                                    </li>
                                                                    <li style={{ width: pdfl40width }}>
                                                                        <div className="print_pdf_student_list_grid_single">
                                                                            <div className="print_pdf_student_list_grid_single_number">{this.props.l40studentcount}</div>
                                                                            <div className={TS_Details.ActiveHeaderColumn == 'l40' ? "print_pdf_student_list_grid_single_text print_pdf_active_range" : "print_pdf_student_list_grid_single_text"}>&#x3c; {this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%</div>
                                                                        </div>
                                                                    </li>
                                                                    <li style={{ width: pdfl40to50width }}>
                                                                        <div className="print_pdf_student_list_grid_single">
                                                                            <div className="print_pdf_student_list_grid_single_number">{this.props.l40to59Studentcount}</div>
                                                                            <div className={TS_Details.ActiveHeaderColumn == 'g59' ? "print_pdf_student_list_grid_single_text print_pdf_active_range" : "print_pdf_student_list_grid_single_text"}>{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                                                                        </div>
                                                                    </li>
                                                                    <li style={{ width: pdfl60to79width }}>
                                                                        <div className="print_pdf_student_list_grid_single">
                                                                            <div className="print_pdf_student_list_grid_single_number">{this.props.l60to79Studentcount}</div>
                                                                            <div className={TS_Details.ActiveHeaderColumn == 'g79' ? "print_pdf_student_list_grid_single_text print_pdf_active_range" : "print_pdf_student_list_grid_single_text"}>{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                                                                        </div>
                                                                    </li>
                                                                    <li style={{ width: pdfg80width }}>
                                                                        <div className="print_pdf_student_list_grid_single">
                                                                            <div className="print_pdf_student_list_grid_single_number">{this.props.l80Studentcount}</div>
                                                                            <div className={TS_Details.ActiveHeaderColumn == 'l80' ? "print_pdf_student_list_grid_single_text print_pdf_active_range" : "print_pdf_student_list_grid_single_text"}>&#x2265;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div className="print_pdf_student_list_table sp_studentlist" style={{ tableLayout: "auto" }}>

                                                            <table style={{ borderCollapse: "collapse" }}>
                                                                <thead style={{ borderBottom: "1px solid #9B9B9B" }}>

                                                                    <th style={{ padding: "10px", borderRight: "1px solid #9B9B9B" }} colSpan="2" width="45%">
                                                                    {Nav.class ? "Students" : Nav.school ? "Class" : "School"} ({this.props.totalstudentcount}/{Nav.class ? HeaderDetails.StudentIds.length : (Nav.school ? HeaderDetails.ClassIds.length : (Nav.district && (HeaderDetails.SchoolIds.length !== HeaderDetails.schoolsList.length)?HeaderDetails.SchoolIds.length:HeaderDetails.schoolsList.length))}) <br />
                                                                        <span style={{ fontWeight: "500" }}> ({Nav.class ? "Students" : Nav.school ? "Classes" : "Schools"} Assessed Online/ {Nav.class ? "Students" : Nav.school ? "Classes" : "Schools"} {Nav.district?((HeaderDetails.SchoolIds.length !== HeaderDetails.schoolsList.length)?"Selected":"Rostered"):(Nav.school ?((HeaderDetails.ClassIds.length !== HeaderDetails.ClassList.length)?"Selected":"Rostered"):(Nav.class?((HeaderDetails.StudentsList.length !== HeaderDetails.StudentIds.length)?"Selected":"Rostered"):null))})</span>
                                                                        <span class="togglers" style={{ visibility: "hidden" }}><i class="material-icons">expand_more</i><i class="material-icons blueColor">expand_less</i></span>
                                                                        <span> <ArrowDisplay column="students" Sorting_Column={TS_Details.Sorting_Column != undefined ? TS_Details.Sorting_Column : ""} Sorting_Type={TS_Details.Sorting_Type != undefined ? TS_Details.Sorting_Type : ""} /></span>
                                                                    </th>
                                                                    {Nav.class ? <th style={{ padding: "10px", borderRight: "1px solid #9B9B9B" }}>
                                                                        Student ID
                                </th> : null}

                                                                    <th style={{ padding: "10px", borderRight: "1px solid #9B9B9B" }}>
                                                                        No.of Questions
                                                    <span> <ArrowDisplay column="questions" Sorting_Column={TS_Details.Sorting_Column != undefined ? TS_Details.Sorting_Column : ""} Sorting_Type={TS_Details.Sorting_Type != undefined ? TS_Details.Sorting_Type : ""} /></span>
                                                                    </th>
                                                                    {(Nav.school || Nav.district) ? <th style={{ padding: "10px", borderRight: "1px solid #9B9B9B" }}>
                                                                        % Students Complete
                                <span> <ArrowDisplay column="percentage" Sorting_Column={TS_Details.Sorting_Column != undefined ? TS_Details.Sorting_Column : ""} Sorting_Type={TS_Details.Sorting_Type != undefined ? TS_Details.Sorting_Type : ""} /></span>
                                                                    </th> : null}
                                                                    <th style={{ padding: "10px" }}>
                                                                        Score
                                                    <span> <ArrowDisplay column="score" Sorting_Column={TS_Details.Sorting_Column != undefined ? TS_Details.Sorting_Column : ""} Sorting_Type={TS_Details.Sorting_Type != undefined ? TS_Details.Sorting_Type : ""} /></span>
                                                                    </th>
                                                                </thead>
                                                                <tbody className="performance_overtime_pdf_font">
                                                                    {row1}
                                                                    {filteredNA != undefined && filteredNA.length > 0 ? <tr><td colSpan="5" style={{ textAlign: "left", background: "#F3F5FA", borderBottom: "1px solid #9B9B9B", borderTop: "1px solid #9B9B9B" }}><b style={{ fontFamily: "Quicksand", fontSize: "14px" }}>No test data for:</b></td></tr> : null}
                                                                    {(filteredNA != undefined && filteredNA.length > 0) ? row2 : null}
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                       
                    </table>

                   
                        <div className="print_pdf_footer">
                            <ul>
                                <li>
                                    <b style={{ fontFamily: "Quicksand" }}>Achievement Levels:</b>
                                </li>
                                <li>
                                    <div className="print_pdf_color_stripe_block">
                                        <div className="print_pdf_color_stripe_bar"></div>
                                        <div className="print_pdf_color_stripe_text">
&lt; {this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%
                    </div>
                                    </div>
                                </li>
                                <li>
                                    <div className="print_pdf_color_stripe_block">
                                        <div className="print_pdf_color_stripe_bar"></div>
                                        <div className="print_pdf_color_stripe_text">
                                        {this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%
                    </div>
                                    </div>
                                </li>
                                <li>
                                    <div className="print_pdf_color_stripe_block">
                                        <div className="print_pdf_color_stripe_bar"></div>
                                        <div className="print_pdf_color_stripe_text">
                                        {this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%
                    </div>
                                    </div>
                                </li>
                                <li>
                                    <div className="print_pdf_color_stripe_block">
                                        <div className="print_pdf_color_stripe_bar"></div>
                                        <div className="print_pdf_color_stripe_text">
                                            &ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%
                    </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    
                </div>
            </div>
        );
    }
}


class PrintList extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let {NavigationByHeaderSelection}= this.props;
        let context= "district";
        let reportName ="schoollistpdf";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        reportName ="classlistpdf";
        }  else if(NavigationByHeaderSelection.class)
        {
        context = "class";
        reportName ="studentlistpdf";
        } 
        
        let conditionalRender = false;
        const conditionalData = this.props.HeaderDetails.Roster_Tab;

        if (conditionalData.SelectedClass != {} && conditionalData.StudentIds.length > 0 && conditionalData.TeacherIds.length > 0 && conditionalData.schoolsList.length > 0) {
            conditionalRender = true
        }
        if (this.props.NavigationByHeaderSelection.district) {
            conditionalRender = true
        }
        return (
            <div>
                {conditionalRender ? <div>
                    <ReactToPrint
                        trigger={() => <span className="printIcon"><img src={printIco} onClick={()=>this.props.trackingUsage(`assessmentreports_${reportName}:${context}`)} width="21" /></span>}
                        content={() => this.componentRef}
                    />
                    <div style={{ display: "none" }}>
                        <LandscapeOrientation />
                        <ComponentToPrint totalstudentlist={this.props.totalstudentlist} l40studentcount={this.props.l40studentcount}
                            l40to59Studentcount={this.props.l40to59Studentcount} l60to79Studentcount={this.props.l60to79Studentcount}
                            NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
                            l80Studentcount={this.props.l80Studentcount} averageScore={this.props.averageScore} questionCount={this.props.questionCount}
                            standardName={this.props.standardName} strandName={this.props.strandName} strandDescription={this.props.strandDescription}
                            strandDetailsDesc={this.props.strandDetailsDesc}
                            ref={el => (this.componentRef = el)}
                            DataToDisplay={this.props.DataToDisplay}
                            HeaderDetails={this.props.HeaderDetails}
                            pdfl40to50width={this.props.pdfl40to50width}
                            pdfl40width={this.props.pdfl40width}
                            pdfl60to79width={this.props.pdfl60to79width}
                            pdfg80width={this.props.pdfg80width}
                            selectedTestGrade={this.props.selectedTestGrade}
                            selectedTestAssessment={this.props.selectedTestAssessment}
                            Data={this.props.Data}
                            ContextHeader={this.props.ContextHeader}
                            Pagination={this.props.pagination}
                            AchivementLevels= {this.props.AchivementLevels}
                            from="PrintList.js"
                        />
                    </div>
                </div> : null}

            </div>
        );
    }
}
const mapStateToProps = ({ Universal }) => {
    const { AchivementLevels, NavigationByHeaderSelection, ContextHeader } = Universal

    return {
        AchivementLevels, NavigationByHeaderSelection, ContextHeader
    };
}

export default connect(mapStateToProps, {
    trackingUsage
})(PrintList);


function convertGrade(grade) {

    if (grade == "null" || grade == null || grade == undefined) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1];
        return `${value2}`
    }

}
function getCheckedArray(originalList) {


    let SelectedData = originalList.filter(item => item.check === true);
    let finalData = [];
    SelectedData.map(e=>{
        finalData.push(e.name)
    })
    
        return finalData;
    

}
function SortList(column, sortType, ArrayList,CurrentNav) {

    if (CurrentNav.school && column == 'lastName') {
        column = 'className';
    } else if (CurrentNav.school && column == 'testScore') {
        column = 'classScore';
    } else if (CurrentNav.district && column == 'lastName') {
        column = 'schoolName';
    } else if (CurrentNav.school && column == 'Date Submitted') {
        column = 'endDate';
    } else if (CurrentNav.school && column == 'studentPectgComplete') {
        column = 'studentPectgComplete';
    }else if (CurrentNav.district && column == '% Students Complete') {
        column = 'studentPectgComplete';
    }
    let SortedArray = [];
    if (ArrayList.length != 0) {
        if(column == "" && sortType == ""){
            SortedArray = ArrayList;
        }
        else if (column == "testScore" || column == "totalQuestions" || column == "classScore") {
            SortedArray = SortArrayTestScore(ArrayList, column, sortType);
        } else {
            SortedArray = SortArray(ArrayList, column, sortType);
        }

    }
    
    return SortedArray;
}
