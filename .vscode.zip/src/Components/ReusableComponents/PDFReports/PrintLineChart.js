import React from 'react';
import ReactToPrint from 'react-to-print';
import './PrintLineChart.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import Chart from '../PDFReports/LineChartUI';
import CompareCheckBoxesForPDF from '../PDFReports/CompareCheckBoxesPDF';
import { connect } from "react-redux";
import { convertUTCDateToLocalDate, displayLocalTimeInPDFContextHeaderBasedOnFlag, Sort_ApiResponse_Payload_Array } from '../AllReusableFunctions';
import { LandscapeOrientation } from '../LandscapeOrientation';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../Utils/globalVars';
class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
    }

   colorCodes(score,AchivementLevels) {
        switch (true) {
          
            case (score <= AchivementLevels[0]['max']):
                return "print_line_chart_avgscore_student print_line_chart_redColor";
            case (score <= AchivementLevels[1]['max']):
                return "print_line_chart_avgscore_student print_line_chart_orangeColor";
            case (score <= AchivementLevels[2]['max']):
                return "print_line_chart_avgscore_student print_line_chart_YellowColor";
            case (score <= AchivementLevels[3]['max']):
                return "print_line_chart_avgscore_student print_line_chart_GreenColor"
            default:
                return "bec_group_multi_list_grey";
        }
    }

    render() {
        let TestNamesList = this.props.linechartprops;
        let ContextDetails = this.props.contextheaderprops.Roster_Tab;
        let TestDetails = this.props.contextheaderprops;
        let ProductDetails = this.props.contextheaderprops;
        if (ProductDetails.Tests_of_PresentClass.length > 0) {
            ProductDetails = ProductDetails.Tests_of_PresentClass[0].productName;
        } else {
            ProductDetails = "";
        }

        let LineChartData;
        let Pagination_StartCount = this.props.Pagination.Chart_Page_Count_Start + 1;
        let Pagination_EndCount = this.props.Pagination.Chart_Page_Count_End;
        if (Pagination_EndCount > TestNamesList.ActualLineChartData.length) {
            Pagination_EndCount = TestNamesList.ActualLineChartData.length;
        }
        if (TestNamesList.ActualLineChartData != undefined) {
            LineChartData = TestNamesList.ActualLineChartData
        }
        
        let dataArray = Sort_ApiResponse_Payload_Array(JSON.parse(JSON.stringify(this.props.data)), 'linechartlist');
        dataArray.reverse();
        return (
            <div className="print_line_chart">
                <div className="print_line_chart_inr">
                    <div className="print_line_chart_header">
                        <div className="print_line_chart_logo">
                            <img src={beclogo} width="105" height="28" />
                        </div>
                        <div className="print_line_chart_head_text">
                            {ProductDetails}
                        </div>
                    </div>
                    <div className="print_line_chart_context_header">
                        <div className="print_line_chart_header_row">
                            <ul>
                            {ContextDetails.SelectedStudent != "All" && this.props.nav.student ? <li className="pdf_class_name">
                                    <span>
                                        <b>Student</b>: <span className={this.props.nav.student?"print_line_chart_current_context_color":""}>{ContextDetails.SelectedStudent.name}</span>
                                    </span>
                                </li> : null}

                                {this.props.nav.class && ContextDetails.SelectedStudent != "All" && (ContextDetails.SelectedStudent.length != ContextDetails.StudentsList.length) ?
                                    <li className="pdf_class_name">
                                        <span>
                                            <b>Student</b>: Custom ({ContextDetails.SelectedStudent.length})
                                        </span>
                                    </li>
                                    : null}

{this.props.nav.student || this.props.nav.class? <li className="pdf_class_name">
                                    <span>
                                        <b>Class Name</b>: <span className={this.props.nav.class?"print_line_chart_current_context_color":""}>{ContextDetails.SelectedClass.name}</span>
                                    </span>
                                </li>:null }
                              {!this.props.nav.district?<li className="pdf_teacher_name">
                        <span>
                            <b>Teacher</b>:  {ContextDetails.SelectedTeacher == "All" ? "All":ContextDetails.TeacherIds.length > 1 ?"Custom("+ContextDetails.TeacherIds.length+")": ContextDetails.SelectedTeacher.name}
                        </span>
                    </li>:null}
                    {this.props.nav.district && (ContextDetails.SchoolIds.length !== ContextDetails.schoolsList.length)?<li className="pdf_school_name">
                                    <span>
                                        <b>School</b>: <span>Custom ({ContextDetails.SchoolIds.length})</span>
                                    </span>
                                </li>:null}
                    <li className="pdf_grade">
                                    <span>
                                        <b>Grade</b>: {convertGrade(ContextDetails.selectedRosterGrade)}
                                    </span>
                                </li>
                                {((ContextDetails.SelectedStudent === "All" && this.props.nav.class)|| this.props.nav.school)?<li className="pdf_school_name">
                                    <span>
                                        <b>School</b>: <span className={this.props.nav.school?"print_line_chart_current_context_color":""}>{ContextDetails.SelectedSchool.name}</span>
                                    </span>
                                </li>:null}
                                {(this.props.nav.school || this.props.nav.district)?<li className="pdf_district_name">
                                    <span>
                                        <b>District</b>: <span className={this.props.nav.district?"print_line_chart_current_context_color":""}>{ContextDetails.SelectedDistrict.name}</span>
                                    </span>
                                </li>:null}
                                {(this.props.nav.district)?<li className="pdf_tests_name">
                                    <span>
                                        <b>Tests</b>: {TestDetails.tests}
                                    </span>
                                </li>:null}
                                {(this.props.nav.district)&& (ContextDetails.SchoolIds.length === ContextDetails.schoolsList.length)?<li className="pdf_dates">
                                    <span>
                                        <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                    </span>
                                </li>:null}
                                </ul>
            </div>
            <div className={`print_line_chart_header_row print_line_chart_pdf_PO ${(this.props.nav.school || this.props.nav.district)?"print_line_chart_header_row_last_header_border":(this.props.nav.student || this.props.nav.class)?"print_line_chart_header_row_required_border":""}`}>
                <ul>
                {(this.props.nav.student || (ContextDetails.SelectedStudent != "All" && this.props.nav.class))?<li className="pdf_school_name">
                                    <span>
                                        <b>School</b>: {ContextDetails.SelectedSchool.name}
                                    </span>
                                </li>:null}
                                {(this.props.nav.student || this.props.nav.class)?<li className="pdf_district_name">
                                    <span>
                                        <b>District</b>: {ContextDetails.SelectedDistrict.name}
                                    </span>
                                </li>:null}
                                {(!this.props.nav.district)?<li className="pdf_tests_name">
                                    <span>
                                        <b>Tests</b>: {TestDetails.tests}
                                    </span>
                                </li>:null}
                                {(!this.props.nav.district)?<li className="pdf_dates">
                                    <span>
                                        <b>Dates</b>:{displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                      </span>
                                </li>:null}
                                {(this.props.nav.district)&& (ContextDetails.SchoolIds.length != ContextDetails.schoolsList.length)?<li className="pdf_dates">
                                    <span>
                                        <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(TestDetails)}
                                    </span>
                                </li>:null}
                                {(this.props.nav.school || this.props.nav.district)?<li className="pdf_assessed_dates">
                                    <span>
                                        <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                                    </span>
                                </li>:null}
                                {(this.props.nav.school || this.props.nav.district) && (ContextDetails.selectedRosterGrade != this.props.selectedTestGrade) ? <li className="pdf_testdata_assessed_for">
                                    <span>
                                        <b>Test Data Assessed For Grade </b>:  {typeof this.props.selectedTestGrade === 'object' && this.props.selectedTestGrade !== null?convertGrade(this.props.selectedTestGrade.grade):convertGrade(this.props.selectedTestGrade)}
                                    </span>
                                </li>:null}
                            </ul>
                        </div>
                        {(this.props.nav.student || this.props.nav.class)?<div className="print_line_chart_header_row print_line_chart_border_none">
                <ul>
                <li className="pdf_assessed_dates">
                                    <span>
                                        <b>Assessed With </b>: {this.props.selectedTestAssessment}+ Questions
                                    </span>
                                </li>
                                {ContextDetails.selectedRosterGrade != this.props.selectedTestGrade ? <li className="pdf_testdata_assessed_for">
                                    <span>
                                        <b>Test Data Assessed For Grade </b>:  {typeof this.props.selectedTestGrade === 'object' && this.props.selectedTestGrade !== null?convertGrade(this.props.selectedTestGrade.grade):convertGrade(this.props.selectedTestGrade)}
                                    </span>
                                </li>:null}
                    </ul>
                    </div>:null}
                    </div>
                    <div className="print_line_chart_body">
                        <div className="print_line_chart_body_middle">
                            <div className="print_line_chart_header_title" style={{position:"relative",top:"-15px"}}>
                                <div className="print_line_chart_header_title_block print_line_chart_header_transparent" style={{border:"none"}}>
                                    <span><span className="print_line_chart_dimond_symbol"></span>Performance Over Time</span>
                                       <div className="second_line" style={{width:"96%", borderTop:"1px solid #9B9B9B",padding:"4px 0px", margin:"5px auto"}}><b>Note:</b> The average score listed in the line graph below is calculated from all data available for each assessment based on the context selected. It does not assume the cohort of students remains the same across the assessments listed.</div>
                                    <div className="print_line_chart_border_line"></div>
                                </div>
                                <div className="print_line_chart_header_strand_name">{this.props.standardName}</div>
                                {(this.props.strandName != null || undefined) ? <div className="print_line_chart_header_standard_name">{this.props.strandName}</div> : null}
                                {(this.props.strandDetailsDesc != null || undefined) ? <div className="print_line_chart_header_description">
                                    <b>{this.props.strandDetailsDesc}:</b> {this.props.strandDescription}
                                </div> : null}
                            </div>


                            <div style={{ marginTop: "20px" }}>
                                <div className="print_line_chart_student_list_block_head_title">
                                    Average Score {this.props.totalAverageScore}% based on {this.props.totalQuestions} questions
                            </div>
                                <div className="print_line_chart_student_list_block_head_subtitle">
                                    Note: Average Score for all standards reports equals (earned points/total points)*100
                            </div>
                                {!this.props.nav.district?<CompareCheckBoxesForPDF
                                    Navselection={this.props.nav}
                                    TS_Overtime={this.props.TS_Overtime}
                                    CheckeThis={this.props.CheckeThis}
                                    ClickOnLabel={this.props.ClickOnLabel}
                                    lastcheckedlabel={this.props.LastChecked_CB} />:null}
                            </div>
                            <Chart margin={{ left: 60, right: 0, bottom: 100, top: 30 }}
                                width={980}
                                height={400}
                                data={this.props.data} XAxis_Params={this.props.XAxis_Params}
                                YAxis_Params={this.props.YAxis_Params}
                                DataSetParam={this.props.DataSetParam}
                                // TooltipParams={tooltipParams}
                                TooltipParams={this.props.TooltipParams}
                                ToolTipData={this.props.ToolTipData}
                                ClassChecked={this.props.ClassChecked}
                                SchoolChecked={this.props.SchoolChecked}
                                DistrictChecked={this.props.DistrictChecked}
                                LastChecked_CB={this.props.LastChecked_CB} />

                            <div class="Test_names_label" style={{float:"left"}}>Test Name</div>
                        </div>
                    </div>

                    <div style={{width:'100%',maxWidth:'1045px',margin:'0 auto'}}>        
    <table style={{border:"none"}}>
        <thead>
            <tr>
                <td>
                <div className="overtime_print_header-space">&nbsp;</div>
                </td>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>
                <div className="overtime_print_content">
                    {/* start */}

                    <div class="print_line_chart_linechart_block">
                                <div class="print_line_chart_linechart_inr_block">
                                    <div class="print_line_chart_linechart_inr_main">
                                        <div class="print_line_chart_linechart_paginator">
                                            Showing results from <span>{Pagination_StartCount} - {Pagination_EndCount}</span> out of <span>{TestNamesList.ActualLineChartData.length}</span>
                                        </div>

                                        <div class="print_line_chart_testsList_block">
                                            <div class="print_line_chart_testList_inr_block">
                                                <div class="print_line_chart_testList_header_block">
                                                    <div class="print_line_chart_testList_header_title">
                                                        Performance Over Time Details {(this.props.strandDetailsDesc !== null)?"("+this.props.strandDetailsDesc+")":null}
                                            </div>
                                                    <div class="print_line_chart_testlist_subheader_block">
                                                        <div class="print_line_chart_testlist_testName_block" style={{ padding: "25px 10px 24px 10px", borderRight: "1px solid #9B9B9B" }}>
                                                            Test Name ({this.props.data.length>0?this.props.data.length:null})
                                                </div>
                                                        <div class="print_line_chart_testlist_avgscore_block" style={{ borderRight: "1px solid #9B9B9B" }}>
                                                            <div class="print_line_chart_testlist_avgscore_title_block">Average Score (%)</div>
                                                            <div class="print_line_chart_testlist_avgscore_scores_divider_block">
                                                                <ul>
                                                                    {this.props.nav.student ? <li> Student</li> : null}
                                                                    {(this.props.nav.student || this.props.nav.class) ?<li> Class </li>:null}
                                                                    {(this.props.TS_Overtime.checkSchool || this.props.nav.school)? <li> School </li> : null}
                                                                    {(this.props.TS_Overtime.checkDistrict || this.props.nav.district)? <li> District </li> : null}
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="print_line_chart_testlist_testSubmitted_block" style={{ padding: "17px 10px 17px 10px", borderRight: "1px solid #9B9B9B" }}>
                                                            Test <br />Submitted
                                                </div>
                                                        <div class="print_line_chart_testlist_questions_block" style={{ padding: "25px 10px 24px 10px" }}>
                                                            Questions
                                                </div>
                                                    </div>
                                                </div>
                                                <div class="print_line_chart_testList_table_block performance_overtime_pdf_font">
                                                    {dataArray.map((test, index) => {
                                                        let Std_Or_CLass= this.props.Navselection.student || this.props.Navselection.class;
                                                        let TestQuestionsList= Std_Or_CLass ?   test.queAndClassIds!==null &&  test.queAndClassIds!==undefined? test.queAndClassIds.map(item=> item.split("-")[0]) : [] : test.questionsList ;
                                                        TestQuestionsList = TestQuestionsList == null || TestQuestionsList == undefined ? []: TestQuestionsList
                                                        return <div class="print_line_chart_testList_table_row">
                                                            <div class="print_line_chart_testlist_testName_block">
                                                            <div class="pdf_sn_number">{index+1}</div>
                                                            <div className="pdf_testname_data">
                                                                {test.testName}
                                                                </div>
                                                            </div>
                                                            <div class="print_line_chart_testlist_avgscore_block">
                                                                <div class="print_line_chart_testlist_avgscore_scores_divider_block">
                                                                    <ul>
                                                                        {this.props.nav.student ? <li>
                                                                            <span 
                                                                                className={this.colorCodes(test.testScore,this.props.AchivementLevels)}
                                                                                // class="print_line_chart_avgscore_student print_line_chart_redColor"
                                                                                >{test.testScore}</span>
                                                                        </li> : null}

                                                                        {(this.props.nav.student || this.props.nav.class) ? <li>
                                                                            <span class="print_line_chart_testlist_avgscore_class">
                                                                                <span className={`print_line_chart_testlist_avgscore_class_score ${this.props.nav.class?this.colorCodes(test.classScore,this.props.AchivementLevels):null}`}>
                                                                                    {this.props.nav.class ? test.classScore : test.testScore}
                                                                                </span>
                                                                                <span class="print_line_chart_testlist_avgscore_class_results">({test.classResults})</span>
                                                                            </span>
                                                                        </li>:null}
                                                                        {(this.props.TS_Overtime.checkSchool || this.props.nav.school)? <li>
                                                                            <span class="print_line_chart_testlist_avgscore_school">
                                                                                <span className={`print_line_chart_testlist_avgscore_school_score ${this.props.nav.school?this.colorCodes(test.schoolScore,this.props.AchivementLevels):null}`}>{test.schoolScore}</span>
                                                                                <span class="print_line_chart_testlist_avgscore_school_results">({test.schoolResults})</span>
                                                                            </span>
                                                                        </li> : null}
                                                                        {(this.props.TS_Overtime.checkDistrict || this.props.nav.district)? <li>
                                                                            <span class="print_line_chart_testlist_avgscore_district">
                                                                                <span className={`print_line_chart_testlist_avgscore_district_score ${this.props.nav.district?this.colorCodes(test.districtScore,this.props.AchivementLevels):null}`}>{test.districtScore}</span>
                                                                                <span class="print_line_chart_testlist_avgscore_district_results">({test.districtResults})</span>
                                                                            </span>
                                                                        </li> : null}
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                            <div className="print_line_chart_testlist_testSubmitted_block">
                                                                {DISPLAY_LOCAL_TIME_IN_UI == true?((test.submitStart == test.submitEnd)?convertUTCDateToLocalDate(test.submitStart,test.submitStartTime):convertUTCDateToLocalDate(test.submitStart,test.submitStartTime)+"-"+convertUTCDateToLocalDate(test.submitEnd,test.submitEndTime)):((test.submitStart == test.submitEnd)?test.submitStart:test.submitStart + "-" + test.submitEnd)}
                                                            </div>
                                                            <div class="print_line_chart_testlist_questions_block">
                                                                                <div class="print_line_chart_testlist_question_count">No. of questions: {  TestQuestionsList.length}</div>
                                                                                <div class="print_line_chart_testlist_question_numbers">({ TestQuestionsList.sort((a, b) => a - b).join(",")})</div>{/**test.queAndClassIds.sort().join(",") */}
                                                                            </div>
                                                        </div>


                                                                        })}

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                    {/* end */}
                </div>
                </td>
            </tr>
            </tbody>
            {/* <tfoot>
            <tr>
                <td>
                <div className="overtime_print_footer-space">&nbsp;</div>
                </td>
            </tr>
            </tfoot> */}
    </table>
</div>


<div className="print_line_chart_footer footer_style_to_avoid_content_break">
                    <ul>
                        <li>
                        <b style={{fontFamily:"Quicksand"}}>Achievement Levels:</b>
                            </li>
                        <li>
                            <div className="print_line_chart_color_stripe_block">
                                <div className="print_line_chart_color_stripe_bar"></div>
                                <div className="print_line_chart_color_stripe_text">
                                    &lt; {this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="print_line_chart_color_stripe_block">
                                <div className="print_line_chart_color_stripe_bar"></div>
                                <div className="print_line_chart_color_stripe_text">
                                {this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="print_line_chart_color_stripe_block">
                                <div className="print_line_chart_color_stripe_bar"></div>
                                <div className="print_line_chart_color_stripe_text">
                                {this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%
                                    </div>
                            </div>
                        </li>
                        <li>
                            <div className="print_line_chart_color_stripe_block">
                                <div className="print_line_chart_color_stripe_bar"></div>
                                <div className="print_line_chart_color_stripe_text">
                                    &ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%
                                    </div>
                            </div>
                        </li>
                    </ul>
                </div>

                </div>
            
            </div>
        );
    }
}

class PrintLineChart extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        let conditionalRender = false;
        const conditionalData = this.props.ContextHeader.Roster_Tab;

        if(conditionalData.StudentIds.length > 0 && conditionalData.TeacherIds.length > 0 && conditionalData.schoolsList.length > 0){
            conditionalRender = true
        }
        if(this.props.NavigationByHeaderSelection.district){
            conditionalRender = true
        }
        return (
            <div>
                {conditionalRender ? <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon"><img src={printIco} width="21" /></span>}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        nav={this.props.NavigationByHeaderSelection}
                        ferppaCoppaEnable={this.props.ferppaCoppaEnable}
                        linechartprops={this.props.StandardPerformance_Overview}
                        contextheaderprops={this.props.ContextHeader}
                        data={this.props.data} XAxis_Params={this.props.XAxis_Params}
                        YAxis_Params={this.props.YAxis_Params}
                        DataSetParam={this.props.DataSetParam}
                        selectedTestAssessment={this.props.selectedTestAssessment}
                        selectedTestGrade={this.props.selectedTestGrade}
                        // TooltipParams={tooltipParams}
                        TooltipParams={this.props.TooltipParams}
                        ToolTipData={this.props.ToolTipData}
                        ClassChecked={this.props.ClassChecked}
                        SchoolChecked={this.props.SchoolChecked}
                        DistrictChecked={this.props.DistrictChecked}
                        LastChecked_CB={this.props.LastChecked_CB}
                        standardName={this.props.standardName}
                        strandName={this.props.strandName}
                        strandDetailsDesc={this.props.strandDetailsDesc}
                        strandDescription={this.props.strandDescription}
                        Navselection={this.props.Navselection}
                        TS_Overtime={this.props.TS_Overtime}
                        CheckeThis={this.props.CheckeThis}
                        Pagination={this.props.Pagination}
                        totalAverageScore={this.props.totalAverageScore}
                        totalQuestions={this.props.totalQuestions}
                        AchivementLevels= {this.props.AchivementLevels}
                        ref={el => (this.componentRef = el)}
                        from="PrintLineChart.js"
                    />
                </div>
                </div> : null}
            </div>
        );
    }
}

const mapStateToProps = ({ Universal, Reports }) => {
    const { AchivementLevels, ContextHeader, NavigationByHeaderSelection,ferppaCoppaEnable } = Universal
    const { StandardPerformance_Overview } = Reports;
    return {
        AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview,ferppaCoppaEnable
    };
}

export default connect(mapStateToProps, {

})(PrintLineChart);

function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }

}