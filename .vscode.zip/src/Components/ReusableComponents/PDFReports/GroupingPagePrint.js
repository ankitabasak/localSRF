import React from 'react';
import ReactToPrint from 'react-to-print';
import './GroupingPagePrint.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import {
  EditClassGrouping,
  GroupPage_SS_Nav,
  GroupPageMoveStudent,
  ClassGroupBy,
  ApplyGroupPopup,
  onClickBubbleGrouping,
  SortGroupsBasedOnParam,
  moveStudentConfirmation
} from '../../../Redux_Actions/ClassGroupingAction';
import { LandscapeOrientation } from '../LandscapeOrientation';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

/*const FooterList = (props) => {
  let dataIndexStart = (props.index) % 4;
  let dataIndexEnd = (props.index) % 3;
  return <div>
    {dataIndexStart ==0 ?` <div className="someExtedndDivision"><li>ok</li>`:null}

    {dataIndexEnd == 0 ? `<li>ok</li></div>`:null}

  </div>
};*/
class ComponentToPrint extends React.Component {
  constructor(props) {
    super(props);
  }
  getCurrentDate(separator = '/') {

    let newDate = new Date()
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();

    return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
  }
  colorCodes(score, AchivementLevels) {
    switch (true) {
      case (score <= AchivementLevels[0]['max']):
        return "color_circle_avaerage_red";
      case (score <= AchivementLevels[1]['max']):
        return "color_circle_avaerage_orange";
      case (score <= AchivementLevels[2]['max']):
        return "color_circle_avaerage_yellow";
      case (score <= AchivementLevels[3]['max']):
        return "color_circle_avaerage_green"
      default:
        return "color_circle_avaerage_grey";
    }
  }
  /**
   * 
   * @param {* String} ParamOnwhichScore 
   * @param {* String with 'ASC OR DSC'} orderOfSort 
   */
  handleSortingGroups(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
    this.props.SortGroupsBasedOnParam(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
  }

  render() {
    // const {GroupPage,openGroupPopUp,selectedGroupByParam, GroupStrandsTab, G_ApiCalls, AppliedChanges} = this.props.ClassGroupingReducer;
    var StrandsorStrandardsList = this.props.StrandsorStrandardsList;
    var standardsList = this.props.standardsList;
    var ShowStrandsorStandards = this.props.ShowStrandsorStandards;
    var TotalGroupingList = this.props.TotalGroupingList;
    var HeaderDetails = this.props.HeaderDetails;
    var ContextHeaderDetails = this.props.HeaderDetails.Roster_Tab;
    var GroupBy = this.props.AppliedChanges;
    let products = this.props.ShowStrandsorStandards;
    let rows = [];
    let sortOptions = this.props.sortOptions;

    for (let i = 0; i < Math.floor(products.length); i++) {
      const row = (
        <div className="gp_print_strands_standards_list_ul_row">
          <Row
            products={products.slice(4 * i, 4 * (i + 1))}

          />
        </div>

      );

      rows.push(row);


    }

    //start dates
    let startDateString = HeaderDetails.Date_Tab.Report_termStartDate.substring(0, 11);
    let startDateStringArray = startDateString.split(" ");
    let startDateStringArray2 = startDateStringArray[0].split("-");

    //end dates
    let endDateString = HeaderDetails.Date_Tab.Report_termEndDate.substring(0, 11);
    let endDateStringArray = endDateString.split(" ");
    let endDateStringArray2 = endDateStringArray[0].split("-");

    return (
      <div className="GP_print_pdf">
        <div className="GP_print_header1">
          <div className="GP_print_pdf_header">
            <div className="GP_print_pdf_logo">
              <img src={beclogo} width="105" height="28" />
            </div>
            <div className="GP_print_pdf_head_text">

            </div>
          </div>
          <div className="GP_print_pdf_context_header">
            <div className="GP_print_pdf_header_row">
              <ul>
                {ContextHeaderDetails.SelectedStudent !== "All" ? <li className="pdf_class_name">
                  <span>
                    <b>Students</b> : {(ContextHeaderDetails.SelectedStudent !== undefined) ? ContextHeaderDetails.SelectedStudent.name : null}
                  </span>
                </li> : null}
                <li className="pdf_class_name">
                  <span>
                    <b>Class</b> : {ContextHeaderDetails.SelectedClass.name}
                  </span>
                </li>
                <li className="pdf_grade">
                  <span>
                    <b>Teacher</b> : {ContextHeaderDetails.SelectedTeacher == "All" ? "All" : ContextHeaderDetails.TeacherIds.length > 1 ? "Custom(" + ContextHeaderDetails.TeacherIds.length + ")" : ContextHeaderDetails.SelectedTeacher.name}
                  </span>
                </li>
                <li className="pdf_class_name">
                  <span>
                    <b>Grade</b> : {convertGrade(this.props.selectedTestGrade)}
                  </span>
                </li>
                {ContextHeaderDetails.SelectedStudent === "All" ? <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                  </span>
                </li> : null}
              </ul>
            </div>
            <div className="GP_print_pdf_header_row">

              <ul>
                {ContextHeaderDetails.SelectedStudent !== "All" ? <li className="pdf_teacher_name">
                  <span>
                    <b>School</b> : {ContextHeaderDetails.SelectedSchool.name}

                  </span>
                </li> : null}
                <li className="pdf_district_name">
                  <span>
                    <b>District</b> : {ContextHeaderDetails.SelectedDistrict.name}
                  </span>
                </li>
                <li className="pdf_tests_name">
                  <span>
                    <b>Tests</b> : {HeaderDetails.tests}
                  </span>
                </li>
                <li className="pdf_dates">
                  <span>
                    <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}
                  </span>
                </li>


              </ul>
            </div>
            <div className="GP_print_pdf_header_row">
              <ul>
                <li className="pdf_assessed_dates">
                  <span>
                    <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                  </span>
                </li>
                <li className="pdf_testdata_assessed_for">
                  <span>
                    <b>Test Data Assessed For Grade </b> : {convertGrade(this.props.selectedTestGrade)}
                  </span>
                </li>
              </ul>
            </div>
          </div>
          <div className="GP_print_pdf_body">
            <div className="GP_print_pdf_body_middle">
              <div className="GP_print_pdf_header_title">
                <div className="GP_print_pdf_header_title_block">
                  <div className="GP_print_pdf_header_title_block_left"><span className="GP_print_pdf_dimond_symbol"></span>Grouping</div>
                  <div className="GP_print_pdf_header_title_block_right">Date Created: {this.getCurrentDate()}</div>
                </div>
              </div>
              <div className="GP_GroupingBy_main">
                <div className="GP_GroupingBy_main_Center">
                  <div className="GP_GroupingBy_Select_levels">
                    <div style={{ margin: '0 22%' }}>
                      <span className="titles">Grouped by</span>
                      <span><span className="circle"><span class={GroupBy == "CLUSTERING" ? "activated" : ''}></span></span><span className="titles">Cluster</span></span>
                      <span><span className="circle"><span class={GroupBy == "AVERAGE" ? "activated" : ''}></span></span><span className="titles">Average</span></span>
                      <span><span className="circle"><span class={GroupBy == "HIGH_LOW" ? "activated" : ''}></span></span><span className="titles">High-Low</span></span>
                    </div>
                  </div>
                  <div className="GP_GroupingBy_Descriptions">
                    <div className="GP_GroupingBy_Description_single"><b>Cluster:</b>Students are grouped by common strengths and weakness on the selected standards. Groups are not necessarily equal size.</div>
                    <div className="GP_GroupingBy_Description_single"><b>Average:</b>Groups of equal size are created based on student's average score across the selected standards.</div>
                    <div className="GP_GroupingBy_Description_single"><b>High-Low:</b>Students with the highest and lowest overall average scores across the selected standards are grouped together.</div>
                  </div>

                </div>
              </div>

              <div className="Strands_Standards_header" style={{ alignItems: "center", display: "flex" }}>
                <div className="GP_strandName">
                  {StrandsorStrandardsList.length > 1 ? "Strands" : StrandsorStrandardsList.length != 0 ? StrandsorStrandardsList[0].strandName : null}
                </div>
                <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                  {StrandsorStrandardsList.length > 1 ? ShowStrandsorStandards.map((value) => (
                    <div className="GP_standards" style={{ alignItems: "center", display: "flex" }}>
                      <span>{value.strandName}</span>
                      <span className="bec_group_multi_list_sub_header_strands_single_sort1" style={{ float: "right", position: "relative", top: "2px" }}>
                        <span className="bec_group_multi_list_toggler">
                          <span className={(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.strandName && sortOptions.orderOfSort == "ASC" ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top")}
                            onClick={
                              () => this.handleSortingGroups("standardAndStrandAvg", "strands", value.strandName, "ASC")
                            }>



                            {(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.strandName && sortOptions.orderOfSort == "ASC" ? <i className="material-icons">expand_less</i> : "")}

                          </span>
                          <span className={(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.strandName && sortOptions.orderOfSort == "DSC" ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom")}
                            onClick={
                              () => this.handleSortingGroups("standardAndStrandAvg", "strands", value.strandName, "DSC")
                            }>

                            {(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.strandName && sortOptions.orderOfSort == "DSC" ? <i className="material-icons">expand_more</i> : "")}
                          </span>
                        </span>
                      </span>
                    </div>
                  )) : ShowStrandsorStandards.map((value) => (
                    <div className="GP_standards">
                      <span> {value.standardName}</span>
                      <span className="bec_group_multi_list_sub_header_strands_single_sort1" style={{ float: "right", position: "relative", top: "2px" }}>
                        <span className="bec_group_multi_list_toggler">
                          <span
                            className={(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.standardId && sortOptions.orderOfSort == "ASC" ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top")}
                            onClick={
                              () => this.handleSortingGroups("standardAndStrandAvg", "standards", value.standardId, "ASC")
                            }>
                            {(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.standardId && sortOptions.orderOfSort == "ASC" ? <i className="material-icons">expand_less</i> : "")}

                          </span>
                          <span
                            className={(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.standardId && sortOptions.orderOfSort == "DSC" ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom")}
                            onClick={
                              () => this.handleSortingGroups("standardAndStrandAvg", "standards", value.standardId, "DSC")
                            }>
                            {(this.props.sortOptions == undefined) ? "ok" : (sortOptions.Strand_Standard == value.standardId && sortOptions.orderOfSort == "DSC" ? <i className="material-icons">expand_more</i> : "")}

                          </span>
                        </span>
                      </span>
                    </div>
                  ))}
                </div>

              </div>

              <div className="GP_Main_Table_Header_middle">
                <div className="GP_serialNumb">
                  S.No.
                </div>
                <div className="GP_NumberOFStudents_Groups">
                  <span className="bec_group_multi_list_sub_header_label_title" style={{ float: "left" }}>
                    Groups({TotalGroupingList.length})/ <br /> Students(23)
                  </span>
                  <span className="bec_group_multi_list_toggler" style={{ float: "left" }}>
                    <span style={{ position: "relative", top: "5px" }}
                      className={(this.props.sortOptions == undefined) ? "ok" : ((sortOptions.ParamOnwhichScore == "lastName" && sortOptions.orderOfSort == "ASC") ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top")}
                      onClick={
                        () => this.handleSortingGroups("lastName", StrandsorStrandardsList.length > 1 ? "strands" : "standards", 'nomatter', "ASC")
                      }>

                      {(this.props.sortOptions == undefined) ? "" : ((sortOptions.ParamOnwhichScore == "lastName" && sortOptions.orderOfSort == "ASC") ? <i className="material-icons">expand_less</i> : "")}
                    </span>

                    <span style={{ position: "relative", top: "5px" }}
                      className={(this.props.sortOptions == undefined) ? "ok1" : ((sortOptions.ParamOnwhichScore == "lastName" && sortOptions.orderOfSort == "DSC") ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom")}
                      onClick={
                        () => this.handleSortingGroups("lastName", StrandsorStrandardsList.length > 1 ? "strands" : "standards", 'nomatter', "DSC")
                      }>
                      {(this.props.sortOptions == undefined) ? "" : ((sortOptions.ParamOnwhichScore == "lastName" && sortOptions.orderOfSort == "DSC") ? <i className="material-icons">expand_more</i> : "")}

                    </span>
                  </span>
                </div>
                <div className="GP_avaerageScore">
                  <span className="bec_group_multi_list_sub_header_avg_score_label" style={{ float: "left" }}>
                    <div>
                      <b>Average % Score</b>

                    </div>
                    <div style={{ fontSize: '9px' }}>
                      (based on selected standards)
                    </div>
                  </span>
                  <span className="bec_group_multi_list_toggler" style={{ float: "left" }}>
                    <span style={{ position: "relative", top: "5px" }}
                      className={(this.props.sortOptions == undefined) ? "ok" : ((sortOptions.ParamOnwhichScore == "studentPercentage" && sortOptions.orderOfSort == "ASC") ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top")}
                      onClick={
                        () => this.handleSortingGroups("studentPercentage", "nomatter", 'nomatter', "ASC")
                      }>

                      {(this.props.sortOptions == undefined) ? "" : ((sortOptions.ParamOnwhichScore == "studentPercentage" && sortOptions.orderOfSort == "ASC") ? <i className="material-icons">expand_less</i> : "")}
                    </span>

                    <span style={{ position: "relative", top: "5px" }}
                      className={(this.props.sortOptions == undefined) ? "ok1" : ((sortOptions.ParamOnwhichScore == "studentPercentage" && sortOptions.orderOfSort == "DSC") ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom")}
                      onClick={
                        () => this.handleSortingGroups("studentPercentage", "nomatter", 'nomatter', "DSC")
                      }>
                      {(this.props.sortOptions == undefined) ? "" : ((sortOptions.ParamOnwhichScore == "studentPercentage" && sortOptions.orderOfSort == "DSC") ? <i className="material-icons">expand_more</i> : "")}

                    </span>
                  </span>
                </div>
                <div className="GP_GroupingBy_Descriptions_note">
                  <b>Note:</b>All Grouping Strategies are based on the following average score calculation for each student/standard in the table below: (earned points/total points)*100
                </div>
              </div>
            </div>

          </div>

        </div>
        <div style={{ width: '100%', maxWidth: '1037px', margin: '0 auto' }}>
          {/* <table style={{borderSpacing:0}}>
    <thead>
      <tr>
        <td>
          <div className="GP_print_header-space">&nbsp;</div>
        </td>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td> */}
          <div className="content">
            {TotalGroupingList.map((StudentNameArray, i) => (

              <div className="GP_groups">
                <div className="print_group_single_group_title">
                  <div className="print_group_single_group_title_inr">
                    <b>Group {i + 1}</b> ({StudentNameArray.length} Students)
                  </div>
                </div>
                {StudentNameArray.map((Values, j) => (
                  <div className="student_list">
                    <div className="serial_num"> {j + 1} </div>
                    <div className="student_name">{Values.firstName + " " + Values.lastName} <span style={(Values.presentGroup == Values.previousGroup) || (Values.presentGroup == Values.parentGroup) ? { visibility: 'hidden' } : { visibility: 'visible' }}><span style={{ float: 'left', marginTop: "5px" }}>{Values.presentGroup !== Values.previousGroup ? <i className="material-icons" style={{ fontSize: "16px", color: "#1964A5", float: "left", marginRight: "5px" }}>flag</i> : ""} {(Values.presentGroup !== Values.previousGroup) ? "(Moved from group " + (Values.previousGroup + 1) + ")" : ""} </span></span></div>
                    <div className="student_average_score">
                      <div className={`color_circle_avaerage ${this.colorCodes(Values.studentPercentage, this.props.AchivementLevels)}`}>{Values.studentPercentage}</div></div>
                    <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                      {Values.standardAndStrandVODetails.map((strands, k) => (
                        <div className="student_standard_strand">
                          <div class={`standard_strand_score ${strands.standardAndStrandAvg != null ? this.colorCodes(strands.standardAndStrandAvg, this.props.AchivementLevels) : "color_circle_avaerage_grey"}`}>{strands.standardAndStrandAvg != null ? strands.standardAndStrandAvg : '-'}</div>
                          <div className="Question_number">No.QA: {strands.noOfQuestions}</div>
                        </div>
                      ))}
                    </div>
                  </div>))}
              </div>
            ))}

            <div className="gp_print_strands_standards_list">
              <div className="gp_print_strands_standards_list_inr">
                <div className="gp_print_strands_standards_list_main">
                  <div className="gp_print_strands_standards_list_title">
                    Strands/Standards Selected
                  </div>
                  <div className="gp_print_strands_standards_list_inr_block">
                    <div className="gp_print_strands_standards_list_inr_block_title">
                      {StrandsorStrandardsList.length > 1 ? "Strands" : StrandsorStrandardsList.length != 0 ? StrandsorStrandardsList[0].strandName + " " : null}
                    </div>
                    <div className="gp_print_strands_standards_list_ul">
                      <ul>
                        {rows}

                        {/*{StrandsorStrandardsList.length > 1 ? ShowStrandsorStandards.map((value1,index) => (
              <li>
              <span className="gp_print_strands_standards_list_ul_strandard">
                   {value1.strandName}
              </span>
          </li>
                )):ShowStrandsorStandards.map((value) => (
                      <li>
                      <span className="gp_print_strands_standards_list_ul_strandard">
                      {value.standardName}
                      </span>
                      <span className="gp_print_strands_standards_list_ul_strandard_desc">
                      {value.standardDesc}
                        </span>
                     </li>
                            
                            
                    ))}*/}



                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
          {/* </td>
      </tr>
    </tbody>
    <tfoot>
      <tr>
        <td>
          <div className="GP_print_footer-space">&nbsp;</div>
        </td>
      </tr>
    </tfoot>
  </table> */}
        </div>
        <div className="GP_print_footer1"> <div className="gp_print_footer">
          <div className="gp_print_footer_inr">
            <div className="gp_print_footer_left">
              <div className="gp_print_footer_left_title">Achievement Levels:</div>
              <div className="gp_print_footer_left_color_blocks">
                <ul>
                  <li>
                    <div className="gp_print_footer_color_single_block">
                      <div className="gp_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                      <div className="gp_print_footer_color_text ">&lt;{this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%</div>
                    </div>
                  </li>
                  <li>
                    <div className="gp_print_footer_color_single_block">
                      <div className="gp_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                      <div className="gp_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                    </div>
                  </li>
                  <li>
                    <div className="gp_print_footer_color_single_block">
                      <div className="gp_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                      <div className="gp_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                    </div>
                  </li>
                  <li>
                    <div className="gp_print_footer_color_single_block">
                      <div className="gp_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                      <div className="gp_print_footer_color_text">&ge;{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div className="gp_print_footer_right">
              <div className="gp_print_footer_flag_block">
                <span className="gp_print_footer_flag_img">
                  <i class="fa fa-flag" aria-hidden="true" style={{ fontSize: '16px' }}></i>
                </span>
                <span className="gp_print_footer_flag_text">
                  Student Manually Placed in Group
                </span>
              </div>
              <div className="gp_print_footer_na_block">
                <span className="gp_print_footer_na_img">No. QA</span>
                <span className="gp_print_footer_na_text">
                  Number of Questions Assessed
                </span>
              </div>
            </div>
          </div>
        </div>
        </div>

      </div>
    )
  }
}

class GroupingPagePrint extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {

    var PerformanceFilter = this.props.StandardPerformance_Overview.StandardPerformanceFilter;
    var selectedTestAssessment;
    var selectedTestGrade;
    selectedTestAssessment = PerformanceFilter.TestAssessment.selectedTestAssessment;
    selectedTestGrade = PerformanceFilter.TestGrade.selectedTestgrade == '' ||
      PerformanceFilter.TestGrade.selectedTestgrade == null ? '' :
      PerformanceFilter.TestGrade.selectedTestgrade.grade;


    let { G_ApiCalls } = this.props.ClassGroupingReducer

    return (
      <div>
        <ReactToPrint
          trigger={() => <span className="printIcon"><img src={printIco} onClick={()=>this.props.trackingUsage("assessmentreports_standardperformancegroupingpdf:class")} width="21" /></span>}
          content={() => this.componentRef}
        />
        <div style={{ display: "none" }}>
          <LandscapeOrientation />
          <ComponentToPrint
            StrandsorStrandardsList={this.props.StrandsorStrandardsList}
            standardsList={this.props.standardsList}
            ShowStrandsorStandards={this.props.ShowStrandsorStandards}
            TotalGroupingList={this.props.TotalGroupingList}
            HeaderDetails={this.props.HeaderDetails}
            selectedTestGrade={selectedTestGrade}
            selectedTestAssessment={selectedTestAssessment}
            AppliedChanges={this.props.AppliedChanges}
            sortOptions={this.props.sortOptions}
            AchivementLevels={this.props.AchivementLevels}
            ref={el => (this.componentRef = el)}
          />
        </div>
      </div>
    )
  }
}
function Row({ products }) {

  const renderedProducts = products.map(p => (

    <Product
      product={p}
    />


  ));


  return (
    <div>
      {renderedProducts}

    </div>
  );
}
function Product({ product }) {
  return (

    <li>
      <span className="gp_print_strands_standards_list_ul_strandard">
        {product.strandName ? product.strandName : product.standardName}
      </span>
      <span className="gp_print_strands_standards_list_ul_strandard_desc">
        {product.standardDesc ? product.standardDesc : ''}
      </span>
    </li>


  );
}
const mapStateToProps = ({ Universal, Reports, ClassGroupingReducer }) => {
  const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
  const { StandardPerformance_Overview } = Reports;
  return {
    AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview, ClassGroupingReducer
  };
}

export default connect(mapStateToProps, {
  trackingUsage
})(GroupingPagePrint);

function convertGrade(grade) {

  if (grade == "null" || grade == null) {
    return ``
  } else {
    const value = grade.toString()
    const value2 = value.split("_")[1]
    return `${value2}`
  }

}