import React from 'react';
import ReactToPrint from 'react-to-print';
import './AllSummaryPDF.css';
import beclogo from '../../../../public/images/bec-logo.svg';
import printIco from '../../../../public/images/ic_print_new.svg';
import { connect } from "react-redux";
import {
    Comparison_Popup,
    EditComparison_Popup,
    SortComparisonBasedOnParam,
    navigationArrowsStandardComparison,
    comparisonCurrentPageClick
} from '../../../Redux_Actions/ComparisonActions';
import SummaryCheckboxesPDF from './SummaryCheckboxesPDF';
import { resetTriggerPDF } from "../../../Redux_Actions/BatchPrintAction";
import { LandscapeOrientation } from '../LandscapeOrientation';
import { displayLocalTimeInPDFContextHeaderBasedOnFlag } from '../AllReusableFunctions';
import {colorCodes} from '../AllReusableFunctions_Two';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
    }
    getCurrentDate(separator = '/') {

        let newDate = new Date()
        let date = newDate.getDate();
        let month = newDate.getMonth() + 1;
        let year = newDate.getFullYear();

        return `${month < 10 ? `0${month}` : `${month}`}${separator}${date}${separator}${year}`
    }


    ReturnStandardAvg_for_Dist_School_Class(Data) {
        return Data.map((key) => <div className="bec_summary_multi_list_header_strands_single scorefontfamily AllSummary_comapreScoreFontSize"> {key[2]} </div>

        )
    }
    DistrictAverage(Nav, Data, Avg) {
        return (

            <div className="AllSummary_print_bec_compare_multi_list_sub_block_compare_row">
                <div className="bec_compare_multi_list_sub_block_compare_label">District Average</div>
                <div className="AllSummary_pdf_student_average_score AllSummary_fontstyle">
                    <span className={Avg != null ? ("color_circle_avaerage summary_compare_col_pdf_padding " + colorCodes(Avg, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                        {Avg}
                    </span>
                </div>
                <div className="bec_compare_multi_list_sub_block_compare_strands_list AllSummary_fontstyle">
                    {this.ReturnStandardAvg_for_Dist_School_Class(Data)}
                </div>
            </div>
        )
    };
    SchoolAverage(Nav, Data, Avg) {
        return (

            <div className="AllSummary_print_bec_compare_multi_list_sub_block_compare_row">
                <div className="bec_compare_multi_list_sub_block_compare_label">School Average</div>
                <div className="AllSummary_pdf_student_average_score AllSummary_fontstyle">
                    <span className={Avg != null ? ("color_circle_avaerage summary_compare_col_pdf_padding " + colorCodes(Avg, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                        {Avg}
                    </span>
                </div>
                <div className="bec_compare_multi_list_sub_block_compare_strands_list AllSummary_fontstyle">
                    {this.ReturnStandardAvg_for_Dist_School_Class(Data)}
                </div>
            </div>
        )
    };
    ClassAverage(Nav, Data, Avg) {
        return (

            <div className="AllSummary_print_bec_compare_multi_list_sub_block_compare_row">
                <div className="bec_compare_multi_list_sub_block_compare_label">Class Average</div>
                <div className="AllSummary_pdf_student_average_score AllSummary_fontstyle">
                    <span className={Avg != null ? ("color_circle_avaerage summary_compare_col_pdf_padding " + colorCodes(Avg, this.props.AchivementLevels)) : "bec_group_multi_list_grey"}>

                        {Avg}
                    </span>
                </div>
                <div className="bec_compare_multi_list_sub_block_compare_strands_list AllSummary_fontstyle">
                    {this.ReturnStandardAvg_for_Dist_School_Class(Data)}
                </div>
            </div>
        )
    };
    /**
     * 
     * @param {* String} ParamOnwhichScore 
     * @param {* String with 'ASC OR DSC'} orderOfSort 
     */
    handleSortingGroups(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
        this.props.SortGroupsBasedOnParam(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
    }
    handleSortingComparison(fromContext, fromtab, ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
        this.props.SortComparisonBasedOnParam(fromContext, fromtab, ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
    }

    ReturnStrandards(StandardsData, DataSortOn, SortOrder, SortStandard) {
        if (StandardsData == undefined) {
            return null;
        } else {


            return StandardsData.map((vals, index) => {

                return <div className="bec_compare_multi_list_header_strands_single AllSummary_fontstyle AllSummary_fontsize" key={index}><div className="All_Summary_Strand_Top_name">{vals.standardShortValue}</div>
                    <span className="bec_group_multi_list_sub_header_strands_single_sort1" style={{ position: "relative", top: "2px" }}>


                        {(DataSortOn == "onStandardScore" && SortOrder == "asc" && SortStandard == (vals.standardAndStrandName) ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null)}
                        {(DataSortOn == "onStandardScore" && SortOrder == "desc" && SortStandard == (vals.standardAndStrandName) ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null)}


                    </span>

                </div>
            })
        }
    }
    render() {
        let Nav = this.props.NavigationByHeaderSelection;
        let Summary_Prop = this.props.SummaryDataProp;
        const { DataSortOn, SortOrder, SortStandard } = Summary_Prop
        let Strad = Summary_Prop.List;
        let Current_Nav_Left = parseInt(Summary_Prop.navigation.navigationLeft);
        let Current_Nav_Right = parseInt(Summary_Prop.navigation.navigationRight);

        let DistrictData = Strad.scoreAndMaxScoreForDistrict !== undefined ? Strad.scoreAndMaxScoreForDistrict : [];
        //DistrictData = DistrictData.slice(Current_Nav_Left, Current_Nav_Right);

        let SchoolData = Strad.scoreAndMaxScoreForSchool !== undefined ? Strad.scoreAndMaxScoreForSchool : [];
        //SchoolData = SchoolData.slice(Current_Nav_Left, Current_Nav_Right);

        let ClassData = Strad.scoreAndMaxScoreForClass !== undefined ? Strad.scoreAndMaxScoreForClass : [];
        //ClassData = ClassData.slice(Current_Nav_Left, Current_Nav_Right);

        let StandardsData = Strad.summaryList !== undefined ?
            Strad.summaryList.length > 0 ?
                Strad.summaryList[0].standardAndStrandVODetails : [] : [];

        let totalStandardsLength = StandardsData.length

        let showArrows = StandardsData.length > 10 ? true : false

        StandardsData = Strad.summaryList !== undefined ? StandardsData : [];

        let DistrictAvg = Summary_Prop.DistrictAvg;
        let SchoolAvg = Summary_Prop.SchoolAvg;
        let ClassAvg = Summary_Prop.ClassAvg;

        let DisableLeftNav = Current_Nav_Left <= 0;
        let DisableRightNav = Current_Nav_Right >= Summary_Prop.navigation.TotalNavClount;
        let Pagination = Summary_Prop.Pagination;

        let ListToDisplay = Summary_Prop.List.summaryList !== undefined && Summary_Prop.List.summaryList !== null ?
            Summary_Prop.List.summaryList : [];

        let ContextHeaderDetails = this.props.ContextHeader.Roster_Tab;
        let HeaderDetails = this.props.ContextHeader;

        let fromContext = this.props.fromContext;

        let CheckBox = Summary_Prop.CheckBox;
        let rows = [];
        for (let i = 0; i < Math.floor(totalStandardsLength); i = i + 8) {
            let sliced_standards_data = StandardsData.slice(i, i + 8)
            let ClassData_Sliced = ClassData.slice(i, i + 8)
            let SchoolData_Sliced = SchoolData.slice(i, i + 8)
            let DistrictData_Sliced = DistrictData.slice(i, i + 8)
            const row = (
                <div className="AllSummary_print_pdf">
                    <div className="AllSummary_student_contex_comparison_print_header1">
                        <div className="AllSummary_print_pdf_header">
                            <div className="AllSummary_print_pdf_logo">
                                <img src={beclogo} width="105" height="28" />
                            </div>
                            <div className="AllSummary_print_pdf_head_text">

                            </div>
                        </div>
                        <div className="AllSummary_print_pdf_context_header">
                            <div className="AllSummary_print_pdf_header_row">
                                <ul>
                                    {Nav.student ? <li className="pdf_class_name">
                                        <span>
                                            <b>Student</b> : {(ContextHeaderDetails.SelectedStudent.name !== undefined) ? ContextHeaderDetails.SelectedStudent.name : ""}
                                        </span>
                                    </li> : ""}
                                    {Nav.class && ContextHeaderDetails.SelectedStudent !== "All" ? <li className="pdf_class_name">
                                        <span>
                                            <b>Students</b> : {(ContextHeaderDetails.SelectedStudent !== undefined) ?
                                                typeof ContextHeaderDetails.SelectedStudent == "object" ?
                                                    ContextHeaderDetails.SelectedStudent.name : ContextHeaderDetails.SelectedStudent : null}
                                        </span>
                                    </li> : ""}
                                    {(Nav.student || Nav.class) ? <li className="pdf_class_name">
                                        <span>
                                            <b>Class</b> : <span className={Nav.class ? "print_pdf_current_context_color" : ""}>{ContextHeaderDetails.SelectedClass.name}</span>
                                        </span>
                                    </li> : null}
                                    {(Nav.student || Nav.class || Nav.school) ? <li className="pdf_grade">
                                        <span>
                                            <b>Teacher</b> : {ContextHeaderDetails.SelectedTeacher == "All" ? "All" : ContextHeaderDetails.TeacherIds.length > 1 ? "Custom(" + ContextHeaderDetails.TeacherIds.length + ")" : ContextHeaderDetails.SelectedTeacher.name}
                                        </span>
                                    </li> : null}
                                    {Nav.district && (ContextHeaderDetails.SchoolIds.length !== ContextHeaderDetails.schoolsList.length) ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : <span>Custom ({ContextHeaderDetails.SchoolIds.length})</span>

                                        </span>
                                    </li> : null}
                                    <li className="pdf_class_name">
                                        <span>
                                            <b>Grade</b> : {convertGrade(ContextHeaderDetails.selectedRosterGrade)}
                                        </span>
                                    </li>
                                    {(Nav.district === false) ? <li className="pdf_teacher_name">
                                        <span>
                                            <b>School</b> : <span className={Nav.school ? "print_pdf_current_context_color" : ""}>{ContextHeaderDetails.SelectedSchool.name}</span>

                                        </span>
                                    </li> : null}


                                    {(Nav.school || Nav.district) ? <li className="pdf_district_name topdistrict_name">
                                        <span>
                                            <b>District</b> : <span className={Nav.district ? "print_pdf_current_context_color" : ""}>{ContextHeaderDetails.SelectedDistrict.name}</span>
                                        </span>
                                    </li> : null}
                                    {(Nav.district) ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Tests</b> : {HeaderDetails.tests}
                                        </span>
                                    </li> : null}
                                    {Nav.district && (ContextHeaderDetails.SchoolIds.length == ContextHeaderDetails.schoolsList.length) ? <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}

                                            {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                                        </span>
                                    </li> : null}
                                </ul>
                            </div>
                            <div className="AllSummary_print_pdf_header_row">
                                <ul>
                                    {(Nav.class) ? <li className="pdf_district_name topdistrict_name">
                                        <span>
                                            <b>District</b> : {ContextHeaderDetails.SelectedDistrict.name}
                                        </span>
                                    </li> : null}
                                    {(Nav.class || Nav.school) ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Tests</b> : {HeaderDetails.tests}
                                        </span>
                                    </li> : null}
                                    {Nav.student ? <li className="pdf_tests_name">
                                        <span>
                                            <b>Test</b> : {HeaderDetails.tests}
                                        </span>
                                    </li> : null}
                                    {(!Nav.district) ? <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}

                                            {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                                        </span>
                                    </li> : null}

                                    {/* <li className="pdf_assessed_dates">
                        <span>
                            <b>Assessed With </b> : {this.props.selectedTestAssessment}+ Questions
                        </span> 
                    </li>*/}
                                    {Nav.district && (ContextHeaderDetails.SchoolIds.length != ContextHeaderDetails.schoolsList.length) ? <li className="pdf_dates">
                                        <span>
                                            <b>Dates</b> : {displayLocalTimeInPDFContextHeaderBasedOnFlag(HeaderDetails)}

                                            {/* {startDateStringArray2[1]+"/"+startDateStringArray2[2]+"/"+startDateStringArray2[0]}  { HeaderDetails.Date_Tab.Report_termStartDate != HeaderDetails.Date_Tab.Report_termEndDate ? "- " + endDateStringArray2[1]+"/"+endDateStringArray2[2]+"/"+endDateStringArray2[0] : null } */}
                                        </span>
                                    </li> : null}
                                    {(Nav.school || Nav.district) ? <li className="pdf_testdata_assessed_for">
                                        <span>
                                            <b>Test Data Assessed for Grade </b> :

                                             {convertGrade(this.props.TestGrade)}
                                        </span>
                                    </li> : null}
                                    {(Nav.school || Nav.district) ? <li className="pdf_class_name">
                                        <span>
                                            <b>View</b> : {this.props.View}
                                        </span>
                                    </li> : null}
                                </ul>

                            </div>
                            {(Nav.class) ? <div className="AllSummary_print_pdf_header_row" style={{ borderTop: "1px solid #9B9B9B", borderBottom: "none" }}>
                                <ul>
                                    {(Nav.class) ? <li className="pdf_testdata_assessed_for">
                                        <span>
                                            <b>Test Data Assessed for Grade </b> : {convertGrade(this.props.TestGrade)}
                                        </span>
                                    </li> : null}
                                    <li className="pdf_class_name">
                                        <span>
                                            <b>View</b> : {this.props.View}
                                        </span>
                                    </li>
                                </ul>
                            </div> : null}
                        </div>
                    </div>

                    {/* body start */}

                    <div className="AllSummary_print_pdf_body">
                        <div className="AllSummary_print_pdf_body_middle">
                            <div className="AllSummary_print_pdf_header_title">
                                <div className="AllSummary_print_pdf_header_title_block">
                                    <div className="AllSummary_print_pdf_header_title_block_left"><span className="AllSummary_print_pdf_dimond_symbol"></span>Average</div>
                                    <div className="Summary_print_pdf_header_title_block_createdBy AllSummary_createdByCenter">
                                        <b>Created by:</b> {HeaderDetails.LoggedInUserName}
                                    </div>
                                    <div className="AllSummary_print_pdf_header_title_block_right"><b>Date Created:</b> <span className="AllSummary_fontstyle">{this.getCurrentDate()}</span></div>
                                </div>
                            </div>
                            <div className="AllSummary_print_main">
                                <div className="AllSummary_GroupingBy_main_Center">
                                    <div className="AllSummary_print_Select_levels">
                                        <div style={{ width: '100%', margin: '0 auto', maxWidth: '1037px' }}>
                                            <div className="bec_compare_tab_compare_label">
                                                <SummaryCheckboxesPDF SCheckbox={CheckBox} Navselection={Nav} />
                                            </div>
                                        </div>
                                    </div>


                                </div>


                            </div>
                            {/* start */}
                            <div className="AllSummary_Strands_Standards_header">
                                <div className="AllSummary_strandName">
                                    Standards<span className="AllSummary_strandName_count">(<span style={{ fontWeight: "500" }}>{(i + 8 > totalStandardsLength) ? ((i + 1) + "-" + (totalStandardsLength) + " out of " + totalStandardsLength) : (i + 1) + "-" + (i + 8) + " out of " + totalStandardsLength}</span>)
                    </span></div>
                                <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                                    {this.ReturnStrandards(sliced_standards_data, DataSortOn, SortOrder, SortStandard)}

                                </div>

                            </div>
                            {/* Strands Comparison start */}
                            <div className="bec_compare_multi_list_sub_block_compare">

                                {CheckBox.district ? this.DistrictAverage(Nav, DistrictData_Sliced, DistrictAvg) : null}
                                {CheckBox.school ? this.SchoolAverage(Nav, SchoolData_Sliced, SchoolAvg) : null}
                                {CheckBox.class ? this.ClassAverage(Nav, ClassData_Sliced, ClassAvg) : null}


                            </div>
                            {/* Strands Comparson end */}


                            <div className="AllSummary_print_Main_Table_Header_middle">
                                {/* <div className="AllSummary_serialNumb">
                    
                    </div> */}
                                <div className="AllSummary_NumberOFStudents_Groups">
                                    <span className="bec_group_multi_list_sub_header_label_title" style={{ float: "left", fontWeight: "bold" }}>
                                        {Nav.student ? "Student" : null}
                                        {Nav.class ? `Students (${(ListToDisplay.length > 0 ? (ListToDisplay.length + "/" + HeaderDetails.Roster_Tab.StudentsList.length) : 0)})` : null}
                                        {Nav.school ? `Class (${(ListToDisplay.length > 0 ? (ListToDisplay.length + "/" + HeaderDetails.Roster_Tab.ClassList.length) : 0)})` : null}
                                        {Nav.district ? `Schools (${(ListToDisplay.length > 0 ? (ListToDisplay.length + "/" + HeaderDetails.Roster_Tab.schoolsList.length) : 0)})` : null}
                                    </span>
                                    <span className="bec_compare_multi_list_toggler" style={{ position: "relative", top: "4px" }}>
                                        {(DataSortOn == "onname" && SortOrder == "asc") ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null}
                                        {(DataSortOn == "onname" && SortOrder == "desc") ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null}

                                    </span>

                                </div>
                                <div className="AllSummary_avaerageScore">
                                    <span className="AllSummary_bec_group_multi_list_sub_header_avg_score_label">
                                        <div>
                                            <b>Average % Score</b>

                                        </div>
                                        <div style={{ fontSize: '7px' }}>
                                        </div>
                                    </span>
                                    <span className="bec_compare_multi_list_toggler">
                                        {DataSortOn == "onAverageScore" && SortOrder == "asc" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null}
                                        {DataSortOn == "onAverageScore" && SortOrder == "desc" ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null}

                                    </span>
                                </div>
                                <div className="bec_compare_multi_list_sub_header_strands_list" style={{ width: "660px" }}>

                                    {sliced_standards_data.map((vals, index) => {
                                        return <div className="bec_compare_multi_list_sub_header_strands_single">
                                            <div className="bec_compare_multi_list_sub_header_strands_single_sort" style={{ position: "relative", top: "8px" }}>
                                                {(DataSortOn == "onStandardScore" && SortOrder == "asc" && SortStandard == (vals.standardAndStrandName) ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_less</i> : null)}
                                                {(DataSortOn == "onStandardScore" && SortOrder == "desc" && SortStandard == (vals.standardAndStrandName) ? <i className="material-icons" style={{ fontSize: "14px" }}>expand_more</i> : null)}
                                            </div>
                                        </div>
                                    })}
                                </div>
                            </div>

                            {/* end */}
                        </div>
                    </div>

                    {/* body end */}

                    <div style={{ width: '100%', maxWidth: '1037px', margin: '0 auto' }}>

                        {ListToDisplay.map((Values, j) =>
                            <div className="AllSummary_groups no-page-break">
                                <div className="AllSummary_student_list AllSummary_fontstyle">
                                    <div className="serial_num"> {j + 1} </div>
                                    <div className="student_name" style={{ textAlign: "left" }}>{Nav.district ? (Values.schoolName) : (Nav.school ? Values.className : Values.firstName + " " + Values.lastName)}</div>
                                    <div className="student_average_score">
                                        <div className={`color_circle_avaerage ${(Nav.district ? Values.schoolPercentage : (Nav.school ? Values.classPercentage : Values.studentPercentage)) != null ? colorCodes(Nav.district ? Values.schoolPercentage : (Nav.school ? Values.classPercentage : Values.studentPercentage), this.props.AchivementLevels) : "bec_group_multi_list_grey"}`}>{Nav.district ? Values.schoolPercentage : (Nav.school ? Values.classPercentage : Values.studentPercentage)}</div></div>
                                    <div style={{ float: 'left', width: '660px', display: 'flex' }}>
                                        {/* Start */}
                                        {Values.standardAndStrandVODetails.slice(i, i + 8).map(Values => <div className="bec_compare_multi_list_Single_compare_body_row_strand_score">
                                            <div className="AllSummary_bec_compare_single_score_inr_middle">

                                                <div className="student_standard_strand">
                                                    <div class={`standard_strand_score ${Values.standardAndStrandAvg != null ? colorCodes(Values.standardAndStrandAvg, this.props.AchivementLevels) : "color_circle_avaerage_grey"}`}>{Values.standardAndStrandAvg != null ? Values.standardAndStrandAvg : '-'}</div>
                                                    <div className="AllSummary_Question_number"> {Values.noOfQuestions != null ? "No.QA:" : null} {(Values.noOfQuestions != null) ? Values.noOfQuestions : "No Data"}</div>
                                                </div>
                                            </div>
                                        </div>
                                        )}

                                        {/* End */}
                                    </div>
                                </div>
                            </div>
                        )}

                    </div>
                    <div className={Nav.student ? "" : ""}> <div className="AllSummary_print_footer">
                        <div className="AllSummary_print_footer_inr">
                            <div className="AllSummary_print_footer_left">
                                <div className="AllSummary_print_footer_left_title">Achievement Levels:</div>
                                <div className="AllSummary_print_footer_left_color_blocks">
                                    <ul>
                                        <li>
                                            <div className="AllSummary_print_footer_color_single_block">
                                                <div className="AllSummary_print_footer_color_stripe red" style={{ background: "#FF5B5B" }}></div>
                                                <div className="AllSummary_print_footer_color_text ">&lt; {this.props.AchivementLevels && this.props.AchivementLevels[0]['label']}%</div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="AllSummary_print_footer_color_single_block">
                                                <div className="AllSummary_print_footer_color_stripe orange" style={{ background: "#FF8E2D" }}></div>
                                                <div className="AllSummary_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[1]['label']}%</div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="AllSummary_print_footer_color_single_block">
                                                <div className="AllSummary_print_footer_color_stripe yellow" style={{ background: "#FFC52D" }}></div>
                                                <div className="AllSummary_print_footer_color_text">{this.props.AchivementLevels && this.props.AchivementLevels[2]['label']}%</div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="AllSummary_print_footer_color_single_block">
                                                <div className="AllSummary_print_footer_color_stripe green" style={{ background: "#32AC41" }}></div>
                                                <div className="AllSummary_print_footer_color_text"><span className=" ar_pdf_greaterthensymbol_font">&ge;</span>{this.props.AchivementLevels && this.props.AchivementLevels[3]['label']}%</div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="AllSummary_print_footer_right">
                                <div className="AllSummary_print_footer_na_block" style={{ float: "right" }}>
                                    <span className="AllSummary_print_footer_na_img">No. QA</span>
                                    <span className="AllSummary_print_footer_na_text" style={{ fontSize: "12px" }}>
                                        Number of Questions Assessed
        </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <div class="page-break-after">&nbsp;</div>
                </div>

            )
            rows.push(row);


        }

        return (<table style={{ border: "none" }} className="AllSummary_print_pdf_table">
            <thead>
                <tr>
                    <td>
                        <div className="AllSummary_print_header_space">&nbsp;</div>
                    </td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>

                        <div className="student_context_content">{rows}</div>
                    </td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td>
                        <div className="AllSummary_print_footer_space">&nbsp;</div>
                    </td>
                </tr>
            </tfoot>
        </table>)
    }
}

class AllSummaryPDF extends React.Component {
    constructor(props) {
        super(props);
        this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
    }

    componentDidMount() {
        this.autoTriggerFunction()
    }
    componentDidUpdate() {
        this.autoTriggerFunction()
    }

    autoTriggerFunction(e) {
        let Nav = this.props.NavigationByHeaderSelection        
        let selectedContextData = Nav.class ? this.props.classBatchPrint : Nav.student ? this.props.studentBatchPrint : null
        let selectedData = selectedContextData != null ? Nav.summary ? selectedContextData.summaryData : null : null;
        if ((Nav.student || Nav.class) && (selectedData != null) && (selectedData.triggerPDF === true)) {
            let context = Nav.student? "student":"class";
            document.getElementById('printIcon').click();
            this.props.resetTriggerPDF() 
            this.props.trackingUsage(`assessmentreports_standardperformanceaveragepdf:${context}`)    
        }
    }
    render() {
        let {NavigationByHeaderSelection}= this.props;
        let context= "district";
        if(NavigationByHeaderSelection.school)
        {
        context = "school";
        }    

        return (
            <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon" id="printIcon"><img src={printIco} onClick={()=> this.props.trackingUsage(`assessmentreports_standardperformanceaveragepdf:${context}`)} width="21" /></span>}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        ref={el => (this.componentRef = el)}
                        SummaryDataProp={this.props.SummaryDataProp}
                        NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
                        ContextHeader={this.props.ContextHeader}
                        DistrictAvg={this.props.DistrictAvg}
                        SchoolAvg={this.props.SchoolAvg}
                        ClassAvg={this.props.ClassAvg}
                        View={this.props.View}
                        fromContext={this.props.fromContext}
                        TestGrade={this.props.TestGrade}
                        AchivementLevels={this.props.AchivementLevels}
                    />
                </div>
            </div>
        )
    }
}

const mapStateToProps = ({ Universal, Reports, BatchPrintReducer }) => {
    const { AchivementLevels, ContextHeader, NavigationByHeaderSelection } = Universal
    const { StandardPerformance_Overview } = Reports;
    const { classBatchPrint, studentBatchPrint } = BatchPrintReducer
    return {
        AchivementLevels, ContextHeader, NavigationByHeaderSelection, StandardPerformance_Overview,
        classBatchPrint, studentBatchPrint
    };
}

const MapActionToProps = {
    Comparison_Popup,
    EditComparison_Popup,
    SortComparisonBasedOnParam,
    navigationArrowsStandardComparison,
    comparisonCurrentPageClick,
    resetTriggerPDF,
    trackingUsage
}

export default connect(mapStateToProps, MapActionToProps)(AllSummaryPDF);

function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }

}