import React, { Component } from 'react';
import './SummaryCheckboxesPDF.css'
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
class SummaryCheckboxesPDF extends Component {
    constructor(props) {
        super(props);
    }
    // updateCompareActive() {
    //     this.setState({
    //         updatedCompareActive: true
    //     });
    // }

    // addClass(compareActiveFor) {
    //     this.setState({ compareActiveFor });
    // }

    render() {

        let NavigationSelection = this.props.Navselection;
        let SCheckbox = this.props.SCheckbox;
   
        return (
            <div className={NavigationSelection.student?"Summary_pdf_Comparison_print_main":"Allsummary_pdf_remove_margin"}>
            <div className="summary_pdf_comparison_block text-center">
                <ul className="summary_pdf_comparison_block-ul-list">

                    <li className="summary_pdf_comparison_title">Compare:</li>
                    {
                        NavigationSelection.student || NavigationSelection.class ?<li className={this.props.lastcheckedlabel === "Class" ?  "summary_pdf_compareCheckBoxesSingleUI pdf_class-compare compare_pdf_activeCompare" : "summary_pdf_compareCheckBoxesSingleUI compare_pdf_class-compare"}>
                    
                    {SCheckbox.class?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                    {/* <label className={SCheckbox.class ? "summary_pdf_compare-checkbox Summary_pdf_activeComparePDF" : "summary_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className="summary_pdf_compare_title">Class</span>
                        </li>
                        :null
                    }

                    {
                        NavigationSelection.student || NavigationSelection.class || NavigationSelection.school ? <li className={this.props.lastcheckedlabel === "School" ? "summary_pdf_compareCheckBoxesSingleUI compare_pdf_school-compare compare_pdf_activeCompare" : "summary_pdf_compareCheckBoxesSingleUI compare_pdf_school-compare"}>
                        
                        {SCheckbox.school?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        {/* <label className={SCheckbox.school ? "summary_pdf_compare-checkbox Summary_pdf_activeComparePDF" : "summary_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className="summary_pdf_compare_title">School</span>
                    </li>:null
                    }

                    {
                        NavigationSelection.student || NavigationSelection.class || NavigationSelection.school || NavigationSelection.district ?<li className={this.props.lastcheckedlabel === "District" ? "summary_pdf_compareCheckBoxesSingleUI compare_pdf_district-compare compare_pdf_activeCompare" : "summary_pdf_compareCheckBoxesSingleUI compare_district-compare"}>
                        {SCheckbox.district?<img src={print_checkbox_selected} className="compare_img_sizes"/>:<img src={print_checkbox_unselected} className="compare_img_sizes"/>}
                        {/* <label className={SCheckbox.district ? "summary_pdf_compare-checkbox Summary_pdf_activeComparePDF" : "summary_pdf_compare-checkbox"}>
                            <i class="fa fa-check" aria-hidden="true"></i>
                        </label> */}
                        <span className="summary_pdf_compare_title">District</span>
                    </li>:null
                    }

                </ul>
            </div >
            </div>
        );
    }
}

export default SummaryCheckboxesPDF;