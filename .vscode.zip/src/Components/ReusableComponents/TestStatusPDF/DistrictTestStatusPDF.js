import React from 'react';
import ReactToPrint from 'react-to-print';
import printIco from '../../../../public/images/ic_print_new.svg';
import beclogo from '../../../../public/images/bec-logo.svg';
import { connect } from "react-redux";
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
import testStatusSortingUp from '../../../../public/images/testStatusSortingUp.svg';
import testStatusSortingDown from '../../../../public/images/testStatusSortingDown.svg';
import { resetTestStatusTriggerPDF } from '../../../Redux_Actions/TestStatusPrintActions';
import { PortraitOrientation } from '../PortraitOrientation';
import { convertUTCDateToLocalDate, displayLocalTimeInPDFContextHeaderBasedOnFlag, userTimeZoneDate } from '../AllReusableFunctions';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../Utils/globalVars';
import { newDateHandling } from '../AllReusableFunctions_Two';
class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
    }
    getCurrentDate(separator='/'){

      let newDate = new Date()
      let date = newDate.getDate();
      let month = newDate.getMonth() + 1;
      let year = newDate.getFullYear();
      
      return `${month<10?`0${month}`:`${month}`}${separator}${date}${separator}${year}`
      }
    colorCodes(score) {
        switch (true) {
            case (score < 40):
                return "color_circle_avaerage_red";
            case (score >= 40 && score <= 59):
                return "color_circle_avaerage_orange";
            case (score >= 60 && score <= 79):
                return "color_circle_avaerage_yellow";
            case (score >= 80):
                return "color_circle_avaerage_green"
            default:
                return "color_circle_avaerage_grey";
        }
    }


    render() {
        let ContextHeader = this.props.ContextHeader;
        const Nav = this.props.NavigationByHeaderSelection;
        let Roster_Tab = this.props.ContextHeader.Roster_Tab;
        const {SortStatus, SortStatus_Type, StatusDetail} = this.props.TestStatusReducer.District;
        const { testStatusLevel, PdfData , reportLevel } = this.props.districtTestStatusPrint;
        const { SortField, SortType } = StatusDetail;
        let selectedData = [];
        testStatusLevel.testStatusLevelList_temp.map((statusCode)=>{
          if(statusCode.check){
       selectedData.push(statusCode.reportLevelName);
      }
      })

      let radioButtunData = reportLevel.reportSelected_temp;
      let DetailsData = (typeof PdfData.testDataDetails !== undefined && PdfData.testDataDetails !== null)?PdfData.testDataDetails:null;
return(<div className="testStatusPDFClass">
  <div className="testStatusPDFClassInr">
    {/* top header */}
    <div className="testStatusPDFClass_header">
      <div className="testStatusPDFClass_logo">
      <img src={beclogo} width="105" height="28" />
      </div>
      <div className="testStatusHeaderRight">
  <div className="testStatusHeaderRight_top">
    <span>Test Status</span>
  </div>
  <div>
    <div className="testStatusHeaderRight_bottom_createdBy">
      <b>Created by:</b> {ContextHeader.LoggedInUserName}
    </div>
    <div className="testStatusHeaderRight_bottom_Date">
      <b>Date:</b> {this.getCurrentDate()}
    </div>
  </div>
</div>
    </div>
    {/* top header end */}
    {/* context header */}
    <div className="testStatusPDFClass_context_header">
      <div className="testStatusPDFClass_header_row">
        <ul>
        {Nav.district && (Roster_Tab.SchoolIds.length !== Roster_Tab.schoolsList.length) ?<li className="testStatusPDFClass_teacher_name">
            <span>
              <b>School</b>: <span>Custom ({Roster_Tab.SchoolIds.length})</span>
            </span>
          </li>:null}
          <li className="testStatusPDFClass_class_name">
            <span>
              <b>Grade</b>: {convertGrade(Roster_Tab.selectedRosterGrade)}
            </span>
          </li>
          
            <li className="testStatusPDFClass_district_name">
            <span>
              <b>District</b>: <span style={{color:"#1964A5"}}>{Roster_Tab.SelectedDistrict.name}</span>
            </span>
          </li>
          <li className="testStatusPDFClass_tests_name">
            <span>
              <b>Tests</b>: {ContextHeader.tests}
            </span>
          </li>
          {Nav.district && (Roster_Tab.SchoolIds.length === Roster_Tab.schoolsList.length) ?<li className="testStatusPDFClass_dates">
            <span>
              <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(ContextHeader)}
            </span>
          </li>:null}
          </ul>
      </div>
      {Nav.district && (Roster_Tab.SchoolIds.length !== Roster_Tab.schoolsList.length) ?<div className="testStatusPDFClass_header_row">
        <ul>
        <li className="testStatusPDFClass_dates">
            <span>
           <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(ContextHeader)}
            </span>
          </li>
          </ul>
          </div>:null}
      <div className="testStatusPDFClass_header_row_filter">
                <ul>
                  <li>
                    <b>Filters:</b>
                  </li>
                        <li key={10} style={{display:"flex"}}><img src={print_checkbox_selected} width={16}/><b style={{marginLeft:"5px"}}>{(radioButtunData ==="summary")?"Summary":"Detail"}</b></li>
                          {selectedData.map((name,key) =>
                        <li key={key} style={{display:"flex"}}>
                        <img src={print_checkbox_selected} width={16}/>
                        <b style={{marginLeft:"5px"}}>{name}</b>
                        </li>
                      )}
                  </ul>
              </div>
    </div>
    {/* context header end */}
    {/* breadcrumb start */}
    {/* <div className="testStatusPDFClass_breadCrumbs">
              <div className="testStatusPDFClass_breadCrumbs_inr">
                <div className="testStatusPDFClass_header_breadcrumb_name">
                  <span className="testStatusPDFClass_dimond_symbol" /> Assessments | Test
                  Status
                </div>
                <div className="testStatusPDFClass_header_createdBy">
                  <b>Created by:</b> {ContextHeader.LoggedInUserName}
                </div>
                <div className="testStatusPDFClass_header_createdOn">
                  <b>Date Created:</b> {this.getCurrentDate()}
                </div>
              </div>
            </div> */}
    {/* breadcrumb end */}
    {/* breadcrumb start */}
    <div className="testStatusPDFClass_note">
      <div className="testStatusPDFClass_note_inr">
        <div className="testStatusPDFClass_header_note_context">
          <b>Note:</b> Students who have taken a test more than once will be
          repeated in the test status results.
        </div>
      </div>
    </div>
    {/* breadcrumb end */}
    <div className="testStatusBody">
      <div className="testStatusBody_inr">
        <div className="testStatusBody_inr_main">
         
          {(radioButtunData ==="summary")?
          <div>
          <div className="testStatus_body_head_left">
              <div className="testStatus_body_head_left_inr" style={{border:"none"}}>
                <div className="testStatusPDFClassTitle"><b>Summary</b></div>
              </div>
              </div>
        <table cellpadding="8" style={{borderCollapse:"collapse"}}>
          <thead>
          <tr style={{width:'940'}}>
              <td style={{width:"600px"}} cellpadding="0">
              <div className="testStatus_body_head_left">
              <div className="testStatus_body_head_left_inr" style={{height:"64px"}}>
                <div className="testStatusPDFClassTitle"></div>
              </div>
              </div>
              </td>
              <td style={{width:"480px"}} colSpan="4" cellpadding="0">
              <div className="testStatus_body_head_right">
              <div className="testStatus_body_head_right_inr">
                <div className="testStatus_body_student_ts_name"><b>Student Test Status</b></div>
              </div>
              </div>
              </td>
          </tr>
              <tr style={{width:'940'}}>
              <th style={{width:"600px"}}  cellpadding="0">
              <div className="testStatus_body_subhead_left_title">
    <b>Test Name</b> <span className="testStatusFontQuestrial" style={{fontWeight:"400"}}>{PdfData.testStatusSummary.tests.length>0?"("+PdfData.testStatusSummary.tests.length+")":null}
      </span>
    </div>
                </th>
                {selectedData.includes("Not Started")?<th style={{width:"120px"}} cellpadding="0">
                      <div className="testStatus_body_subhead_single_status testStatus_body_subhead_not_started">
                        <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders">Not Started</span>
             
                        </div>
                        <div className="testStatus_body_subhead_status_label_indicator" />
                      </div>
                    </th>:null}
                    {selectedData.includes("In Progress")?<th style={{width:"120px"}} cellpadding="0">
                      <div className="testStatus_body_subhead_single_status testStatus_body_subhead_in_progress">
                        <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders">In Progress</span>
              
                        </div>
                        <div className="testStatus_body_subhead_status_label_indicator" />
                      </div>
                    </th>:null}
                    {selectedData.includes("Needs to Be Graded")?<th style={{width:"120px"}} cellpadding="0">
                      <div className="testStatus_body_subhead_single_status testStatus_body_subhead_need_graded">
                        <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders" style={{textAlign:"left",position:"relative",top:"-7px"}}>Needs to Be Graded</span>
              
                        </div>
                        <div className="testStatus_body_subhead_status_label_indicator" />
                      </div>
                    </th>:null}
                    {selectedData.includes("Complete")?<th style={{width:"120px"}} cellpadding="0">
                      <div className="testStatus_body_subhead_single_status testStatus_body_subhead_complete">
                        <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders">Complete</span>
              
                        </div>
                        <div className="testStatus_body_subhead_status_label_indicator" />
                      </div>
                    </th>:null}
            </tr>
            </thead>
            <tbody style={{borderBottom:"2px solid #D0D6E1"}}>
            <tr  style={{width:"940px",borderRadius: "2px",background:"#F3F5FA",lineHeight: 1,borderBottom:"2px solid #D0D6E1"}}>
<td className="testStatus_body_count_strip_left" style={{ position:"relative"}}>
                <span><b style={{fontFamily:"Quicksand"}}>Total Students</b></span>
                <span className="testStatusPDFSortingArrows">{SortStatus === "testTitle" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg"/>:null}
              {SortStatus === "testTitle" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
               </span>
              </td>
              {selectedData.includes("Not Started")?<td style={{textAlign:"center", position:"relative"}}>
                      <div className="testStatus_body_count_strip__single_count" style={{color:"#000"}}>
                        {PdfData.testStatusSummary.totalNotStartedCount}
                      </div>
                      <span className="testStatusPDFSortingArrows">
              {SortStatus === "not-started" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "not-started" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg" />:null}
              </span>
                    </td>:null}
                    {selectedData.includes("In Progress")?<td style={{textAlign:"center", position:"relative"}}>
                      <div className="testStatus_body_count_strip__single_count" style={{color:"#000"}}>
                     {PdfData.testStatusSummary.totalInProgressCount}
                      </div>
                      <span className="testStatusPDFSortingArrows">
              {SortStatus === "in-progress" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "in-progress" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg" />:null}
               </span>
                    </td>:null}
                    {selectedData.includes("Needs to Be Graded")?<td style={{textAlign:"center", position:"relative"}}>
                      <div className="testStatus_body_count_strip__single_count" style={{color:"#000"}}>
                     {PdfData.testStatusSummary.totalNeedsToBeGradedCount}
                      </div>
                      <span className="testStatusPDFSortingArrows">
              {SortStatus === "need-tobe-graded" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "need-tobe-graded" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg" />:null}
               </span>
                    </td>:null}
                    {selectedData.includes("Complete")?<td style={{textAlign:"center", position:"relative"}}>
                      <div className="testStatus_body_count_strip__single_count" style={{color:"#000"}}>
                     {PdfData.testStatusSummary.totalCompleteCount}
                      </div>
                      <span className="testStatusPDFSortingArrows">
              {SortStatus === "completed" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "completed" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg" />:null}
               </span>
                    </td>:null}
</tr>
       {(typeof PdfData.testStatusSummary.tests !== undefined &&  PdfData.testStatusSummary !==null && PdfData.testStatusSummary.tests.length>0)?
            TestNames(PdfData.testStatusSummary.tests, selectedData)
            :null}
            </tbody>
          </table></div>:(typeof DetailsData !== undefined && DetailsData !== null && DetailsData.data !== null?detailsBlockData(PdfData.testDataDetails,selectedData,this.props.TestStatusReducer.District):null)}
          
           
        </div>
      </div>
    </div>
  </div>
</div>
)
    }
}

class DistrictTestStatusPDF extends React.Component {
    constructor(props) {
        super(props);
        this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
      
    }
    componentDidMount(){
     this.autoTriggerFunction()
    }
    componentDidUpdate(){
    this.autoTriggerFunction()
    }

    autoTriggerFunction(e){
        document.getElementById('printIcon').click();
        if(this.props.districtTestStatusPrint.triggerPDF){
        this.props.resetTestStatusTriggerPDF("district");
        }
    }
    render() {

   
        return (
            <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon" id="printIcon" ><img src={printIco} width="21" /></span>} // style={{display:"none"}}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                  <PortraitOrientation />
                    <ComponentToPrint
                    ref={el => (this.componentRef = el)}
                    NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
                    ContextHeader={this.props.ContextHeader}
                    TestStatusReducer={this.props.TestStatusReducer}
                    districtTestStatusPrint={this.props.districtTestStatusPrint}// this.props.TestStatusReducer.Student.List
                    />
                </div>
            </div>
        )
    }
}
const mapStateToProps = ({ Universal, TestStatusReducer, TestStatusPrintReducer }) => {
    const { ContextHeader, NavigationByHeaderSelection } = Universal
    const { districtTestStatusPrint } = TestStatusPrintReducer
    return {
        ContextHeader, NavigationByHeaderSelection, TestStatusReducer , districtTestStatusPrint
    };
}

const MapActionToProps = {
  resetTestStatusTriggerPDF
}
export default connect(mapStateToProps,MapActionToProps)(DistrictTestStatusPDF);
function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }
  
  }

  const TestNames = (DataArray, selectedData) => {

    return DataArray.map((item, index) =>
<tr className="testStatusLastChildBorderNone">
<td style={{width:"350px"}}>
                  <div className="testStatus_body_data_singleRow_number" style={{color:"#000"}}>{index+1}</div>
                  <div className="testStatus_body_data_singleRow_testName" style={{color:"#000"}}>
                  {item.testTitle == null || item.testTitle == "null" ? "-":item.testTitle}
                  </div>
</td>

                {selectedData.includes("Not Started")?<td className="testStatus_body_data_singleRow_status" style={{width:"120px",textAlign:"center",color:"#0F0C04"}}>{item.notStartedCount == null || item.notStartedCount == "null" ? "-":item.notStartedCount}</td>:null}
                {selectedData.includes("In Progress")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}} className="testStatus_body_data_singleRow_status">{item.inProgressCount == null || item.inProgressCount == "null" ? "-":item.inProgressCount}</td>:null}
                {selectedData.includes("Needs to Be Graded")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}} className="testStatus_body_data_singleRow_status">{item.needsToBeGradedCount == null || item.needsToBeGradedCount == "null" ? "-":item.needsToBeGradedCount}</td>:null}
                {selectedData.includes("Complete")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}} className="testStatus_body_data_singleRow_status">{item.completedCount == null || item.completedCount == "null" ? "-":item.completedCount}</td>:null}

            </tr>
           

        )

}


// details block
export function detailsBlockData(testDataDetails,selectedData,reportLevelClassData){

  const {StatusDetail} = reportLevelClassData
  const {selectedTest ,SortField, SortType} = StatusDetail
 // let dataToLoop = testDataDetails.data; // testDataDetails[`${selectedTest.testTitle}`]
 let dataToLoop = custom_sort(testDataDetails.data, SortField, SortType);
 let name = null;
   let groupedData = groupBy(dataToLoop,"testStatus")
  let detailsListData = selectedData.map((statusname,key) => {
    if(statusname === "Needs to Be Graded"){
      name = "Needs ToBe Graded"
      }else{
        name = statusname;
      }
    let noOfStudents = 0;
    if(groupedData[name] != undefined || groupedData[name] != null){
      for (let i = 0; i < groupedData[name].length; i++) {
        noOfStudents += groupedData[name][i].count
      }
    }
    return groupedData[`${name}`] != undefined ? <React.Fragment>
    
      <tr style={{width:"940px",background: '#F3F5FA'}}>
        <td><span style={{fontWeight:800}} ><b>{name}</b></span></td>
<td style={{textAlign:"center"}}>{noOfStudents}</td>
<td colSpan="3"></td>
      </tr>

        {DetailsList(groupedData[name], SortField, SortType)}
        

  </React.Fragment>:null
  }

)


  return (<div className="testStatus_body_details">
  <div className="testStatus_body_details_inr">
<div className="testStatus_body_details_title">Detail</div>
<div className="testStatus_body_details_body">
  <div className="testStatus_body_details_body_inr">
    {/* start block */}
    <div className="testStatusPDFClass_details_single">
      <div className="testStatusPDFClass_details_single_header">
        <div className="testStatusPDFClass_details_single_sno">1</div>
        <div className="testStatusPDFClass_details_single_title_block">
          <div className="testStatusPDFClass_details_single_title">
            <b>{testDataDetails.testName}</b>
          </div>
            </div>
      </div>
      <div className="testStatusPDFClass_details_single_body">
        <div className="testStatusPDFClass_details_single_body_inr">
          <table cellpadding="8" style={{borderCollapse:"collapse"}}>
            <thead style={{background:"#D0D6E1",width:940}}>
            <th style={{width:"330px", textAlign:"left",position:"relative",fontWeight:"800"}}>
              <span style={{float:"left"}}>School</span>
              <span  style={{marginLeft:"4px"}}>
        {SortField === "schoolName" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "schoolName" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            <th style={{width:"180px",textAlign:"center",fontWeight:"800"}}>
              No. of Students
            </th>
            <th style={{width:"140px",textAlign:"center",position:"relative",fontWeight:"800"}}>
            <span style={{float:"left"}}>Start Date</span>
              <span  style={{marginLeft:"4px"}}>
        {SortField === "startDate" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "startDate" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            <th style={{width:"120px",textAlign:"center",position:"relative",fontWeight:"800"}}>
            <span style={{float:"left"}}>Due Date</span>
              <span style={{marginLeft:"4px"}}>
        {SortField === "dueDate" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "dueDate" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            <th style={{width:"190px",position:"relative",fontWeight:"800"}}>
            <span style={{float:"left"}}>Submit Date</span>
              <span style={{marginLeft:"4px",position:"absolute"}}>
        {SortField === "submissionDate" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "submissionDate" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            </thead>
            <tbody>
            {detailsListData}
            </tbody>
          </table>
                 
          </div>
      </div>
    </div>
    
  </div>
</div>
</div>
</div>)
}
function DetailsList(DataArray, SortStatus, SortStatus_Type){
  let allNames = DataArray.map((e,index) => {
    return <tr className="testStatusLastChildBorderNone">
        <td  style={{width:"330px"}} className="testStatusPDFClassDetailFont">
         <span className="testStatus_body_data_singleRow_number">
          {index+1}
          </span>
          <span className="testStatus_body_data_singleRow_testName">
            {e.schoolName}
            </span>
        </td>
        <td style={{width:"180px",textTransform:"uppercase",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {e.count}
        </td>
        <td  style={{width:"140px",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(e.startDate,e.startTime): e.startDate}
        
        </td>
        <td  style={{width:"120px",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {e.dueDate == null || (e.dueDate == "null") ? "-" :userTimeZoneDate(e.dueDate,e.dueTime)}
       
        </td>
        <td  style={{width:"190px",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {(e.testStatus === "In Progress" || e.testStatus === "Not Started")?"NA":(DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(e.submissionDate,"00:00:00"):e.submissionDate)}
       
        </td>

    </tr>
})

return allNames;

}
const groupBy = (array, key) => {
  return array.reduce((result, currentValue) => {
    (result[currentValue[key]] = result[currentValue[key]] || []).push(
      currentValue
    );
    return result;
  }, {});
};
export function custom_sort(DataArray,SortField, SortType){
  let Arr = [];
  if(SortField == "schoolName"){
  Arr = DataArray.sort(function(a,b){
    return   SortType==="desc"? a.schoolName.localeCompare( b.schoolName): -( a.schoolName.localeCompare(  b.schoolName));
  })
  return Arr; 
}
else if(SortField == 'StartDate' || SortField == 'DueDate' || SortField == 'SubmissionDate'){
  Arr = (SortType==="asc")?DataArray.sort(function(a, b) {
    let dateA = newDateHandling(a.SortField), dateB = newDateHandling(b.SortField);
    return dateA - dateB;
}):DataArray.sort(function(a, b) {
  let dateA = newDateHandling(a.SortField), dateB = newDateHandling(b.SortField);
  return dateB - dateA;
});
return Arr;
}else{
  return DataArray;

}
}