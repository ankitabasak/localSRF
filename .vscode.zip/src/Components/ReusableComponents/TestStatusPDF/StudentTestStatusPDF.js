import React from 'react';
import ReactToPrint from 'react-to-print';
import printIco from '../../../../public/images/ic_print_new.svg';
import beclogo from '../../../../public/images/bec-logo.svg';
import ts_ic_not_started from '../../../../public/images/ts_ic_not_started.svg';
import ts_ic_in_progress from '../../../../public/images/ts_ic_in_progress.svg';
import ic_grading_print from '../../../../public/images/ic_grading_print.svg';
import ts_ic_completed from '../../../../public/images/ts_ic_completed.svg';
import print_checkbox_unselected from '../../../../public/images/print_checkbox_unselected.svg';
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
import testStatusSortingUp from '../../../../public/images/testStatusSortingUp.svg';
import testStatusSortingDown from '../../../../public/images/testStatusSortingDown.svg';
import { connect } from "react-redux";
import './StudentTestStatusPDF.css'
import { resetTestStatusTriggerPDF } from '../../../Redux_Actions/TestStatusPrintActions';
import { PortraitOrientation } from '../PortraitOrientation';
import { convertUTCDateToLocalDate, displayLocalTimeInPDFContextHeaderBasedOnFlag, userTimeZoneDate } from '../AllReusableFunctions';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../Utils/globalVars';
class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
    }
    getCurrentDate(separator='/'){

      let newDate = new Date()
      let date = newDate.getDate();
      let month = newDate.getMonth() + 1;
      let year = newDate.getFullYear();
      
      return `${month<10?`0${month}`:`${month}`}${separator}${date}${separator}${year}`
      }
    colorCodes(score) {
        switch (true) {
            case (score < 40):
                return "color_circle_avaerage_red";
            case (score >= 40 && score <= 59):
                return "color_circle_avaerage_orange";
            case (score >= 60 && score <= 79):
                return "color_circle_avaerage_yellow";
            case (score >= 80):
                return "color_circle_avaerage_green"
            default:
                return "color_circle_avaerage_grey";
        }
    }


    render() {
        var ContextHeader = this.props.ContextHeader;
        const Nav = this.props.NavigationByHeaderSelection;
        var Roster_Tab = this.props.ContextHeader.Roster_Tab;
        const {filteredData, StatusCodes, SortStatus, SortStatus_Type} = this.props.TestStatusReducer.Student;
        const { testStatusLevel,PdfData } = this.props.studentTestStatusPrint;
        let selectedData = [];
        testStatusLevel.testStatusLevelList_temp.map((statusCode)=>{
          if(statusCode.check){
       selectedData.push(statusCode.reportLevelName);
      }
      })
return(<div className="testStatusPDF">
<div className="testStatusPDFInr">
  {/* top header */}
  <div className="testStatusPDF_header">
    <div className="testStatusPDF_logo">
    <img src={beclogo} width="105" height="28" />
    </div>
    <div className="testStatusHeaderRight">
  <div className="testStatusHeaderRight_top">
    <span>Test Status</span>
  </div>
  <div>
    <div className="testStatusHeaderRight_bottom_createdBy">
      <b>Created by:</b> {ContextHeader.LoggedInUserName}
    </div>
    <div className="testStatusHeaderRight_bottom_Date">
      <b>Date:</b> {this.getCurrentDate()}
    </div>
  </div>
</div>

  </div>
  {/* top header end */}
  {/* context header */}
  <div className="testStatusPDF_context_header">
    <div className="testStatusPDF_header_row">
      <ul>
      <li className="testStatusPDF_class_name">
          <span>
            <b>Student</b>: <span style={{color:"#1964A5"}}> {(Roster_Tab.SelectedStudent.name !== undefined)?Roster_Tab.SelectedStudent.name:""}</span>
          </span>
        </li>
        <li className="testStatusPDF_class_name">
          <span>
            <b>Class</b>: {Roster_Tab.SelectedClass.name}
          </span>
        </li>
        <li className="testStatusPDF_grade">
          <span>
            <b>Teacher</b>: {Roster_Tab.SelectedTeacher == "All" ? "All":Roster_Tab.TeacherIds.length > 1 ?"Custom("+Roster_Tab.TeacherIds.length+")": Roster_Tab.SelectedTeacher.name}
          </span>
        </li>
        <li className="testStatusPDF_class_name">
          <span>
            <b>Grade</b>: {convertGrade(Roster_Tab.selectedRosterGrade)}
          </span>
        </li>
        <li className="testStatusPDF_teacher_name">
          <span>
            <b>School</b>: {Roster_Tab.SelectedSchool.name}
          </span>
        </li>
        
        
      </ul>
    </div>
    <div className="testStatusPDF_header_row">
      <ul>
      <li className="testStatusPDF_district_name">
          <span>
            <b>District</b>: {Roster_Tab.SelectedDistrict.name}
          </span>
        </li>
        <li className="testStatusPDF_tests_name">
          <span>
            <b>Tests</b>: {ContextHeader.tests}
          </span>
        </li>
        <li className="testStatusPDF_dates">
          <span>
          <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(ContextHeader)}
          </span>
        </li>
      </ul>
    </div>
    <div className="testStatusPDF_header_row_filter">
      <ul>
        <li>
          <b>Filters:</b>
        </li>
        {selectedData.map((name,key) =>
        <li key={key} style={{display:"flex"}}>
        <img src={print_checkbox_selected} width={16}/>
        <b style={{marginLeft:"4px"}}>{name}</b>
        </li>
      )}
      </ul>
    </div>
  </div>
  {/* context header end */}
  {/* breadcrumb start */}
  {/* <div className="testStatusPDF_breadCrumbs">
    <div className="testStatusPDF_breadCrumbs_inr">
      <div className="testStatusPDF_header_breadcrumb_name">
        <span className="testStatusPDF_dimond_symbol" /> Assessments | Test
        Status
      </div>
      <div className="testStatusPDF_header_createdBy">
        <b>Created by:</b> {ContextHeader.LoggedInUserName}
      </div>
      <div className="testStatusPDF_header_createdOn">
        <b>Date Created:</b> {this.getCurrentDate()}
      </div>
    </div>
  </div> */}
  {/* breadcrumb end */}
  {/* footer start */}
  <div className="testStatusStudent_footer">
          <div className="testStatusStudent_footer_inr">
            <div className="testStatusStudent_footer_centerBox">
              <ul>
                <li key={1}>
                  <span className="testStatusStudent_footer_icon">
                  <img src={ts_ic_not_started} width="12"  style={{marginTop:"2px"}}/>
                  </span>
                  <span className="testStatusStudent_footer_name">
                    Not Started
                  </span>
                </li>
                <li key={2}>
                  <span className="testStatusStudent_footer_icon">
                  <img src={ts_ic_in_progress} width="12" style={{marginTop:"2px"}}/>
                  </span>
                  <span className="testStatusStudent_footer_name">
                    In Progress
                  </span>
                </li>
                <li key={3}>
                  <span className="testStatusStudent_footer_icon">
                  <img src={ic_grading_print} width="12" style={{marginTop:"2px"}}/>
                  </span>
                  <span className="testStatusStudent_footer_name">
                    Needs to Be Graded
                  </span>
                </li>
                <li key={4}>
                  <span className="testStatusStudent_footer_icon">
                  <img src={ts_ic_completed} width="12" style={{marginTop:"2px"}}/>
                  </span>
                  <span className="testStatusStudent_footer_name">
                    Complete
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      
  {/* footer end */}

  <div className="testStatusPDFBody">
    <div className="testStatusBody_inr">
      <div className="testStatusBody_inr_main">
        <table className="StudentTestStatusTable" cellPadding="3px" style={{ borderCollapse: "collapse", border: 0 }}>
        <thead style={{ borderBottom: "2px solid #D0D6E1",borderTop:"2px solid #D0D6E1" }}> 
        <th style={{ width: 380,padding:'5px 0' }}
            >
              <span className="testStatusStudent_inrSpan">
        <b>Test Name</b> <span style={{fontWeight:"400"}}>{PdfData.length>0?"("+PdfData.length+")":null}</span>
        <span style={{marginLeft:"4px"}}>{SortStatus === "assignmentName" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "assignmentName" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
               </span>
              </span>
              
            </th>
            <th style={{ width: 100,padding:'5px 0' }}
            >
              <span className="testStatusStudent_inrSpan testStatus_student_header_font">Test Status</span>
            
            </th>
            <th style={{ width: 180, textAlign: "left",padding:'5px 0' }}
            >
              <span className="testStatusStudent_inrSpan testStatus_student_header_font">Assignment</span>
  

            </th>
            <th style={{ width: 140,padding:'5px 0' }}
            >
              <span className="testStatusStudent_inrSpan testStatus_student_header_font">Start Date 
              <span style={{marginLeft:"4px"}}>{SortStatus === "startDate" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "startDate" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
               </span>
              </span>
            </th>
            <th style={{ width: 120,padding:'5px 0' }}
            >
              <span className="testStatusStudent_inrSpan testStatus_student_header_font">Due Date
              <span style={{marginLeft:"4px"}}>{SortStatus === "dueDate" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "dueDate" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
               </span>
              </span>
            </th>
            <th style={{ width: 110,padding:'5px 0' }}
            >
              <span className="testStatusStudent_inrSpan testStatus_student_header_font">Submit Date
              <span style={{marginLeft:"4px"}}>{SortStatus === "submissionDate" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
              {SortStatus === "submissionDate" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
               </span>
              </span>
            </th>
            
          </thead>
          <tbody className="StudentTestStatusTable">

          {(PdfData !=undefined && PdfData.length>0) ?TestNames(PdfData):null}
          </tbody>
        </table>
        
        {/* <div className="testStatusStudent_header">
          <div className="testStatusStudent_header_inr">
            

            
            
            
          </div>
        </div>
        <div className="testStatusStudent_body">
          <div className="testStatusStudent_body_inr">
              
              
            </div>
        </div> */}
        </div>
    </div>
  </div>
</div>
</div>
)
    }
}

class StudentTestStatusPDF extends React.Component {
    constructor(props) {
        super(props);
        this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
    }
    componentDidMount(){
      this.autoTriggerFunction()
    }
    componentDidUpdate(){
      this.autoTriggerFunction()
    }

    autoTriggerFunction(e){
        document.getElementById('printIcon').click();
        if(this.props.studentTestStatusPrint.triggerPDF){
        this.props.resetTestStatusTriggerPDF("student");
        }
    }
    render() {

   
        return (
            <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon" id="printIcon" ><img src={printIco} width="21" /></span>} // style={{display:"none"}}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                  <PortraitOrientation />
                    <ComponentToPrint
                    ref={el => (this.componentRef = el)}
                    NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
                    ContextHeader={this.props.ContextHeader}
                    TestStatusReducer={this.props.TestStatusReducer}
                    studentTestStatusPrint={this.props.studentTestStatusPrint}// this.props.TestStatusReducer.Student.List
                    />
                </div>
            </div>
        )
    }
}
const mapStateToProps = ({ Universal, TestStatusReducer, TestStatusPrintReducer }) => {
    const { ContextHeader, NavigationByHeaderSelection } = Universal
    const { studentTestStatusPrint } = TestStatusPrintReducer
    return {
        ContextHeader, NavigationByHeaderSelection, TestStatusReducer , studentTestStatusPrint
    };
}

const MapActionToProps = {
  resetTestStatusTriggerPDF
}
export default connect(mapStateToProps,MapActionToProps)(StudentTestStatusPDF);
function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }
  
  }
  const TestNames = (DataArray) => {

    return DataArray.map((item, index) =>
<tr style={{width:'1080px',padding:"5px 0"}}>
              <td style={{ width: 380,marginLeft:"25px",padding:'10px 9px' }}
              >
                <span className="testStatusStudent_body_sno">{index+1}</span>
                <span className="testStatusStudent_body_testName">
                {item.componentTitle == null || item.componentTitle == "null" ? "-":item.componentTitle}
                </span>
              </td>
              <td  style={{ width: 100,padding:'10px 0' }}>
               <div className={"testStatusStudent_body_status " + CheckStatus(item)}></div>
              </td>
              <td
                 style={{ width: 180 , textAlign:"left",padding:'10px 0' }}>
                {item.assignmentName == null || item.assignmentName == "null" ? "-":item.assignmentName}
              </td>
              <td  style={{ width:140,padding:'10px 0', textAlign:"center" }}>
              {item.startDate == null || item.startDate == "null" ? "-":(DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(item.startDate,item.startTime):item.startDate)}
              </td>
              <td  style={{ width: 120,padding:'10px 0', textAlign:"center" }}>
              {item.dueDate == null || item.dueDate == "null" ? "-":userTimeZoneDate(item.dueDate,item.dueTime)}
              </td>
              <td  style={{ width: 110,padding:'10px 0', textAlign:"center" }}>
              {(item.testStatus == "In Progress" || item.testStatus == "Not Started")?"NA":(item.submissionDate == null || item.submissionDate == "null" ? "-":(DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(item.submissionDate,"00:00:00"):item.submissionDate))}
              </td>
              
            </tr>
           

        )

}
function CheckStatus(item) {

    let status;

    if(item.testStatus == "Not Started"){
        status = "not-started"
    }else if(item.testStatus == "Needs ToBe Graded"){
        status = "need-tobe-graded"
    }else if(item.testStatus == "In Progress"){
        status = "in-progress"
    }else{
        status = "complete"
    }

    switch (status) {
        case 'not-started':
            return "statusIcon_not_started";
        case 'in-progress':
            return "statusIcon_in_progress";
        case 'need-tobe-graded':
            return "student_statusIcon_need_to_be_graded";//student_statusIcon_need_to_be_graded
        case 'complete':
            return "statusIcon_completed";
        default:
            return "not-applied-anything"
    }
}