import React from 'react';
import ReactToPrint from 'react-to-print';
import printIco from '../../../../public/images/ic_print_new.svg';
import beclogo from '../../../../public/images/bec-logo.svg';
import { connect } from "react-redux";
import './ClassTestStatusPDF.css'
import print_checkbox_selected from '../../../../public/images/print_checkbox_selected.svg';
import { resetTestStatusTriggerPDF } from '../../../Redux_Actions/TestStatusPrintActions';
import testStatusSortingUp from '../../../../public/images/testStatusSortingUp.svg';
import testStatusSortingDown from '../../../../public/images/testStatusSortingDown.svg';
import { PortraitOrientation } from '../PortraitOrientation';
import { convertUTCDateToLocalDate, displayLocalTimeInPDFContextHeaderBasedOnFlag, userTimeZoneDate } from '../AllReusableFunctions';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../Utils/globalVars';
class ComponentToPrint extends React.Component {
    constructor(props) {
        super(props);
    }
    getCurrentDate(separator='/'){

      let newDate = new Date()
      let date = newDate.getDate();
      let month = newDate.getMonth() + 1;
      let year = newDate.getFullYear();
      
      return `${month<10?`0${month}`:`${month}`}${separator}${date}${separator}${year}`
      }
    colorCodes(score) {
        switch (true) {
            case (score < 40):
                return "color_circle_avaerage_red";
            case (score >= 40 && score <= 59):
                return "color_circle_avaerage_orange";
            case (score >= 60 && score <= 79):
                return "color_circle_avaerage_yellow";
            case (score >= 80):
                return "color_circle_avaerage_green"
            default:
                return "color_circle_avaerage_grey";
        }
    }

    render() {
        var ContextHeader = this.props.ContextHeader;
        const Nav = this.props.NavigationByHeaderSelection;
        var Roster_Tab = this.props.ContextHeader.Roster_Tab;
        const {SortStatus_Type, SortStatus} = this.props.TestStatusReducer.Class;
        const { testStatusLevel, PdfData, reportLevel} = this.props.classTestStatusPrint;

        let selectedData = [];
        testStatusLevel.testStatusLevelList_temp.map((singleStatus)=>{
          if(singleStatus.check){
            selectedData.push(singleStatus.reportLevelName == "Needs to Be Graded" ? "Needs ToBe Graded":singleStatus.reportLevelName);
          }
        })
        let radioButtunData = reportLevel.reportSelected_temp;

        return(<div className="testStatusPDFClass">
          <div className="testStatusPDFClassInr">
            {/* top header */}
            <div className="testStatusPDFClass_header">
              <div className="testStatusPDFClass_logo">
              <img src={beclogo} width="105" height="28" />
              </div>
              <div className="testStatusHeaderRight">
  <div className="testStatusHeaderRight_top">
    <span>Test Status</span>
  </div>
  <div>
    <div className="testStatusHeaderRight_bottom_createdBy">
      <b>Created by:</b> {ContextHeader.LoggedInUserName}
    </div>
    <div className="testStatusHeaderRight_bottom_Date">
      <b>Date:</b> {this.getCurrentDate()}
    </div>
  </div>
</div>
            </div>
            {/* top header end */}
            {/* context header */}
            <div className="testStatusPDFClass_context_header">
              <div className="testStatusPDFClass_header_row">
                <ul>
                  <li className="testStatusPDFClass_class_name">
                    <span>
                      <b>Class</b>: <span style={{color:"#1964A5"}}>{Roster_Tab.SelectedClass.name}</span>
                    </span>
                  </li>
                  <li className="testStatusPDFClass_grade">
                    <span>
                      <b>Teacher</b>: {Roster_Tab.SelectedTeacher == "All" ? "All":Roster_Tab.TeacherIds.length > 1 ?"Custom("+Roster_Tab.TeacherIds.length+")": Roster_Tab.SelectedTeacher.name}
                    </span>
                  </li>
                  <li className="testStatusPDFClass_class_name">
                    <span>
                      <b>Grade</b>: {convertGrade(Roster_Tab.selectedRosterGrade)}
                    </span>
                  </li>
                  <li className="testStatusPDFClass_teacher_name">
                    <span>
                      <b>School</b>: {Roster_Tab.SelectedSchool.name}
                    </span>
                  </li>
                  
                </ul>
              </div>
              <div className="testStatusPDFClass_header_row">
                <ul>
                <li className="testStatusPDFClass_district_name">
                    <span>
                      <b>District</b>: {Roster_Tab.SelectedDistrict.name}
                    </span>
                  </li>
                  <li className="testStatusPDFClass_tests_name">
                    <span>
                      <b>Tests</b>: {ContextHeader.tests}
                    </span>
                  </li>
                  <li className="testStatusPDFClass_dates">
                    <span>
                    <b>Dates</b>: {displayLocalTimeInPDFContextHeaderBasedOnFlag(ContextHeader)}
                    </span>
                  </li>
                </ul>
              </div>
              <div className="testStatusPDFClass_header_row_filter">
                <ul>
                  <li>
                    <b>Filters:</b>
                  </li>
                        <li key={10} style={{display:"flex"}}><img src={print_checkbox_selected} width={16}/><b style={{marginLeft:"4px"}}>{(radioButtunData ==="summary")?"Summary":"Detail"}</b></li>
                          {selectedData.map((name,key) =>
                        <li key={key} style={{display:"flex"}}>
                        <img src={print_checkbox_selected} width={16}/>
                        <b style={{marginLeft:"4px"}}>{name}</b>
                        </li>
                      )}
                  </ul>
              </div>
            </div>
            {/* context header end */}
            {/* breadcrumb start */}
            {/* <div className="testStatusPDFClass_breadCrumbs">
              <div className="testStatusPDFClass_breadCrumbs_inr">
                <div className="testStatusPDFClass_header_breadcrumb_name">
                  <span className="testStatusPDFClass_dimond_symbol" /> Assessments | Test
                  Status
                </div>
                <div className="testStatusPDFClass_header_createdBy">
                  <b>Created by:</b> {ContextHeader.LoggedInUserName}
                </div>
                <div className="testStatusPDFClass_header_createdOn">
                  <b>Date Created:</b> {this.getCurrentDate()}
                </div>
              </div>
            </div> */}
            {/* breadcrumb end */}
            {/* breadcrumb start */}
            <div className="testStatusPDFClass_note">
              <div className="testStatusPDFClass_note_inr">
                <div className="testStatusPDFClass_header_note_context">
                  <b>Note:</b> Students who have taken a test more than once will be
                  repeated in the test status results.
                </div>
              </div>
            </div>
            {/* breadcrumb end */}
            <div className="testStatusBody">
              <div className="testStatusBody_inr">
                <div className="testStatusBody_inr_main">

                     {radioButtunData == "summary" && (typeof PdfData.testStatusSummary.tests !== undefined && PdfData.testStatusSummary.tests !== null &&  PdfData.testStatusSummary.tests.length > 0) ? summaryBlockData(PdfData.testStatusSummary,selectedData,this.props.TestStatusReducer.Class):PdfData.testDataDetails !=null ? detailsBlockData(PdfData.testDataDetails,selectedData,this.props.TestStatusReducer.Class):null}
               
                </div>
              </div>
            </div>
          </div>
        </div>
        )
    }
}

class ClasstestStatusPDFClass extends React.Component {
    constructor(props) {
        super(props);
        this.autoTriggerFunction = this.autoTriggerFunction.bind(this)
      
    }
    componentDidMount(){
      this.autoTriggerFunction()
    }
    componentDidUpdate(){
    this.autoTriggerFunction()
    }

    autoTriggerFunction(e){
        document.getElementById('printIcon').click();
        if(this.props.classTestStatusPrint.triggerPDF){
        this.props.resetTestStatusTriggerPDF("class");
        }
    }
    render() {

   
        return (
            <div>
                <ReactToPrint
                    trigger={() => <span className="printIcon" id="printIcon" ><img src={printIco} width="21" /></span>} // style={{display:"none"}}
                    content={() => this.componentRef}
                />
                <div style={{ display: "none" }}>
                  <PortraitOrientation />
                    <ComponentToPrint
                    ref={el => (this.componentRef = el)}
                    NavigationByHeaderSelection={this.props.NavigationByHeaderSelection}
                    ContextHeader={this.props.ContextHeader}
                    TestStatusReducer={this.props.TestStatusReducer}
                    classTestStatusPrint={this.props.classTestStatusPrint}
                    />
                </div>
            </div>
        )
    }
}
const mapStateToProps = ({ Universal, TestStatusReducer, TestStatusPrintReducer }) => {
    const { ContextHeader, NavigationByHeaderSelection } = Universal
    const { classTestStatusPrint } = TestStatusPrintReducer
    return {
        ContextHeader, NavigationByHeaderSelection, TestStatusReducer , classTestStatusPrint
    };
}

const MapActionToProps = {
  resetTestStatusTriggerPDF
}
export default connect(mapStateToProps,MapActionToProps)(ClasstestStatusPDFClass);
export function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return ``
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        return `${value2}`
    }
}

// Summary block
export function summaryBlockData(testStatusSummary,selectedData,reportLevelClassData){

  const {SortStatus_Type, SortStatus} = reportLevelClassData

  return (<div>
    <div className="testStatus_body_head_left">
            <div className="testStatus_body_head_left_inr" style={{border:"none",height:"13px"}}>
              <div className="testStatusPDFClassTitle"><b>Summary</b></div>
            </div>
        </div>
    <table cellpadding="8" style={{borderCollapse:"collapse"}}>
      <thead>
      <tr style={{width:'940'}}>
        <td style={{width:"600px"}} cellpadding="0">
        <div className="testStatus_body_head_left">
            <div className="testStatus_body_head_left_inr" style={{height:"64px"}}>
              <div className="testStatusPDFClassTitle"></div>
            </div>
        </div>
        </td>
        <td style={{width:"480px"}} colSpan="4" cellpadding="0">
        <div className="testStatus_body_head_right">
            <div className="testStatus_body_head_right_inr">
              <div className="testStatus_body_student_ts_name"><b>Student Test Status</b></div>
            </div>
        </div>
        </td>
      </tr>
      <tr style={{width:'940'}}>
        <th style={{width:"600px"}}  cellpadding="0">
        <div className="testStatus_body_subhead_left_title"><b>Test Name</b> <span className="testStatusPDFClassDetailFont" style={{fontWeight:"400"}}>{testStatusSummary.tests.length>0?"("+testStatusSummary.tests.length+")":null}
        
        </span>
        </div>
          </th>
          {selectedData.includes("Not Started")?<th style={{width:"120px"}} cellpadding="0">
                <div className="testStatus_body_subhead_single_status testStatus_body_subhead_not_started">
                <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders">Not Started</span>
             
                        </div>
                  <div className="testStatus_body_subhead_status_label_indicator" />
                </div>
              </th>:null}
              {selectedData.includes("In Progress")?<th style={{width:"120px"}} cellpadding="0">
                <div className="testStatus_body_subhead_single_status testStatus_body_subhead_in_progress">
                <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders">In Progress</span>
              
                        </div>
                  <div className="testStatus_body_subhead_status_label_indicator" />
                </div>
              </th>:null}
              {selectedData.includes("Needs ToBe Graded")?<th style={{width:"120px"}} cellpadding="0">
                <div className="testStatus_body_subhead_single_status testStatus_body_subhead_need_graded">
                <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders" style={{textAlign:"left",position:"relative",top:"-7px"}}>Needs to Be Graded</span>
              
                        </div>
                  <div className="testStatus_body_subhead_status_label_indicator" />
                </div>
              </th>:null}
              {selectedData.includes("Complete")?<th style={{width:"120px"}} cellpadding="0">
                <div className="testStatus_body_subhead_single_status testStatus_body_subhead_complete">
                <div className="testStatus_body_subhead_status_label classTestStatusHeaderLables">
                        <span className="testStatusRepeatedHeaders">Complete</span>
              
                        </div>

                  <div className="testStatus_body_subhead_status_label_indicator" />
                </div>
              </th>:null}
      </tr>
     
         
      </thead>
      <tbody className="testStatusPDFClassDetailFont">
      <tr style={{width:"940px",borderRadius: "2px",background:"#F3F5FA",lineHeight: 1,borderBottom:"2px solid #D0D6E1"}}>
        <td style={{position:"relative",background:"#F3F5FA"}}>
          <span><b>Total Students</b></span>
          <span className="testStatusPDFSortingArrows">{SortStatus === "testTitle" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortStatus === "testTitle" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
        </td>
        {selectedData.includes("Not Started")?<td style={{textAlign:"center",position:"relative",background:"#F3F5FA"}} className="testStatusPDFClassDetailFont">
               
            {testStatusSummary.totalNotStartedCount}
            <span className="testStatusPDFSortingArrows">
        {SortStatus === "not-started" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortStatus === "not-started" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
              </td>:null}
              {selectedData.includes("In Progress")?<td style={{textAlign:"center",position:"relative",background:"#F3F5FA"}} className="testStatusPDFClassDetailFont">
               
              {testStatusSummary.totalInProgressCount}
            <span className="testStatusPDFSortingArrows">
        {SortStatus === "in-progress" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortStatus === "in-progress" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
              </td>:null}
              {selectedData.includes("Needs ToBe Graded")?<td style={{textAlign:"center",position:"relative",background:"#F3F5FA"}} className="testStatusPDFClassDetailFont">
               
             {testStatusSummary.totalNeedsToBeGradedCount}
             <span className="testStatusPDFSortingArrows">
        {SortStatus === "need-tobe-graded" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortStatus === "need-tobe-graded" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
              </td>:null}
              {selectedData.includes("Complete")?<td style={{textAlign:"center",position:"relative",background:"#F3F5FA"}} className="testStatusPDFClassDetailFont">
              
              {testStatusSummary.totalCompleteCount}
              <span className="testStatusPDFSortingArrows">
        {SortStatus === "completed" && SortStatus_Type ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortStatus === "completed" && SortStatus_Type ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
              </td>:null}
        
        
        </tr>
        {TestNames(testStatusSummary.tests, selectedData)}
      </tbody>
    </table>
    {/* <div className="testStatus_body_head">
      <div className="testStatus_body_head_inr">
        <div className="testStatus_body_head_left">
          <div className="testStatus_body_head_left_inr"></div>
        </div>
        <div className="testStatus_body_head_right">
          <div className="testStatus_body_head_right_inr">
            Student Test Status
          </div>
        </div>
      </div>
    </div>
    <div className="testStatus_body_subhead">
      <div className="testStatus_body_subhead_inr">
        <div className="testStatus_body_subhead_left">
          
        </div>
        <div className="testStatus_body_subhead_right">
          <div className="testStatus_body_subhead_statuses">
            <ul>
            
              
              
              
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    <div className="testStatus_body_count_strip">
      <div className="testStatus_body_count_strip_inr">
        
        <div className="testStatus_body_count_strip_right">
          <div className="testStatus_body_count_strip_counts">
            <ul>
            
            </ul>
          </div>
        </div>
      </div>
    </div> */}
    <div className="testStatus_body_dataClass" style={{borderBottom:"2px solid #D0D6E1"}}>
     
    </div>
    </div>)

}

export function getAllAssignmentsList(dataToLoop){

  let allAssignments = []
  dataToLoop.map((e,index) => (
    allAssignments.push({
      assignmentID:e.assignmentID,
      assignmentName:e.assignmentName
    })
  ))
  allAssignments = getUnique(allAssignments,'assignmentID')
  allAssignments.map((singleAssn,index) => {
    singleAssn.charCode = assignDynNames(index)
  })

  return allAssignments;

}

const groupBy = (array, key) => {
  return array.reduce((result, currentValue) => {
    (result[currentValue[key]] = result[currentValue[key]] || []).push(
      currentValue
    );
    return result;
  }, {});
};

// details block
export function detailsBlockData(testDataDetails,selectedData,reportLevelClassData){

  const {StatusDetail} = reportLevelClassData
  const {selectedTest ,SortField, SortType} = StatusDetail
  let dataToLoop = testDataDetails.data; // testDataDetails[`${selectedTest.testTitle}`]
  let All_AssignmentsList = getAllAssignmentsList(dataToLoop)
  let groupedData = groupBy(dataToLoop,"testStatus")
  let detailsListData = selectedData.map((name,key) => {
    return groupedData[`${name}`] !==undefined ? <React.Fragment>
    
      <tr style={{width:"940px",background: '#F3F5FA'}}>
        <td colSpan="5" style={{background:"#F3F5FA"}}><span style={{fontWeight:800}} ><b>{name}</b></span> <span className="testStatusFontQuestrial" style={{fontWeight:"400"}}>({groupedData[`${name}`].length})</span></td>
      </tr>

        {DetailsList(groupedData[name], All_AssignmentsList,SortField, SortType)}

  </React.Fragment>:""
  }

)


  return (<div className="testStatus_body_details">
  <div className="testStatus_body_details_inr">
<div className="testStatus_body_details_title">Detail</div>
<div className="testStatus_body_details_body">
  <div className="testStatus_body_details_body_inr">
    {/* start block */}
    <div className="testStatusPDFClass_details_single">
      <div className="testStatusPDFClass_details_single_header">
        {/* <div className="testStatusPDFClass_details_single_sno">1</div> */}
        <div className="testStatusPDFClass_details_single_title_block">
          <div className="testStatusPDFClass_details_single_title">
            <b>{selectedTest.testTitle}</b>
          </div>
          {All_AssignmentsList.map((singleAssn,index)=>{
            return <div className="testStatusPDFClass_details_single_assnmt_a" style={{float:"left"}}>
            <span style={{fontWeight:"700"}}>Assignment  <span style={{textTransform:"uppercase"}}>{singleAssn.charCode}</span>:</span> <span className="testStatusPDFClassDetailFont">{singleAssn.assignmentName} {index != (All_AssignmentsList.length-1) ? ", " : ''} </span>
            </div>
          })}
        </div>
      </div>
      <div className="testStatusPDFClass_details_single_body">
        <div className="testStatusPDFClass_details_single_body_inr">
          <table cellpadding="8" style={{borderCollapse:"collapse"}}>
            <thead style={{background:"#D0D6E1",width:940}}>
            <th style={{width:"350px", textAlign:"left",fontWeight:"800"}}>
              Student <span style={{fontWeight:"400"}}>({dataToLoop.length})</span>
            </th>
            <th style={{width:"180px",textAlign:"center",fontWeight:"800"}}>
              Assignment
            </th>
            <th style={{width:"120px",textAlign:"center",position:"relative",fontWeight:"800"}}>
              Start Date
              <span  style={{top:"9px", position:"absolute",marginLeft:"4px"}}>
        {SortField === "startDate" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "startDate" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            <th style={{width:"120px",textAlign:"center",position:"relative",fontWeight:"800"}}>
              Due Date
              <span style={{top:"9px", position:"absolute",marginLeft:"4px"}}>
        {SortField === "dueDate" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "dueDate" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            <th style={{width:"190px",position:"relative",fontWeight:"800"}}>
              Submit Date
              <span style={{top:"9px", position:"absolute",marginLeft:"4px"}}>
        {SortField === "submissionDate" && SortType ==="desc"?<img src={testStatusSortingDown} width="10" className="testStatusSortingImg" />:null}
        {SortField === "submissionDate" && SortType ==="asc"?<img src={testStatusSortingUp} width="10" className="testStatusSortingImg"/>:null}
        </span>
            </th>
            </thead>
            <tbody>
            {detailsListData}
            </tbody>
          </table>
                 
          </div>
      </div>
    </div>
    
  </div>
</div>
</div>
</div>)
}

const TestNames = (DataArray, selectedData) => {

    return DataArray.map((item, index) =>
    <tr className="testStatusLastChildBorderNone">
           
                <td style={{width:"350px"}}>
                  <div className="testStatus_body_data_singleRow_number">{index+1}</div>
                  <div className="testStatus_body_data_singleRow_testName">
                                  {item.testTitle == null || item.testTitle == "null" ? "-":item.testTitle}
                                  </div>
                </td>
                 {selectedData.includes("Not Started")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}} >{item.notStartedCount == null || item.notStartedCount == "null" ? "-":item.notStartedCount}</td>:null}
                 {selectedData.includes("In Progress")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}}>{item.inProgressCount == null || item.inProgressCount == "null" ? "-":item.inProgressCount}</td>:null}
                  {selectedData.includes("Needs ToBe Graded")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}}>{item.needsToBeGradedCount == null || item.needsToBeGradedCount == "null" ? "-":item.needsToBeGradedCount}</td>:null}
                  {selectedData.includes("Complete")?<td style={{width:"120px",textAlign:"center",color:"#0F0C04"}}>{item.completedCount == null || item.completedCount == "null" ? "-":item.completedCount}</td>:null}

            </tr>
           

        )

}
export function getUnique(arr, index) {

  const unique = arr
       .map(e => e[index])

       // store the keys of the unique objects
       .map((e, i, final) => final.indexOf(e) === i && i)

       // eliminate the dead keys & store unique objects
      .filter(e => arr[e]).map(e => arr[e]);      

   return unique;
}

export function assignDynNames(n) {
  let ordA = 'a'.charCodeAt(0);
  let ordZ = 'z'.charCodeAt(0);
  let len = ordZ - ordA + 1;
  
  let s = "";
  while(n >= 0) {
      s = String.fromCharCode(n % len + ordA) + s;
      n = Math.floor(n / len) - 1;
  }
  return s;
}

function DetailsList(DataArray, All_AssignmentsList ,SortStatus, SortStatus_Type){
  let allNames = DataArray.map((e,index) => {
    return <tr className="testStatusLastChildBorderNone">
        <td  style={{width:"350px"}} className="testStatusPDFClassDetailFont">
         <span style={{marginRight:"25px"}}>
          {index+1}
          </span>
          <span>
            {e.studentName}
            </span>
        </td>
        <td style={{width:"180px",textTransform:"uppercase",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {All_AssignmentsList.filter(assnCode => assnCode.assignmentID === e.assignmentID)[0].charCode}
        </td>
        <td  style={{width:"120px",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(e.startDate,e.startTime):e.startDate}
        
        </td>
        <td  style={{width:"120px",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {e.dueDate == null || (e.dueDate == "null") ? "-" :userTimeZoneDate(e.dueDate,e.dueTime)}
       
        </td>
        <td  style={{width:"190px",textAlign:"center"}} className="testStatusPDFClassDetailFont">
        {(e.testStatus === "In Progress" || e.testStatus === "Not Started")?"NA":(DISPLAY_LOCAL_TIME_IN_UI == true?convertUTCDateToLocalDate(e.submissionDate,"00:00:00"):e.submissionDate)}
       
        </td>

    </tr>
})

return allNames;

}