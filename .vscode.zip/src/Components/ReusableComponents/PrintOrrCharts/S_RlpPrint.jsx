import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import StudentRlpChart from '../../ORR/ReadingLevelProgressComponents/S_RlpChart.jsx';
import './Charts.css';
import SummaryPrint from '../../../../public/assets/orr/rlp-screen/print-solid.svg';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2500px',
                    paddingLeft: '0px',
                    paddingRight: '0px',
                    minHeight: '668px',
                    background: '#ffff'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"Student | Reading Level Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <StudentRlpChart sRlpChart={this.props.StudentRlpChartData}
                                        svgHeight={this.props.svgHeight}
                                        yAlign={this.props.yAlign}
                                        xAlign={this.props.xAlign}
                                        radius1={this.props.radius1}
                                        radius2={this.props.radius2}
                                        yBubleAlign={this.props.yBubleAlign}
                                        yScaleAlign={this.props.yScaleAlign}
                                        xTickAlign={this.props.xTickAlign}
                                        isPrint={this.props.isPrint} />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintS_RLP extends Component {
    render() {
        return (
            <div>
                {this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={SummaryPrint}
                                    width="20"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                {!this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={Print}
                                    width="24"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        StudentRlpChartData={this.props.StudentRlpChartData}
                        ref={el => (this.componentRef = el)}
                        summaryFlag={this.props.summaryFlag}
                        svgHeight={this.props.svgHeight}
                        yAlign={this.props.yAlign}
                        xAlign={this.props.xAlign}
                        radius1={this.props.radius1}
                        radius2={this.props.radius2}
                        yBubleAlign={this.props.yBubleAlign}
                        yScaleAlign={this.props.yScaleAlign}
                        isPrint={this.props.isPrint}
                        xTickAlign={this.props.xTickAlign}
                    />
                </div>
            </div>
        );
    }
}

export default PrintS_RLP;