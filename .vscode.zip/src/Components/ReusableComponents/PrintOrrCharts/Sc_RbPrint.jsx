import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
// import School_RB_Chart from '../../School_ORR/School_RB_Components/School_RB_Chart.jsx';
import SchoolRBSidePanel from '../../School_ORR/School_RB_Components/School_RB_SidePanel.jsx'
import OrrFooter from './OrrFooter.jsx';
import SchoolEaGrid from './Sc_EaSidepanel.jsx'
import SCRbChartPrint from './Sc_RbChart_Print.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        let sidePanelData = this.props.schoolData;
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '40px',
                    paddingRight: '40px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view scrb-print" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"School | Reading Behaviors Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />
                        <tbody>
                            <tr>
                                <td>
                                    <div className="mt-10" style={{ marginTop: '10px', marginLeft: '20px' }}>
                                        <div>
                                            <div className="scrb-print-reading-level-text scRb-rb-22-20">Reading Behavior</div>
                                            <SCRbChartPrint
                                                chartAccordionState={this.props.chartAccordionState}
                                                data={this.props.data}
                                                gradeSelected={this.props.gradeSelected}
                                                selectedRB={this.props.selectedRB}
                                            />

                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                        <OrrFooter />
                    </table>
                </div>
                {/* <br /><br /> */}
                <div className="scRb-tr-22-20">
                    <div className="pull-left rt-left-heading scRb-heading-28-20" style={{
                        paddingTop: '40px'
                    }}>
                        <span>
                            Grade: {sidePanelData.externalFilter['grade']}
                        </span>
                    </div>
                    {/* <hr className="clearfix mb-8" /> */}
                    <div className="Readingtarget-graph txt-lft-28-20">
                        <div className="chart-details mb-10">
                            <div className="reading-level-label mb-8 color-1">
                                First Record Date Range:
                                <span> {sidePanelData['selectedRecordTypeDetails'].firstRecordDateRange}</span>
                            </div>
                            <div className="reading-level-label color-1">
                                Recent Record Date Range:
                                <span> {sidePanelData['selectedRecordTypeDetails'].recentRecordDateRange}</span>
                            </div>
                        </div>
                    </div>

                    <div
                        className="pull-right clearfix scRb-rostered-28-20"
                        style={{ marginBottom: "4px" }}
                    >
                        <span style={{ fontSize: "12px", fontWeight: "500" }}>
                            No. of students rostered: {sidePanelData['selectedRecordTypeDetails'].noOfStudentsRoastered}
                        </span>
                    </div>
                    {sidePanelData.schoolRBSidePanelGridData &&
                        <SchoolEaGrid
                            schGridData={sidePanelData.schoolRBSidePanelGridData}
                            scRbFlag={true}
                        />}
                    {/* Table end */}
                </div>
            </div>
        );
    }
}

class PrintScRb extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}

                        chartAccordionState={this.props.chartAccordionState}
                        data={this.props.data}
                        gradeSelected={this.props.gradeSelected}
                        selectedRB={this.props.selectedRB}

                        schoolData={this.props.schoolData}
                        sortData={this.props.sortData}
                        selectedLevels={this.props.selectedLevels}
                        accordionState={this.props.accordionState}
                        sidePanelApiFailed={this.props.sidePanelApiFailed}
                        scrollFlag={this.props.scrollFlag}
                    />
                </div>
            </div>
        );
    }
}

export default PrintScRb;