import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import SchoolFluencyProgressChart from '../../School_ORR/School_Fluency_Components/SchoolFpotComponents/school-fluency-progress-chart.jsx';
import SchoolFpotGrid from '../../School_ORR/School_Fluency_Components/SchoolFpotComponents/school-fluency-progress.jsx'
import SchoolFawcpmGrid from './Sch_FawcpmSidePanel.jsx';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"School | Fluency Progress Over Time Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <SchoolFluencyProgressChart
                                        scFaPot={true}
                                        firstRecord={this.props.firstRecord}
                                        allRecord={this.props.allRecord}
                                        recentRecord={this.props.recentRecord}
                                        errorRange={this.props.errorRange}
                                        showHideRecentRecord={
                                            this.props.showHideRecentRecord
                                        }
                                        SelectedErr={this.props.SelectedErr}
                                        showRecord={this.props.showRecord}
                                        gradeList={this.props.gradeList}
                                        selGrade={this.props.selGrade}
                                    />

                                </td>
                            </tr>
                            {/* <tr>
                                <td>
                                    <SchoolFpotGrid
                                        scrollFlag={this.props.scrollFlag}
                                        fpotSidePanelResponse={
                                            this.props.fpotSidePanelResponse
                                        }
                                        fpotSidePanelData={this.props.fpotSidePanelData.fpotSidePanelData}
                                        Data={this.props.fpotSidePanelData.SortData}
                                        panelData={this.props.fpotSidePanelData.SfpotGridData}
                                        disableDiv={this.props.fpotSidePanelData.disableDiv}
                                    />
                                </td>
                            </tr> */}
                        </tbody>
                    </table>
                    <br />
                    <br />
                    <div className="scFaFpot-rhs-wrap-28-20" style={{
                        paddingTop: '40px'
                    }}>
                        {/* onclick and on load main api should send the Reading target */}
                        <div className="pull-left rt-left-heading  scFaFpot-heading-28-20">
                            {this.props.fpotSidePanelResponse.selectedRecordTypeDetails.recordTitle}
                        </div>
                        <div className="pos-rel">
                            <div className="rt-rhs-strip"></div>
                            {/* <hr className="clearfix mb-8" /> */}
                        </div>
                        <div className="mb-10 txt-lft-28-20">
                            <div className="reading-level-label mb-8 color-1">
                                First Record Date Range:
                            <span> {
                                    this.props.fpotSidePanelResponse.selectedRecordTypeDetails
                                        .firstRecordDateRange
                                }
                                </span>
                            </div>
                            <div className="reading-level-label color-2">
                                Recent Record Date Range:
                            <span> {
                                    this.props.fpotSidePanelResponse.selectedRecordTypeDetails
                                        .recentRecordDateRange
                                }
                                </span>
                            </div>
                        </div>
                        <div className="pull-right clearfix new-mb-4 rt-label-txt scFaFpot-rostered-22-20">
                            <span className="rt-label">
                                No. of students rostered:
                            <span> {
                                    this.props.fpotSidePanelResponse.selectedRecordTypeDetails
                                        .noOfStudentsRoastered
                                }
                                </span>
                            </span>
                        </div>
                        {this.props.fpotSidePanelData.fpotSidePanelData &&
                            <SchoolFawcpmGrid
                                schGridData={this.props.fpotSidePanelData.fpotSidePanelData}
                            />
                        }
                    </div>
                </div >

                {/* Table end */}
            </div >
        );
    }
}

class PrintScFpot extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}

                        scrollFlag={this.props.scrollFlag}
                        firstRecord={this.props.firstRecord}
                        allRecord={this.props.allRecord}
                        recentRecord={this.props.recentRecord}
                        errorRange={this.props.errorRange}
                        showHideRecentRecord={
                            this.props.showHideRecentRecord
                        }
                        SelectedErr={this.props.SelectedErr}
                        showRecord={this.props.showRecord}
                        gradeList={this.props.gradeList}
                        selGrade={this.props.selGrade}
                        fpotSidePanelResponse={
                            this.props.fpotSidePanelResponse
                        }
                        fpotSidePanelData={this.props.fpotSidePanelData}
                    // Data={this.props.Data}
                    // panelData={this.props.panelData}
                    // disableDiv={this.props.disableDiv}


                    />
                </div>
            </div>
        );
    }
}

export default PrintScFpot;