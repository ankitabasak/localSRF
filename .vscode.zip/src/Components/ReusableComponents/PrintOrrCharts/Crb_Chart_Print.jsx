import React, { Component } from "react";

class Crb_Chart_Print extends Component {
    constructor(props) {
        super(props);
    }
    componentDidMount(props) {
        if (this.props.data && this.props.data.length > 0) {
            let id = this.props.data[0]["sourceRubricId"];

            this.setState({
                ...this.state,
                // accordionSelected: this.props.data.length - 1
            });
        }
    }

    isSelected(item) {
        let listItems = this.props.selectedRB[item["rbType"]];
        let style = { color: "#333333" };
        if (listItems && listItems.length > 0) {
            listItems.forEach((obj, idx) => {
                if (
                    obj.sourceCriteriaId == item.sourceCriteriaId &&
                    obj.criteriaName == item.criteriaName &&
                    obj.selectedRanges == item.selectedRanges
                ) {
                    style = { color: "white", backgroundColor: "rgb(0, 83, 155)" };
                }
            });
        }
        return style;
    }
    // Save selcted boxes
    saveSelectedBoxes(obj) {
        let listItems = this.props.selectedRB[obj["rbType"]];
        let duplicateIdx = -1;
        if (listItems && listItems.length > 0) {
            listItems.forEach((item, idx) => {
                if (
                    obj.sourceCriteriaId == item.sourceCriteriaId &&
                    obj.criteriaName == item.criteriaName &&
                    obj.selectedRanges == item.selectedRanges
                ) {
                    duplicateIdx = idx;
                }
            });

            if (duplicateIdx > -1) {
                listItems.splice(duplicateIdx, 1);
            } else {
                listItems.push(obj);
            }
            this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
        } else {
            listItems = [obj];
            this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
        }
    }


    showCriteriaName(cName) {
        let criteriaName = "";
        if (cName.length > 28) {
            criteriaName = cName.substring(0, 43) + "...";
        } else {
            criteriaName = cName;
        }
        return criteriaName;
    }

    render() {
        let chartAccordion = this.props.accordionState
        if (this.props.data) {
            return (
                <React.Fragment>
                    {/* <!-- Left Chart Table Start --> */}
                    <div className="scRb-heading-28-20">
                        <p>Processing Behaviors &amp; Strategies</p>
                    </div>
                    <div className="panel-group panel-width pt-20" id="accordion">
                        <div className="crb-top-bor4 crb_print-bor-11-20"></div>
                        {/* <div className="crb-top-bor5"></div> */}
                        <p className="crb-first-heading crb_head1">Reading Behavior</p>
                        <p className="crb-first-record lft-4 crb-fr-11-20">First Record</p>
                        <p className="crb-first-record crb-rr-11-20">Recent Record</p>
                        <p className="all-crb-first-record crb-ara-11-20">All Records' Average</p>
                        {/* <div className="class-reading-behaviors print-crb-1">
                            <p>Processing Behaviors &amp; Strategies</p>
                        </div> */}
                        <div className={this.props.scroll ? "crb-inner-wrap print-crb-inner-wrap" : "print-body cRb-pb-22-20"}>
                            {this.props.data.map((crbMainCategory, index) => {
                                return (
                                    <div key={index}>
                                        <div
                                            className={"panel-heading cursor-pointer expanded-accord print-crb-acc"
                                            }
                                        >
                                            <h4
                                                className="panel-title mt-2 pos-rel print-crb-h4"
                                                onClick={() => { this.props.setAccordionState(index) }}
                                            >{
                                                    <div class="tab-left-border print-tab-left-bor"></div>
                                                }


                                                <a className="crb_anchor1">{crbMainCategory["sourceRubricName"]}</a>
                                            </h4>
                                        </div>
                                        <div
                                            id="collapseOne"
                                            className="panel-collapse collapse print-colsp print-colsp-11-05  in show"
                                        >
                                            <div className="panel-body">
                                                <div className="container">
                                                    <div className="row pmb-5 pos-rel">
                                                        <div className="sc_rb_inner-bor crb_inner-bor-11-05"></div>
                                                        <div className="class-rb-col crb-11-05-li pos-rel pull-left">
                                                            {/* <div className="crb-left-color-strip"></div> */}
                                                            <div className="crb-new-bord-strip crb-strip-11-20"></div>
                                                            <ul>
                                                                {crbMainCategory["resultList"].map(
                                                                    (crbListItem, index) => {
                                                                        return (
                                                                            <li
                                                                                className="pos-rel crb-hover-container"
                                                                                key={index}
                                                                            >
                                                                                <div class="left-border"></div>
                                                                                <span>
                                                                                    {
                                                                                        this.showCriteriaName(
                                                                                            crbListItem["sourceCriteriaName"]
                                                                                        )
                                                                                    }
                                                                                </span>

                                                                            </li>
                                                                        );
                                                                    }
                                                                )}
                                                            </ul>
                                                        </div>

                                                        <div
                                                            className="crb-first-record-error pos-rel"
                                                            id="firstRecord"
                                                        >
                                                            <div className="class-rb-table">
                                                                <div className="crb-first-error-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="crb-bor-11"></div>
                                                                    <div className="crb-bor-12"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "firstRecordCount"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "firstRecordCount",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ]
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "firstRecordCount",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: null
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["firstRecordCount"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>{crbListItem[
                                                                                                "firstRecordCount"
                                                                                            ] === null ? 0 : 0}</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="crb-first-record-error pos-rel">
                                                            <div className="class-rb-table">
                                                                <div className="crb-first-error-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="crb-bor-11"></div>
                                                                    <div className="crb-bor-12"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "recentRecordCount"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "recentRecordCount",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: null
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "recentRecordCount",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: null
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["recentRecordCount"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>{crbListItem[
                                                                                                "recentRecordCount"
                                                                                            ] === null ? 0 : 0}</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="crb-first-record-error pos-rel">
                                                            <div className="class-rb-table">
                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="crb-bor-12"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        'range0_25'
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '0-25'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '0-25'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range0_25"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>{crbListItem[
                                                                                                "range0_25"
                                                                                            ] === null ? 0 : 0}</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range26_50"
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '26-50'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '26-50'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range26_50"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>{crbListItem[
                                                                                                "range26_50"
                                                                                            ] === null ? 0 : 0}</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range51_75"
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '51-75'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '51-75'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range51_75"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>{crbListItem[
                                                                                                "range51_75"
                                                                                            ] === null ? 0 : 0}</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range76_100"
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '76-100'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '76-100'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range76_100"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>{crbListItem[
                                                                                                "range76_100"
                                                                                            ] === null ? 0 : 0}</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </React.Fragment>
            );
        } else {
            return <div></div>;
        }
    }
}

export default Crb_Chart_Print;