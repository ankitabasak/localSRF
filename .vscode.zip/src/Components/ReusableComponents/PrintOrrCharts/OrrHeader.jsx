import React, { component, Component } from 'react';
import becLogo from '../../../../public/assets/orr/rlp-screen/benchmark-print-logo.jpg';
import { getDateFormat } from '../OrrReusableComponents';
import PrintFilter from './PrintFilter.jsx';

class OrrHeader extends Component {
    render() {
        const headerDetails = this.props.studentDetails;
        return (
            <React.Fragment>
                {/* <thead> */}
                <tr>
                    <td>
                        <div className="print-wrap">
                            {/* <!-- header section start --> */}
                            <div className="print-header">
                                <div className="pull-left">
                                    <img src={becLogo} />
                                </div>
                                <div className="pull-right" style={{ position: 'relative', top: '10px' }}>
                                    <p>Oral Reading Records</p>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                {/* </thead> */}
                {/* <!-- header section end --> */}

                <tr className="print-footer-wrap">
                    <td colSpan="9">
                        <div className="print-footer hr-page-end">
                            <ul>
                                {this.props.navSelected.student &&
                                    <li>
                                        <b>Student: </b>{headerDetails.Roster_Tab.SelectedStudent.name ? headerDetails.Roster_Tab.SelectedStudent.name : <span className="wc-blank-txt">blank</span>}
                                    </li>}
                                {this.props.navSelected.student || this.props.navSelected.class ?
                                    <li>
                                        <b>Class: </b>{headerDetails.Roster_Tab.SelectedClass.name ? headerDetails.Roster_Tab.SelectedClass.name : <span className="wc-blank-txt">blank</span>}
                                    </li> : ''}
                                {this.props.navSelected.student || this.props.navSelected.class ?
                                    <li>
                                        <b>Teacher: </b>{headerDetails.Roster_Tab.SelectedTeacher.name ? headerDetails.Roster_Tab.SelectedTeacher.name : <span className="wc-blank-txt">blank</span>}
                                    </li> : ''}
                                {this.props.navSelected.student || this.props.navSelected.class || this.props.navSelected.school ?
                                    <li>
                                        <b>Grade: </b>{headerDetails.Roster_Tab.selectedRosterGrade ? headerDetails.Roster_Tab.selectedRosterGrade.length > 0 &&
                                            headerDetails.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
                                            : <span className="wc-blank-txt">blank</span>}
                                    </li> : ''}
                                {this.props.navSelected.student || this.props.navSelected.class || this.props.navSelected.school ?
                                    <li>
                                        <b>School: </b> {headerDetails.Roster_Tab.SelectedSchool.name ? headerDetails.Roster_Tab.SelectedSchool.name : <span className="wc-blank-txt">blank</span>}
                                    </li> : ''}
                                <li>
                                    <b>District: </b>{headerDetails.Roster_Tab.SelectedDistrict.name ? headerDetails.Roster_Tab.SelectedDistrict.name : <span className="wc-blank-txt">blank</span>}
                                </li>
                                <li>
                                    <b>Dates: </b>{this.props.studentDetails.minTestDate || this.props.studentDetails.maxTestDate ? this.props.studentDetails.minTestDate === this.props.studentDetails.maxTestDate ? this.props.studentDetails.minTestDate : this.props.studentDetails.minTestDate + '-' + this.props.studentDetails.maxTestDate : <span className="wc-blank-txt">blank</span>}
                                </li>
                            </ul>
                        </div>
                    </td>
                </tr>

                <tbody>
                    <tr>
                        <td colSpan="10">
                            <div className="print-sub-header">
                                <div className="pull-left">
                                    <span className="title-header">
                                        <span className="print-diamond-symbol" />
                                        {this.props.chartTitle}
                                    </span>
                                </div>
                                <div className="pull-right crb-date-created">
                                    <p>
                                        <span className="fw-500">
                                            <b>Date Created: </b>
                                        </span>
                                        <span>{getDateFormat()}</span>
                                    </p>
                                </div>
                            </div>

                        </td>
                    </tr>
                    <tr>
                        <th colSpan="9" style={{ border: "none" }}>
                            <PrintFilter selectedFilter={this.props.selectedFilter} />
                        </th>
                    </tr>
                </tbody>
            </React.Fragment>
        )
    }
}

export default OrrHeader;

