import React, { Component } from 'react';
import arrowDown from '../../../../public/assets/orr/rlp-screen/select-down-arrow.svg';
class SCRbChartPrint extends Component {

    constructor(props) {
        super(props);
        this.handleDropdownChange = this.handleDropdownChange.bind(this);
    }
    componentDidMount(props) {
        if (this.props.data && this.props.data.length > 0) {

            this.setState({
                ...this.state,
                accordionSelected: this.props.data.length - 1
            });
        }
    }

    isSelected(item) {
        let listItems = this.props.selectedRB[item["rbType"]];
        let style = { color: "#333333" };
        if (listItems && listItems.length > 0) {
            listItems.forEach((obj, idx) => {
                if (
                    obj.sourceCriteriaId == item.sourceCriteriaId &&
                    obj.criteriaName == item.criteriaName &&
                    obj.selectedRanges == item.selectedRanges
                ) {
                    style = { color: "white", backgroundColor: "rgb(0, 83, 155)" };
                }
            });
        }
        return style;
    }
    // Save selcted boxes
    saveSelectedBoxes(obj) {
        let listItems = this.props.selectedRB[obj["rbType"]];
        let duplicateIdx = -1;
        if (listItems && listItems.length > 0) {
            listItems.forEach((item, idx) => {
                if (
                    obj.sourceCriteriaId == item.sourceCriteriaId &&
                    obj.criteriaName == item.criteriaName &&
                    obj.selectedRanges == item.selectedRanges
                ) {
                    duplicateIdx = idx;
                }
            });

            if (duplicateIdx > -1) {
                listItems.splice(duplicateIdx, 1);
            } else {
                listItems.push(obj);
            }
            this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
        } else {
            listItems = [obj];
            this.props.updateSelctedItems({ [obj["rbType"]]: listItems });
        }
    }

    showCollapseAccordion(list) {
        // this.props.SHOW_HIDE_BAR(list);
    }
    //to collapse school
    hideShowAccordion(rubricList) {
        this.props.showHideAccordion({
            ...this.props.srbResponse.showSrbAccordion,
            [rubricList]: !this.props.srbResponse.showSrbAccordion[rubricList]
        });
    }
    //to display the last passage
    showToolTip(passage) {
        let crbHover = false;
        if (passage.length > 28) {
            crbHover = true;
        }
        if (crbHover) {
            return (
                <div className="hover-crb school-rb word-bk">
                    {passage}
                    <div className="tooltip-dot" />
                </div>
            );
        }

    }

    showCriteriaName(cName) {
        let criteriaName = "";
        if (cName.length > 65) {
            criteriaName = cName.substring(0, 65) + "...";
        } else {
            criteriaName = cName;
        }
        return criteriaName;
    }

    handleDropdownChange(e) {

        this.props.updateSelectedGrade(e.target.value)
        // this.props.selectedErrGrade(e.target.value);
        // this.props.triggerDropDown(e.target.value);
    }

    render() {
        let gradeForDropDown = this.props.dropDownData
        let chartAccordion = this.props.chartAccordionState;
        if (this.props.data) {

            return (
                <React.Fragment>
                    {/* <!-- Left Chart Table Start --> */}
                    <div className="scRb-heading-28-20">
                        <p>Processing Behaviors &amp; Strategies</p>
                    </div>
                    <div className="panel-group panel-width pt-20 school-rb-select-wrap ScRb-print-22-20" id="accordion">
                        <div className="crb-top-bor4 scRbtop-bor-22-20"></div>
                        <div className="crb-top-bor5 scRbbtm-bor-22-20"></div>
                        <div className="sfa-grade-select">
                            <div className="bec-select">
                                <div className="select-side select-22-20">
                                    <img src={arrowDown} alt="select" />
                                </div>
                                <span>Grade</span>
                                <select
                                    className="form-control"
                                    id="sel1"
                                    onChange={this.handleDropdownChange}
                                    value={this.props.gradeSelected}
                                >
                                    <option>{this.props.gradeSelected}</option>
                                </select>
                            </div>
                        </div>
                        <p className="crb-first-record lft-4 scRb-fr-22-20">First Record</p>
                        <p className="crb-first-record scRb-rr-22-20">Recent Record</p>
                        <p className="all-crb-first-record scRb-ara-22-20">All Records' Average</p>

                        <div className={this.props.scroll ? "crb-inner-wrap  print-crb-inner-wrap" : "print-body print-body-21-20"}>
                            {this.props.data.map((crbMainCategory, index) => {
                                return (
                                    <div className="panel panel-default" key={index}>
                                        <div
                                            className={"panel-heading mb-6 cursor-pointer expanded-accord print-crb-acc"
                                            }
                                        >
                                            <h4
                                                className="panel-title mt-2 print-crb-h4 pos-rel"
                                                onClick={() => { this.props.setAccordionState(index) }}
                                            >
                                                <div className="tab-left-border scRb-tabbor-22-20"></div>
                                                <a className="crb_anchor1">{crbMainCategory["sourceRubricName"]}</a>
                                            </h4>
                                        </div>
                                        <div
                                            id="collapseOne"
                                            className="panel-collapse collapse in show"
                                        >
                                            <div className="panel-body print-ml-22-20">
                                                <div className="container">
                                                    <div className="row pmb-5 pos-rel">
                                                        <div className="sc_rb_inner-bor scRb-bor-22-20"></div>
                                                        <div className="class-rb-col pos-rel pull-left">
                                                            {/* <div className="crb-left-color-strip"></div> */}

                                                            <ul>
                                                                {crbMainCategory["resultList"].map(
                                                                    (crbListItem, index) => {
                                                                        return (
                                                                            <li
                                                                                className="pos-rel crb-hover-container scRb-container-22-20"
                                                                                key={index}
                                                                            >
                                                                                <div class="left-border"></div>
                                                                                <span>
                                                                                    {
                                                                                        this.showCriteriaName(
                                                                                            crbListItem["sourceCriteriaName"]
                                                                                        )
                                                                                    }
                                                                                </span>
                                                                            </li>
                                                                        );
                                                                    }
                                                                )}
                                                            </ul>
                                                        </div>

                                                        <div
                                                            className="crb-first-record-error pos-rel"
                                                            id="firstRecord"
                                                        >
                                                            <div className="class-rb-table">
                                                                <div className="crb-first-error-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "firstRecordCount"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "firstRecordCount",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ]
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "firstRecordCount",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: null
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["firstRecordCount"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="crb-first-record-error pos-rel">
                                                            <div className="class-rb-table">
                                                                <div className="crb-first-error-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "recentRecordCount"
                                                                                    ] ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "recentRecordCount",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: null
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "recentRecordCount",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: null
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["recentRecordCount"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li key={index}>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="crb-first-record-error pos-rel">
                                                            <div className="class-rb-table">
                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        'range0_25'
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '0-25'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '0-25'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range0_25"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range26_50"
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '26-50'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '26-50'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range26_50"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range51_75"
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '51-75'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '51-75'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range51_75"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>

                                                                <div className="crb-all-records-col pos-rel">
                                                                    <div className="crb-bor-1"></div>
                                                                    <div className="test">
                                                                        <ul>
                                                                            {crbMainCategory["resultList"].map(
                                                                                (crbListItem, index) => {
                                                                                    return crbListItem[
                                                                                        "range76_100"
                                                                                    ] !== null ? (
                                                                                            <li
                                                                                                key={index}
                                                                                                className="cursor-pointer crb-default-bgcolor"
                                                                                                style={this.isSelected({
                                                                                                    rbType: "allRecordRange",
                                                                                                    sourceCriteriaId:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaId"
                                                                                                        ],
                                                                                                    criteriaName:
                                                                                                        crbListItem[
                                                                                                        "sourceCriteriaName"
                                                                                                        ],
                                                                                                    selectedRanges: '76-100'
                                                                                                })}
                                                                                                onClick={() => {
                                                                                                    this.saveSelectedBoxes({
                                                                                                        rbType: "allRecordRange",
                                                                                                        sourceCriteriaId:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaId"
                                                                                                            ],
                                                                                                        criteriaName:
                                                                                                            crbListItem[
                                                                                                            "sourceCriteriaName"
                                                                                                            ],
                                                                                                        rubricId:
                                                                                                            crbMainCategory[
                                                                                                            "sourceRubricId"
                                                                                                            ],
                                                                                                        selectedRanges: '76-100'
                                                                                                    });
                                                                                                }}
                                                                                            >
                                                                                                {crbListItem["range76_100"]}
                                                                                            </li>
                                                                                        ) : (
                                                                                            <li>0</li>
                                                                                        );
                                                                                }
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                    </div>
                </React.Fragment>
            );
        } else {
            return <div></div>;
        }
    }
}

export default SCRbChartPrint;