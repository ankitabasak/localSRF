import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import ClassFluencyProgressChart from '../../Class_ORR/FluencyProgressComponents/class-fluency-prorgress-chart.jsx';
import ClassFluencyProgress from '../../Class_ORR/FluencyProgressComponents/class-fluency-progress.jsx'
import ClassSidePanelPrint from './Class_SidePanel.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={"Class | Fluency Progress Over Time"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <ClassFluencyProgressChart
                                        firstRecord={this.props.fpoData.firstRecordObj}
                                        allRecord={this.props.fpoData.allRecordObj}
                                        recentRecord={this.props.fpoData.recentRecordObj}
                                        errorRange={this.props.fpoData.errorRange}
                                        showHideRecentRecord={
                                            this.props.fpoData.showHideRecentRecord
                                        }
                                        showHideFirstRecord={this.props.fpoData.showHideFirstRecord}
                                        showHideAllRecord={this.props.fpoData.showHideAllRecord}
                                        SelectedErr={this.props.fpoData.SelectedErr}
                                        showRecord={this.props.fpoData.showRecord}
                                    />

                                </td>
                            </tr>
                            {this.props.fpoData.fpoGridResponse && this.props.fpoData.fpoGridData &&
                                <tr className="cFaFpot-15-20">
                                    <td>
                                        <div className="pull-left rt-left-heading cea-new-pr">
                                            {this.props.fpoData.fpoGridResponse.selectedRecordTypeDetails
                                                .recordTitle
                                                === "All Record's Average" ? "All Records' Average"
                                                : this.props.fpoData.fpoGridResponse.selectedRecordTypeDetails
                                                    .recordTitle}
                                        </div>
                                        <div className="pos-rel">
                                            <div className="rt-rhs-strip"></div>
                                            <hr className="clearfix mb-8 cFaFpot-hr-15-20" />
                                        </div>
                                        <div className="reading-level-label mb-8 color-1">
                                            First Record Date Range:
                                        <span> {this.props.fpoData.fpoGridResponse.selectedRecordTypeDetails.firstRecordDateRange}
                                            </span>
                                        </div>
                                        <div className="reading-level-label color-2">
                                            Recent Record Date Range:
                                        <span> {
                                                this.props.fpoData.fpoGridResponse.selectedRecordTypeDetails
                                                    .recentRecordDateRange
                                            }
                                            </span>
                                        </div>
                                        <div className="pull-right clearfix new-mb-4 rt-label-txt">
                                            <span className="rt-label">
                                                No. of students rostered:
                                            <span> {this.props.fpoData.fpoGridResponse.selectedRecordTypeDetails.noOfStudentsRoastered}
                                                </span>
                                            </span>
                                        </div>
                                        <ClassSidePanelPrint
                                            Data={this.props.fpoData.SortData}
                                            sideTableData={this.props.fpoData.fpoGridData} />
                                    </td>
                                </tr>}
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintCfaFpot extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="class_print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}
                        fpoData={this.props.fpoData}
                    />
                </div>
            </div>
        );
    }
}

export default PrintCfaFpot;