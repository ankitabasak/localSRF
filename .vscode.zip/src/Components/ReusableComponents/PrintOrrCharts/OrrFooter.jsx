import React, { Component } from 'react';

class OrrFooter extends Component {
    render() {
        const studentDetails = this.props.studentDetails;
        return (
            <React.Fragment>
                <tfoot>
                    <tr className="print-footer-wrap">
                        <td>
                            <div className="crb-perct-analysis pos-rel scrb-footer crb-perct-11-20">
                                <div className="crb-btm-bor crb-bor-22-20"></div>
                                <ul>
                                    <li>
                                        <span className="arrow_box-crb">% of Analysis</span>
                                    </li>
                                    <li style={{ borderBottom: " 4px solid rgb(213, 234, 242" }}>
                                        0-25
                                     </li>
                                    <li style={{ borderBottom: " 4px solid rgb(191, 224, 235" }}>
                                        26-50
                                    </li>
                                    <li style={{ borderBottom: " 4px solid rgb(170, 214, 229" }}>
                                        51-75
                                    </li>
                                    <li style={{ borderBottom: "4px solid rgb(128, 195, 218)" }}>
                                        76-100
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </React.Fragment>
        )
    }
}

export default OrrFooter;