import React, { Component } from 'react';

class PrintFilter extends Component {
    render() {
        const selectedFilter = this.props.selectedFilter;
        return (
            <React.Fragment>
                <div className="print-selected-filter clearfix pos-rel">
                    <div className="print-header-top-bor"></div>
                    <div className="pull-rght">
                        <ul className="header-select-filter-11-20">
                            <li>
                                <b>Selected Filters:</b>
                            </li>
                            <li
                                className={
                                    selectedFilter.proficiency.independent
                                        ? 'show filter-independent'
                                        : 'hide'
                                }
                            >
                                Independent
                      </li>
                            <li
                                className={
                                    selectedFilter.proficiency.instructional
                                        ? 'show filter-instructional'
                                        : 'hide'
                                }
                            >
                                Instructional
                      </li>
                            <li
                                className={
                                    selectedFilter.proficiency.frustrational
                                        ? 'show filter-frustrational'
                                        : 'hide'
                                }
                            >
                                Frustrational
                      </li>
                            <li
                                className={
                                    selectedFilter.language.english ? 'show filter-border' : 'hide'
                                }
                            >
                                English
                      </li>
                            <li
                                className={
                                    selectedFilter.language.spanish ? 'show filter-border' : 'hide'
                                }
                            >
                                Spanish
                            </li>
                            <li
                                className={
                                    selectedFilter.category.fiction ? 'show filter-border' : 'hide'
                                }
                            >
                                Fiction
                      </li>
                            <li
                                className={
                                    selectedFilter.category.nonfiction ? 'show filter-border' : 'hide'
                                }
                            >
                                Nonfiction
                      </li>
                            <li
                                className={selectedFilter.type.unseen ? 'show filter-border' : 'hide'}
                            >
                                Unseen
                      </li>
                            <li
                                className={selectedFilter.type.seen ? 'show filter-border' : 'hide'}
                            >
                                Seen
                      </li>
                        </ul>
                    </div>
                </div>
            </React.Fragment>
        )
    }
}

export default PrintFilter;