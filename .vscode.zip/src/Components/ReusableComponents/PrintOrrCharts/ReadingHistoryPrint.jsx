import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import { LandscapeOrientation } from '../LandscapeOrientation';
import SRhoTablePrint from './S_Rho_Table.jsx'

class ComponentToPrint extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    const data = this.props.data;
    const actualArray = this.props.ActualArray;

    const dashSymbol = <span>&mdash;</span>;
    return (
      <div
        className="container bg-white"
        style={{
          maxWidth: '2000px',
          paddingLeft: '10px',
          paddingRight: '10px',
          minHeight: '580px',
          background: '#ffff'
        }}
      >
        {/* Table start */}

        <div className="clearfix">
          <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
            {/* Header code */}

            <OrrHeader chartTitle={"Student | Reading History Report"}
              selectedFilter={this.props.selectedFilter}
              studentDetails={this.props.studentDetails}
              navSelected={this.props.navSelected}
            />
            <SRhoTablePrint
              Data={this.props.data}
              sideTableData={this.props.ActualArray} />
          </table>
        </div>
        {/* Table end */}
      </div>
    );
  }
}

class PrintS_ReadingHistoryData extends Component {
  render() {
    return (
      <div>
        <ReactToPrint
          trigger={() => (
            <span className="print-icon cursor-pointer">
              <img
                className="print-space"
                src={Print}
                width="24"
                height="20"
                alt="Reference icon"
              />
            </span>
          )}
          content={() => this.componentRef}
        />
        <div style={{ display: 'none' }}>
          <LandscapeOrientation />
          <ComponentToPrint
            externalData={this.props.externalFilter}
            selectedFilter={this.props.selectedFilter}
            navSelected={this.props.navSelected}
            data={this.props.Data}
            ActualArray={this.props.ActualArray}
            studentDetails={this.props.studentDetails}
            ref={el => (this.componentRef = el)}
          />
        </div>
      </div>
    );
  }
}

export default PrintS_ReadingHistoryData;