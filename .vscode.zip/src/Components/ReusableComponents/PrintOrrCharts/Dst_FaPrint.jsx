import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import DistrictFASidePanelComponent from '../../District_ORR/District_FA_Components/District_FA_SidePanel.jsx';
import DistrictFAChartComponent from '../../District_ORR/District_FA_Components/District_FA_Chart_Component.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '20px',
                    paddingRight: '20px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="distFaView-25-20 col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={"District | Fluency Analysis"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <DistrictFAChartComponent
                                        data={this.props.data}
                                        readingLevels={this.props.readingLevels}
                                        selectedBubsFromReducer={this.props.selectedBubsFromReducer}
                                    />
                                </td>
                            </tr>
                            {/* <tr>
                                <td>
                                    <DistrictFASidePanelComponent
                                        panelData={this.props.panelData}
                                        bubblesSelected={this.props.bubblesSelected}
                                        sortData={this.props.sortData}
                                        scrollFlag={this.props.scrollFlag}
                                    />
                                </td>
                            </tr> */}
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
                <div style={{ paddingTop: '40px' }} className="distFaPrint-12-20">
                    <DistrictFASidePanelComponent
                        panelData={this.props.panelData}
                        bubblesSelected={this.props.bubblesSelected}
                        sortData={this.props.sortData}
                        scrollFlag={this.props.scrollFlag}
                    />
                </div>
            </div>
        );
    }
}

class PrintDstFa extends Component {
    render() {
        return (
            <React.Fragment>
                <ReactToPrint
                    trigger={() => (
                        <span className="class_print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />

                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}

                        data={this.props.data}
                        readingLevels={this.props.readingLevels}
                        selectedBubsFromReducer={this.props.selectedBubsFromReducer}
                        panelData={this.props.panelData}
                        bubblesSelected={this.props.bubblesSelected}
                        sortData={this.props.sortData}
                        scrollFlag={this.props.scrollFlag}

                    />
                </div>
            </React.Fragment>
        );
    }
}

export default PrintDstFa;