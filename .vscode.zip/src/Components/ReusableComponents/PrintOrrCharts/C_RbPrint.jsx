import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
// import ClassReadingBehaviourChart from '../../Class_ORR/C_ReadingBehaviorComponents/C_RB_Chart.jsx'
import Crb_Chart_Print from './Crb_Chart_Print.jsx';
import OrrFooter from './OrrFooter.jsx';
import ClassSidePanelPrint from './Class_SidePanel.jsx';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"Class | Reading Behaviors"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />
                        <tbody>
                            <tr>
                                <td>
                                    {/* <div style={{ marginTop: '30px' }}> */}
                                    <Crb_Chart_Print
                                        data={this.props.data}
                                        accordionState={this.props.accordionState}
                                        selectedRB={this.props.selectedRB}
                                    />
                                    {/* </div> */}
                                </td>
                            </tr>
                        </tbody>
                        <OrrFooter />
                    </table>
                    <div className="cRbbtm-table-05-20" style={{
                        paddingTop: '40px',
                        width: '55%'
                    }}>
                        {this.props.sidePanelData &&
                            <React.Fragment>
                                <div>
                                    <div className="pull-left rt-left-heading cRb-heading-28-20">
                                        {this.props.sidePanelData['recordType']}
                                    </div>
                                    <div className="pos-rel" style={{ width: '100%' }}>
                                        {/* <div className="rt-rhs-strip"></div> */}
                                        {/* <hr className="clearfix mb-8" /> */}
                                    </div>
                                    <div className="mb-10 txt-lft-28-20">
                                        <div className="reading-level-label mb-8 color-1">
                                            First Record Date Range:
                                            <span> {this.props.sidePanelData.firstRecordDateRange}</span>
                                        </div>
                                        <div className="reading-level-label color-2">
                                            Recent Record Date Range:
                                            <span> {this.props.sidePanelData.recentRecordDateRange}</span>
                                        </div>
                                    </div>
                                    <div className="pull-right clearfix new-mb-4 print-rt-label-txt crb-label-11-05">
                                        <span className="rt-label">
                                            No. of students rostered:
                                        <span> {this.props.sidePanelData.noOfStudentsRostered}</span>
                                        </span>
                                    </div>
                                </div>
                                <ClassSidePanelPrint
                                    scrollFlag={true}
                                    sideTableData={this.props.sidePanelData.cpbGridDataResponseList}
                                    Data={this.props.sortData}
                                    chartName={"crb"} />
                            </React.Fragment>
                        }
                    </div>
                </div>
                {/* Table end */}
            </div>

        );
    }
}

class PrintCRB extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="class_print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        data={this.props.data}
                        accordionState={this.props.accordionState}
                        selectedRB={this.props.selectedRB}
                        sidePanelData={this.props.sidePanelData}
                        sortData={this.props.sortData}
                        ref={el => (this.componentRef = el)}
                    />
                </div>
            </div>
        );
    }
}

export default PrintCRB;