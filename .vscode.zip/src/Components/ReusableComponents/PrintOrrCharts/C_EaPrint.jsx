import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import ClassSidePanelPrint from './Class_SidePanel.jsx';
import ClassErrorAnalysisChart from '../../Class_ORR/Class_Error_Analysis/class-error-analysis-chart.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"Class | Error Analysis Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <ClassErrorAnalysisChart
                                        firstRecord={this.props.firstRecord}
                                        allRecord={this.props.allRecord}
                                        recentRecord={this.props.recentRecord}
                                        errorRange={this.props.errorRange}
                                        msvErrorRange={this.props.msvErrorRange}
                                        showHideRecentRecord={this.props.showHideRecentRecord}
                                        SelectedErr={this.props.SelectedErr}
                                        showRecord={this.props.showRecord}
                                        disableDiv={this.props.disableDiv}
                                        isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                                    />

                                </td>
                            </tr>
                            {this.props.sideTableData && <tr className="cEa-td-14-20">
                                <td style={{ width: '100%' }} className="cEa-td-14-20">
                                    <div className="cEa-wrap-03-20">
                                        <div className="pull-left rt-left-heading cea-new-pr">
                                            {this.props.sideTableData.selectedRecordDetails.recordTitle
                                                === "All Record's Average" ? "All Records' Average"
                                                : this.props.sideTableData.selectedRecordDetails.recordTitle}
                                        </div>
                                        <div className="pos-rel">
                                            <div className="rt-rhs-strip"></div>
                                            <hr className="clearfix mb-8 cEaMb-14-20" />
                                        </div>
                                        <div className="reading-level-label mb-8 color-1 clearfix">
                                            First Record Date Range:
                                    <span> {this.props.sideTableData.selectedRecordDetails.firstRecordDateRange}
                                            </span>
                                        </div>
                                        <div className="reading-level-label color-2">
                                            Recent Record Date Range:
                                     <span> {this.props.sideTableData.selectedRecordDetails.recentRecordDateRange}
                                            </span>
                                        </div>
                                        <div className="pull-right clearfix new-mb-4 rt-label-txt rostered-txt-14-20">
                                            <span className="rt-label">
                                                No. of students rostered:
                                    <span> {this.props.sideTableData.selectedRecordDetails.noOfStudentsRoastered}
                                                </span>
                                            </span>
                                        </div>
                                        <ClassSidePanelPrint
                                            scrollFlag={true}
                                            sideTableData={this.props.sideTableData.tableData || []}
                                            Data={this.props.Data}
                                            disableDiv={this.props.disableDiv} />

                                    </div>
                                </td>
                            </tr>}
                        </tbody>
                        {/* <OrrFooter studentDetails={this.props.studentDetails} /> */}
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintCEa extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="class_print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        firstRecord={this.props.firstRecord}
                        allRecord={this.props.allRecord}
                        recentRecord={this.props.recentRecord}
                        errorRange={this.props.errorRange}
                        msvErrorRange={this.props.msvErrorRange}
                        showHideRecentRecord={this.props.showHideRecentRecord}
                        SelectedErr={this.props.SelectedErr}
                        showRecord={this.props.showRecord}
                        disableDiv={this.props.disableDiv}
                        sideTableData={this.props.sideTableData}
                        Data={this.props.Data}
                        isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                        ref={el => (this.componentRef = el)}
                    />
                </div>
            </div>
        );
    }
}

export default PrintCEa;