import React, { Component } from 'react';

class ClassSidePanelPrint extends Component {
    arrayConstruction(list, endIndex) {
        var idx = 0
        var result = []
        while (idx < list.length) {
            if (idx % endIndex === 0) result.push([])
            result[result.length - 1].push(list[idx++])
        }
        return result
    }

    sidePanelDataConst(list, endIndex, chartName) {
        let count = 0;
        let start = 1;
        let colName;
        let dateCol;
        if (chartName === 'cRlp') {
            colName = 'letterLevel';
        } else if (chartName === 'crb') {
            colName = 'level';
        } else {
            colName = 'readingLevel';
        }

        if (chartName === 'crb') {
            dateCol = 'date'
        } else {
            dateCol = 'assignmentDate'
        }

        let modifiedArray = this.arrayConstruction(list, endIndex);
        let total = modifiedArray.map((indArray, index) => {
            start = 1 + count;
            count = count + indArray.length;
            return this.printTable(indArray, list, start, count, index, this.props.Data, colName, dateCol)
        })
        return total

    }
    LineUnderActiveColumnFiled(Data, columnName, SortType) {
        return Data.sortColumn == columnName && Data.sortType == SortType
            ? 'btmline-color font-Questrial'
            : 'font-Questrial';
    }

    assignClasses(Data, column, type) {
        if (Data.sortColumn === column && Data.sortType === type) {
            return ' blueColor';
        } else {
            return '';
        }
    }

    printTable(arr, list, start, count, index, Data, colName, dateCol) {
        const dashSymbol = <span>&mdash;</span>;
        return <React.Fragment>
            <table className={"class-rb-mt0-11-05 crho-table-print crhs-mt" + index} style={{ width: '60%', borderCollapse: 'collapse', textAlign: 'left', paddingTop: '20px' }}>
                <tr className="cea-tr-bor" style={{ height: '40px' }}>

                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'lastName',
                        Data.sortType
                    )}>{"Students" + " (" + list.length + ")"}</span>
                        <span className="togglers crb-sidepanel-ic">
                            <i
                                className={
                                    'cursor-pointer material-icons ' +
                                    this.assignClasses(Data, 'lastName', 'desc')
                                } style={{ position: 'relative', top: '6px', left: '0px' }}
                            >
                                expand_more
                            </i>
                            <i
                                className={
                                    'cursor-pointer material-icons expand-less ' +
                                    this.assignClasses(Data, 'lastName', 'asc')
                                } style={{ position: 'relative', right: '21px' }}
                            >
                                expand_less
                            </i>
                        </span>
                    </th>
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        colName,
                        Data.sortType
                    )}>Level</span>
                        <span className="togglers crb-sidepanel-ic">
                            <i
                                className={
                                    'cursor-pointer material-icons ' +
                                    this.assignClasses(Data, colName, 'desc')
                                } style={{ position: 'relative', top: '6px', left: '0px' }}
                            >
                                expand_more
                            </i>
                            <i
                                className={
                                    'cursor-pointer material-icons expand-less ' +
                                    this.assignClasses(Data, colName, 'asc')
                                } style={{ position: 'relative', right: '21px' }}
                            >
                                expand_less
                            </i>
                        </span>
                    </th>
                    {this.props.chartName === 'cfa' &&
                        <th><span className={this.LineUnderActiveColumnFiled(
                            Data,
                            'fluency',
                            Data.sortType
                        )}>Fluency</span>
                            <span className="togglers crb-sidepanel-ic">
                                <i
                                    className={
                                        'cursor-pointer material-icons ' +
                                        this.assignClasses(Data, 'fluency', 'desc')
                                    } style={{ position: 'relative', top: '6px', left: '0px' }}
                                >
                                    expand_more
                                </i>
                                <i
                                    className={
                                        'cursor-pointer material-icons expand-less ' +
                                        this.assignClasses(Data, 'fluency', 'asc')
                                    } style={{ position: 'relative', right: '21px' }}
                                >
                                    expand_less
                                </i>
                            </span>
                        </th>
                    }
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'proficiency',
                        Data.sortType
                    )}>Proficiency</span>
                        <span className="togglers crb-sidepanel-ic">
                            <i
                                className={
                                    'cursor-pointer material-icons ' +
                                    this.assignClasses(Data, 'proficiency', 'desc')
                                } style={{ position: 'relative', top: '6px', left: '0px' }}
                            >
                                expand_more
                            </i>
                            <i
                                className={
                                    'cursor-pointer material-icons expand-less ' +
                                    this.assignClasses(Data, 'proficiency', 'asc')
                                } style={{ position: 'relative', right: '21px' }}
                            >
                                expand_less
                            </i>
                        </span>
                    </th>
                    {this.props.chartName !== 'cfa' && <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        dateCol,
                        Data.sortType
                    )}>Date</span>
                        <span className="togglers crb-sidepanel-ic">
                            <i className={
                                'cursor-pointer material-icons ' +
                                this.assignClasses(Data, dateCol, 'desc')
                            } style={{ position: 'relative', top: '6px', left: '0px' }}
                            > expand_more</i>
                            <i className={
                                'cursor-pointer material-icons expand-less ' +
                                this.assignClasses(Data, dateCol, 'asc')
                            } style={{ position: 'relative', right: '21px' }}
                            >
                                expand_less
                            </i>
                        </span>
                    </th>}
                </tr>
                {arr.map((data, val) => {
                    return <React.Fragment>
                        <tr className="crho-print">
                            <td style={{ textAlign: "left" }}>{data.firstName + ' ' + data.lastName}</td>
                            <td style={{ textAlign: "left" }} >{data.readingLevel || data.letterLevel || data.level}</td>
                            {this.props.chartName === 'cfa' && <td style={{ textAlign: "left" }} >{data.fluency}</td>}
                            <td style={{ textAlign: "left" }} >{data.proficiency}</td>
                            {this.props.chartName !== 'cfa' && <td style={{ textAlign: "left" }} >{data.assignmentDate || data.date}</td>}
                        </tr>
                    </React.Fragment>
                })}

            </table>
            <div className="pagebreak"> </div>
        </React.Fragment>
    }

    render() {
        return (
            <React.Fragment>
                {this.sidePanelDataConst(this.props.sideTableData, 10, this.props.chartName)}
            </React.Fragment>
        )
    }
}

export default ClassSidePanelPrint;