import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import ClassFluencyChartComponent from '../../Class_ORR/FluencyComponents/ClassFluencyChartComponent/ClassFluencyChartComponent.jsx';
import FluencyTable from '../../Class_ORR/FluencyComponents/Fluency_Table.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={"Class | Fluency Word Count Per Minute"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr
                            // style={{
                            //     height: '595px'
                            // }}
                            >
                                <td>
                                    <ClassFluencyChartComponent
                                        monthRangeObj={this.props.monthRangeObj}
                                        selAll={this.props.selAll}
                                        toggleData={this.props.toggleData}
                                        selectBubblesFromReducer={
                                            this.props.classFluencySelectedBubbles
                                        }
                                        chartData={this.props.CF_Chart_Response}
                                        CH_Data={this.props.classFluencyChartData} />

                                </td>
                            </tr>
                            <tr  className="cFaWcpmTr-02-20">
                                <td style={{
                                    paddingTop: '50px'
                                }}>
                                    <FluencyTable
                                        scrollFlag={true}
                                        cfaData={this.props.cfaGridData}
                                        Data={this.props.SortData}
                                        chartData={this.props.CF_Chart_Response}
                                        selectBubblesFromReducer={
                                            this.props.classFluencySelectedBubbles
                                        }
                                        apiLoader={this.props.sidePanelApiLoader}
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintCfaWcpm extends Component {
    render() {
        return (
            <div>
                {!this.props.toggleData ?
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={Print}
                                    width="24"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    /> : <span className="class_print-icon">
                        <img
                            className="print-space"
                            src={Print}
                            width="24"
                            height="20"
                            alt="Reference icon"
                        />
                    </span>}
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}

                        classFluencySelectedBubbles={
                            this.props.selectBubblesFromReducer
                        }
                        classFluencyChartData={this.props.CH_Data}
                        cfaGridData={this.props.cfaData}
                        SortData={this.props.Data}
                        CF_Chart_Response={this.props.chartData}
                        sidePanelApiLoader={this.props.apiLoader}
                        monthRangeObj={this.props.monthRangeObj}
                        selAll={this.props.selAll}
                        toggleData={this.props.toggleData}
                    />
                </div>
            </div>
        );
    }
}

export default PrintCfaWcpm;