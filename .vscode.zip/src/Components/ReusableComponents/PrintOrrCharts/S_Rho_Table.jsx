import React, { Component } from 'react';
import SortUpInActiveArrow from '../../../../public/images/Sort_Up_Inactive.svg';
import SortUpActiveArrow from '../../../../public/images/Sort_Up_Active.svg';
import SortDownInactiveArrow from '../../../../public/images/Sort_Down_Inactive.svg';
import SortDownActiveArrow from '../../../../public/images/Sort_Down_Active.svg';

class SRhoTablePrint extends Component {
    arrayConstruction(list, endIndex) {
        var idx = 0
        var result = []
        while (idx < list.length) {
            if (idx % endIndex === 0) result.push([])
            result[result.length - 1].push(list[idx++])
        }
        return result
    }

    sidePanelDataConst(list, endIndex) {
        let modifiedArray = this.arrayConstruction(list, endIndex);
        let total = modifiedArray.map((indArray, index) => {
            return this.printTable(indArray, index, this.props.Data)
        })
        return total

    }


    assignClasses(Data, column, type) {
        if (type === 'asc') {
            if (Data.sortColumn === column && Data.sortType === type) {
                return SortUpActiveArrow;
            } else {
                return SortUpInActiveArrow;
            }
        }
        if (type === 'desc') {
            if (Data.sortColumn === column && Data.sortType === type) {
                return SortDownActiveArrow;
            } else {
                return SortDownInactiveArrow;
            }
        }

    }

    LineUnderActiveColumnFiled(Data, columnName, SortType) {
        return Data.sortColumn == columnName && Data.sortType == SortType
            ? 'btmline-color'
            : '';
    }

    printTable(arr, index, Data) {
        const dashSymbol = <span>&mdash;</span>;
        return <React.Fragment>
            <table className={"stRho-table-01-2020 crho-table-print crhs-mt" + index}
                style={{ width: '60%', borderCollapse: 'collapse', textAlign: 'left', paddingTop: '20px', pageBreakInside: 'avoid', pageBreakAfter: 'auto' }}>
                <tr className="onn cea-tr-bor " style={{ height: '40px' }}>
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'assignmentDate',
                        Data.sortType
                    )} style={{ top: '-4px' }}>Date</span>
                        <span>
                            <img src={this.assignClasses(Data, 'assignmentDate', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} />
                        </span>
                        <span><img src={this.assignClasses(Data, 'assignmentDate', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>
                    </th>
                    <th><span className={"sec " +
                        this.LineUnderActiveColumnFiled(
                            Data,
                            'letterLevel',
                            Data.sortType
                        )
                    } style={{ top: '-4px' }}>Level</span>
                        <span><img src={this.assignClasses(Data, 'letterLevel', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} /></span>
                        <span><img src={this.assignClasses(Data, 'letterLevel', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>
                    </th>
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'proficiency',
                        Data.sortType
                    )} style={{ top: '-4px' }}>Proficiency</span>
                        <span><img src={this.assignClasses(Data, 'proficiency', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} /></span>
                        <span><img src={this.assignClasses(Data, 'proficiency', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>
                    </th>

                    <th><span className={"passage_length " +
                        this.LineUnderActiveColumnFiled(
                            Data,
                            'lastPassage',
                            Data.sortType
                        )
                    } style={{ top: '-4px' }}>Passage</span>
                        <span><img src={this.assignClasses(Data, 'lastPassage', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} /></span>
                        <span><img src={this.assignClasses(Data, 'lastPassage', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>
                    </th>
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'category',
                        Data.sortType
                    )} style={{ top: '-4px' }}>Category</span>
                        <span><img src={this.assignClasses(Data, 'category', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} /></span>
                        <span><img src={this.assignClasses(Data, 'category', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>
                    </th>
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'accuracy',
                        Data.sortType
                    )} style={{ top: '-4px' }}>Accuracy</span>
                        <span><img src={this.assignClasses(Data, 'accuracy', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} /></span>
                        <span><img src={this.assignClasses(Data, 'accuracy', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>
                    </th>
                    <th><span style={{ top: '-4px' }}>Self-Correction</span>
                        {/* <span><img src={this.assignClasses(Data, 'selfCorrection', 'desc')} /></span>
                        <span><img src={this.assignClasses(Data, 'selfCorrection', 'asc')} /></span> */}

                    </th>
                    <th><span className={this.LineUnderActiveColumnFiled(
                        Data,
                        'fluency',
                        Data.sortType
                    )} style={{ top: '-4px' }}>Fluency</span>
                        <span><img src={this.assignClasses(Data, 'fluency', 'desc')} style={{ position: 'relative', top: '3px', left: '4px' }} /></span>
                        <span><img src={this.assignClasses(Data, 'fluency', 'asc')} style={{ position: 'relative', top: '-7px', right: '5px' }} /></span>

                    </th>
                    <th><span style={{ top: '-4px' }}>Retell</span>
                        {/* <span><img src={this.assignClasses(Data, 'reTelling', 'desc')} /></span>
                        <span><img src={this.assignClasses(Data, 'reTelling', 'asc')} /></span> */}
                    </th>
                    <th><span style={{ top: '-4px' }}>Comprehension</span>
                        {/* <span><img src={this.assignClasses(Data, 'comprehension', 'desc')} /></span>
                        <span><img src={this.assignClasses(Data, 'comprehension', 'asc')} /></span> */}

                    </th>
                </tr>
                {arr.map((data, val) => {
                    return <React.Fragment>
                        <tr className="srho-print-bor" style={{ height: '30px' }}>
                            <td style={{ textAlign: "left" }}>{data.assignmentDate}</td>
                            <td style={{ textAlign: "left" }} >{data.letterLevel}</td>
                            <td style={{ textAlign: "left" }} >{data.proficiency}</td>
                            <td style={{ textAlign: "left" }} >{data.lastPassage ? data.lastPassage : dashSymbol}</td>
                            <td style={{ textAlign: "left" }} >{data.category ? data.category : dashSymbol}</td>
                            <td style={{ textAlign: "left" }}>{data.accuracy ? data.accuracy + ' %' : dashSymbol}</td>
                            <td style={{ textAlign: "left" }} >{data.selfCorrection ? data.selfCorrection : dashSymbol}</td>
                            <td style={{ textAlign: "left" }} >{data.fluency ? data.fluency + ' wcpm' : dashSymbol}</td>
                            <td style={{ textAlign: "left" }} >{data.reTelling ? data.reTelling : dashSymbol}</td>
                            <td style={{ textAlign: "left" }} >{data.comprehension ? data.comprehension : dashSymbol}</td>
                        </tr>
                    </React.Fragment>
                })}

            </table>
            <div className="pagebreak"> </div>
        </React.Fragment>
    }

    render() {
        return (
            <React.Fragment>
                {this.sidePanelDataConst(this.props.sideTableData, 10)}
            </React.Fragment>
        )
    }
}

export default SRhoTablePrint;