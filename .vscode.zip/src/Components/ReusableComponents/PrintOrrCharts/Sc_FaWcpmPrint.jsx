import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import SchoolFAChartComponent from '../../School_ORR/School_FA_Print_Components/School_FA_Chart_Component.jsx'
import SchoolFASidePanelComponent from '../../School_ORR/School_FA_Components/School_FA_SidePanel.jsx';
import SchoolFawcpmGrid from './Sch_FawcpmSidePanel.jsx';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        let key =
            this.props.bubblesSelected && Object.keys(this.props.bubblesSelected)[0];
        let selLvls = key && this.props.bubblesSelected[key];
        let sidePanelData = this.props.panelData["tableData"];
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="ScFaWcpmView-25-20 col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"School | Fluency Word Count Per Minute"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <SchoolFAChartComponent
                                        scFaChart={true}
                                        data={this.props.data}
                                        readingLevels={this.props.readingLevels}
                                        selectedBubsFromReducer={this.props.selectedBubsFromReducer}
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <br />
                    <br />
                    <div className="reading-target-wrap scFaWpcm-rhs-wrap-28-20" style={{
                        paddingTop: '10px'
                    }}>
                        <div className="pull-left rt-left-heading scFaWpcm-heading-28-20">
                            <div className="mb-8">{sidePanelData["selectedRecordTypeDetails"]["recordTitle"]}</div>
                            <div>
                                Grade: {selLvls[0] ? selLvls[0]["grade"] : ''}
                            </div>
                        </div>
                        {/* <hr className="clearfix mb-8" /> */}
                        <div className="Readingtarget-graph txt-lft-28-20">
                            <div className="chart-details mb-10">
                                <div className="reading-level-label mb-8 color-1">
                                    First Record Date Range:
                 <span> {sidePanelData["selectedRecordTypeDetails"]["firstRecordDateRange"]}</span>
                                </div>
                                <div className="reading-level-label color-1">
                                    Recent Record Date Range:
                 <span> {sidePanelData["selectedRecordTypeDetails"]["recentRecordDateRange"]}</span>
                                </div>
                            </div>
                        </div>
                        <div
                            className="pull-right clearfix  scFaWpcpm-rostered-22-20"
                            style={{ marginBottom: "4px" }}
                        >
                            <span style={{ fontSize: "12px", fontWeight: "500" }}>
                                No. of students rostered: {sidePanelData["selectedRecordTypeDetails"]["noOfStudentsRoastered"]}
                            </span>
                        </div>
                        {sidePanelData["sFAGridData"] &&
                            <SchoolFawcpmGrid
                                schGridData={sidePanelData["sFAGridData"]}
                            />
                        }
                    </div>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintScFaWcpm extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}
                        scrollFlag={this.props.scrollFlag}
                        data={this.props.data}
                        readingLevels={this.props.readingLevels}
                        selectedBubsFromReducer={this.props.selectedBubsFromReducer}

                        panelData={this.props.panelData}
                        bubblesSelected={this.props.bubblesSelected}
                        sortData={this.props.sortData}
                    />
                </div>
            </div>
        );
    }
}

export default PrintScFaWcpm;