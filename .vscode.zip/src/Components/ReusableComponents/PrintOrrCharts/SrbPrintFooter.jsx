import React, { Component } from 'react';
import ExtremeLeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-new.svg';
import LeftArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-new.svg';
import RightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-new.svg';
import ExtremeRightArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-new.svg';
import ExtremeLeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-active-new.svg';
import LeftActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-active-new.svg';
import RightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-active-new.svg';
import ExtremeRightActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-active-new.svg';
import '../../ORR/S_FluencyComponents/Fluency.css';

class SrbFooter extends Component {

    stdProficiencyType(type) {
        switch (type) {
            case 'Instructional':
                return 'ar';
            case 'Independent':
                return 'ar-blue';
            case 'Frustrational':
                return 'ar-yellow';
        }
    }

    render() {
        return (
            <React.Fragment>

                <div className="prev-arrow-rbsection new-par">
                    <div className="prev-img1"
                        style={
                            this.props.srbResponse.scrollIndex > 0
                                ? { cursor: 'pointer' }
                                : { cursor: 'default' }
                        }
                    >
                        {this.props.srbResponse.scrollIndex > 0 ? (
                            <img
                                src={ExtremeLeftActiveArrow}
                                width="52px"
                                height="48px"
                            />
                        ) : (
                                <img src={ExtremeLeftArrow} width="52px" height="48px" />
                            )}
                    </div>
                    <div
                        className="prev-img2"
                        style={
                            this.props.srbResponse.scrollIndex > 0
                                ? { cursor: 'pointer' }
                                : { cursor: 'default' }
                        }
                    >
                        {this.props.srbResponse.scrollIndex > 0 ? (
                            <img src={LeftActiveArrow} width="52px" height="48px" />
                        ) : (
                                <img src={LeftArrow} width="52px" height="48px" />
                            )}
                    </div>
                </div>
                <div
                    className="chart-section pos-rel srb-btm-mid-sec srb-mid-print-sec cs-12-20"
                >
                    <ul>
                        {this.props.srbResponse.srbXAxis &&
                            this.props.srbResponse.srbXAxis.map((xData, value) => (
                                <li className="chart-box-rb ">
                                    <p
                                        className={this.stdProficiencyType(
                                            xData.proficiency
                                        )}
                                    />
                                    <p className="cursor-pointer xaxis-txt">
                                        <span>{xData.assignmentCompletionDate}</span>
                                        <br />
                                        <span>{xData.letterLevel}</span>
                                    </p>

                                </li>
                            ))}
                    </ul>
                </div>
                <div className="next-arrow-section new-nas">
                    <div
                        className="prev-img1"
                        style={
                            this.props.srbResponse.scrollIndex <
                                this.props.srbResponse.srbResponse.spbxAxisResponseList
                                    .length -
                                7
                                ? { cursor: 'pointer' }
                                : { cursor: 'default' }
                        }
                    >
                        {this.props.srbResponse.scrollIndex <
                            this.props.srbResponse.srbResponse.spbxAxisResponseList
                                .length -
                            7 ? (
                                <img src={RightActiveArrow} width="52px" height="48px" />
                            ) : (
                                <img src={RightArrow} width="52px" height="48px" />
                            )}
                    </div>
                    <div
                        className="prev-img2"
                        style={
                            this.props.srbResponse.scrollIndex <
                                this.props.srbResponse.srbResponse.spbxAxisResponseList
                                    .length -
                                7
                                ? { cursor: 'pointer' }
                                : { cursor: 'default' }
                        }
                    >
                        {this.props.srbResponse.scrollIndex <
                            this.props.srbResponse.srbResponse.spbxAxisResponseList
                                .length -
                            7 ? (
                                <img
                                    src={ExtremeRightActiveArrow}
                                    width="52px"
                                    height="48px"
                                />
                            ) : (
                                <img src={ExtremeRightArrow} width="52px" height="48px" />
                            )}
                    </div>
                </div>
                <div className="block-name block-name-print">
                    <span>Assignment</span>
                </div>
            </React.Fragment>
        )
    }
}

export default SrbFooter