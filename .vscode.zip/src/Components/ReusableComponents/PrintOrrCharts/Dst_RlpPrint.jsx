import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import YAxisComponent from '../../District_ORR/Dist_RLPComponents/District_RLP_Reading_Level_Component/District_RLP_Reading_Levels.jsx';
import DistrictRlpGrade from '../../District_ORR/Dist_RLPComponents/District_RLP_Grade_Column/DistrictRLPGradeColumn.jsx';
import ScSidePanel from '../../District_ORR/Dist_RLPComponents/District_RLP_Side_Panel.jsx'
import SummaryPrint from '../../../../public/assets/orr/rlp-screen/print-solid.svg';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="distRlp-safari-09-20 col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={this.props.xAxisName === 'grade' ? "District Reading Level Progress" : "District Reading Level Progress"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <div className="row mt-10" style={{ marginTop: '7px' }}>
                                        <div className="srlp-lhs-wrap sc-rlp-wrap distRlp-fullWidth-16-20">
                                            <div className="wrap-srlp pos-rel ">
                                                <div className="readingLevel-srlp">Reading Level</div>
                                                <div className="grade-txt-srlp">{this.props.xAxisName}</div>
                                                <div className="rhs-line-srlp" />
                                                <div className="rhs-line2-srlp" />
                                                <div className="rhs-line-btm-srlp" />
                                                <div className="rhs-line-btm1-srlp" />
                                                <YAxisComponent
                                                    axisData={this.props.axisData}
                                                />
                                                <DistrictRlpGrade
                                                    summaryFlag={this.props.summaryFlag}
                                                    monthRangeObj={this.props.monthRangeObj}
                                                    selAll={this.props.selAll}
                                                    gradesData={this.props.gradesData}
                                                    readingLevels={this.props.readingLevels}
                                                    selectedLevels={this.props.selectedLevels}
                                                    currentChartInDisplay={
                                                        this.props.currentChartInDisplay
                                                    }
                                                    totalGradeItems={this.props.totalGradeItems}
                                                    scrollIndex={this.props.scrollIndex}
                                                    scrollFlag={this.props.scrollFlag}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr className="DistRlp-tr-21-20">
                                <td>
                                    <ScSidePanel
                                        scrollFlag={this.props.scrollFlag}
                                        districtData={this.props.districtData}
                                        sortData={this.props.sortData}
                                        currentChartInDisplay={
                                            this.props.currentChartInDisplay
                                        }
                                        selectedLevels={this.props.selectedLevels}
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintDstRlp extends Component {

    render() {
        return (
            <React.Fragment>

                {this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={SummaryPrint}
                                    width="20"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                {!this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={Print}
                                    width="24"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        summaryFlag={this.props.summaryFlag}
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}
                        xAxisName={this.props.xAxisName}
                        scrollFlag={this.props.scrollFlag}

                        axisData={this.props.axisData}

                        backToMainChart={this.props.backToMainChart}
                        gradesData={this.props.gradesData}
                        readingLevels={this.props.readingLevels}
                        selectedLevels={
                            this.props.selectedLevels
                        }
                        currentChartInDisplay={
                            this.props.currentChartInDisplay
                        }
                        totalGradeItems={this.props.totalGradeItems}
                        scrollIndex={this.props.scrollIndex}

                        districtData={this.props.districtData}
                        sortData={this.props.sortData}
                        // currentChartInDisplay={
                        //     this.props.currentChartInDisplay
                        // }
                        selectedLevels={
                            this.props.selectedLevels
                        }
                        monthRangeObj={this.props.monthRangeObj}
                        selAll={this.props.selAll}
                    />
                </div>
            </React.Fragment>
        );
    }
}

export default PrintDstRlp;