import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import ClassRhoPrint from '../../Class_ORR/C_RHOComponets/cRhoPrint.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={"Class | Reading History Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <ClassRhoPrint classReadingHistoryData={this.props.classReadingHistoryData} />
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintCRho extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        classReadingHistoryData={this.props.classReadingHistoryData}
                        ref={el => (this.componentRef = el)}
                    />
                </div>
            </div>
        );
    }
}

export default PrintCRho;