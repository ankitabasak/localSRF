import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import SRbChart from '../../ORR/S_ReadingBehaviorsComponent/Srb_chartPrint.jsx';
import SrbFooter from './SrbPrintFooter.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '0px',
                    paddingRight: '0px',
                    minHeight: '600px',
                    background: '#ffff',
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"Student | Reading Behaviors Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr><td>
                                <SRbChart
                                    srbResponse={this.props.StudentRBState} />
                            </td></tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td style={{ backgroundColor: '#fff' }}>
                                    <div className="" style={{ position: 'relative' }}>
                                        <SrbFooter srbResponse={this.props.StudentRBState} />
                                        {/* <div className="srb-tab-top-bor"></div> */}
                                        <div className="print-bor-top print-srb-last-bt sRb-12-20"></div>
                                        <div className="print-bor-bottom print-srb-last-bt sRb-12-20"></div>
                                        {/* <div className="last-bor-top1"></div> */}
                                    </div>

                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintSrb extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        StudentRBState={this.props.StudentRBState}
                        ref={el => (this.componentRef = el)}
                    />
                </div>
            </div>
        );
    }
}

export default PrintSrb;