import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import ErrorAnalysisChart from '../../ORR/ChartComponents/ErrorChart.jsx';
import FirstArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end.svg';
import PreviousArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev.svg';
import NextArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next.svg';
import LastArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end.svg';
import FirstActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-end-active.svg';
import PreviousActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-prev-active.svg';
import NextActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-active.svg';
import LastActiveArrow from '../../../../public/assets/orr/rlp-screen/sfa-x-next-end-active.svg';
import ErrorDonutChart from '../../ORR/ChartComponents/ErrorValues.jsx';
import MsvDonutChart from '../../ORR/ChartComponents/MsvValues.jsx';
import './Charts.css';
import '../../ORR/ErrorAnalysisComponents/ErrorAnalysis.css';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
  constructor(props) {
    super(props);
  }
  proficiencyType(type) {
    switch (type) {
      case 'Instructional':
        return 'ar';
      case 'Independent':
        return 'ar-blue';
      case 'Frustrational':
        return 'ar-yellow';
    }
  }

  render() {
    const studentDataList = this.props.studentData;
    const date = studentDataList.date;
    const substitutionArray = studentDataList.substitution;
    const omissionArray = studentDataList.omission;
    const insertionArray = studentDataList.insertion;
    const meaningCuesArray = studentDataList.meaningCues;
    const omissionToldsArray = studentDataList.omissionTolds;
    const repetationArray = studentDataList.repetation;
    const selfCorrectionArray = studentDataList.selfCorrection;
    const structuralCuesArray = studentDataList.structuralCues;
    const toldArray = studentDataList.told;
    const visualCuesArray = studentDataList.visualCues;
    const dashSymbol = <span>&mdash;</span>;
    const average = this.props.dataObject.data.errorAnalysisAverage;
    const errorValueAverage = this.props.dataObject.data.errorAnalysisDonutData;
    const msvValueAverage = this.props.dataObject.data.msvAnalysisDonutData;

    return (
      <div
        className="container"
        style={{
          maxWidth: '2500px',
          paddingLeft: '10px',
          paddingRight: '10px',
          minHeight: '668px',
          background: '#ffff'
        }}
      >
        {/* Table start */}
        <div className="clearfix">
          <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
            {/* Header code */}
            <OrrHeader chartTitle={"Student | Error Analysis Report"}
              selectedFilter={this.props.selectedFilter}
              studentDetails={this.props.studentDetails}
              navSelected={this.props.navSelected}
            />
            {/* error analysis chart start */}
            <tbody>
              <tr>
                <td>
                  <div className="sea-wrapper pt-100 print-wrap-21-20">
                    <div class="chart-btm-bor2-print"></div>
                    <div class="chart-btm-bor3-print"></div>
                    <div className="error-section-print">
                      <span className="vert-error-txt">Error</span>
                    </div>
                    <div className="error-analysis-section-print bor-btm">
                      <p>Error Analysis</p>
                    </div>
                    <div className="avg-col-txt-print">
                      <p>Average</p>
                    </div>
                    <div className="sea-scroller-print">
                      <div className="sea-table sea-table-print">
                        <div>
                          {/* Substitution start */}
                          <div className="first-panel top-border">
                            <span className="sea-sticky-col pos-rel">
                              Substitution
                            <span className="row-strip-1 strip-bg-1" />
                            </span>
                            <span>
                              {substitutionArray.map((substitution, value) => (
                                <span
                                  key={value}
                                  className={
                                    'mid-size-td ' +
                                    (value <= 4 ? 'one ' : 'one two')
                                  }
                                >
                                  {substitution.value}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-gray ">
                              {average.substitutionAverage}
                            </span>
                          </div>
                          {/* Substitution end */}
                          {/* Omission start */}
                          <div className="first-panel">
                            <span className="sea-sticky-col pos-rel">
                              Omission
                            <span className="row-strip-1 strip-bg-2" />
                            </span>
                            <span>
                              {omissionArray.map((omission, value) => (
                                <span
                                  className={
                                    'mid-size-td ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {omission.value}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-gray">
                              {average.ommissionAverage}
                            </span>
                          </div>
                          {/* Omission end */}
                          {/* Insertion start */}
                          <div className="first-panel">
                            <span className="sea-sticky-col pos-rel">
                              Insertion
                            <span className="row-strip-1 strip-bg-3" />
                            </span>
                            <span>
                              {insertionArray.map((insertion, value) => (
                                <span
                                  className={
                                    'mid-size-td ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {insertion.value}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-gray">
                              {average.insertionAverage}
                            </span>
                          </div>
                          {/* Insertion end */}
                          {/* Told start */}
                          <div className="first-panel">
                            <span className="sea-sticky-col pos-rel">
                              Told
                            <span className="row-strip-1 strip-bg-4" />
                            </span>
                            <span>
                              {toldArray.map((told, value) => (
                                <span
                                  className={
                                    'mid-size-td  ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {told.value}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-gray">
                              {average.toldAverage}
                            </span>
                          </div>
                          {/* Told end */}
                          {/* Repetition start */}
                          <div className="first-panel">
                            <span className="sea-sticky-col pos-rel">
                              Repetition
                            <span className="row-strip-1 strip-bg-5" />
                            </span>
                            <span>
                              {repetationArray.map((repetation, value) => (
                                <span
                                  className={
                                    'mid-size-td  ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {repetation.value}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-gray">
                              {average.repetationAverage}
                            </span>
                          </div>

                          {/* Repetition end */}
                          {/* Self-Correction start */}
                          <div className="first-panel">
                            <span className="sea-sticky-col pos-rel">
                              Self-Correction
                            <span className="row-strip-1 strip-bg-6" />
                            </span>
                            <span>
                              {selfCorrectionArray.map(
                                (selfCorrection, value) => (
                                  <span
                                    className={
                                      'mid-size-td  ' +
                                      (value <= 4 ? 'one' : 'one two')
                                    }
                                  >
                                    {selfCorrection.value}
                                  </span>
                                )
                              )}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-gray">
                              {average.selfCorrectionAverage}
                            </span>
                          </div>
                        </div>
                        {/* Self-Correction end */}
                        {/* Meaning Cues start */}
                        <div>
                          <div className="second-panel msv-col-bg">
                            <span className="sea-sticky-col pos-rel">
                              Meaning
                            <span className="row-strip-1 strip-bg-7" />
                            </span>
                            <span>
                              {meaningCuesArray.map((meaningCues, value) => (
                                <span
                                  className={
                                    'mid-size-td  ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {meaningCues.value !== null
                                    ? meaningCues.value + '%'
                                    : dashSymbol}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-darkgray">
                              {average.meaningCuesAverage !== null
                                ? average.meaningCuesAverage + '%'
                                : dashSymbol}
                            </span>
                          </div>
                          {/* Meaning Cues end */}
                          {/* Structural Cues start */}
                          <div className="second-panel msv-col-bg">
                            <span className="sea-sticky-col pos-rel">
                              Structural
                            <span className="row-strip-1 strip-bg-7" />
                            </span>
                            <span>
                              {structuralCuesArray.map(
                                (structuralCues, value) => (
                                  <span
                                    className={
                                      'mid-size-td  ' +
                                      (value <= 4 ? 'one' : 'one two')
                                    }
                                  >
                                    {structuralCues.value !== null
                                      ? structuralCues.value + '%'
                                      : dashSymbol}
                                  </span>
                                )
                              )}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-darkgray">
                              {average.structuralCuesAverage !== null
                                ? average.structuralCuesAverage + '%'
                                : dashSymbol}
                            </span>
                          </div>
                          {/* Structural Cues end */}
                          {/* Visual Cues start */}
                          <div className="second-panel msv-col-bg">
                            <span className="sea-sticky-col pos-rel">
                              Visual
                            <span className="row-strip-1 strip-bg-7" />
                            </span>
                            <span>
                              {visualCuesArray.map((visualCues, value) => (
                                <span
                                  className={
                                    'mid-size-td  ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {visualCues.value !== null
                                    ? visualCues.value + '%'
                                    : dashSymbol}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-darkgray">
                              {average.visualCuesAverage !== null
                                ? average.visualCuesAverage + '%'
                                : dashSymbol}
                            </span>
                          </div>
                          {/* Visual Cues end */}
                          {/* Omission & Tolds start */}
                          <div className="second-panel msv-col-bg">
                            <span className="sea-sticky-col pos-rel">
                              Omission &amp; Tolds
                            <span className="row-strip-1 strip-bg-7" />
                            </span>
                            <span>
                              {omissionToldsArray.map((omissionTolds, value) => (
                                <span
                                  className={
                                    'mid-size-td ' +
                                    (value <= 4 ? 'one' : 'one two')
                                  }
                                >
                                  {omissionTolds.value !== null
                                    ? omissionTolds.value + '%'
                                    : dashSymbol}
                                </span>
                              ))}
                            </span>
                            <span className="sea-sticky-colr-print avg-bg-darkgray">
                              {average.ommissionToldsAverage !== null
                                ? average.ommissionToldsAverage + '%'
                                : dashSymbol}
                            </span>
                          </div>
                        </div>
                        {/* Omission & Tolds end */}
                        <div className="no-hover pag-row">
                          <span
                            style={{ width: '128px' }}
                            className="pp-print pagination-set1-print"
                          >
                            <span>
                              <img src={
                                this.props.icon.firstIcon
                                  ? FirstActiveArrow
                                  : FirstArrow
                              } />
                            </span>
                            <span className="pag-prev-img">
                              <img
                                src={
                                  this.props.icon.previousIcon
                                    ? PreviousActiveArrow
                                    : PreviousArrow
                                }
                              />
                            </span>
                          </span>
                          <div className="wd-126-print">
                            {date.map((date, value) => (
                              <div className="date-alignment" id={value}>
                                <span
                                  id={value}
                                  className={
                                    'cursor-pointer ar1-print ' +
                                    this.proficiencyType(date.proficiency) +
                                    (value <= 4 ? ' one' : ' one two')
                                  }
                                >
                                  {date.assignmentDate}
                                  <span
                                    id={value}
                                    className={
                                      'cursor-pointer level-alignment ' +
                                      (value <= 4 ? 'one' : 'one two')
                                    }
                                  >
                                    {date.readingLevel}
                                  </span>
                                </span>
                              </div>
                            ))}
                          </div>
                          <span className="sea-sticky-colr-print pagination-set2-print">
                            <img className="pag-next-img-print"
                              src={this.props.icon.nextIcon ? NextActiveArrow : NextArrow}
                            />
                          </span>
                          <span className="sea-sticky-colrNew-print zs-new pagination-set2-print pag2 mid-size-td">
                            <img
                              src={this.props.icon.lastIcon ? LastActiveArrow : LastArrow}
                            />
                          </span>
                        </div>
                        {/* date and level start */}

                        {/* date and level end */}
                      </div>
                    </div>
                    <div className="assginment-txt">
                      <p>Assignment</p>
                    </div>
                  </div>
                  <div className="error-analysis-right-print">
                    <div>
                      {/* need to uncomment once data comes from api className={this.hideMsvChart(average)} */}
                      <div className="lf1">
                        <div className="gray-clr">
                          <h4>
                            <span className="pt-sub-font-print">
                              Error Analysis
                          </span>
                          </h4>
                        </div>

                        <div>
                          <ErrorDonutChart data={errorValueAverage} />
                        </div>
                      </div>

                      <div className="lf2">
                        <div className="gray-clr">
                          <h4>
                            {/* <i className="icon-open" /> */}
                            <span className="pt-sub-font-print">MSV Analysis</span>
                          </h4>
                        </div>
                        <div className="print-msv">
                          <MsvDonutChart data={msvValueAverage} />
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              <tr />
            </tbody>
            {/* error analysis chart end */}
          </table>
        </div>
        {/* Table end */}
      </div>
    );
  }
}

class PrintS_Error_Analysis extends Component {
  render() {
    return (
      <div>
        <ReactToPrint
          trigger={() => (
            <span className="print-icon cursor-pointer">
              <img
                className="print-space"
                src={Print}
                width="24"
                height="20"
                alt="Reference icon"
              />
            </span>
          )}
          content={() => this.componentRef}
        />
        <div style={{ display: 'none' }}>
          <LandscapeOrientation />
          <ComponentToPrint
            externalData={this.props.externalFilter}
            selectedFilter={this.props.selectedFilter}
            navSelected={this.props.navSelected}
            dataObject={this.props.dataObject}
            studentData={this.props.studentData}
            studentDetails={this.props.studentDetails}
            icon={this.props.navIcon}
            ref={el => (this.componentRef = el)}
          />
        </div>
      </div>
    );
  }
}

export default PrintS_Error_Analysis;