import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import YAxisComponent from '../../School_ORR/Sc_RLPComponents/School_RLP_Reading_Level_Component/School_RLP_Reading_Levels.jsx';
import SchoolRlpGrade from '../../School_ORR/Sc_RLPComponents/School_RLP_Grade_Column/SchoolRLPGradeColumn.jsx';
import ScSidePanel from '../../School_ORR/Sc_RLPComponents/School_Side_Panel.jsx'
import SummaryPrint from '../../../../public/assets/orr/rlp-screen/print-solid.svg';
import SchoolSidePanel from './Sch_SidePanel.jsx';
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="scRlp-safari-09-20 col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={this.props.gradeSelected ? "School | Grade  Reading Level Progress" : "School | Reading Level Progress"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <div className="row mt-10" style={{ marginTop: '15px' }}>
                                        <div className="srlp-lhs-wrap sc-rlp-wrap ipad-3col" style={{ paddingLeft: '150px' }}>
                                            <div className="wrap-srlp pos-rel ">
                                                <div className="legend_sec">
                                                    <span>Legend:</span>
                                                    <div className="gray-rect" />
                                                    <p>Grade Reading</p>
                                                    <p>Level Target</p>
                                                </div>

                                                <div className="readingLevel-srlp">Reading Level</div>
                                                <div className="grade-txt-srlp">
                                                    {this.props.currentChartInDisplay == 'SLRLP'
                                                        ? 'Grade'
                                                        : 'Classes'}
                                                </div>
                                                <div className="rhs-line-srlp" />
                                                <div className="rhs-line2-srlp" />
                                                <div className="rhs-line-btm-srlp" />
                                                <div className="rhs-line-btm1-srlp" />
                                                <YAxisComponent
                                                    axisData={this.props.axisData}
                                                />
                                                <SchoolRlpGrade
                                                    summaryFlag={this.props.summaryFlag}
                                                    monthRangeObj={this.props.monthRangeObj}
                                                    selAll={this.props.selAll}
                                                    gradesData={this.props.gradesData}
                                                    readingLevels={this.props.readingLevels}
                                                    selectedLevels={this.props.selectedLevels}
                                                    currentChartInDisplay={
                                                        this.props.currentChartInDisplay
                                                    }
                                                    totalGradeItems={this.props.totalGradeItems}
                                                    scrollIndex={this.props.scrollIndex}
                                                    scrollFlag={this.props.scrollFlag}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                    <br />
                    <br />
                    <div className="scRlp-rhs-wrap-28-20">
                        <div className="reading-target-wrap" style={{ paddingTop: '40px' }}>
                            <div className="pull-left rt-left-heading scRlp-heading-28-20">
                                {this.props.currentChartInDisplay == "SLRLP" ? (
                                    <span>
                                        Grades:&nbsp;
                                        {this.props.schoolData.grade}
                                    </span>
                                ) : this.props.currentChartInDisplay == "CLRLP" ? (
                                    <span>{this.props.schoolData.classes}</span>
                                ) : (
                                            ""
                                        )}
                            </div>
                            {/* <hr className="clearfix mb-8" /> */}
                            <div className="Readingtarget-graph txt-lft-28-20">
                                <div className="chart-details mb-10">
                                    <div className="reading-level-label mb-8 color-1">
                                        First Record Date Range:
                  <span> {this.props.schoolData.firstRecDR}</span>
                                    </div>
                                    <div className="reading-level-label color-1">
                                        Recent Record Date Range:
                  <span> {this.props.schoolData.recentRecDR}</span>
                                    </div>
                                </div>
                            </div>
                            <div
                                className="pull-right clearfix  scRlp-rostered-22-20"
                                style={{ marginBottom: "4px" }}
                            >
                                <span style={{ fontSize: "12px", fontWeight: "500" }}>
                                    No. of students rostered: {this.props.schoolData.studentRoster}
                                </span>
                            </div>
                        </div>
                        <div>
                            {this.props.schoolData.schoolSidePanelData &&
                                <SchoolSidePanel
                                    schGridData={this.props.schoolData.schoolSidePanelData}
                                />
                            }
                        </div>
                    </div>
                </div>

            </div>
        );
    }
}

class PrintScRlp extends Component {
    render() {
        return (
            <div>
                {this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={SummaryPrint}
                                    width="20"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                {!this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={Print}
                                    width="24"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}

                        axisData={this.props.axisData}
                        gradesData={this.props.gradesData}
                        readingLevels={this.props.readingLevels}
                        selectedLevels={this.props.selectedLevels}
                        currentChartInDisplay={
                            this.props.currentChartInDisplay
                        }
                        totalGradeItems={this.props.totalGradeItems}
                        scrollIndex={this.props.scrollIndex}
                        schoolData={this.props.schoolData}
                        sortData={this.props.sortData}
                        scrollFlag={this.props.scrollFlag}
                        gradeSelected={this.props.gradeSelected}
                        summaryFlag={this.props.summaryFlag}
                        monthRangeObj={this.props.monthRangeObj}
                        selAll={this.props.selAll}
                    />
                </div>
            </div>
        );
    }
}

export default PrintScRlp;