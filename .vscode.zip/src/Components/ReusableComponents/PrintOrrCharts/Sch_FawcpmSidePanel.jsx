import React, { Component } from 'react';

class SchoolFawcpmGrid extends Component {

    arrayConstruction(list, endIndex) {
        var arrayConst = list.map((data, index) => {
            return {
                header: data.className, listItems: this.schoolData(data.studentDetails, endIndex), count: data.studentDetails.length,
            }
        });
        return arrayConst
    }

    schoolData(list, endIndex) {
        var idx = 0
        var result = []
        while (idx < list.length) {
            if (idx % endIndex === 0) result.push([])
            result[result.length - 1].push(list[idx++])
        }
        return result;
    }

    dataConstruction(list, endIndex) {
        let modifiedArray =
            this.arrayConstruction(list, endIndex);

        let total = modifiedArray.map((indArray, mainInd) => {
            return indArray.listItems.map((obj, idx) => {
                return this.printTable(obj, indArray.header, indArray.count, idx)
            })
        })
        return total
    }

    studentCount(list, idx) {
        let start = 1;
        let end = 0;
        if (idx === 0) {
            start = 1;
            end = list.length;
        } else {
            start = idx * 5 - 4;
            end = list.length < 5 ? start + list.length - 1 : idx * list.length
        }
        return `${start} - ${end}`
    }


    printTable(arr, header, count, idx) {
        const dashSymbol = <span>&mdash;</span>;
        return <React.Fragment>
            <tr><th className="print-th-28-20">{header} &nbsp;&nbsp;({arr.length} Students)</th></tr>
            <tr className="print-tr-28-20">
                <th>Student</th>
                <th>Grade</th>
                <th>Level </th>
                <th>Proficiency</th>
            </tr>
            {arr.map((data, val) => {
                return <React.Fragment>
                    <tr className="crho-print">
                        <td style={{ textAlign: "left" }}>{data.firstName + ' ' + data.lastName}</td>
                        <td style={{ textAlign: "left" }}>{data.grade}</td>
                        <td style={{ textAlign: "left" }}>{data.readingLevel}</td>
                        <td style={{ textAlign: "left" }}>{data.proficiency}</td>
                    </tr>
                </React.Fragment>
            })}
        </React.Fragment>
    }

    render() {
        return (
            <React.Fragment>
                <table id="scGridId">
                    {this.dataConstruction(this.props.schGridData, 5)}
                </table>

            </React.Fragment>
        )
    }
}

export default SchoolFawcpmGrid;