import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import SchoolErrorAnalysisChart from '../../School_ORR/School_Error_Analysis/school-error-analysis-chart.jsx'
import Sc_Ea_Table from '../../School_ORR/School_Error_Analysis/school-error-grid.jsx'
import SchoolEaGrid from './Sc_EaSidepanel.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader chartTitle={"School | Error Analysis Report"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr>
                                <td>
                                    <SchoolErrorAnalysisChart
                                        seaPrint={true}
                                        firstRecord={this.props.firstRecord}
                                        allRecord={this.props.allRecord}
                                        recentRecord={this.props.recentRecord}
                                        errorRange={this.props.errorRange}
                                        msvErrorRange={this.props.msvErrorRange}
                                        showHideRecentRecord={this.props.showHideRecentRecord}
                                        SelectedErr={this.props.SelectedErr}
                                        showRecord={this.props.showRecord}
                                        disableDiv={this.props.disableDiv}
                                        dropDownData={this.props.dropDownData}
                                        selectedGrade={this.props.selectedGrade}
                                        isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                                    />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br />
                    <br />
                    <div className="scEa-rhs-wrap-28-20" style={{
                        paddingTop: '40px'
                    }}>
                        <div className="pull-left rt-left-heading scEa-heading-28-20">
                            {this.props.sideTableData.selectedRecordDetails
                                .recordTitle === "All Record's Average"
                                ? "All Records' Average"
                                : this.props.sideTableData.selectedRecordDetails
                                    .recordTitle}
                        </div>
                        <div className="pos-rel">
                            <div className="rt-rhs-strip"></div>
                            {/* <hr className="clearfix mb-8" /> */}
                        </div>
                        <div className="mb-10 txt-lft-28-20">
                            <div className="reading-level-label mb-8 color-1">
                                First Record Date Range:
                         <span> {this.props.sideTableData.selectedRecordDetails
                                    .firstRecordDateRange
                                }
                                </span>
                            </div>
                            <div className="reading-level-label color-2">
                                Recent Record Date Range:
                        <span> {
                                    this.props.sideTableData.selectedRecordDetails
                                        .recentRecordDateRange
                                }
                                </span>
                            </div>
                        </div>
                        <div className="pull-right clearfix new-mb-4 rt-label-txt scEa-rostered-22-20">
                            <span className="rt-label">
                                No. of students rostered:
                    <span> {
                                    this.props.sideTableData.selectedRecordDetails
                                        .noOfStudentsRoastered
                                }
                                </span>
                            </span>
                        </div>

                        {this.props.sideTableData.tableData &&
                            <SchoolEaGrid
                                schGridData={this.props.sideTableData.tableData}
                            />}
                    </div>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintScEa extends Component {
    render() {
        return (
            <div>
                <ReactToPrint
                    trigger={() => (
                        <span className="print-icon cursor-pointer">
                            <img
                                className="print-space"
                                src={Print}
                                width="24"
                                height="20"
                                alt="Reference icon"
                            />
                        </span>
                    )}
                    content={() => this.componentRef}
                />
                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        ref={el => (this.componentRef = el)}

                        firstRecord={this.props.firstRecord}
                        allRecord={this.props.allRecord}
                        recentRecord={this.props.recentRecord}
                        errorRange={this.props.errorRange}
                        msvErrorRange={this.props.msvErrorRange}
                        showHideRecentRecord={this.props.showHideRecentRecord}
                        SelectedErr={this.props.SelectedErr}
                        showRecord={this.props.showRecord}
                        scrollFlag={this.props.scrollFlag}
                        dropDownData={this.props.dropDownData}
                        selectedGrade={this.props.selectedGrade}
                        sideTableData={this.props.sideTableData}
                        Data={this.props.Data}
                        disableDiv={this.props.disableDiv}
                        isAllThreeMsvValuesNull={this.props.isAllThreeMsvValuesNull}
                    />
                </div>
            </div>
        );
    }
}

export default PrintScEa;