import React, { Component } from 'react';
import ReactToPrint from 'react-to-print';
import Print from '../../../../public/assets/orr/rlp-screen/new-print-icon.svg';
import SummaryPrint from '../../../../public/assets/orr/rlp-screen/print-solid.svg';
import OrrHeader from './OrrHeader.jsx';
import './Charts.css';
import Class_RLP from '../../Class_ORR/ChartComponents/Class_RLP.jsx'
import RlpGrid from '../../Class_ORR/ChartComponents/RLP_Grid.jsx'
import { LandscapeOrientation } from '../LandscapeOrientation';

class ComponentToPrint extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div
                className="container bg-white"
                style={{
                    maxWidth: '2000px',
                    paddingLeft: '10px',
                    paddingRight: '10px'
                }}
            >
                {/* Table start */}
                <div className="clearfix">
                    <table className="col-md-12 table-bordered print_table-view" style={{ width: '100%' }}>
                        {/* Header code */}
                        <OrrHeader
                            chartTitle={"Class | Reading Level Progress"}
                            selectedFilter={this.props.selectedFilter}
                            studentDetails={this.props.studentDetails}
                            navSelected={this.props.navSelected}
                        />

                        <tbody>
                            <tr className="cRlp-tr-14-20"
                            // style={{
                            //     height: '595px'
                            // }}
                            >
                                <td>
                                    <Class_RLP
                                        summaryFlag={this.props.summaryFlag}
                                        monthRangeObj={this.props.monthRangeObj}
                                        selAll={this.props.selAll}
                                        toggleData={this.props.toggleData}
                                        class_rlp_object={this.props.Class_RLP_Object}
                                        selectedBubs={this.props.selectedBubs}
                                    />

                                </td>
                            </tr>

                            <tr className="cRlp-tr-14-20 cRlp-wrap-02-20">
                                <td style={{
                                    paddingTop: '40px'
                                }}>
                                    <RlpGrid
                                        scrollFlag={true}
                                        gridData={this.props.gridData}
                                        Data={this.props.Data}
                                        gridFilterData={
                                            this.props.gridFilterData
                                        }
                                        rosterCount={this.props.rosterCount}
                                        PieChartData={this.props.PieChartData}
                                        DonutFlag={this.props.DonutFlag}
                                        gridHeaderData={
                                            this.props.gridHeaderData
                                        }
                                        gridTitle={this.props.gridTitle} />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                {/* Table end */}
            </div>
        );
    }
}

class PrintCRlp extends Component {
    render() {
        return (
            <React.Fragment>
                {this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={SummaryPrint}
                                    width="20"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }
                {!this.props.summaryFlag &&
                    <ReactToPrint
                        trigger={() => (
                            <span className="class_print-icon cursor-pointer">
                                <img
                                    className="print-space"
                                    src={Print}
                                    width="24"
                                    height="20"
                                    alt="Reference icon"
                                />
                            </span>
                        )}
                        content={() => this.componentRef}
                    />
                }

                <div style={{ display: 'none' }}>
                    <LandscapeOrientation />
                    <ComponentToPrint
                        summaryFlag={this.props.summaryFlag}
                        selectedFilter={this.props.selectedFilter}
                        studentDetails={this.props.studentDetails}
                        navSelected={this.props.navSelected}
                        Class_RLP_Object={this.props.Class_RLP_Object}
                        selectedBubs={this.props.selectedBubs}
                        gridData={this.props.gridData}
                        Data={this.props.Data}
                        gridFilterData={
                            this.props.gridFilterData
                        }
                        rosterCount={this.props.rosterCount}
                        PieChartData={this.props.PieChartData}
                        DonutFlag={this.props.DonutFlag}
                        gridHeaderData={
                            this.props.gridHeaderData
                        }
                        gridTitle={this.props.gridTitle}
                        monthRangeObj={this.props.monthRangeObj}
                        selAll={this.props.selAll}
                        toggleData={this.props.toggleData}
                        // width={this.props.width}
                        // height={this.props.height}
                        // StudentFluencyState={this.props.StudentFluencyState}
                        ref={el => (this.componentRef = el)}
                    />
                </div>

            </React.Fragment >);
    }
}

export default PrintCRlp;