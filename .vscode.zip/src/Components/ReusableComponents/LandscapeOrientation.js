import React from 'react'
export const LandscapeOrientation = () =>(
    <style type="text/css">
      {"@media print{@page {size: landscape}* { overflow: visible !important; }}"}
      {"html, body, #appServerContainer{background:#fff !important;}"}
      {"html, body, #appServerContainer{background-image:none !important;}"}
      {"html.reporting body #appServerContainer{background-image:none !important;}"}
    </style>
);