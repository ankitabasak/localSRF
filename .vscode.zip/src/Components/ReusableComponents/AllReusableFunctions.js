import { getMonthName } from "../../Utils/DatePicker/helpers";
import {
  TeachersList_From_Roster_Details,
  ClassList_From_Roster_Details,
} from "../../Redux_Reducers/U_reducer_functions_to_returnSate";
import { DISPLAY_LOCAL_TIME_IN_UI } from "../../Utils/globalVars";

import { getGradesListIfNoTeachersFindInside, newDateHandling } from "./AllReusableFunctions_Two";


var date_sort_desc = function (date1, date2) {
  // This is a comparison function that will result in dates being sorted in
  // DESCENDING order

  date1 = newDateHandling(date1.endDate);
  date2 = newDateHandling(date2.endDate);

  if (date1 > date2) return -1;
  if (date1 < date2) return 1;
  return 0;
};

export const Sort_Roster_Tests = (List) => {
  return List.sort(function (one, two) {
    let date1 = one.subEndTimestamp;
    let date2 = two.subEndTimestamp;
    return date1 > date2 ? -1 : date1 < date2 ? 1 : 0;
  });
};
/**
 *
 * @param {Array} Arr
 * @param {String} sortfield
 * @returns {Array}
 * it will return the sorted array of response payload.
 */

export function Sort_ApiResponse_Payload_Array(Arr, sortfield) {
  if (Arr) {
    if (sortfield == "summary" || sortfield == "termId") {
      let Valueis = sortfield == "summary" ? "standardAndStrandName" : "termId";
      const SortedArr = Arr.sort(function (a, b) {
        const FirstElement = a[Valueis]; //a.standardAndStrandName;
        const SecondElement = b[Valueis]; //b.standardAndStrandName;
        let comparison = 0;
        if (FirstElement > SecondElement) {
          comparison = 1;
        } else if (FirstElement < SecondElement) {
          comparison = -1;
        }
        return comparison;
      });
      return SortedArr;
    } else if (sortfield == "grades") {
      let NewCompleteGradesArray = [];
      if (Arr.length > 1) {
        let StringArray = Arr.filter((item) => !hasNumber(item.grade));
        StringArray.sort(function (a, b) {
          if (a.grade < b.grade) {
            return -1;
          }
          if (a.grade > b.grade) {
            return 1;
          }
          return 0;
        });
        let NumberArray = Arr;
        if (Arr.length > 1) {
          NumberArray = Arr.filter((item) => hasNumber(item.grade));
          NumberArray.sort(function (a, b) {
            /*    if (a.grade < b.grade) { return 1; }
                           if (a.grade > b.grade) { return -1; }
                           return 0; */
            const aPart = a.grade.match(/\d+|\D+/g);
            const bPart = b.grade.match(/\d+|\D+/g);
            let i = 0;
            let len = Math.min(aPart.length, bPart.length);
            while (i < len && aPart[i] === bPart[i]) {
              i++;
            }
            if (i === len) {
              return aPart.length - bPart.length;
            }
            if (hasNumber(aPart[i]) && hasNumber(bPart[i])) {
              return bPart[i] - aPart[i];
            }
            return aPart[i].localeCompare(bPart[i]);
          });
        }
        NewCompleteGradesArray = NumberArray.concat(StringArray);
      } else {
        NewCompleteGradesArray = Arr;
      }
      return NewCompleteGradesArray;
      function hasNumber(myString) {
        return /\d/.test(myString);
      }
    } else if (sortfield == "s_linechartlist" || sortfield == "single_Test") {
      let SOrtedArrayIs = Arr.sort(function (date1, date2) {
        // This is a comparison function that will result in dates being sorted in
        // DESCENDING order.
        date1 =
          sortfield == "single_Test"
            ? newDateHandling(date1.testEndDate)
            : newDateHandling(date1.endDate);
        date2 =
          sortfield == "single_Test"
            ? newDateHandling(date2.testEndDate)
            : newDateHandling(date2.endDate);

        if (date1 > date2) {
          return -1;
        } else if (date1 < date2) {
          return 1;
        } else return 0;
      });
      return SOrtedArrayIs;
    } else {
      const SortedArr = Arr.sort(function (a, b) {
        const FirstElement = ReturnSortValue(a, sortfield);
        const SecondElement = ReturnSortValue(b, sortfield);
        let comparison = 0;
        if (FirstElement > SecondElement) {
          comparison = 1;
        } else if (FirstElement < SecondElement) {
          comparison = -1;
        }
        return comparison;
      });
      return SortedArr;
    }
  } else return [];
}

/**
 *
 * @param {Array} ReqArray
 * @param {String} Object_ID
 * @returns {Object}
 *
 * will return array object whose id is matched with request param.
 */
export function ReturnObjectOf_Matcheditem_In_The_Array(ReqArray, Object_ID) {
  let OBJ = {};
  for (var i = 0; i < ReqArray.length; i++) {
    let arrayItem = ReqArray[i];
    if (arrayItem.id == Object_ID) {
      OBJ = JSON.parse(JSON.stringify(arrayItem));
      break;
    }
  }
  delete OBJ.grades;
  return OBJ;
}

function ReturnSortValue(Object, sortfield) {
  let valuesis =
    sortfield == "grades"
      ? Object.grade
      : sortfield == "classlist" || sortfield == "schoolslist"
      ? Object.name
      : sortfield == "studentslist" || sortfield == "teacherlist"
      ? Object.lastName
      : sortfield == "classlist_for_Nav"
      ? Object.className
      : sortfield == "testslist"
      ? Object.subEndTimestamp
      : sortfield == "classlistOnStrands" || sortfield == "classlistOnTS"
      ? Object.className
      : sortfield == "school_listOnStrands" ||
        sortfield == "school_listOnTS" ||
        sortfield == "school_listOnsummary"
      ? Object.schoolName
      : sortfield == "strands"
      ? Object.strandName
      : sortfield == "linechartlist"
      ? Object.avgSubmittedTimeStamp
      : sortfield == "s_linechartlist"
      ? Object.endDate
      : sortfield == "testslist_roster"
      ? Object.subEndTimestamp
      : sortfield === "view"
      ? Object.view
      : Object.endDate;
  sortfield == "s_linechartlist" ||
  sortfield == "single_Test" ||
  sortfield == "testslist_roster"
    ? (valuesis = newDateHandling(valuesis))
    : null;

  if (valuesis !== null) {
    return valuesis.toString().toUpperCase();
  } else {
    return valuesis;
  }
}

/**
 *
 * @param {Array Items List} Arr
 * sort (Desc Order) array based on true or false .
 * so checked items will come first and then false items will come in the list.
 */

export function SortArrayBaseOnTrueOrFalse(Arr) {
  let SortedArr = Arr.sort(function (a, b) {
    const FirstElement = a.check == undefined ? false : a.check;
    const SecondElement = b.check == undefined ? false : b.check;
    let comparison = 0;
    if (FirstElement > SecondElement) {
      comparison = 1;
    } else if (FirstElement < SecondElement) {
      comparison = -1;
    }
    return comparison * -1;
  });
  return SortedArr;
}
/**
 *
 * @param {Test List Array} Arr
 * @param {True Or False} value
 * when user checks or unchecks All test items.
 */
export function CheckOrUncheckAllValuesOfTestArray(
  Arr,
  value,
  componentFromAssessment
) {
  return Arr.map((item, i) => {
    if (componentFromAssessment) {
      if (item.componentCode == componentFromAssessment) {
        return { ...item, check: true };
      } else {
        return { ...item, check: false };
      }
    } else {
      return { ...item, check: value };
    }
  });
}

/**
 *
 * @param {Array} items --Array List.
 * @param {string} sortType -- desc/asc
 * @returns {Array}
 */
export function SortArray(items, Column, sortType) {
  Column = Column == "Date Submitted" ? "endDate" : Column;
  let Arr = items.sort(function (a, b) {
    let FirstElement =
      Column == "standardAvg" ||
      Column == "lastName" ||
      Column == "endDate" ||
      Column == "studentPectgComplete" ||
      Column == "testResults" ||
      Column == "schoolScore"
        ? a[Column]
        : a[Column].toString().toUpperCase();
    let SecondElement =
      Column == "standardAvg" ||
      Column == "lastName" ||
      Column == "endDate" ||
      Column == "studentPectgComplete" ||
      Column == "testResults" ||
      Column == "schoolScore"
        ? b[Column]
        : b[Column].toString().toUpperCase();
    if (
      Column == "testStartDate" ||
      Column == "testEndDate" ||
      Column == "endDate"
    ) {
      FirstElement = newDateHandling(FirstElement);
      SecondElement = newDateHandling(SecondElement);
    }
    let comparison = 0;
    if (FirstElement > SecondElement) {
      comparison = 1;
    } else if (FirstElement < SecondElement) {
      comparison = -1;
    }
    return sortType == "desc" ? comparison * -1 : comparison;
  });
  return Arr;
}

export function SortArrayTestScore(items, Column, sortType) {
  let Arr = items.sort(function (a, b) {
    let FirstElement = Column == "standardAvg" ? a[Column] : a[Column];
    let SecondElement = Column == "standardAvg" ? b[Column] : b[Column];
    if (Column == "totalQuestions") {
      FirstElement = parseInt(FirstElement, 10);
      SecondElement = parseInt(SecondElement, 10);
    }
    let comparison = 0;
    if (FirstElement > SecondElement) {
      comparison = 1;
    } else if (FirstElement < SecondElement) {
      comparison = -1;
    }
    return sortType == "desc" ? comparison * -1 : comparison;
  });
  return Arr;
}

/**
 * @param {Array}  ArrayList.
 * @param {string} componentCode
 * @param {string} Req_from -- component from where we are calling this function.
 * @returns {Array}  -- Id'sList
 */

export function GetIds_of_Each_Object_In_The_Array(
  ArrayList,
  componentCode,
  Req_from
) {
  let IdsList = [];
  let nationalStandards = null;
  if (Req_from == "test_tab") {
    ArrayList.map((item) => {
      IdsList.push(item.componentCode);
    });
  } else if (Req_from == "strands_table") {
    ArrayList.map((strand) => {
      if (strand.strandName == componentCode) {
        nationalStandards = [];
        strand.standards.map((standards) => {
          if (standards.nationalStdIds != undefined) {
            for (let ij = 0; ij < standards.nationalStdIds.length; ij++) {
              nationalStandards.push(standards.nationalStdIds[ij]);
            }
          } else {
            nationalStandards.push(standards.standardId);
          }
        });
        IdsList = [...new Set(nationalStandards)];
      }
    });
  } else if (Req_from == "forapicall") {
    nationalStandards = [];
    ArrayList.map((item) => {
      if (item.nationalStdIds != undefined) {
        for (let ij = 0; ij < item.nationalStdIds.length; ij++) {
          nationalStandards.push(item.nationalStdIds[ij]);
        }
      } else {
        nationalStandards.push(item.standardId);
      }
    });
    IdsList = [...new Set(nationalStandards)];
  }
  return IdsList;
}

/**
 *
 * @param {Object} StrandsObject
 * @returns {Object}
 * it will return request params to get students list and linechart data of selected strand in class context.
 */
export function payloadParamsFor_Class_StdList_Graph_On_Strands(StrandsObject) {
  let taxonomyRelatedStrands = Return_Taxonomy_Strand_Standards_list(
    StrandsObject.ActualList
  );
  let StrandsList = taxonomyRelatedStrands[0];
  let strandAvg = StrandsList.strandAvg;
  let strandName = StrandsList.strandName;
  let strandardsarray = GetIds_of_Each_Object_In_The_Array(
    StrandsList.standards,
    strandName,
    "forapicall"
  );
  return { StrandsList, strandAvg, strandName, strandardsarray };
}

/**
 *
 * @param {Array} array
 * we are using this to get id's of each student in the list.
 */
export function Get_Ids_Of_Student_List(array) {
  let Ids = array.map((item) =>
    item.id == null && item.studentId !== null && item.studentId !== undefined
      ? item.studentId
      : item.id
  );
  return Ids;
}

/**
 *
 * @param {Array} array
 *
 * it will return Checked/selected students.
 * not only for student will use this to get selected items in the array
 *
 */
export function Get_Selected_Students_List(array) {
  let checkedList = array.filter((item) => item.check);
  return checkedList;
}
/**
 *
 * @param {Object} Nav -- Application Navigation Details Object
 * @param {Object} Context_Data  --  Context Header Data.
 * @returns {Object} -- Request Payload Object
 */
export function Request_PayloadFor_LineChart_Data(Nav, Context_Data) {
  return {
    studentId: Nav.class ? "" : Context_Data.Student.id,
    classId: Context_Data.Class.id,
    schoolId: Context_Data.School.id,
    testIdList: [],
  };
}

/**
 *
 * @param {int} TotalPaginationCount  -- Count of Paginations for the List
 * @param {int} FromBubble --function call from bubble number.
 * @returns {Boolean}
 */

export function PageBubbleDisable(TotalPaginationCount, FromBubble) {
  if (FromBubble == 2) {
    return TotalPaginationCount < 2 ? true : false;
  } else if (FromBubble == 3) {
    return TotalPaginationCount < 3 ? true : false;
  }
}

/**
 *
 * @param {Array} ArrayList --Array
 * @param {Array} SortedArray --SortedArray of students List
 * @return {Object}
 */
export function ParamsForStudentsListTable(
  ArrayList,
  SortedArray,
  Nav,
  AchivementLevels
) {
  ArrayList = ArrayList == undefined ? [] : ArrayList;
  let sortedValue = false;
  let lessthan40Studentcount = 0;
  let l40to59Studentcount = 0;
  let l60to79Studentcount = 0;
  let totalStudentCount = 0;
  let l80Studentcount = 0;
  let totalAverageScore = 0;
  let l40to59width = 0;
  let l60to79width = 0;
  let g80width = 0;
  let l40width = 0;
  let pdfl40width = 0;
  let pdfl40to50width = 0;
  let pdfl60to79width = 0;
  let pdfg80width = 0;
  let setdefaultwidth = 48;
  let pdfdefaultwidth = 165;
  let testName = null;
  let submittedStartDate = null;
  let submittedEndDate = null;
  let AchivementLevelData =
    AchivementLevels === undefined ? [] : AchivementLevels;
  let AchivementLevel2MinValue =
    AchivementLevelData !== null && AchivementLevelData.length > 0
      ? AchivementLevelData[1]["min"]
      : 40;
  let AchivementLevel2MaxValue =
    AchivementLevelData !== null && AchivementLevelData.length > 0
      ? AchivementLevelData[1]["max"]
      : 59;
  let AchivementLevel3MinValue =
    AchivementLevelData !== null && AchivementLevelData.length > 0
      ? AchivementLevelData[2]["min"]
      : 60;
  let AchivementLevel3MaxValue =
    AchivementLevelData !== null && AchivementLevelData.length > 0
      ? AchivementLevelData[2]["max"]
      : 79;
  let AchivementLevel4MinValue =
    AchivementLevelData !== null && AchivementLevelData.length > 0
      ? AchivementLevelData[3]["min"]
      : 80;
  if (ArrayList.length > 0) {
    totalStudentCount = ArrayList.length;
  }
  for (var i in ArrayList) {
    totalAverageScore = Nav.district
      ? +totalAverageScore + +ArrayList[i].schoolScore
      : Nav.school
      ? +totalAverageScore + +ArrayList[i].classScore
      : +totalAverageScore + +ArrayList[i].testScore;
    let L40 = Nav.district
      ? ArrayList[i].schoolScore < AchivementLevel2MinValue
      : Nav.school
      ? ArrayList[i].classScore < AchivementLevel2MinValue
      : ArrayList[i].testScore < AchivementLevel2MinValue;
    let G40_L60 = Nav.district
      ? ArrayList[i].schoolScore >= AchivementLevel2MinValue &&
        ArrayList[i].schoolScore <= AchivementLevel2MaxValue
      : Nav.school
      ? ArrayList[i].classScore >= AchivementLevel2MinValue &&
        ArrayList[i].classScore <= AchivementLevel2MaxValue
      : ArrayList[i].testScore >= AchivementLevel2MinValue &&
        ArrayList[i].testScore <= AchivementLevel2MaxValue;
    let G60_L80 = Nav.district
      ? ArrayList[i].schoolScore >= AchivementLevel3MinValue &&
        ArrayList[i].schoolScore <= AchivementLevel3MaxValue
      : Nav.school
      ? ArrayList[i].classScore >= AchivementLevel3MinValue &&
        ArrayList[i].classScore <= AchivementLevel3MaxValue
      : ArrayList[i].testScore >= AchivementLevel3MinValue &&
        ArrayList[i].testScore <= AchivementLevel3MaxValue;
    let G80 = Nav.district
      ? ArrayList[i].schoolScore >= AchivementLevel4MinValue
      : Nav.school
      ? ArrayList[i].classScore >= AchivementLevel4MinValue
      : ArrayList[i].testScore >= AchivementLevel4MinValue;
    if (L40) {
      lessthan40Studentcount++;
    } else if (G40_L60) {
      l40to59Studentcount++;
    } else if (G60_L80) {
      l60to79Studentcount++;
    } else if (G80) {
      l80Studentcount++;
    }
    testName = ArrayList[i].testName;
    submittedStartDate = ArrayList[i].endDate;
    submittedEndDate = ArrayList[i].endDate;
  }
  if (lessthan40Studentcount == 0) {
    l40width = setdefaultwidth;
    pdfl40width = pdfdefaultwidth;
  } else {
    l40width = calculateWidth(lessthan40Studentcount, totalStudentCount);
    pdfl40width = calculatePdfWidth(lessthan40Studentcount, totalStudentCount);
  }
  if (l40to59Studentcount == 0) {
    l40to59width = setdefaultwidth;
    pdfl40to50width = pdfdefaultwidth;
  } else {
    l40to59width = calculateWidth(l40to59Studentcount, totalStudentCount);
    pdfl40to50width = calculatePdfWidth(l40to59Studentcount, totalStudentCount);
  }
  if (l60to79Studentcount == 0) {
    l60to79width = setdefaultwidth;
    pdfl60to79width = pdfdefaultwidth;
  } else {
    l60to79width = calculateWidth(l60to79Studentcount, totalStudentCount);
    pdfl60to79width = calculatePdfWidth(l60to79Studentcount, totalStudentCount);
  }
  if (l80Studentcount == 0) {
    g80width = setdefaultwidth;
    pdfg80width = pdfdefaultwidth;
  } else {
    g80width = calculateWidth(l80Studentcount, totalStudentCount);
    pdfg80width = calculatePdfWidth(l80Studentcount, totalStudentCount);
  }
  totalAverageScore = totalAverageScore / totalStudentCount;
  totalAverageScore = Math.round(totalAverageScore);
  if (SortedArray != undefined) {
    if (SortedArray.length >= 0 && SortedArray.length != totalStudentCount) {
      sortedValue = true;
    }
  }
  return {
    lessthan40Studentcount,
    l40width,
    l40to59Studentcount,
    l40to59width,
    l60to79Studentcount,
    l60to79width,
    l80Studentcount,
    g80width,
    totalStudentCount,
    totalAverageScore,
    testName,
    submittedStartDate,
    submittedEndDate,
    sortedValue,
    pdfl40to50width,
    pdfl40width,
    pdfl60to79width,
    pdfg80width,
  };
}

function calculatePdfWidth(value, count) {
  let totalwidth = 204;
  let calValue = (value * 100) / count;
  calValue = (totalwidth * calValue) / 100;
  calValue = 165 + calValue;
  return calValue;
}
/**
 *
 * @param {int} value  --students Count Between The Certain range. ex:less than 40,40-70 etc..
 * @param {int} count  --Total number of students.
 */
function calculateWidth(value, count) {
  let ScreenWidth = window.screen.availWidth;
  let totalwidth;
  if (ScreenWidth < 1100) {
    totalwidth = 140;
  } else {
    totalwidth = 204;
  }
  let calValue = (value * 100) / count;
  calValue = (totalwidth * calValue) / 100;
  calValue = 48 + calValue;
  return calValue;
}

/**
 *  CALLING FROM c_sp_overview.js & c_ts_overview.js.
 * @param {Array} --Array  Total Records of A graph
 * @param {int} Pagination_Start  -- Display LineChart record Starts From Pagination_Start
 * @param {int} Pagination_End -- Display LineChart record ends at Pagination_End
 * @returns {Object}
 */
export function LineChartInput_Params(
  Array,
  Pagination_Start,
  Pagination_End,
  FromComponent,
  Compare_School_List,
  Compare_District_List
) {
  const XAxis_Params = {
    LabelOffSet: 60,
    LabelName: "",
    LabelFontSize: 16,
    LabelTickFontSize: 11,
    LabelTickX_param: 15,
  };
  const YAxis_Params = {
    LabelOffset: FromComponent == "s_ts_overview" ? 50 : 30,
    LabelfontSize: 16,
    LabelName: "Test Scores (%)",
    LabelTickFontSize: 11,
    LabelTickY_param: 15,
  };
  const DatatPointParams = {
    DotRadius: 12,
    DotTextfontSize: 14,
    LinePathWidth: 1,
  };
  if (FromComponent == "s_ts_overview") {
    var tooltipParams = {
      TooltipXcoordsPad: 10,
      TooltipYcoordsPad: 130,
      TooltipDisplayVisible: true,
    };
    var margin = { left: 100, right: 0, bottom: 100, top: 40 };
    var width = 1200;
    var height = 600;
    var Ipadwidth = 920;
    var Ipadheight = 500;
  } else {
    var tooltipParams =
      FromComponent == "c_ts_overview"
        ? {
            TooltipXcoordsPad: 0,
            TooltipYcoordsPad: 10,
            TooltipDisplayVisible: false,
          }
        : FromComponent == "s_sp_overview" || FromComponent == "c_sp_overview"
        ? {
            TooltipXcoordsPad: 55,
            TooltipYcoordsPad: 100,
            TooltipDisplayVisible: true,
          }
        : {
            TooltipXcoordsPad: 80,
            TooltipYcoordsPad: 10,
            TooltipDisplayVisible: false,
          };
    var margin = { left: 70, right: 0, bottom: 100, top: 30 };
    var width = FromComponent == "c_ts_overview" ? 485 : 435;
    var height = 420;
    var Ipadwidth = 440;
    var Ipadheight = 375;
  }
  const data =
    Array !== null ? Array.slice(Pagination_Start, Pagination_End) : [];
  const dataset_2 =
    Compare_School_List !== null && Compare_School_List !== undefined
      ? Compare_School_List.slice(Pagination_Start, Pagination_End)
      : [];
  const dataset_3 =
    Compare_District_List !== null && Compare_District_List !== undefined
      ? Compare_District_List.slice(Pagination_Start, Pagination_End)
      : [];
  return {
    XAxis_Params,
    YAxis_Params,
    DatatPointParams,
    tooltipParams,
    data,
    margin,
    width,
    height,
    Ipadwidth,
    Ipadheight,
    dataset_2,
    dataset_3,
  };
}
/**
 *
 * @param {Array} FreshList -- test List Of Current activated filter instance (student/class)
 * @param {Array} existingList  -- -- test List Of last activated filter instance (student/class)
 * @param {Object} Nav  -- Navigation
 */
export function TestListComparisonAferGetItFromTheServer(
  FreshList,
  existingList,
  Nav
) {
  let FreshListAfterCheck;
  let Element = FreshList[0];
  existingList.map((exist, i) => {
    FreshList.map((freshItem, i) =>
      freshItem.componentCode == exist.componentCode
        ? (freshItem.check = exist.check)
        : freshItem
    );
  });
  return FreshList;
}

/**
 * @param {Object} Context_Header
 * Returning StudentId and Selected Tests Component ids to make an API call
 */
export function GetStudentId_And_SelectedTestList(Context_Header) {
  let firstStdId = Context_Header.Roster_Tab.StudentsList[0];
  firstStdId = firstStdId && firstStdId.id;
  let Student =
    Context_Header.Student == "All"
      ? firstStdId
      : Context_Header.Student.id == undefined
      ? Context_Header.Student.studentId
      : Context_Header.Student.id;
  let Selected_List = Context_Header.TestTab.TestList.filter(
    (item) => item.check
  );
  let SelectedTestList = GetIds_of_Each_Object_In_The_Array(
    Selected_List,
    "component",
    "test_tab"
  );
  return { Student, SelectedTestList };
}

/**
 *
 * @param {Boolean} check
 * @param {String} payloadselectedOption
 * @param {Object} reducerprop
 *
 * it will return the last selected checkbox name.
 */
export const LastClickedCheckBox = (
  check,
  payloadselectedOption,
  reducerprop
) => {
  return check
    ? payloadselectedOption
    : payloadselectedOption == "District"
    ? reducerprop.checkSchool
      ? "School"
      : reducerprop.checkClass
      ? "Class"
      : ""
    : payloadselectedOption == "School"
    ? reducerprop.checkDistrict
      ? "District"
      : reducerprop.checkClass
      ? "Class"
      : ""
    : reducerprop.checkDistrict
    ? "District"
    : reducerprop.checkSchool
    ? "School"
    : "";
};

/**
 *
 * @param {String} SelectedStrandName
 * @param {String} SelectedStandardId
 * @param {Array} strandsList
 */
export const checkForSelectedStrand_Or_StradardPresentStrandsTables = (
  SelectedStrandName,
  SelectedStandardId,
  strandsList
) => {
  let IsOptionExistIn_The_List = false;
  for (var i = 0; i < strandsList.length; i++) {
    let Strand = strandsList[i];
    if (SelectedStandardId == "" || SelectedStandardId == null) {
      if (SelectedStrandName == Strand.strandName) {
        IsOptionExistIn_The_List = true;
        break; // stop the loop
      }
    } else {
      if (IsOptionExistIn_The_List) {
        break;
      }
      for (var j = 0; j < Strand.standards.length; j++) {
        let Standards = Strand.standards[j];
        // let Standards = Strand.standards[j];
        if (Standards.standardId == SelectedStandardId) {
          IsOptionExistIn_The_List = true;
          break; // stop the loop
        }
      }
    }
  }
  return IsOptionExistIn_The_List;
};

/**
 *
 * @param {Array} districtTerms
 * @returns {Object}
 */
export function DateTab_Params_After_get_APIresponse(
  districtTerms,
  selected_term
) {
  let SelectedReportTerm,
    termStartDate,
    termEndDate,
    Selected_term_DatesList = [];
  let Terms_has_reportData = 0;
  if (selected_term !== null && selected_term !== undefined) {
    for (var i = 0; i < districtTerms.length; i++) {
      let item = districtTerms[i];
      let TermYear;
      let today = new Date();
      let TermStartYear = item.termStartDate.split(" ")[0].split("-")[0];
      let TermEndDate = GetTermEndDate(today, item);
      let TermEndYear = TermEndDate.split(" ")[0].split("-")[0];
      if (item.termRange == selected_term) {
        TermYear = selected_term;
        SelectedReportTerm = item.termRange;
        termStartDate = item.termStartDate;
        termEndDate = GetTermEndDate(today, item);
        Selected_term_DatesList = item.termDates;
      }
    }
  } else {
    for (var i = 0; i < districtTerms.length; i++) {
      let item = districtTerms[i];
      let TermYear;
      if (item.termDates !== null && item.termDates.length > 0) {
        Terms_has_reportData = Terms_has_reportData + 1;
        TermYear =
          TermYear == undefined || TermYear == null ? item.termRange : TermYear;
        if (
          SelectedReportTerm < item.termRange ||
          SelectedReportTerm == undefined
        ) {
          let today = new Date();
          SelectedReportTerm = item.termRange;
          termStartDate = item.termStartDate;
          termEndDate = GetTermEndDate(today, item);
          Selected_term_DatesList = item.termDates;
        }
      }
    }
  }
  return {
    SelectedReportTerm,
    termStartDate,
    termEndDate,
    Selected_term_DatesList,
    Terms_has_reportData,
  };
}

/**
 *
 * @param {String} SelectedReportTerm
 * @param {Array} districtTerms
 * @returns {Object}
 *
 */
export function selectedDistrict_term_Details_of_Date_Tab(
  SelectedReportTerm,
  districtTerms
) {
  let Selected_term_DatesList_ = [],
    termStartDate_,
    termEndDate_;
  districtTerms.map((item, i) => {
    if (item.termRange == SelectedReportTerm) {
      Selected_term_DatesList_ = item.termDates;
      termStartDate_ = item.termStartDate;
      let today = new Date();
      termEndDate_ = GetTermEndDate(today, item);
    }
  });
  return { Selected_term_DatesList_, termStartDate_, termEndDate_ };
}

export const GetTermEndDate = (today, item) => {
  let termEndDate;
  if (today < newDateHandling(item.termEndDate)) {

    let date =
      today.getFullYear() +
      "-" +
      (today.getMonth() + 1) +
      "-" +
      today.getDate();
    let time =
      today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    termEndDate = date + " " + time;
  } else {
    termEndDate = item.termEndDate;
  }
  return termEndDate;
};

/**
 *
 * @param {String} termEndDate
 * @param {Array} Selected_term_DatesList
 * @returns {Object}
 * To find is there dates for past 30,60,90 days report for selected reports term.
 */

export function Find_Last_30_60_90_DateRange_On_SelectedDate(
  termEndDate,
  Selected_term_DatesList,
  termStartDate
) {
  let DaysDiff;
  let days_30 = false,
    days_60 = false,
    days_90 = false;
  let startDate;
  let Custom_EndDate;
  Selected_term_DatesList.map((item) => {
    startDate = startDate == undefined ? item : startDate;
    Custom_EndDate = Custom_EndDate == undefined ? item : Custom_EndDate;
    if (startDate > item) {
      startDate = item;
    } else if (Custom_EndDate < item) {
      Custom_EndDate = item;
    }
    DaysDiff = FindDaysDifferent_Between_Dates(termEndDate, item);
    DaysDiff = parseInt(DaysDiff) + 1;

    DaysDiff < 30
      ? (days_30 = true)
      : DaysDiff > 30 && DaysDiff < 60
      ? (days_60 = true)
      : DaysDiff > 60 && DaysDiff < 90
      ? (days_90 = true)
      : null;
  });
  let date = startDate.split(" ")[0].split("-");
  let Custom_startDate = date[1] + "/" + date[2] + "/" + date[0];
  let enddate = Custom_EndDate.split(" ")[0].split("-");
  Custom_EndDate = enddate[1] + "/" + enddate[2] + "/" + enddate[0];
  return {
    days_30,
    days_60,
    days_90,
    DaysDiff,
    Custom_startDate,
    Custom_EndDate,
  };
}

/**
 *
 * @param {String} Date
 * @returns {DateFormat}
 *
 * will get it in string format from server and will convert it to calendar understandable format.
 */

export function DateFormatForCalendar_inDateTab(date) {
  let formattedDate = newDateHandling(date);
  return (
    formattedDate.getMonth() +
    1 +
    "/" +
    formattedDate.getDate() +
    "/" +
    formattedDate.getFullYear()
  );
}

/**
 *
 * @param {Array} TermTotalDates
 * @param {int} selectedMonth
 * @returns {Array}
 * it will return days number which has no data for the days in the month.
 */

export function GetDisabledDatesOfAMonth(TermTotalDates, selectedMonth) {
  selectedMonth = parseInt(selectedMonth) + 1;
  let emptyData_Days = [
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "08",
    "09",
    "10",
    "11",
    "12",
    "13",
    "14",
    "15",
    "16",
    "17",
    "18",
    "19",
    "20",
    "21",
    "22",
    "23",
    "24",
    "25",
    "26",
    "27",
    "28",
    "29",
    "30",
    "31",
  ];
  TermTotalDates.map((item) => {
    if (item.slice(5, 7) == selectedMonth) {
      let day = item.slice(8, 10);
      let index = emptyData_Days.indexOf(day);
      if (index == -1) {
      } else {
        emptyData_Days.splice(index, 1);
      }
    }
  });
  for (var i = 0; i < emptyData_Days.length; i++)
    emptyData_Days[i] = parseInt(emptyData_Days[i], 10);
  return emptyData_Days;
}

/**
 *
 * @param {String} startdate
 * @param {String} enddate
 * @returns {Object}
 */
export function FindDaysDifferent_Between_Dates(enddate, startdate) {
  let d1 = newDateHandling(enddate);
  let d2 = newDateHandling(startdate);
  let timeDiff = d1.getTime() - d2.getTime();
  let DaysDiff = timeDiff / (1000 * 3600 * 24);
  return DaysDiff + 1;
}

export function formatDate(date) {
  let d = newDateHandling(date);
  let returnDate;
  let month = pad(d.getMonth() + 1);
  let day = pad(d.getDate());
  let year = d.getFullYear();
  returnDate = year + "-" + month + "-" + day;
  return returnDate;
}

/**
 *
 * @param {Array} datesList
 * @param {String} startDate
 * @param {String} EndDate
 * @returns {Array}
 *
 * will return months number which has no reporting data.
 */

export function returnMonthsWhichHasNoreportdates(
  datesList,
  startDate,
  EndDate
) {
  let MonthsList1 = [];
  datesList.map((item1) => {
    let datesplit = item1.split(" ");
    let MonthSplit = datesplit[0].split("-");
    let Monthis = parseInt(MonthSplit[1]);
    const monthName = getMonthName(parseInt(Monthis - 1));
    const monthCapital = monthName.toUpperCase();
    let displayMonthname = monthCapital.slice(0, 3) + " " + MonthSplit[0];
    if (MonthsList1.indexOf(displayMonthname) == -1) {
      MonthsList1.push(displayMonthname);
    }
  });
  return MonthsList1;
}

/**
 *
 * @param {*} startDate
 * @param {*} EndDate
 */
export function monthnamesofPresetTurm(startDate, EndDate) {
  var Name_of_monthsList = [];
  const startYear = newDateHandling(startDate).getFullYear();
  const endYear = newDateHandling(EndDate).getFullYear();
  const StartYearForMonths = newDateHandling(startDate).getMonth();
  const EndYearForMonths = newDateHandling(EndDate).getMonth() + 1;
  var MonthAndYear = "";
  for (var i = startYear; i <= endYear; i++) {
    if (i == startYear) {
      for (var j = StartYearForMonths; j < 12; j++) {
        MonthAndYear = `${GetOnlyMonthName(j)} ${i}`;
        Name_of_monthsList.push(MonthAndYear);
      }
    } else if (i <= endYear) {
      if (i == endYear) {
        for (var k = 0; k < EndYearForMonths; k++) {
          MonthAndYear = `${GetOnlyMonthName(k)} ${i}`;
          Name_of_monthsList.push(MonthAndYear);
        }
      } else {
        for (var l = 0; l < 12; l++) {
          MonthAndYear = `${GetOnlyMonthName(l)} ${i}`;
          Name_of_monthsList.push(MonthAndYear);
        }
      }
    }
  }
  return Name_of_monthsList;
}
function GetOnlyMonthName(i) {
  const monthName = getMonthName(i);
  const monthCapital = monthName.toUpperCase();
  let displayMonthname = monthCapital.slice(0, 3);
  return displayMonthname;
}

/**
 *
 * @param {String} selectedRange
 * @param {Array} selectedTerm_dates
 */

export function Datetab_Data_on_selectedRange(
  selectedRange,
  selectedTerm_dates,
  termEnddate
) {
  let termstartDate = "",
    datesrangearray = [];
  selectedTerm_dates.map((item, i) => {
    let daysdifference = FindDaysDifferent_Between_Dates(termEnddate, item);
    if (daysdifference <= 30) {
      termstartDate = TermStartDate(termstartDate, item);
      datesrangearray.push(item);
    } else if (daysdifference <= 60) {
      termstartDate = TermStartDate(termstartDate, item);
      datesrangearray.push(item);
    } else if (daysdifference <= 90) {
      termstartDate = TermStartDate(termstartDate, item);
      datesrangearray.push(item);
    }
  });

  let StartDateArray = termstartDate.split("-");
  const monthName = getMonthName(parseInt(StartDateArray[1]));
  const monthCapital = monthName.toUpperCase();
  let Active_Month = monthCapital.slice(0, 3) + " " + StartDateArray[0];
  let startdate_to_show_in_calendar =
    StartDateArray[1] + "/" + StartDateArray[2] + "/" + StartDateArray[3];
  let DisabledDatesInCalendar = GetDisabledDatesOfAMonth(
    datesrangearray,
    StartDateArray[1]
  );
  return {
    termstartDate,
    datesrangearray,
    Active_Month,
    startdate_to_show_in_calendar,
    DisabledDatesInCalendar,
  };
}

/**
 *
 * @param {String} termstartDate
 * @param {String} item
 * to find term start date.
 */
const TermStartDate = (termstartDate, item) => {
  return termstartDate == ""
    ? item
    : termstartDate > item
    ? item
    : termstartDate;
};

/**
 *
 * @param {Array} TotalMonthsOfTerm
 * @param {Array} DataIsThereForMonths
 * @returns {Array}
 */

export function SortMonthsNamewhichHasReports(
  TotalMonthsOfTerm,
  DataIsThereForMonths
) {
  let SortedArray = [];
  for (let index = 0; index < TotalMonthsOfTerm.length; index++) {
    const element = TotalMonthsOfTerm[index];
    if (DataIsThereForMonths.indexOf(element) !== -1) {
      SortedArray.push(element);
    }
    if (SortedArray.length === DataIsThereForMonths.length) {
      break;
    }
  }
  return SortedArray;
}
/**
 *
 * @param {String} SelectedStrandName
 * @param {String} SelectedStandardId
 * @param {Array} strandsList
 */
export function CheckForStrandId_And_StrandName_InThe_StrandsList(
  SelectedStrandName,
  SelectedStandardId,
  strandsList,
  sel_Taxonomy,
  Txn_Obj,
  sel_Ques_No,
  TestAssessment_Obj
) {
  let StrandNameisThere = false;
  let StandardIdIsThere = false;
  if (
    Txn_Obj !== undefined
      ? Txn_Obj.TaxonomyList.find((ele) => ele == sel_Taxonomy) &&
        (TestAssessment_Obj.MaxTestAssessmentCount > sel_Ques_No ||
          TestAssessment_Obj.MaxTestAssessmentCount == sel_Ques_No)
      : true
  ) {
    for (var i = 0; i < strandsList.length; i++) {
      let Strand = strandsList[i];
      if (Strand.strandName == SelectedStrandName) {
        StrandNameisThere = true;
        for (var j = 0; j < Strand.standards.length; j++) {
          let standard = Strand.standards[j];
          if (standard.standardId == SelectedStandardId) {
            StandardIdIsThere = true;
          }
        }
      }

      if (StrandNameisThere) {
        break;
      }
    }
  } else {
    sel_Taxonomy = Txn_Obj.selectedTaxonomy;
    sel_Ques_No = TestAssessment_Obj.selectedTestAssessment;
  }
  return { StrandNameisThere, StandardIdIsThere, sel_Taxonomy, sel_Ques_No };
}

/**
 *
 * @param {Array} TestTypeList
 */
export function getTestTypes(TestTypeList = []) {
  let testTypes = [];
  for (const { testTypeId, testTypeName } of TestTypeList) {
    const alreadyInTestTypes = testTypes.some(
      (testType) =>
        testType.testTypeId === testTypeId &&
        testType.testTypeName === testTypeName
    );
    if (!alreadyInTestTypes) {
      let check = true;
      testTypes.push({ testTypeId, testTypeName, check });
    }
  }
  return testTypes;
}

/**
 *
 * @param {Array} selectedTests
 * @param {Object} TestTypeObject
 * @returns {Object}
 *
 */
export function TestTypeOnTestSelectionAction(selectedTests, TestTypesList) {
  for (var i = 0; i < TestTypesList.length; i++) {
    let TestTypeExist = false;
    let TestType = TestTypesList[i];
    for (var j = 0; j < selectedTests.length; j++) {
      let Test = selectedTests[j];
      if (Test.testTypeId == TestType.testTypeId) {
        TestTypeExist = true;
        break;
      }
    }
    if (TestTypeExist) {
      TestTypeExist = false;
      TestTypesList[i].check = true;
    } else {
      TestTypesList[i].check = false;
    }
  }
  let TestTypes = TestTypesList;
  let SelectedTestTypes = TestTypes.filter((item) => item.check);
  return { TestTypes, SelectedTestTypes };
}

/**
 *
 * @param {Array} TestList
 * @returns {Object}
 */
export function TestTypes_And_Selected_TsTypes_On_TestList(TestList = []) {
  let TestTypes = getTestTypes(TestList);
  let SelectedTests = TestList.filter((tst) => tst.check);
  let TesttypesRes_ = TestTypeOnTestSelectionAction(SelectedTests, TestTypes);
  TestTypes = TesttypesRes_.TestTypes;
  let SelectedTestTypes = TesttypesRes_.SelectedTestTypes;
  let TestsOnContext = "All (" + TestList.length + ")";
  if (SelectedTests.length !== TestList.length) {
    if (SelectedTestTypes.length == 1) {
      TestsOnContext =
        SelectedTestTypes[0].testTypeName + " (" + SelectedTests.length + ")";
    } else {
      TestsOnContext = "Custom (" + SelectedTests.length + ")";
    }
  } else if (TestList.length == 1) {
    TestsOnContext = TestList[0].testName;
  }
  return { SelectedTests, TestTypes, SelectedTestTypes, TestsOnContext };
}

/**
 *
 * @param {Array} Arr1
 * @param {Array} Arr2
 *
 * its will check for
 *
 */
export function Check_Previous_Report_List_Modified_Or_Not(Arr1, Arr2) {
  let Modified = false;
  for (var i = 0; i < Arr1.length; i++) {
    let Arr2_item = Arr2.find((item) => item.id == Arr1[i].id);
    if (Arr2_item == undefined) {
    } else if (Arr2_item.check == Arr1[i].check) {
    } else {
      Arr1[i].check = Arr2_item.check;
      Modified = true;
    }
  }
  return { Modified, Arr1 };
}

/**
 *
 * @param {Array} Arr1
 * @param {Array} Arr2
 *
 * @returns {Boolean}
 */
export function checkIsTwo_Test_Arraya_Same(Arr1, Arr2) {
  let ArryisNotMatch = false;
  for (var i = 0; i < Arr1.length; i++) {
    let Test1 = Arr1[i];
    let testisMatched = false;
    for (var j = 0; j < Arr2.length; j++) {
      let Test2 = Arr2[j];
      if (Test1.componentCode == Test2.componentCode) {
        testisMatched = true;
        break;
      }
    }
    if (!testisMatched) {
      ArryisNotMatch = true;
      break;
    }
  }
  return ArryisNotMatch;
}

export function Return_Taxonomy_Strand_Standards_list(strandsList) {
  // taxonomy related updates start
  let InitialLoadStrandTaxonomyList = { ...strandsList };
  // get taxonomies
  let InitialLoadTaxonomyList = [];
  InitialLoadStrandTaxonomyList.strands.map((strand) => {
    strand.standards.map((initial_single_standard) => {
      InitialLoadTaxonomyList.push(initial_single_standard.taxonomy);
    });
  });
  InitialLoadTaxonomyList = [...new Set(InitialLoadTaxonomyList)];
  // end get taxonomies
  InitialLoadStrandTaxonomyList.strands = InitialLoadStrandTaxonomyList.strands
    .map((strand) => {
      return {
        ...strand,
        standards: [
          ...strand.standards.filter(
            (single_taxonomy_standard) =>
              single_taxonomy_standard.taxonomy == InitialLoadTaxonomyList[0]
          ),
        ],
      };
    })
    .filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);
  return InitialLoadStrandTaxonomyList.strands;
}

/**
 *
 * @param {Array} Teachers
 * @returns {Object}
 */
export function Return_Teacher_Class_On_Selection(
  Teachers,
  Selectedoption,
  selectionon,
  U_Roster
) {
  let selectedTeacher;
  let Class;
  let Student = selectionon == "onstudent" ? Selectedoption : "All";
  for (var i = 0; i < Teachers.length; i++) {
    let Teacher = Teachers[i];
    let Classes = Teacher.classes;
    for (var j = 0; j < Classes.length; j++) {
      let Id =
        selectionon == "onstudent"
          ? Selectedoption.classId
          : Selectedoption.classId == undefined
          ? Selectedoption.id
          : Selectedoption.classId;
      if (Classes[j].id == Id) {
        Class = JSON.parse(JSON.stringify(Classes[j]));
        selectedTeacher = JSON.parse(JSON.stringify(Teacher));
        break;
      }
    }
  }
  if (
    selectedTeacher === undefined ||
    (selectedTeacher === null && selectionon == "onstudent")
  ) {
    selectedTeacher = U_Roster.SelectedTeacher;
    Class = U_Roster.SelectedClass;
  }
  return { selectedTeacher, Class, Student };
}

export function check_Selected_item_Of_Array(
  ArrayList,
  selecteditem,
  actionfor
) {
  let SelectedSchool;
  if (actionfor == "forschool") {
    ArrayList.map((item) => {
      if (item.id == selecteditem.schoolId) {
        item.check = true;
        SelectedSchool = JSON.parse(JSON.stringify(item));
        delete SelectedSchool.grades;
      } else {
        item.check = false;
      }
    });
    return { SelectedSchool, ArrayList };
  } else {
    ArrayList.map((item) => {
      if (item.id == selecteditem.id) {
        item.check = true;
      } else {
        item.check = false;
      }
    });
    return ArrayList;
  }
}

export function RemoveDuplicateObjectsFromArray(arr, comp) {
  // return Arry
  const unique = arr
    .map((e) => e[comp])
    // store the keys of the unique objects
    .map((e, i, final) => final.indexOf(e) === i && i)
    .filter((e) => arr[e])
    .map((e) => arr[e]);
  return unique;
}

export function Sorting_To_Place_Selected_Option_First(
  Array,
  Selected_Id,
  sortOn
) {
  if (sortOn == "grade") {
    if (Selected_Id == "All") {
      return Array;
    }
    return Array.sort(function (x, y) {
      return x.grade == Selected_Id ? -1 : y.grade == Selected_Id ? 1 : 0;
    });
  } else {
    return Array.sort(function (x, y) {
      return x.id == Selected_Id ? -1 : y.id == Selected_Id ? 1 : 0;
    });
  }
}

export function Sort_By_Date(Array, SelectedTerm, sortOn) {
  return Array.sort((a, b) =>
    a.termId == SelectedTerm ? -1 : b.termId == SelectedTerm ? 1 : 0
  );
}

export function calculateStrandAvgOnTaxonimy_Filter(List) {
  List = List == null || List == undefined ? {} : List;
  let MainList =
    List.strands == undefined ? [] : JSON.parse(JSON.stringify(List.strands));
  for (var i = 0; i < MainList.length; i++) {
    let standards =
      MainList[i].standards == undefined ? [] : MainList[i].standards;
    let maxScore = 0;
    let score = 0;
    standards.map((item) => {
      maxScore += item.maxScore;
      score += item.score;
    });
    let avg = (score / maxScore) * 100;
    MainList[i].strandAvg = Math.round(avg);
  }
  List.strands = MainList;
  return List;
}

export function convertToNumberGrade(grade) {
  if (grade == "null" || grade == null) {
    return ``;
  } else {
    const value = grade.toString();
    const value2 = value.split("_")[1];
    return `${value2}`;
  }
}

export function getDateTime(datevalue) {
  var now = datevalue == undefined || datevalue == "" ? new Date() : datevalue;
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  var hour = now.getHours();
  var minute = now.getMinutes();
  var second = now.getSeconds();
  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (day.toString().length == 1) {
    day = "0" + day;
  }
  if (hour.toString().length == 1) {
    hour = "0" + hour;
  }
  if (minute.toString().length == 1) {
    minute = "0" + minute;
  }
  if (second.toString().length == 1) {
    second = "0" + second;
  }
  var dateTime =
    year + "/" + month + "/" + day + " " + hour + ":" + minute + ":" + second;
  return dateTime;
}

export function AllClassesList(ClassList) {
  let classesList = [];
  ClassList.map((classData) => classesList.push(classData.id));
  return classesList;
}
export function GetStudentIdsFor_compareOfGrade(selectedGrade, Grades) {
  let Teachers = TeachersList_From_Roster_Details(selectedGrade, Grades);
  let ClassList = ClassList_From_Roster_Details(Teachers, "All");
  let StdListIds = [];
  ClassList.map((item) => {
    let Stdlist = item.students == null ? [] : item.students;
    Stdlist.map((item1) => {
      StdListIds.push(item1.id);
    });
  });
  let UniqueStdList = [];
  StdListIds.forEach(function (item) {
    if (UniqueStdList.indexOf(item) === -1) {
      UniqueStdList.push(item);
    }
  });
  return UniqueStdList;
}

export function GetStudentIdsFor_compare(Grades) {
  let Teachers = TeachersList_From_Roster_Details("All", Grades);
  if (Teachers.length == 0) {
    return [];
  }
  let ClassList = ClassList_From_Roster_Details(Teachers, "All");
  let StdListIds = [];
  ClassList.map((item) => {
    let Stdlist = item.students == null ? [] : item.students;
    Stdlist.map((item1) => {
      StdListIds.push(item1.id);
    });
  });
  let UniqueStdList = [];
  StdListIds.forEach(function (item) {
    if (UniqueStdList.indexOf(item) === -1) {
      UniqueStdList.push(item);
    }
  });
  return UniqueStdList;
}
/**
 *
 * @param {Array} TaxonomyRelatedStandardsList
 * @param {String} sel_Taxonomy
 * @returns { Array} contains current selected taxonomy strands only.
 */
export function ReturnStrandsList_On_Taxonomy(
  TaxonomyRelatedStandardsList,
  sel_Taxonomy
) {
  TaxonomyRelatedStandardsList.strands = TaxonomyRelatedStandardsList.strands
    .map((strand, strand_index) => {
      return {
        ...strand,
        standards: [
          ...strand.standards.filter(
            (single_taxonomy_standard) =>
              single_taxonomy_standard.taxonomy == sel_Taxonomy
          ),
        ],
      };
    })
    .filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);
  return calculateStrandAvgOnTaxonimy_Filter(TaxonomyRelatedStandardsList);
}

export function ReturnTaxonomyBasedSTrandsAndStandards(
  SelectionBasedTaxonomyList,
  Selec_Taxonomyis
) {
  return SelectionBasedTaxonomyList.strands
    .map((strand) => {
      return {
        ...strand,
        standards: [
          ...strand.standards.filter(
            (single_taxonomy_standard) =>
              single_taxonomy_standard.taxonomy == Selec_Taxonomyis
          ),
        ],
      };
    })
    .filter((emptyRemovalStrands) => emptyRemovalStrands.standards.length);
}

export function Return_TeacherOf_A_Class(T_List, Sel_Class) {
  let Sel_Teachers = {};
  T_List = T_List.map((item) => {
    let classes = item.classes == null ? [] : item.classes;
    let classFind = classes.find((C_item) => C_item.id == Sel_Class.id);
    if (classFind !== undefined) {
      item.check = true;
      Sel_Teachers = item;
      return item;
    } else {
      item.check = false;
      return item;
    }
  });
  let Clss_List = Sel_Teachers.classes;
  Clss_List = Clss_List == null || Clss_List == undefined ? [] : Clss_List;

  Clss_List.map((item) => {
    if (item.id == Sel_Class.id) {
      item.check = true;
    } else {
      item.check = false;
    }
  });

  let Std_List = Sel_Class.students;
  Std_List = Std_List == null || Std_List == undefined ? [] : Std_List;

  Std_List = CheckOrUncheckAllValuesOfTestArray(Std_List, true);

  return {
    T_List,
    Sel_Teachers,
    Clss_List,
    Std_List,
  };
}
export function Return_ClassOf_A_Student(classList, Sel_Std) {
  let Sel_Class = {};
  Sel_Class = classList.find((item) => {
    let stds = item.students == null ? [] : item.students;
    let stdFind = stds.find((S_item) => S_item.id == Sel_Std.id);
    if (stdFind !== undefined) {
      Sel_Class = item;
      return item;
    }
  });
  return {
    Sel_Class,
  };
}

export function getGradeOfClassFromRoaster(Grades, studentId) {
  let gradeSelected = null;
  let GradesList = Grades;
  for (let i = 0; i < GradesList.length; i++) {
    for (let t = 0; t < GradesList[i].teachers.length; t++) {
      for (let c = 0; c < GradesList[i].teachers[t].classes.length; c++) {
        for (
          let s = 0;
          s < GradesList[i].teachers[t].classes[c].students.length;
          s++
        ) {
          if (
            GradesList[i].teachers[t].classes[c].students[s].id == studentId
          ) {
            gradeSelected = GradesList[i].grade;
            break;
          }
        }
        if (gradeSelected != null) {
          break;
        }
      }
      if (gradeSelected != null) {
        break;
      }
    }
    if (gradeSelected != null) {
      break;
    }
  }
  return gradeSelected;
}

export function Return_ERROR_Status_Code(error, seconds_Start) {
  let seconds_End = new Date().getTime() / 1000;
  let diffTime = seconds_End - seconds_Start;
  return error.message == "Network Error" && diffTime < 90
    ? 502
    : error.response == undefined
    ? 504
    : error.response.status;
}
export function MakeTermEndDate_As_CurrentDate_If_It_GreaterThanToDay(Data) {
  return Data.map((item) => {
    if (newDateHandling(item.termEndDate) > new Date()) {
      item.termEndDate = getUTCDateTime(newDateHandling(item.termEndDate));
    }

    return item;
  });
}
/**
 *
 * @param {Object} PrevReports
 * @param {Object} Context_Roster
 * @param {Object} Nav
 * @returns {Boolean}
 */
export function CheckPreviousReports_Roster_CurrentRoster(
  PrevReports,
  Context_Roster,
  Nav
) {
  switch (true) {
    case Nav.student:
      return (
        PrevReports.selectedStudent.id == Context_Roster.SelectedStudent.id
      );
    case Nav.class:
      return PrevReports.selectedClass.id == Context_Roster.SelectedClass.id;
    case Nav.school:
      return PrevReports.selectedSchool.id == Context_Roster.SelectedSchool.id;
    case Nav.district:
      return true;
    default:
      return false;
  }
}

export function DateFormarFor_APiCalls(StartDate, EndDate) {
  let startdateis = StartDate.split("/");
  let Enddateis = EndDate.split("/");
  if (startdateis.length > 2) {
    StartDate =
      startdateis[2] +
      "-" +
      startdateis[0] +
      "-" +
      startdateis[1] +
      " " +
      "00:00:00";
  }
  if (Enddateis.length > 2) {
    EndDate =
      Enddateis[2] + "-" + Enddateis[0] + "-" + Enddateis[1] + " " + "23:59:59";
  }
  return { StartDate, EndDate };
}

export function ReturnListOfSelected(ArrayList, ListToReturn, selectedItem) {
  let List = [];
  ArrayList.map((item) => {
    if (ListToReturn == "class") {
      item.classes.map((item) => {
        item.check = item.id == selectedItem.id;
      });
      List = List.concat(item.classes);
    } else {
      item.students.map((item) => {
        item.check = item.id == selectedItem.id;
      });
      List = List.concat(item.students);
    }
  });
  return List;
}
export function getRequiredDataFromPersist(reqObject, getState) {
  if (reqObject == "ts") {
    return getState.PersistanceReducer.TS_Persistance;
  } else if (reqObject == "ts_overview") {
    return getState.PersistanceReducer;
  } else if (reqObject == "ts_overview_compare") {
    return getState.PersistanceReducer.compareOptions;
  } else if (reqObject == "sta") {
    return getState.PersistanceReducer.SingleTest_Persistance;
  } else if (reqObject == "ts_compare_checkboxes") {
    return getState.PersistanceReducer.compareOptions;
  } else if (reqObject == "persist_compare_checkboxes") {
    return getState.PersistanceReducer.compareOptions;
  } else if (reqObject == "sta_test") {
    return getState.PersistanceReducer.SingleTest_Persistance.selected_test;
  } else if (reqObject == "sp_persistance") {
    return getState.PersistanceReducer.SP_Persistance;
  } else if (reqObject == "sp_comparison_persistance") {
    return getState.PersistanceReducer.sp_comparison_persistance;
  } else if (reqObject == "batch_options") {
    return getState.PersistanceReducer.BatachOptions;
  } else {
    return getState.PersistanceReducer;
  }
}

export function GetAssessed_Ques_ToPersist(LastActiveNav, getState) {
  let QuestionToPersist;
  switch (true) {
    case LastActiveNav.student:
      QuestionToPersist =
        getState().StudentReports.S_StandardPerformance_Overview
          .StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
      break;
    case LastActiveNav.class:
      QuestionToPersist =
        getState().Reports.StandardPerformance_Overview
          .StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
      break;
    case LastActiveNav.school:
      QuestionToPersist =
        getState().schoolReducer.Sc_StandardPerformance_Overview
          .StandardPerformanceFilter.TestAssessment
          .selectedTestAssessmentselectedTestAssessment;
      break;
    case LastActiveNav.district:
      QuestionToPersist =
        getState().DistrictReducer.D_StandardPerformance_Overview
          .StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
      break;
    default:
      break;
  }

  return QuestionToPersist;
}

export function GetTaxonomy_ToPersist_AndStrandDetails(
  LastActiveNav,
  getState
) {
  let last_active_Taxonomy;
  let StrandNameToPersist;
  let StandardIdToPersist;
  let StandsState;
  switch (true) {
    case LastActiveNav.student:
      StandsState = getState().StudentReports.S_StandardPerformance_Overview;
      last_active_Taxonomy =
        StandsState.StandardPerformanceFilter.Taxonomy.selectedTaxonomy;
      StrandNameToPersist = StandsState.StrandNameOfSelectedStandard;
      StandardIdToPersist = StandsState.selectedStandardId;
      return { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist };
      break;
    case LastActiveNav.class:
      StandsState = getState().Reports.StandardPerformance_Overview;
      last_active_Taxonomy =
        StandsState.StandardPerformanceFilter.Taxonomy.selectedTaxonomy;
      StrandNameToPersist = StandsState.StrandNameOfSelectedStandard;
      StandardIdToPersist = StandsState.selectedStandardId;
      return { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist };
      break;
    case LastActiveNav.school:
      StandsState = getState().schoolReducer.Sc_StandardPerformance_Overview;
      last_active_Taxonomy =
        StandsState.StandardPerformanceFilter.Taxonomy.selectedTaxonomy;
      StrandNameToPersist = StandsState.StrandNameOfSelectedStandard;
      StandardIdToPersist = StandsState.selectedStandardId;
      return { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist };
      return getState().schoolReducer.Sc_StandardPerformance_Overview
        .StandardPerformanceFilter.Taxonomy.selectedTaxonomy;
      break;
    case LastActiveNav.district:
      StandsState = getState().DistrictReducer.D_StandardPerformance_Overview;
      last_active_Taxonomy =
        StandsState.StandardPerformanceFilter.Taxonomy.selectedTaxonomy;
      StrandNameToPersist = StandsState.StrandNameOfSelectedStandard;
      StandardIdToPersist = StandsState.selectedStandardId;
      return { last_active_Taxonomy, StrandNameToPersist, StandardIdToPersist };
      break;
    default:
      break;
  }
  return { TaxonomyToPersist };
}

export function Strands_Grade_ToPersist(LastActiveNav, getState) {
  switch (true) {
    case LastActiveNav.student:
      return getState().StudentReports.S_StandardPerformance_Overview
        .StandardPerformanceFilter.TestGrade.selectedTestgrade;
      break;
    case LastActiveNav.class:
      return getState().Reports.StandardPerformance_Overview
        .StandardPerformanceFilter.TestGrade.selectedTestgrade;
      break;
    case LastActiveNav.school:
      return getState().schoolReducer.Sc_StandardPerformance_Overview
        .StandardPerformanceFilter.TestGrade.selectedTestgrade;
      break;
    case LastActiveNav.district:
      return getState().DistrictReducer.D_StandardPerformance_Overview
        .StandardPerformanceFilter.TestGrade.selectedTestgrade;
      break;
    default:
      break;
  }
}

export function GetPrevItemToPersistIn_Compare(
  state,
  LastActiveNav,
  CurrentNav,
  valueFor,
  PayloadList,
  Item_To_Persist,
  persisted_grade
) {
  switch (true) {
    case LastActiveNav.student:
      if (valueFor == "taxonomy") {
        let taxon = Item_To_Persist
          ? Item_To_Persist
          : state.studentComparison.Std_Comparison.PopupFilter.TaxonomyParams
              .selectedTaxonomy;
        let find = PayloadList.find((item) => item == taxon);
        return find ? taxon : PayloadList[0];
      } else if (valueFor == "grade") {
        let grade =
          persisted_grade != null && persisted_grade != undefined
            ? persisted_grade
            : state.studentComparison.Std_Comparison.PopupFilter.GradeParams
                .selectedGrade;
        let find =
          grade && PayloadList.find((item) => item.grade == grade.grade);
        return find ? grade : PayloadList[0];
      }
      break;
    case LastActiveNav.class:
      if (valueFor == "taxonomy") {
        let taxon = Item_To_Persist
          ? Item_To_Persist
          : state.classComparison.Std_Comparison.PopupFilter.TaxonomyParams
              .selectedTaxonomy;
        let find = PayloadList.find((item) => item == taxon);
        return find ? taxon : PayloadList[0];
      } else if (valueFor == "grade") {
        let grade =
          persisted_grade != null && persisted_grade != undefined
            ? persisted_grade
            : state.classComparison.Std_Comparison.PopupFilter.GradeParams
                .selectedGrade;
        let find =
          grade && PayloadList.find((item) => item.grade == grade.grade);
        return find ? grade : PayloadList[0];
      }
      break;
    case LastActiveNav.school:
      if (valueFor == "taxonomy") {
        let taxon = Item_To_Persist
          ? Item_To_Persist
          : state.schoolComparison.Std_Comparison.PopupFilter.TaxonomyParams
              .selectedTaxonomy;
        let find = PayloadList.find((item) => item == taxon);
        return find ? taxon : PayloadList[0];
      } else if (valueFor == "grade") {
        let grade =
          persisted_grade != null && persisted_grade != undefined
            ? persisted_grade
            : state.schoolComparison.Std_Comparison.PopupFilter.GradeParams
                .selectedGrade;
        let find =
          grade && PayloadList.find((item) => item.grade == grade.grade);
        return find ? grade : PayloadList[0];
      }
      break;
    case LastActiveNav.district:
      if (valueFor == "taxonomy") {
        let taxon = Item_To_Persist
          ? Item_To_Persist
          : state.districtComparison.Std_Comparison.PopupFilter.TaxonomyParams
              .selectedTaxonomy;
        let find = PayloadList.find((item) => item == taxon);
        return find ? taxon : PayloadList[0];
      } else if (valueFor == "grade") {
        let grade =
          persisted_grade != null && persisted_grade != undefined
            ? persisted_grade
            : state.districtComparison.Std_Comparison.PopupFilter.GradeParams
                .selectedGrade;
        let find =
          grade && PayloadList.find((item) => item.grade == grade.grade);
        return find ? grade : PayloadList[0];
      }
      break;
    default:
      break;
  }
}

export function Is_RosterOr_TestAPis_Action(ApiCalls) {
  return (
    ApiCalls.getTests ||
    ApiCalls.Get_Selected_School_Info ||
    ApiCalls.loadingFor == "tests" ||
    ApiCalls.loadingFor == "school" ||
    ApiCalls.getStudentData_cls ||
    ApiCalls.loadingFor == "studentData"
  );
}

export function getClassAndSchoolListOfStudentData(studentData) {
  let stdDataSelectedClassIds = [];
  let stdDataSelectedSchoolIds = [];
  studentData.StudentData_cls.map((singleCls) => {
    if (singleCls.check) {
      stdDataSelectedClassIds.push(singleCls.id);
      stdDataSelectedSchoolIds.push(singleCls.schoolId);
    }
  });
  stdDataSelectedClassIds = [...new Set(stdDataSelectedClassIds)];
  stdDataSelectedSchoolIds = [...new Set(stdDataSelectedSchoolIds)];
  if (
    stdDataSelectedClassIds.length == 0 &&
    stdDataSelectedSchoolIds.length == 0
  ) {
    stdDataSelectedClassIds = studentData.ClassIds;
    stdDataSelectedSchoolIds = studentData.SchoolIds;
  }
  return {
    stdDataSelectedClassIds,
    stdDataSelectedSchoolIds,
  };
}

export function getListOfStandardsBasedOnSelections(
  selectedObjectData,
  performanceOvertimeData
) {
  let listOfStandardIds = [];
  const { viewSelection } = performanceOvertimeData;
  const { selectedView_temp, viewsList, viewsList_temp } = viewSelection;
  let listOfSelectedViews = [];
  viewsList_temp.map((singleView) => {
    if (singleView.check) {
      listOfSelectedViews.push(singleView.taxonomy);
    }
  });
  const {
    StrandNameOfSelectedStandard,
    selectedstandardObject,
    cmpList,
    selectedTaxonomy,
  } = selectedObjectData;
  if (selectedView_temp == "strand") {
    for (let i = 0; i < cmpList.length; i++) {
      if (cmpList[i].strandName == StrandNameOfSelectedStandard) {
        if (selectedstandardObject == null) {
          for (let r = 0; r < cmpList[i].standards.length; r++) {
            if (cmpList[i].standards[r].taxonomy == selectedTaxonomy) {
              if (cmpList[i].standards[r].nationalStdIds != undefined) {
                for (
                  let ij = 0;
                  ij < cmpList[i].standards[r].nationalStdIds.length;
                  ij++
                ) {
                  listOfStandardIds.push(
                    cmpList[i].standards[r].nationalStdIds[ij]
                  );
                }
              } else {
                listOfStandardIds.push(cmpList[i].standards[r].standardId);
              }
            }
          }
        } else {
          if (selectedstandardObject.nationalStdIds != undefined) {
            for (
              let ij = 0;
              ij < selectedstandardObject.nationalStdIds.length;
              ij++
            ) {
              listOfStandardIds.push(selectedstandardObject.nationalStdIds[ij]);
            }
          } else {
            listOfStandardIds.push(selectedstandardObject.standardId);
          }
        }
        break;
      }
    }
  } else {
    if (viewsList.length === listOfSelectedViews.length) {
      listOfStandardIds = [];
    } else {
      for (let k = 0; k < cmpList.length; k++) {
        for (let m = 0; m < cmpList[k].standards.length; m++) {
          if (
            listOfSelectedViews.indexOf(cmpList[k].standards[m].taxonomy) !== -1
          ) {
            if (cmpList[k].standards[m].nationalStdIds != undefined) {
              for (
                let pk = 0;
                pk < cmpList[k].standards[m].nationalStdIds.length;
                pk++
              ) {
                listOfStandardIds.push(
                  cmpList[k].standards[m].nationalStdIds[pk]
                );
              }
            } else {
              listOfStandardIds.push(cmpList[k].standards[m].standardId);
            }
          }
        }
      }
    }
  }
  listOfStandardIds = [...new Set(listOfStandardIds)];
  return listOfStandardIds;
}
export const GetSelectedSchoolIdsOf_Grade = (Roster_Tab, ActualGrades) => {
  let Grade = Roster_Tab.selectedRosterGrade;
  let Schools = Roster_Tab.schoolsList.filter((item) => item.check);
  let GradeSchools = ActualGrades.filter((item) => item.grade == Grade);
  let SchoolIds = [];
  Schools.map((item) => {
    let findSchool = GradeSchools.find((school) => school.id == item.id);
    if (findSchool) {
      SchoolIds.push(item.id);
    }
  });
  return SchoolIds;
};

export const sortDataBasedOnUserPrefferences = (data) => {
  let returnedData = {};
  returnedData.achievementlevels = data.achievementlevels;
  returnedData.standardsetorders = [];
  let StandardsSetOrder = Object.keys(data.standardsetorders);
  for (let index = 0; index < StandardsSetOrder.length; index++) {
    let orderNo = parseInt(
      StandardsSetOrder[index].replace("standardsetorder", "")
    );
    returnedData.standardsetorders.push({
      orderKey: orderNo,
      setValue: parseInt(data.standardsetorders[StandardsSetOrder[index]]),
    });
  }
  returnedData.standardsetorders.sort((a, b) => {
    if (a.orderKey < b.orderKey) {
      return -1;
    }
    if (a.orderKey > b.orderKey) {
      return 1;
    }
    return 0;
  });
  return returnedData;
};

export const sortTaxonomyDataBasedOnUserPrefferences = (
  preferences,
  setValues
) => {
  let orderedTaxonomyList = [];
  if (setValues.length > 1) {
    preferences.standardsetorders.map((dataVore) => {
      let filterData = setValues.filter(
        (setData) => setData.setId == dataVore.setValue
      );
      if (filterData.length > 0) {
        orderedTaxonomyList.push(filterData[0].taxonomy);
      }
    });
  } else {
    orderedTaxonomyList.push(setValues[0].taxonomy);
  }
  return orderedTaxonomyList;
};
export function getUTCDateTime(datevalue) {
  var now = datevalue == undefined || datevalue == "" ? new Date() : datevalue;
  var year = now.getUTCFullYear();
  var month = now.getUTCMonth() + 1;
  var day = now.getUTCDate();
  var hour = now.getUTCHours();
  var minute = now.getUTCMinutes();
  var second = now.getUTCSeconds();
  if (month.toString().length == 1) {
    month = "0" + month;
  }
  if (day.toString().length == 1) {
    day = "0" + day;
  }
  if (hour.toString().length == 1) {
    hour = "0" + hour;
  }
  if (minute.toString().length == 1) {
    minute = "0" + minute;
  }
  if (second.toString().length == 1) {
    second = "0" + second;
  }
  var dateTime =
    year + "-" + month + "-" + day + " " + hour + ":" + minute + ":" + second;
  return dateTime;
}

export const getTimeStampofUTCIfweHaveCurrentDate = (endDate) => {
  let endDateObtained =
    endDate == null || endDate == undefined ? new Date() : newDateHandling(endDate);
  let resultantDate = null;
  if (
    new Date().getFullYear() === endDateObtained.getFullYear() &&
    new Date().getMonth() === endDateObtained.getMonth() &&
    new Date().getDate() === endDateObtained.getDate()
  ) {
    resultantDate = getUTCDateTime(new Date());
  } else {
    resultantDate = getUTCDateTime(newDateHandling(endDate));
    resultantDate = resultantDate.split(" ")[0] + " " + "23:59:59";
  }
  return resultantDate;
};

export const getStdPersistChanged = (curState) => {
  let stdModifed = false;
  const { StudentReports, schoolReducer, Reports, DistrictReducer } = curState;
  let d_strand =
    DistrictReducer.D_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let d_standard =
    DistrictReducer.D_StandardPerformance_Overview.StandardPerformanceFilter
      .selectedstandardObject != null
      ? Object.keys(
          DistrictReducer.D_StandardPerformance_Overview
            .StandardPerformanceFilter.selectedstandardObject
        ).length !== 0
        ? DistrictReducer.D_StandardPerformance_Overview.selectedstandardObject
            .standardId
        : null
      : null;
  let sc_strand =
    schoolReducer.Sc_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let sc_standard =
    schoolReducer.Sc_StandardPerformance_Overview.selectedstandardObject != null
      ? Object.keys(
          schoolReducer.Sc_StandardPerformance_Overview.selectedstandardObject
        ).length !== 0
        ? schoolReducer.Sc_StandardPerformance_Overview.selectedstandardObject
            .standardId
        : null
      : null;
  let c_strand =
    Reports.StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let c_standard =
    Reports.StandardPerformance_Overview.selectedstandardObject != null
      ? Object.keys(Reports.StandardPerformance_Overview.selectedstandardObject)
          .length !== 0
        ? Reports.StandardPerformance_Overview.selectedstandardObject.standardId
        : null
      : null;
  let s_strand =
    StudentReports.S_StandardPerformance_Overview.StrandNameOfSelectedStandard;
  let s_standard =
    StudentReports.S_StandardPerformance_Overview.selectedstandardObject != null
      ? Object.keys(
          StudentReports.S_StandardPerformance_Overview.selectedstandardObject
        ).length !== 0
        ? StudentReports.S_StandardPerformance_Overview.selectedstandardObject
            .standardId
        : null
      : null;
  if (
    ((d_strand !== sc_strand) !== c_strand) !== s_strand &&
    ((d_standard !== sc_standard) !== c_standard) !== s_standard
  ) {
    stdModifed = true;
  }
  return stdModifed;
};

export const GetDataBasedOnAchivementLevels = (
  achievementlevelData,
  ACHIEVEMENT_LEVELS_ENABLE
) => {
  let achievementlevelsUpdated = [];
  const { achievementlevels } = achievementlevelData;
  const {
    achievementlevel1,
    achievementlevel2,
    achievementlevel3,
    achievementlevel4,
  } = achievementlevels;
  if (achievementlevelData != null && ACHIEVEMENT_LEVELS_ENABLE) {
    achievementlevelsUpdated = [
      {
        level: 1,
        min: getSplitMinMax(achievementlevel1).min,
        max: getSplitMinMax(achievementlevel1).max,
        key: achievementlevel1,
        label: `${getSplitMinMax(achievementlevel1).max + 1}`,
      },
      {
        level: 2,
        min: getSplitMinMax(achievementlevel2).min,
        max: getSplitMinMax(achievementlevel2).max,
        key: achievementlevel2,
        label: achievementlevel2,
      },
      {
        level: 3,
        min: getSplitMinMax(achievementlevel3).min,
        max: getSplitMinMax(achievementlevel3).max,
        key: achievementlevel3,
        label: achievementlevel3,
      },
      {
        level: 4,
        min: getSplitMinMax(achievementlevel4).min,
        max: getSplitMinMax(achievementlevel4).max,
        key: achievementlevel4,
        label: `${getSplitMinMax(achievementlevel4).min}`,
      },
    ];
  } else {
    achievementlevelsUpdated = [
      {
        level: 1,
        min: 0,
        max: 39,
        key: "0-39",
        label: "40",
      },
      {
        level: 2,
        min: 40,
        max: 59,
        key: "40-59",
        label: "40-59",
      },
      {
        level: 3,
        min: 60,
        max: 79,
        key: "60-79",
        label: "60-79",
      },
      {
        level: 4,
        min: 80,
        max: 100,
        key: "80-100",
        label: "80",
      },
    ];
  }

  return achievementlevelsUpdated;
};

function getSplitMinMax(value) {
  let splitValue = value.split("-");
  let min = parseInt(splitValue[0]);
  let max = parseInt(splitValue[1]);

  return {
    min,
    max,
  };
}

/**
 *
 * @param {unixtimestamp} timestamp
 * @returns {date}
 * it will return the local date as response.
 */
export function timestampToDatetime(timestamp) {
  if (timestamp !== undefined && timestamp !== null) {
    let inputvalue = newDateHandling(timestamp * 1000);
    let date =
      pad(inputvalue.getMonth() + 1) +
      "/" +
      pad(inputvalue.getDate()) +
      "/" +
      inputvalue.getFullYear();
    return date;
  } else {
    return timestamp;
  }
}
/**
 * @param {date} dateparam
 * @param {time} time
 * @returns {date}//mm/dd/yyyy
 * it will return the local date as response.
 */
export const convertUTCDateToLocalDate = (dateparam, time) => {
  let date = dateTimeParamsExistCheck(dateparam, time);
  let newDate = newDateHandling(date);
  if (newDateHandling(newDate) > new Date()) {
    let month = new Date().getMonth() + 1;
    let day = new Date().getDate();
    let year = new Date().getFullYear();
    return pad(month) + "/" + pad(day) + "/" + year;
  } else {
    return [
      pad(newDate.getMonth() + 1),
      pad(newDate.getDate()),
      newDate.getFullYear(),
    ].join("/");
  }
};
export function getLocalTimestamp(date) {
  let currentDate = newDateHandling(date);
  let currentTime = currentDate.getTime();
  let localOffset = (-1) * currentDate.getTimezoneOffset() * 60000;// adjustes time with timezone
  let timestamp = newDateHandling(currentTime + localOffset).getTime();
  return timestamp;
}
export function userTimeZoneDate(dateInput, timeInput) {
  if (timeInput == undefined) {
    timeInput = "00:00:00"
  }
  let datetime = dateInput + " " + timeInput;
  let mydate = newDateHandling(datetime).getTime();
  let calculatedDate = getLocalTimestamp(mydate);
  let calculatedDate1 = newDateHandling(calculatedDate);
  const month = pad(calculatedDate1.getMonth() + 1);
  const day = pad(calculatedDate1.getDate());
  const year = calculatedDate1.getFullYear();
  return month + "/" + day + "/" + year;
}
function dateTimeParamsExistCheck(date, time) {
  if (
    date !== undefined &&
    date !== null &&
    time !== undefined &&
    time !== null &&
    time !== ""
  ) {
    return newDateHandling(date + " " + time);
  } else if (
    date !== undefined &&
    date !== null &&
    (time == undefined || time == null || time == "")
  ) {
    return newDateHandling(date + " " + "00:00:00");
  }
}

export function pad(s) {
  return s < 10 ? "0" + s : s;
}
/**
 * this used in PDF context header dates reusable value
 * @param {date} dateparam
 * @param {DISPLAY_LOCAL_TIME_IN_UI} flag
 * @returns {date}
 */

export function displayLocalTimeInPDFContextHeaderBasedOnFlag(Display) {
  let LocalDate = null;
  if (DISPLAY_LOCAL_TIME_IN_UI == true) {
    LocalDate =
      Display.minTestDate != undefined &&
      Display.minTestDate != null &&
      Display.maxTestDate != undefined &&
      Display.maxTestDate != null
        ? Display.minTestDate === Display.maxTestDate
          ? convertUTCDateToLocalDate(Display.minTestDate, Display.minDateTime)
          : convertUTCDateToLocalDate(
              Display.minTestDate,
              Display.minDateTime
            ) +
            " - " +
            convertUTCDateToLocalDate(Display.maxTestDate, Display.maxDateTime)
        : null;
  } else {
    LocalDate =
      Display.minTestDate != undefined &&
      Display.minTestDate != null &&
      Display.maxTestDate != undefined &&
      Display.maxTestDate != null
        ? Display.minTestDate === Display.maxTestDate
          ? Display.minTestDate
          : Display.minTestDate + " - " + Display.maxTestDate
        : null;
  }

  return LocalDate;
}
export function checkTaxonomySetId(setvalues, taxonomy) {
  let setId = setvalues.find((tax) => tax.taxonomy == taxonomy).setId;
  return setId;
}

export function calculate_And_Round_Avg(First, Second) {
  if (First != null) {
    if (Second != 0) {
      return Math.round((First / Second) * 100);
    } else {
      return null;
    }
  } else {
    return null;
  }
}
export function ReturnColorUnderStrandAvgBeneath(strand, achivementLevelData) {
  if (strand == null) {
    return "none";
  }
  else if (strand != null && strand < achivementLevelData[0].max) {
    return "red";
  } else if (strand < achivementLevelData[1].max) {
    return "orange";
  } else if (strand <= achivementLevelData[2].max) {
    return "yellow";
  } else {
    return "green";
  }
}
//for SA, DA we are sending studentIds in api req obj only when multiselection of students else empty array
export const setStudentIdsWhenMultiSelectionsInSADA = (store, stdIds) => {
  let universal = store.Universal;
  let currentTerm = universal.currentTermID;
  let selectedTerm = universal.ContextHeader.Date_Tab.selectedTermId;
  let Nav = universal.NavigationByHeaderSelection;
  if (
    selectedTerm &&
    currentTerm !== selectedTerm &&
    (Nav.school || Nav.district)
  ) {
    let UniversalRoster = universal.UniversalSelecter.Roster_Data;
    stdIds =
      UniversalRoster.ActualStudents.length !==
        UniversalRoster.StudentIds.length ||
      UniversalRoster.ActualClasses.length !== UniversalRoster.ClassIds.length
        ? UniversalRoster.StudentIds
        : [];
  }
  return stdIds;
};
export function retriggerAPI(diffTime, retries, statusCode) {
  let retry =
    diffTime < 90 && retries < 2 && (statusCode == 502 || statusCode == 504);
  return retry;
}
export function getRealmFromURL(url) {
  let realm = "";
  if (process.env.HELP_LINK_ENV === "STAGING") {
    realm = url.substring(url.lastIndexOf("=") + 1, url.lastIndexOf("#"));
  } else if (process.env.HELP_LINK_ENV === "PRODUCTION") {
    realm = url.substring(
      url.lastIndexOf("https://") + 8,
      url.lastIndexOf(".benchmarkuniverse.com")
    );
  }
  return realm;
}

export function TestToPersistInTestScoreGraph(ResponseList, getState) {
  let LastActiveNav = getState.LastActiveUniversalProps.NaviGation;
  let CurrentActive = getState.Universal.NavigationByHeaderSelection;

  let LastActiveTest;

  switch (true) {
    case LastActiveNav.student && !CurrentActive.student:
      LastActiveTest =
        getState.StudentReports.S_Test_Scores_OverView.SelectedTestData;

      break;

    case LastActiveNav.class && !CurrentActive.class:
      LastActiveTest = getState.Reports.Test_Scores_OverTime.SelectedTestData;
      break;

    case LastActiveNav.school && !CurrentActive.school:
      LastActiveTest =
        getState.schoolReducer.Sc_Test_Scores_OverTime.SelectedTestData;
      break;

    case LastActiveNav.district && !CurrentActive.district:
      LastActiveTest =
        getState.DistrictReducer.D_Test_Scores_OverTime.SelectedTestData;
      break;

    default:
      break;
  }

  if (LastActiveTest !== undefined && LastActiveTest !== null && ResponseList) {
    LastActiveTest = ResponseList.find(
      (item) => item.componentCode === LastActiveTest.componentCode
    );
  }
  return LastActiveTest;
}
export function toggleToPersist_In_StrandsOverview(getState) {
  let PrevNav = getState().LastActiveUniversalProps.NaviGation;
  let activeToggle;
  switch (true) {
    case PrevNav.student:
      //     activeToggle = getState().StudentReports.S_StandardPerformance_Overview.
      break;
    case PrevNav.class:
      activeToggle =
        getState().Reports.StandardPerformance_Overview
          .ActiveToggelIn_SP_Overview;
      break;
    case PrevNav.school:
      activeToggle =
        getState().schoolReducer.Sc_StandardPerformance_Overview
          .ActiveToggelIn_SP_Overview;
      break;
    case PrevNav.district:
      activeToggle =
        getState().DistrictReducer.D_StandardPerformance_Overview
          .ActiveToggelIn_SP_Overview;
      break;

    default:
      break;
  }
  return activeToggle;
}
export function dropDownEllipsis(value) {
  if (value === undefined || value === null || value === "") {
    return value;
  } else if (value.length > 20) {
    return value.slice(0, 20) + "...";
  } else return value;
}

/**
 *
 * @param {string} grade
 * @param {Array} GradesList
 *
 * it will only returns all teachers and all classes and all students list along with those id's also.
 */
export function GetAllRosterDataOfA_Grade(grade, GradesList) {
  let teachersList = [];
  let classList = [];
  let studentList = [];
  let teacherIds = [];
  let classIds = [];
  let studentIds = [];
  for (let i = 0; i < GradesList.length; i++) {
    if (GradesList[i].grade == grade || grade == "All") {
      teachersList = GradesList[i].teachers ? GradesList[i].teachers : [];
      if (Array.isArray(teachersList)) {
        teachersList.map((teacherItem) => {
          teacherItem.check = true;
          teacherIds.push(teacherItem.id);
          if (teacherItem.classes) {
            teacherItem.classes.map((classItem) => {
              classItem.check = true;
              classList.push(classItem);
              classIds.push(classItem.id);
              if (classItem.students) {
                classItem.students.map((studentItem) => {
                  studentItem.check = true;
                  studentList.push(studentItem);
                  studentIds.push(studentItem.id);
                });
              }
            });
          }
        });
      }

      if (grade !== "All") {
        break;
      }
    }
  }

  if (teachersList.length > 0) {
    teachersList = Sort_ApiResponse_Payload_Array(
      RemoveDuplicateObjectsFromArray(teachersList, "id"),
      "teacherlist"
    );
    classList = Sort_ApiResponse_Payload_Array(
      RemoveDuplicateObjectsFromArray(classList, "id"),
      "classlist"
    );
    studentList = Sort_ApiResponse_Payload_Array(
      RemoveDuplicateObjectsFromArray(studentList, "id"),
      "studentslist"
    );
    teacherIds = Get_Ids_Of_Student_List(teachersList);
    classIds = Get_Ids_Of_Student_List(classList);
    studentIds = Get_Ids_Of_Student_List(studentList);
  }
  return {
    teachersList,
    classList,
    studentList,
    teacherIds,
    classIds,
    studentIds,
    grade,
  };
}

export function SortObjectByKey(params) {
  return Object.keys(params)
    .sort()
    .reduce(function (result, key) {
      result[key] = params[key];
      return result;
    }, {});
}

export function ViewListSortByUserPreferences(a, b) {
  if (a.setId < b.setId) {
    return -1;
  }
  if (a.setId > b.setId) {
    return 1;
  }
  return 0;
}
export function SummaryHeaderEllipsis(value, length) {
  if (value === undefined || value === null || value === "") {
    return value;
  } else if (value.length > length) {
    return value.slice(0, length) + "...";
  } else return value;
}
export function get_RosterData_On_ClassSelection(
  GradeList,
  Selected_Class_Data,
  gradeToStore,
  ContextHeader
) {
  let TeachersList = [];
  let selectedTeacher = {};
  let selectedGrade = "";
  let classList = [];
  let selectedClass = {};
  let studentList = [];
  let StdIds = [];
  GradeList= getGradesListIfNoTeachersFindInside(GradeList,ContextHeader)
  if (Selected_Class_Data) {
    for (let i = 0; i < GradeList.length; i++) {
      let teachers = GradeList[i].teachers;
      if (teachers) {
        for (let j = 0; j < teachers.length; j++) {
          let classes = teachers[j].classes;
          if (classes) {
            let find = classes.find(
              (item) => item.id == Selected_Class_Data.id
            );
            if (find) {
              selectedGrade = GradeList[i].grade;
              TeachersList = teachers;
              selectedTeacher = teachers[j];
              classList = classes;
              selectedClass = find;
            } else {
              teachers[j].check = false;
            }
          } else {
            teachers[j].check = false;
          }
        }
      }
      if (selectedGrade !== "") {
        break;
      }
    }
  } else {
    selectedGrade = gradeToStore;
  }
  let studentsList = [];
  let stdIds = [];
  if (classList && classList.length > 0) {
    TeachersList = Sort_ApiResponse_Payload_Array(
      RemoveDuplicateObjectsFromArray(TeachersList, "id"),
      "teacherlist"
    );
    classList = Sort_ApiResponse_Payload_Array(
      RemoveDuplicateObjectsFromArray(classList, "id"),
      "classlist"
    );
    classList.map((item) => {
      if (item.id == selectedClass.id) {
        item.check = true;
        let Stdlist = item.students == null ? [] : item.students;
        Stdlist.map((item1) => {
          item1.check = true;
        });
        studentList = studentList.concat(Stdlist);
      } else {
        item.check = false;
      }
    });
    studentList = Sort_ApiResponse_Payload_Array(
      RemoveDuplicateObjectsFromArray(studentList, "id"),
      "studentslist"
    );
    StdIds = Get_Ids_Of_Student_List(studentList);
  }
  return {
    selectedGrade,
    selectedTeacher,
    TeachersList,
    classList,
    selectedClass,
    studentList,
    StdIds,
  };
}

export function getClassAndTeacherOf_Student(Teachers, ActiveStudent) {
  let selectedTeacher, selectedClass;
  if (Teachers) {
    for (let i = 0; i < Teachers.length; i++) {
      let classes = Teachers[i].classes;
      if (classes) {
        for (let j = 0; j < classes.length; j++) {
          let Students = classes[j].students;
          if (Students) {
            let find = Students.find((item) => item.id == ActiveStudent.id);
            if (find) {
              selectedTeacher = Teachers[i];
              selectedClass = classes[j];
              break;
            }
          }
        }
      }
      if (selectedClass) {
        break;
      }
    }
  }
  return { selectedTeacher, selectedClass };
}
export function verifyGradeInCompare(state, fromContext, gradeInput) {
  let grade = gradeInput;
  switch (fromContext) {
    case "student":
      let StdGradeList_temp =
        state.studentComparison.Std_Comparison.PopupFilter.GradeParams
          .GradeList_temp;
      let Stfind =
        grade != null &&
        StdGradeList_temp.find((item) => item.grade == gradeInput.grade);
      return Stfind ? grade : StdGradeList_temp[0];

    case "class":
      let ClsGradeList_temp =
        state.classComparison.Std_Comparison.PopupFilter.GradeParams
          .GradeList_temp;
      let Clsfind =
        grade != null &&
        ClsGradeList_temp.find((item) => item.grade == gradeInput.grade);
      return Clsfind ? grade : ClsGradeList_temp[0];

    case "school":
      let ScGradeList_temp =
        state.schoolComparison.Std_Comparison.PopupFilter.GradeParams
          .GradeList_temp;
      let Scfind =
        grade != null &&
        ScGradeList_temp.find((item) => item.grade == gradeInput.grade);
      return Scfind ? grade : ScGradeList_temp[0];

    case "district":
      let DistGradeList_temp =
        state.districtComparison.Std_Comparison.PopupFilter.GradeParams
          .GradeList_temp;
      let Distfind =
        grade != null &&
        DistGradeList_temp.find((item) => item.grade == gradeInput.grade);
      return Distfind ? grade : DistGradeList_temp[0];

    default:
      break;
  }
}
export function SummaryTestStatusGradeSorting(Arr) {
  //let Data = Arr;
  let Data = Arr.sort((a,b) => {
    if(a.grade > b.grade) return 1;
    if(a.grade < b.grade) return -1;
    return 0;
});
return Data;
}
// function validateNumberORString(Data){    
//   let finalData = [];
//     let re = /^[A-Za-z]+$/;
//     if(re.Data.grade){

//     }else{

//     }
 
// }
export function simpleAlphaSort(Arr) {
  let SortedData =  Arr && Arr.sort((a, b) => (a.name > b.name) - (a.name < b.name))
  return SortedData;
}
export function GetComponentCode_In_The_Array(ArrayList) {
  let IdsList = [];

    ArrayList.map((item) => {
      IdsList.push(item.componentCode);
    });
  
  return IdsList;
}
export function testsFilter(TestList) {
  let Selected_List = TestList.filter(
    (item) => item.check
  );
  
  return Selected_List;
}

export const GetBrowserName = (Navigator)=>{
  let userAgent = Navigator && Navigator.userAgent;
  let browserName;
         if(userAgent.match(/chrome|chromium|crios/i)){
             browserName = "chrome";
           }else if(userAgent.match(/firefox|fxios/i)){
             browserName = "firefox";
           }  else if(userAgent.match(/safari/i)){
             browserName = "safari";
           }else if(userAgent.match(/opr\//i)){
             browserName = "opera";
           } else if(userAgent.match(/edg/i)){
             browserName = "edge";
           }else{
             browserName="No browser detection";
           }
           return browserName;
}