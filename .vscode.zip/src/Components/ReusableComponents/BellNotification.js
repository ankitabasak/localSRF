import React, { Component } from 'react';
import { connect } from "react-redux";
import agp_doticon from '../../../public/images/agp_doticon.svg';
import './BellNotification.css'
import { ClickBellNotification ,hideDownloadNotificationDotIcon } from '../../Redux_Actions/UniversalSelectorActions';
//import { DOWNLOADS_LINK } from '../../Utils/globalVars';
class BellNotification extends Component {
    constructor(props) {
        super(props);
        this.BellNotificationRef = {}
        this.handleClickOutside = this.handleClickOutside.bind(this);
        this.redirectToDownloads = this.redirectToDownloads.bind(this);

    }
    redirectToDownloads(anchor) {
      var hashIndex = window.location.href.indexOf('#');
      var url= window.location.href.slice(0, hashIndex >= 0 ? hashIndex : 0) + '#' + anchor;
      return url;       
    }
    componentDidMount() {
        document.addEventListener("mousedown", this.handleClickOutside);
    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.handleClickOutside);
    }
    handleClickOutside(event) {
        if (event.target == null || event.target == undefined) {
        }
        if (this.props.AgpCSV.BellNotification) {
            if (this.BellNotificationRef !== null && this.BellNotificationRef !== undefined) {
                let isitemexists = this.BellNotificationRef.contains(event.target);
                if (isitemexists == undefined || isitemexists == null || isitemexists == false) {
                    this.props.ClickBellNotification(true)

                }
            }

        }
    }
    render() {
      var downloads=  this.redirectToDownloads('downloads')
          return (
            <div className="ar_agp_download_notification">
                <span className="ar_agp_download_notification-banner-images" onClick={() =>
                    this.props.AgpCSV.BellNotification ?
                        this.props.ClickBellNotification(true) :
                        this.props.ClickBellNotification(false)}
                    ref={ref => (ref !== null ? this.BellNotificationRef = ref : null)}>
                  {this.props.AgpCSV.hideBellNotification === true || <img className="ar_agp_download_notification-icon" src={agp_doticon} /> }
                </span>
                {this.props.AgpCSV.BellNotification ? <div className="ar_agp_download_tooltip" ref={ref => (ref !== null ? this.BellNotificationRef = ref : null)}>
                    <div className="ar_agp_download_tooltip-inr">
                        <div className="ar_agp_download_tooltip-contant">Your files are ready to download.
        Go to the <a style={{textDecoration:"none"}} target="_blank" href={downloads}>
            <span onClick ={()=> this.props.hideDownloadNotificationDotIcon()}>Downloads</span></a> page.
      </div>
                    </div>
                </div> : null}
            </div>

        );
    }
}
const mapStateToProps = ({ Universal }) => {

    const { AgpCSV } = Universal;

    return { AgpCSV };
}
export default connect(mapStateToProps, { ClickBellNotification ,hideDownloadNotificationDotIcon })(BellNotification)