

/**
 *
 * @param {Array} --Array  Total Records of A graph
 * @param {int} Pagination_Start  -- Display LineChart record Starts From Pagination_Start
 * @param {int} Pagination_End -- Display LineChart record ends at Pagination_End
 * @returns {Object}
 */
export function rlpChartInput_Params(
  Array,
  Pagination_Start,
  Pagination_End,
  FromComponent
) {
  const XAxis_Params = {
    LabelOffSet: 60,
    LabelName: '',
    LabelFontSize: 16,
    LabelTickFontSize: 11,
    LabelTickX_param: 15
  };
  const YAxis_Params = {
    LabelOffset: FromComponent == 'rlp_chart' ? 50 : 30,
    LabelfontSize: 16,
    LabelName: 'Test Scores (%)',
    LabelTickFontSize: 11,
    LabelTickY_param: 15
  };

  const DatatPointParams = {
    DotRadius: 12,
    DotTextfontSize: 14,
    LinePathWidth: 1
  };

  if (FromComponent == 'rlp_chart') {
    var tooltipParams = {
      TooltipXcoordsPad: 10,
      TooltipYcoordsPad: 130,
      TooltipDisplayVisible: true
    };
    var margin = { left: 100, right: 0, bottom: 100, top: 40 };
    var width = 1200;
    var height = 600;
    var Ipadwidth = 920;
    var Ipadheight = 500;
  }

  const data =
    Array !== null ? Array.slice(Pagination_Start, Pagination_End) : [];

  return {
    XAxis_Params,
    YAxis_Params,
    DatatPointParams,
    tooltipParams,
    data,
    margin,
    width,
    height,
    Ipadwidth,
    Ipadheight
  };
}

//Sorting Data
export function dataSorting(list, column, sortType) {
  if (list && list.length > 0) {
    let arrayList = list.sort(function (a, b) {
      let firstElement =
        column !== 'lastName' ? a[column] : a[column].toString().toUpperCase();
      let secondElement =
        column !== 'lastName' ? b[column] : b[column].toString().toUpperCase();

      if (column === 'assignmentDate') {
        firstElement = new Date(firstElement);
        secondElement = new Date(secondElement);
      }

      let comparison = 0;
      if (firstElement > secondElement) {
        comparison = 1;
      } else if (firstElement < secondElement) {
        comparison = -1;
      }

      return sortType == 'desc' ? comparison * -1 : comparison;
    });
    return arrayList;
  }
}


export function getDate() {
  var today = new Date();
  var dd = String(today.getDate()).padStart(2, '0');
  var mm = String(today.getMonth() + 1).padStart(2, '0');
  var yyyy = today.getFullYear();

  today = dd + '/' + mm + '/' + yyyy;
  return today;
}

export function getDateFormat() {
  var getDay = new Date();
  var dd = String(getDay.getDate()).padStart(2, '0');
  var mm = String(getDay.getMonth() + 1).padStart(2, '0');
  var yyyy = getDay.getFullYear();

  getDay = mm + '/' + dd + '/' + yyyy;
  return getDay;
}

export function constructCsvData(payLoadData) {
  let headers = [];
  let csvData = [];
  headers = [{ label: "District Name", key: "district_name" },
  { label: "School Name", key: "school_name" },
  { label: "Grade", key: "grade" },
  { label: "Teacher Name", key: "teacher_name" },
  { label: "Class Name", key: "class_name" },
  { label: "Student Name", key: "student_name" },
  { label: "Student ID (SIS)", key: "student_id" },
  { label: "Passage Name", key: "component_title" },
  { label: "Reading Level", key: "letter_level" },
  { label: "Assignment Completion Date", key: "assignment_completion_date" },
  { label: "Language", key: "language" },
  { label: "Category", key: "category" },
  { label: "Type", key: "read_type" },
  { label: "Proficiency", key: "proficiency" },
  { label: "Accuracy", key: "accuracy" },
  { label: "Fluency (wcpm)", key: "fluency" },
  { label: "Error Rate", key: "error_rate" },
  { label: "Self-Correction Rate", key: "self_correction_rate" },
  { label: "Comprehension Score", key: "comprehension_score" },
  { label: "Substitutions", key: "marking_substitutions" },
  { label: "Ommissions", key: "marking_ommissions" },
  { label: "Insertions", key: "marking_insertions" },
  { label: "Tolds", key: "marking_tolds" },
  {label: "Repetitions", key: "marking_repetitions"},
  { label: "Self-Corrections", key: "marking_self_corrections" },
  { label: "Meaning", key: "cues_meaning" },
  { label: "Structural", key: "cues_structural" },
  { label: "Visual", key: "cues_visual" },
  { label: "MSV Not Scored", key: "cues_ommissions" },
  { label: "Retell", key: "retelling" },
  { label: "Fluency - Phrasing/Fluency", key: "fluency_Phrasing/Fluency" },
  { label: "Fluency - Intonation", key: "fluency_Intonation" },
  { label: "Fluency - Pace", key: "fluency_Pace" },
  { label: "Fluency - Accuracy", key: "fluency_Accuracy" },
  {
    label: "Reading Behavior: The student appears to control one-to-one matching on multi-syllable words",
    key: "RB_5_21"
  },
  {
    label: "Reading Behavior: The student appears to control directionality left to right",
    key: "RB_5_22"
  },
  {
    label: "Reading Behavior: The student appears to control directionality on return sweep",
    key: "RB_5_23"
  },
  {
    label: "Reading Behavior: The student appears to control locating known words",
    key: "RB_5_24"
  },
  {
    label: "Reading Behavior: The student appears to control locating unknown words",
    key: "RB_5_25"
  },
  {
    label: "Reading Behavior: The student appears to control one-to-one matching on one-syllable words",
    key: "RB_5_55"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student shows flexible use of strategies",
    key: "RB_6_20"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student self-corrects using different cues",
    key: "RB_6_26"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student cross-checks cue sources",
    key: "RB_6_27"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student appeals for help",
    key: "RB_6_28"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student rereads to confirm",
    key: "RB_6_29"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student uses pictures",
    key: "RB_6_30"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student uses the first letter",
    key: "RB_6_31"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student searches for visual patterns",
    key: "RB_6_32"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student uses known words to solve unknown words",
    key: "RB_6_33"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student attempts unfamiliar words",
    key: "RB_6_34"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student waits to be told",
    key: "RB_6_35"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student makes multiple attempts",
    key: "RB_6_36"
  },
  {
    label: "Reading Behavior: The student reads word-by-word",
    key: "RB_7_37"
  },
  {
    label: "Reading Behavior: The student uses fluent phrasing",
    key: "RB_7_38"
  },
  {
    label: "Reading Behavior: The student uses expression",
    key: "RB_7_39"
  }, {
    label: "Reading Behavior: At point of difficulty, the student shows flexible use of strategies",
    key: "RB_8_20"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student self-corrects using different cues",
    key: "RB_8_26"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student cross-checks cue sources",
    key: "RB_8_27"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student appeals for help",
    key: "RB_8_28"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student rereads to confirm",
    key: "RB_8_29"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student searches for visual patterns",
    key: "RB_8_32"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student uses known words to solve unknown words",
    key: "RB_8_33"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student attempts unfamiliar words",
    key: "RB_8_34"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student waits to be told",
    key: "RB_8_35"
  },

  {
    label: "Reading Behavior: At point of difficulty, the student shows increasing control of visual patterns",
    key: "RB_8_40"
  },

  {
    label: "Reading Behavior: At point of difficulty, the student uses word meaning and context clues to problem-solve",
    key: "RB_8_41"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student problem-solves at the point of error and makes multiple attempts to self-correct",
    key: "RB_8_42"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student searches through the problem word and blends sounds together",
    key: "RB_8_43"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student reads high-frequency words fluently",
    key: "RB_8_44"
  },
  {
    label: "Reading Behavior: The student uses fluent phrasing",
    key: "RB_9_38"
  },
  {
    label: "Reading Behavior: The student uses expression",
    key: "RB_9_39"
  },
  {
    label: "Reading Behavior: The student reads word by word",
    key: "RB_9_45"
  },
  {
    label: "Reading Behavior: The student uses punctuation",
    key: "RB_9_46"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student reads word by word",
    key: "RB_10_45"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student uses nonfiction text features (table of contents, headings, glossary, index, diagrams, etc.) to locate information and read for a purpose",
    key: "RB_10_47"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student decodes text using knowledge of sound/symbol relationships, including blends, dipgraphs, and irregular spelling patterns",
    key: "RB_10_48"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student decodes text using context clues, word structures, inflectional endings, and simple prefixes and suffixes",
    key: "RB_10_49"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student integrates meaning, structure, and visual cues to decode and comprehend text",
    key: "RB_10_50"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student reads fluently, needing to problem-solve on only one or two items",
    key: "RB_10_51"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student problem-solves mostly \"in the head\" rather than in observable ways",
    key: "RB_10_52"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student applies flexible strategies with good control of visual patterns",
    key: "RB_10_53"
  },
  {
    label: "Reading Behavior: At point of difficulty, the student builds on background knowledge to make sense of text",
    key: "RB_10_54"
  },
  {
    label: "Reading Behavior: The student uses fluent phrasing",
    key: "RB_11_38"
  },
  {
    label: "Reading Behavior: The student uses expression",
    key: "RB_11_39"
  },
  {
    label: "Reading Behavior: The student uses punctuation",
    key: "RB_11_46"
  }]


  payLoadData.csvData.data.map((dataList, index) => {
    let singleDataRow = ''
    singleDataRow = {
      'district_name': dataList['district_name'],
      'school_name': dataList['school_name'],
      'grade': dataList['grade'],
      'teacher_name': dataList['teacher_name'],
      'class_name': dataList['class_name'],
      'student_name': dataList['student_name'],
      'student_id': dataList['student_id'] === '' ? '-' : dataList['student_id'],
      'component_title': dataList['component_title'],
      'letter_level': dataList['letter_level'],
      'assignment_completion_date': dataList['assignment_completion_date'],
      'language': dataList['language'],
      'category': dataList['category'],
      'read_type': dataList['read_type'].charAt(0).toUpperCase() + dataList['read_type'].slice(1),
      'proficiency': dataList['proficiency'],
      'accuracy': dataList['accuracy'],
      'fluency': dataList['fluency'],
      'error_rate': dataList['error_rate'] === "NA" ? "No Errors" : " " + dataList['error_rate'],
      'self_correction_rate': dataList['self_correction_rate'] === "NA" ? "No Self-Corrections" : dataList['self_correction_rate'],
      'comprehension_score': dataList['comprehension_score'] ? " " + dataList['comprehension_score'] : dataList['comprehension_score'],
      'marking_substitutions': dataList['marking_substitutions'],
      'marking_ommissions': dataList['marking_ommissions'],
      'marking_insertions': dataList['marking_insertions'],
      'marking_tolds': dataList['marking_tolds'],
      'marking_repetitions': dataList['marking_repetitions'],
      'marking_self_corrections': dataList['marking_self_corrections'],
      'cues_meaning': dataList['cues_meaning'],
      'cues_structural': dataList['cues_structural'],
      'cues_visual': dataList['cues_visual'],
      'cues_ommissions': dataList['cues_ommissions'],
      'retelling': dataList['retelling'] ? " " + dataList['retelling'] : dataList['retelling'],
      'fluency_Phrasing/Fluency': dataList["fluency_Phrasing/Fluency"],
      'fluency_Intonation': dataList['fluency_Intonation'],
      'fluency_Pace': dataList['fluency_Pace'],
      'fluency_Accuracy': dataList['fluency_Accuracy'],
      'RB_5_21': dataList['RB_5_21'],
      'RB_5_22': dataList['RB_5_22'],
      'RB_5_23': dataList['RB_5_23'],
      'RB_5_24': dataList['RB_5_24'],
      'RB_5_25': dataList['RB_5_25'],
      'RB_5_55': dataList['RB_5_55'],
      'RB_6_20': dataList['RB_6_20'],
      'RB_6_26': dataList['RB_6_26'],
      'RB_6_27': dataList['RB_6_27'],
      'RB_6_28': dataList['RB_6_28'],
      'RB_6_29': dataList['RB_6_29'],
      'RB_6_30': dataList['RB_6_30'],
      'RB_6_31': dataList['RB_6_31'],
      'RB_6_32': dataList['RB_6_32'],
      'RB_6_33': dataList['RB_6_33'],
      'RB_6_34': dataList['RB_6_34'],
      'RB_6_35': dataList['RB_6_35'],
      'RB_6_36': dataList['RB_6_36'],
      'RB_7_37': dataList['RB_7_37'],
      'RB_7_38': dataList['RB_7_38'],
      'RB_7_39': dataList['RB_7_39'],
      'RB_8_20': dataList['RB_8_20'],
      'RB_8_26': dataList['RB_8_26'],
      'RB_8_27': dataList['RB_8_27'],
      'RB_8_28': dataList['RB_8_28'],
      'RB_8_29': dataList['RB_8_29'],
      'RB_8_32': dataList['RB_8_32'],
      'RB_8_33': dataList['RB_8_33'],
      'RB_8_34': dataList['RB_8_34'],
      'RB_8_35': dataList['RB_8_35'],
      'RB_8_40': dataList['RB_8_40'],
      'RB_8_41': dataList['RB_8_41'],
      'RB_8_42': dataList['RB_8_42'],
      'RB_8_43': dataList['RB_8_43'],
      'RB_8_44': dataList['RB_8_44'],
      'RB_9_38': dataList['RB_9_38'],
      'RB_9_39': dataList['RB_9_39'],
      'RB_9_45': dataList['RB_9_45'],
      'RB_9_46': dataList['RB_9_46'],
      'RB_10_45': dataList['RB_10_45'],
      'RB_10_47': dataList['RB_10_47'],
      'RB_10_48': dataList['RB_10_48'],
      'RB_10_49': dataList['RB_10_49'],
      'RB_10_50': dataList['RB_10_50'],
      'RB_10_51': dataList['RB_10_51'],
      'RB_10_52': dataList['RB_10_52'],
      'RB_10_53': dataList['RB_10_53'],
      'RB_10_54': dataList['RB_10_54'],
      'RB_11_38': dataList['RB_11_38'],
      'RB_11_39': dataList['RB_11_39'],
      'RB_11_46': dataList['RB_11_46'],
    }

    csvData.push(singleDataRow)
  })
  return { 'header': headers, 'data': csvData }
}

function modifyORRdatesForDistrictAndSchool(Req_Payload, headerProps) {
  const modifiedDates = Req_Payload.externalFilter;
  let termStartDate = null;
  let termEndDate = null;
  if (headerProps.ContextHeader !== undefined) {
    if (headerProps.ContextHeader.Date_Tab !== undefined) {
      if (headerProps.ContextHeader.Date_Tab.selectedterm_Obj !== undefined) {
        termStartDate =
          headerProps.ContextHeader.Date_Tab.selectedterm_Obj.termStartDate;
        termEndDate =
          headerProps.ContextHeader.Date_Tab.selectedterm_Obj.termEndDate;
      }
    }
  }
  if (termStartDate !== null) {
    const startEpoch = Date.parse(modifiedDates.startDate);
    const termStartEpoch = Date.parse(termStartDate);
    if (startEpoch < termStartEpoch) {
      const resetStart = new Date(termStartEpoch);
      const startToConvert =
        resetStart.getFullYear()+'-'+(resetStart.getMonth()+1)+'-'+resetStart.getDate();
      modifiedDates.startDate = formatDateForApi(startToConvert);
    }
    const endEpoch = Date.parse(modifiedDates.endDate);
    const termEndEpoch = Date.parse(termEndDate);
    if (endEpoch > termEndEpoch) {
      const resetEnd = new Date(termEndEpoch);
      const endToConvert =
        resetEnd.getFullYear()+'-'+(resetEnd.getMonth()+1)+'-'+resetEnd.getDate();
      modifiedDates.endDate = formatDateForApi(endToConvert);
    }
  }
  return modifiedDates
}

export function getCommonHeaders(headerProps, chartName) {
  let termIdVar = "";
  try {
    termIdVar = headerProps.ContextHeader.Date_Tab.selectedterm_Obj.termId;
  } catch (error) {

  }
  let reportTermEndDate;
  let reportTermStartDate;
  if (headerProps.ContextHeader) {
    reportTermEndDate = headerProps.ContextHeader.Date_Tab.Report_termEndDate ?
      headerProps.ContextHeader.Date_Tab.Report_termEndDate :
      headerProps.ContextHeader.Date_Tab.selectedterm_Obj.termEndDate;

    reportTermStartDate = headerProps.ContextHeader.Date_Tab.Report_termStartDate ?
      headerProps.ContextHeader.Date_Tab.Report_termStartDate :
      headerProps.ContextHeader.Date_Tab.selectedterm_Obj.termStartDate;
  }

  const Req_Payload = {
    externalFilter: {
      endDate: formatDateForApi(reportTermEndDate),
      startDate: formatDateForApi(reportTermStartDate),
      termId : termIdVar,
      ...getIds(headerProps, chartName)
    },
    internalFilter: headerProps.CommonFilterData
  };
  if (chartName === 'school' || chartName === 'district') {
    Req_Payload.externalFilter =
      modifyORRdatesForDistrictAndSchool(Req_Payload, headerProps);
  }
  return Req_Payload;
}

export const formatDateForApi = (date) => {
  if (date) {
    const tempDate = date.split(" ")[0];
    const dateFormat = tempDate.split("-");
    let month;
    let day;
    if (dateFormat[1].length > 1) {
      month = dateFormat[1];
    } else {
      month = "0" + dateFormat[1]
    }
    if (dateFormat[2].length > 1) {
      day = dateFormat[2];
    } else {
      day = "0" + dateFormat[2]
    }
    return month + "/" + day + "/" + dateFormat[0];
  }
};

export const getIds = (headerProps, chartName) => {
  let Summary_Reports;
  if (headerProps.NavigationByHeaderSelection) {
    ({ Summary_Reports } = headerProps.NavigationByHeaderSelection);
  }
  let ContextHeader_RosterTab = headerProps.ContextHeader ? headerProps.ContextHeader.Roster_Tab : undefined;
  if(Summary_Reports) {
    ContextHeader_RosterTab = headerProps.ContextHeader.Summary_Roster_Data
  }
  let selectedSchoolId;
  let studentIds = [];
  if (ContextHeader_RosterTab) {
    selectedSchoolId = ContextHeader_RosterTab.SelectedSchool.id;
    studentIds = ContextHeader_RosterTab.StudentIds;
  }

  switch (chartName) {
    case 'student':
      return {
        studentId: ContextHeader_RosterTab.SelectedStudent.id,
        schoolId: selectedSchoolId, //'10001'
      }
    case 'class':
      return {
        classId: ContextHeader_RosterTab.SelectedClass.id, //10014
        schoolId: selectedSchoolId, //'10001'
        grade: ContextHeader_RosterTab.selectedRosterGrade,
        selectedStudentsList: studentIds,
      }
    case 'school':
      return {
        schoolId: selectedSchoolId, //'10001'
        selectedStudentsList: studentIds//[]
      }
    case 'district':
      return {
        districtId: ContextHeader_RosterTab.SelectedDistrict.id,//10000
        selectedStudentsList:studentIds,//[]
      }
  }
}
