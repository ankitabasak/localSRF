import React, { Component } from 'react';
import spinner from '../../../../public/assets/orr/rlp-screen/loader-white-bg.gif';
import '../../ORR/ErrorAnalysisComponents/ErrorAnalysis.css';

class Spinner extends Component {
  // if spinner component is up and running start timer
  componentDidMount() {
    if (this.props.startSpinner) {
      this.interval = setInterval(() => {
        this.props.showTimeOut();
        clearInterval(this.interval);
      }, 90000);
    } else {
      clearInterval(this.interval);
    }
  }

  componentWillUnmount() {
    // clearing timer so that t never returns time out component
    clearInterval(this.interval);
  }

  render() {
    return (
      <div>
        <div className="spinner-container">
          <img src={spinner} alt="spinner" />
        </div>
      </div>
    );
  }
}

export default Spinner;
