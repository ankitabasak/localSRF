import React, { Component } from 'react';
import '../../../../public/css/style.css';
import icon from '../../../../public/images/no_data_found.svg';

class TimeOut extends Component {
  render() {
    let ScreenHeight = window.screen.availHeight;
    return (
      <div className="grey_background" style={{ height: ScreenHeight }}>
        <div className="grey_background_extend">
          <div className="model_center content-wdt">
            <div className="model_center_img">
              <img className="h-118" style={{ paddingTop: '25px' }} src={icon} />
            </div>
            <div className="model_center_no_data_line ">
              The Chart Did Not Load!
            </div>

            <div className="model_center_take_me_back">
              <div
                style={{ cursor: 'pointer' }}
                onClick={() => {
                  this.props.tryAgain();
                }}
                className="model_center_take_me_back_text"
              >
                Retry
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default TimeOut;
