import React, { Component } from 'react';
import '../../../public/css/style.css';
import { connect } from 'react-redux';
import { convertGrade } from '../Common/UniversalFilter/Roster';
import { Scrollbars } from 'react-custom-scrollbars';
import PaginationComponent from '../../Utils/UniversalSelector_Pagination';


class RosterField extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            SearchFocus: false
        }
    }

    ReturnList(ItemsList, Selected, Pagination, OpenDropDown, Fieldfor, Roster_Data) {

        // // let Pagination = this.props.Pagination;
        // let StudentsList = StdList;

        let List = ItemsList.length != 0 ?
            ItemsList.slice(Pagination.countStart, Pagination.countEnd) : [];

        let AllSelected = IsAllSelected(Fieldfor, Roster_Data)

        return <div className="menu-dropdown-list-inr">
            <ul>
                {List.length === 0 ?
                    null
                    : <li value="All"
                        style={{ backgroundColor: Selected === 'All' ? "#d0d6e1" : "" }}
                        onClick={(txt) => {
                            let SelectedAll = !AllSelected
                            /**
                             * 1-> selected student
                             * 2-> student index
                             * 3-> true or false
                             */
                            this.props.SaveSelectedStudent("All", 0, SelectedAll);
                        }}
                    >
                        <div className="rosterTabStudentList">
                            <div
                                className="input-checkbox checkbox-lightBlue"
                            >
                                <input
                                    checked={AllSelected}
                                    value={AllSelected}
                                    type="checkbox" />
                                <span className="checkbox"></span>
                            </div>
                        </div>
                        All</li>}
            </ul>
            <ul>
                <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={210}>
                    {List.length === 0 ? <li>No Records Available</li> :

                        List.map((item, indx) =>
                            <li
                                style={{ backgroundColor: item.id === Selected.id ? "#d0d6e1" : "" }}
                                onClick={(txt) => {
                                    // if (item.id !== SelectedStudent.id) {
                                    // let Student = item;
                                    let check = item.check === undefined ? false : !item.check
                                    this.props.SaveSelected(item, indx, check);
                                    // }
                                }} value={item.id} key={indx}>
                                <div className="rosterTabStudentList">
                                    <div
                                        className="input-checkbox checkbox-lightBlue"
                                    >
                                        <input
                                            checked={item.check}
                                            value={item.check}
                                            type="checkbox" />
                                        <span className="checkbox"></span>
                                    </div>
                                </div>
                                <span></span>
                                {item.name}
                            </li>
                        )}
                </Scrollbars>
            </ul>
            {Pagination.totalPagesCount > 1 && OpenDropDown ?
                // this.ReturnPaginationMain(Pagination, StdList)
                <PaginationComponent
                    Pagination={Pagination}
                    paginationbubbleCount={Pagination.totalPagesCount} />
                : null}
        </div>
    }

    render() {


        let { Fieldfor, Loading, OpenDropDown, RosterList, Selected, Pagination, Actu__List,
            ClearSearch_Fun, Roster_Data } = this.props;

        Actu__List = Actu__List == undefined ? [] : Actu__List;

        return <div>
            <div className="universal-input-field">
                <div className="menu-title">
                    {Fieldfor}
                    <span className="data-refresh">
                        {Loading == "grade" ?
                            <i className="material-icons">autorenew</i> : null}
                    </span>
                </div>
                <div className={OpenDropDown ?
                    "menu-selector active-selector" : "menu-selector"}>
                    <button
                        style={{
                            background: RosterList.length <= 1 ?
                                "#FFF" : ""
                        }}
                        // className={School_Ids.length > 1 && isDistrictAdmin ? "disable_us" : "select-dropdown"} // disable_us
                        className={"select-dropdown"}
                        onClick={() => {

                            this.props.OnSelect_DropDown();

                            // if (((RosterList.length !== 1 && RosterList.length !== 0 && Loading == '') ||
                            //     (RosterList.length == 1 && (U_Selector.selectedRosterGrade == null ||
                            //         U_Selector.selectedRosterGrade == "")))
                            //     //  && School_Ids.length == 1
                            // ) {

                            //     let selected_School = U_Selector.Roster_Data.SelectedSchool;
                            //     let Call_Get_SChool_Details_Api = U_Selector.Roster.OpenScoolDropDown && selected_School.id !== undefined;
                            //     if (selected_School.id !== undefined) {
                            //         selected_School = U_Selector.Roster_Data.schoolsList.filter(item => item.id == selected_School.id)[0];
                            //     }

                            //     let AccessToken = this.props.LoginDetails.JWTToken;
                            //     let Dateterm = this.props.ContextHeader.Date_Tab.selectedterm_Obj;
                            //     let FromDist_Report = false;

                            //     this.props.OpenSelectorInRoaster('grade', Call_Get_SChool_Details_Api, selected_School, AccessToken, Dateterm, FromDist_Report)
                            //     this.FilterDropDownList("", 'grade')
                            // }
                        }
                        }>
                        <span className="Roster-Dropdown-text">
                            {Selected !== undefined && Selected !== ""
                                ? Selected == "All" ? "All" : convertGrade(Selected) : RosterList.length == 0 ? "No Records Available" : 'Select Grade'}
                        </span>
                    </button>
                    {this.ReturnList(RosterList, Selected, Pagination, OpenDropDown, Fieldfor, Roster_Data)}

                </div>
            </div>
        </div >
    }


}

const mapStateToProps = ({
    Universal,
    Authentication,
    CommonFilterDetails,
    School_FA_Reducer
}) => {
    const {
        UniversalFilter,
        UniversalSelecter,
        OpenMainmenu,
        Pagination,
        ApiCalls,
        UserScreenWidth,
        ContextHeader,
        NavigationByHeaderSelection
    } = Universal;
    const { LoginDetails } = Authentication;
    const { CommonFilterData } = CommonFilterDetails;
    const { School_fpot, ScFTabSelection } = School_FA_Reducer;
    return {
        UniversalFilter,
        UniversalSelecter,
        OpenMainmenu,
        Pagination,
        ApiCalls,
        UserScreenWidth,
        ContextHeader,
        LoginDetails,
        NavigationByHeaderSelection,
        CommonFilterData,
        School_fpot,
        ScFTabSelection
    };
};

export default connect(
    mapStateToProps,
    {

    }
)(RosterField);



function IsAllSelected(Fieldfor, Roster_Data) {
    if (Fieldfor == "Student") {
        return Roster_Data.ActualStudents.length == Roster_Data.StudentIds.length
    } else {
        return false
    }
}