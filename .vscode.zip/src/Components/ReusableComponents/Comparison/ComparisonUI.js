import React, { Component } from 'react';

class ComparisonUI extends Component {
    state = {  }
    render() { 
        return (
            <div>
                This is a Comparison Tab Page that we are going to show.
            </div>
        );
    }
}
 
export default ComparisonUI;