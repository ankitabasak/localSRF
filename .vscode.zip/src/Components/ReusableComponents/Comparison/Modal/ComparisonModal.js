import React, { Component } from 'react';

class ComparisonModal extends Component {
    state = {  }
    render() { 
        return (
            <div>
                Modal PopUp that we are calling from Click
            </div>
        );
    }
}
 
export default ComparisonModal;