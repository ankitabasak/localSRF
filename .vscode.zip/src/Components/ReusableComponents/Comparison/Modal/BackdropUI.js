import React, { Component } from 'react';

class BackdropUI extends Component {
    state = {  }
    render() { 
        return (
            <div>
                This is a BackdropUI
            </div>
        );
    }
}
 
export default BackdropUI;