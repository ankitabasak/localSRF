import React, { Component } from 'react';
import '../../../public/css/style.css';
import { connect } from 'react-redux';

import { FooterAction } from '../../Redux_Actions/UniversalSelectorActions';
import { AccessToKeyFooter } from '../../Utils/globalVars';

import { CloseUniversalFilter } from '../../Redux_Actions/UniversalSelectorActions_Secondary';
// import SpotModal from './usables/SpotModal';
import AchivementLevels from '../AchivementLevels';
class Footer extends Component {

  componentDidUpdate() {
    if (this.props.FooterOpen) {

      // window.scrollTo(0, document.body.scrollHeight);
      // window.scrollTo(0, document.body.scrollHeight);

    }
  }

  /**
   * Return Footer View If the Footer Is Open State.
   */

  render() {
    let Nav = this.props.NavigationByHeaderSelection
    const role = this.props.LoginDetails.UserRole

    let currentApplication = ((Nav.ORR) ? 'ORR' : '');
    currentApplication += ((Nav.Assessement) ? 'eAR': '');
    currentApplication += ((Nav.usageReport) ? 'usage': '');
    const showFooterKey = AccessToKeyFooter.includes(currentApplication)
    const {LoginDetails} = this.props;
    const {ReportingAccessParam} = LoginDetails;
    let OnlyORRAccess = !ReportingAccessParam.includes('eAR') && ReportingAccessParam.includes('ORR');

    return (
      <div id="footerView" className="footer_container_main">

        <footer>
          <div className="footer_container_inr">
            {(!OnlyORRAccess && showFooterKey && !(Nav.test_status && (!Nav.comparison || !Nav.grouping || !Nav.summary))) && (

              <div className="becfooter-container">
                <div
                  className={
                    this.props.FooterOpen ? "footer-container-inr active-keytoggle" :
                      "footer-container-inr"}>
                  <div className="footer-key-btn-container">
                    <div className="footer-key-btn"
                      style={{ cursor: 'pointer' }}
                      onClick={() => this.props.UniversalFilter !== '' ? null : this.props.FooterAction()}>
                      <span>
                        <i className="material-icons">{this.props.FooterOpen ? "expand_more" : "expand_less"}</i> Key
                    </span>
                    </div>

                    <div onClick={() =>
                      this.props.UniversalFilter === '' ? null :
                        this.props.CloseUniversalFilter('OutSideUniversalClickRef')
                    }
                      className={this.props.UniversalFilter !== "" ?
                        this.props.FooterOpen ? "back-drop-footer" : "back-drop-footer-close" : ""}>
                    </div>

                  </div>
                  <div className="footer-indicators">
                    <div className="footer-indicators-fullwidth ">
                      {this.props.AchivementLevels != undefined && this.props.AchivementLevels.length >0?<div className={Nav.st_analysis ? "footer-indicators-singletest" : "footer-indicators-global"}>
                        {/* footer-indicators-singletest */}
                        <div className="footer-indicate-title">Achievement Levels </div>
                        <div className="footer-indicators-list">
                             {<AchivementLevels AchivementLevels={this.props.AchivementLevels} />}
                        </div>
                      </div>:null}
                      {Nav.st_analysis ? <div className="footer-indicators-singletest-analysis">
                        <div className="footer-indicators-singletest-analysis-inr">
                          <div className="footer-indicate-title">Questions </div>
                          <div className="footer-st_analysis-indicators-list">
                            <ul>

                              <li>
                                <div className="footer-st_analysis-single-indicator">
                                  <span className="footer-st_analysis-key-bar footer-st_analysis-key_greenbg">
                                    <i class="material-icons">done</i>
                                  </span>
                                  <span className="footer-st_analysis-single-indicator-title">Correct</span>
                                </div>
                              </li>
                              <li>
                                <div className="footer-st_analysis-single-indicator">
                                  <span className="footer-st_analysis-key-bar footer-st_analysis-key_redbg">
                                    <i class="material-icons">clear</i>
                                  </span>
                                  <span className="footer-st_analysis-single-indicator-title">Incorrect</span>
                                </div>
                              </li>
                              <li>
                                <div className="footer-st_analysis-single-indicator">
                                  <span className="footer-st_analysis-key-bar footer-st_analysis-key_yellowbg">
                                    <span className="footer-st_analysis_halfMark">
                                    </span>
                                  </span>
                                  <span className="footer-st_analysis-single-indicator-title">Partial</span>
                                </div>
                              </li>
                              <li>
                                <div className="footer-st_analysis-single-indicator">
                                  <span className="footer-st_analysis-key-bar footer-st_analysis-key_nobg">
                                    <i class="material-icons">clear</i>
                                  </span>
                                  <span className="footer-st_analysis-single-indicator-title">Not Answered</span>
                                </div>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </div> : null}
                    </div>
                  </div>
                </div>
                {/*  */}
              </div>

            )}
            <div className="footer-bottom">
              <div className="footer-left">
                &copy; Benchmark Education Company LLC All rights reserved.
          </div>
              <div className="footer-right">
                <a href="http://help.benchmarkuniverse.com/bustudent/#Student%20Customer%20Support/Privacy%20Policy.htm"
                  target="_blank" className="privacy">Privacy Policy</a>
              </div>
            </div>
          </div>
        </footer>
      </div >
    )
  }
}

const mapStateToProps = ({ Universal, Authentication }) => {

  const { FooterOpen, UniversalFilter, NavigationByHeaderSelection, AchivementLevels } = Universal;
  const { LoginDetails } = Authentication;
  return { FooterOpen, UniversalFilter, NavigationByHeaderSelection, AchivementLevels, LoginDetails };
}

export default connect(mapStateToProps, {
  FooterAction, CloseUniversalFilter
})(Footer);
