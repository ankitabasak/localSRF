import React, { Component } from 'react';
import '../../../../public/css/style.css';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { } from '../../../Redux_Actions/UniversalSelectorActions';
import ContextHeader from './ContextHeader';
import cn from 'classnames';

import { SaveContextSelection } from '../../../Redux_Actions/UniversalSelectorActions';
import { SUMMARY_REPORTS_FLAG } from '../../../Utils/globalVars';

class ReportSelector extends React.PureComponent {
  constructor(props) {
    super(props);
  }
  componentDidUpdate() {
    let Nav = this.props.NavigationByHeaderSelection;
    // if (Nav.T_scores) {
    //     this.props.history.push('/class/testscore/overview')
    // }
  }

  render() {
    let SummaryReportsAccessesingFirstTime = this.props.SummaryReportsAccessesingFirstTime;
    let Nav = this.props.NavigationByHeaderSelection;
    let ReportingAccess = this.props.LoginDetails.ReportingAccessParam;
    const { isPastDistrictTerm, isTermIdsEqualAndNull } = this.props;
    const classNamesForORR = cn('', {
      active: Nav.O_R_R === 'display_and_selected',
      '': Nav.O_R_R === 'display_and_not_selected',
      hide: Nav.O_R_R === 'hide'
    });

    let SummaryDeactivateCond = Nav.student || (!Nav.Summary_Reports && (isPastDistrictTerm) && !SummaryReportsAccessesingFirstTime && (Nav.district || Nav.school || Nav.class));
    return (
      <div className="container-fluid m-0 p-0 float-left page-selectors">
        <div className="page-selectors-inr">
          <div className="row m-0 p-0">
            <ul className="p-0 mb-0 mx-auto text-center">



              {SUMMARY_REPORTS_FLAG ? <li

                onClick={() =>
                  Nav.student || (Nav.Summary_Reports || ((Nav.district || Nav.school || Nav.class) && (isPastDistrictTerm) && !SummaryReportsAccessesingFirstTime))
                    ? null
                    : this.props.SaveContextSelection('Summary_Reports')
                }
                className={SummaryDeactivateCond ? "ar_summary_deactivate_in_pastdistrict_term ar_summary-tab" : (Nav.Summary_Reports ? ' active' : '')}
              >
                <div className="ar_summary-tab-tooltip">
                  <div className="ar_summary-tab-tooltip-inr">
                    <div className="ar_summary-tab-tooltip-context">{Nav.student?"Summary reports are not available at student level.":"Summary reports are not available for past school year."}</div>
                  </div>
                </div>
                <span className={SummaryDeactivateCond ? "ar_summary_deactivate_lable_opacity" : ""}>Summary</span>
              </li> : null}

              {ReportingAccess.includes("usageReports") ? <li
                onClick={() => {
                  if (!Nav.usageReport) {

                    return this.props.SaveContextSelection('usageReports');
                  }
                  return null;
                }}
                className={Nav.usageReport ? 'active' : ''}
              >
                Usage
                </li> : null}

              {ReportingAccess.includes("eAR") ? <li
                onClick={() =>
                  Nav.Assessement
                    ? null
                    : this.props.SaveContextSelection('Assessement')
                }
                className={Nav.Assessement ? 'active' : ''}
              >
                Assessments
                </li> : null}
              {ReportingAccess.includes("ORR") ? <li
                onClick={() =>
                  Nav.ORR
                    ? null
                    : this.props.SaveContextSelection('ORR')
                }
                className={Nav.ORR ? 'active' : ''}
              >
                Oral Reading Records
                </li> : null}

              {/* <li
                    onClick={() =>
                      Nav.O_R_R === 'display_and_selected'
                        ? null
                        : this.props.SaveContextSelection('O_R_R')
                    }
                    className={classNamesForORR}
                  >
                  Oral Reading Records
                </li> */}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ Authentication, Universal }) => {
  const { LoginDetails } = Authentication;
  const { NavigationByHeaderSelection, isTermIdsEqualAndNull, isPastDistrictTerm, SummaryReportsAccessesingFirstTime } = Universal;
  const { User_Role } = Universal.ContextHeader;
  return { NavigationByHeaderSelection, LoginDetails, isTermIdsEqualAndNull, isPastDistrictTerm, SummaryReportsAccessesingFirstTime, User_Role };
};

export default withRouter(
  connect(
    mapStateToProps,
    {
      SaveContextSelection
    }
  )(ReportSelector)
);
