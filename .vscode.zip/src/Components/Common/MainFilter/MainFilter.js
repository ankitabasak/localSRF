import React, { Component } from "react";
import "../../../../public/css/style.css";
import { connect } from "react-redux";
import {
  SetUsageReportsNavigationLevel,
  FilterMainModule,
  ChangeStickyContextHeader,
  SaveContextSelection,
  ChangeStickyUniversalSelector,
  GetStudent_Data_Action,
} from "../../../Redux_Actions/UniversalSelectorActions";

import { getInitialStudentObj } from "../../../Redux_Actions/Student_ReportsAction";
import { SaveSelectedSchool } from "../../../Redux_Actions/UniversalSelectorActions_Secondary";
import ContextHeader from "./ContextHeader";
import SelectionTabFilter from "./Selection_Tab_Filter";
import Switching_Blocks_Filter from "./Switching_Blocks_Filter";
import ReportSelector from "./ReportSelector";
import StudentIcon from "../../../../public/images/ic_student.svg";

import SchoolIcon from "../../../../public/images/ic_school.svg";
import DistrictIcon from "../../../../public/images/ic_district.svg";

import { Get_StudentData } from "../../../services/student.service";
import {
  GetIds_of_Each_Object_In_The_Array,
  Sort_ApiResponse_Payload_Array,
  AllClassesList,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compare,
  getGradeOfClassFromRoaster,
  Check_Previous_Report_List_Modified_Or_Not,
  getClassAndSchoolListOfStudentData,
} from "../../ReusableComponents/AllReusableFunctions";

import {
  GetStudentsListOfstandardOrStrandId,
  GetLineChartDetailsofSelected_Standards,
  Get_Class_TestScores_Over_Time,
} from "../../../Redux_Actions/ReportsActions";

import {
  Get_Student_TestScores_Details,
  Get_Student_StandardPerformance_Table,
  GetLineChartDetailsof_Student_Standards,
  getTestAssessmentMaxCountOfStudent,
} from "../../../Redux_Actions/Student_ReportsAction";
import BreadCrumbSelector from "./BreadCrumbSelector";
import { getGroupingStudentList_Ts_SummaryDetails } from "../../../Utils/TestStatus/TestScore_Blocks";
import { schoolObjCondition } from "../UniversalFilter/RosterUtils";
import { EnddateValues, StartdateValues } from "../../../Utils/reUsableSnipets";

class MainFilter extends Component {
  constructor(props) {
    super(props);
    this.handleScroll = this.handleScroll.bind(this);
    this.GetSingleTestContextInfo = this.GetSingleTestContextInfo.bind(this);
  }
  /**
   *  Add Event to listen On window page Scrolling .
   */
  componentDidMount() {
    window.addEventListener("scroll", this.handleScroll);
  }

  /**
   * Remove Event wile we remove this component from DOM.
   */

  componentWillUnmount() {
    window.removeEventListener("scroll", this.handleScroll);
  }
  /**
   * if context header reaches certain height will make it sticky by changeing redux state.
   */
  handleScroll() {
    let element = this.refs.Sticky_context_header;
    var domRect = element.getBoundingClientRect();
    if (domRect.top > 0) {
      this.props.StickyContextHeader
        ? this.props.ChangeStickyContextHeader()
        : null;
    } else {
      this.props.StickyContextHeader
        ? null
        : this.props.ChangeStickyContextHeader();
    }

    if (domRect.top > 57) {
      this.props.StickyUniversalSelector
        ? this.props.ChangeStickyUniversalSelector()
        : null;
    } else {
      this.props.StickyUniversalSelector
        ? null
        : this.props.ChangeStickyUniversalSelector();
    }
  }

  getInitialStudentObj() {
    if (this.props.ApiCalls.STUDENT_OBJ_API) {
      let AccessToken = this.props.LoginDetails.JWTToken;
      let Context_Header = this.props.ContextHeader;
      let ids = Context_Header.Roster_Tab.StudentIds;
      if (ids.length == 0 && this.props.NavigationByHeaderSelection.student) {
        ids = this.props.UniversalSelecter.Roster_Data.StudentIds;
      }
      let startDate = Context_Header.Date_Tab.Report_termStartDate;
      let endDate = Context_Header.Date_Tab.Report_termEndDate;
      let classId = Context_Header.Roster_Tab.SelectedClass.id;
      let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
      let currentTermId = this.props.currentTermID;
      let rosterGrade = Context_Header.Roster_Tab.selectedRosterGrade
      if ((startDate == undefined || startDate == "") && !this.props.NavigationByHeaderSelection.test_status) {
        startDate = StartdateValues(this.props.Context_DateTab)
      }
      if ((endDate == undefined || endDate == "") && !this.props.NavigationByHeaderSelection.test_status) {
        endDate = EnddateValues(this.props.Context_DateTab)
      }
      if (classId == undefined) {
        classId = this.props.UniversalSelecter.Roster_Data.SelectedClass.id;
      }
      if (schoolId == undefined) {
        schoolId = this.props.UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      if (rosterGrade == undefined && this.props.UniversalSelecter.Roster_Data.SelectedGrade != undefined) {
        rosterGrade = this.props.UniversalSelecter.Roster_Data.SelectedGrade;
      }
      if (currentTermId == undefined) {
        currentTermId = this.props.Context_DateTab.SelectedDistrictTerm.termId;
        if (this.props.NavigationByHeaderSelection.test_status) {
          currentTermId = this.props.Context_DateTab_TestStatus.SelectedDistrictTerm.termId;
        }
      }
      let Req_Payload = {
        classId: classId,
        schoolId: schoolId,
        rosterGrade: rosterGrade,
        startDate: startDate,
        endDate: endDate,
        districtId: Context_Header.DistrictId
          ? Context_Header.DistrictId
          : Context_Header.Roster_Tab.SelectedDistrict.id,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        termId: Context_Header.Date_Tab.selectedTermId,
        currentTermId: currentTermId,
        ids: Context_Header.Roster_Tab.StudentIds,
      };
      this.props.getInitialStudentObj(
        Req_Payload,
        AccessToken,
        this.props.NavigationByHeaderSelection
      );
    }
  }
  componentDidUpdate() {
    /*  If school and class is selected , will request for the test data of selected school & class */
    let Reports_APICall = this.props.ApiCalls_Reports;
    let AccessToken = this.props.LoginDetails.JWTToken;
    let Context_Header = this.props.ContextHeader;
    let Nav = this.props.NavigationByHeaderSelection;

    /**
     *  get student and linechart of a selected strand or standard in class context.
     */
const {getStudentData_cls, loadingFor} = this.props.ApiCalls;
    if (
      this.props.ApiCalls.getStudentData_cls &&
      this.props.ApiCalls.STUDENT_OBJ_API == false
    ) {
      let StdIds = this.props.UniversalSelecter.Roster_Data.SelectedStudent.id;
      let TermId = this.props.ContextHeader.Date_Tab.selectedTermId;
      let getTestsAfterStd_Data = this.props.ApiCalls.getTestsAfterStd_Data;
      Get_StudentData(StdIds, TermId, this.props, getTestsAfterStd_Data);
    }

    this.getInitialStudentObj();

    let ClassStrandsObject = this.props.StandardPerformance_Overview;

    if (
      Reports_APICall.get_students_and_Graph_ofClassStrand &&
      !Reports_APICall.loading_Strands_table &&
      ClassStrandsObject.ActualList.length !== 0 &&
      Nav.class &&
      Nav.S_performance &&
      Nav.Overview
    ) {
      let StrandsList = [];
      let strandAvg = "";
      let strandName = "";
      let standardId = "";
      let selectedStandard = null;
      let Strand_List = ClassStrandsObject.ActualList.strands;
      let strandardsarray = [];
      let StrandSelectionIsExist =
        (ClassStrandsObject.selectedStandardId === "" ||
          ClassStrandsObject.selectedStandardId === null) &&
        (ClassStrandsObject.StrandNameOfSelectedStandard == "" ||
          ClassStrandsObject.StrandNameOfSelectedStandard == null);

      if (!StrandSelectionIsExist) {
        if (
          ClassStrandsObject.selectedStandardId === "" ||
          ClassStrandsObject.selectedStandardId === null
        ) {
          // let SelectedStrand = [];
          for (var i = 0; i < Strand_List.length; i++) {
            if (
              Strand_List[i].strandName ==
              ClassStrandsObject.StrandNameOfSelectedStandard
            ) {
              StrandsList = Strand_List[i];
              break;
            }
          }

          StrandsList =
            StrandsList.standards == undefined ? Strand_List[0] : StrandsList;
          strandAvg = StrandsList.strandAvg;
          strandName = StrandsList.strandName;

          strandardsarray = GetIds_of_Each_Object_In_The_Array(
            StrandsList.standards,
            strandName,
            "forapicall"
          );
        } else if (
          ClassStrandsObject.selectedStandardId !== "" &&
          ClassStrandsObject.selectedStandardId !== null
        ) {
          strandAvg = ClassStrandsObject.selectedstandardObject.standardAvg;
          standardId = ClassStrandsObject.selectedstandardObject.standardId;
          strandName = ClassStrandsObject.StrandNameOfSelectedStandard;
          strandardsarray =
            ClassStrandsObject.selectedstandardObject.nationalStdIds;
          selectedStandard = ClassStrandsObject.selectedstandardObject;
        }
      } else {
        StrandsList = ClassStrandsObject.ActualList.strands[0];
        strandAvg = StrandsList.strandAvg;
        strandName = StrandsList.strandName;
        strandardsarray = GetIds_of_Each_Object_In_The_Array(
          StrandsList.standards,
          strandName,
          "forapicall"
        );
      }

      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTestList = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );
      // let ActualStudents = Context_Header.StudentList_Actual
      // let SelectedStudents = ActualStudents.length == Context_Header.SelectedMultipleStudents.length ? [] : Context_Header.SelectedMultipleStudents;

      let selectedTestAssessment =
        ClassStrandsObject.StandardPerformanceFilter.TestAssessment
          .selectedTestAssessment;
      selectedTestAssessment =
        selectedTestAssessment == "" ? 1 : selectedTestAssessment;

      // let ClassId = Context_Header.Class.id == undefined ? ContextHeader.Default_classID : Context_Header.Class.id

      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      let Compare_Std_Ids =
        SchoolStds == undefined || SchoolStds == null
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));
      if (Compare_Std_Ids.length == 0) {
        let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }

      let Grade =
        ClassStrandsObject.StandardPerformanceFilter.TestGrade
          .selectedTestgrade !== ""
          ? ClassStrandsObject.StandardPerformanceFilter.TestGrade
              .selectedTestgrade.grade
          : "";

      let SelectedStudents = Context_Header.Roster_Tab.StudentIds;
      let currentTermId = this.props.currentTermID;
      
      const { UniversalSelecter,Context_DateTab } = this.props;
      let classId = Context_Header.Roster_Tab.SelectedClass.id;
      let startDate = Context_Header.Date_Tab.Report_termStartDate;
      let endDate = Context_Header.Date_Tab.Report_termEndDate;
      let districtId = Context_Header.DistrictId;
      let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
  
      if (classId == undefined) {
        classId = UniversalSelecter.Roster_Data.SelectedClass.id;
      }
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(Context_DateTab);
      }
      if (districtId == undefined) {
        districtId = Context_Header.Default_districtID;
      }
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }

      const GradeValues = ClassStrandsObject.StandardPerformanceFilter.TestGrade;
      if ((Grade == undefined || Grade == "") && GradeValues && GradeValues.TestGradeList && GradeValues.TestGradeList[0]) {
        Grade = GradeValues.TestGradeList[0].grade;
      }


      let ReqPayload = {
        classId: classId,
        classIds: Context_Header.Roster_Tab.ClassIds,
        schoolId: schoolId,
        districtId: districtId,
        grade: Grade, // remove later or
        standardIds: strandardsarray,
        startDate: startDate,
        endDate: endDate,
        componentCodeList: SelectedTestList,
        studentIds: SelectedStudents,
        studentId: SelectedStudents[0],
        isClass: true,
        isDistrict: true,
        isSchool: true,
        assessedQuestionsNo: selectedTestAssessment,
        compareStudentIds: Compare_Std_Ids,
        rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
      };

      if (Nav.class) {
        const AllClassesList_ = AllClassesList(
          Context_Header.Roster_Tab.ClassList
        );
        ReqPayload.classIds = AllClassesList_;
        delete ReqPayload.studentId;
      }

      let Enableloading = true;
      let UpdatedselectedStandard = null;
      if (selectedStandard === null || selectedStandard === undefined) {
      } else {
        let standardDetails = getexact_standard_avg_on_class_student_persist(
          Strand_List,
          strandName,
          selectedStandard
        );
        strandName = standardDetails.strandOrStandardName;
        UpdatedselectedStandard = standardDetails.UpdatedselectedStandard;
        standardId =
          standardDetails.selectedStandardUpdated != undefined
            ? standardDetails.selectedStandardUpdated
            : standardId;
        strandAvg = standardDetails.strandAvg;
      }
      if (
        ReqPayload.grade !== "" &&
        ReqPayload.grade !== undefined &&
        Nav.class
      ) {
        if (!Reports_APICall.Get_OnlyGraphOnCompareInStrandsComp) {
          let selectedTaxonomy =
            this.props.StandardPerformance_Overview.StandardPerformanceFilter
              .Taxonomy.selectedTaxonomy;
          let Sel_Ass_Ques =
            this.props.StandardPerformance_Overview.StandardPerformanceFilter
              .TestAssessment.selectedTestAssessment;

          this.props.GetStudentsListOfstandardOrStrandId(
            AccessToken,
            ReqPayload,
            standardId,
            strandAvg,
            strandName,
            UpdatedselectedStandard,
            Enableloading,
            UpdatedselectedStandard,
            selectedTaxonomy,
            Sel_Ass_Ques
          );
        }
        // let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));
        this.props.GetLineChartDetailsofSelected_Standards(
          AccessToken,
          ReqPayload,
          standardId,
          strandAvg,
          strandName,
          UpdatedselectedStandard,
          Enableloading
        );
      }
    }

    /**
     * get linechart of a strands in student context.
     */
    let studentsStrandsObject = this.props.S_StandardPerformance_Overview;
    let Strand_List =
      studentsStrandsObject.ActualList.strands == undefined
        ? []
        : studentsStrandsObject.ActualList.strands;
        let universalApis = (getStudentData_cls || loadingFor == "studentData")
    if (
      !universalApis &&
      this.props.S_ApiCalls.getLineChartOfStrands &&
      !this.props.S_ApiCalls.Get_Student_Strands &&
      this.props.NavigationByHeaderSelection.student &&
      Strand_List.length > 0
    ) {
      let StrandsList = [];
      let strandardsarray = [];
      let strandAvg = "";
      let strandName = "";
      let isStandard = false;
      let selectedStandard = null;
      let standardId = "";
      /**
       * if selected strand and standard is null or empty it means previous and present class is not same. in that case will get linechart details of first strand in the strands List list
       */
      let StrandSelectionIsExist =
        (studentsStrandsObject.selectedStandardId === "" ||
          studentsStrandsObject.selectedStandardId === null) &&
        (studentsStrandsObject.StrandNameOfSelectedStandard == "" ||
          studentsStrandsObject.StrandNameOfSelectedStandard == null);
      if (
        this.props.S_ApiCalls
          .getLineChart_OfStrands_on_StudentSelectionFromClass ||
        !StrandSelectionIsExist
      ) {
        if (
          studentsStrandsObject.selectedStandardId === "" ||
          studentsStrandsObject.selectedStandardId === null
        ) {
          // let SelectedStrand = [];
          for (var i = 0; i < Strand_List.length; i++) {
            if (
              Strand_List[i].strandName ==
              studentsStrandsObject.StrandNameOfSelectedStandard
            ) {
              StrandsList = Strand_List[i];
              break;
            }
          }
          StrandsList =
            StrandsList.length == 0
              ? studentsStrandsObject.ActualList.strands[0]
              : StrandsList;
          strandAvg = StrandsList.strandAvg;
          strandName = StrandsList.strandName;
          strandardsarray = GetIds_of_Each_Object_In_The_Array(
            StrandsList.standards,
            strandName,
            "forapicall"
          );
        } else if (
          studentsStrandsObject.selectedStandardId !== "" &&
          studentsStrandsObject.selectedStandardId !== null
        ) {
          // strandAvg = studentsStrandsObject.selectedstandardObject.standardAvg;
          standardId = studentsStrandsObject.selectedStandardId;
          strandName = studentsStrandsObject.StrandNameOfSelectedStandard;
          isStandard = true;
          strandardsarray =
            studentsStrandsObject.selectedstandardObject.nationalStdIds;
          selectedStandard = studentsStrandsObject.selectedstandardObject;
        }
      } else {
        StrandsList = studentsStrandsObject.ActualList.strands[0];
        strandAvg = StrandsList.strandAvg;
        strandName = StrandsList.strandName;
        strandardsarray = GetIds_of_Each_Object_In_The_Array(
          StrandsList.standards,
          strandName,
          "forapicall"
        );
      }

      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTestList = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );
      let StandardPerformanceFilter =
        this.props.S_StandardPerformance_Overview.StandardPerformanceFilter;
      let selectedTestAssessment =
        StandardPerformanceFilter.TestAssessment.selectedTestAssessment;
      selectedTestAssessment =
        selectedTestAssessment == "" ? 1 : selectedTestAssessment;
      let Grade =
        studentsStrandsObject.StandardPerformanceFilter.TestGrade
          .selectedTestgrade !== ""
          ? studentsStrandsObject.StandardPerformanceFilter.TestGrade
              .selectedTestgrade.grade
          : "";

      let Context_Roster = this.props.ContextHeader.Roster_Tab;
      const AllStudentList = AllClassesList(
        Context_Header.Roster_Tab.StudentsList
      );

      /**
       * Start Of Getting All Students Of The School for school report,
       * for Teachers, All students of the teacher.
       */
      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;

      let Compare_Std_Ids =
        SchoolStds == undefined
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));
      if (Compare_Std_Ids.length == 0) {
        let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }

      /**
       * ENd of getting students.
       */

      let clsids =
        Context_Roster.StudentData_cls_ids.length ==
        Context_Roster.StudentData_cls.length
          ? []
          : Context_Roster.StudentData_cls_ids;
      // clsids = clsids.length == 0 ? Context_Roster.ClassIds : clsids;
      let currentTermId = this.props.currentTermID;

      const { UniversalSelecter,Context_DateTab } = this.props;
      const { SelectedDistrictTerm } = Context_DateTab;
      let classId = Context_Roster.SelectedClass.id;
      let startDate = Context_Header.Date_Tab.Report_termStartDate;
      let endDate = Context_Header.Date_Tab.Report_termEndDate;
      let districtId = Context_Header.DistrictId;
      let schoolId = Context_Roster.SelectedSchool.id;
      let studentId = Context_Roster.SelectedStudent.id;
  
      if (classId == undefined) {
        classId = UniversalSelecter.Roster_Data.SelectedClass.id;
      }
      if (startDate == undefined || startDate == "") {
        startDate = SelectedDistrictTerm.termStartDate;
      }
      if (endDate == undefined || endDate == "") {
        endDate = SelectedDistrictTerm.termEndDate;
      }
      if (districtId == undefined) {
        districtId = Context_Header.Default_districtID;
      }
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      if (studentId == undefined) {
        studentId = UniversalSelecter.Roster_Data.SelectedStudent.id;
      }
      const GradeValues = studentsStrandsObject.StandardPerformanceFilter.TestGrade;
      if ((Grade == undefined || Grade == "" ) && GradeValues && GradeValues.TestGradeList && GradeValues.TestGradeList[0]) {
        Grade = GradeValues.TestGradeList[0].grade;
      }

      let ReqPayload = {
        studentId: studentId,
        studentIds: AllStudentList,
        classId: classId,
        classIds: clsids,
        schoolId: schoolId,
        districtId: Context_Header.DistrictId,
        standardIds: strandardsarray,
        grade: Grade, //remove or modify later
        rosterGrade: Context_Roster.selectedRosterGrade,
        startDate: startDate,
        endDate: endDate,
        componentCodeList: SelectedTestList,
        isClass: true,
        isDistrict: true,
        isSchool: true,
        assessedQuestionsNo: selectedTestAssessment,
        compareStudentIds: Compare_Std_Ids,
        isPastDistrictTerm:
          this.props.ContextHeader.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
      };
      let Enableloading = true;
      let UpdatedselectedStandard = null;

      if (selectedStandard === undefined || selectedStandard === null) {
      } else {
        let standardDetails = getexact_standard_avg_on_class_student_persist(
          studentsStrandsObject.ActualList.strands,
          strandName,
          selectedStandard
        );
        UpdatedselectedStandard = standardDetails.UpdatedselectedStandard;
        strandAvg = standardDetails.strandAvg;
      }

      let Sel_Taxonomy =
        studentsStrandsObject.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;
      let Sel_Ques =
        studentsStrandsObject.StandardPerformanceFilter.TestAssessment
          .selectedTestAssessment;

      const { stdDataSelectedClassIds, stdDataSelectedSchoolIds } =
        getClassAndSchoolListOfStudentData(Context_Roster);
      ReqPayload.stdDataSelectedClassIds = stdDataSelectedClassIds;
      ReqPayload.stdDataSelectedSchoolIds = stdDataSelectedSchoolIds;

      this.props.GetLineChartDetailsof_Student_Standards(
        AccessToken,
        ReqPayload,
        "",
        standardId,
        strandAvg,
        strandName,
        UpdatedselectedStandard,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
    }

    this.GetSchool_Selected_Info(false);
    /**
     * end getting school data
     */
  }

  GetSchool_Selected_Info(call, selectedschool) {
    if (this.props.ApiCalls.Get_Selected_School_Info || call) {
      let Nav= this.props.NavigationByHeaderSelection;
      let OnTestStatusCLick =
      Nav.test_status &&
        this.props.UniversalFilter !== "roster";

        let Roster_Tab = Nav.Summary_Reports? this.props.ContextHeader.Summary_Roster_Data : 
        this.props.ContextHeader.Roster_Tab

      if (selectedschool == undefined) {
        school = Roster_Tab.SelectedSchool;
        school = schoolObjCondition(Roster_Tab.SelectedSchool);
        school.districtId =
        Roster_Tab.SelectedDistrict.id;
        school.districtName =
        Roster_Tab.SelectedDistrict.name;
      }
      // let Sc_List= this.props.UniversalSelecter
      let school = call ? selectedschool : school;
      let index = 0; // no use with this
      let check = true;
      let AccessToken = this.props.LoginDetails.JWTToken;
      let Dateterm = OnTestStatusCLick
        ? this.props.DateTabComponents.SelectedDistrictTerm
        : this.props.ContextHeader.Date_Tab.selectedterm_Obj;

      let fromDist_Reports = true;
      let Current_Selected_Sc_List =
        this.props.UniversalSelecter.Roster_Data.SchoolIds;
      let SchoolAdmin = this.props.ContextHeader.User_Role == "SCHOOL_ADMIN";
      this.props.SaveSelectedSchool(
        school,
        index,
        check,
        AccessToken,
        Dateterm,
        fromDist_Reports,
        Current_Selected_Sc_List,
        SchoolAdmin
      );
    }
  }

  clickOnNavigation(
    clickOn,
    SlectedStudent,
    SelectedClass,
    SelectedSchool,
    selectedGradeSt
  ) {
    let Nav = this.props.NavigationByHeaderSelection;

    if (
      Nav.usageReport &&
      process.env.BUUR_REMOVE_UNIVERSAL_SELECTOR === "true"
    ) {
      return;
    }
    if (Nav.usageReport) {
      this.props.SetUsageReportsNavigationLevel(clickOn);
      return;
    }

    if (Nav.district) {
      const { School } = this.PickSChoolOnSchoolNavClick(Nav);
      SelectedSchool = School;
    }

    let ActiveGrade = null;
    ActiveGrade =
      ActiveGrade == null || ActiveGrade == undefined || ActiveGrade == ""
        ? ""
        : ActiveGrade.grade;

    if (Nav.st_analysis) {
      const { selectedGradeSt } = this.PickSChoolOnSchoolNavClick(Nav);

      let SelectedSc_Id =
        clickOn == "student"
          ? SlectedStudent.schoolId
          : clickOn == "class"
          ? SelectedClass.schoolId
          : undefined;

      if (SelectedSc_Id !== undefined) {
        SelectedSchool = this.props.ContextHeader.Roster_Tab.schoolsList.filter(
          (item) => item.id == SelectedSc_Id
        )[0];
      }

      ActiveGrade = selectedGradeSt;
    }

    let Student = {};
    let Class = this.props.ContextHeader.Class;

    /**
     * null params are related to grouping tab action.
     */

    if (
      ActiveGrade == undefined ||
      ActiveGrade == "" ||
      ActiveGrade == null
      //  && Nav.test_status && Nav.district
    ) {
      ActiveGrade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade;
    }
    this.props.SaveContextSelection(
      clickOn,
      null,
      null,
      Student,
      Class,
      SlectedStudent,
      SelectedClass,
      SelectedSchool,
      ActiveGrade
    );

    if (
      Nav.Assessement &&
      !Nav.st_analysis &&
      !Nav.summary &&
      !Nav.comparison
    ) {
      if (
        this.props.studentComparison.Std_Comparison.PopupFilter
          .Strands_And_Standards.Original_List.length == 0 ||
        this.props.classComparison.Std_Comparison.PopupFilter
          .Strands_And_Standards.Original_List.length == 0 ||
        clickOn == "school"
      ) {
        this.props.SaveContextSelection("Overview");
      }
    }
  }
  GetSingleTestContextInfo(Nav) {
    let selectedData;
    let singleTestContextInfo;
    let selectedGrade;

    if (
      this.props.ContextHeader.PickDataFromSingleTestAnalysis != null &&
      (this.props.ContextHeader.Roster_Tab.SelectedSchool.id != undefined
        ? this.props.ContextHeader.PickDataFromSingleTestAnalysis.schoolId ==
          this.props.ContextHeader.Roster_Tab.SelectedSchool.id
        : true)
    ) {
      selectedData = this.props.ContextHeader.PickDataFromSingleTestAnalysis;
    } else if (
      Nav.district &&
      this.props.district_TestAnalysis.AnalysisData.Operational_Data.length !==
        0
    ) {
      selectedData =
        this.props.district_TestAnalysis.AnalysisData.Operational_Data
          .concernedData;
    } else if (
      Nav.school &&
      this.props.school_TestAnalysis.AnalysisData.Operational_Data.length !== 0
    ) {
      selectedData =
        this.props.school_TestAnalysis.AnalysisData.Operational_Data
          .concernedData;
      selectedGrade = getGradeOfClassFromRoaster(
        this.props.ContextHeader.Roster_Tab.GradesList,
        selectedData.studentId
      );
      if (selectedGrade != null) {
        selectedData.grade = selectedGrade;
      }
    } else if (
      Nav.class &&
      this.props.class_TestAnalysis.AnalysisData.Operational_Data.length !== 0
    ) {
      selectedData =
        this.props.class_TestAnalysis.AnalysisData.Operational_Data
          .concernedData;
      selectedGrade = getGradeOfClassFromRoaster(
        this.props.ContextHeader.Roster_Tab.GradesList,
        selectedData.studentId
      );
      if (selectedGrade != null) {
        selectedData.grade = selectedGrade;
      }
    } else if (
      Nav.student &&
      this.props.student_TestAnalysis.AnalysisData.Operational_Data.length !== 0
    ) {
      selectedData =
        this.props.student_TestAnalysis.AnalysisData.Operational_Data
          .concernedData;
      selectedGrade = getGradeOfClassFromRoaster(
        this.props.ContextHeader.Roster_Tab.GradesList,
        selectedData.studentId
      );
      if (selectedGrade != null) {
        selectedData.grade = selectedGrade;
      }
    }

    if (selectedData.length !== 0) {
      singleTestContextInfo = selectedData;
    } else {
      singleTestContextInfo = null;
    }
    return singleTestContextInfo;
  }

  PickStudentOnStudentNavClick(Nav) {
    if (Nav.usageReport) {
      return {};
    }
    let student = {};
    let List;
    if (Nav.class) {
      let { StrandNameOfSelectedStandard } =
        this.props.StandardPerformance_Overview;
      let { SelectedTestData } = this.props.Test_Scores_OverTime;
      let { selectedTest } = this.props.TestStatusReducer.Class.StatusDetail;
      if (
        Nav.S_performance &&
        Nav.Overview &&
        (StrandNameOfSelectedStandard == "" ||
          StrandNameOfSelectedStandard == undefined ||
          StrandNameOfSelectedStandard == null)
      ) {
        return student;
      } else if (
        Nav.T_scores &&
        Nav.Overview &&
        (SelectedTestData.componentCode == undefined ||
          SelectedTestData.componentCode == null)
      ) {
        return student;
      } else if (
        Nav.test_status &&
        (selectedTest.componentCode == undefined ||
          selectedTest.componentCode == null)
      ) {
        return student;
      }

      let PreviousStdData = this.props.LastActiveUniversalProps.Student_Report;
      let CurrentClass = this.props.ContextHeader.Roster_Tab.SelectedClass;

      let Last_Stds = JSON.parse(JSON.stringify(PreviousStdData.StudentList));
      let CurrentStds = JSON.parse(
        JSON.stringify(this.props.ContextHeader.Roster_Tab.StudentsList)
      );

      let Student_Selection_Modified =
        Check_Previous_Report_List_Modified_Or_Not(Last_Stds, CurrentStds);
      if (
        CurrentClass.id === PreviousStdData.selectedClass.id &&
        PreviousStdData.selectedClass.id !== undefined &&
        PreviousStdData.selectedClass.id !== null &&
        !Student_Selection_Modified.Modified
      ) {
        student = PreviousStdData.selectedStudent;
      } else {
        if (Nav.test_status) {
          // List = ;

          let listdata = getGroupingStudentList_Ts_SummaryDetails(
            this.props.TestStatusReducer.Class.StatusDetail.List
          );

          List = listdata[0] ? listdata[0].data : null;
        } else {
          List = Nav.comparison
            ? null
            : Nav.S_performance
            ? this.props.StandardPerformance_Overview.SP_ActualStudentsList
            : Nav.T_scores
            ? this.props.StudentsListTable.ActualList.testScoreList
            : null;
          if (List == undefined || List == null) {
            if (Nav.st_analysis) {
              let ObjectRe = this.GetSingleTestContextInfo(Nav);
              List = [];
              if (ObjectRe !== null) {
                List.push(ObjectRe);
              }
            } else if (Nav.comparison) {
              List = Nav.S_performance
                ? Sort_ApiResponse_Payload_Array(
                    this.props.classComparison.Std_Comparison.ComparisonData
                      .Operational_Data,
                    "studentslist"
                  )
                : Sort_ApiResponse_Payload_Array(
                    this.props.classComparison.Ts_Comparison.ComparisonData
                      .Operational_Data.students,
                    "studentslist"
                  );
            } else {
              List = Sort_ApiResponse_Payload_Array(
                this.props.ContextHeader.Roster_Tab.StudentsList,
                "studentslist"
              );
            }
          }
          // KV - Hack put in to get a list of students for ORR Reporting
          if (Nav.ORR) {
            List = this.props.ContextHeader.Roster_Tab.StudentsList;
          }
          if (Nav.Summary_Tab) {
            List = this.props.ContextHeader.Roster_Tab.StudentsList;
          }
          if (Nav.summary && Nav.S_performance) {
            List = this.props.Summary.Class.List.summaryList;
          }
          if (!Nav.st_analysis) {
            List = Sort_ApiResponse_Payload_Array(List, "studentslist");
          }
        }
        student = List[0];
      }
    }

    if (Nav.school || student == undefined) {
      List = Sort_ApiResponse_Payload_Array(
        this.props.ContextHeader.Roster_Tab.StudentsList,
        "studentslist"
      );
      student = List[0];
    }

    if (Nav.st_analysis) {
      let ObjectRe = this.GetSingleTestContextInfo(Nav);
      ObjectRe.id = ObjectRe.studentId;
      List = [];
      if (ObjectRe !== null) {
        List.push(ObjectRe);
      }
      student = List[0];
    }

    return student;
  }

  checkForClssSelection_SummaryReports(){
    const {SummaryReports_Class} = this.props.LastActiveUniversalProps;
    const {Summary_Roster_Data}= this.props.ContextHeader;
    let Class ;
    if(Summary_Roster_Data.selectedRosterGrade == SummaryReports_Class.selectedRosterGrade && SummaryReports_Class.selectedClass && SummaryReports_Class.selectedClass.id){
      Class = SummaryReports_Class.selectedClass;
    }
    return Class;
    }

  PickClassOnClassNavClick(Nav) {
    if (Nav.usageReport) {
      return {};
    }
    const {Summary_Reports}= Nav;
    if(Summary_Reports){
      const res= this.checkForClssSelection_SummaryReports();
      if(res){
        return res;
      }
    }
    let Class = {};
    let List;
    let ActiveGrade;
    if (Nav.student) {
      Class = this.props.ContextHeader.Roster_Tab.SelectedClass;
    } else if (Nav.school) {
      if (Nav.Overview) {
        let LeftViewNotSelected;
        if (Nav.S_performance) {
          let { StrandNameOfSelectedStandard, selectedStandardId } =
            this.props.Sc_StandardPerformance_Overview;
          LeftViewNotSelected =
            StrandNameOfSelectedStandard == "" && selectedStandardId == "";
        } else if (Nav.T_scores) {
          let { SelectedTestData } = this.props.Sc_Test_Scores_OverTime;
          LeftViewNotSelected =
            SelectedTestData.componentCode == "" ||
            SelectedTestData.componentCode == undefined;
        } else if (Nav.test_status) {
          let { selectedTest } =
            this.props.TestStatusReducer.School.StatusDetail;
          LeftViewNotSelected =
            selectedTest.componentCode == "" ||
            selectedTest.componentCode == undefined;
        }

        if (LeftViewNotSelected) {
          return Class;
        }
      }

      if (Nav.comparison && !Nav.test_status) {
        if (Nav.S_performance) {
          // pick Class From Data already loaded
          Class =
            this.props.schoolComparison.Std_Comparison.ComparisonData
              .Operational_Data[0];
        } else {
          Class =
            this.props.schoolComparison.Ts_Comparison.ComparisonData
              .Operational_Data.classes[0];
        }
      } else if (Nav.summary && !Nav.st_analysis) {
        Class = this.props.Summary.School.List.summaryList[0];
      } else {
        if (!Nav.ORR) {
          List = Nav.test_status
            ? this.props.TestStatusReducer.School.StatusDetail.List
            : Nav.S_performance
            ? this.props.Sc_StandardPerformance_Overview.SP_ActualStudentsList
            : this.props.Sc_TS_Class_ListTable.ActualList.testScoreList;
        }

        if (List == null || List == undefined) {
          if (Nav.st_analysis) {
            let ObjectRe = this.GetSingleTestContextInfo(Nav);
            List = [];
            if (ObjectRe !== null) {
              List.push(ObjectRe);
              ActiveGrade = ObjectRe.grade;
            }
          } else {
            List = JSON.parse(
              JSON.stringify(this.props.ContextHeader.Roster_Tab.ClassList)
            );
            List = Sort_ApiResponse_Payload_Array(List, "classlist");
          }
        } else {
          List = Nav.test_status
            ? List
            : Sort_ApiResponse_Payload_Array(List, "classlist_for_Nav");
        }
        Class = List[0];
      }
    } else {
      Class =
        Nav.test_status &&
        this.props.LastActiveUniversalProps.Class_TestStaus.selectedClass.id !==
          undefined
          ? this.props.LastActiveUniversalProps.Class_TestStaus.selectedClass
          : Class;
    }

    // Class = Class == undefined || Class == null ? {} : Class;
    // let StrandIsNotSelected =
    if (
      Class !== undefined &&
      Class.id == undefined &&
      Class.classId == undefined
    ) {
      List = JSON.parse(
        JSON.stringify(this.props.ContextHeader.Roster_Tab.ClassList)
      );
      List = Sort_ApiResponse_Payload_Array(List, "classlist");
      Class = List[0];
    }

    if (Nav.st_analysis && !Nav.student) {
      let ObjectRe = this.GetSingleTestContextInfo(Nav);
      // ObjectRe.id = ObjectRe.classId
      List = [];
      if (ObjectRe !== null) {
        List.push(ObjectRe);
        ActiveGrade = ObjectRe.grade;
      }
      Class = List[0];
    }

    return Class;
  }
  checkForSchoolSelection_SummaryReports(){
    const {SummaryReports_School} = this.props.LastActiveUniversalProps;
    const {Summary_Roster_Data}= this.props.ContextHeader;
    let School, selectedGradeSt ;
    if(Summary_Roster_Data.selectedRosterGrade == SummaryReports_School.selectedRosterGrade && SummaryReports_School.selectedSchool && SummaryReports_School.selectedSchool.id){
      School = SummaryReports_School.selectedSchool;
      selectedGradeSt= Summary_Roster_Data.selectedRosterGrade;
    }
    return {School,selectedGradeSt};
    }
  PickSChoolOnSchoolNavClick(Nav) {
    if (Nav.usageReport) {
      return {};
    }
    let School = {};
    let selectedGradeSt;

    if (Nav.student || Nav.class) {
      let { SelectedSchool } = Nav.Summary_Reports
        ? this.props.ContextHeader.Summary_Roster_Data
        : this.props.ContextHeader.Roster_Tab;
      School = SelectedSchool;
    } else if (Nav.district) {

    const {Summary_Reports}= Nav;
    if(Summary_Reports){
      const res= this.checkForSchoolSelection_SummaryReports();
      if(res.School && res.selectedGradeSt){
        return res;
      }
    }

      if (Nav.Overview) {
        let LeftViewNotSelected = false;
        if (Nav.S_performance) {
          let { StrandNameOfSelectedStandard, selectedStandardId } =
            this.props.D_StandardPerformance_Overview;
          LeftViewNotSelected =
            StrandNameOfSelectedStandard == "" && selectedStandardId == "";
        } else if (Nav.T_scores) {
          let { SelectedTestData } = this.props.D_Test_Scores_OverTime;
          LeftViewNotSelected =
            SelectedTestData.componentCode == "" ||
            SelectedTestData.componentCode == undefined;
        } else if (Nav.test_status) {
          let { selectedTest } =
            this.props.TestStatusReducer.District.StatusDetail;
          LeftViewNotSelected =
            selectedTest.componentCode == "" ||
            selectedTest.componentCode == undefined;
        }

        if (LeftViewNotSelected) {
          selectedGradeSt =
            this.props.ContextHeader.Roster_Tab.selectedRosterGrade;
          return { School, selectedGradeSt };
        }
      }

      let List = Nav.test_status
        ? this.props.TestStatusReducer.District.StatusDetail.List
        : Nav.comparison
        ? null
        : Nav.S_performance && Nav.summary
        ? this.props.Summary.District.List &&
          this.props.Summary.District.List.summaryList &&
          this.props.Summary.District.List.summaryList
        : Nav.S_performance
        ? this.props.D_StandardPerformance_Overview.SP_ActualStudentsList
        : this.props.D_TS_School_ListTable.ActualList.testScoreList;
      if (List == null || List == undefined) {
        if (Nav.st_analysis) {
          let ObjectRe = this.GetSingleTestContextInfo(Nav);
          List = [];
          if (ObjectRe !== null) {
            List.push(ObjectRe);
            selectedGradeSt = ObjectRe.grade;
          }
        } else if (Nav.comparison) {
          List = Nav.S_performance
            ? JSON.parse(
                JSON.stringify(
                  this.props.districtComparison.Std_Comparison.ComparisonData
                    .Operational_Data
                )
              )
            : JSON.parse(
                JSON.stringify(
                  this.props.districtComparison.Ts_Comparison.ComparisonData
                    .Operational_Data.schools
                )
              );

          List = Sort_ApiResponse_Payload_Array(List, "school_listOnStrands");
        } else {
          List = JSON.parse(
            JSON.stringify(this.props.ContextHeader.Roster_Tab.schoolsList)
          );
          List = Sort_ApiResponse_Payload_Array(List, "schoolslist");
        }
      } else if (List.length === 0) {
        List = JSON.parse(
          JSON.stringify(this.props.ContextHeader.Roster_Tab.schoolsList)
        );
        List = Sort_ApiResponse_Payload_Array(List, "schoolslist");
      } else {
        List = Nav.test_status
          ? List
          : Sort_ApiResponse_Payload_Array(List, "school_listOnStrands");
      }
      School = List[0];

      if (School.schoolId !== undefined) {
        School = this.props.UniversalSelecter.Roster_Data.schoolsList.find(
          (item) => item.id == School.schoolId
        );
      }

      if (Nav.S_performance && Nav.summary) {
      }
    }

    if (Nav.test_status && selectedGradeSt == undefined) {
      selectedGradeSt = this.props.ContextHeader.Roster_Tab.selectedRosterGrade;
    }
    return { School, selectedGradeSt };
  }

  render() {
    let Nav = this.props.NavigationByHeaderSelection;
    let User_Role = this.props.LoginDetails.UserRole;
    const usageBlocksUniversalSelector =
      Nav.usageReport && process.env.BUUR_REMOVE_UNIVERSAL_SELECTOR === "true";
    let Selected_class_TS_tooltipdata = this.props.ToolTipData.tooltipData;
    const cursorType = usageBlocksUniversalSelector ? "default" : "pointer";
    if (Nav.usageReport) {
      Nav = {
        usageReport: true,
        Summary_Reports: false,
        student: this.props.usageReports.navigationLevel === "student",
        class: this.props.usageReports.navigationLevel === "class",
        school: this.props.usageReports.navigationLevel === "school",
        district: this.props.usageReports.navigationLevel === "district",
      };
    }
    return (
      <div className="bec-header">
        {/* Student/Class Filter start */}
        <div className="container-fluid p-0 main-filter">
          <div className="row m-0 p-0">
            <div className="col-sm-12 m-0 p-0 float-left retangular-strip"></div>
            <div className="col-sm-12 px-0 py-2 bec-header_fixed_width">
              <div className="subway_navigation_filter_main mx-auto text-center">
                <div className="col-sm-3 px-0 subway_nav_tooltip">
                  {(!usageBlocksUniversalSelector &&
                    Nav.district &&
                    User_Role == "DISTRICT_ADMIN") ||
                  Nav.Summary_Reports ? (
                    <div>
                      <div class="subway_nav_tooltip_arrow ar_summary_stdOverview-subway_nav_tooltip_arrow"></div>
                      <div
                        className={
                          Nav.Summary_Reports
                            ? "ar_summary_stdOverview-subway_nav_tooltiptext subway_nav_tooltiptext"
                            : "subway_nav_tooltiptext"
                        }
                      >
                        {Nav.Summary_Reports
                          ? "Summary reports are not available at student level."
                          : "School level must be selected."}
                      </div>
                    </div>
                  ) : (Nav.school && User_Role == "DISTRICT_ADMIN") ||
                    (Nav.school && User_Role == "SCHOOL_ADMIN") ? (
                    <div>
                      <div class="subway_nav_tooltip_arrow"></div>
                      <div class="subway_nav_tooltiptext">
                        Class level must be selected.
                      </div>
                    </div>
                  ) : null}
                  {/* {(Nav.school && User_Role == "SCHOOL_ADMIN") ?<span class="subway_nav_tooltiptext">Class level must be selected.</span>:null} */}

                  <div
                    onClick={
                      () => {
                        if (
                          !Nav.Summary_Reports &&
                          !Nav.student &&
                          !Nav.usageReport
                        ) {
                          let student = this.PickStudentOnStudentNavClick(Nav);
                          (Nav.class && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.class && User_Role == "SCHOOL_ADMIN") ||
                          (Nav.class && User_Role == "TEACHER")
                            ? this.clickOnNavigation("student", student)
                            : null;
                        }
                      }
                      // this.props.FilterMainModule('Student')
                      // this.props.handler('Student')
                    }
                    // style={{ cursor: 'pointer' }}
                    className={
                      Nav.student
                        ? "single-filter text-center active-filter"
                        : (Nav.district && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "SCHOOL_ADMIN") ||
                          Nav.Summary_Reports ||
                          Nav.usageReport
                        ? "single-filter text-center subway_nav_add_opacity"
                        : "single-filter text-center"
                    }
                  >
                    <div
                      style={
                        Nav.Summary_Reports || Nav.usageReport
                          ? {}
                          : { cursor: cursorType }
                      }
                      className="single-filter-icon"
                    >
                      {/* <i className="material-icons">
                                                person
                                        </i> */}

                      <img src={StudentIcon} width="24" height="24" />
                    </div>
                    <div
                      className="single-filter-text"
                      //  onClick={() => {
                      //   if (!(Nav.student)) {
                      //     let student = this.PickStudentOnStudentNavClick(Nav);
                      //     ((Nav.class && User_Role == "DISTRICT_ADMIN") || (Nav.class && User_Role == "SCHOOL_ADMIN") || (Nav.class && User_Role == "TEACHER")) ? this.clickOnNavigation('student', student) : null
                      //   }
                      // }
                      //   // Nav.student ? null : this.clickOnNavigation('student')
                      //   // this.props.FilterMainModule('Student')
                      //   // this.props.handler('Student')
                      // }
                    >
                      {" "}
                      <span
                        style={{ cursor: cursorType }}
                        className={
                          (Nav.district && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "SCHOOL_ADMIN")
                            ? "subway_nav_add_opacity"
                            : ""
                        }
                      >
                        {" "}
                        Student
                      </span>
                    </div>
                  </div>
                </div>
                <div className="col-sm-3 px-0 subway_nav_tooltip">
                  {!usageBlocksUniversalSelector &&
                  Nav.district &&
                  User_Role == "DISTRICT_ADMIN" ? (
                    <div>
                      <div class="subway_nav_tooltip_arrow"></div>
                      <div class="subway_nav_tooltiptext">
                        School level must be selected.{" "}
                      </div>
                    </div>
                  ) : null}
                  <div
                    className={
                      Nav.class ||
                      (!Nav.student &&
                        !Nav.class &&
                        !Nav.school &&
                        !Nav.district)
                        ? "single-filter text-center active-filter"
                        : Nav.district && User_Role == "DISTRICT_ADMIN"
                        ? "single-filter text-center subway_nav_add_opacity"
                        : "single-filter text-center"
                    }
                  >
                    <div
                      style={{ cursor: cursorType }}
                      onClick={() => {
                        if (!Nav.class) {
                          //  this.props.FilterMainModule('Class')
                          let Class = this.PickClassOnClassNavClick(Nav);
                          let student = {};
                          (Nav.student && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "SCHOOL_ADMIN") ||
                          (Nav.student && User_Role == "SCHOOL_ADMIN") ||
                          (Nav.student && User_Role == "TEACHER")
                            ? this.clickOnNavigation("class", student, Class)
                            : null;
                        }
                      }}
                      className="single-filter-icon"
                    >
                      <i
                        className="material-icons"
                        style={{ fontSize: "26px" }}
                      >
                        people
                      </i>
                    </div>
                    <div
                      className="single-filter-text"
                      onClick={() => {
                        if (!Nav.class) {
                          let Class = this.PickClassOnClassNavClick(Nav);
                          let student = {};
                          (Nav.student && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "DISTRICT_ADMIN") ||
                          (Nav.school && User_Role == "SCHOOL_ADMIN") ||
                          (Nav.student && User_Role == "SCHOOL_ADMIN") ||
                          (Nav.student && User_Role == "TEACHER")
                            ? this.clickOnNavigation("class", student, Class)
                            : null;
                        }
                      }}
                    >
                      <span
                        style={{ cursor: cursorType }}
                        className={
                          Nav.district && User_Role == "DISTRICT_ADMIN"
                            ? "subway_nav_add_opacity"
                            : ""
                        }
                      >
                        Class
                      </span>
                    </div>
                  </div>
                </div>
                {User_Role == "SCHOOL_ADMIN" ||
                User_Role == "DISTRICT_ADMIN" ||
                User_Role == "SUPER_ADMIN" ? (
                  <div className="col-sm-3 px-0">
                    <div
                      onClick={() => {
                        if (!Nav.school) {
                          const { School, selectedGradeSt, ActiveGrade } =
                            this.PickSChoolOnSchoolNavClick(Nav);
                          let Student = {};
                          let Class = {};
                          this.clickOnNavigation(
                            "school",
                            Student,
                            Class,
                            School,
                            selectedGradeSt
                          );
                        }
                      }}
                      className={
                        Nav.school
                          ? "single-filter text-center active-filter"
                          : "single-filter text-center"
                      }
                    >
                      <div
                        style={{ cursor: cursorType }}
                        className="single-filter-icon"
                      >
                        <img src={SchoolIcon} width="20" height="20" />
                      </div>
                      <div
                        className="single-filter-text"
                        onClick={() => {
                          if (!Nav.school) {
                            const { School, ActiveGrade } =
                              this.PickSChoolOnSchoolNavClick(Nav);
                            let Student = {};
                            let Class = {};
                            this.clickOnNavigation(
                              "school",
                              Student,
                              Class,
                              School,
                              ActiveGrade
                            );
                          }
                        }}
                      >
                        {" "}
                        <span style={{ cursor: cursorType }}> School</span>
                      </div>
                    </div>
                  </div>
                ) : null}
                {User_Role == "DISTRICT_ADMIN" || User_Role == "SUPER_ADMIN" ? (
                  <div className="col-sm-3 px-0">
                    <div
                      onClick={() =>
                        Nav.district ? null : this.clickOnNavigation("district")
                      }
                      className={
                        Nav.district
                          ? "single-filter text-center active-filter"
                          : "single-filter text-center"
                      }
                    >
                      <div
                        style={{ cursor: cursorType }}
                        className="single-filter-icon"
                      >
                        <img src={DistrictIcon} width="20" height="20" />
                      </div>
                      <div
                        className="single-filter-text"
                        onClick={() =>
                          Nav.district
                            ? null
                            : this.clickOnNavigation("district")
                        }
                      >
                        {" "}
                        <span style={{ cursor: cursorType }}> District</span>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
        {/* Student/Class Filter ends  */}

        <ReportSelector />
        {/* // Context header start      active-context-header*/}

        {this.ContextHeader(this.props.NavigationByHeaderSelection)}

        {/*  */}
      </div>
    );
  }

  /**
   *
   * @param {Object} Nav
   *
   * if current selection is assessement Report than return context header view.
   */
  ContextHeader(Nav) {
    return (
      <div>
        <div ref="Sticky_context_header" className="context-header-main">
          <div
            className={
              this.props.StickyContextHeader
                ? "container-fluid m-0 p-0 float-left context-header active-context-header"
                : "container-fluid m-0 p-0 float-left context-header"
            }
          >
            <div
              className={
                Nav.Summary_Reports
                  ? "summary-context-header-row row m-0 p-0"
                  : "row m-0 p-0"
              }
            >
              <div
                className={
                  Nav.Summary_Reports
                    ? "summary-context-header-fixed-width"
                    : "context-header-fixed-width"
                }
              >
                {/*  Context Header Component  */}
                <ContextHeader />
              </div>
            </div>
          </div>
          {this.props.StickyContextHeader ? <BreadCrumbSelector /> : null}
        </div>

        {Nav.Assessement && <SelectionTabFilter />}
        {<Switching_Blocks_Filter />}
      </div>
    );
  }
}
const mapStateToProps = ({
  Authentication,
  Universal,
  DateTabReducer,
  Reports,
  StudentReports,
  schoolReducer,
  DistrictReducer,
  ComparisonReducer,
  SingleTestAnalysis,
  Summary,
  TestStatusReducer,
  LastActiveUniversalProps,
}) => {
  const { LoginDetails } = Authentication;
  const { DateTabComponents,Context_DateTab, Context_DateTab_TestStatus } = DateTabReducer;
  const {
    ContextHeader,
    ApiCalls,
    StickyUniversalSelector,
    usageReports,
    StickyContextHeader,
    UniversalSelecter,
    NavigationByHeaderSelection,
    StandardPerformanceFilter,
    UniversalFilter,
    currentTermID,
  } = Universal;
  const { S_ApiCalls, S_StandardPerformance_Overview } = StudentReports;
  const {
    ApiCalls_Reports,
    StandardPerformance_Overview,
    ToolTipData,
    StudentsListTable,
    Test_Scores_OverTime,
  } = Reports;

  const {
    Sc_StandardPerformance_Overview,
    Sc_TS_Class_ListTable,
    Sc_Test_Scores_OverTime,
  } = schoolReducer;
  const {
    D_StandardPerformance_Overview,
    D_TS_School_ListTable,
    D_Test_Scores_OverTime,
  } = DistrictReducer;

  const {
    studentComparison,
    classComparison,
    schoolComparison,
    districtComparison,
  } = ComparisonReducer;
  const {
    student_TestAnalysis,
    class_TestAnalysis,
    school_TestAnalysis,
    district_TestAnalysis,
  } = SingleTestAnalysis;

  return {
    ContextHeader,
    StickyContextHeader,
    ApiCalls_Reports,
    StickyUniversalSelector,
    UniversalSelecter,
    NavigationByHeaderSelection,
    ApiCalls,
    StandardPerformance_Overview,
    LoginDetails,
    S_ApiCalls,
    S_StandardPerformance_Overview,
    ToolTipData,
    Sc_StandardPerformance_Overview,
    Sc_TS_Class_ListTable,
    D_StandardPerformance_Overview,
    D_TS_School_ListTable,
    studentComparison,
    classComparison,
    StudentsListTable,
    schoolComparison,
    districtComparison,
    LastActiveUniversalProps,
    usageReports,
    student_TestAnalysis,
    class_TestAnalysis,
    school_TestAnalysis,
    district_TestAnalysis,
    Summary,
    DateTabComponents,
    UniversalFilter,
    TestStatusReducer,

    Test_Scores_OverTime,
    D_Test_Scores_OverTime,
    Sc_Test_Scores_OverTime,
    currentTermID,
    Context_DateTab,
    Context_DateTab_TestStatus
  };
};

export default connect(mapStateToProps, {
  // Add Action Here
  FilterMainModule,
  ChangeStickyContextHeader,
  ChangeStickyUniversalSelector,
  SaveContextSelection,
  GetStudentsListOfstandardOrStrandId,
  GetLineChartDetailsofSelected_Standards,
  Get_Student_TestScores_Details,
  Get_Student_StandardPerformance_Table,
  GetLineChartDetailsof_Student_Standards,
  getTestAssessmentMaxCountOfStudent,
  Get_Class_TestScores_Over_Time,
  SetUsageReportsNavigationLevel,
  SaveSelectedSchool,
  GetStudent_Data_Action,
  getInitialStudentObj,
})(MainFilter);

export function getexact_standard_avg_on_class_student_persist(
  Strand_List,
  strandName,
  selectedStandard
) {
  let strandAvg,
    UpdatedselectedStandard,
    strandOrStandardName,
    selectedStandardUpdated;

  for (var j = 0; j < Strand_List.length; j++) {
    let strand = Strand_List[j];

    if (strand.strandName == strandName) {
      strandOrStandardName = strand.strandName;

      for (var i = 0; i < strand.standards.length; i++) {
        let standard = strand.standards[i];

        let StandardId =
          selectedStandard == null || selectedStandard == undefined
            ? ""
            : selectedStandard.standardId;

        if (standard.standardId == StandardId) {
          UpdatedselectedStandard = standard;
          strandAvg = standard.standardAvg;
          break;
        }
      }
      break;
    }
  }
  if (UpdatedselectedStandard == undefined) {
    UpdatedselectedStandard = Strand_List[0];
    strandOrStandardName = Strand_List[0].strandName;
    strandAvg = Strand_List[0].strandAvg;
    selectedStandardUpdated = "";
  }
  return {
    strandAvg,
    UpdatedselectedStandard,
    strandOrStandardName,
    selectedStandardUpdated,
  };
}
