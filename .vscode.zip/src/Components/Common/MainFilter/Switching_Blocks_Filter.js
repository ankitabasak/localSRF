import React, { Component } from 'react';
// import '../../../../public/css/style.css';
import { connect } from "react-redux";
import { } from "../../../Redux_Actions/UniversalSelectorActions";
// import ContextHeader from './ContextHeader';
// import { classGroupingNew } from '../../../Redux_Actions/ClassGroupingAction';
import {
  SaveContextSelection,
  compareContextSelection
} from '../../../Redux_Actions/UniversalSelectorActions';
import { Get_Class_CSV_Details } from '../../../Redux_Actions/ReportsActions';
import {
  GetIds_of_Each_Object_In_The_Array,
  payloadParamsFor_Class_StdList_Graph_On_Strands
} from '../../ReusableComponents/AllReusableFunctions';
import { UniqueProducts } from '../UniversalFilter/Product';
import standardOverviewIcon from '../../../../public/images/ic_overview_ico.svg';
import comparisonIcon from '../../../../public/images/ic_comparison.svg';
import summaryIcon from '../../../../public/images/ic_summary.png';
import averageIcon from '../../../../public/images/ic_average.svg';
import GroupingIcon from '../../../../public/images/ic_overview_group.svg';
import ComparisonReducer from '../../../Redux_Reducers/ComparisonReducer';
import { STRANDS_SUMMARY_REPORTS } from "../../../Utils/globalVars";
import { SUMMARY_REPORTS_FLAG } from '../../../Utils/globalVars';
import { SummaryDistNavCondition } from '../../../Utils/reUsableSnipets';
class Switching_Blocks_Filter extends React.PureComponent {
  constructor(props) {
    super(props);
    this.GetCSVData = this.GetCSVData.bind(this);
    // this.GetCSVData = this.GetCSVData.bind(this);
    this.handleCompareClick = this.handleCompareClick.bind(this);
    this.ComparisonTabChecker = this.ComparisonTabChecker.bind(this);
  }
  /**
   * to download csv file data
   */
  GetCSVData() {
    let { strandardsarray } = payloadParamsFor_Class_StdList_Graph_On_Strands(
      this.props.StandardPerformance_Overview
    );
    let AccessToken = this.props.LoginDetails.JWTToken;
    let Display = this.props.ContextHeader;
    let U_Selector = this.props.UniversalSelecter.TestTab;
    let Nav = this.props.NavigationByHeaderSelection;
    let Selected_List = Display.Tests_of_PresentClass.filter(
      item => item.check
    );
    let SelectedTests = GetIds_of_Each_Object_In_The_Array(
      Selected_List,
      'component',
      'test_tab'
    );
    let Studentid = '';
    if (Display.Student != null || undefined) {
      Studentid = Display.Student.id;
    }

    let grade = Nav.class
      ? this.props.StandardPerformance_Overview.StandardPerformanceFilter
        .TestGrade.selectedTestgrade
      : this.props.S_StandardPerformance_Overview.StandardPerformanceFilter
        .TestGrade.selectedTestgrade;

    let ReqPayload = {
      districtId: Display.School.districtId,
      schoolId: Display.School.id,
      classId: Display.Class.id,
      studentId: Studentid,
      districtName: Display.School.districtName,
      teacherName: Display.Teacher.name,
      schoolName: Display.School.name,
      className: Display.Class.name,
      startDate: Display.Date_Tab.Report_termStartDate,
      endDate: Display.Date_Tab.Report_termEndDate,
      grade: grade != null ? grade.grade : null,
      standardIds: strandardsarray,
      componentCodeList: SelectedTests
    };
    let Enableload = true;

    this.props.Get_Class_CSV_Details(
      AccessToken,
      ReqPayload,
      Enableload,
      Nav.class
    );
  }

  handleCompareClick(Nav) {
    this.props.SaveContextSelection('comparison');
    // Here need to decide which params and context that need to pass
    let contextSelected = null;
    let contextTabSelected = null;
    let StandardPeformanceData = null;
    let TestScoreData = null;
    let dataExistInStd = false;

    if (Nav.Assessement) {
      if (Nav.district) {
        contextSelected = "district";
        if (Nav.S_performance) {
          contextTabSelected = "StandardPerformance";
          StandardPeformanceData = this.props.D_StandardPerformance_Overview;

          if (
            this.props.districtComparison.Std_Comparison.PopupFilter
              .Strands_And_Standards.Original_List.length !== 0
          ) {
            dataExistInStd = true;
          }
        } else if (Nav.T_scores) {
          contextTabSelected = "testScores";
          TestScoreData = this.props.D_Test_Scores_OverTime;
        } else {
        }
      }
      if (Nav.school) {
        contextSelected = 'school'
        if (Nav.S_performance) {
          contextTabSelected = "StandardPerformance";
          StandardPeformanceData = this.props.Sc_StandardPerformance_Overview;

          if (
            this.props.schoolComparison.Std_Comparison.PopupFilter
              .Strands_And_Standards.Original_List.length !== 0
          ) {
            dataExistInStd = true;
          }
        } else if (Nav.T_scores) {
          contextTabSelected = "testScores";
          TestScoreData = this.props.schoolComparison.Ts_Comparison
            .ComparisonData.Operational_Data;
          if (TestScoreData !== null) {
            dataExistInStd = true;
          }
        } else {
        }
      }
      if (Nav.class) {
        contextSelected = "class";
        if (Nav.S_performance) {
          contextTabSelected = "StandardPerformance";
          StandardPeformanceData = this.props.StandardPerformance_Overview;

          if (
            this.props.classComparison.Std_Comparison.PopupFilter
              .Strands_And_Standards.Original_List.length !== 0
          ) {
            dataExistInStd = true;
          }

        } else if (Nav.T_scores) {
          contextTabSelected = "testScores";
          TestScoreData = this.props.classComparison.Ts_Comparison
            .ComparisonData.Operational_Data;
          if (TestScoreData !== null) {
            dataExistInStd = true;
          }
        } else {
        }
      }
      if (Nav.student) {
        contextSelected = "student";
        if (Nav.S_performance) {
          contextTabSelected = "StandardPerformance";
          StandardPeformanceData = this.props.S_StandardPerformance_Overview;

          if (
            this.props.studentComparison.Std_Comparison.PopupFilter
              .Strands_And_Standards.Original_List.length !== 0
          ) {
            dataExistInStd = true;
          }
        } else if (Nav.T_scores) {
          contextTabSelected = "testScores";
          TestScoreData = this.props.studentComparison.Ts_Comparison
            .ComparisonData.Operational_Data;
          if (TestScoreData !== null) {
            dataExistInStd = true;
          }
        } else {
        }
      }
    }

    let From_DeepLinking = false

    dataExistInStd
      ? null
      : this.props.compareContextSelection(
        contextSelected,
        contextTabSelected,
        StandardPeformanceData,
        TestScoreData,
        From_DeepLinking
      );
  }

  ComparisonTabChecker(Nav) {
    let CompStatus = false;
    let district_std = this.props.D_StandardPerformance_Overview;
    let school_std = this.props.Sc_StandardPerformance_Overview;
    let student_std = this.props.S_StandardPerformance_Overview;
    let class_std = this.props.StandardPerformance_Overview;
    let D_ApiCalls = this.props.D_ApiCalls;
    let Sc_ApiCalls = this.props.Sc_ApiCalls;
    let ApiCalls_Reports = this.props.ApiCalls_Reports;
    let S_ApiCalls = this.props.S_ApiCalls;

    let testList =
      this.props.ContextHeader.TestTab.TestList != undefined
        ? this.props.ContextHeader.TestTab.TestList
        : [];
    testList.filter(test => test.check);

    if (
      Nav.Assessement &&
      Nav.student &&
      Nav.S_performance &&
      // student_std.originalList.length != 0 &&
      !S_ApiCalls.loading_on_strandsLC
    ) {
      CompStatus = true;
    }
    if (
      Nav.Assessement &&
      Nav.class &&
      Nav.S_performance &&
      // class_std.originalStrandsList.length != 0 &&
      !ApiCalls_Reports.loading_Strands_table
    ) {
      CompStatus = true;
    }

    if (
      Nav.Assessement &&
      Nav.school &&
      Nav.S_performance &&
      //school_std.originalList.length != 0 &&
      !Sc_ApiCalls.loading_Strands_table
    ) {
      CompStatus = true;
    }
    if (
      Nav.Assessement &&
      Nav.district &&
      Nav.S_performance &&
      // district_std.originalList.length != 0 &&
      !D_ApiCalls.loading_Strands_table
    ) {
      CompStatus = true;
    }

    // For Testscores

    if (
      Nav.Assessement &&
      Nav.student &&
      Nav.T_scores &&
      testList.length != 0 &&
      !S_ApiCalls.loading_on_student_TS
    ) {
      CompStatus = true;
    }
    if (
      Nav.Assessement &&
      Nav.class &&
      Nav.T_scores &&
      testList.length != 0 &&
      !(
        ApiCalls_Reports.loading_LC_students ||
        ApiCalls_Reports.loading_on_TS_LC
      )
    ) {
      CompStatus = true;
    }
    if (
      Nav.Assessement &&
      Nav.school &&
      Nav.T_scores &&
      testList.length != 0 &&
      !(Sc_ApiCalls.loading_LC_students || Sc_ApiCalls.loading_on_TS_LC)
    ) {
      CompStatus = true;
    }

    if (
      Nav.Assessement &&
      Nav.district &&
      Nav.T_scores &&
      testList.length != 0 &&
      !(D_ApiCalls.loading_LC_students || D_ApiCalls.loading_on_TS_LC)
    ) {
      CompStatus = true;
    }

    return CompStatus;
  }

  SummaryTabChecker(Nav, strands_summary_report_enable) {
    let summary_status = false
    let district_std = this.props.D_StandardPerformance_Overview
    let school_std = this.props.Sc_StandardPerformance_Overview
    let student_std = this.props.S_StandardPerformance_Overview
    let class_std = this.props.StandardPerformance_Overview
    let D_ApiCalls = this.props.D_ApiCalls
    let Sc_ApiCalls = this.props.Sc_ApiCalls
    let ApiCalls_Reports = this.props.ApiCalls_Reports
    let S_ApiCalls = this.props.S_ApiCalls

    if (
      Nav.Assessement &&
      Nav.student &&
      Nav.S_performance
      // && student_std.originalList.length != 0
      // && !S_ApiCalls.loading_on_strandsLC
    ) {
      summary_status = true;
    }
    if (
      Nav.Assessement &&
      Nav.class &&
      Nav.S_performance
      // && class_std.originalStrandsList.length != 0
      // && !ApiCalls_Reports.loading_Strands_table
    ) {
      summary_status = true;
    }
    if (
      Nav.Assessement &&
      Nav.school &&
      Nav.S_performance
      // && school_std.originalList.length != 0
      // &&!Sc_ApiCalls.loading_Strands_table
    ) {
      summary_status = true;
    }
    if (SummaryDistNavCondition(Nav)) {
      summary_status = true
    }

    return summary_status && strands_summary_report_enable
  }

  render() {
    let Nav = this.props.NavigationByHeaderSelection;
    const role = this.props.LoginDetails.UserRole;
    // const count = this.props.UniversalSelecter.Selected_Students_List;
    let C_Header = this.props.ContextHeader;

    let switchTabClass = 'container-fluid m-0 float-left switching-tabs';

    if (Nav.ORR) {
      switchTabClass += ' orr';
    }
    if (Nav.Assessement && (Nav.st_analysis || Nav.test_status)) {
      switchTabClass += "-notabs";
    }
    let comparisonTabStatus = this.ComparisonTabChecker(Nav);
    let strands_summary_report_enable = (STRANDS_SUMMARY_REPORTS === "true")
    let summaryTabStatus = this.SummaryTabChecker(Nav, strands_summary_report_enable);
    return (
      <div className={switchTabClass}>
        <div className="switchingtab_overview_block">
          <div className="row switchingtab_overview_inr float-left text-center">
            <ul className="p-0 mx-auto mb-0 ipad-tab-align">
              {Nav.Assessement && !Nav.st_analysis ?
                <React.Fragment>
                  <li
                    className={Nav.Overview ? "active_tab" : "inactive_tab"}
                    onClick={() =>
                      Nav.Overview
                        ? null
                        : this.props.SaveContextSelection("Overview")
                    }
                  >
                    <span className="switchingTab_icons">
                      <img src={standardOverviewIcon} width="20" />
                    </span>
                    <span style={{ position: "relative", padding: "2px 0px", top: "1px" }}>Overview</span>
                  </li>
                  <li
                    className={Nav.comparison ? "active_tab" : "inactive_tab"}
                    onClick={comparisonTabStatus ? () =>
                      Nav.comparison
                        ? null
                        : this.handleCompareClick(
                          this.props.NavigationByHeaderSelection
                        ) : null
                    }>
                    <span className="switchingTab_icons">
                      <img src={comparisonIcon} width="18" />
                    </span>
                    <span style={{ position: "relative", padding: "2px 0px", top: "1px" }}>Comparison</span>
                  </li>

                  {(role == "TEACHER" || role == "PRIMARY_TEACHER") &&
                    Nav.Assessement &&
                    Nav.class &&
                    Nav.S_performance &&
                    C_Header.Roster_Tab.StudentIds.length > 2 ? (
                    <li
                      className={Nav.grouping ? "active_tab" : "inactive_tab"}
                      onClick={
                        () =>
                          Nav.grouping
                            ? null
                            : this.props.SaveContextSelection(
                              "grouping",
                              UniqueProducts(
                                this.props.UniversalSelecter.TestTab
                                  .SelectedTestList
                              ),
                              this.props.StandardPerformance_Overview
                                .StandardPerformanceFilter
                            )
                        // this.props.classGroupingNew()
                      }
                    >
                      <span className="switchingTab_icons">
                        {/* <img src={GroupingIcon} width="18" /> */}
                        <i className="material-icons">group_add</i>
                      </span>
                      <span style={{ position: "relative", padding: "2px 0px", top: "1px" }}>Grouping</span>
                    </li>
                  ) : null}

                  {summaryTabStatus ? <li
                    className={Nav.summary ? 'active_tab' : 'inactive_tab'}
                    onClick={() =>
                      Nav.summary
                        ? null
                        : this.props.SaveContextSelection('summary')
                    }>
                    <span className="switchingTab_icons">
                      {SUMMARY_REPORTS_FLAG ? <img src={averageIcon} width="18" /> :
                        <img src={summaryIcon} width="18" />}
                    </span>
                    {SUMMARY_REPORTS_FLAG ? <span style={{ position: "relative", padding: "2px 0px", top: "1px" }}>Average</span> :
                      <span style={{ position: "relative", padding: "2px 0px", top: "1px" }}>Summary</span>}
                  </li> : null}
                </React.Fragment> : null}

              {Nav.ORR && (
                <React.Fragment>
                  <li
                    onClick={() =>
                      Nav.rlp ? null : this.props.SaveContextSelection('RLP')
                    }
                    className={Nav.rlp ? 'active_tab' : 'inactive_tab'}
                  >
                    Reading Level Progress
                  </li>

                  <React.Fragment>
                    <li
                      className={
                        Nav.readingHistory ? 'active_tab' : 'inactive_tab'
                      }
                      onClick={() =>
                        Nav.readingHistory
                          ? null
                          : this.props.SaveContextSelection('ReadingHistory')
                      }
                    >
                      Reading History
                      </li>
                    {!this.props.NavigationByHeaderSelection.district &&
                      <li
                        className={
                          Nav.errorAnalysis ? 'active_tab' : 'inactive_tab'
                        }
                        onClick={() =>
                          Nav.errorAnalysis
                            ? null
                            : this.props.SaveContextSelection('ErrorAnalysis')
                        }
                      >
                        Error Analysis
                      </li>}
                  </React.Fragment>


                  <li
                    className={
                      Nav.fluencyAnalysis ? 'active_tab' : 'inactive_tab'
                    }
                    onClick={() =>
                      Nav.fluencyAnalysis
                        ? null
                        : this.props.SaveContextSelection('FluencyAnalysis')
                    }
                  >
                    Fluency Analysis
                    </li>


                  {!this.props.NavigationByHeaderSelection.district &&
                    <li
                      className={
                        Nav.readingBehaviors ? 'active_tab' : 'inactive_tab'
                      }
                      onClick={() =>
                        Nav.readingBehaviors
                          ? null
                          : this.props.SaveContextSelection('ReadingBehaviors')
                      }
                    >
                      Reading Behaviors
                  </li>}
                  {/* <li
                    className={
                      Nav.Summary_Tab ? 'active_tab' : 'inactive_tab'
                    }
                    onClick={() =>
                      Nav.Summary_Tab
                        ? null
                        : this.props.SaveContextSelection('Summary_Tab')
                    }
                  >
                    Summary_Tab
                      </li> */}
                </React.Fragment>
              )}

            </ul>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  Reports,
  StudentReports,
  DistrictReducer,
  schoolReducer,
  ComparisonReducer
}) => {
  const {
    NavigationByHeaderSelection,
    UniversalSelecter,
    ContextHeader,
    UniversalFilter
  } = Universal;
  const { LoginDetails } = Authentication;
  const {
    D_StandardPerformance_Overview,
    D_Test_Scores_OverTime,
    D_ApiCalls
  } = DistrictReducer;
  const {
    Sc_StandardPerformance_Overview,
    Sc_Test_Scores_OverTime,
    Sc_ApiCalls
  } = schoolReducer;
  const {
    StandardPerformance_Overview,
    Test_Scores_OverTime,
    ApiCalls_Reports
  } = Reports;
  const {
    S_StandardPerformance_Overview,
    S_Test_Scores_OverView,
    S_ApiCalls
  } = StudentReports;
  const {
    studentComparison,
    classComparison,
    schoolComparison,
    districtComparison
  } = ComparisonReducer;
  return {
    NavigationByHeaderSelection,
    LoginDetails,
    UniversalSelecter,
    ContextHeader,
    StandardPerformance_Overview,
    Test_Scores_OverTime,
    S_StandardPerformance_Overview,
    UniversalFilter,
    Sc_StandardPerformance_Overview,
    Sc_Test_Scores_OverTime,
    D_StandardPerformance_Overview,
    D_Test_Scores_OverTime,
    D_ApiCalls,
    S_Test_Scores_OverView,
    Sc_ApiCalls,
    studentComparison,
    classComparison,
    schoolComparison,
    districtComparison,
    ApiCalls_Reports,
    S_ApiCalls
  };
};

export default connect(mapStateToProps, {
  SaveContextSelection,
  compareContextSelection,
  Get_Class_CSV_Details
})(Switching_Blocks_Filter);
