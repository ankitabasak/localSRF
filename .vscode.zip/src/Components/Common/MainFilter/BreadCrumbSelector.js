import React, { Component } from 'react';
import { connect } from 'react-redux';

class BreadCrumbSelector extends Component {

    constructor(props) {
        super(props);
        this.breadCrumbList = this.breadCrumbList.bind()
    }

    breadCrumbList(Nav) {
        return <ul>
            {Nav.Assessement ? <li>Assessments</li> : null}
            {/* {Nav.class ? <li>Class</li>:null}
            {Nav.student ? <li>Student</li>:null}
            {Nav.school ? <li>School</li>:null}
            {Nav.district ? <li>District</li>:null} */}
            {Nav.Assessement && Nav.S_performance ? <li>Standards Performance</li> : null}
            {Nav.Assessement && Nav.T_scores ? <li>Test Scores</li> : null}
            {Nav.Assessement && Nav.st_analysis && (!Nav.comparison || !Nav.grouping || !Nav.summary) ? <li>Single Test Analysis</li> : null}
            {Nav.Assessement && Nav.test_status && (!Nav.comparison || !Nav.grouping || !Nav.summary) ? <li>Test Status</li> : null}
            {Nav.Assessement && Nav.Overview && !Nav.st_analysis && !Nav.test_status ? <li>Overview</li> : null}
            {Nav.Assessement && Nav.comparison && !Nav.st_analysis && !Nav.test_status ? <li>Comparison</li> : null}
            {Nav.Assessement && Nav.grouping && !Nav.st_analysis && !Nav.test_status ? <li>Grouping</li> : null}
            {Nav.Assessement && Nav.summary && !Nav.st_analysis && !Nav.test_status ? <li>Summary</li> : null}
            {/* for Summary */}
            {Nav.Summary_Reports ? <li style={{ fontWeight: "bold" }}>Summary</li> : null}
            {/* for ORR */}
            {Nav.ORR ? <li>ORR</li> : null}
            {Nav.ORR && Nav.rlp ? <li>Reading Level Progress</li> : null}
            {Nav.ORR && Nav.readingHistory ? <li>Reading History</li> : null}
            {Nav.ORR && Nav.errorAnalysis ? <li>Error Analysis</li> : null}
            {Nav.ORR && Nav.fluencyAnalysis ? <li>Fluency Analysis</li> : null}
            {Nav.ORR && Nav.readingBehaviors ? <li>Reading Behaviors</li> : null}
        </ul>
    }

    render() {

        const breadCrumbs = this.breadCrumbList(this.props.NavigationByHeaderSelection)
        const Nav = this.props.NavigationByHeaderSelection
        return (
            <div className={Nav.Summary_Reports ? "ar_breadcrumb_main summary-ar_breadcrumb_main" : "ar_breadcrumb_main"}>
                <div className="container-fluid m-0 p-0 float-left">
                    <div className="row m-0 p-0">
                        <div className="ar_breadcrumb_inr">
                            {breadCrumbs}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = ({ Universal }) => {

    const { NavigationByHeaderSelection } = Universal;

    return {
        NavigationByHeaderSelection
    };

}

const mapStateToActions = {}

export default connect(mapStateToProps, mapStateToActions)(BreadCrumbSelector);