import React, { Component } from 'react';
import '../../../../public/css/style.css';
import './ContextHeader.css';
import { connect } from 'react-redux';
import {
    Open_U_Selector_From_ContextHeader
} from '../../../Redux_Actions/UniversalSelectorActions';
import ClassOverviewCSV from '../../ReusableComponents/CSV/ClassOverviewCSV';
import info_icon from '../../../../public/images/info_icon.svg';
import { Get_Class_CSV_Details } from '../../../Redux_Actions/ReportsActions';
import { SetOptionContextHeader, ClickStudentDataInfoIcon, ClickPdTestsInfoIcon, ClickPdDatesInfoIcon } from '../../../Redux_Actions/UniversalSelectorActions';
import { convertUTCDateToLocalDate, GetIds_of_Each_Object_In_The_Array, payloadParamsFor_Class_StdList_Graph_On_Strands } from '../../ReusableComponents/AllReusableFunctions';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../Utils/globalVars';
import { contextHeaderDates } from '../../../Utils/reUsableSnipets';

class ContextHeader extends React.PureComponent {
    constructor(props) {
        super(props);
        this.MoreOptionsRef = '';
        this.OnMouseDown = this.OnMouseDown.bind(this);
        this.renderUsageReportsSubwayNav = this.renderUsageReportsSubwayNav.bind(this);
        this.getSelectedUsageReportNames = this.getSelectedUsageReportNames.bind(this);
        this.openUniversalSelectorForUsage = this.openUniversalSelectorForUsage.bind(this);
        this.makeUsageHeaderSelection = this.makeUsageHeaderSelection.bind(this);
        this.StudentDataToolTip_Refs = null;
        this.pastDistrictTermRef = {};
        this.pastDistrictTermDatesRef = {};
        // this.GetCSVData = this.GetCSVData.bind(this);
        this.headerTypeValues = {
            'district': { 'label': 'District', 'type': 'district', 'tab': 'roster' },
            'school': { 'label': 'School', 'type': 'school', 'tab': 'roster' },
            'grade': { 'label': 'Grade', 'type': 'grade', 'tab': 'roster' },
            'teacher': { 'label': 'Teacher', 'type': 'teacher', 'tab': 'roster' },
            'class': { 'label': 'Class', 'type': 'class', 'tab': 'roster' },
            'student': { 'label': 'Student', 'type': 'student', 'tab': 'roster' },
            'dates': { 'label': 'Dates', 'type': 'dates', 'tab': 'date' },
        };
    }


    componentDidMount() {
        document.addEventListener("mousedown", this.OnMouseDown)
    }

    OnMouseDown(event) {
        if (this.props.ContextHeader.EnableMoreOptions) {
            // this.MoreOptionsRef

            if (this.MoreOptionsRef.contains(event.target)) {

            } else this.props.SetOptionContextHeader(false);
        }



        if (this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "contextheader") {
            if (event.target !== null && this.StudentDataToolTip_Refs !== null) {
                let Click_On_StudentDataTooltip = this.StudentDataToolTip_Refs.contains(event.target);

                Click_On_StudentDataTooltip ? null : this.props.ClickStudentDataInfoIcon("");
            }
        }
        if (this.props.ContextHeader.PdTestsInfoIcon) {
            if (this.pastDistrictTermRef !== null && this.pastDistrictTermRef !== undefined) {
                let isitemexists = this.pastDistrictTermRef.contains(event.target);
                if (isitemexists == undefined || isitemexists == null || isitemexists == false) {
                    this.props.ClickPdTestsInfoIcon(true)

                }
            }

        }
        if (this.props.ContextHeader.PdDatesInfoIcon) {
            if (this.pastDistrictTermDatesRef !== null && this.pastDistrictTermDatesRef !== undefined) {
                let isitemexists = this.pastDistrictTermDatesRef.contains(event.target);
                if (isitemexists == undefined || isitemexists == null || isitemexists == false) {
                    this.props.ClickPdDatesInfoIcon(true)

                }
            }

        }

    }

    componentWillUnmount() {
        document.removeEventListener("mousedown", this.OnMouseDown)

    }

    /**
     * 
     * @param {string} TabToOpen -- Roster/test/Date 
     * @param {string} from  --class/date/teests/school/student
     * open universal filter tabs from context header by passing exact tab name which has to open (ex: roster,test,date)
     */
    OpenU_SelectorTab(TabToOpen, from) {
        this.props.Open_U_Selector_From_ContextHeader(TabToOpen, from);
    }


    tooptipDisplay(tooltipName) {

        let contextTooltip = null;
        if (tooltipName !== null && tooltipName !== undefined) {
            tooltipName.length > 18 ? contextTooltip =
                <div className="bec_tooltip">
                    <div className="bec_tooltip_arrow"></div>
                    <div className="bec_tooltip_content">
                        {tooltipName}
                    </div>
                </div> : null;
        }

        return contextTooltip;
    }

    tooptipDisplayForPopup(tooltipName) {

        let contextTooltip = null;
        if (tooltipName !== null && tooltipName !== undefined) {
            tooltipName.length > 28 ? contextTooltip =
                <div className="bec_tooltip">
                    <div className="bec_tooltip_arrow"></div>
                    <div className="bec_tooltip_content">
                        {tooltipName}
                    </div>
                </div> : null;
        }

        return contextTooltip;
    }

    tooptipDisplayForTest(tooltipName) {

        let contextTooltip = null;
        if (tooltipName !== null && tooltipName !== undefined) {
            tooltipName.length > 13 ? contextTooltip =
                <div className="bec_tooltip">
                    <div className="bec_tooltip_arrow"></div>
                    <div className="bec_tooltip_content">
                        {tooltipName}
                    </div>
                </div> : null;
        }

        return contextTooltip;
    }

    /**
     * 
     * @param {Object} C_RosterData 
     * @returns {JSX Element} 
     * 
     */
    ReturnStudentView(C_RosterData) {
        let SelectedStudent = C_RosterData.SelectedStudent && C_RosterData.SelectedStudent.name == undefined ? C_RosterData.SelectedStudent :
            C_RosterData.SelectedStudent && C_RosterData.SelectedStudent.name;
        if (C_RosterData.StudentsList.length !== 1 && C_RosterData.StudentsList.length !== C_RosterData.StudentIds.length && SelectedStudent !== "All") {
            return <li
                className="active-context">
                <span className="context-header-title">Student: </span>
                <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('roster', 'student')}>
                    {Ellipsis(SelectedStudent)}
                    {this.tooptipDisplay(SelectedStudent)}
                </span>
            </li>
        }
    }
    StudentDataClassTrueCheck(value) {
        if (value != undefined || value != null || value != "") {
            let SelectedTestList = value.filter(item => item.check == true);
            return SelectedTestList;
        };
    }
    ContextHeaderTestsInfoIcon() {
        return this.props.isPastDistrictTerm ? <span class="infoIconForRosterClass"
            onClick={() =>
                this.props.ContextHeader.PdTestsInfoIcon ?
                    this.props.ClickPdTestsInfoIcon(true) :
                    this.props.ClickPdTestsInfoIcon(false)}
            ref={ref => (ref !== null ? this.pastDistrictTermRef = ref : null)}
        >
            <img src={info_icon} style={{ marginTop: "-1px", marginLeft: "4px", cursor: "pointer", width: "16px" }} />
            {this.props.ContextHeader.PdTestsInfoIcon ?
                <div ref={ref => (ref !== null ? this.pastDistrictTermRef = ref : null)} className="infoIconForRosterClass_tooltip" style={{ position: "absolute", top: "-62px", right: "-21px" }}>
                    <span className="infoIconForRosterClass_tooltip_left" style={{ borderColor: "#606060 transparent transparent", top: "52px", borderWidth: "8px" }}></span>
                    <span className="infoIconForRosterClass_tooltip_right" style={{ width: "141px", height: "36px" }}>
                        <span className="infoIconForRosterClass_tooltip_Description">Tests displayed are from past district term.</span>
                    </span>
                </div> : null}
        </span> : null
    }
    ContextHeaderDatesInfoIcon() {
        return this.props.isPastDistrictTerm ? <span class="infoIconForRosterClass"
            onClick={() =>
                this.props.ContextHeader.PdDatesInfoIcon ?
                    this.props.ClickPdDatesInfoIcon(true) :
                    this.props.ClickPdDatesInfoIcon(false)}
            ref={ref => (ref !== null ? this.pastDistrictTermDatesRef = ref : null)}
        >
            <img src={info_icon} style={{ marginTop: "-2px", marginLeft: "4.5px", cursor: "pointer", width: "16px" }} />
            {this.props.ContextHeader.PdDatesInfoIcon ?
                <div ref={ref => (ref !== null ? this.pastDistrictTermDatesRef = ref : null)} class="infoIconForRosterClass_tooltip" style={{ position: "absolute", top: "-62px", right: "-18px" }}>
                    <span class="infoIconForRosterClass_tooltip_left" style={{ borderColor: "#606060 transparent transparent", top: "51px", borderWidth: "8px", right: "17px" }}></span>
                    <span class="infoIconForRosterClass_tooltip_right" style={{ width: "131px", height: "36px" }}>
                        <span class="infoIconForRosterClass_tooltip_Description">Dates displayed are from past district term.</span>
                    </span>
                </div> : null}
        </span> : null
    }
    ContextHeaderLocalTimeBasedOnFlag(Display) {
        let LocalDate = null;
        LocalDate = (Display.minTestDate === Display.maxTestDate) ? (Display.minTestDate !== undefined && Display.minTestDate !== null ? convertUTCDateToLocalDate(Display.minTestDate, Display.minDateTime) : Display.minTestDate) : (Display.minTestDate !== undefined && Display.minTestDate !== null ? convertUTCDateToLocalDate(Display.minTestDate, Display.minDateTime) : Display.minTestDate) + '-' + (Display.maxTestDate !== undefined && Display.maxTestDate !== null ? convertUTCDateToLocalDate(Display.maxTestDate, Display.maxDateTime) : Display.maxTestDate);
        return LocalDate;
    }

    componentDidCatch(error, info) {
    }

    /**
     * @returns {JSX Element}
     */
    SwitchBasedOnSubwayNav() {
        const { showContextHeaderDates } = this.props;
        let Display = this.props.ContextHeader;
        let Nav = this.props.NavigationByHeaderSelection;
        // let StudentName = Display.Student && Display.Student.name == undefined ? "" : Display.Student && Display.Student.name;
        // let StudentId = Display.Student && Display.Student.id == undefined ? Display.Student && Display.Student.studentId : Display.Student && Display.Student.id;

        let C_RosterData = Nav.Summary_Reports ? Display.Summary_Roster_Data : Display.Roster_Tab;

        let U_RosterStudent = C_RosterData.SelectedStudent !== undefined &&
            C_RosterData.SelectedStudent !== null ? C_RosterData.SelectedStudent : {}

        let C_RosterClass = C_RosterData.SelectedClass !== undefined &&
            C_RosterData.SelectedClass !== null ? C_RosterData.SelectedClass : {}


        let C_RosterTeacher = C_RosterData.SelectedTeacher !== undefined &&
            C_RosterData.SelectedTeacher !== null ? C_RosterData.SelectedTeacher : {}

        let C_RosterSchool = C_RosterData.SelectedSchool !== undefined &&
            C_RosterData.SelectedSchool !== null ? C_RosterData.SelectedSchool : {}

        let C_RosterDistrict = C_RosterData.SelectedDistrict !== undefined &&
            C_RosterData.SelectedDistrict !== null ? C_RosterData.SelectedDistrict : {}

        let filteredStudentData = (C_RosterData.StudentData_cls != undefined && C_RosterData.StudentData_cls != null && C_RosterData.StudentData_cls.length > 0) ? this.StudentDataClassTrueCheck(C_RosterData.StudentData_cls) : [];

        let IsDistrictAdmin = Display.User_Role == "DISTRICT_ADMIN";

        let IsSchoolAdmin = Display.User_Role == "SCHOOL_ADMIN";
        let isPastDistrictTerm = this.props.isPastDistrictTerm

        let IsTeacher = Display.User_Role == "TEACHER" || Display.User_Role == "PRIMARY_TEACHER";
        let studentSSID = ' (' + ((U_RosterStudent.sisId == null || U_RosterStudent.sisId == "null") ? '' : U_RosterStudent.sisId) + ')'
        let studentFulldata = U_RosterStudent == undefined || U_RosterStudent == null ? "" : U_RosterStudent.name == undefined ? "" : U_RosterStudent.name + studentSSID

        // block for disable context header text starts if no data in District Summary Reports added in sprint_54
        const { SummaryReports, LoginDetails,DateTabComponents } = this.props;
        const { ReportingAccessParam } = LoginDetails;
        let OnlyORRData = !ReportingAccessParam.includes('eAR') && ReportingAccessParam.includes('ORR')
        let fromContext = Nav.district ? "district" : Nav.school ? "school" : "class";
        let context_props = SummaryReports[`${fromContext}`].assessments;
        const { standardperformance } = context_props;
        let summary_stand_perf_data_length = standardperformance !== undefined ? (standardperformance.data != null && standardperformance.data != undefined ? Object.keys(standardperformance.data).length : 0) : 0;
        const { Date_Tab } = Display;
        let GrayoutContextHeader = !OnlyORRData && (Nav.district || Nav.school || Nav.class) && Nav.Summary_Reports && (summary_stand_perf_data_length === 0 ||  DateTabComponents.TermsListWithOutUTCFormat && DateTabComponents.TermsListWithOutUTCFormat[0] && Date_Tab.summaryReportsTerm.termId != DateTabComponents.TermsListWithOutUTCFormat[0].termId) ? true : false;
        // block for disable context header text ends  if no data in District Summary Reports  added in sprint_54   
       
        switch (true) {
            case Nav.class:
                return this.props.UserScreenWidth < 1900 ? <ul className={Display.selected_Students.length !== Display.LastApplyiedStudents.length && Display.Student != "All" ? "m-0 context-header-for-class" : Nav.Summary_Reports ? "summary-context_header_class m-0" : "m-0 context-header-for-class"}>
                    {!Nav.Summary_Reports && this.ReturnStudentView(C_RosterData)}

                    {
                        <li
                            className={"active-context"}>
                            <span className="context-header-title">Class: </span>
                            <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text"} 
                            onClick={() =>!GrayoutContextHeader ?
                                this.OpenU_SelectorTab('roster', 'class'):null}>
                                {Ellipsis(C_RosterClass.name)}
                                {this.tooptipDisplay(C_RosterClass.name)}
                            </span>
                        </li>
                    }

                    <li className={Nav.Summary_Reports ? "sumary-context-class-teacher" : ""}>
                        <span className="context-header-title">Teacher: </span>
                         <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text"} 
                           onClick={() => IsSchoolAdmin || !GrayoutContextHeader ? this.OpenU_SelectorTab('roster', 'class') : null}>
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : Ellipsis(C_RosterTeacher) : Ellipsis(C_RosterTeacher.name)}
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : this.tooptipDisplay(C_RosterTeacher) : this.tooptipDisplay(C_RosterTeacher.name)}
                        </span>
                    </li>
                    {/* {U_RosterStudent == "All" ? */}
                    {C_RosterData.StudentIds.length === C_RosterData.StudentsList.length  && <li>
                        <span className="context-header-title">Grade: </span>
                        <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text"} 
                            style={{
                                cursor: this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER"
                                    || this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" ? "text" : "pointer"
                            }}
                            onClick={() =>
                                IsSchoolAdmin|| !GrayoutContextHeader ? this.OpenU_SelectorTab('roster', 'school') : null}>
                            {/*  {convertGrade(C_RosterData.selectedRosterGrade)} */}
                            {(C_RosterData.selectedRosterGrade == "All") ? C_RosterData.GradesList[0] && convertGrade(C_RosterData.GradesList[0].grade) : convertGrade(C_RosterData.selectedRosterGrade)}
                        </span>
                    </li> }
                    
                    {/* : null */}

                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}
                        </span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null
                    }
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Dates: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('date', 'dates')}>{EllipsisForTest(Display.dates)}{this.tooptipDisplayForTest(Display.dates)}
                            {showContextHeaderDates && ((DISPLAY_LOCAL_TIME_IN_UI == true) ? this.ContextHeaderLocalTimeBasedOnFlag(Display) : contextHeaderDates(Display))}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null
                    }
                    {Nav.Summary_Reports && Nav.class ? <li>
                        <span className="context-header-title Summary-report-context-header-title">Dates: </span>
                        <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text Summary-report-context-header-text"} style={{ cursor: 'default' }}>{this.props.DateTabComponents.SelectedDistrictTerm.termName}</span>

                    </li> : null}
                    <li className="context_header_more_options"
                        onClick={() => {
                            this.props.SetOptionContextHeader(true)
                        }}>
                        <span className="context-header-title">
                            <i class="material-icons">
                                more_vert
                            </i>
                        </span>
                        {Display.EnableMoreOptions == true ?
                            <div class="context-header-popup" ref={(node) => this.MoreOptionsRef = node} >
                                {/* {U_RosterStudent != "All" ?
                                    <div class="title_and_attribute">
                                        <span className="context_header_popup_title_display">Grade: </span>
                                        <span className="context_header_popup_text_display"
                                            style={{
                                                cursor: this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER"
                                                    || this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" ? "text" : "pointer"
                                            }}
                                            onClick={() =>
                                                this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER" || this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" ? null : this.OpenU_SelectorTab('roster', 'school')}>
                                            <span className="context-header-text">{convertGrade(C_RosterData.selectedRosterGrade)}</span>
                                        </span>
                                    </div> : null} */}
                                <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">School:</div>
                                    <div className="context_header_popup_text_display" onClick={() =>
                                        IsSchoolAdmin ? this.OpenU_SelectorTab('roster', 'school') : null}>
                                        <span className="context-header-text">
                                            {EllipsisForPopup(C_RosterSchool.name)}
                                            {this.tooptipDisplayForPopup(C_RosterSchool.name)}
                                        </span>
                                    </div>
                                </div>
                                <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">District:</div>
                                    <div className="context_header_popup_text_display">
                                        <span className="context-header-text">
                                            {EllipsisForPopup(C_RosterDistrict.name)}
                                            {this.tooptipDisplayForPopup(C_RosterDistrict.name)}
                                        </span>
                                    </div>
                                </div>
                                {U_RosterStudent == "All" ? null :

                                    <div class="title_and_attribute">
                                        <div className="context_header_popup_title_display">Grade:</div>
                                        <div className="context_header_popup_text_display">
                                            <span className="context-header-text" onClick={() => IsSchoolAdmin ? this.OpenU_SelectorTab('roster', 'class') : null}>
                                                {/* {convertGrade(C_RosterData.selectedRosterGrade)} */}
                                                {(C_RosterData.selectedRosterGrade == "All") ? C_RosterData.GradesList[0] && convertGrade(C_RosterData.GradesList[0].grade) : convertGrade(C_RosterData.selectedRosterGrade)}
                                            </span>
                                        </div>
                                    </div>

                                }

                                {/* <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">Product:</div>
                                    <div className="context_header_popup_text_display">BEC Report</div>
                                </div> */}

                            </div>
                            : null}
                    </li>

                </ul > : <ul className={C_RosterData.StudentIds.length !== C_RosterData.StudentsList.length ? "m-0 context-header_multi" : "m-0"}>
                    {!Nav.Summary_Reports && this.ReturnStudentView(C_RosterData)}

                    {/*######### Class Context Header ###########*/}

                    {
                        <li
                            className={Display.selected_Students.length !== Display.LastApplyiedStudents.length ? "active-context" : "active-context"}>
                            <span className="context-header-title">Class: </span>
                            <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text Summary-report-context-header-text"} 
                                 onClick={() => !GrayoutContextHeader ?
                                this.OpenU_SelectorTab('roster', 'class'):null}>
                                {Ellipsis(C_RosterClass.name)}
                                {this.tooptipDisplay(C_RosterClass.name)}
                            </span>
                        </li>
                    }
                    <li>
                        <span className="context-header-title">Teacher: </span>
                        <span className="context-header-text" onClick={() => IsSchoolAdmin ? this.OpenU_SelectorTab('roster', 'class') : null}>
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : Ellipsis(C_RosterTeacher) : Ellipsis(C_RosterTeacher.name)}
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : this.tooptipDisplay(C_RosterTeacher) : this.tooptipDisplay(C_RosterTeacher.name)}
                        </span>
                    </li>

                    <li>
                        <span className="context-header-title">Grade: </span>
                        <span className="context-header-text"
                            style={{
                                cursor: this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER" || this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" ? "text" : "pointer"
                            }}
                            onClick={() =>
                                this.OpenU_SelectorTab('roster', 'school')}>
                            {/* {convertGrade(C_RosterData.selectedRosterGrade)} */}
                            {(C_RosterData.selectedRosterGrade == "All") ? C_RosterData.GradesList[0] && convertGrade(C_RosterData.GradesList[0].grade) : convertGrade(C_RosterData.selectedRosterGrade)}
                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">School:</span>
                        <span className="context-header-text" onClick={() =>
                            IsSchoolAdmin ? this.OpenU_SelectorTab('roster', 'school') : null}>

                            {Ellipsis(C_RosterSchool.name)}
                            {this.tooptipDisplay(C_RosterSchool.name)}

                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">District:</span>
                        <span className="context-header-text">

                            {Ellipsis(C_RosterDistrict.name)}
                            {this.tooptipDisplay(C_RosterDistrict.name)}

                        </span>
                    </li>
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}
                        </span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null}
                    {Nav.Assessement ? <li>
                        < span className="context-header-title">Dates: </span>
                        <span className="context-header-text"
                            onClick={() => this.OpenU_SelectorTab('date', 'dates')}
                        >{showContextHeaderDates && ((DISPLAY_LOCAL_TIME_IN_UI == true) ? this.ContextHeaderLocalTimeBasedOnFlag(Display) : contextHeaderDates(Display))}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null}

                    {Nav.Summary_Reports && Nav.class ? <li style={{ float: "right" }}>
                        <span className="context-header-title Summary-report-context-header-title">Dates: </span>
                        <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text Summary-report-context-header-text"} style={{ cursor: 'default' }}>{this.props.DateTabComponents.SelectedDistrictTerm.termName}</span>

                    </li> : null}

                </ul >
            case Nav.student:
                return this.props.UserScreenWidth < 1900 ? <ul className="m-0 context-header-for-student">

                    {/*######### Student Context Header ###########*/}

                    <li
                        className="active-context">
                        <span className="context-header-title">Student: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('roster', 'student')}>
                            {Ellipsis(studentFulldata)}
                            {this.tooptipDisplay(studentFulldata)}
                        </span>
                    </li>

                    <li>
                        <span className="context-header-title">Class: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('roster', 'class')}>
                            {Ellipsis(C_RosterClass.name)}
                            {this.tooptipDisplay(C_RosterClass.name)}
                        </span>

                        {
                            (filteredStudentData.length > 1 || (C_RosterData.StudentData_cls_ids.length == 0 && C_RosterData.StudentData_cls.length > 1) || (filteredStudentData.length == 1 && (C_RosterData.SelectedStudentData.id != C_RosterClass.id))) && Nav.student && !isPastDistrictTerm

                                ?
                                <span class="infoIconForRosterClass"
                                    onClick={() =>
                                        this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "contextheader" ?
                                            null :
                                            this.props.ClickStudentDataInfoIcon("contextheader")}
                                    ref={(refNode) => refNode == null ? null : this.StudentDataToolTip_Refs = refNode}
                                >
                                    <img src={info_icon} style={{ marginTop: "-5px", marginLeft: "4px", cursor: "pointer", width: "16px" }} />
                                    {this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "contextheader" ?
                                        <div class="infoIconForRosterClass_tooltip">
                                            <span class="infoIconForRosterClass_tooltip_left"></span>
                                            <span class="infoIconForRosterClass_tooltip_right">
                                                <span class="infoIconForRosterClass_tooltip_Description">This report includes student data from another class or classes.</span>
                                            </span>
                                        </div> : null}
                                </span> :
                                null}
                    </li>

                    <li>
                        <span className="context-header-title">Teacher: </span>
                        <span className="context-header-text"
                            style={{ cursor: this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER" || this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" ? "text" : "pointer" }}
                            onClick={() =>
                                IsSchoolAdmin ?
                                    this.OpenU_SelectorTab('roster', 'school') : null
                            }>
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : Ellipsis(C_RosterTeacher) : Ellipsis(C_RosterTeacher.name)}
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : this.tooptipDisplay(C_RosterTeacher) : this.tooptipDisplay(C_RosterTeacher.name)}
                        </span>
                    </li>

                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}</span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null}
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Dates: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('date', 'dates')}>{EllipsisForTest(Display.dates)}{this.tooptipDisplayForTest(Display.dates)}
                            {showContextHeaderDates && ((DISPLAY_LOCAL_TIME_IN_UI == true) ? this.ContextHeaderLocalTimeBasedOnFlag(Display) : contextHeaderDates(Display))}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null
                    }
                    <li class="context_header_more_options"
                        onClick={() => { this.props.SetOptionContextHeader(true) }}>
                        <span className="context-header-title">
                            <i class="material-icons">
                                more_vert
                            </i>
                        </span>
                        {Display.EnableMoreOptions == true ?

                            <div class="context-header-popup" ref={(node) => this.MoreOptionsRef = node}>
                                <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">Grade:</div>
                                    <div className="context_header_popup_text_display"
                                        onClick={() => this.OpenU_SelectorTab('roster', 'school')}
                                    >{convertGrade(C_RosterData.selectedRosterGrade)}</div>
                                </div>
                                <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">School:</div>
                                    <div className="context_header_popup_text_display" onClick={() =>
                                        IsSchoolAdmin ? this.OpenU_SelectorTab('roster', 'school') : null}>
                                        <span className="context-header-text">
                                            {EllipsisForPopup(C_RosterSchool.name)}
                                            {this.tooptipDisplayForPopup(C_RosterSchool.name)}
                                        </span>
                                    </div>
                                </div>
                                <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">District:</div>
                                    <div className="context_header_popup_text_display">
                                        <span className="context-header-text">
                                            {EllipsisForPopup(C_RosterDistrict.name)}
                                            {this.tooptipDisplayForPopup(C_RosterDistrict.name)}
                                        </span></div>
                                </div>
                                {/* <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">Product:</div>
                                    <div className="context_header_popup_text_display">BEC Report</div>
                                </div> */}
                            </div> : null}
                    </li>
                </ul> : <ul className="m-0 context-header-for-student">

                    {/*######### Student Context Header ###########*/}
                    <li

                        className="active-context">
                        <span className="context-header-title">Student: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('roster', 'student')}>
                            {Ellipsis(studentFulldata)}
                            {this.tooptipDisplay(studentFulldata)}
                        </span>
                    </li>

                    <li
                    >
                        <span className="context-header-title">Class: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('roster', 'class')}>
                            {Ellipsis(C_RosterClass.name)}
                            {this.tooptipDisplay(C_RosterClass.name)}
                        </span>





                        {(filteredStudentData.length > 1 || (C_RosterData.StudentData_cls_ids.length == 0 && C_RosterData.StudentData_cls.length > 1) || (filteredStudentData.length == 1 && (C_RosterData.SelectedStudentData.id != C_RosterClass.id))) && Nav.student && !isPastDistrictTerm ?
                            <span class="infoIconForRosterClass"
                                onClick={() =>
                                    this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "contextheader" ?
                                        null :
                                        this.props.ClickStudentDataInfoIcon("contextheader")}
                                ref={(refNode) => refNode == null ? null : this.StudentDataToolTip_Refs = refNode}
                            >
                                <img src={info_icon} style={{ marginTop: "-5px", marginLeft: "4px", cursor: "pointer", width: "16px" }} />
                                {this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "contextheader" ?
                                    <div class="infoIconForRosterClass_tooltip">
                                        <span class="infoIconForRosterClass_tooltip_left"></span>
                                        <span class="infoIconForRosterClass_tooltip_right">
                                            <span class="infoIconForRosterClass_tooltip_Description">This report includes student data from another class or classes.</span>
                                        </span>
                                    </div> : null}
                            </span> :
                            null}

                    </li>

                    <li>
                        <span className="context-header-title">Teacher: </span>
                        <span className="context-header-text"
                            style={{ cursor: this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER" || this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" ? "text" : "pointer" }}
                            onClick={() =>
                                IsSchoolAdmin ?
                                    this.OpenU_SelectorTab('roster', 'school') : null
                            }>
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : Ellipsis(C_RosterTeacher) : Ellipsis(C_RosterTeacher.name)}
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : this.tooptipDisplay(C_RosterTeacher) : this.tooptipDisplay(C_RosterTeacher.name)}
                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">Grade: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('roster', 'class')}>{convertGrade(C_RosterData.selectedRosterGrade)}</span>
                    </li>
                    <li>
                        <span className="context-header-title">School:</span>
                        <span className="context-header-text" onClick={() => IsSchoolAdmin ? this.OpenU_SelectorTab('roster', 'school') : null} >

                            {Ellipsis(C_RosterSchool.name)}
                            {this.tooptipDisplay(C_RosterSchool.name)}

                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">District:</span>
                        <span className="context-header-text">
                            {Ellipsis(C_RosterDistrict.name)}
                            {this.tooptipDisplay(C_RosterDistrict.name)}
                        </span>
                    </li>
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}</span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null}
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Dates: </span>
                        <span className="context-header-text"
                            onClick={() => this.OpenU_SelectorTab('date', 'dates')}
                        >{showContextHeaderDates && ((DISPLAY_LOCAL_TIME_IN_UI == true) ? this.ContextHeaderLocalTimeBasedOnFlag(Display) : contextHeaderDates(Display))}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null}


                </ul >
            case Nav.school:
                return this.props.UserScreenWidth < 1900 ? <ul className={Nav.Summary_Reports ? "summary-context_header_school m-0" : "m-0 context_header_school"}>
                    {!Nav.Summary_Reports ? <li>
                        <span className="context-header-title">Teacher: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : Ellipsis(C_RosterTeacher) : Ellipsis(C_RosterTeacher.name)}
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : this.tooptipDisplay(C_RosterTeacher) : this.tooptipDisplay(C_RosterTeacher.name)}
                        </span>
                    </li> : null}
                    {!Nav.Summary_Reports ? <li>
                        <span className="context-header-title">Grade: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>

                            {(C_RosterData.selectedRosterGrade == "All") ? C_RosterData.GradesList[0] && convertGrade(C_RosterData.GradesList[0].grade) : convertGrade(C_RosterData.selectedRosterGrade)}

                        </span>
                    </li> : null}
                    {!Nav.Summary_Reports ? <li>
                        <span className="context-header-title">School: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>

                            {Ellipsis(C_RosterSchool.name)}
                            {this.tooptipDisplay(C_RosterSchool.name)}

                        </span>
                    </li> : null}
                    {Nav.Summary_Reports && Nav.school ? <li>
                        <span className="context-header-title Summary-report-context-header-title" >School: </span>
                        <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout" : "context-header-text Summary_Reports_District_active"} onClick={() =>!GrayoutContextHeader ?
                                this.OpenU_SelectorTab('roster', 'school'):null}>
                            {Ellipsis(C_RosterSchool.name)}
                            {this.tooptipDisplay(C_RosterSchool.name)}

                        </span>
                    </li> : null}
                    {Nav.Summary_Reports && Nav.school ? <li>
                        <span className="context-header-title Summary-report-context-header-title">District: </span>
                        <span className={Nav.Summary_Reports && Nav.school ? GrayoutContextHeader ? "ar_summary_context_header_grayout" : "context-header-text Summary_Reports_District_active Summary-report-context-header-text" : "context-header-text"}
                            onClick={() =>!GrayoutContextHeader ?
                                this.OpenU_SelectorTab('roster', 'school'):null}>
                            {Ellipsis(C_RosterDistrict.name)}
                            {this.tooptipDisplay(C_RosterDistrict.name)}
                        </span>
                    </li> : null}
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}</span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null}
                    {Nav.Summary_Reports && Nav.school ? <li>
                        <span className="context-header-title Summary-report-context-header-title">Dates: </span>
                        <span className={GrayoutContextHeader ? "ar_summary_context_header_grayout context-header-text" : "context-header-text Summary-report-context-header-text"} style={{ cursor: 'default' }}>{this.props.DateTabComponents.SelectedDistrictTerm.termName}</span>

                    </li> : null}
                    {Nav.Assessement ? <li >
                        <span className="context-header-title">Dates: </span>
                        <span className="context-header-text"
                            onClick={() => this.OpenU_SelectorTab('date', 'dates')}
                        >{showContextHeaderDates && ((DISPLAY_LOCAL_TIME_IN_UI == true) ? this.ContextHeaderLocalTimeBasedOnFlag(Display) : contextHeaderDates(Display))}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null}
                    {Nav.Assessement ? <li class="context_header_more_options"
                        onClick={() => { this.props.SetOptionContextHeader(true) }}>
                        <span className="context-header-title">
                            <i class="material-icons">
                                more_vert
                            </i>
                        </span>
                        {Display.EnableMoreOptions == true ?
                            <div class="context-header-popup" ref={(node) => this.MoreOptionsRef = node}>
                                <div class="title_and_attribute">
                                    <div className="context_header_popup_title_display">District:</div>
                                    <div className="context_header_popup_text_display">
                                        <span className="context-header-text">
                                            {Ellipsis(C_RosterDistrict.name)}
                                            {this.tooptipDisplay(C_RosterDistrict.name)}
                                        </span></div>
                                </div>
                            </div> : null}
                    </li> : null}
                </ul> : <ul className="m-0 context_header_school">
                    <li>
                        <span className="context-header-title">Teacher: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : Ellipsis(C_RosterTeacher) : Ellipsis(C_RosterTeacher.name)}
                            {C_RosterTeacher.name == undefined ? typeof C_RosterTeacher == "object" ? "" : this.tooptipDisplay(C_RosterTeacher) : this.tooptipDisplay(C_RosterTeacher.name)}
                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">Grade: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>
                            {(C_RosterData.selectedRosterGrade == "All") ? C_RosterData.GradesList[0] && convertGrade(C_RosterData.GradesList[0].grade) : convertGrade(C_RosterData.selectedRosterGrade)}
                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">School: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>

                            {Ellipsis(C_RosterSchool.name)}
                            {this.tooptipDisplay(C_RosterSchool.name)}

                        </span>
                    </li>
                    <li>
                        <span className="context-header-title">District: </span>
                        <span className={Nav.Summary_Reports && Nav.district && GrayoutContextHeader ? "context-header-text ar_summary_context_header_grayout" : Nav.Summary_Reports && Nav.district ? "context-header-text Summary_Reports_District_active" : "context-header-text"}
                            onClick={() => !GrayoutContextHeader ? this.OpenU_SelectorTab('roster', 'school') : null}>
                            {Ellipsis(C_RosterDistrict.name)}
                            {this.tooptipDisplay(C_RosterDistrict.name)}

                        </span>
                    </li>
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}</span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null}
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Dates: </span>
                        <span className={Nav.Summary_Reports && Nav.district && GrayoutContextHeader ? "context-header-text ar_summary_context_header_grayout" : "context-header-text"} style={{ cursor: 'default' }}>{this.props.DateTabComponents.SelectedDistrictTerm.termName}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null}
                </ul>
            case Nav.district:
                return <ul className={Nav.Summary_Reports ? "summary-context_header_district context_header_district m-0" : "m-0 context_header_district"}>
                    {Nav.Assessement && C_RosterData.SchoolIds.length != 0 && C_RosterData.schoolsList && (C_RosterData.SchoolIds.length !== C_RosterData.schoolsList.length) ? <li>
                        <span className="context-header-title">School: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>
                            Custom ({C_RosterData.SchoolIds && C_RosterData.SchoolIds.length})
                        </span>
                    </li> : null}
                    {!Nav.Summary_Reports ? <li>
                        <span className="context-header-title">Grade: </span>
                        <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>{(C_RosterData.selectedRosterGrade == "All") ? C_RosterData.GradesList[0] && convertGrade(C_RosterData.GradesList[0].grade) : convertGrade(C_RosterData.selectedRosterGrade)}</span>
                        {/* <span className="context-header-text" onClick={() =>
                            this.OpenU_SelectorTab('roster', 'school')}>
                            {(C_RosterData.selectedRosterGrade != "All") ? convertGrade(C_RosterData.selectedRosterGrade) : C_RosterData.selectedRosterGrade}
                        </span> */}
                    </li> : null}

                    <li>
                        <span className="context-header-title">District: </span>
                        <span className={Nav.Summary_Reports && Nav.district ? GrayoutContextHeader ? "context-header-text ar_summary_context_header_grayout" : "context-header-text Summary_Reports_District_active" : "context-header-text"}
                            onClick={() =>!GrayoutContextHeader ?
                                this.OpenU_SelectorTab('roster', 'school'):null}>
                            {Ellipsis(C_RosterDistrict.name)}
                            {this.tooptipDisplay(C_RosterDistrict.name)}
                        </span>
                    </li>
                    {Nav.Assessement ? <li>
                        <span className="context-header-title">Tests: </span>
                        <span className="context-header-text" onClick={() => this.OpenU_SelectorTab('test', 'tests')}>{EllipsisForTest(Display.tests)}{this.tooptipDisplayForTest(Display.tests)}</span>
                        {this.ContextHeaderTestsInfoIcon()}
                    </li> : null}
                    {Nav.Assessement ? <li
                    >
                        <span className="context-header-title">Dates: </span>
                        <span className="context-header-text"
                            onClick={() => this.OpenU_SelectorTab('date', 'dates')}
                        >{showContextHeaderDates && ((DISPLAY_LOCAL_TIME_IN_UI == true) ? this.ContextHeaderLocalTimeBasedOnFlag(Display) : contextHeaderDates(Display))}</span>
                        {this.ContextHeaderDatesInfoIcon()}
                    </li> : null}
                    {Nav.Summary_Reports && Nav.district ? <li className="summary_context_header_district-li">
                        <span className="context-header-title">Dates: </span>
                        <span className={GrayoutContextHeader ? "context-header-text ar_summary_context_header_grayout" : "context-header-text"} style={{ cursor: 'default' }}>{Date_Tab.summaryReportsTerm.termName}</span>

                    </li> : null}
                </ul>
            default:
                return null
        }
    }

    getSelectedUsageReportNames() {
        const displayLevels = ['school', 'teacher', 'class', 'student'];
        const displayNames = {};
        let name = '';
        let idName = '';
        let listName = '';
        let totalSelected = 0;
        displayLevels.forEach((level) => {
            if (this.props.usageReports.contextNames[level] !== undefined) {
                displayNames[level] = this.props.usageReports.contextNames[level];
            } else {
                idName = `${level}Ids`;
                listName = `${level}List`;
                totalSelected = this.props.usageReports[idName].length;
                name = (totalSelected === 0) ? 'All' : `Custom(${totalSelected})`;
                if (Array.isArray(this.props.usageReports[listName])) {
                    name = (totalSelected === this.props.usageReports[listName].length) ? 'All' : name;
                }
                if (totalSelected === 1) {
                    if (this.props.usageReports[listName] !== null) {
                        this.props.usageReports[listName].forEach((member) => {
                            if (member.id === this.props.usageReports[idName][0]) {
                                name = member.name;
                            }
                        });
                    }
                }
                displayNames[level] = (name === 'Custom(1)') ? 'Unknown' : name;
            }
        });
        displayNames.district = this.props.usageReports.districtName !== null
          ? this.props.usageReports.districtName : '';
        return displayNames;
    }

    openUniversalSelectorForUsage(TabToOpen, from) {
        console.log('open Universal selector to ', TabToOpen, ' from ', from);
    }

    makeUsageHeaderSelection(headerValues, name) {
        const headerClass =
            (process.env.BUUR_REMOVE_UNIVERSAL_SELECTOR !== 'true')
                ? 'context-header-text' : 'context-header-text no-universal-selector'
        return (<li>
            <span className="context-header-title">{headerValues.label}: </span>
            <span className={headerClass}
                onClick={() => this.openUniversalSelectorForUsage(headerValues.tab, headerValues.type)}>
                {Ellipsis(name)}
                {this.tooptipDisplay(name)}
            </span>
        </li>);
    }

    renderUsageReportsSubwayNav() {
        const displayNames = this.getSelectedUsageReportNames();
        const displayOrder = {
            'district': ['school', 'grade', 'district'],
            'school': ['teacher', 'grade', 'school', 'district'],
            'class': ['class', 'teacher', 'grade', 'school', 'district'],
            'student': ['student', 'class', 'teacher', 'grade', 'school', 'district'],
        };
        let name = '';
        const leveledClassName = `m-0 context_header_${this.props.usageReports.navigationLevel}}`;
        let headerRender = [];
        if (this.props.usageReports.navigationLevel !== null) {
            displayOrder[this.props.usageReports.navigationLevel].forEach((level) => {
                if (process.env.BUUR_HIDE_GRADE_FILTER !== 'true' || level !== 'grade') {
                    name = 'Unknown';
                    if (displayNames[level] !== undefined) {
                        name = displayNames[level];
                    } else if (level === 'grade') {
                        name = (this.props.usageReports.grade.length === 0) ? 'All' : `Custom (${this.props.usageReports.grade.length})`;
                        if (Array.isArray(this.props.usageReports.gradeList)) {
                            name = (this.props.usageReports.grade.length === this.props.usageReports.gradeList.length) ? 'All' : name;
                        }
                        name = (this.props.usageReports.grade.length === 1) ? convertGrade(this.props.usageReports.grade[0]) : name;
                    } else if (level === 'dates') {
                        if (this.props.usageReports.startDate !== null && this.props.usageReports.endDate !== null) {
                            name = `${this.props.usageReports.startDate} - ${this.props.usageReports.endDate}`;
                        } else {
                            name = '-';
                        }
                    }
                    headerRender.push(this.makeUsageHeaderSelection(this.headerTypeValues[level], name));
                }
            });
        }
        return (
          <ul className={leveledClassName}>
              {headerRender}
          </ul>
        );
    }

    render() {
        if (this.props.NavigationByHeaderSelection.usageReport) {
            return this.renderUsageReportsSubwayNav();
        }
        return this.SwitchBasedOnSubwayNav()
    }
}

const mapStateToProps = ({ Authentication, Reports, Universal, DateTabReducer, SummaryReports }) => {
    const { LoginDetails } = Authentication;
    const { StandardPerformance_Overview } = Reports;
    const {
        ContextHeader,
        NavigationByHeaderSelection,
        UniversalSelecter,
        UserScreenWidth,
        isPastDistrictTerm,
        usageReports,
        showContextHeaderDates
    } = Universal;
    const { DateTabComponents } = DateTabReducer;
    return {
        DateTabComponents,
        LoginDetails,
        StandardPerformance_Overview,
        ContextHeader,
        NavigationByHeaderSelection,
        UniversalSelecter,
        UserScreenWidth,
        isPastDistrictTerm,
        SummaryReports,
        usageReports,
        showContextHeaderDates
    };
}

export default connect(mapStateToProps, {
    Open_U_Selector_From_ContextHeader, Get_Class_CSV_Details, SetOptionContextHeader,
    ClickStudentDataInfoIcon, ClickPdTestsInfoIcon, ClickPdDatesInfoIcon,
})(ContextHeader);

/**
 * 
 * @param {string} value  --value to display on context header.
 * @returns {string}  -- if string exceeds certain length ellipsis will be applied. 
 */
function Ellipsis(value) {
    if (value == undefined || value === null || value === "") {
        return value;
    } else if (value.length > 18) {
        return value.slice(0, 18) + "...";
    } else {
        return value;
    }
}

function EllipsisForPopup(value) {
    if (value === undefined || value === null || value === "") {
        return value;
    } else if (value.length > 28) {
        return value.slice(0, 28) + "...";
    } else return value;
}

function EllipsisForTest(value) {
    if (value === undefined || value === null || value === "") {
        return value;
    } else if (value.length > 13) {
        return value.slice(0, 13) + "...";
    } else return value;
}

function convertGrade(grade) {
    if (grade == null || grade == undefined || typeof grade == "object") {
        return "";
    }
    if (grade.toLowerCase() === 'grade_u') {
        return "Unassigned";
    }
    const value = grade.toString();
    const value2 = value.split("_")[1];
    return `${value2}`;
}