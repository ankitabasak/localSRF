import React, { Component } from 'react';
import '../../../../public/css/style.css';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { } from '../../../Redux_Actions/UniversalSelectorActions';
import ContextHeader from './ContextHeader';
import ClassOverviewCSV from '../../ReusableComponents/CSV/ClassOverviewCSV';
import ComparisonReducer from '../../../Redux_Reducers/ComparisonReducer';
import cn from 'classnames';

import { ClickAgpcsvPopup, SaveContextSelection, compareContextSelection, LoadBellNotificationAPI } from '../../../Redux_Actions/UniversalSelectorActions';

import {
  Get_CSV_Details,
  Get_class_grouping_CSV_download,
  schoolCSV_PopUp_enable
} from '../../../Redux_Actions/ReportsActions';
import { payloadParamsFor_Class_StdList_Graph_On_Strands, GetIds_of_Each_Object_In_The_Array, DateFormarFor_APiCalls } from '../../ReusableComponents/AllReusableFunctions';
import Grouping_CSV_Download from '../../class/grouping/Grouping_CSV_Download';
import Std_Perf_CSV_Download from '../../../Utils/CSVDownload/Std_Perf_CSV_Download';
import TestScore_CSV_Download from '../../../Utils/CSVDownload/TestScore_CSV_Download';
import CsvIcon from '../../../../public/images/ic_save.svg';
import School_CSVPopup from '../../../Utils/CSVDownload/CSVPopup/School_CSVPopup'
import Test_Status_CSV_Download from '../../../Utils/CSVDownload/Test_Status_CSV_Download';
import { TEST_STATUS_TAB, AGP_MODELS } from "../../../Utils/globalVars";
import Test_Status_Dist_CSV_Download from '../../../Utils/CSVDownload/Test_Status_Dist_CSV_Download';
import ReportCsvDownload from '../../../Utils/CSVDownload/ReportCsvDownload';
import BellNotification from '../../ReusableComponents/BellNotification';
import Agp_CSVPopup from '../../../Utils/CSVDownload/AGPPopup/Agp_CSVPopup';
import Confirmation_AgpPopup from '../../../Utils/CSVDownload/AGPPopup/Confirmation_AgpPopup';
import Already_DownloadPopup from '../../../Utils/CSVDownload/AGPPopup/Already_DownloadPopup';
import { EnddateValues, StartdateValues } from '../../../Utils/reUsableSnipets';


class SelectionTabFilter extends React.PureComponent {
  constructor(props) {
    super(props);
    // this.GetCSVData = this.GetCSVData.bind(this);
    this.csvOnClickDecission = this.csvOnClickDecission.bind(this); this.handleClickOnContextFor_Std_performance = this.handleClickOnContextFor_Std_performance.bind(this)
    this.handleClickOnContextFor_TestScore = this.handleClickOnContextFor_TestScore.bind(this)
    this.handleClickOnContextFor_SingleTest = this.handleClickOnContextFor_SingleTest.bind(this)
  }

  handleClickOnContextFor_Std_performance(Nav) {
    this.props.SaveContextSelection('S_performance')

    if (Nav.Assessement) {
      let dataExistInStd = false;
      let contextSelected = null;
      let contextTabSelected = null;
      let StandardPeformanceData = null;
      let TestScoreData = null;

      if (Nav.comparison) {

        if (Nav.district) {
          contextSelected = 'district'
          contextTabSelected = 'StandardPerformance'
          StandardPeformanceData = this.props.D_StandardPerformance_Overview
          if (this.props.districtComparison.Std_Comparison.PopupFilter.Strands_And_Standards.Original_List.length !== 0) {
            dataExistInStd = true
          }

        }

        if (Nav.school) {
          contextSelected = 'school'
          contextTabSelected = 'StandardPerformance'
          StandardPeformanceData = this.props.Sc_StandardPerformance_Overview
          if (this.props.schoolComparison.Std_Comparison.PopupFilter.Strands_And_Standards.Original_List.length !== 0) {
            dataExistInStd = true
          }

        }

        if (Nav.class) {
          contextSelected = 'class'
          contextTabSelected = 'StandardPerformance'
          StandardPeformanceData = this.props.StandardPerformance_Overview

          if (this.props.classComparison.Std_Comparison.PopupFilter.Strands_And_Standards.Original_List.length !== 0) {
            dataExistInStd = true
          }

        }

        if (Nav.student) {
          contextSelected = 'student'
          contextTabSelected = 'StandardPerformance'
          StandardPeformanceData = this.props.S_StandardPerformance_Overview

          if (this.props.studentComparison.Std_Comparison.PopupFilter.Strands_And_Standards.Original_List.length !== 0) {
            dataExistInStd = true
          }
        }

      }

      let From_DeepLinking = false

      this.props.SaveContextSelection('Overview')
      dataExistInStd ? null : this.props.compareContextSelection(contextSelected, contextTabSelected, StandardPeformanceData, TestScoreData, From_DeepLinking)
    }
  }

  handleClickOnContextFor_TestScore(Nav) {
    this.props.SaveContextSelection('T_scores')
  }

  handleClickOnContextFor_SingleTest(Nav) {
    this.props.SaveContextSelection('st_analysis')
  }

  /**
   * to download csv file data 
   */

  csvOnClickDecission() {

    let Nav = this.props.NavigationByHeaderSelection;
    let { Roster_Tab, TestTab, Date_Tab } = this.props.ContextHeader;
    let ActualSchoolsList = Roster_Tab.schoolsList;
    let ActualGradesList = Roster_Tab.GradesList;
    let UserRole = this.props.ContextHeader.User_Role;
    let AccessToken = this.props.LoginDetails.JWTToken;
    let Selected_List = TestTab.TestList.filter(item => item.check)
    let SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
    if (SelectedTests == undefined || SelectedTests.length == 0) {
      Selected_List = this.props.UniversalSelecter.TestTab.TestList.filter(item => item.check)
      SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
    }
    let Studentid = "";
    if (Roster_Tab.SelectedStudent != null || undefined) {
      Studentid = Roster_Tab.SelectedStudent.id;
    }

    let Roster_data = Roster_Tab;
    let grade = Roster_data.selectedRosterGrade
    // end of Param Accessing
    // Delete after Use case
    let factor_decide = '';
    // end  of delte code

    if (Nav.Assessement && Nav.S_performance && Nav.class && Nav.grouping) {

      this.props.Get_class_grouping_CSV_download();

    } else if ((UserRole != "TEACHER" || UserRole != "PRIMARY_TEACHER") && (Nav.school) && (ActualSchoolsList.length > 1 || ActualGradesList.length > 1)) {

      let status_flag = this.props.CSVDownload.popupStatus

      this.props.schoolCSV_PopUp_enable(status_flag)

    } else {
      let currentTermId = this.props.currentTermID;


      let classId = Roster_Tab.SelectedClass.id;
      let startDate = Date_Tab.Report_termStartDate;
      let endDate = Date_Tab.Report_termEndDate;
      let districtId = Roster_data.SelectedDistrict.id;
      let schoolId = Roster_Tab.SelectedSchool.id;
      let studentId = Roster_Tab.SelectedStudent.id;
      let rosterGrade = Roster_Tab.selectedRosterGrade;
      const { UniversalSelecter } = this.props;
      const { Context_DateTab } = this.props.DateTabReducer;
      
      if (classId == undefined) {
          classId = UniversalSelecter.Roster_Data.SelectedClass == "All"?UniversalSelecter.Roster_Data.ClassList[0] && UniversalSelecter.Roster_Data.ClassList[0].id:UniversalSelecter.Roster_Data.SelectedClass.id;
      }
      if (startDate == undefined || startDate == "") {
          startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
          endDate = EnddateValues(Context_DateTab);
      }
      if (districtId == undefined) {
          districtId = this.props.ContextHeader.Default_districtID;
      }
      if (schoolId == undefined) {
          schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      if (studentId == undefined) {
          studentId = UniversalSelecter.Roster_Data.SelectedStudent.id;
      }
      if (rosterGrade == undefined) {
          rosterGrade = Roster_Tab.GradesList[0].grade;
        }


      // Direct Download will goes here...
      let ReqPayload = {
        "districtId": districtId,
        "schoolId": schoolId,
        "classId": classId,
        "classIds": Roster_data.ClassIds,
        "studentIds": Roster_data.StudentIds,
        "studentId": Studentid,
        "districtName": Roster_data.SelectedDistrict.name,
        "teacherName": Roster_data.SelectedTeacher.name,
        "schoolName": Roster_data.SelectedSchool.name,
        "className": Roster_data.SelectedClass.name,
        "startDate": startDate,
        "endDate": endDate,
        "rosterGrade": rosterGrade,
        "grade": grade != null ? grade : null,
        "componentCodeList": SelectedTests,
        "ids": null,
        "context": null,
        "testStatus": "ALL",
        "termId": Date_Tab.selectedTermId,
        "isPastDistrictTerm": Date_Tab.isPastDistrictTerm,
        "currentTermId": currentTermId // datetab api response first alpha term_id

      };

      if (Nav.class || Nav.student) {
        delete ReqPayload.classIds
      }
      if (Nav.student) {
        delete ReqPayload.studentIds
      }

      if (Nav.test_status) {

        let Date_TS_Cont = this.props.DateTabReducer.Context_DateTab_TestStatus

        let StartDate = Date_TS_Cont.StartDateInDateTab;
        let EndDate = Date_TS_Cont.EndDateInDateTab;

        StartDate = StartDate == '' ?
          Date_TS_Cont.SelectedDistrictTerm.termStartDate :
          StartDate;

        EndDate = EndDate == '' ?
          Date_TS_Cont.SelectedDistrictTerm.termEndDate :
          EndDate;

        let Resp = DateFormarFor_APiCalls(StartDate, EndDate);
        ReqPayload.startDate = Resp.StartDate;
        ReqPayload.endDate = Resp.EndDate;

        // test Status related updated based on context here
        let selectedIds;
        let selectedContext

        if (Nav.student) {
          selectedIds = Roster_data.SelectedStudent.id == undefined ? "" : [Roster_data.SelectedStudent.id];
          selectedContext = "student";

          //delete ReqPayload.districtId
          //delete ReqPayload.schoolId
        } else if (Nav.class) {
          selectedIds = Roster_data.StudentIds;
          selectedContext = "student";
          //  delete ReqPayload.districtId
          //  delete ReqPayload.schoolId
        } else if (Nav.school) {
          selectedIds = Roster_data.ClassIds;
          selectedContext = "school";
          delete ReqPayload.districtId
        } else {
          selectedIds = Roster_data.SchoolIds;
          selectedContext = "school"
        }

        ReqPayload.termId = Date_TS_Cont.SelectedDistrictTerm.termId
        ReqPayload.ids = selectedIds
        ReqPayload.context = selectedContext
        delete ReqPayload.classIds
        delete ReqPayload.studentIds
        delete ReqPayload.standardIds
      }

      this.props.Get_CSV_Details(AccessToken, ReqPayload, Nav)

    }

  }

  conditionalDisplay_of_Icon(ContextSelected, Nav) {

    let finalReturn = false

    if (ContextSelected.reportDataCSV_loader || ContextSelected.testStatusContext_loader) {
      finalReturn = true
    }
    return finalReturn
  }

  render() {
    let Nav = this.props.NavigationByHeaderSelection;
    const { ContextHeader, CSVDownload, GroupPage } = this.props;
    const TriggerGroupingCSVDownload = this.props.GroupingCSVDownload.enableCSVDownload;
    const PastDistrictTermFlag = this.props.isPastDistrictTerm;
    const { ContextSelected } = CSVDownload

    let currentTermId = this.props.currentTermID;
    let StartDate = ContextHeader.Date_Tab.Report_termStartDate;
    let EndDate = ContextHeader.Date_Tab.Report_termEndDate;
    let schoolId = ContextHeader.Roster_Tab.SelectedSchool.id == undefined ? "" : ContextHeader.Roster_Tab.SelectedSchool.id;
    let SelectedGrade = (this.props.AgpCSV.selectedGrade == "Current Selection" || this.props.AgpCSV.selectedGrade == "") ? ContextHeader.Roster_Tab.selectedRosterGrade : this.props.AgpCSV.selectedGrade;
    let RequestObj = {
      "districtId": `${ContextHeader.DistrictId}`,
      "schoolId": Nav.district ? "" : schoolId,
      "rosterGrade": SelectedGrade,
      "termId": currentTermId,
      "startDate": StartDate,
      "endDate": EndDate,
      "context": Nav.district ? "district" : "school",
      "isTestStatusEnable":  Nav.district && Nav.test_status?true:false
    }

    return (
      <div className="container-fluid m-0 float-left secondLevel-page-selectors">

        {TriggerGroupingCSVDownload ?
          <Grouping_CSV_Download TriggerGroupingCSVDownload={TriggerGroupingCSVDownload} GroupPageData={GroupPage} />
          : null}

        {ContextSelected.TriggerDownloadCsv ?
          ContextSelected.reportDataCSV ?
            <ReportCsvDownload CSVDownload={CSVDownload} /> : null
          : null
        }

        {ContextSelected.TriggerDownloadCsv ?
          ContextSelected.testStatus ?
            !Nav.district ?
              <Test_Status_CSV_Download Nav={Nav} /> :
              <Test_Status_Dist_CSV_Download Nav={Nav} />
            : null
          : null
        }

        {/* {
          this.props.CSVDownload.popupStatus ? <School_CSVPopup CSVTriggerStatus={this.conditionalDisplay_of_Icon(ContextSelected, Nav)} GradeList={this.props.ContextHeader.Roster_Tab.GradesList} SchoolList={this.props.ContextHeader.Roster_Tab.schoolsList} DefaultSchool={this.props.ContextHeader.Roster_Tab.SelectedSchool} /> : null
        } */}

        <div className="secondLevel-page-selectors_overview_block">
          <div className="row secondLevel-page-selectors_overview_inr float-left text-center">
            <ul className="p-0 mx-auto">
              <li onClick={() =>
                Nav.S_performance
                  ? null
                  : this.handleClickOnContextFor_Std_performance(this.props.NavigationByHeaderSelection)
              }
                className={Nav.S_performance ? "active_tab" : "inactive_tab"}
              >
                Standards Performance
                            </li>

              <li onClick={() =>
                Nav.T_scores
                  ? null
                  : this.handleClickOnContextFor_TestScore(this.props.NavigationByHeaderSelection)
              }
                className={Nav.T_scores ? "active_tab" : "inactive_tab"}>
                Test Scores
                            </li>

              {(Nav.class || Nav.student || Nav.school || Nav.district) ? <li onClick={() =>
                Nav.st_analysis
                  ? null
                  : this.handleClickOnContextFor_SingleTest(this.props.NavigationByHeaderSelection)
              }
                className={Nav.st_analysis ? "active_tab" : "inactive_tab"}>
                Single Test Analysis
              </li> : null}

              {((TEST_STATUS_TAB === "true") && (Nav.Assessement)) ? <li onClick={() => {
                PastDistrictTermFlag ? null : (Nav.test_status
                  ? null
                  : this.props.SaveContextSelection('test_status')
                )
              }}
                className={PastDistrictTermFlag ? "past_district_term_tooltip teststatustab_bgcolor" : (Nav.test_status ? "active_tab" : "inactive_tab")}>
                <span className={PastDistrictTermFlag ? "past_district_term_test_status_inactive" : ""}>Test Status </span>
                {PastDistrictTermFlag ? <div className="teststatus_tooltipmain"><div className="ts_tooltip_arrow"></div><div className="ts_tooltiptext">Test Status reports are not available for past district terms.</div></div> : null}
              </li> : null}

              { AGP_MODELS && (Nav.district || Nav.school) ? (Nav.school && Nav.test_status && ContextSelected.testStatus && ContextSelected.testStatusContext_loader?<div className="download_csv"><span className="csv_download_icon">
                      <i className="material-icons">autorenew</i>
                    </span></div>:<div><div className="download_csv">
                <span className="csv_download_icon" onClick={() => {
                  this.props.ClickAgpcsvPopup(true, RequestObj, this.props.LoginDetails.JWTToken, this.props.AgpCSV.student_grade_api);

                }}>
                    <div className="ar_summary-csv-file-infoicon">
                      <div className="ar_summary-csv-file-infoicon-inr" >
                        <div className="ar_summary-csv-file-infoicon-inr-text">Download CSV File</div>
                      </div>
                    </div>
                  <img src={CsvIcon} width="20" height="20" />

                </span>

              </div>
              
              </div>) : null}
              {AGP_MODELS && (Nav.district || Nav.school) && this.props.AgpCSV.csvpopup ? <Agp_CSVPopup /> : null}
              {AGP_MODELS && this.props.AgpCSV.popupConfirmation ? <Confirmation_AgpPopup switchDownloadsSuccess={this.props.switchDownloadsSuccess} /> : null}
              {this.props.AgpCSV.download_already_requested ? <Already_DownloadPopup /> : null}
              {/* {(Nav.school && Nav.test_status && AGP_MODELS) ?
                <div className="download_csv">

                  {this.conditionalDisplay_of_Icon(ContextSelected, Nav) ?
                    <span className="csv_download_icon">
                      <i className="material-icons">autorenew</i>
                    </span>
                    : <span className="csv_download_icon" onClick={() => {
                      this.csvOnClickDecission()

                    }}>

                      <div className="ar_summary-csv-file-infoicon">
                        <div className="ar_summary-csv-file-infoicon-inr" >
                          <div className="ar_summary-csv-file-infoicon-inr-text">Download CSV File</div>
                        </div>
                      </div>

                      <img src={CsvIcon} width="20" height="20" />
                    </span>}

                </div> : null} */}
              {/* we need to put this condition again when district test status csv needed =>(Nav.district && !(Nav.test_status && (!Nav.comparison || !Nav.grouping || !Nav.summary))) || Nav.st_analysis */}
              {(AGP_MODELS == false && Nav.school) || (Nav.class || Nav.student) ? ((Nav.district && !((Nav.test_status && !Nav.district) && (!Nav.comparison || !Nav.grouping || !Nav.summary))) || Nav.st_analysis ? null : <div className="download_csv">

                {this.conditionalDisplay_of_Icon(ContextSelected, Nav) ?
                  <span className="csv_download_icon">
                    <i className="material-icons">autorenew</i>
                  </span>
                  : <span className="csv_download_icon" onClick={() => {
                    this.csvOnClickDecission()

                  }}>

                    <div className="ar_summary-csv-file-infoicon">
                      <div className="ar_summary-csv-file-infoicon-inr" >
                        <div className="ar_summary-csv-file-infoicon-inr-text">Download CSV File</div>
                      </div>
                    </div>

                    <img src={CsvIcon} width="20" height="20" />
                  </span>}

              </div>) : null}

            </ul>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ Authentication, Universal, StudentReports, ClassGroupingReducer, Reports, schoolReducer, DistrictReducer, ComparisonReducer, TestStatusReducer, DateTabReducer }) => {
  const { LoginDetails } = Authentication;
  const { S_StandardPerformance_Overview, S_Test_Scores_OverView } = StudentReports;
  const { AgpCSV, isPastDistrictTerm, NavigationByHeaderSelection, UniversalSelecter, ContextHeader, UniversalFilter, ApiCalls, currentTermID } = Universal;
  const { StandardPerformance_Overview, CSVDownload, Test_Scores_OverView } = Reports;
  const { Sc_StandardPerformance_Overview, Sc_Test_Scores_OverView } = schoolReducer;
  const { D_StandardPerformance_Overview, D_Test_Scores_OverView } = DistrictReducer;
  const { GroupingCSVDownload, GroupPage } = ClassGroupingReducer;
  const { Student, Class, School, District } = TestStatusReducer;
  const { studentComparison, classComparison, schoolComparison, districtComparison } = ComparisonReducer

  return {
    AgpCSV, isPastDistrictTerm, NavigationByHeaderSelection, UniversalSelecter, ContextHeader, UniversalFilter, StandardPerformance_Overview, S_StandardPerformance_Overview, LoginDetails, CSVDownload,
    Sc_StandardPerformance_Overview, D_StandardPerformance_Overview, GroupingCSVDownload, GroupPage,
    S_Test_Scores_OverView, Test_Scores_OverView, Sc_Test_Scores_OverView, D_Test_Scores_OverView, ApiCalls,
    studentComparison, classComparison, schoolComparison, districtComparison, TestStatusReducer, DateTabReducer, Student, Class, School, District, currentTermID
  };
};

export default withRouter(
  connect(mapStateToProps, {
    SaveContextSelection, LoadBellNotificationAPI, Get_CSV_Details, Get_class_grouping_CSV_download, schoolCSV_PopUp_enable, compareContextSelection, ClickAgpcsvPopup,
  })(SelectionTabFilter)
);
