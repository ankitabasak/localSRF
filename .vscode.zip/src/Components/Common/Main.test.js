test('the best flavor is grapefruit', () => {
    let SampleJest = 'grapefruit'
    expect(SampleJest).toBe('grapefruit');
});


test('Sample 2 ', () => {
    expect(true).toBeTruthy;
});