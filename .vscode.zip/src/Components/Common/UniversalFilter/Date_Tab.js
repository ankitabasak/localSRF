import React, { Component } from 'react';
import '../../../../public/css/style.css';
import { connect } from 'react-redux';
import PaginationComponent from '../../../Utils/UniversalSelector_Pagination';
import {
     OpenSelectorInDateTab, OpenDateRangeInDateTab, OpenDatePickerInDateTab, SaveSelected_Date,
    SaveSelected_Range, ApplyFilterInDate_Tab, StoreSelectedValuesInDateTab,
    OpenOrCLoseMonthsListInDateTabCalendar, ChangeMonthINDateTab_Calendar
    // ChangeTestTabPagination
} from '../../../Redux_Actions/UniversalSelectorActions';

import {CloseUniversalFilter} from '../../../Redux_Actions/UniversalSelectorActions_Secondary'

import DateIcon from '../../../../public/images/ic_date_unselected.svg';

import DatePicker from '../../../Utils/DatePicker/DatePicker';
import { DateFormatForCalendar_inDateTab } from '../../ReusableComponents/AllReusableFunctions';
import { formatSingle } from 'highcharts';
import { getMonthName } from '../../../Utils/DatePicker/helpers';
import { newDateHandling } from '../../ReusableComponents/AllReusableFunctions_Two';

class TestTab extends React.PureComponent {
    constructor(props) {
        super(props);
        this.handleDayClick = this.handleDayClick.bind(this);
        this.handleMonthClick = this.handleMonthClick.bind(this);
        this.openMonthsList = this.openMonthsList.bind(this);
        this.state = {
            selectedDateCal: new Date(),
            month: '',
            year: '',
            selectDate: '',
        }
    }

    /**
     * 
     * @param {Object} Date_Prop 
     * it will return date range list based on available dates.
     */
    DateRangeList(Date_Prop) {

        return <ul>
            {Date_Prop.days_30 ? <li key="Last 30 Days" value="Last 30 Days"
                className={selected_li_of_date_ange(Date_Prop, "Last 30 Days") ? "selected-li-in-datetab" : ""}
                onClick={(txt) => {
                    this.props.SaveSelected_Range("Last 30 Days")
                }}>
                Last 30 Days
            </li> : null
            }
            {
                Date_Prop.days_60 ? <li key="Last 60 Days" value="Last 60 Days"
                    className={selected_li_of_date_ange(Date_Prop, "Last 60 Days") ? "selected-li-in-datetab" : ""}
                    onClick={(txt) => {
                        this.props.SaveSelected_Range("Last 60 Days")
                    }}>
                    Last 60 Days
            </li> : null
            }
            {
                Date_Prop.days_90 ? <li key="Last 90 Days" value="Last 90 Days"
                    className={selected_li_of_date_ange(Date_Prop, "Last 90 Days") ? "selected-li-in-datetab" : ""}
                    onClick={(txt) => {
                        this.props.SaveSelected_Range("Last 90 Days")
                    }}>
                    Last 90 Days
            </li> : null
            }
            <li key="District Term To Date" value="District Term To Date"
                className={selected_li_of_date_ange(Date_Prop, "District Term To Date") ? "selected-li-in-datetab" : ""}
                onClick={(txt) => {
                    this.props.SaveSelected_Range("District Term To Date")
                }}>
                District Term To Date
            </li>

            {Date_Prop.display_custom_daterange ? <li key="Custom Date Range" value="Custom Date Range"
                className={selected_li_of_date_ange(Date_Prop, "Custom Date Range") ? "selected-li-in-datetab" : ""}
                onClick={(txt) => {
                    this.props.SaveSelected_Range("Custom Date Range")
                }}>
                Custom Date Range
            </li> : null}
        </ul >
    }
    DateTab() {
        const { selectedDateCal } = this.state;
        let Date_Prop = this.props.UniversalSelecter.Date;
        let Loading = this.props.ApiCalls.loadingFor;

        return <div className="datetabContainer">
            {/* district term */}
            <div className="universal-input-field">
                <div className="menu-title">
                    District Term
                    <span className="data-refresh">
                        {Loading == "datetab" ?
                            <i className="material-icons">autorenew</i>
                            : null}

                    </span>
                </div>
                <div className={Date_Prop.OpenDateDropDown ?
                    "menu-selector active-selector" : "menu-selector"} >
                    <button
                        onClick={() => Date_Prop.Count_of_Years_has_reportData > 1 ?
                            this.props.OpenSelectorInDateTab() : null}
                        className={Date_Prop.Count_of_Years_has_reportData > 1 ?
                            "select-dropdown" : "district-term-cannot-open"}>
                        {Date_Prop.selected_term === "" ? "Select Date" : Date_Prop.selected_term}
                    </button>
                    <div className="menu-dropdown-container">
                        <div className="menu-dropdown-list">
                            <div className="menu-dropdown-list-inr">
                                <ul>
                                    <li key={Date_Prop.selected_term} value={Date_Prop.selected_term}
                                        class={"selected-li-in-datetab"}
                                    // onClick={(txt) => {
                                    //     this.props.SaveSelected_Date(item.termRange)
                                    // }}
                                    >
                                        {Date_Prop.selected_term}
                                    </li>
                                    {Date_Prop.DistrictTerms.map((item, i) => {
                                        if (item.termDates !== null && item.termRange !== Date_Prop.selected_term) {
                                            return <li key={i} value={item.termRange}
                                                class={Date_Prop.selected_term == item.termRange ? "selected-li-in-datetab" : ""}
                                                onClick={(txt) => {
                                                    this.props.SaveSelected_Date(item.termRange)
                                                }}>
                                                {item.termName}
                                            </li>
                                        }
                                    })}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* varied dates */}
            <div className="universal-input-field">
                <div className="menu-title">
                    Date Range
                    <span className="data-refresh">

                        {Loading == "datetab" ?

                            <i className="material-icons">autorenew</i>

                            : null}
                    </span>
                </div>
                <div className={Date_Prop.OpenDateRange ?
                    "menu-selector active-selector" : "menu-selector"} >
                    <button
                        onClick={() => this.props.OpenDateRangeInDateTab()}
                        className="select-dropdown">

                        {Date_Prop.SelectedRange === undefined ? "District Term To Date" : Date_Prop.SelectedRange}
                    </button>
                    <div className="menu-dropdown-container">
                        <div className="menu-dropdown-list">
                            <div className="menu-dropdown-list-inr">
                                {this.DateRangeList(Date_Prop)}

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* custom dates */}
            {Date_Prop.SelectedRange === "Custom Date Range" ?
                <div className="universal-input-field">
                    <div className="Date_tab">
                        <div style={{ float: 'left', width: '100%' }}>
                            <div className="menu-title" style={{ width: '50%' }}>
                                Start Date
                    </div>
                            <div className="menu-title" style={{ width: '50%', paddingLeft: '7px' }}>
                                End Date
                    </div>
                        </div>

                        <div className="DateWeekCalender">
                            <div
                                className={Date_Prop.active_calendar_for == 'startdate' ?
                                    "date-selector activeCalendar" : "date-selector"}
                                style={{ float: 'left', borderBottom: Date_Prop.active_calendar_for == 'startdate' ? '1px solid #00539B' : null }}  >
                                <button onClick={() => {
                                    let selected = Date_Prop.active_calendar_for == 'startdate' ? '' : 'startdate'
                                    this.props.OpenDatePickerInDateTab(selected)
                                }}>
                                    {Date_Prop.selected_term === undefined ||
                                        Date_Prop.selected_term === "" ? this.returnStartDate(Date_Prop) : this.returnStartDate(Date_Prop)}
                                </button>
                            </div>

                            <div className={Date_Prop.active_calendar_for == 'enddate' ?
                                "date-selector activeCalendar" : "date-selector"} style={{ float: 'right', borderBottom: Date_Prop.active_calendar_for == 'enddate' ? '1px solid #00539B' : null }}>
                                <button onClick={() => {
                                    let selected = Date_Prop.active_calendar_for == 'enddate' ? '' : 'enddate';
                                    this.props.OpenDatePickerInDateTab(selected);
                                }}>
                                    {Date_Prop.selected_term === undefined ||
                                        Date_Prop.selected_term === "" ? this.returnEndDate(Date_Prop) : this.returnEndDate(Date_Prop)}
                                </button>
                            </div>
                        </div>
                        {Date_Prop.active_calendar_for !== "" && this.props.UniversalFilter == "date" ? this.callCalendar(Date_Prop) : null}
                        <div className="dateBottomTitleText">Date Range: {parseInt(Date_Prop.daterangeDiff)} Days</div>
                    </div>
                </div> : null}

        </div>
    }

    returnStartDate(Date_Prop) {

        // return Date_Prop.Calendar.start_date_to_show_in_calendar;
        return Date_Prop.Custom_startDate;

    }

    returnEndDate(Date_Prop) {

        // return Date_Prop.Calendar.end_date_to_show_in_calendar;
        return Date_Prop.Custom_endDate;
    }

    callCalendar(Date_Prop) {

        let DateToCAllCalendar =
            Date_Prop.active_calendar_for == 'startdate' ?
                Date_Prop.Calendar.start_date_to_show_in_calendar :
                Date_Prop.Calendar.end_date_to_show_in_calendar;

        let selected_Term_Dates = Date_Prop.selected_Term_Dates;

        let DisabledDays = Date_Prop.Calendar.DisabledDates_InCalendar;
        let ReportStartMonthName = this.props.ContextHeader.Date_Tab.ReportStart_MonthName;
        let ReportEndMonthName = this.props.ContextHeader.Date_Tab.ReportEnd_MonthName


        return <DatePicker fullDate={newDateHandling(DateToCAllCalendar)}
            Date_Prop={Date_Prop}
            openMonthsList={this.openMonthsList}
            DisabledDays={DisabledDays}
            ReportStartMonthName={ReportStartMonthName}
            ReportEndMonthName={ReportEndMonthName}
            selected_Term_Dates={selected_Term_Dates}
            onDayClick={this.handleDayClick}
            onMonthClick={this.handleMonthClick}
        />
    }

    /**
    * 
    * @param {*} newDate
    *  Change state on date selection.
    */

    handleDayClick(newDay) {

        const { selectedDateCal } = this.state;

        let Date_Prop = this.props.UniversalSelecter.Date;

        let calendarFor = Date_Prop.active_calendar_for;
        // let Current_selectedDate = calendarFor == "startdate" ? Date_Prop.Calendar.start_date_to_show_in_calendar :
        //     Date_Prop.Calendar.end_date_to_show_in_calendar;


        let response = getMonthNameNumber(Date_Prop)

        // let Current_selectedDate_Arr = Current_selectedDate.split("/");

        let selectedDate = response.Month + "/" + newDay + "/" +
            response.Year;

        // let Fullyear = new Date(Current_selectedDate).getFullYear();
        // let Month = new Date(Current_selectedDate).getMonth() + 1;

        // let selectedDate = Month + '/' + newDay + '/' + Fullyear

        this.props.StoreSelectedValuesInDateTab(selectedDate, calendarFor)
    }


    /**
     * 
     * @param {*} newMonth
     *  Change state on month selection.
     */
    handleMonthClick(newMonth) {

        // const { selectedDateCal } = this.state;
        // let SelectedMonth = newMonth == 'toPreviousMonth' ?
        //     selectedDateCal.getMonth() - 1 : selectedDateCal.getMonth() + 1

        // this.setState({
        //     selectedDateCal: new Date(
        //         selectedDateCal.getFullYear(),
        //         SelectedMonth
        //     ),
        // })

        let Date_Prop = this.props.UniversalSelecter.Date;
        let DateToCAllCalendar =
            Date_Prop.active_calendar_for == 'startdate' ?
                Date_Prop.Calendar.start_date_to_show_in_calendar :
                Date_Prop.Calendar.end_date_to_show_in_calendar;

        let SelectedDate = converselectedMonthtoDateFormat(newMonth, DateToCAllCalendar, Date_Prop);

        this.props.ChangeMonthINDateTab_Calendar(newMonth, SelectedDate.DateToCAllCalendar, SelectedDate.newMonth);

    }

    /**
     * 
     * @param {String} openorclose 
     * when open or close months list in calender will change prop in reducer
     */
    openMonthsList(openorclose) {

        this.props.OpenOrCLoseMonthsListInDateTabCalendar(openorclose);

    }

    render() {
        let Date_Props = this.props.UniversalSelecter.Date;
        let Context_props = this.props.ContextHeader.Date_Tab
        return <div className="menu-item-expand-block">
            <div className="menu-item-expand-block-inr dateTabBlockContainer">
                {this.DateTab()}
                <div className="universal-select-filter">
                    <div className="apply-btn float-right">
                        <button
                            disabled={DisableDateTabApplyButton(Date_Props, Context_props)}
                            onClick={() => this.props.ApplyFilterInDate_Tab()}

                            className={DisableDateTabApplyButton(Date_Props, Context_props) ?
                                "universal-selector-applyfilter disableFilter_us" : "universal-selector-applyfilter"}>Apply</button></div>
                    <div className="cancel-btn float-right"
                        onClick={() => this.props.CloseUniversalFilter()}
                    >Cancel</div>
                </div>
            </div>
        </div>
    }
}
const mapStateToProps = ({ Universal }) => {
    const { UniversalSelecter, ApiCalls, ContextHeader, UniversalFilter, usageReports } = Universal;
    return { UniversalSelecter, ApiCalls, ContextHeader, UniversalFilter, usageReports }
}

export default connect(mapStateToProps, {
    CloseUniversalFilter, OpenSelectorInDateTab, OpenDateRangeInDateTab,
    OpenDatePickerInDateTab, SaveSelected_Date, SaveSelected_Range, ApplyFilterInDate_Tab,
    StoreSelectedValuesInDateTab,
    OpenOrCLoseMonthsListInDateTabCalendar,
    ChangeMonthINDateTab_Calendar
})(TestTab);

/**
 * 
 * @param {Object} Date_Prop 
 * @param {String} from 
 * @returns {Boolean}
 */
function selected_li_of_date_ange(Date_Prop, from) {
    return Date_Prop.SelectedRange == from;
}


/**
 * 
 * @param {String} newMonth 
 * @param {String} DateToCAllCalendar 
 * @returns {String}
 */
function converselectedMonthtoDateFormat(newMonth, DateToCAllCalendar, Date_Prop) {

    let Selectedoption = newMonth;

    let CurrentMonth = Date_Prop.active_calendar_for == "startdate" ? Date_Prop.Calendar.selectedStartDateMonth : Date_Prop.Calendar.selectedEndMonth
    if (newMonth == "toNextMonth" || newMonth == "toPreviousMonth") {

        let IndexOfCuttentMonth = Date_Prop.Calendar.reportsforthisMonths.indexOf(CurrentMonth);

        let index = newMonth == "toNextMonth" ? IndexOfCuttentMonth + 1 : IndexOfCuttentMonth - 1;

        newMonth = Date_Prop.Calendar.reportsforthisMonths[index]

    } else {

    }

    let monthName = newMonth.split(" ");



    switch (monthName[0]) {

        case "JAN":
            DateToCAllCalendar = returnDate('01', DateToCAllCalendar, monthName[1]);

            break;
        case "FEB":
            DateToCAllCalendar = returnDate('02', DateToCAllCalendar, monthName[1]);
            break;
        case "MAR":
            DateToCAllCalendar = returnDate('03', DateToCAllCalendar, monthName[1]);
            break;
        case "APR":
            DateToCAllCalendar = returnDate('04', DateToCAllCalendar, monthName[1]);
            break;
        case "MAY":
            DateToCAllCalendar = returnDate('05', DateToCAllCalendar, monthName[1]);
            break;
        case "JUN":
            DateToCAllCalendar = returnDate('06', DateToCAllCalendar, monthName[1]);
            break;
        case "JUL":
            DateToCAllCalendar = returnDate('07', DateToCAllCalendar, monthName[1]);
            break;
        case "AUG":
            DateToCAllCalendar = returnDate('08', DateToCAllCalendar, monthName[1]);
            break;
        case "SEP":
            DateToCAllCalendar = returnDate('09', DateToCAllCalendar, monthName[1]);
            break;
        case "OCT":


            DateToCAllCalendar = returnDate('10', DateToCAllCalendar, monthName[1]);


            break;
        case "NOV":
            DateToCAllCalendar = returnDate('11', DateToCAllCalendar, monthName[1]);
            break;
        case "DEC":
            DateToCAllCalendar = returnDate('12', DateToCAllCalendar, monthName[1]);
            break;

        default:
            break;

    }

    /**
   * 
   * @param {BigInteger} SelectedMonthNumber 
   * @param {String} DateToCAllCalendar 
   */
    function returnDate(SelectedMonthNumber, DateToCAllCalendar, monthYear) { // displayName() is the inner function, a closure
        // alert(name); // use variable declared in the parent function


        let DAteArray = DateToCAllCalendar.split("/");

        let DateToReturn = SelectedMonthNumber + "/" + DAteArray[1] + "/" + monthYear;

        return DateToReturn;
    }

    return { DateToCAllCalendar, newMonth };

}


function DisableDateTabApplyButton(Date_Props, Context_props) {


    if (Date_Props.selected_term == Context_props.selected_District_term &&
        Date_Props.SelectedRange == Context_props.dateRange) {


        if (Date_Props.Calendar.start_date_to_show_in_calendar == Context_props.CustomStartDate &&
            Date_Props.Calendar.end_date_to_show_in_calendar == Context_props.CustomEndDate) {
            return true;
        } else return false;

    } else return false;

}


function getMonthNameNumber(Date_Prop) {


    let MonthName = Date_Prop.active_calendar_for == "enddate" ? Date_Prop.Calendar.selectedEndMonth.split(" ")[0] :
        Date_Prop.Calendar.selectedStartDateMonth.split(" ")[0];

    let Year = Date_Prop.active_calendar_for == "enddate" ? Date_Prop.Calendar.selectedEndMonth.split(" ")[1] :
        Date_Prop.Calendar.selectedStartDateMonth.split(" ")[1];

    let Month = '00';

    switch (MonthName) {

        case "JAN":

            Month = '01'

            return { Month, Year };

            break;
        case "FEB":

            Month = '02';
            return { Month, Year };
            break;
        case "MAR":

            Month = '03';
            return { Month, Year };
            break;
        case "APR":

            Month = '04';
            return { Month, Year };
            break;
        case "MAY":

            Month = '05';
            return { Month, Year };
            break;
        case "JUN":

            Month = '06';
            return { Month, Year };
            break;
        case "JUL":

            Month = '07';
            return { Month, Year };
            break;
        case "AUG":

            Month = '08';
            return { Month, Year };
            break;
        case "SEP":

            Month = '09';
            return { Month, Year };
            break;
        case "OCT":

            Month = '10';
            return { Month, Year };

            break;
        case "NOV":
            Month = '11';
            return { Month, Year };
            break;
        case "DEC":
            Month = '12';
            return { Month, Year };
            break;

        default:
            break;

    }

}