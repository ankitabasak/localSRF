import React, { Component } from 'react';
import '../../../../public/css/style.css';
import { connect } from 'react-redux';
import { CheckOrUncheckProductCheckBox, ApplyFiltersInProductTab, OpenOrCloseProductTypes } from '../../../Redux_Actions/UniversalSelectorActions';


import {CloseUniversalFilter} from '../../../Redux_Actions/UniversalSelectorActions_Secondary'

class Product extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            checkvalue: undefined,
            allcheck: undefined

        }
    }



    checkoruncheck(product, selectAllTests, selectedTestList) {
        if (selectAllTests == true) {
            return true;
        }
        for (let i = 0; i < selectedTestList.length; i++) {
            if (selectedTestList[i].productId == product.productId) {
                return true;
            }
        }
        return false;
    }

    render() {
        let TestsOfPresentClass = this.props.ContextHeader.Tests_of_PresentClass;
        let uniqueItems = UniqueProducts(TestsOfPresentClass, this.state);
        let universalSelector = this.props.UniversalSelecter;
        let selectAllTests;
        let selectedTestList;
        if (universalSelector !== undefined || null) {
            selectAllTests = universalSelector.TestTab.selectAllTests;
            selectedTestList = this.props.UniversalSelecter.TestTab.SelectedTestList;
        }
        return <div className="menu-item-expand-block">
            <div className="menu-item-expand-block-inr">
                <div className="productTab-dropdown-list">
                    <div className="productTab-dropdown-list-inr">
                        <div className="productUniverselSelectorList">
                            <ul>
                                <li value="All" onClick={() => {
                                            let i = 'All';
                                            let Check = selectAllTests;
                                            Check = !selectAllTests;
                                            // Check Values Based On CUrrent CheckBox Value
                                            this.props.CheckOrUncheckProductCheckBox(Check, i)
                                        }}>
                                    <div className="productsingleitem">
                                        <div className="input-checkbox checkbox-lightBlue">
                                            <input
                                                checked={this.checkoruncheck("all", selectAllTests, selectedTestList)}
                                                value="true"
                                                type="checkbox" />
                                            <span className="checkbox"></span>
                                        </div>
                                        <span></span>
                                    </div>
                                    All
                            </li>
                                {uniqueItems.map((product, index) => (

                                    <li value="benchmarkadvance" onClick={() => {
                                        let Check = product.check === undefined || "" ? true : !product.check;
                                        this.setState({
                                            checkvalue: Check
                                        })
                                        let SelectedElement = uniqueItems[index];
                                        this.props.CheckOrUncheckProductCheckBox(Check, SelectedElement)
                                    }}>
                                        <div className="productsingleitem">
                                            <div key={index} className="input-checkbox checkbox-lightBlue">
                                                <input
                                                    checked={this.checkoruncheck(product, selectAllTests, selectedTestList)}
                                                    value={product.check}
                                                    type="checkbox" />
                                                <span className="checkbox"></span>
                                            </div>
                                            <span></span>
                                        </div>
                                        {product.productName}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="universal-select-filter">
                    <div class="cancel-btn float-left"
                        onClick={() => this.props.CloseUniversalFilter()}>Cancel</div>
                    <div class="apply-btn float-right">
                        <button class="universal-selector-applyfilter"
                            onClick={() => this.props.ApplyFiltersInProductTab(this.props.UniversalSelecter.TestTab.TestList)}>Apply</button>
                    </div>
                </div>

            </div>
        </div>
    }

}

const mapStateToProps = ({ Universal }) => {
    const { ContextHeader, UniversalSelecter } = Universal;
    return {
        ContextHeader, UniversalSelecter
    };
}

export default connect(mapStateToProps, {
    // Add Action Here 
    CheckOrUncheckProductCheckBox, ApplyFiltersInProductTab,
    OpenOrCloseProductTypes, CloseUniversalFilter
})(Product);

/**
 * 
 * @param {Array} TestsOfPresentClass 
 * @param {Object} state
 * it will return unique 
 *  
 */

export function UniqueProducts(TestsOfPresentClass, state) {

    if (state == undefined) {
        state = { checkvalue: true };
    }

    let a = [];
    for (let i = 0; i < TestsOfPresentClass.length; i++) {
        let productId = TestsOfPresentClass[i].productId;
        let productName = TestsOfPresentClass[i].productName;
        let check = state.checkvalue;
        a.push({ productId, productName, check });
    }
    const unique = a
        .map(e => e['productId'])
        // store the keys of the unique objects
        .map((e, i, final) => final.indexOf(e) === i && i)
        // eliminate the dead keys & store unique objects
        .filter(e => a[e]).map(e => a[e]);
    return unique;
}