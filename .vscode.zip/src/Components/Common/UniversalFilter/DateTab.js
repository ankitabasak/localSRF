import React, { Component } from 'react';
import '../../../../public/css/style.css';
import { connect } from 'react-redux';
import {
    OpenSelectorInDateTab, OpenDateRangeInDateTab, OpenDatePickerInDateTab, SaveSelected_Date,
    SaveSelected_Range, ApplyFilterInDate_Tab, StoreSelectedValuesInDateTab,
    OpenOrCLoseMonthsListInDateTabCalendar, ChangeMonthINDateTab_Calendar, SetUsageDates
} from '../../../Redux_Actions/UniversalSelectorActions'
import { formatDate } from "../../../Utils/globalVars";
import { CloseUniversalFilter } from '../../../Redux_Actions/UniversalSelectorActions_Secondary';
import {
    DistrictTermsDropDown, DateRangeDropDown, SelectedRange, SelectedDistrictTerm, OpenDatePicker, SetAfterClickDateInCalendar, updateNumbersOfMonthsIndex, resetCallApplyDateTab_InDateTab_JS
} from '../../../Redux_Actions/DateTabActions'
import {
    getMonthName
} from '../../../Utils/DatePicker/helpers'
import DatePicker from '../../../Utils/DatePicker/DatePicker';
import { S_RLP_API_CALL } from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import { READING_HISTORY_STUDENT_DATA } from '../../../Redux_Actions/ReadingHistoryActions';
import { ERROR_ANALYSIS_STUDENT_DATA } from '../../../Redux_Actions/ErrorAnalysisActions.jsx';
import { CLASS_READING_HISTORY_DATA } from '../../../Redux_Actions/C_ReadingHistoryActions.jsx';
import { Fluency_Chart_Api_Request, CLASS_FPO_API } from '../../../Redux_Actions/C_FlunecyActions.jsx';
import { CRB_Chart_API_Call } from '../../../Redux_Actions/CRB_Actions.jsx';
import {
    DISTRICT_FA_CHART_API_CALL, DFA_LOAD_ICON
} from "../../../Redux_Actions/District_FA_Action.jsx";
import { DISTRICT_RH_ERRORHANDLING, DISTRICT_READING_HISTORY_DATA } from '../../../Redux_Actions/District_ReadingHistoryAction.jsx';
import {
    CLASS_EA_API,
    LOAD_STATUS_ICON
} from '../../../Redux_Actions/C_ErrorAnalysisAction.jsx';
import {
    School_Level_RLP_Chart_API,
    School_Class_Level_RLP_Chart_API,
    Sum_Sc_RLP_Chart_API
} from '../../../Redux_Actions/School_RlpActions.jsx';
import {
    SCHOOL_READING_HISTORY_DATA,
    SCHOOL_RH_ERRORHANDLING
} from "../../../Redux_Actions/School_ReadingHistoryAction.jsx";
import {
    School_EA_Dropdown
} from "../../../Redux_Actions/School_ErrorAnalysisAction.jsx";
import {
    CLASS_READING_LEVEL_PROGRESS,
    CLASS_READING_LEVEL_GRID_DATA
} from '../../../Redux_Actions/C_ReadingLevelAction.jsx';
import {
    District_Class_Level_RLP_Chart_API,
    District_Level_RLP_Chart_API,
    Sum_Dst_RLP_Chart_API
} from '../../../Redux_Actions/District_RlpActions.jsx';
import { S_Fluency_Chart_Data } from '../../../Redux_Actions/S_FluencyActions.jsx';
import { S_RB_API_CALL } from '../../../Redux_Actions/S_ReadingBehaviorActions.jsx';
import {
    SCHOOL_FPOT_API_SUCCESS,
    LOAD_ICON,
    SCHOOL_FA_CHART_API_CALL,
    FA_LOAD_ICON,
    Sc_GRADES
} from "../../../Redux_Actions/School_FA_Action.jsx";
import {
    School_RB_Chart_API_Call,
    Show_loading_Icon,
    School_RB_Dropdown
} from "../../../Redux_Actions/School_RB_Actions.jsx";
import { getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import {
    Sort_By_Date
} from "../../ReusableComponents/AllReusableFunctions";
import { newDateHandling } from '../../ReusableComponents/AllReusableFunctions_Two';

class TestTab extends React.PureComponent {
    constructor(props) {
        super(props);
        let DateTabComponents = this.props.DateTabReducer.DateTabComponents;
        this.cancelUsageDates = this.cancelUsageDates.bind(this);
        this.applyUsageDateTab = this.applyUsageDateTab.bind(this);
        this.handleDayClick = this.handleDayClick.bind(this);
        this.selectUsageDistrictTerm = this.selectUsageDistrictTerm.bind(this);
        this.setUsageDateRange = this.setUsageDateRange.bind(this);
        this.DateRangeList = this.DateRangeList.bind(this);
        this.state = {
            DistrictTerm: DateTabComponents.SelectedDistrictTerm.termRange,
            DateRange: DateTabComponents.SelectedDateRange !== '' ? DateTabComponents.SelectedDateRange : "District Term To Date",
            StartDateState: DateTabComponents.StartDateInDateTab,
            EndDateState: DateTabComponents.EndDateInDateTab
        }
    }
    componentDidUpdate() {
        let { callApplyDateTab_InDateTab_JS } = this.props.DateTabReducer;
        if (callApplyDateTab_InDateTab_JS) {
            this.props.resetCallApplyDateTab_InDateTab_JS()
            setTimeout(() => {
                this.applyDateTab()
            }, 1500);
        }
    }
    /**
     * Saves date and term for usage and then closes flyout menu
     */
    cancelUsageDates() {
        this.props.SetUsageDates({
            uiStartDate: this.props.usageReports.startDate,
            uiEndDate: this.props.usageReports.endDate,
            uiTermId: this.props.usageReports.termId,
            uiDateRange: this.props.usageReports.dateRange
        })
        this.props.CloseUniversalFilter("date");
    }
    /**
     * Saves date and term for usage and then closes flyout menu
     */

    applyUsageDateTab() {
        const DateTabComponents = this.props.DateTabReducer.DateTabComponents;
        const startDate =
            (this.props.usageReports.uiDateRange === 'Custom Date Range')
                ? DateTabComponents.StartDateInDateTab : this.props.usageReports.uiStartDate;
        const endDate =
            (this.props.usageReports.uiDateRange === 'Custom Date Range')
                ? DateTabComponents.EndDateInDateTab : this.props.usageReports.uiEndDate;
        this.props.SetUsageDates({
            uiStartDate: startDate,
            uiEndDate: endDate,
            startDate,
            endDate,
            termId: this.props.usageReports.uiTermId,
            dateRange: this.props.usageReports.uiDateRange
        })
        this.props.CloseUniversalFilter("date");
    }

    /**
     * 
     * @param {Object} Date_Prop 
     * it will return date range list based on available dates.
     */
    applyDateTab() {
        // let ContextHeader = this.props.ContextHeader;
        let selectedTab = this.props.NavigationByHeaderSelection;
        let Token = this.props.LoginDetails.JWTToken;
        let commonInterFilter = this.props.CommonFilterData;
        if (selectedTab.student && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'student');
            if (selectedTab.readingHistory) {
                this.props.READING_HISTORY_STUDENT_DATA(Token, Req_Payload, 'student');
            } else if (selectedTab.errorAnalysis) {
                this.props.ERROR_ANALYSIS_STUDENT_DATA(Token, Req_Payload, 'student');
            } else if (selectedTab.rlp) {
                this.props.S_RLP_API_CALL(Token, Req_Payload, 'student');
            } else if (selectedTab.fluencyAnalysis) {
                this.props.S_Fluency_Chart_Data(Token, Req_Payload, 'student');
            } else if (selectedTab.readingBehaviors) {
                this.props.S_RB_API_CALL(Token, Req_Payload, 'student');
            } else if (selectedTab.Summary_Tab) {
                this.props.S_RLP_API_CALL(Token, Req_Payload, 'student');
            }
        } else if (selectedTab.class && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'class');
            if (selectedTab.readingHistory) {
                this.props.CLASS_READING_HISTORY_DATA(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.rlp) {
                this.props.CLASS_READING_LEVEL_PROGRESS(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.errorAnalysis) {
                let errorRecordType = {
                    allRecords: this.props.showRecord === 'all' ? true : false,
                    recentRecord: this.props.showRecord === 'rec' ? true : false
                };
                Req_Payload.errorRecordType = errorRecordType;
                this.props.CLASS_EA_API(Token, Req_Payload);
            } else if (selectedTab.fluencyAnalysis) {

                if (this.props.FluencyTabSelection.wcpm) {
                    this.props.Fluency_Chart_Api_Request(
                        Token,
                        Req_Payload
                    );
                }
                if (this.props.FluencyTabSelection.fpot) {
                    let dataRecordType = {
                        allRecords: this.props.progressOverTime.showRecord === 'all' ? true : false,
                        recentRecord: this.props.progressOverTime.showRecord === 'rec' ? true : false
                    };
                    Req_Payload.dataRecordType = dataRecordType
                    this.props.CLASS_FPO_API(Token,
                        Req_Payload
                    );
                }
            } else if (selectedTab.readingBehaviors) {
                this.props.CRB_Chart_API_Call(Token, Req_Payload)
            } else if (selectedTab.Summary_Tab) {
                this.props.CLASS_READING_LEVEL_PROGRESS(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            }
        } else if (selectedTab.school && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'school');
            if (selectedTab.readingHistory) {
                this.props.SCHOOL_RH_ERRORHANDLING({
                    isApiLoading: true,
                    isDataNotAvailable: false,
                    timeOut: false
                });
                this.props.SCHOOL_READING_HISTORY_DATA(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.rlp) {
                this.props.School_Level_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.fluencyAnalysis) {
                let grade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
                if (this.props.ScFTabSelection["fpot"]) {
                    let dataRecordType = {
                        allRecords:
                            this.props.School_fpot.showRecord === "all" ? true : false,
                        recentRecord:
                            this.props.School_fpot.showRecord === "rec" ? true : false
                    };
                    this.props.LOAD_ICON({
                        isApiLoading: true,
                        apiTimeOut: false,
                        hideChart: true
                    });

                    let gradePayLoad = {
                        dataRecordType,
                        internalFilter: Req_Payload.internalFilter,
                        externalFilter: Object.assign(Req_Payload.externalFilter, {
                            chartName: "ScFR"
                        })
                    }
                    this.props.Sc_GRADES(Token, gradePayLoad,
                        this.props.ContextHeader.Roster_Tab.selectedRosterGrade,
                        this.props.CommonFilterData, 'rec');
                }
                if (this.props.ScFTabSelection["wcpm"]) {
                    this.props.FA_LOAD_ICON();
                    this.props.SCHOOL_FA_CHART_API_CALL(this.props.LoginDetails.JWTToken, {
                        ...Req_Payload
                    }, grade);
                }
            } else if (selectedTab.Summary_Tab) {
                this.props.Sum_Sc_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.errorAnalysis) {
                let errorRecordType = {
                    allRecords: this.props.showRecordSea === 'all' ? true : false,
                    recentRecord: this.props.showRecordSea === 'rec' ? true : false
                };
                let payload = {
                    ["errorRecordType"]: errorRecordType,
                    internalFilter: Req_Payload.internalFilter,
                    externalFilter: Object.assign(Req_Payload.externalFilter, {
                        chartName: "ScEA"
                    })
                };
                this.props.School_EA_Dropdown(this.props.LoginDetails.JWTToken, payload, this.props.ContextHeader.Roster_Tab.selectedRosterGrade);
            } else if (selectedTab.readingBehaviors) {
                let grade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
                this.props.Show_loading_Icon();
                let payLoad = {
                    internalFilter: Req_Payload.internalFilter,
                    externalFilter: Object.assign(Req_Payload.externalFilter, {
                        chartName: "ScRB"
                    })
                }
                this.props.School_RB_Dropdown(
                    this.props.LoginDetails.JWTToken,
                    payLoad,
                    grade
                );
            }
        } else if (selectedTab.district && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'district');
            if (selectedTab.rlp) {
                //need to change
                this.props.District_Level_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.readingHistory) {
                this.props.DISTRICT_RH_ERRORHANDLING({
                    isApiLoading: true,
                    isDataNotAvailable: false,
                    timeOut: false
                });
                this.props.DISTRICT_READING_HISTORY_DATA(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.Summary_Tab) {
                this.props.Sum_Dst_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.fluencyAnalysis) {
                this.props.DFA_LOAD_ICON();
                this.props.DISTRICT_FA_CHART_API_CALL(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            }
        }
    }

    DateRangeList(DateTabComponents, CurrentNav_Context_DateTab) {
        let { SelectedDateRange } = DateTabComponents;
        let Context_SelectedDateRange = CurrentNav_Context_DateTab.SelectedDateRange;
        SelectedDateRange = SelectedDateRange == "" || SelectedDateRange == undefined ? "District Term To Date" : SelectedDateRange;
        Context_SelectedDateRange = Context_SelectedDateRange == "" || Context_SelectedDateRange == undefined ? "District Term To Date" : Context_SelectedDateRange;
        let dateRangeArray = ["Last 30 Days", "Last 60 Days", "Last 90 Days", "District Term To Date", "Custom Date Range"].filter(item => Context_SelectedDateRange != item);
        dateRangeArray.unshift(Context_SelectedDateRange)
        return <ul>
            {/*  changed regarding BU_18730 */}
            {dateRangeArray.map(dateRange => {
                return <li className={SelectedDateRange == dateRange ? "selected-li-in-datetab" : ""}
                    onClick={() => {
                        let { usageReport } = this.props.NavigationByHeaderSelection;
                        let result = null
                        if ((dateRange == "District Term To Date" || dateRange == "Custom Date Range") && !usageReport) {
                            this.props.SelectedRange("", dateRange);
                        } else {
                            result = dateRange == "Last 30 Days" ? GetLast30Days(this.props, "Last 30 Days") :
                                dateRange == "Last 60 Days" ? GetLast60Days(this.props, "Last 60 Days") : GetLast90Days(this.props, "Last 90 Days");
                        }

                        if (usageReport) {
                            this.setUsageDateRange(DateTabComponents, dateRange, result);
                        }
                        // if (item == "Last 30 Days") {
                        //     const result = GetLast30Days(this.props, "Last 30 Days");
                        //     if (this.props.NavigationByHeaderSelection.usageReport) {
                        //         this.setUsageDateRange(DateTabComponents, "Last 30 Days", result);
                        //     }
                        // } else if (item == "Last 60 Days") {
                        //     const result = GetLast60Days(this.props, "Last 60 Days");
                        //     if (this.props.NavigationByHeaderSelection.usageReport) {
                        //         this.setUsageDateRange(DateTabComponents, "Last 60 Days", result);
                        //     };
                        // } else if (item == "Last 90 Days") {
                        //     const result = GetLast90Days(this.props, "Last 90 Days");
                        //     if (this.props.NavigationByHeaderSelection.usageReport) {
                        //         this.setUsageDateRange(DateTabComponents, "Last 90 Days", result);
                        //     }
                        // }
                        // else if (item == "District Term To Date") {
                        //     if (this.props.NavigationByHeaderSelection.usageReport) {
                        //         this.setUsageDateRange(DateTabComponents, "District Term To Date");
                        //     } else {
                        //         this.props.SelectedRange("", "District Term To Date");
                        //     }
                        // } 
                        // else {
                        //     if (this.props.NavigationByHeaderSelection.usageReport) {
                        //         this.setUsageDateRange(DateTabComponents, "Custom Date Range");
                        //     } else {
                        //         this.props.SelectedRange("", "Custom Date Range");
                        //     }
                        // }
                    }}>
                    {dateRange}
                </li>
            })}
            {/*  <li className={DateTabComponents.SelectedDateRange == "Last 30 Days" ? "selected-li-in-datetab" : ""}
                onClick={() => {
                    const result = GetLast30Days(this.props, "Last 30 Days");
                    if (this.props.NavigationByHeaderSelection.usageReport) {
                        this.setUsageDateRange(DateTabComponents, "Last 30 Days", result);
                    }
                }}>
                Last 30 Days
            </li>
            <li className={DateTabComponents.SelectedDateRange == "Last 60 Days" ? "selected-li-in-datetab" : ""}
                onClick={() => {
                    
                    const result = GetLast60Days(this.props, "Last 60 Days");
                    if (this.props.NavigationByHeaderSelection.usageReport) {
                        this.setUsageDateRange(DateTabComponents, "Last 60 Days", result);
                    };
                    
                }}>
                Last 60 Days
            </li>
            <li className={DateTabComponents.SelectedDateRange == "Last 90 Days" ? "selected-li-in-datetab" : ""}
                onClick={() => {
                    const result = GetLast90Days(this.props, "Last 90 Days");
                    if (this.props.NavigationByHeaderSelection.usageReport) {
                        this.setUsageDateRange(DateTabComponents, "Last 90 Days", result);
                    }
                }}>
                Last 90 Days
            </li>
            <li className={DateTabComponents.SelectedDateRange == "District Term To Date" || DateTabComponents.SelectedDateRange == undefined ? "selected-li-in-datetab" : ""}
                onClick={() => {
                    if (this.props.NavigationByHeaderSelection.usageReport) {
                        this.setUsageDateRange(DateTabComponents, "District Term To Date");
                    } else {
                        this.props.SelectedRange("", "District Term To Date");
                    }
                }}>
                District Term To Date
            </li>

            <li className={DateTabComponents.SelectedDateRange == "Custom Date Range" ? "selected-li-in-datetab" : ""}
                onClick={() => {
                    if (this.props.NavigationByHeaderSelection.usageReport) {
                        this.setUsageDateRange(DateTabComponents, "Custom Date Range");
                    } else {
                        console.log("this.props",this.props.SelectedRange("", "District Term To Date"));
                        this.props.SelectedRange("", "Custom Date Range");
                    }
                }}>
                Custom Date Range
            </li> */}
        </ul >
    }

    dateDisplayinCustomRange(EndDate) {
        return EndDate
    }
    selectUsageDistrictTerm(item) {
        this.props.SetUsageDates({
            uiTermId: item.termId,
            uiStartDate: item.termStartDate,
            uiEndDate: item.termEndDate,
            uiDateRange: 'District Term To Date'
        });
    }

    DateTab(DateTabComponents, Nav, CurrentNav_Context_DateTab) {
        let Date_Prop = this.props.ContextHeader.Date_Tab;
        let Loading = false;
        if (Nav.usageReport) {
            if (this.props.usageReports.uiTermId !== null) {
                let usageTerm = null;
                Date_Prop.DistrictTerms_New.forEach((term) => {
                    if (term.termId === this.props.usageReports.uiTermId) {
                        usageTerm = term;
                    }
                });
                if (usageTerm !== null) {
                    DateTabComponents.SelectedDistrictTerm = usageTerm;
                    DateTabComponents.SelectedDateRange = this.props.usageReports.uiDateRange;
                    if (this.props.usageReports.uiDateRange !== 'Custom Date Range') {
                        DateTabComponents.StartDateInDateTab = this.props.usageReports.uiStartDate;
                        DateTabComponents.EndDateInDateTab = this.props.usageReports.uiEndDate;
                    }
                } else {
                    Loading = true;
                }
            } else {
                Loading = true;
            }
        }
        if (Loading) {
            return (<div className="datetabContainer">
                <div className="universal-input-field">
                    <div className="menu-title">
                        District Term
                        <span className="data-refresh">
                            <i className="material-icons">autorenew</i>
                        </span>
                    </div>
                </div>
            </div>);
        }
        Loading = this.props.ApiCalls.loadingFor;
        let totalMonthsList = monthnamesofPresetTurm(DateTabComponents.SelectedDistrictTerm.termStartDate, DateTabComponents.SelectedDistrictTerm.termEndDate)

        return <div className="datetabContainer">
            {/* district term */}
            <div className="universal-input-field">
                <div className="menu-title">
                    District Term
                    <span className="data-refresh">
                        {Loading == "datetab" ?
                            <i className="material-icons">autorenew</i>
                            : null}
                    </span>
                </div>
                <div className={DateTabComponents.openDistrictTermDropdown && !Nav.test_status && (!this.props.usageReports.disableTerms || !Nav.usageReport) ?
                    "menu-selector active-selector" : "menu-selector"} >
                    <button
                        onClick={Date_Prop.DistrictTerms_New.length > 1 && !Nav.test_status && (!this.props.usageReports.disableTerms || !Nav.usageReport) ? () =>
                            this.props.DistrictTermsDropDown() : null}
                        className="select-dropdown"
                        style={{
                            background: ((Date_Prop.DistrictTerms_New.length == 1 || Nav.test_status || (this.props.usageReports.disableTerms && Nav.usageReport)) ? "#fff" : null),
                            cursor: ((Date_Prop.DistrictTerms_New.length == 1 || Nav.test_status || (this.props.usageReports.disableTerms && Nav.usageReport)) ? "default" : null)
                        }}>
                        {DateTabComponents.SelectedDistrictTerm.termName == "" || DateTabComponents.SelectedDistrictTerm.termName == undefined ? "Select Date" : DateTabComponents.SelectedDistrictTerm.termName}
                    </button>
                    {Date_Prop.DistrictTerms_New.length > 1 ?
                        <div className="menu-dropdown-container">
                            <div className="menu-dropdown-list">
                                <div className="menu-dropdown-list-inr">
                                    <ul>
                                        {Date_Prop.DistrictTerms_New.map((item, i) => (
                                            <li key={i} value={item.termRange}
                                                class={DateTabComponents.SelectedDistrictTerm.termId == item.termId ? "selected-li-in-datetab" : ""}
                                                onClick={(txt) => {
                                                    if (Nav.usageReport) {
                                                        this.selectUsageDistrictTerm(item);
                                                    } else {
                                                        this.props.SelectedDistrictTerm(item);
                                                    }
                                                }}>
                                                {item.termName}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            </div>
                        </div> : null}
                </div>
            </div>
            {/* varied dates */}
            <div className="universal-input-field">
                <div className="menu-title">
                    Date Range
                    <span className="data-refresh">

                        {Loading == "datetab" ?

                            <i className="material-icons">autorenew</i>

                            : null}
                    </span>
                </div>
                <div className={DateTabComponents.openDateRangeDropDown ?
                    "menu-selector active-selector" : "menu-selector"} >
                    <button
                        onClick={() => this.props.DateRangeDropDown()}
                        className="select-dropdown">

                        {DateTabComponents.SelectedDateRange === "" ? "District Term To Date" : DateTabComponents.SelectedDateRange}
                    </button>
                    <div className="menu-dropdown-container">
                        <div className="menu-dropdown-list">
                            <div className="menu-dropdown-list-inr">
                                { /* Sort_By_Date(this.DateRangeList(DateTabComponents), DateTabComponents.SelectedDateRange, "SelectedDateRange") */
                                    this.DateRangeList(DateTabComponents, CurrentNav_Context_DateTab)}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* custom dates */}
            {DateTabComponents.SelectedDateRange === "Custom Date Range" ?
                <div className="universal-input-field">
                    <div className="Date_tab">
                        <div style={{ float: 'left', width: '100%' }}>
                            <div className="menu-title" style={{ width: '50%' }}>
                                Start Date
                            </div>
                            <div className="menu-title" style={{ width: '50%', paddingLeft: '7px' }}>
                                End Date
                            </div>
                        </div>
                        <div className="DateWeekCalender">
                            <div
                                className={DateTabComponents.CheckStartOrEndDate == 'Start Date' ?
                                    "date-selector activeCalendar" : "date-selector"}
                                style={{ float: 'left', borderBottom: DateTabComponents.CheckStartOrEndDate == 'Start Date' ? '1px solid #00539B' : null }}  >
                                <button onClick={() => {
                                    let selected = 'Start Date'
                                    this.props.OpenDatePicker(selected)
                                }}>
                                    {DateTabComponents.StartDateInDateTab == '' ? this.returnStartDate(DateTabComponents.SelectedDistrictTerm.termStartDate) : this.returnStartDate(DateTabComponents.StartDateInDateTab)}
                                </button>
                            </div>
                            <div className={DateTabComponents.CheckStartOrEndDate == 'End Date' ?
                                "date-selector activeCalendar" : "date-selector"}
                                style={{ float: 'right', borderBottom: DateTabComponents.CheckStartOrEndDate == 'End Date' ? '1px solid #00539B' : null }}>
                                <button onClick={() => {
                                    let selected = 'End Date'
                                    this.props.OpenDatePicker(selected);
                                }}>
                                    {this.dateDisplayinCustomRange(DateTabComponents.EndDateInDateTab === undefined ||
                                        DateTabComponents.EndDateInDateTab === "" ? this.returnEndDate(DateTabComponents.SelectedDistrictTerm.termEndDate) : this.returnEndDate(DateTabComponents.EndDateInDateTab))}
                                </button>
                            </div>
                        </div>
                        {DateTabComponents.CheckStartOrEndDate !== "" && this.props.UniversalFilter == "date" ? this.callCalendar(DateTabComponents, totalMonthsList) : null}
                        <div className="dateBottomTitleText">Date Range: {parseInt(DaysCalculate(DateTabComponents))} Days</div>
                    </div>
                </div> : null}
        </div>
    }

    returnStartDate(SelectedDistrictTerm) {
        return DateFormat(SelectedDistrictTerm);
    }

    returnEndDate(SelectedDistrictTerm) {
        return DateFormat(SelectedDistrictTerm);
    }

    callCalendar(DateTabComponents, totalMonthsList) {
        let DateToCAllCalendar =
            DateTabComponents.CheckStartOrEndDate == "Start Date" ? DateTabComponents.StartDateInDateTab !== '' ? DateTabComponents.StartDateInDateTab : DateTabComponents.SelectedDistrictTerm.termStartDate : DateTabComponents.EndDateInDateTab !== '' ? DateTabComponents.EndDateInDateTab : DateTabComponents.SelectedDistrictTerm.termEndDate
        let ReportStartMonthName = GetMonthAndYear(DateTabComponents.StartDateInDateTab !== '' ? DateTabComponents.StartDateInDateTab : DateTabComponents.SelectedDistrictTerm.termStartDate);
        let ReportEndMonthName = GetMonthAndYear(DateTabComponents.EndDateInDateTab !== '' ? DateTabComponents.EndDateInDateTab : DateTabComponents.SelectedDistrictTerm.termEndDate);
        return <DatePicker
            fullDate={newDateHandling(DateToCAllCalendar)}
            totalMonths={totalMonthsList}
            ReportStartMonthName={ReportStartMonthName}
            ReportEndMonthName={ReportEndMonthName}
            onDayClick={this.handleDayClick}
            onMonthClick={this.handleMonthClick}
            selectedTerm={DateTabComponents.SelectedDistrictTerm}
            DateTabComponents={DateTabComponents}
        />
    }

    /**
    * 
    * @param {*} newDate
    *  Change state on date selection.
    */

    handleDayClick(newDay) {
        let DateTabComponents = this.props.DateTabReducer.DateTabComponents;
        let calendarFor = DateTabComponents.CheckStartOrEndDate;
        let SelectedMonthFinal = DateTabComponents.CheckStartOrEndDate == "Start Date" ? DateTabComponents.SelectedStartMonth == '' ? GetMonthAndYear(DateTabComponents.SelectedDistrictTerm.termStartDate) : DateTabComponents.SelectedStartMonth : DateTabComponents.SelectedEndMonth == '' ? GetMonthAndYear(DateTabComponents.SelectedDistrictTerm.termEndDate) : DateTabComponents.SelectedEndMonth
        let selectedDate = GetFullDate(newDay, SelectedMonthFinal)
        this.props.SetAfterClickDateInCalendar(selectedDate, calendarFor)
    }

    StateChange(DateTabComponents) {
        this.setState({
            DistrictTerm: DateTabComponents.SelectedDistrictTerm.termRange,
            DateRange: DateTabComponents.SelectedDateRange,
            StartDateState: DateTabComponents.StartDateInDateTab,
            EndDateState: DateTabComponents.EndDateInDateTab
        })
    }

    setUsageDateRange(DateTabComponents, range, data = null) {
        const TermStartDate = DateTabComponents.SelectedDistrictTerm.termStartDate;
        const TermEndDate = DateTabComponents.SelectedDistrictTerm.termEndDate;
        if (range === 'District Term To Date' || range === 'Custom Date Range') {
            this.props.SetUsageDates({
                uiDateRange: range,
                uiStartDate: DateFormat(TermStartDate),
                uiEndDate: DateFormat(TermEndDate)
            });
            return;
        }
        this.props.SetUsageDates({
            uiDateRange: range,
            uiStartDate: DateFormat(data),
            uiEndDate: DateFormat(TermEndDate)
        });
    }

    render() {
        const { UniversalSelecter, ContextHeader, NavigationByHeaderSelection, DateTabReducer, usageReports } = this.props
        let Date_Props = UniversalSelecter.Date;
        let Context_props = ContextHeader.Date_Tab;
        let { DateTabComponents, Date_last_Active_Report_Props, Context_DateTab_TestStatus, Context_DateTab,
            ORR_Context_DateTab } = DateTabReducer;
        let CurrentNav_Context_DateTab = NavigationByHeaderSelection.ORR ? ORR_Context_DateTab :
            NavigationByHeaderSelection.Assessement && NavigationByHeaderSelection.test_status ? Context_DateTab_TestStatus :
                Context_DateTab;

        let DissableApply = true;
        if (NavigationByHeaderSelection.usageReport) {
            if (usageReports.uiTermId !== usageReports.termId ||
                usageReports.uiDateRange !== usageReports.dateRange ||
                usageReports.uiStartDate !== usageReports.startDate ||
                usageReports.uiEndDate !== usageReports.endDate ||
                DateTabComponents.StartDateInDateTab !== usageReports.startDate ||
                DateTabComponents.EndDateInDateTab !== usageReports.endDate) {
                DissableApply = false;
            }
        } else {
            let PropsOf_Current_Report = Date_last_Active_Report_Props;
            DissableApply = DisableDateTabApplyButton(DateTabReducer, ContextHeader, PropsOf_Current_Report, NavigationByHeaderSelection)
        }
        return <div className="menu-item-expand-block">
            <div className="menu-item-expand-block-inr dateTabBlockContainer">
                {this.DateTab(DateTabComponents, NavigationByHeaderSelection, CurrentNav_Context_DateTab)}
                <div className="universal-select-filter">
                    <div className="apply-btn float-right">
                        <button
                            disabled={DissableApply}
                            onClick={() => {
                                if (NavigationByHeaderSelection.usageReport) {
                                    this.applyUsageDateTab();
                                } else {
                                    this.props.ApplyFilterInDate_Tab(DateTabComponents), this.StateChange(DateTabComponents)
                                    setTimeout(() => {
                                        this.applyDateTab()
                                    }, 1500);
                                }
                            }}
                            className={DissableApply ?
                                "universal-selector-applyfilter disableFilter_us" : "universal-selector-applyfilter"}>Apply</button></div>
                    <div className="cancel-btn float-right"
                        onClick={() => {
                            if (!NavigationByHeaderSelection.usageReport) {
                                this.props.CloseUniversalFilter("date")
                            } else {
                                this.cancelUsageDates();
                            }
                        }}
                    >Cancel</div>
                </div>
            </div>
        </div >
    }
}
const mapStateToProps = ({ Universal, DateTabReducer, Authentication, CommonFilterDetails,
    School_FA_Reducer,
    classFluency,
    ClassEaData,
    SchoolErrorAnalysisData }) => {
    const { UniversalSelecter, ApiCalls, ContextHeader, UniversalFilter, NavigationByHeaderSelection, usageReports } = Universal;
    const { LoginDetails } = Authentication;
    const { CommonFilterData } = CommonFilterDetails;
    const { School_fpot, ScFTabSelection } = School_FA_Reducer;
    const { FluencyTabSelection, progressOverTime } = classFluency;
    const { showRecord } = ClassEaData;
    const { showRecordSea } = SchoolErrorAnalysisData;
    return {
        UniversalSelecter, ApiCalls, ContextHeader, UniversalFilter, DateTabReducer, NavigationByHeaderSelection,
        LoginDetails,
        CommonFilterData,
        School_fpot,
        ScFTabSelection,
        FluencyTabSelection,
        progressOverTime,
        showRecord,
        showRecordSea,
        usageReports
    }
}
export default connect(mapStateToProps, {
    CloseUniversalFilter, OpenSelectorInDateTab, OpenDateRangeInDateTab,
    OpenDatePickerInDateTab, SaveSelected_Date, SaveSelected_Range, ApplyFilterInDate_Tab,
    StoreSelectedValuesInDateTab,
    OpenOrCLoseMonthsListInDateTabCalendar,
    ChangeMonthINDateTab_Calendar, DistrictTermsDropDown, DateRangeDropDown, SelectedRange, SelectedDistrictTerm, OpenDatePicker, SetAfterClickDateInCalendar, updateNumbersOfMonthsIndex,
    resetCallApplyDateTab_InDateTab_JS,
    S_RLP_API_CALL,
    S_RB_API_CALL,
    READING_HISTORY_STUDENT_DATA,
    ERROR_ANALYSIS_STUDENT_DATA,
    CLASS_READING_HISTORY_DATA,
    Fluency_Chart_Api_Request,
    CLASS_FPO_API,
    CRB_Chart_API_Call,
    CLASS_READING_LEVEL_PROGRESS,
    CLASS_READING_LEVEL_GRID_DATA,
    CLASS_EA_API,
    School_Level_RLP_Chart_API,
    School_EA_Dropdown,
    School_Class_Level_RLP_Chart_API,
    LOAD_STATUS_ICON,
    District_Class_Level_RLP_Chart_API,
    District_Level_RLP_Chart_API,
    S_Fluency_Chart_Data,
    SCHOOL_FPOT_API_SUCCESS,
    Sc_GRADES,
    LOAD_ICON,
    Sum_Sc_RLP_Chart_API,
    Sum_Dst_RLP_Chart_API,
    SCHOOL_READING_HISTORY_DATA,
    SCHOOL_RH_ERRORHANDLING,
    SCHOOL_FA_CHART_API_CALL,
    FA_LOAD_ICON,
    School_RB_Chart_API_Call,
    Show_loading_Icon,
    School_RB_Dropdown,
    DISTRICT_FA_CHART_API_CALL,
    DFA_LOAD_ICON,
    DISTRICT_RH_ERRORHANDLING,
    DISTRICT_READING_HISTORY_DATA,
    SetUsageDates
})(TestTab);

function DisableDateTabApplyButton(DateTabRedu, Context, PropsOf_Current_Report, Nav) {
    let { DateTabComponents, ORR_Context_DateTab, Context_DateTab_TestStatus, Context_DateTab, Date_last_Active_Report_Props } = DateTabRedu;
    let DateTab_Context = Nav.ORR ? ORR_Context_DateTab : Nav.test_status ? Context_DateTab_TestStatus :
        Context_DateTab;
    let Context_props = Context.Date_Tab;
    if (DateTabComponents.SelectedDateRange == "Custom Date Range") {
        if (DateTabComponents.StartDateInDateTab == "" && DateTabComponents.EndDateInDateTab == "") {
            return true
        } else if (DateTabComponents.StartDateInDateTab == "") {
            return DateTabComponents.EndDateInDateTab == Date_last_Active_Report_Props.SelectedEndDate;
        } else if (DateTabComponents.EndDateInDateTab == "") {
            return DateTabComponents.StartDateInDateTab == Date_last_Active_Report_Props.SelectedStartDate;
        } else {
            return DateTabComponents.StartDateInDateTab == Date_last_Active_Report_Props.StartDateInDateTab &&
                DateTabComponents.EndDateInDateTab == Date_last_Active_Report_Props.EndDateInDateTab;
        }
    }
    else if (Context_props.dateRange == "District Term To Date" && (DateTabComponents.SelectedDateRange == "" || DateTabComponents.SelectedDateRange == "District Term To Date")
    ) {
        if (DateTab_Context.SelectedDistrictTerm && DateTabComponents.SelectedDistrictTerm && DateTab_Context.SelectedDistrictTerm.termId != DateTabComponents.SelectedDistrictTerm.termId) {
            return false;
        } else return true;

    } else if (DateTabComponents.SelectedDistrictTerm.termId == DateTab_Context.SelectedDistrictTerm.termId
        && DateTabComponents.SelectedDateRange == DateTab_Context.SelectedDateRange) {
        return true
    } else if (DateTabComponents.SelectedDistrictTerm.termRange == DateTab_Context.SelectedDistrictTerm.termId && DateTabComponents.SelectedDateRange === "District Term To Date") {
        return true
    } else {
        return false;
    }
}

function DateFormat(date) {
    let newDate = newDateHandling(date)
    var Oneyear = newDate.getFullYear();
    var Onemonth = newDate.getMonth() + 1
    var Oneday = newDate.getDate();
    return Onemonth + "/" + Oneday + "/" + Oneyear;
}

function isEmpty(obj) {
    for (var key in obj) {
        if (obj.hasOwnProperty(key))
            return false;
    }
    return true;
}

function GetMonthAndYear(date) {
    let months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
        "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

    let newDate = newDateHandling(date)
    let month = months[newDate.getMonth()];
    let year = newDate.getFullYear();

    return month + " " + year

}

function GetFullDate(newDate, MonthYear) {
    let tempDate = newDateHandling(newDate + " " + MonthYear)
    let month = tempDate.getMonth() + 1;
    let year = tempDate.getFullYear();
    return month + "/" + newDate + "/" + year
}

function DaysCalculate(DateTabComponents) {
    let value1 = DateTabComponents.StartDateInDateTab !== '' ? DateTabComponents.StartDateInDateTab : DateTabComponents.SelectedDistrictTerm.termStartDate;
    let value2 = DateTabComponents.EndDateInDateTab !== '' ? DateTabComponents.EndDateInDateTab : DateTabComponents.SelectedDistrictTerm.termEndDate
    let d1 = newDateHandling(value2);
    let d2 = newDateHandling(value1);
    let timeDiff = d1.getTime() - d2.getTime();
    let DaysDiff = timeDiff / (1000 * 3600 * 24);

    return DaysDiff + 1;
}

function GetLast30Days(props, range) {
    let TermEndDate = props.DateTabReducer.DateTabComponents.SelectedDistrictTerm.termEndDate;
    let getdata = new Date() < newDateHandling(TermEndDate) ?
        newDateHandling(new Date().setDate(new Date().getDate() - 30)) :
        newDateHandling(new Date(TermEndDate).setDate(newDateHandling(TermEndDate).getDate() - 30));
    if (!props.NavigationByHeaderSelection.usageReport) {
        props.SelectedRange(getdata, range);
    }
    return getdata;
}
function GetLast60Days(props, range) {
    let TermEndDate = props.DateTabReducer.DateTabComponents.SelectedDistrictTerm.termEndDate;
    let getdata = new Date() < newDateHandling(TermEndDate) ?
        newDateHandling(new Date().setDate(new Date().getDate() - 60)) :
        newDateHandling(new Date(TermEndDate).setDate(newDateHandling(TermEndDate).getDate() - 60));
    if (!props.NavigationByHeaderSelection.usageReport) {
        props.SelectedRange(getdata, range);
    }
    return getdata;
}
function GetLast90Days(props, range) {
    let TermEndDate = props.DateTabReducer.DateTabComponents.SelectedDistrictTerm.termEndDate;
    let getdata = new Date() < newDateHandling(TermEndDate) ?
        newDateHandling(new Date().setDate(new Date().getDate() - 90)) :
        newDateHandling(new Date(TermEndDate).setDate(newDateHandling(TermEndDate).getDate() - 90));
    if (!props.NavigationByHeaderSelection.usageReport) {
        props.SelectedRange(getdata, range);
    }
    return getdata;
}

function monthnamesofPresetTurm(startDate, EndDate) {
    var Name_of_monthsList = [];
    const startYear = newDateHandling(startDate).getFullYear();
    const endYear = newDateHandling(EndDate).getFullYear();
    const StartYearForMonths = newDateHandling(startDate).getMonth();
    const EndYearForMonths = newDateHandling(EndDate).getMonth() + 1;
    var MonthAndYear = '';
    for (var i = startYear; i <= endYear; i++) {
        if (i == startYear) {
            let MonthForCondition = startYear == endYear ? EndYearForMonths : 12;
            for (var j = StartYearForMonths; j < MonthForCondition; j++) {
                MonthAndYear = `${GetOnlyMonthName(j)} ${i}`
                Name_of_monthsList.push(MonthAndYear)
            }
        } else
            if (i <= endYear) {
                if (i == endYear) {
                    for (var k = 0; k < EndYearForMonths; k++) {
                        MonthAndYear = `${GetOnlyMonthName(k)} ${i}`
                        Name_of_monthsList.push(MonthAndYear)
                    }
                } else {
                    for (var l = 0; l < 12; l++) {
                        MonthAndYear = `${GetOnlyMonthName(l)} ${i}`
                        Name_of_monthsList.push(MonthAndYear)
                    }
                }
            }
    };
    return Name_of_monthsList;
}
function getLocalTimestamp(date) {
    let currentDate = newDateHandling(date);
    let currentTime = currentDate.getTime();
    let localOffset = (-1) * currentDate.getTimezoneOffset() * 60000;// adjustes time with timezone
    let timestamp = newDateHandling(currentTime + localOffset).getTime();
    return timestamp;
}
function GetOnlyMonthName(i) {
    const monthName = getMonthName(i);
    const monthCapital = monthName.toUpperCase();
    let displayMonthname = monthCapital.slice(0, 3)
    return displayMonthname;
}
function GetFullDateRemoveTime(newDate) {
    let tempDate = newDateHandling(newDate)
    let date = tempDate.getDate();
    let month = tempDate.getMonth() + 1;
    let year = tempDate.getFullYear();
    return year + "-" + month + "-" + date;
}