export function schoolNameCondition(SelectedSchool) {
    let flag = false;
    if (SelectedSchool && SelectedSchool.name !== undefined) {
        flag = true
    }
    return flag;
}
export function schoolObjCondition(school) {
    if (school == "All") {
        school = {};
    }
    return school;
}