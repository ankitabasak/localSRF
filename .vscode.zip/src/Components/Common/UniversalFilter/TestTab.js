import React, { Component } from "react";
import "../../../../public/css/style.css";
import { connect } from "react-redux";
import PaginationComponent from "../../../Utils/UniversalSelector_Pagination";

import {
  UncheckTestTypeByClickingOnDisplaySpan,
  OpenOrCloseTestTypes,
  ApplyFiltersInTestTab,
  CheckOrUncheckTestTypeCheckBox,
  StoreFilteredListInTest,
  CloseUniversalFilter,
} from "../../../Redux_Actions/UniversalSelectorActions_Secondary";

import {
  SaveTestDataAfterSorting,
  DoneInTestTypeView,
} from "../../../Redux_Actions/UniversalSelectorActions_Primary";

import { CheckOrUncheckTestCheckBox } from "../../../Redux_Actions/UniversalSelectorActions_Secondary";

import { OpenUniversalFilter } from "../../../Redux_Actions/UniversalSelectorActions_Secondary";

import {
  convertUTCDateToLocalDate,
  SortArray,
} from "../../ReusableComponents/AllReusableFunctions";
import {
  GetIds_of_Each_Object_In_The_Array,
  Request_PayloadFor_LineChart_Data,
} from "../../ReusableComponents/AllReusableFunctions";

import { Scrollbars } from "react-custom-scrollbars";
import TestIcon from "../../../../public/images/ic_test_unselected.svg";
import { DISPLAY_LOCAL_TIME_IN_UI } from "../../../Utils/globalVars";

class TestTab extends React.PureComponent {
  testTypeResultsBody(TestTab, Nav) {
    let TestTypesList = TestTab.TestTypes.TestTypesList;
    return TestTypesList.map((testType, i) => {
      let checkvalue = testType.check === undefined ? false : testType.check;
      return (
        <li
          value="benchmarkadelente"
          key={i}
          onClick={() => {
            let Check = testType.check === undefined ? true : !testType.check;
            let SelectedElement = TestTypesList[i];
            this.props.CheckOrUncheckTestTypeCheckBox(Check, SelectedElement);
          }}
        >
          <div class="testTypesingleitem">
            <div class="input-checkbox checkbox-lightBlue">
              <input
                type="checkbox"
                //checked={this.CheckOrUncheckTestType(testType)}
                checked={checkvalue}
                value={checkvalue}
              />
              <span class="checkbox"></span>
            </div>
            <span></span>
          </div>
          {testType.testTypeName}
        </li>
      );
    });
  }

  /**
   *
   * @param {Array} Selected_U_List_Types
   * @returns {JSX element}
   *
   * it will return selected test type names
   */

  returnSelectedTest_Types(Selected_U_List_Types) {
    return Selected_U_List_Types.filter((item) => item.check).map(
      (testtype) => (
        <span className="selectedTestTypeUI">
          <span className="selectedTestTypeUIName">
            {testtype.testTypeName}
          </span>
          <span
            className="cancelTestTypeUI"
            onClick={() => {
              this.props.UncheckTestTypeByClickingOnDisplaySpan(testtype);
            }}
          >
            X
          </span>
        </span>
      )
    );
  }

  /**
   *
   * @param {Object} U_SelectorTest
   *
   * @returns {String}  All/ Custom (5)/ selected test name.
   *
   *
   */
  TEstTypesSelections_TEXT(U_SelectorTest, Nav) {
    let Tests = U_SelectorTest.TestTypes.LastInstanceTestTypes;
    let Tests_Selected = U_SelectorTest.TestTypes.LastInstanceSelectedTestTypes;
    if (Tests_Selected.length == 1) {
      return Tests_Selected[0].testTypeName;
    } else if (Tests_Selected.length == Tests.length) {
      return "All";
    } else {
      return "Custom (" + Tests_Selected.length + ")";
    }
  }

  /**
   *  Returning test's view
   */
  TestSubElements() {
    let S_Column = this.props.UniversalSelecter.TestTab.SortColumnIs;
    let S_Type = this.props.UniversalSelecter.TestTab.SortType;
    let U_SelectorTest = this.props.UniversalSelecter.TestTab;
    let Nav = this.props.NavigationByHeaderSelection;
    let ContextHeader = this.props.ContextHeader;

    let Selected_Context_TestTypes =
      U_SelectorTest.TestTypes.LastInstanceSelectedTestTypes;

    let Selected_U_List_Types = U_SelectorTest.TestTypes.selectedTestTypes;

    let DisableButton = DisabledFilterButton_TestTypes_(
      Selected_U_List_Types,
      Selected_Context_TestTypes,
      Nav
    );

    let DisableMainFIlterBt = DisabledFilterButton(
      U_SelectorTest,
      this.props.ContextHeader,
      Nav
    );

    let TestTypes = U_SelectorTest.TestTypes.TestTypesList;
    return (
      <div className="menu-item-expand-block test-results">
        <div className="test-type-main-block">
          <div className="test-type-inrBlock">
            <div className="test-type-input-field">
              <div className="menu-title">
                <span className="test-type-title">Test Type</span>
                <span className="test-search-reload">
                  {this.props.ApiCalls.loadingFor == "tests" ? (
                    <i className="material-icons">cached</i>
                  ) : null}
                </span>

                <span className="test-count">
                  Tests Selected: {U_SelectorTest.SelectedTestList.length}/
                  {U_SelectorTest.ActualTestList.length !== 0
                    ? U_SelectorTest.ActualTestList.length
                    : null}
                </span>
              </div>
              <div className="menu-selector active-selector">
                <button
                  class={
                    U_SelectorTest.TestTypes.opentestType
                      ? "select-dropdown_activated"
                      : "select-dropdown"
                  }
                  onClick={() =>
                    TestTypes.length > 1 && !Nav.st_analysis
                      ? this.props.OpenOrCloseTestTypes()
                      : null
                  }
                  style={
                    TestTypes.length < 2 || Nav.st_analysis
                      ? { background: !Nav.st_analysis ? "#fff" : "#DCDCDC" }
                      : null
                  }
                >
                  <span class="Roster-Dropdown-text">
                    {this.TEstTypesSelections_TEXT(U_SelectorTest, Nav)}
                  </span>
                  {/* <div class="bec_tooltip">
                                                <div class="bec_tooltip_arrow"></div>
                                                <div class="bec_tooltip_content">Select Test Type</div>
                                            </div> */}
                </button>
                <div className="testTypeSelectedBlocksUI">
                  {Selected_U_List_Types == undefined
                    ? null
                    : Selected_U_List_Types.length > 1
                    ? this.returnSelectedTest_Types(Selected_U_List_Types)
                    : null}
                </div>

                {this.props.UniversalSelecter.TestTab.TestTypes.opentestType ? (
                  <div className="menu-dropdown-container">
                    <div className="menu-dropdown-list">
                      <div className="menu-dropdown-list-inr">
                        <ul>
                          <li
                            onClick={() => {
                              let i = "All";
                              let Check =
                                !this.props.UniversalSelecter.TestTab.TestTypes
                                  .selectAllTestTypes; // Check Values Based On CUrrent CheckBox Value
                              this.props.CheckOrUncheckTestTypeCheckBox(
                                Check,
                                i
                              );
                            }}
                          >
                            <div class="testTypesingleitem">
                              <div class="input-checkbox checkbox-lightBlue">
                                <input
                                  type="checkbox"
                                  checked={
                                    this.props.UniversalSelecter.TestTab
                                      .TestTypes.selectAllTestTypes
                                  }
                                  value={
                                    this.props.UniversalSelecter.TestTab
                                      .TestTypes.selectAllTestTypes
                                  }
                                />
                                <span class="checkbox"></span>
                              </div>
                              <span></span>
                            </div>
                            All
                          </li>

                          {this.testTypeResultsBody(U_SelectorTest, Nav)}
                        </ul>
                      </div>

                      <div
                        class="universal-select-filter"
                        style={{
                          borderTop: "1px solid #D6DBE5",
                          padding: "10px 0px 0px 0px",
                        }}
                      >
                        <div class="test-btns">
                          <div
                            class="cancel-btn float-left"
                            onClick={() => this.props.OpenOrCloseTestTypes()}
                          >
                            Cancel
                          </div>
                          <div class="apply-btn float-right">
                            <button
                              class="btn universal-selector-applyfilter"
                              className={
                                DisableButton
                                  ? "btn universal-selector-applyfilter disableFilter_us"
                                  : "btn universal-selector-applyfilter"
                              }
                              disabled={DisableButton}
                              onClick={() => {
                                this.props.DoneInTestTypeView();
                              }}
                            >
                              Done
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
        <div className="universal-test-search">
          <span className="test-search-filter">
            {U_SelectorTest.ActualTestList.length != 0 ? (
              <div className="menu-varient-search">
                <input
                  type="text"
                  value={U_SelectorTest.IpSearchvalue_InTest}
                  onChange={(txt) =>
                    this.FilterDropDownForTest(txt.target.value, "test")
                  }
                  placeholder="Search"
                  className={
                    U_SelectorTest.IpSearchvalue_InTest != undefined &&
                    U_SelectorTest.IpSearchvalue_InTest != null &&
                    U_SelectorTest.IpSearchvalue_InTest.length > 0
                      ? "roster_magnifier_search_bg_none"
                      : "roster_magnifier_search_test_bg"
                  }
                />
                {U_SelectorTest.IpSearchCancle__InTest ? (
                  <span
                    onClick={() => this.FilterDropDownForTest("", "test")}
                    className="menu-varient-search-cancel"
                  >
                    x
                  </span>
                ) : null}
              </div>
            ) : null}
          </span>
        </div>

        <div className="universal-test-results">
          <div className="universal-test-results-table">
            <div className="universal-test-results-table-outline">
              <div className="test-results-header">
                <div className="test-results-col" style={{ width: "20px" }}>
                  <span className="testTabCustomClass">
                    <label className="input-checkbox checkbox-lightBlue">
                      <input
                        checked={
                          this.props.UniversalSelecter.TestTab.selectAllTests
                        }
                        value={
                          this.props.UniversalSelecter.TestTab.selectAllTests
                        }
                        onClick={() => {
                          let i = "All"; // Test Result Index Value
                          let Check =
                            !this.props.UniversalSelecter.TestTab
                              .selectAllTests; // Check Values Based On CUrrent CheckBox Value
                          this.props.CheckOrUncheckTestCheckBox(Check, i);
                        }}
                        type="checkbox"
                      />
                      <span className="checkbox"></span>
                    </label>
                    <div className="bec_tooltip">
                      <div className="bec_tooltip_arrow"></div>
                      <div className="bec_tooltip_content">Select All Test</div>
                    </div>
                  </span>
                </div>
                <div
                  className="test-results-col"
                  style={{ width: "75px", cursor: "pointer" }}
                >
                  <span
                    className={
                      S_Column === "testName"
                        ? "activeSortingfield testTabCustomClass"
                        : "testTabCustomClass"
                    }
                  >
                    Name
                    <div className="bec_tooltip">
                      <div className="bec_tooltip_arrow"></div>
                      <div className="bec_tooltip_content">Test Name</div>
                    </div>
                  </span>

                  <span className="togglers">
                    <i
                      className={
                        S_Column === "testName"
                          ? S_Type === "desc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testName"
                          ? S_Type === "desc"
                            ? null
                            : this.ApplySortingOnTestData("testName", "desc")
                          : this.ApplySortingOnTestData("testName", "desc");
                      }}
                    >
                      expand_more
                    </i>
                    <i
                      className={
                        S_Column === "testName"
                          ? S_Type === "asc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testName"
                          ? S_Type === "asc"
                            ? null
                            : this.ApplySortingOnTestData("testName", "asc")
                          : this.ApplySortingOnTestData("testName", "asc");
                      }}
                    >
                      expand_less
                    </i>
                  </span>
                </div>
                <div className="test-results-col" style={{ width: "140px" }}>
                  <span
                    className={
                      S_Column === "testResults"
                        ? "activeSortingfield testTabCustomClass"
                        : "testTabCustomClass"
                    }
                  >
                    Number of Results
                    <div className="bec_tooltip">
                      <div className="bec_tooltip_arrow"></div>
                      <div className="bec_tooltip_content">
                        Number of Test Results Available
                      </div>
                    </div>
                  </span>

                  <span className="togglers">
                    <i
                      className={
                        S_Column === "testResults"
                          ? S_Type === "desc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testResults"
                          ? S_Type === "desc"
                            ? null
                            : this.ApplySortingOnTestData("testResults", "desc")
                          : this.ApplySortingOnTestData("testResults", "desc");
                      }}
                    >
                      expand_more
                    </i>
                    <i
                      className={
                        S_Column === "testResults"
                          ? S_Type === "asc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testResults"
                          ? S_Type === "asc"
                            ? null
                            : this.ApplySortingOnTestData("testResults", "asc")
                          : this.ApplySortingOnTestData("testResults", "asc");
                      }}
                    >
                      expand_less
                    </i>
                  </span>
                </div>
                <div className="test-results-col" style={{ width: "110px" }}>
                  <span
                    className={
                      S_Column === "testStartDate"
                        ? "activeSortingfield testTabCustomClass"
                        : "testTabCustomClass"
                    }
                  >
                    {Nav.test_status ? "Start Date" : "Earliest Date"}
                    <div className="bec_tooltip">
                      <div className="bec_tooltip_arrow"></div>
                      <div className="bec_tooltip_content">
                        Earliest Submission date
                      </div>
                    </div>
                  </span>

                  <span className="togglers">
                    <i
                      className={
                        S_Column === "testStartDate"
                          ? S_Type === "desc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testStartDate"
                          ? S_Type === "desc"
                            ? null
                            : this.ApplySortingOnTestData(
                                "testStartDate",
                                "desc"
                              )
                          : this.ApplySortingOnTestData(
                              "testStartDate",
                              "desc"
                            );
                      }}
                    >
                      expand_more
                    </i>
                    <i
                      className={
                        S_Column === "testStartDate"
                          ? S_Type === "asc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testStartDate"
                          ? S_Type === "asc"
                            ? null
                            : this.ApplySortingOnTestData(
                                "testStartDate",
                                "asc"
                              )
                          : this.ApplySortingOnTestData("testStartDate", "asc");
                      }}
                    >
                      expand_less
                    </i>
                  </span>
                </div>
                <div className="test-results-col" style={{ width: "95px" }}>
                  <span
                    className={
                      S_Column === "testEndDate"
                        ? "activeSortingfield testTabCustomClass"
                        : "testTabCustomClass"
                    }
                  >
                    {Nav.test_status ? "Due Date" : "Latest Date"}
                    <div className="bec_tooltip">
                      <div className="bec_tooltip_arrow"></div>
                      <div className="bec_tooltip_content">
                        Latest Submission date
                      </div>
                    </div>
                  </span>

                  <span className="togglers">
                    <i
                      className={
                        S_Column === "testEndDate"
                          ? S_Type === "desc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testEndDate"
                          ? S_Type === "desc"
                            ? null
                            : this.ApplySortingOnTestData("testEndDate", "desc")
                          : this.ApplySortingOnTestData("testEndDate", "desc");
                      }}
                    >
                      expand_more
                    </i>
                    <i
                      className={
                        S_Column === "testEndDate"
                          ? S_Type === "asc"
                            ? "material-icons greenColor"
                            : "material-icons"
                          : "material-icons"
                      }
                      onClick={() => {
                        S_Column === "testEndDate"
                          ? S_Type === "asc"
                            ? null
                            : this.ApplySortingOnTestData("testEndDate", "asc")
                          : this.ApplySortingOnTestData("testEndDate", "asc");
                      }}
                    >
                      expand_less
                    </i>
                  </span>
                </div>
              </div>
              <div className="test-results-body">
                {U_SelectorTest.TestList !== undefined ? (
                  U_SelectorTest.TestList.length > 0 ? (
                    <Scrollbars
                      autoHeight
                      autoHeightMin={54}
                      autoHeightMax={324}
                    >
                      {this.ReturnTestResultsBody()}{" "}
                    </Scrollbars>
                  ) : (
                    <div className="text-center test-norecords-found">
                      No Records Found
                    </div>
                  )
                ) : (
                  <div className="text-center test-norecords-found">
                    No Records Found
                  </div>
                )}
              </div>
            </div>
            {this.props.Pagination.totalPagesCount > 1 ? (
              <div className="test-results-pagination">
                <div className="selector-pagination-testTab">
                  <PaginationComponent
                    from="testTab"
                    Pagination={this.props.Pagination}
                    paginationbubbleCount={
                      this.props.Pagination.totalPagesCount
                    }
                  />
                </div>
              </div>
            ) : null}
          </div>
        </div>
        <div className="universal-select-filter">
          <div className="test-btns">
            <div
              className="cancel-btn float-left"
              onClick={() => {
                // this.FilterDropDownForTest('', 'test');
                this.props.CloseUniversalFilter();
              }}
            >
              Cancel
            </div>
            <div className="apply-btn float-right">
              <button
                className={
                  DisableMainFIlterBt
                    ? "btn universal-selector-applyfilter disableFilter_us"
                    : "btn universal-selector-applyfilter"
                }
                disabled={
                  DisableMainFIlterBt
                  // U_Selector.StudentsList.length == 0 ? true : false
                }
                onClick={() => this.TestTabOnClick()}
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  /**
   * triggers when Click On Apply Button.
   */
  TestTabOnClick() {
    let AccessToken = this.props.LoginDetails.JWTToken;
    let TestTab = this.props.UniversalSelecter.TestTab;
    let Nav = this.props.NavigationByHeaderSelection;
    let Context_Data = this.props.ContextHeader;
    let AllTestsSelected = this.props.UniversalSelecter.TestTab.selectAllTests;
    let SelectedTestIds = AllTestsSelected
      ? GetIds_of_Each_Object_In_The_Array(
          this.props.UniversalSelecter.TestTab.SelectedTestList,
          "componentCode",
          "test_tab"
        )
      : [];
    let Req_Payload = Request_PayloadFor_LineChart_Data(Nav, Context_Data);
    Req_Payload.componentCodeList = SelectedTestIds;

    this.props.ApplyFiltersInTestTab(
      AccessToken,
      Req_Payload,
      Nav.class,
      this.props.Universal
    );
  }
  /**
   *
   * @param {Column name} Column ;
   * @param {asc/desc} sortType ;
   * Sort test array data , enabled to all columns.
   */
  ApplySortingOnTestData(Column, sortType) {
    let items = JSON.parse(
      JSON.stringify(this.props.UniversalSelecter.TestTab.TestList)
    );
    let Arr = [];
    if (items.length != 0) {
      Arr = SortArray(items, Column, sortType);
      this.props.SaveTestDataAfterSorting(Arr, Column, sortType);
    }
  }
  /**
   *
   * @param {searching input value} Searchvalue
   * @param {"test" } type
   * method to  filter matched results.
   */
  FilterDropDownForTest(Searchvalue, type) {
    let Testlist = this.props.UniversalSelecter.TestTab.ActualTestList;
    let q = Searchvalue.toLowerCase();

    if (Testlist.length != 0) {
      Testlist = Testlist.filter(function (item) {
        return item.testName.toLowerCase().indexOf(q) >= 0;
      });
      this.props.StoreFilteredListInTest(Testlist, type, Searchvalue);
    }
  }

  CheckOrUncheckTest(Test) {
    return Test.check == undefined ? false : Test.check;
  }

  /**
   * If Test array is not empty then this will call & results will be returned
   */
  ReturnTestResultsBody() {
    var CiclkOfCheckbox = false;
    let TestTab = this.props.UniversalSelecter.TestTab.TestList;
    let Arr = [];
    let U_Selector = this.props.UniversalSelecter;
    let Pagination = this.props.Pagination;
    let TestsList = TestTab;

    // if (this.props.UniversalSelecter.TestTab.IpSearchvalue_InTest === '') {
    TestsList = TestTab.filter(function (item, i) {
      return i + 2 > Pagination.countStart && i < Pagination.countEnd;
    });
    // }
    if (Pagination.pageAt > 1) {
      TestsList.shift();
    }

    return TestsList.map((Test, i) => {
      return (
        <div
          key={i}
          className="test-results-row-set"
          onClick={() => {
            let Check = Test.check === undefined ? true : !Test.check;
            let SelectedElement = TestsList[i];
            this.props.CheckOrUncheckTestCheckBox(Check, SelectedElement);
          }}
        >
          <div className="test-results-row">
            <div className="test-results-col">
              <div className="input-checkbox checkbox-lightBlue">
                <input
                  checked={this.CheckOrUncheckTest(Test)}
                  value={Test.check}
                  type="checkbox"
                />
                <span className="checkbox"></span>
              </div>
            </div>
            <div className="test-results-col-full">{Test.testName}</div>
          </div>
          <div className="test-results-row">
            <div className="test-results-col" style={{ width: "20px" }}>
              &nbsp;
            </div>
            <div className="test-results-col" style={{ width: "75px" }}>
              &nbsp;
            </div>
            <div className="test-results-col" style={{ width: "140px" }}>
              {Test.testResults}
              {Test.testResults == 1 || Test.testResults == 0
                ? " Result"
                : " Results"}
            </div>
            <div className="test-results-col" style={{ width: "110px" }}>
              {DISPLAY_LOCAL_TIME_IN_UI === true
                ? convertUTCDateToLocalDate(
                    Test.testStartDate,
                    Test.testStartTime
                  )
                : Test.testStartDate}
            </div>
            <div className="test-results-col" style={{ width: "95px" }}>
              {DISPLAY_LOCAL_TIME_IN_UI === true
                ? convertUTCDateToLocalDate(Test.testEndDate, Test.testEndTime)
                : Test.testEndDate}
            </div>
          </div>
        </div>
      );
    });
  }
  render() {
    return (
      <li
        className={this.props.UniversalFilter === "test" ? "active-menu" : ""}
        // style={{ cursor: 'pointer' }}
      >
        <div className="menu-item-block">
          <div
            className="menu-item"
            onClick={() =>
              this.props.UniversalFilter === "test"
                ? this.props.CloseUniversalFilter()
                : this.props.OpenUniversalFilter("test")
            }
          >
            {/* <span className="menu-icon">
                        <i className="material-icons">assignment</i>
                    </span> */}
            <div>
              <img src={TestIcon} className="icon_dimensions" />
            </div>
            <span className="menu-name">Test</span>
            {this.props.UniversalFilter == "test" ? null : (
              <div className="bec_tooltip">
                <div className="bec_tooltip_arrow"></div>
                <div className="bec_tooltip_content">Select Test(s)</div>
              </div>
            )}
          </div>
          {this.TestSubElements()}
        </div>
      </li>
    );
  }
}
const mapStateToProps = ({ Authentication, Universal }) => {
  const { LoginDetails } = Authentication;
  const {
    UniversalFilter,
    UniversalSelecter,
    Pagination,
    ApiCalls,
    ContextHeader,
    NavigationByHeaderSelection,
  } = Universal;

  return {
    LoginDetails,
    Universal,
    UniversalFilter,
    UniversalSelecter,
    Pagination,
    ApiCalls,
    ContextHeader,
    NavigationByHeaderSelection,
    Universal,
  };
};

export default connect(mapStateToProps, {
  // Add Action Here
  OpenUniversalFilter,
  CheckOrUncheckTestCheckBox,
  CloseUniversalFilter,
  ApplyFiltersInTestTab,
  SaveTestDataAfterSorting,
  StoreFilteredListInTest,
  OpenOrCloseTestTypes,
  CheckOrUncheckTestTypeCheckBox,
  UncheckTestTypeByClickingOnDisplaySpan,
  DoneInTestTypeView,
  // ChangeTestTabPagination
})(TestTab);

function EventHandle() {
  return <span className="tooltiptext">Number of Test Results Available</span>;
}

/**
 *
 * @param {object} TabData  -- Test Tab data with current instance.
 * @param {object} ContextData --present context header data.
 * @returns {Boolean} true/false
 */
export function DisabledFilterButton(TabData, ContextData, Nav) {
  let Arr1 = TabData.SelectedTestList;
  let Arr2 = ContextData.TestTab.TestList;

  if (Nav.st_analysis) {
    let St_Test = Nav.student
      ? TabData.SingleTestAnalysis.Student.SelectedTest
      : Nav.class
      ? TabData.SingleTestAnalysis.Class.SelectedTest
      : Nav.school
      ? TabData.SingleTestAnalysis.School.SelectedTest
      : TabData.SingleTestAnalysis.District.SelectedTest;
    if (TabData.SelectedTestList.length == 0) {
      return true;
    } else if (Arr1[0] == undefined) {
      return false;
    } else return St_Test.componentCode == Arr1[0].componentCode;
  }

  Arr2 = Arr2 == undefined ? [] : Arr2.filter((item) => item.check);

  let SameArrays = false;
  if (TabData.SelectedTestList.length == 0) {
    return true;
  } else if (Arr1.length == Arr2.length) {
    let MatchedArr = [];
    Arr1.forEach((element) =>
      Arr2.forEach((element2) => {
        if (
          element.testName == element2.testName &&
          element.componentCode == element2.componentCode
        ) {
          MatchedArr.push(element);
        }
      })
    );
    return MatchedArr.length == TabData.SelectedTestList.length ? true : false;
  }
  //  else if (TabData.selectAllTests) {
  //     return true
  // }
  else return false;
}

/**
 *
 * @param {Array} ContextList
 * @param {Array} U_List
 *
 */
function DisabledFilterButton_TestTypes_(U_List, ContextList) {
  if (ContextList == undefined || U_List == undefined || U_List.length == 0) {
    return true;
  } else {
    if (ContextList.length == U_List.length) {
      let testTypeNotThere = false;

      for (var i = 0; i < ContextList.length; i++) {
        let notExist = true;

        let contxt = ContextList[i];
        for (var j = 0; j < U_List.length; j++) {
          let Ulist = U_List[i];
          if (Ulist.testTypeId == contxt.testTypeId) {
            notExist = false;
            break;
          }
        }

        if (notExist) {
          testTypeNotThere = true;
          break;
        }
      }

      return !testTypeNotThere;
    } else {
      return false;
    }
  }
}
