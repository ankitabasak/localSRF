import React, { Component } from 'react';
import '../../../../public/css/style.css';
import info_icon from '../../../../public/images/info_icon.svg';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import {
    ApplyFilterOnRoasterTab,
    GetGradesListOn_School
} from '../../../Redux_Actions/UniversalSelectorActions';

import CheckboxSearchDropdown from '../../CheckboxSearchDropdown/index.jsx';
import BuurRoster from './BuurRoster';
import {
    StoreFilteredListInRoster,
    SaveSelected_RosterGrade,
    SaveSelectedTeacher,
    SaveSelectedStudent,
    SaveSelected_CLass,
    SaveSelected_StudentData,
    ClickStudentDataInfoIcon
} from '../../../Redux_Actions/UniversalSelectorActions_Primary';

import {
    OpenSelectorInRoaster, SaveSelectedSchool, ApplyRoasterTabFilter,
    CloseUniversalFilter
} from '../../../Redux_Actions/UniversalSelectorActions_Secondary';


import PaginationComponent from '../../../Utils/UniversalSelector_Pagination';
import { READING_HISTORY_STUDENT_DATA } from '../../../Redux_Actions/ReadingHistoryActions';
import { ERROR_ANALYSIS_STUDENT_DATA } from '../../../Redux_Actions/ErrorAnalysisActions.jsx';
import { CLASS_READING_HISTORY_DATA } from '../../../Redux_Actions/C_ReadingHistoryActions.jsx';
import { Fluency_Chart_Api_Request, CLASS_FPO_API } from '../../../Redux_Actions/C_FlunecyActions.jsx';
import { CRB_Chart_API_Call } from '../../../Redux_Actions/CRB_Actions.jsx';
import {
    DISTRICT_FA_CHART_API_CALL, DFA_LOAD_ICON
} from "../../../Redux_Actions/District_FA_Action.jsx";
import {
    CLASS_EA_API,
    LOAD_STATUS_ICON
} from '../../../Redux_Actions/C_ErrorAnalysisAction.jsx';
import {
    School_Level_RLP_Chart_API,
    School_Class_Level_RLP_Chart_API,
    Sum_Sc_RLP_Chart_API
} from '../../../Redux_Actions/School_RlpActions.jsx';
import {
    SCHOOL_READING_HISTORY_DATA,
    SCHOOL_RH_ERRORHANDLING
} from "../../../Redux_Actions/School_ReadingHistoryAction.jsx";
import {
    School_EA_Dropdown
} from "../../../Redux_Actions/School_ErrorAnalysisAction.jsx";
import {
    CLASS_READING_LEVEL_PROGRESS,
    CLASS_READING_LEVEL_GRID_DATA
} from '../../../Redux_Actions/C_ReadingLevelAction.jsx';
import {
    District_Class_Level_RLP_Chart_API,
    District_Level_RLP_Chart_API,
    Sum_Dst_RLP_Chart_API
} from '../../../Redux_Actions/District_RlpActions.jsx';
import { S_Fluency_Chart_Data } from '../../../Redux_Actions/S_FluencyActions.jsx';
import { S_RLP_API_CALL } from '../../../Redux_Actions/S_ReadingLevelAction.jsx';
import { S_RB_API_CALL } from '../../../Redux_Actions/S_ReadingBehaviorActions.jsx';
import { DISTRICT_RH_ERRORHANDLING, DISTRICT_READING_HISTORY_DATA } from '../../../Redux_Actions/District_ReadingHistoryAction.jsx';
import {
    SCHOOL_FPOT_API_SUCCESS,
    LOAD_ICON,
    SCHOOL_FA_CHART_API_CALL,
    FA_LOAD_ICON,
    Sc_GRADES
} from "../../../Redux_Actions/School_FA_Action.jsx";
import {
    School_RB_Chart_API_Call,
    Show_loading_Icon,
    School_RB_Dropdown
} from "../../../Redux_Actions/School_RB_Actions.jsx";
import { getCommonHeaders } from '../../ReusableComponents/OrrReusableComponents';
import { schoolNameCondition } from './RosterUtils';

class Roster extends Component {

    constructor(props) {
        super(props);
        this.ApplyFilter = this.ApplyFilter.bind(this);
        this.CloseFilter = this.CloseFilter.bind(this);
        this.applyRoaster = this.applyRoaster.bind(this);
        this.StudentDataToolTip_OutsideClick = this.StudentDataToolTip_OutsideClick.bind(this);
        this.tooltipDisplayDistrict = this.tooltipDisplayDistrict.bind(this);
        this.StudentDataToolTip_Refs = null
        this.state = {
            SearchFocus: false
        }
    }

    componentDidMount() {
        document.addEventListener('mousedown', this.StudentDataToolTip_OutsideClick);
    }
    componentWillUnmount() {
        document.removeEventListener('mousedown', this.StudentDataToolTip_OutsideClick);
    }

    StudentDataToolTip_OutsideClick(event) {
        if (this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "roster") {
            if (event.target !== null && this.StudentDataToolTip_Refs !== null) {
                let Click_On_StudentDataTooltip = this.StudentDataToolTip_Refs.contains(event.target);

                Click_On_StudentDataTooltip ? null : this.props.ClickStudentDataInfoIcon("");
            }
        }
    }

    /**
     * Apply Button Action of roster tab.
     *
     */
    ApplyFilter() {
        let StdId = this.props.UniversalSelecter.SelectedStudentId;
        let SchoolId = this.props.UniversalSelecter.Selected_school_data.id;
        let ClassId = this.props.UniversalSelecter.Selected_class_data.id;
        let AccessToken = this.props.LoginDetails.JWTToken;
        this.props.ApplyFilterOnRoasterTab(AccessToken, SchoolId, ClassId, StdId);
    }
    /**
     * Apply Button Action of roster tab on dynamic roster changes.
     *
     */
    applyRoaster() {
        let selectedTab = this.props.NavigationByHeaderSelection;
        let Token = this.props.LoginDetails.JWTToken;
        if (selectedTab.student && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'student');
            if (selectedTab.readingHistory) {
                this.props.READING_HISTORY_STUDENT_DATA(Token, Req_Payload, 'student');
            } else if (selectedTab.errorAnalysis) {
                this.props.ERROR_ANALYSIS_STUDENT_DATA(Token, Req_Payload, 'student');
            } else if (selectedTab.rlp) {
                this.props.S_RLP_API_CALL(Token, Req_Payload, 'student');
            } else if (selectedTab.fluencyAnalysis) {
                this.props.S_Fluency_Chart_Data(Token, Req_Payload, 'student');
            } else if (selectedTab.readingBehaviors) {
                this.props.S_RB_API_CALL(Token, Req_Payload, 'student');
            } else if (selectedTab.Summary_Tab) {
                this.props.S_RLP_API_CALL(Token, Req_Payload, 'student');
            }
        } else if (selectedTab.class && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'class');
            if (selectedTab.readingHistory) {
                this.props.CLASS_READING_HISTORY_DATA(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.rlp) {
                this.props.CLASS_READING_LEVEL_PROGRESS(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.errorAnalysis) {
                let errorRecordType = {
                    allRecords: this.props.showRecord === 'all' ? true : false,
                    recentRecord: this.props.showRecord === 'rec' ? true : false
                };
                Req_Payload.errorRecordType = errorRecordType;
                this.props.CLASS_EA_API(Token, Req_Payload);
            } else if (selectedTab.fluencyAnalysis) {

                if (this.props.FluencyTabSelection.wcpm) {
                    this.props.Fluency_Chart_Api_Request(
                        Token,
                        Req_Payload
                    );
                }

                if (this.props.FluencyTabSelection.fpot) {
                    let dataRecordType = {
                        allRecords: this.props.progressOverTime.showRecord === 'all' ? true : false,
                        recentRecord: this.props.progressOverTime.showRecord === 'rec' ? true : false
                    };
                    Req_Payload.dataRecordType = dataRecordType
                    this.props.CLASS_FPO_API(Token,
                        Req_Payload
                    );
                }
            } else if (selectedTab.readingBehaviors) {
                this.props.CRB_Chart_API_Call(Token, Req_Payload)
            } else if (selectedTab.Summary_Tab) {
                this.props.CLASS_READING_LEVEL_PROGRESS(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            }
        } else if (selectedTab.school && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'school')
            if (selectedTab.readingHistory) {
                this.props.SCHOOL_RH_ERRORHANDLING({
                    isApiLoading: true,
                    isDataNotAvailable: false,
                    timeOut: false
                });
                this.props.SCHOOL_READING_HISTORY_DATA(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.rlp) {
                this.props.School_Level_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.fluencyAnalysis) {
                let grade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
                if (this.props.ScFTabSelection["fpot"]) {
                    let dataRecordType = {
                        allRecords:
                            this.props.School_fpot.showRecord === "all" ? true : false,
                        recentRecord:
                            this.props.School_fpot.showRecord === "rec" ? true : false
                    };
                };
                this.props.LOAD_ICON({
                    isApiLoading: true,
                    apiTimeOut: false,
                    hideChart: true
                });

                let gradePayLoad = {
                    internalFilter: Req_Payload.internalFilter,
                    externalFilter: Object.assign(Req_Payload.externalFilter, {
                        chartName: "ScFR"
                    })
                }
                this.props.Sc_GRADES(Token, gradePayLoad, this.props.ContextHeader.Roster_Tab.selectedRosterGrade,
                    'rec');

                if (this.props.ScFTabSelection["wcpm"]) {
                    this.props.FA_LOAD_ICON();
                    this.props.SCHOOL_FA_CHART_API_CALL(this.props.LoginDetails.JWTToken, {
                        ...Req_Payload
                    }, grade);
                }
            } else if (selectedTab.Summary_Tab) {
                this.props.Sum_Sc_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.errorAnalysis) {
                let errorRecordType = {
                    allRecords: this.props.showRecordSea === 'all' ? true : false,
                    recentRecord: this.props.showRecordSea === 'rec' ? true : false
                };
                let payload = {
                    ["errorRecordType"]: errorRecordType,
                    internalFilter: Req_Payload.internalFilter,
                    externalFilter: Object.assign(Req_Payload.externalFilter, {
                        chartName: "ScEA"
                    })
                };
                this.props.School_EA_Dropdown(this.props.LoginDetails.JWTToken, payload, this.props.ContextHeader.Roster_Tab.selectedRosterGrade);
            } else if (selectedTab.readingBehaviors) {
                let grade = this.props.ContextHeader.Roster_Tab.selectedRosterGrade && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.length > 0 && this.props.ContextHeader.Roster_Tab.selectedRosterGrade.replace('grade_', '').toLocaleUpperCase()
                this.props.Show_loading_Icon();
                let payLoad = {
                    internalFilter: Req_Payload.internalFilter,
                    externalFilter: Object.assign(Req_Payload.externalFilter, {
                        chartName: "ScRB"
                    })
                }
                this.props.School_RB_Dropdown(
                    this.props.LoginDetails.JWTToken,
                    payLoad,
                    grade
                );
            }

        } else if (selectedTab.district && !(selectedTab.Assessement)) {
            let Req_Payload = getCommonHeaders(this.props, 'district');
            if (selectedTab.rlp) {

                this.props.District_Level_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.readingHistory) {
                this.props.DISTRICT_RH_ERRORHANDLING({
                    isApiLoading: true,
                    isDataNotAvailable: false,
                    timeOut: false
                });
                this.props.DISTRICT_READING_HISTORY_DATA(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.Summary_Tab) {
                this.props.Sum_Dst_RLP_Chart_API(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            } else if (selectedTab.fluencyAnalysis) {
                this.props.DFA_LOAD_ICON();
                this.props.DISTRICT_FA_CHART_API_CALL(
                    this.props.LoginDetails.JWTToken,
                    Req_Payload
                );
            }
        }
    }
    /* Filtering Schools and Class List On Name */
    /**
     *
     * @param {Search input value} Searchvalue
     * @param {school/class} type
     */
    FilterDropDownList(Searchvalue, type) {
        let U_Selecter =
            this.props.NavigationByHeaderSelection.Summary_Reports ?
                this.props.UniversalSelecter.Summary_Roster_Data :
                this.props.UniversalSelecter.Roster_Data;
        let List =
            type == 'school'
                ? U_Selecter.ActualSchools
                : type == 'class'
                    ? U_Selecter.ActualClasses
                    : type == 'teacher'
                        ? U_Selecter.ActualTeachers
                        : type == 'student_data'
                            ? U_Selecter.ActualStudentDataList : U_Selecter.ActualStudents;
        let q = Searchvalue.toLowerCase();

        List = List.filter(function (item) {
            return (
                item.name.toLowerCase().indexOf(q) >= 0
            )
        });
        this.props.StoreFilteredListInRoster(List, type, Searchvalue);
        return;
    }

    /**
    *
    * @param {schools array} Schools
    * @param {Object} U_Selector
    * Return Schools By applying pagination.
    */

    ReturnSchoolsList(Schools, U_Selector, SelectedSchool, isDistrictAdmin, Nav, RosterData) {
        let Pagination = this.props.Pagination;
        let SchoolsList = Schools;
        /* filtering schools list which satisfies pagination requirement. */
        SchoolsList = Schools.length !== 0 ? Schools.filter(function (item, i) {
            return (i + 1) > Pagination.countStart && i < Pagination.countEnd;
        }) : [];
        return <div className="menu-dropdown-container">
            <div
                className="menu-varient-search">
                <input type="text"
                    value={U_Selector.Roster.IpSearchvalue}
                    onChange={(txt) => this.FilterDropDownList(txt.target.value, 'school')}
                    placeholder="Search" className={U_Selector.Roster.IpSearchvalue != undefined && U_Selector.Roster.IpSearchvalue != null && U_Selector.Roster.IpSearchvalue.length > 0 ? "roster_magnifier_search_bg_none" : "roster_magnifier_search_bg"} />
                {U_Selector.Roster.IpSearchCancle ?
                    <span
                        onClick={() => this.FilterDropDownList('', 'school')}
                        className="menu-varient-search-cancel">
                        x
                    </span> : null}
            </div>
            <div className="menu-dropdown-list">
                <div className="menu-dropdown-list-inr">

                    <ul>
                        {isDistrictAdmin && SchoolsList.length > 0 ? <li value="All"
                            style={{ backgroundColor: SelectedSchool === 'All' && Nav.Summary_Reports ? "#d0d6e1" : "" }}
                            onClick={(txt) => {
                                // if (SelectedSchool !== 'All') {
                                let check = SelectedSchool == "All";
                                let AccessToken = this.props.LoginDetails.JWTToken;
                                let Dateterm = this.props.ContextHeader.Date_Tab.selectedterm_Obj;
                                let Current_Selected_Sc_List = RosterData.SchoolIds;
                                let FromDist_Report = false;
                                let SchoolAdmin = this.props.ContextHeader.User_Role == "SCHOOL_ADMIN";
                                this.props.SaveSelectedSchool("All", 0, !check, AccessToken, Dateterm, FromDist_Report, Current_Selected_Sc_List, SchoolAdmin)
                                // }
                            }} >
                            {!Nav.Summary_Reports && <div className="rosterTabStudentList">
                                <div
                                    className="input-checkbox checkbox-lightBlue">
                                    <input
                                        checked={SelectedSchool == "All"}
                                        value={SelectedSchool == "All"}
                                        type="checkbox" />
                                    <span className="checkbox"></span>
                                </div>
                            </div>}
                            All</li> : null}
                    </ul>
                    <ul>
                        <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={210}>
                            {SchoolsList.length === 0 ? <li>No Records Available</li> :
                                SchoolsList.map((item, i) =>
                               
                                    <li className={RosterData.SelectedSchool && item.id == RosterData.SelectedSchool.id?"ar_reporting_roster_selctedbg":""}
                                        onClick={(txt) => {
                                            if (RosterData !== item.id || isDistrictAdmin) {
                                                let AccessToken = this.props.LoginDetails.JWTToken;
                                                let Dateterm = this.props.ContextHeader.Date_Tab.selectedterm_Obj;
                                                let FromDist_Report = false;
                                                let Current_Selected_Sc_List = RosterData.SchoolIds;
                                                let SchoolAdmin = this.props.ContextHeader.User_Role == "SCHOOL_ADMIN";
                                                !isDistrictAdmin && this.FilterDropDownList('', 'school')
                                                item.districtId =this.props.ContextHeader.Roster_Tab.SelectedDistrict.id;
                                                item.districtName =this.props.ContextHeader.Roster_Tab.SelectedDistrict.name;
                                                this.props.SaveSelectedSchool(item, i, !item.check, AccessToken, Dateterm, FromDist_Report, Current_Selected_Sc_List, SchoolAdmin)
                                            }
                                        }} value={item.id} key={i}>

                                        {isDistrictAdmin && !Nav.Summary_Reports ? <div className="rosterTabStudentList">
                                            <div
                                                className="input-checkbox checkbox-lightBlue"
                                            >
                                                <input
                                                    checked={item.check == undefined ? false : item.check}
                                                    value={item.check == undefined ? false : item.check}
                                                    type="checkbox" />
                                                <span className="checkbox"></span>
                                            </div>
                                        </div> : null}
                                        <span></span>

                                        {item.name}</li>
                                )}
                        </Scrollbars>
                    </ul>
                    {Pagination.totalPagesCount > 1 && U_Selector.Roster.OpenScoolDropDown ?
                        <PaginationComponent
                            Pagination={Pagination}
                            paginationbubbleCount={Pagination.totalPagesCount} />
                        // this.ReturnPaginationMain(Pagination, Schools)
                        : null}
                </div>
            </div>
        </div >
    }

    /**
    *
    * @param {schools array} Grades
    * @param {Object} U_Selector
    * Return Schools By applying pagination.
    */

    ReturnGradeList(GradeList, U_Selector, SelectedGrade, isDistrictAdmin, isSchoolAdmin, Nav) {
        const RosterGradeList = GradeList;
        return <div className="menu-dropdown-container">
            <div className="menu-dropdown-list">
                <div className="menu-dropdown-list-inr">
                    {(isDistrictAdmin || isSchoolAdmin) && Nav.Summary_Reports ? <ul>
                        <li value="All"
                            style={{ backgroundColor: SelectedGrade === 'All' ? "#d0d6e1" : "" }}
                            onClick={(txt) => {
                                SelectedGrade === "All" ? null :
                                    this.props.SaveSelected_RosterGrade("All")
                            }}>
                            All</li>
                    </ul> : null}
                    <ul >
                        <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={210}>
                            {RosterGradeList.length == 0 ? <li>No Records Available</li> :
                                RosterGradeList.map((item, i) =>
                                    <li
                                        style={{ backgroundColor: item.grade === SelectedGrade ? "#d0d6e1" : "" }}
                                        onClick={(txt) => {
                                            if (SelectedGrade !== item.grade) {
                                                this.props.SaveSelected_RosterGrade(item)
                                            }
                                        }} value={item.grade} key={i}>
                                        {convertGrade(item.grade)}</li>
                                )}
                        </Scrollbars>
                    </ul>
                </div>
            </div>
        </div>
    }

    /**
     *
     * @param {Object} U_Selector
     * @param {Array} Teacher
     * @returns {JSX}
     */
    ReturnTeacherList(U_Selector, Teacher, SelectedTeacher, RosterData, Nav) {
        let Pagination = this.props.Pagination;
        let TeacherList = Teacher;

        let Selec_T_List = RosterData.TeacherIds;
        let Act_T_List = RosterData.ActualTeachers;

        let AllChecked_T = SelectedTeacher == "All" || Selec_T_List.length == Act_T_List.length;

        if (U_Selector.Roster.IpSearchvalue === '') {
            TeacherList = Teacher.length !== 0 ? Teacher.filter(function (item, i) {
                return (i + 1) > Pagination.countStart && i < Pagination.countEnd;
            }) : [];
        }
        return <div className="menu-dropdown-container">
            {/* {U_Selector.TeachersList.length != 0 ? */}
            <div
                className="menu-varient-search">
                <input type="text"
                    value={U_Selector.Roster.IpSearchvalue}
                    onChange={(txt) => this.FilterDropDownList(txt.target.value, 'teacher')}
                    placeholder="Search" className={U_Selector.Roster.IpSearchvalue != undefined && U_Selector.Roster.IpSearchvalue != null && U_Selector.Roster.IpSearchvalue.length > 0 ? "roster_magnifier_search_bg_none" : "roster_magnifier_search_bg"} />
                {U_Selector.Roster.IpSearchCancle ?
                    <span
                        onClick={() => this.FilterDropDownList('', 'teacher')}
                        className="menu-varient-search-cancel">
                        x
                    </span> : null}
            </div>

            <div className="menu-dropdown-list">
                <div className="menu-dropdown-list-inr">

                    <ul>
                        {TeacherList.length === 0 ?
                            null
                            : <li value="All"
                                style={{ backgroundColor: SelectedTeacher === 'All' ? "#d0d6e1" : "" }}
                                onClick={(txt) => {
                                    // let SelectedAll = this.AllStudentsCheckBox()
                                    let check = !AllChecked_T;
                                    !check && Nav.Summary_Reports ? null : this.props.SaveSelectedTeacher("All", 0, check)
                                }} >
                                {!Nav.Summary_Reports ? <div className="rosterTabStudentList">
                                    <div
                                        className="input-checkbox checkbox-lightBlue">
                                        <input
                                            checked={AllChecked_T}
                                            value={AllChecked_T}
                                            type="checkbox" />
                                        <span className="checkbox"></span>
                                    </div>
                                </div> : null}
                                All</li>}
                    </ul>
                    <ul>
                        <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={210}>
                            {TeacherList.length === 0 ? <li>No Records Available</li> :
                                TeacherList.map((item, i) =>
                                    <li
                                        style={{ backgroundColor: item.id === SelectedTeacher.id ? "#d0d6e1" : "" }}
                                        onClick={(txt) => {
                                            let check = !item.check;
                                            this.props.SaveSelectedTeacher(item, i, check)
                                        }} value={item.id} key={i}>

                                        {Nav.Summary_Reports ? null : <div className="rosterTabStudentList">
                                            <div
                                                className="input-checkbox checkbox-lightBlue"
                                            >
                                                <input
                                                    checked={item.check}
                                                    value={item.check}
                                                    type="checkbox" />
                                                <span className="checkbox"></span>
                                            </div>
                                        </div>}
                                        <span></span>

                                        {item.name}</li>
                                )}
                        </Scrollbars>
                    </ul>
                    {Pagination.totalPagesCount > 1 && U_Selector.Roster.OpenTeacherDropDown ?

                        <PaginationComponent
                            Pagination={Pagination}
                            paginationbubbleCount={Pagination.totalPagesCount} />
                        : null}
                </div>
            </div>
        </div>
    }
    /**
     *
     * @param { Object} U_Selector -- reducer props of Universal selector Object .
     * @param {Array} Class -- Class List
     * @returns {JSX.Element}
     * Return Class By applying pagination.
     */
    ReturnClassList(U_Selector, Class, SelectedClass, RosterData, Nav) {

        let Pagination = this.props.Pagination;
        let ClassList = Class;
        let Selec_CS_List = RosterData.ClassIds;
        let Act_CS_List = RosterData.ActualClasses;
        let AllChecks_CS = Selec_CS_List.length == Act_CS_List.length || RosterData.SelectedClass == "All";
        ClassList = Class.length != 0 ?
            Class.slice(Pagination.countStart, Pagination.countEnd) : [];
        let IsteacherRole = this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER";
        return <div className="menu-dropdown-container">
            {Act_CS_List.length != 0 ?
                <div
                    className="menu-varient-search">
                    <input type="text"
                        value={U_Selector.Roster.IpSearchvalue}
                        onChange={(txt) => this.FilterDropDownList(txt.target.value, 'class')}
                        placeholder="Search" className={U_Selector.Roster.IpSearchvalue != undefined && U_Selector.Roster.IpSearchvalue != null && U_Selector.Roster.IpSearchvalue.length > 0 ? "roster_magnifier_search_bg_none" : "roster_magnifier_search_bg"} />
                    {U_Selector.Roster.IpSearchCancle ?
                        <span
                            onClick={() => this.FilterDropDownList('', 'class')}
                            className="menu-varient-search-cancel">
                            x
                    </span> : null}
                </div>
                : null}
            <div className="menu-dropdown-list">
                <div className="menu-dropdown-list-inr">

                    <ul>
                        {ClassList.length === 0 || IsteacherRole ?
                            null
                            : <li value="All"
                                style={{ backgroundColor: SelectedClass === 'All' ? "#d0d6e1" : "" }}
                                onClick={(txt) => {
                                    let ClassObj = "All";
                                    let check = !AllChecks_CS;
                                    this.props.SaveSelected_CLass(ClassObj, 0, check)
                                }} >
                                {!Nav.Summary_Reports ? <div className="rosterTabStudentList">
                                    <div
                                        className="input-checkbox checkbox-lightBlue">
                                        <input
                                            checked={AllChecks_CS}
                                            value={AllChecks_CS}
                                            type="checkbox" />
                                        <span className="checkbox"></span>
                                    </div>
                                </div> : null}
                                All</li>}
                    </ul>

                    <ul>
                        {/* <li>Select Class</li> */}
                        <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={210}>
                            {ClassList.length === 0 ? <li>No Records Available</li> :
                                ClassList.map((item, indx) =>
                                    <li
                                        style={{ backgroundColor: item.id === SelectedClass.id ? "#d0d6e1" : "" }}
                                        onClick={(txt) => {

                                            if (IsteacherRole && RosterData.SelectedClass.id == item.id) {
                                            } else {
                                                const ClassObj = item;
                                                let check = item.check === undefined ? false : !item.check
                                                this.props.SaveSelected_CLass(ClassObj, indx, check)
                                            }


                                        }} value={item.id} key={indx}>
                                        {IsteacherRole || Nav.Summary_Reports ? null : <div className="rosterTabStudentList">
                                            <div
                                                className="input-checkbox checkbox-lightBlue"
                                            >
                                                <input
                                                    checked={item.check}
                                                    value={item.check}
                                                    type="checkbox" />
                                                <span className="checkbox"></span>
                                            </div>
                                        </div>}
                                        <span></span>
                                        {item.name}
                                    </li>
                                )}
                        </Scrollbars>
                    </ul>
                    {Pagination.totalPagesCount > 1 && U_Selector.Roster.OpenClassDropDown ?
                        // this.ReturnPaginationMain(Pagination, Class)
                        <PaginationComponent
                            Pagination={Pagination}
                            paginationbubbleCount={Pagination.totalPagesCount} />
                        : null}
                </div>
            </div>
        </div>
    }
    /**
     *
     * @param {Array} StdList --Students Array
     * @param {Object} U_Selector
     * @returns {JSX.Element}
     *  Return StudentsList By applying pagination.
     */

    RetunStudentsList(StdList, U_Selector, SelectedStudent, RosterData) {


        let Pagination = this.props.Pagination;
        let StudentsList = StdList;

        StudentsList = StdList.length != 0 ?
            StdList.slice(Pagination.countStart, Pagination.countEnd) : [];

        let All_Stds_Checked = this.AllStudentsCheckBox(RosterData);

        return <div className="menu-dropdown-list-inr">
            <ul>
                {StudentsList.length === 0 ?
                    null
                    : <li value="All"
                        style={{ backgroundColor: SelectedStudent === 'All' ? "#d0d6e1" : "" }}
                        onClick={(txt) => {
                            let SelectedAll = !All_Stds_Checked
                            /**
                             * 1-> selected student
                             * 2-> student index
                             * 3-> true or false
                             */
                            this.props.SaveSelectedStudent("All", 0, SelectedAll);
                        }}
                    >
                        <div className="rosterTabStudentList">
                            <div
                                className="input-checkbox checkbox-lightBlue"
                            >
                                <input
                                    checked={All_Stds_Checked}
                                    value={All_Stds_Checked}
                                    type="checkbox" />
                                <span className="checkbox"></span>
                            </div>
                        </div>
                        All</li>}
            </ul>
            <ul>
                <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={210}>
                    {StudentsList.length === 0 ? <li>No Records Available</li> :

                        StudentsList.map((item, indx) =>
                            <li
                                style={{ backgroundColor: item.id === SelectedStudent.id ? "#d0d6e1" : "" }}
                                onClick={(txt) => {
                                    // if (item.id !== SelectedStudent.id) {
                                    let Student = item;
                                    let check = item.check === undefined ? false : !item.check
                                    this.props.SaveSelectedStudent(Student, indx, check);
                                    // }
                                }} value={item.id} key={indx}>
                                <div className="rosterTabStudentList">
                                    <div
                                        className="input-checkbox checkbox-lightBlue"
                                    >
                                        <input
                                            checked={item.check}
                                            value={item.check}
                                            type="checkbox" />
                                        <span className="checkbox"></span>
                                    </div>
                                </div>
                                <span></span>
                                {item.name}
                            </li>
                        )}
                </Scrollbars>
            </ul>
            {Pagination.totalPagesCount > 1 && U_Selector.Roster.OpenStudentDropDown ?
                // this.ReturnPaginationMain(Pagination, StdList)
                <PaginationComponent
                    Pagination={Pagination}
                    paginationbubbleCount={Pagination.totalPagesCount} />
                : null}
        </div>
    }



    /**
    *
    * @param { Object} U_Selector -- reducer props of Universal selector Object .
    * @param {Array} Class -- Class List
    * @returns {JSX.Element}
    * Return Class By applying pagination.
    */
    ReturnStudentDataList(U_Selector, Class, SelectedStudentData, RosterData) {

        let Pagination = this.props.Pagination;
        let ClassList = Class;
        let Selec_CS_List = RosterData.StudentData_cls_ids;
        let Act_CS_List = RosterData.StudentData_cls;
        let AllChecks_CS = (Selec_CS_List.length === 0 && Act_CS_List.length > 1 && RosterData.SelectedStudentData !== "Select Class") || RosterData.SelectedStudentData == "All";

        ClassList = Class.length != 0 ?
            Class.slice(Pagination.countStart, Pagination.countEnd) : [];

        return <div className="menu-dropdown-container">
            {Act_CS_List.length != 0 ?
                <div
                    className="menu-varient-search">
                    <input type="text"
                        value={U_Selector.Roster.IpSearchvalue}
                        onChange={(txt) => this.FilterDropDownList(txt.target.value, 'student_data')}
                        placeholder="Search" className={U_Selector.Roster.IpSearchvalue != undefined && U_Selector.Roster.IpSearchvalue != null && U_Selector.Roster.IpSearchvalue.length > 0 ? "roster_magnifier_search_bg_none" : "roster_magnifier_search_bg"} />
                    {U_Selector.Roster.IpSearchCancle ?
                        <span
                            onClick={() => this.FilterDropDownList('', 'student_data')}
                            className="menu-varient-search-cancel">
                            x
                    </span> : null}
                </div>
                : null}
            <div className="menu-dropdown-list">
                <div className="menu-dropdown-list-inr">

                    <ul>
                        {ClassList.length === 0 ?
                            null
                            : <li value="All"
                                onClick={(txt) => {
                                    let ClassObj = "All";
                                    let check = !AllChecks_CS
                                    this.props.SaveSelected_StudentData(ClassObj, 0, check)
                                }} >
                                <div className="rosterTabStudentList">
                                    <div
                                        className="input-checkbox checkbox-lightBlue">
                                        <input
                                            checked={AllChecks_CS}
                                            value={AllChecks_CS}
                                            type="checkbox" />
                                        <span className="checkbox"></span>
                                    </div>
                                </div>
                                All</li>}
                    </ul>


                    <ul className="studentDataFillterBlock">
                        {ClassList.length === 0 ? <li>No Records Available</li> :

                            ClassList.sort(
                                (a, b) => {
                                    return a.name > b.name ? 1 : -1;
                                }
                            ).map((item, indx) =>

                                <li
                                    style={{ backgroundColor: item.id === SelectedStudentData.id ? "#d0d6e1" : "" }}
                                    onClick={(txt) => {

                                        //  else {
                                        const ClassObj = item;
                                        let check = item.check === undefined ? false : !item.check
                                        this.props.SaveSelected_StudentData(ClassObj, indx, check)
                                        // }


                                    }} value={item.id} key={indx}>
                                    <div className="rosterTabStudentList">
                                        <div
                                            className="input-checkbox checkbox-lightBlue"
                                        >
                                            <input
                                                checked={item.check}
                                                value={item.check}
                                                type="checkbox" />
                                            <span className="checkbox"></span>
                                        </div>
                                    </div>
                                    <span></span>
                                    <span><span>{item.name}</span>
                                        {item.isStudentInMultipleSchools ? <div className="bec_tooltip">
                                            <div className="bec_tooltip_arrow"></div>
                                            <div className="bec_tooltip_content">
                                                {item.teacherAndSchool !== null && item.teacherAndSchool !== undefined ? item.teacherAndSchool : null}
                                            </div>
                                        </div> : null}
                                    </span>
                                </li>

                            )}
                    </ul>
                    {Pagination.totalPagesCount > 1 && U_Selector.Roster.OpenStudentDataDropDown ?
                        // this.ReturnPaginationMain(Pagination, Class)
                        <PaginationComponent
                            Pagination={Pagination}
                            paginationbubbleCount={Pagination.totalPagesCount} />
                        : null}
                </div>
            </div>
        </div>
    }

    /**
     * will return true or false for all(all selected) check box in roster tab.
     *
     */
    AllStudentsCheckBox(Roster_Data) {
        let Nav = this.props.NavigationByHeaderSelection;
        return Roster_Data.ActualStudents.length == Roster_Data.StudentIds.length
    }

    /**
     * Action to close universal filter Tab.
     */
    CloseFilter() {
        this.props.CloseUniversalFilter('FromCLoseFIlter');
    }

    /**
     * Action to show tool tip for ellipsis names
     */

    tooltipDisplay(tooltipName) {

        let contextTooltip = null;
        if (tooltipName !== null && tooltipName !== undefined) {
            tooltipName.length > 24 ? contextTooltip =
                <div className="bec_tooltip">
                    <div className="bec_tooltip_arrow"></div>
                    <div className="bec_tooltip_content">
                        {tooltipName}
                    </div>
                </div>
                : null;
        }

        return contextTooltip;
    }

    tooltipDisplayDistrict(message) {
        return <div className="bec_tooltip">
            <div className="bec_tooltip_arrow"></div>
            <div className="bec_tooltip_content">
                {message ? message : "School level must be selected."}
            </div>
        </div>
    }

    /**
     * @param {String}
     *
     * when user selects any items from respective list , will check if he used search option, if yes we need to clear that search option after select any one of the list.
     *
     */

    ClearIpSearchValue_If_Any(listType) {
        if (this.props.UniversalSelecter.Roster.IpSearchvalue !== '') {
            this.FilterDropDownList('', listType);
        }
    }

    OpenSelectorFrom_School(fromContext, Call_Get_SChool_Details_Api, selected_Sc, AccessToken, Dateterm, FromDist_Report) {

    };

    render() {
        let Nav = this.props.NavigationByHeaderSelection;
        if (Nav.usageReport) {
            return (<BuurRoster
              CloseUniversalFilter={this.props.CloseUniversalFilter}
            />);
        }
        let Token = '';
        const {UniversalFilter}= this.props;
        let U_Selector = this.props.UniversalSelecter;
        let RosterData =
            Nav.Summary_Reports ? U_Selector.Summary_Roster_Data :
                U_Selector.Roster_Data


        let ActualSchoolList = RosterData.ActualSchools;
        let SchoolsList = RosterData.schoolsList;
        let School_Ids = RosterData.SchoolIds;
        let SelectedSchool = RosterData.SelectedSchool; 
        

        let RosterGradeList = RosterData.GradesList;
        let SelectedGrade = //Nav.Summary_Reports ? RosterData.summaryReportsGrade : 
            RosterData.SelectedGrade;

        let ActualTeachersList = RosterData.ActualTeachers;
        let TeachersList = RosterData.TeachersList;
        let SelectedTeacher = RosterData.SelectedTeacher;

        let ClassList = RosterData.ClassList;
        let ActualClassList = RosterData.ActualClasses;
        let SelectedClass = RosterData.SelectedClass;

        let StudentsList = RosterData.StudentsList;
        let Universal_StudentsDataList = RosterData.StudentsDataList;
        let Universal_ActualStudentDataList = RosterData.ActualStudentDataList;
        let Actu_Stds_List = RosterData.ActualStudents
        let SelectedStudent = RosterData.SelectedStudent;

        let Loading = this.props.ApiCalls.loadingFor;


        let DIsableApplyButton = UniversalFilter == "" || DisabledFilterButton(U_Selector,
            this.props.ContextHeader, Nav, Loading, RosterData);
        let isDistrictAdmin = this.props.ContextHeader.User_Role == "DISTRICT_ADMIN";
        let isSchoolAdmin = !isDistrictAdmin && this.props.ContextHeader.User_Role == "SCHOOL_ADMIN";

        let SelectedStudentData = RosterData.SelectedStudentData;

        let TeacherRole = this.props.LoginDetails.UserRole == "TEACHER" || this.props.LoginDetails.UserRole == "PRIMARY_TEACHER";

        let isPastDistrictTerm = this.props.isPastDistrictTerm
        // let isInSummaryReports = Nav.Summary_Reports;
        return <div className={Nav.Summary_Reports ? "menu-item-expand-block ar-menu-item-expand-block" : "menu-item-expand-block"}>
            <div className="menu-item-expand-block-inr">
                {
                    // TeacherRole || (this.props.LoginDetails.UserRole == "SCHOOL_ADMIN" &&
                    (ActualSchoolList.length == 0 || ActualSchoolList.length == 1) || (ActualSchoolList.length > 1 && TeacherRole && Nav.student)
                        //  )
                        ? null :
                        <div className="universal-input-field">
                            <div className="menu-title">
                                School
                        <span className="data-refresh">
                                    {Loading == "school" || this.props.ApiCalls.getschools_Loader ?
                                        <i className="material-icons">autorenew</i>
                                        : null}
                                </span>
                            </div>
                            <div className={U_Selector.Roster.OpenScoolDropDown ?
                                "menu-selector active-selector" : "menu-selector"} >
                                <button style={{
                                    background: schoolNameCondition(SelectedSchool) ? "" : ActualSchoolList.length == 1 ?
                                        "#FFF" : ""
                                }}
                                    onClick={() => {

                                        if (ActualSchoolList.length > 1) {

                                            let selected_Sc = RosterData.SelectedSchool;
                                             
                                            // selected_Sc.districtName =RosterData.SelectedSchool.name;
                                            let Call_Get_SChool_Details_Api = U_Selector.Roster.OpenScoolDropDown &&
                                                this.props.ContextHeader.User_Role == "DISTRICT_ADMIN" &&
                                                RosterData.SchoolIds.length == 1;
                                          if (Call_Get_SChool_Details_Api) {
                                                selected_Sc = RosterData.schoolsList.find(item => item.id == selected_Sc.id);
                                            }
                                            let AccessToken = this.props.LoginDetails.JWTToken;
                                            let Dateterm = this.props.ContextHeader.Date_Tab.selectedterm_Obj;
                                            let FromDist_Report = false;

                                            //logic added for get CurrentTermObj in DA single selection of schoool in roster or roster/details/schoolLevel api STARTS
                                            let DateTermsforSchoolRoasterInDistrict = this.props.LastActiveUniversalProps.Date_TabFullDetails;
                                            let currentTermID = this.props.currentTermID;
                                            let CurrentTermObj = {}
                                            if (Array.isArray(DateTermsforSchoolRoasterInDistrict)) {
                                                DateTermsforSchoolRoasterInDistrict.map(item => {
                                                    if (item.termId == currentTermID) {
                                                        CurrentTermObj = { ...item };
                                                    }
                                                });
                                            }
                                            //logic added for get CurrentTermObj in DA single selection of schoool in roster or roster/details/schoolLevel api ENDS
                                            this.OpenSelectorFrom_School('school', Call_Get_SChool_Details_Api, selected_Sc, AccessToken, Dateterm, FromDist_Report);
                                            this.props.OpenSelectorInRoaster('school', Call_Get_SChool_Details_Api, selected_Sc, AccessToken, CurrentTermObj, FromDist_Report);
                                            this.ClearIpSearchValue_If_Any('school')
                                        }
                                    }}
                                    className="select-dropdown">
                                    <span className="Roster-Dropdown-text">
                                        {schoolNameCondition(SelectedSchool) ?
                                            DisplaySelectedRosterItem(SelectedSchool.name) : SelectedSchool == "All" ? "All" :
                                                typeof SelectedSchool !== "object" ? SelectedSchool : 'Select School'}
                                        {schoolNameCondition(SelectedSchool) && this.tooltipDisplay(SelectedSchool.name)}
                                    </span>
                                </button>
                                {this.ReturnSchoolsList(SchoolsList, U_Selector, SelectedSchool, isDistrictAdmin, Nav, RosterData)}
                            </div>
                        </div>}
                {/* Grades Block */}
                {TeacherRole && RosterGradeList.length === 1 ?
                    null :
                    <div className="universal-input-field">
                        <div className="menu-title">
                            Grade
        <span className="data-refresh">
                                {Loading == "grade" ?
                                    <i className="material-icons">autorenew</i> : null}
                            </span>
                        </div>
                        <div className={U_Selector.Roster.OpenGradeDropDown ?
                            "menu-selector active-selector" : "menu-selector"}>
                            <button
                                style={{
                                    background: RosterGradeList.length <= 1 ?
                                        "#FFF" : ""
                                }}
                                // className={ Nav.district && Nav.test_status && (School_Ids.length > 1 || School_Ids.length == 0) ? "disable_us" : "select-dropdown"} // disable_us
                                className={(Nav.district && Nav.Summary_Reports && (RosterData.SchoolIds.length > 1))
                                    ? "disable_us" : "select-dropdown"}
                                onClick={() => {
                                    if (((RosterGradeList.length !== 1 && RosterGradeList.length !== 0 && Loading == '') ||
                                        (RosterGradeList.length == 1 && (U_Selector.selectedRosterGrade == null ||
                                            U_Selector.selectedRosterGrade == ""))
                                    ) && !(Nav.district && Nav.Summary_Reports && RosterData.SchoolIds.length > 1)
                                    ) {

                                        let selected_School = RosterData.SelectedSchool;
                                        let Call_Get_SChool_Details_Api = U_Selector.Roster.OpenScoolDropDown && selected_School.id !== undefined;
                                        if (selected_School.id !== undefined) {
                                            selected_School = RosterData.schoolsList.filter(item => item.id == selected_School.id)[0];
                                        }

                                        let AccessToken = this.props.LoginDetails.JWTToken;
                                        let Dateterm = this.props.ContextHeader.Date_Tab.selectedterm_Obj;
                                        let FromDist_Report = false;
                                        this.props.OpenSelectorInRoaster('grade', Call_Get_SChool_Details_Api, selected_School, AccessToken, Dateterm, FromDist_Report)
                                        this.FilterDropDownList("", 'grade')
                                    }
                                }}>
                                <span className="Roster-Dropdown-text">
                                    {SelectedGrade !== undefined && SelectedGrade !== ""
                                        ? SelectedGrade == "All" ? "All" : convertGrade(SelectedGrade) : RosterGradeList.length == 0 ? "No Records Available" : 'Select Grade'}
                                </span>
                            </button>
                            {this.ReturnGradeList(RosterGradeList, U_Selector, SelectedGrade, isDistrictAdmin, isSchoolAdmin, Nav)}

                        </div>
                    </div>
                }
                {TeacherRole ? null : <div className="universal-input-field">
                    <div className="menu-title">
                        Teacher
                        <span className="data-refresh">
                            {Loading == "teacher" ?
                                <i className="material-icons">autorenew</i> : null}
                        </span>
                    </div>
                    <div className={U_Selector.Roster.OpenTeacherDropDown ?
                        "menu-selector active-selector" : "menu-selector"}>
                        <button
                            className={ActualTeachersList.length === 0 || (Nav.Summary_Reports && SelectedGrade === "All") ?
                                "disable_us" : "select-dropdown"}
                            onClick={() => {
                                if ((((TeachersList.length > 0 && SelectedTeacher.name == undefined) || TeachersList.length > 1) && Loading !== "class" && Loading !== "student" ||
                                    U_Selector.Roster.OpenTeacherDropDown) &&
                                    !(Nav.Summary_Reports && SelectedGrade === "All")) {
                                    this.props.OpenSelectorInRoaster('teacher');
                                    this.ClearIpSearchValue_If_Any('teacher');
                                }
                            }}
                            style={{ background: ActualTeachersList.length < 2 ? "#fff" : null }}
                        >
                            <span className="Roster-Dropdown-text">
                                {typeof SelectedTeacher != "object" && RosterData.ActualTeachers.length != RosterData.TeacherIds.length && RosterData.TeacherIds.length>0? SelectedTeacher:(RosterData.ActualTeachers == 0 || RosterData.TeacherIds.length == 0 ? (Nav.district ? "All" : SelectedTeacher && SelectedTeacher.name && SelectedTeacher.name != undefined ? SelectedTeacher.name : 'Select Teacher') :
                                    SelectedTeacher && SelectedTeacher == "All" || SelectedTeacher && SelectedTeacher.name &&  SelectedTeacher.name == undefined ?
                                        typeof SelectedTeacher == "object" ? "All" : SelectedTeacher :
                                        DisplaySelectedRosterItem(SelectedTeacher.name))
                                }{SelectedTeacher && SelectedTeacher.name && this.tooltipDisplay(SelectedTeacher.name)}
                                {(RosterData.ActualTeachers == 0 || RosterData.TeacherIds.length == 0) && Nav.district ? this.tooltipDisplayDistrict() : null}
                            </span>
                        </button>
                        {ActualTeachersList.length > 0 ? this.ReturnTeacherList(U_Selector, TeachersList, SelectedTeacher, RosterData, Nav) : null}
                    </div>
                </div>}

                {/* Class Block */}
                <div className="universal-input-field">
                    <div className="menu-title">
                        Class
                        <span className="data-refresh">
                            {Loading == "class" ?
                                <i className="material-icons">autorenew</i> : null}
                        </span>
                    </div>
                    <div className={U_Selector.Roster.OpenClassDropDown ?
                        "menu-selector active-selector" : "menu-selector"}>
                        <button style={{
                            background: SelectedClass.name == undefined ? "" : ClassList.length == 1 ?
                                "#FFF" : ""
                        }}
                            className={ActualClassList.length === 0 || (!Nav.class&& Nav.Summary_Reports && SelectedGrade === "All") || ((Nav.class&& Nav.Summary_Reports && SelectedGrade === "All" ) && ( RosterGradeList.length != 1 || RosterGradeList.length > 1 )) ?
                                "disable_us" : "select-dropdown"}
                            onClick={() => {
                                if (((ActualClassList.length !== 1 && ActualClassList.length !== 0 ||
                                    (ActualClassList.length == 1 && SelectedClass.name == undefined || U_Selector.Roster.OpenClassDropDown)
                                ) &&
                                    !(Nav.Summary_Reports && SelectedGrade === "All")
                                )) {
                                    this.ClearIpSearchValue_If_Any('class')
                                    this.props.OpenSelectorInRoaster('class')
                                }
                            }}>
                            <span className="Roster-Dropdown-text">
                                {ActualClassList.length == 0 || RosterData.ClassIds == 0 ? (Nav.district ? "All" : 'Select Class') :
                                    SelectedClass == "All" || SelectedClass.name == undefined ?
                                        typeof SelectedClass == "object" ? "All" : SelectedClass :
                                        DisplaySelectedRosterItem(SelectedClass.name)
                                }
                                {this.tooltipDisplay(SelectedClass.name)}
                                {(ActualClassList.length == 0 || RosterData.ClassIds == 0) && Nav.district ? this.tooltipDisplayDistrict() : null}
                            </span>
                        </button>
                        {this.ReturnClassList(U_Selector, ClassList, SelectedClass, RosterData, Nav)}
                    </div>
                </div>
                <div className="universal-input-field">
                    <div className="menu-title">
                        Student
                        <span className="data-refresh">
                            {Loading == "student" || this.props.ApiCalls.getstudents_Loader ?
                                <i className="material-icons">autorenew</i> :
                                null}
                        </span>
                    </div>
                    <div className={U_Selector.Roster.OpenStudentDropDown && !Nav.Summary_Reports ?
                        "menu-selector active-selector" : "menu-selector"}>
                        <button
                            className={Actu_Stds_List.length === 0 || Nav.Summary_Reports ?
                                "disable_us" : "select-dropdown"
                            }

                            disabled={Actu_Stds_List.length === 0 ? true :
                                false
                            }
                            onClick={() => {
                                if (StudentsList.length != 0) {
                                    this.props.OpenSelectorInRoaster('student');
                                    this.ClearIpSearchValue_If_Any('student')
                                }
                            }}>
                            <span className="Roster-Dropdown-text">
                                {StudentsList.length === 0 ? (Nav.district ? "All" : 'Select Student') :
                                    SelectedStudent == "All" || SelectedStudent.name == undefined ? typeof SelectedStudent == "object" ?
                                        "All" : SelectedStudent :
                                        DisplaySelectedRosterItem(SelectedStudent.name)}
                                {this.tooltipDisplay(SelectedStudent.name)}
                                {StudentsList.length === 0 && Nav.district && !Nav.Summary_Reports ? this.tooltipDisplayDistrict() : null}
                                {Nav.Summary_Reports ? this.tooltipDisplayDistrict("Summary reports are not available at student level.") : null}
                            </span>
                        </button>
                        <div className="menu-dropdown-container">
                            {Actu_Stds_List !== undefined ? Actu_Stds_List.length != 0 ?
                                <div
                                    className="menu-varient-search">
                                    <input type="text"
                                        value={U_Selector.Roster.IpSearchvalue}
                                        onChange={(txt) => this.FilterDropDownList(txt.target.value, 'student')}
                                        placeholder="Search" className={U_Selector.Roster.IpSearchvalue != undefined && U_Selector.Roster.IpSearchvalue != null && U_Selector.Roster.IpSearchvalue.length > 0 ? "roster_magnifier_search_bg_none" : "roster_magnifier_search_bg"} />
                                    {U_Selector.Roster.IpSearchCancle ?
                                        <span
                                            onClick={() => this.FilterDropDownList('', 'student')}
                                            className="menu-varient-search-cancel">
                                            x
                                        </span> : null
                                    }
                                </div>
                                : null : null}
                            <div className="menu-dropdown-list">
                                {this.RetunStudentsList(StudentsList, U_Selector, SelectedStudent, RosterData)}
                            </div>
                        </div>
                    </div>
                </div>
                {Nav.student && this.props.ContextHeader.FERPA_COPPA_ENABLED && Universal_ActualStudentDataList.length > 1 ?
                    <div className="universal-input-field">
                        <div className="menu-title">
                            <span style={{ float: "left" }}>Student Data</span>
                            <span class="infoIconForRoster" style={{ marginLeft: "4px", marginTop: "-4px" }}
                                onClick={() =>
                                    this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "roster"
                                        ? null : this.props.ClickStudentDataInfoIcon("roster")}
                                ref={(refNode) => refNode == null ? null : this.StudentDataToolTip_Refs = refNode}
                            >
                                <img src={info_icon} style={{ cursor: "pointer", width: "16px" }} />
                                {this.props.UniversalSelecter.Roster.StudentDataInfoIcon == "roster" ?
                                    <div class="infoIconForRoster_tooltip"  >
                                        <span class="infoIconForRoster_tooltip_left"></span>
                                        <span class="infoIconForRoster_tooltip_right">
                                            <span class="infoIconForRoster_tooltip_Description">
                                                {isPastDistrictTerm ? "Classes displayed are from the past district term. Select classes to include individual student's data in reports." : "Select additional classes to include this data in the student's reports."}</span>
                                        </span>
                                    </div> : null}
                            </span>
                            {/* : null} */}
                            <span className="data-refresh">
                                {Loading == "class" ?
                                    <i className="material-icons">autorenew</i> : null}
                            </span>
                        </div>
                        <div
                            // className={"menu-selector active-selector"}
                            className={U_Selector.Roster.OpenStudentDataDropDown ?
                                "menu-selector active-selector" : "menu-selector"}
                        >
                            <button style={{
                                background: SelectedStudentData.name == undefined ? "" : Universal_StudentsDataList.length == 1 ?
                                    "#FFF" : ""
                            }}
                                className={Universal_StudentsDataList.length === 0 ?
                                    "disable_us" : "select-dropdown"}
                                onClick={() => {
                                    this.props.OpenSelectorInRoaster('studentData')
                                }}
                            >
                                <span className="Roster-Dropdown-text">
                                    {Universal_StudentsDataList.length == 0 || RosterData.ClassIds == 0 ? 'Select Class' :
                                        SelectedStudentData == "All" || SelectedStudentData.name == undefined ?
                                            typeof SelectedStudentData == "object" ? "All" : SelectedStudentData :
                                            DisplaySelectedRosterItem(SelectedStudentData.name)
                                    }{this.tooltipDisplay(SelectedStudentData.name)}</span>
                            </button>
                            {this.ReturnStudentDataList(U_Selector, Universal_StudentsDataList, SelectedStudentData, RosterData)}
                        </div>
                    </div> : null}

                <div className="universal-select-filter">
                    <div className="cancel-btn float-left"
                        onClick={() => {
                            this.props.CloseUniversalFilter('FromCLoseFIlter')
                        }}>
                        Cancel
                    </div>
                    <div className="apply-btn float-right">
                        <button
                            className={DIsableApplyButton ?
                                "universal-selector-applyfilter disableFilter_us" : "universal-selector-applyfilter"}
                            disabled={DIsableApplyButton
                            }
                            onClick={() => {
                                if (U_Selector.Roster.IpSearchvalue !== '') {
                                    let SelectedIS = U_Selector.Roster.OpenStudentDropDown ? 'student' :
                                        U_Selector.Roster.OpenClassDropDown ? 'class' :
                                            U_Selector.Roster.OpenTeacherDropDown ? 'teacher' :
                                                U_Selector.Roster.OpenScoolDropDown ? 'school' : ''
                                    this.FilterDropDownList('', SelectedIS, RosterData);
                                }
                                this.ApplyButton_Action(U_Selector, Nav, SelectedClass, RosterData, SelectedGrade);

                            }}>
                            Apply
                        </button>
                    </div>
                </div>

            </div>
        </div >
    }

    ApplyButton_Action(U_Selector, Nav, roster_SelectedClass, RosterData, SelectedGrade) {

        const { SelectedSchool, SelectedClass, selectedRosterGrade } = this.props.ContextHeader.Roster_Tab;
        let Select_SChool = RosterData.SelectedSchool;
        let Call_Get_SChool_Details_Api = U_Selector.Roster.OpenScoolDropDown &&
            RosterData.SchoolIds.length == 1 && SelectedSchool.id !== Select_SChool.id;


        if (!Call_Get_SChool_Details_Api) {

            let sameClass = roster_SelectedClass.id ==
                SelectedClass.id &&
                selectedRosterGrade ==
                SelectedGrade;

            this.props.ApplyRoasterTabFilter(sameClass, Nav)
            setTimeout(() => {
                this.applyRoaster()
            }, 1500)

        } else {
            let selected_Sc = RosterData.SelectedSchool;
            if(Call_Get_SChool_Details_Api) {
                selected_Sc = RosterData.schoolsList.find(item => item.id == selected_Sc.id);
            }
            let AccessToken = this.props.LoginDetails.JWTToken;
            let Dateterm = this.props.ContextHeader.Date_Tab.selectedterm_Obj;
            let FromDist_Report = true;
            this.props.OpenSelectorInRoaster('', Call_Get_SChool_Details_Api, selected_Sc, AccessToken, Dateterm, FromDist_Report);
        }
    }

}

const mapStateToProps = ({
    Universal,
    Authentication,
    CommonFilterDetails,
    School_FA_Reducer,
    classFluency,
    ClassEaData,
    SchoolErrorAnalysisData,
    LastActiveUniversalProps
}) => {
    const { UniversalFilter, UniversalSelecter, OpenMainmenu, Pagination, currentTermID,
        ApiCalls, UserScreenWidth, ContextHeader, NavigationByHeaderSelection, isPastDistrictTerm } = Universal;
    const { LoginDetails } = Authentication;
    const { CommonFilterData } = CommonFilterDetails;
    const { School_fpot, ScFTabSelection } = School_FA_Reducer;
    const { FluencyTabSelection, progressOverTime } = classFluency;
    const { showRecord } = ClassEaData;
    const { showRecordSea } = SchoolErrorAnalysisData;
    return {
        showRecordSea,
        UniversalFilter,
        UniversalSelecter,
        OpenMainmenu,
        Pagination,
        ApiCalls,
        UserScreenWidth,
        ContextHeader,
        LoginDetails,
        NavigationByHeaderSelection,
        CommonFilterData,
        School_fpot,
        ScFTabSelection,
        FluencyTabSelection,
        progressOverTime,
        showRecord,
        isPastDistrictTerm,
        currentTermID,
        LastActiveUniversalProps
    };
};

export default connect(
    mapStateToProps,
    {
        CloseUniversalFilter,
        ApplyFilterOnRoasterTab,
        OpenSelectorInRoaster,
        StoreFilteredListInRoster,
        SaveSelectedStudent,
        ApplyRoasterTabFilter,
        S_RLP_API_CALL,
        S_RB_API_CALL,
        READING_HISTORY_STUDENT_DATA,
        ERROR_ANALYSIS_STUDENT_DATA,
        CLASS_READING_HISTORY_DATA,
        Fluency_Chart_Api_Request,
        CLASS_FPO_API,
        CRB_Chart_API_Call,
        CLASS_READING_LEVEL_PROGRESS,
        CLASS_READING_LEVEL_GRID_DATA,
        CLASS_EA_API,
        School_Level_RLP_Chart_API,
        School_EA_Dropdown,
        School_Class_Level_RLP_Chart_API,
        LOAD_STATUS_ICON,
        District_Class_Level_RLP_Chart_API,
        District_Level_RLP_Chart_API,
        S_Fluency_Chart_Data,
        SaveSelected_CLass,
        SaveSelected_StudentData,
        SaveSelectedTeacher,
        SaveSelected_RosterGrade,
        SaveSelectedSchool,
        GetGradesListOn_School,
        SCHOOL_FPOT_API_SUCCESS,
        Sc_GRADES,
        LOAD_ICON,
        Sum_Sc_RLP_Chart_API,
        Sum_Dst_RLP_Chart_API,
        SCHOOL_READING_HISTORY_DATA,
        SCHOOL_RH_ERRORHANDLING,
        SCHOOL_FA_CHART_API_CALL,
        FA_LOAD_ICON,
        School_RB_Chart_API_Call,
        Show_loading_Icon,
        School_RB_Dropdown,
        ClickStudentDataInfoIcon,
        DISTRICT_FA_CHART_API_CALL,
        DFA_LOAD_ICON,
        DISTRICT_RH_ERRORHANDLING,
        DISTRICT_READING_HISTORY_DATA
    }
)(Roster);


/**
 * @function
 * @param {Selected DropDown Item Name} name
 * @returns -- string.
 * if the string length is exceeding some limit, will apply ellipsis by  sliceing the string,  and return specific length of the string.
 */
function DisplaySelectedRosterItem(name) {
    return name == undefined
        ? ''
        : name.length > 24
            ? name.slice(0, 24) + '...'
            : name;
}
/**
 * @function
 * @param { Object } U_Selector -- Universal Selector Props.
 * @param {int} UserScreenWidth -- Monitor Width.
 * @param {object} ContextHeaderData -- Data OF Context Header.
 * @returns {boolean}
 */

function DisabledFilterButton(U_Selector, Context, Nav, LoadingFor, U_RosterData) {

    //const U_RosterData = RosterData;

    const { Summary_Reports } = Nav;

    let Context_RosterData = Summary_Reports ? Context.Summary_Roster_Data : Context.Roster_Tab;
    let isTeacherRole = Context.User_Role == "TEACHER";

    let StudentsAreSelected = U_RosterData.SchoolIds.length == 0 ? U_RosterData.StudentIds.length > 0 : true

    let Ctx_Scids = Context_RosterData.SchoolIds.sort();
    let R_scids = U_RosterData.SchoolIds.sort();

    let Ctx_cls_ids = Context_RosterData.ClassIds.sort();
    let R_cls_ids = U_RosterData.ClassIds.sort();

    let Ctx_Std_ids = Context_RosterData.StudentIds.sort();
    let R_Std_ids = U_RosterData.StudentIds.sort();

    let SchoolCompare = CompareTwoArrays(Ctx_Scids, R_scids);
    if (Nav.class && Nav.Summary_Reports) {
        let Number_Ctx_cls_ids = Ctx_cls_ids.map(Number);
        let Number_R_cls_ids = R_cls_ids.map(Number);
        Ctx_cls_ids = Number_Ctx_cls_ids;
        R_cls_ids = Number_R_cls_ids;
    }
    let ClassCompare = CompareTwoArrays(Ctx_cls_ids, R_cls_ids);
    let StudentCompare = R_Std_ids.length == 0 && !Nav.district ? true :
        Nav.student && U_RosterData.StudentData_cls_ids.length == 0 && Context.FERPA_COPPA_ENABLED
            && Ctx_Std_ids[0] == R_Std_ids[0] ? true :
            CompareTwoArrays(Ctx_Std_ids, R_Std_ids);

    if (LoadingFor !== "") {
        return true
    }

    const SelectedGrade = U_RosterData.SelectedGrade;
    let PrecheckSelectedRosterGrade = Nav.Summary_Reports ? Context_RosterData.selectedRosterGrade : (Context_RosterData.selectedRosterGrade == "All" ? Context_RosterData.GradesList[0].grade : Context_RosterData.selectedRosterGrade)
    let SameGrade = PrecheckSelectedRosterGrade === SelectedGrade;
    let LastStdIds = Context_RosterData.StudentData_cls.filter(item => item.check);
    let CUrrentStdIds = U_RosterData.StudentData_cls.filter(item => item.check);
    LastStdIds = LastStdIds == undefined || LastStdIds == null ? [] : LastStdIds;
    CUrrentStdIds = CUrrentStdIds == undefined || CUrrentStdIds == null ? [] : CUrrentStdIds;

    let StdDataisSame = Nav.student && R_Std_ids.length > 0 && CUrrentStdIds.length > 0 ? false : true;
    
    if (Nav.student && R_Std_ids.length == 1 && !StdDataisSame) {
        let ctx_std_data_ids = Context_RosterData.StudentData_cls_ids.sort();
        let roster_std_data_ids = U_RosterData.StudentData_cls_ids.sort();

        if (roster_std_data_ids.length !== ctx_std_data_ids.length) {
            StdDataisSame = false;
        } else {
            StdDataisSame = CompareTwoArrays(ctx_std_data_ids, roster_std_data_ids)

        }

    }

    let SameSchool = R_scids.length === 1 ?
        Context_RosterData.SelectedSchool.id == U_RosterData.SelectedSchool.id : false;
    let NoSelection_StudentData = U_RosterData.SelectedStudentData == "Select Class" && Context.FERPA_COPPA_ENABLED;

    if (Nav.district && !SchoolCompare && R_scids.length > 0) {
        return false
    }
let conditionOne = (SchoolCompare && ClassCompare && StudentCompare && StdDataisSame && SameGrade);
let conditionTwo = (R_Std_ids.length == 0 && !Nav.district && SameSchool && !Summary_Reports);
let conditionThree = (R_Std_ids.length == 0 && R_scids.length == 1 && !U_Selector.Roster.OpenScoolDropDown && !Summary_Reports);
let conditioFour = (R_scids.length === 0 && !isTeacherRole && !Summary_Reports) || (NoSelection_StudentData && !Summary_Reports);


    if ( conditionOne ||
        conditionTwo ||
        conditionThree
        ||  conditioFour
        // || R_Std_ids.length == 0
    ) {
        return true;
    } else {
        return false;
    }
}
/**
 *
 * @param {Object} U_Selector
 * @param {Object} ContextHeaderData
 * it checks present selected students and last appliyed students data
 */
function CheckSudents(U_Selector, ContextHeaderData, Nav, RosterData) {
    let SelectedStds = ContextHeaderData.Roster_Tab.StudentsList.filter(item => item.check);
    SelectedStds = SelectedStds == undefined || SelectedStds == null ? [] : SelectedStds;
    let selectedstds = RosterData.StudentsList;
    selectedstds = selectedstds.length > 0 ? selectedstds.filter(item => item.check) : [];
    return ArrayIsEqual(SelectedStds, selectedstds)
}

/**
 *
 * @param {Array} Arr1
 * @param {Array} Arr2
 * if the array is not equal, it will enable apply button in roster tab, else will check every id of arra1 and array 2 then will enable or disable button
 */
export var ArrayIsEqual = function (Arr1, Arr2) {

    if (Arr1.length == Arr2.length) {
        let itemExist = true;
        Arr1.map(item => {
            for (var i = 0; i < Arr2.length; i++) {
                let Arr2item = Arr2.indexOf(item);
                Arr2item == -1 ? itemExist = false : null;
            }
        })
        return itemExist
    } else if (Arr2.length == 0) {
        return true;
    } else return false;
};

export function convertGrade(grade) {

    if (grade == "null" || grade == null) {
        return `Select Grade`
    } else {
        const value = grade.toString()
        const value2 = value.split("_")[1]
        if (value2 == undefined) {
            return `Select Grade`
        } else return `Grade ${value2}`
    }
}

export function CompareTwoArrays(array1, array2) {
    return array1.length === array2.length && array1.sort().every(function (value, index) {
        return value === array2.sort()[index]
    });
}