import React, { Component } from 'react';
import { connect } from 'react-redux';
import CheckboxSearchDropdown from '../../CheckboxSearchDropdown/index.jsx';
import {
  SetUsageReportsCollectiveNounIds,
  SetUsageReportsCollectiveNounUiIds,
  SetUsageReportsGrade,
  ResetUsageUiNavigationLevel,
  SetUsageContextNames
} from '../../../Redux_Actions/UniversalSelectorActions';
import { setContextNames } from '../../../Utils/UsageReporting/usageReports';
import { conditionExecution } from '../../../Utils/buurUtils.js';

class BuurRoster extends Component {

  constructor(props) {
    super(props);
    this.updateIdsState = this.updateIdsState.bind(this);
    this.cancelButton = this.cancelButton.bind(this);
    this.applyButton = this.applyButton.bind(this);
    this.handleOpenedDropdown = this.handleOpenedDropdown.bind(this);
    this.state = {
      uiGradeIds: [],
      uiSchoolIds: [],
      uiTeacherIds: [],
      uiClassIds: [],
      uiStudentIds: [],
      hasDataChanged: false,
      openDropdown: ''
    };
    this.validDataTypes = ['uiGradeIds', 'uiSchoolIds', 'uiTeacherIds', 'uiClassIds', 'uiStudentIds'];
    this.dataTypeConversion = {
      uiGradeIds: 'grade',
      uiSchoolIds: 'school',
      uiTeacherIds: 'teacher',
      uiClassIds: 'class',
      uiStudentIds: 'student'
    };
    this.dataTypeLookup = {
      uiGradeIds: 'grade',
      uiSchoolIds: 'schoolIds',
      uiTeacherIds: 'teacherIds',
      uiClassIds: 'classIds',
      uiStudentIds: 'studentIds'
    };
  }

  componentDidMount() {
    this.updateIdsState();
  }

  componentDidUpdate(prevProps) {
    const updates = {};
    let dataType;
    let extenralIdsSet = false;
    this.validDataTypes.forEach((idKey) => {
      if (JSON.stringify(prevProps.usageReports[idKey])
        !== JSON.stringify(this.props.usageReports[idKey])) {
        extenralIdsSet = true;
        updates[idKey] = this.props.usageReports[idKey];
      }
    });
    if (extenralIdsSet) {
      this.validDataTypes.forEach((idKey) => {
        dataType = this.dataTypeLookup[idKey];
        if (JSON.stringify(this.props.usageReports[idKey])
          !== JSON.stringify(this.props.usageReports[dataType])) {
          updates.hasDataChanged = true;
        }
      });
      this.setState(updates);
    }
  }

  updateIdsState() {
    const updates = {};
      this.validDataTypes.forEach((idKey) => {
      updates[idKey] = this.props.usageReports[idKey];
    });
    this.setState(updates);
  }

  wasDataChanged(dataType, newIds) {
    if (this.validDataTypes.indexOf(dataType) === -1) {
      return false;
    }
    const nonUiType = this.dataTypeLookup[dataType];
    return (JSON.stringify(newIds) !== JSON.stringify(this.props.usageReports[nonUiType]));
  }

  changeSelectedUsageIds(type,ids) {
    const updates = {};
    let dataType;
    if (this.validDataTypes.indexOf(type) === -1) {
      return;
    }
    updates[type] = ids;
    updates.hasDataChanged = this.wasDataChanged(type, ids);
    if (!updates.hasDataChanged) {
      this.validDataTypes.forEach((idKey) => {
        dataType = this.dataTypeLookup[idKey];
        if (type !== idKey) {
          if (JSON.stringify(this.props.usageReports[idKey])
            !== JSON.stringify(this.props.usageReports[dataType])) {
            updates.hasDataChanged = true;
          }
        }
      });
    }
    
    const {refreshCondition,idsReplace} = conditionExecution(type,this.props.usageReports)

    if(refreshCondition){
      updates[type] = idsReplace
      updates.hasDataChanged = false
      this.props.SetUsageReportsCollectiveNounUiIds(type,idsReplace);
    }else{
      this.props.SetUsageReportsCollectiveNounUiIds(type,ids);
    }
    this.setState(updates);
  }

  cancelButton() {
    const stateUpdate = {hasDataChanged: false};
    let dataType = '';
    this.validDataTypes.forEach((idKey) => {
      dataType = this.dataTypeLookup[idKey];
      if (dataType !== undefined) {
        if (JSON.stringify(this.state[idKey]) !== JSON.stringify(this.props.usageReports[dataType])) {
          this.props.SetUsageReportsCollectiveNounUiIds(idKey, this.props.usageReports[dataType]);
          stateUpdate[idKey] = this.props.usageReports[dataType];
        }
      }
    });
    this.setState(stateUpdate);
    this.props.ResetUsageUiNavigationLevel();
    this.props.CloseUniversalFilter('FromCLoseFIlter');
  }

  applyButton() {
    let dataType = '';
    let newContextName;
    this.validDataTypes.forEach((idKey) => {
      dataType = this.dataTypeConversion[idKey];
      if (dataType !== undefined) {
        if (JSON.stringify(this.state[idKey]) !== JSON.stringify(this.props.usageReports[dataType])) {
          if (dataType !== 'grade') {
            this.props.SetUsageReportsCollectiveNounIds(dataType, this.state[idKey]);
            newContextName =
              setContextNames(dataType, this.state[idKey], this.props.usageReports[`${dataType}List`] );
            this.props.SetUsageContextNames(newContextName);
          } else {
            this.props.SetUsageReportsGrade(this.state[idKey]);
          }
        }
      }
    });
    this.setState({hasDataChanged: false});
    this.props.CloseUniversalFilter('FromCLoseFIlter');
  }

  handleOpenedDropdown(dropdownId) {
    this.setState({openDropdown: dropdownId});
  }

  render() {
    const lowerFreeze = (this.props.usageReports.uiNavigationLevel === 'district');
    let studentFreeze = (this.props.usageReports.uiNavigationLevel !== 'class');
    studentFreeze = this.props.usageReports.betweenTerms ? true : studentFreeze;
    const notClassNav = (this.props.usageReports.maxNavigationLevel !== 'class');
    const showSchools = (notClassNav || (this.props.usageReports.schoolList && this.props.usageReports.schoolList.length > 1));
    const showGrades = (notClassNav || (this.props.usageReports.gradeList && this.props.usageReports.gradeList.length > 1));
    const showTeachers = (notClassNav || (this.props.usageReports.teacherList && this.props.usageReports.teacherList.length > 1));
    return (
      <div className="menu-item-expand-block">
        <div className="buur-roster-container">
          {showSchools && (
            <div className="buur-collective-noun-dropdown">
              <CheckboxSearchDropdown
                checkboxGlobalId="school"
                menuTitle="Schools"
                loading={false}
                placeholder="All"
                loading={this.props.usageReports.uiLoadingStatus.school}
                selectionItems={this.props.usageReports.schoolList}
                preSelectedItems={this.state.uiSchoolIds}
                frozen={false}
                hasSearch={true}
                onChangeSelectedIds={(ids) => this.changeSelectedUsageIds('uiSchoolIds', ids)}
                onOpenDropdown={this.handleOpenedDropdown}
                externalCloseDropdown={this.state.openDropdown !== 'school'}
              />
            </div>
          )}
          {showGrades && process.env.BUUR_HIDE_GRADE_FILTER !== 'true' && (
            <div className="buur-collective-noun-dropdown">
              <CheckboxSearchDropdown
                checkboxGlobalId="grade"
                menuTitle="Grades"
                placeholder="All"
                loading={this.props.usageReports.uiLoadingStatus.grade}
                selectionItems={this.props.usageReports.gradeList}
                preSelectedItems={this.state.uiGradeIds}
                frozen={false}
                hasSearch={false}
                onChangeSelectedIds={(ids) => this.changeSelectedUsageIds('uiGradeIds', ids)}
                onOpenDropdown={this.handleOpenedDropdown}
                externalCloseDropdown={this.state.openDropdown !== 'grade'}
              />
            </div>
          )}
          {showTeachers && (
            <div className="buur-collective-noun-dropdown">
              <CheckboxSearchDropdown
                checkboxGlobalId="teacher"
                menuTitle="Teachers"
                loading={false}
                placeholder="All"
                loading={this.props.usageReports.uiLoadingStatus.teacher}
                selectionItems={this.props.usageReports.teacherList}
                preSelectedItems={this.state.uiTeacherIds}
                frozen={lowerFreeze}
                hasSearch={true}
                onChangeSelectedIds={(ids) => this.changeSelectedUsageIds('uiTeacherIds', ids)}
                selectionOverride={lowerFreeze ? 'All' : null}
                onOpenDropdown={this.handleOpenedDropdown}
                externalCloseDropdown={this.state.openDropdown !== 'teacher'}
              />
            </div>
          )}
          <div className="buur-collective-noun-dropdown">
            <CheckboxSearchDropdown
              checkboxGlobalId="class"
              menuTitle="Classes"
              placeholder="All"
              loading={this.props.usageReports.uiLoadingStatus.class}
              selectionItems={this.props.usageReports.classList}
              preSelectedItems={this.state.uiClassIds}
              frozen={lowerFreeze}
              hasSearch={true}
              onChangeSelectedIds={(ids) => this.changeSelectedUsageIds('uiClassIds', ids)}
              selectionOverride={lowerFreeze ? 'All' : null}
              onOpenDropdown={this.handleOpenedDropdown}
              externalCloseDropdown={this.state.openDropdown !== 'class'}
            />
          </div>
          <div className="buur-collective-noun-dropdown">
            <CheckboxSearchDropdown
              checkboxGlobalId="student"
              menuTitle="Students"
              placeholder="All"
              loading={this.props.usageReports.uiLoadingStatus.student}
              selectionItems={this.props.usageReports.studentList}
              preSelectedItems={this.state.uiStudentIds}
              frozen={studentFreeze}
              hasSearch={true}
              onChangeSelectedIds={(ids) => this.changeSelectedUsageIds('uiStudentIds', ids)}
              selectionOverride={studentFreeze ? 'All' : null}
              onOpenDropdown={this.handleOpenedDropdown}
              externalCloseDropdown={this.state.openDropdown !== 'student'}
            />
          </div>
          <div className="universal-select-filter">
            <div className="cancel-btn float-left"
                 onClick={this.cancelButton}>
              Cancel
            </div>
            <div className="apply-btn float-right">
              <button
                className={!this.state.hasDataChanged ?
                  "universal-selector-applyfilter disableFilter_us" : "universal-selector-applyfilter"}
                disabled={!this.state.hasDataChanged}
                onClick={this.applyButton}>
                Apply
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({ Universal }) => {
  const { usageReports } = Universal;
  return { usageReports };
};

export default connect(mapStateToProps, {
  SetUsageReportsCollectiveNounIds,
  SetUsageReportsCollectiveNounUiIds,
  SetUsageReportsGrade,
  ResetUsageUiNavigationLevel,
  SetUsageContextNames
})(BuurRoster);
