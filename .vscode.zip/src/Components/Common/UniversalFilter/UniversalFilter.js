import React, { Component } from "react";
import "../../../../public/css/style.css";
import { connect } from "react-redux";
import {
  AccessToRosterTab,
  AccessToTestTab,
  AccessToDateTab,
} from "../../../Utils/globalVars";
import {
  GetStudentsListOnSchoolAndClassID,
  ApplyFilterOnRoasterTab,
  GetClassListOnTeacher,
  Get_TestTabResults,
  Get_DateTabResults,
  getInitialSchoolObjService,
} from "../../../Redux_Actions/UniversalSelectorActions";
import { ChangePaginationBubble } from "../../../Redux_Actions/UniversalSelectorActions_Primary";
import {
  OpenUniversalFilter,
  CloseUniversalFilter,
  Get_TestStatus_Roster_Grades,
} from "../../../Redux_Actions/UniversalSelectorActions_Secondary";
import TestTab from "./TestTab";
import RosterComponent from "./Roster";
import DateTab from "./DateTab";
import RosterIcon from "../../../../public/images/ic_roster_unselected.svg";
import DateIcon from "../../../../public/images/ic_date_unselected.svg";
import {
  DateFormarFor_APiCalls,
  GetSelectedSchoolIdsOf_Grade,
} from "../../ReusableComponents/AllReusableFunctions";
import { call_TS_RosterGrades } from "../../../services/U_Selector.service";
import { style } from "react-toastify";
import { EnddateValues, StartdateValues } from "../../../Utils/reUsableSnipets";
import { studentIdsCond } from "../../ReusableComponents/AllReusableFunctions_Two";

class UniversalFilter extends React.Component {
  constructor(props) {
    super(props);
    this.ApplyFilter = this.ApplyFilter.bind(this);
    this.CloseFilter = this.CloseFilter.bind(this);
    this.state = {
      SearchFocus: false,
      tooltipfor: "roster",
    };
  }

  componentDidUpdate() {
    let Nav = this.props.NavigationByHeaderSelection;
    if (Nav.usageReport) {
      return;
    }
    let ApiCalls = this.props.ApiCalls;
    let AccessToken = this.props.LoginDetails.JWTToken;
    let { defaultApi } = this.props.Auth_Apis;
    const currentApplication = Nav.ORR ? "ORR" : "eAR";
    call_TS_RosterGrades(this.props);
    let TestStatus_ApiCalls = Nav.student
      ? this.props.TestStatusReducer.Student.Apicalls.GetTestTab_TestStatus &&
        !ApiCalls.STUDENT_OBJ_API &&
        !ApiCalls.getStudentData_cls &&
        ApiCalls.loadingFor == ""
      : Nav.class
      ? this.props.TestStatusReducer.Class.Apicalls.GetTestTab_TestStatus
      : Nav.school
      ? this.props.TestStatusReducer.School.Apicalls.GetTestTab_TestStatus
      : Nav.district
      ? this.props.TestStatusReducer.District.Apicalls.GetTestTab_TestStatus
      : false;
    let Get_TestStatusApi = Nav.test_status && TestStatus_ApiCalls;
    let GetSchoolDetails =
      ApiCalls.Get_Selected_School_Info ||
      ApiCalls.loadingFor == "school" ||
      ApiCalls.loadingFor == "studentData" ||
      (ApiCalls.getStudentData_cls && Nav.student) ||
      (ApiCalls.getInitialSchoolObj && Nav.school);
    let GetRosterGrades_For_TS =
      ApiCalls.get_Roster_Grades_TS ||
      ApiCalls.loadingFor == "ts_roster_grades";

    if (ApiCalls.getInitialSchoolObj) {
      let { ContextHeader, SummaryReports, LoginDetails } = this.props;
      let apiStartDate = ContextHeader.Date_Tab.Report_termStartDate;
      let apiEndDate = ContextHeader.Date_Tab.Report_termEndDate;
      let currentTermId = this.props.currentTermID;
      let { selectedRosterGrade, SelectedDistrict } = Nav.Summary_Reports
        ? ContextHeader.Summary_Roster_Data
        : ContextHeader.Roster_Tab;
      let gradeToSendRequest = JSON.parse(JSON.stringify(selectedRosterGrade));
      if (
        Nav.Summary_Reports &&
        (!selectedRosterGrade ||
          selectedRosterGrade == "ALL" ||
          selectedRosterGrade == "All")
      ) {
        let { standardperformance } = SummaryReports.district.assessments;
        let keysOfGradeObj =
          standardperformance.gradeDetails &&
          Object.keys(standardperformance.gradeDetails);

        if (keysOfGradeObj && keysOfGradeObj.length > 0) {
          gradeToSendRequest = keysOfGradeObj[keysOfGradeObj.length - 1];

          if (gradeToSendRequest == "grade_k") {
            gradeToSendRequest = keysOfGradeObj[keysOfGradeObj.length - 2];
          }
        }
      }
      const { Context_DateTab} = this.props.DateTabReducer;
      let districtId =  ContextHeader.DistrictId;
      if(districtId == undefined){
        districtId= ContextHeader.Default_districtID;
      }
      if(gradeToSendRequest == undefined){
        gradeToSendRequest = ContextHeader.Roster_Tab.GradesList[0].grade;
      }
      if((apiStartDate == "" || apiStartDate == undefined) && !Nav.test_status){
        StartDate = StartdateValues(Context_DateTab);
      }
      if((apiEndDate == "" || apiEndDate == undefined) && !Nav.test_status){
        apiEndDate = EnddateValues(Context_DateTab);
      }
      let Request = {
        rosterGrade: gradeToSendRequest,
        startDate: apiStartDate,
        endDate: apiEndDate,
        districtId: districtId,
        isPastDistrictTerm: false,
        currentTermId: currentTermId,
        termId: ContextHeader.Date_Tab.selectedTermId,
        districtName: "Sulphur Springs Union Elementary School District", //SelectedDistrict && SelectedDistrict.name  // "Sulphur Springs Union Elementary School District"
      };
      this.props.getInitialSchoolObjService(LoginDetails.JWTToken, Request);
    }
    const {getRoster_Grades_Schools, loadingFor}= ApiCalls;
    let testsApiCond =
      ((ApiCalls.getTests && AccessToTestTab.includes(currentApplication)) ||
        Get_TestStatusApi) &&
      !GetSchoolDetails &&
      !GetRosterGrades_For_TS &&
      !Nav.Summary_Reports &&
      !Nav.usageReport &&
      !defaultApi;
     const Roster_Grade_SchoolsApi = getRoster_Grades_Schools ||  loadingFor === "school";
    if (
      Nav.test_status &&
      this.props.assessmentLinkData &&
      this.props.assessmentLinkData["ComponentCode"] != undefined
    ) {
      testsApiCond =
        (ApiCalls.Get_school_sp_grades || ApiCalls.Get_Class_SP_Grade) &&
        testsApiCond;
    }

    if (testsApiCond && !Roster_Grade_SchoolsApi) {
      // let AccessToken = this.props.LoginDetails.JWTToken;
      let {
        Roster_Tab,
        Date_Tab,
        Default_districtID,
        DistrictId,
        from_rostertab,
      } = this.props.ContextHeader;
      let { Roster_Data } = this.props.UniversalSelecter;
      let Nav = this.props.NavigationByHeaderSelection;
      let selectedClass =
        Roster_Tab.SelectedClass.id == undefined
          ? ""
          : Roster_Tab.SelectedClass.id;
      const { LastActiveUniversalProps } = this.props;
      let lastClass =
        LastActiveUniversalProps.Class_Report.selectedClass.id == undefined
          ? ""
          : LastActiveUniversalProps.Class_Report.selectedClass.id;

      const { NaviGation } = LastActiveUniversalProps;

      let schoolId =
        Roster_Tab.SelectedSchool.id == undefined
          ? ""
          : Roster_Tab.SelectedSchool.id;

      let ClsIds = Nav.student
        ? Roster_Tab.StudentData_cls_ids.length ==
          Roster_Tab.StudentData_cls.length
          ? []
          : Roster_Tab.StudentData_cls_ids
        : Roster_Tab.ClassIds;

      let Sc_Ids =
        Roster_Tab.SchoolIds.length == Roster_Tab.schoolsList.length &&
        Roster_Tab.schoolsList.length > 1
          ? []
          : Roster_Tab.SchoolIds;

      // parameters related to test Status block
      let selectedIds;
      let selectedContext;
      if (Nav.student) {
        selectedIds =
          Roster_Tab.SelectedStudent.id == undefined
            ? ""
            : [Roster_Tab.SelectedStudent.id];
        selectedContext = "student";
      } else if (Nav.class) {
        selectedIds = Roster_Tab.StudentIds;
        selectedContext = "student";
      } else if (Nav.school) {
        selectedIds = Roster_Tab.ClassIds;
        selectedContext = "class";
      } else {
        selectedIds =
          Roster_Tab.schoolsList.length == Roster_Tab.SchoolIds.length
            ? Roster_Tab.SelectedDistrict.id == undefined
              ? ""
              : [Roster_Tab.SelectedDistrict.id]
            : Roster_Tab.SchoolIds;
        selectedContext =
          Roster_Tab.schoolsList.length == Roster_Tab.SchoolIds.length
            ? "district"
            : "school";
      }
      // end of parameters related to test status block

      let StartDate = Date_Tab.Report_termStartDate;
      let EndDate = Date_Tab.Report_termEndDate;

      if (Get_TestStatusApi) {
        let Date_TestStatus =
          this.props.DateTabReducer.Context_DateTab_TestStatus;

        StartDate =
          Date_TestStatus.StartDateInDateTab == ""
            ? Date_TestStatus.SelectedDistrictTerm.termStartDate
            : Date_TestStatus.StartDateInDateTab;

        EndDate =
          Date_TestStatus.EndDateInDateTab == ""
            ? Date_TestStatus.SelectedDistrictTerm.termEndDate
            : Date_TestStatus.EndDateInDateTab;

        let Resp = DateFormarFor_APiCalls(StartDate, EndDate);
        StartDate = Resp.StartDate;
        EndDate = Resp.EndDate;
      }
      if(!Nav.test_status && (StartDate == "" || StartDate == undefined)){
        StartDate = StartdateValues(this.props.DateTabReducer.Context_DateTab)
      }
      if(!Nav.test_status && (EndDate == "" || EndDate == undefined)){
        EndDate = EnddateValues(this.props.DateTabReducer.Context_DateTab)
      }
      let currentTermId = this.props.currentTermID;
      let Req_Payload = {
        ids: selectedIds,
        context: selectedContext,
        schoolIds: Sc_Ids,
        studentIds: Roster_Tab.StudentIds,
        classIds: ClsIds,
        classId: selectedClass,
        isStudent: Nav.student,
        isClass: Nav.class,
        isSchool: Nav.school,
        isDistrict: Nav.district,
        schoolId: schoolId,
        grade: Roster_Tab.selectedRosterGrade,
        rosterGrade: Roster_Tab.selectedRosterGrade,
        startDate: StartDate,
        endDate: EndDate,
        districtId: DistrictId || Default_districtID,
        isTestStatusEnable: Get_TestStatusApi,
        isPastDistrictTerm: Date_Tab.isPastDistrictTerm,
        termId: Date_Tab.selectedTermId,
        currentTermId: currentTermId, // datetab api response first alpha term_id
      };
      let GetS_Strads_LineChart =
        this.props.S_ApiCalls
          .getLineChart_OfStrands_on_StudentSelectionFromClass;

      let SelectedMultipleStudents = Roster_Tab.StudentIds;
      if (Nav.student) {
        // if (Nav.test_status) {
        //     Req_Payload.ids = [selectedClass]
        // }
        if ((Nav.S_performance || Nav.T_scores) && Nav.Overview) {
          Req_Payload.isSelectionMade = !ApiCalls.LeftViewNotSelectedInStudent;
        }
        Req_Payload.studentId = Roster_Tab.SelectedStudent.id;
        delete Req_Payload.studentIds;
        // delete Req_Payload.classIds;
        delete Req_Payload.schoolIds;
        delete Req_Payload.grade;
      } else if (Nav.class) {
        if (
          (Nav.S_performance || Nav.T_scores || Nav.test_status) &&
          Nav.Overview
        ) {
          if (Nav.test_status && Nav.Overview) {
            Req_Payload.isSelectionMade = !ApiCalls.LeftViewNotSelectedInClass;
          }
          if ((Nav.S_performance || Nav.T_scores) && Nav.Overview) {
            let classCheck = selectedClass != lastClass || !lastClass;

            if (
              classCheck &&
              selectedClass != "All" &&
              selectedClass == "" &&
              from_rostertab
            ) {
              Req_Payload.isSelectionMade =
                !ApiCalls.LeftViewNotSelectedInClass;
            } else {
              Req_Payload.isSelectionMade =
                selectedClass != ""
                  ? ApiCalls.LeftViewNotSelectedInClass
                    ? true
                    : true
                  : !ApiCalls.LeftViewNotSelectedInClass;
            }
          }

          if (
            !Nav.test_status &&
            NaviGation != undefined &&
            NaviGation.test_status
          ) {
            Req_Payload.isSelectionMade = ApiCalls.LeftViewNotSelectedInClass;
          }

          if (!Req_Payload.isSelectionMade && !Nav.test_status) {
            Req_Payload.classId = "";
            Req_Payload.studentIds = [];
          }
        }

        if (Nav.test_status) {
          Req_Payload.ids =
            selectedClass != "" ? Req_Payload.studentIds : [selectedClass];
          Req_Payload.context = selectedClass != "" ? "student" : "class";
        }

        /*   if (Nav.test_status) {
                      Req_Payload.ids = [selectedClass];
                      Req_Payload.context = "class"
  
                  } */

        delete Req_Payload.classIds;
        delete Req_Payload.schoolIds;
        delete Req_Payload.grade;
      } else if (Nav.school) {
        if (Nav.test_status) {
          Req_Payload.ids =
            Roster_Tab.SelectedSchool.id == undefined
              ? ""
              : [Roster_Tab.SelectedSchool.id];
          Req_Payload.context = "school";
        } else if ((Nav.S_performance || Nav.T_scores) && Nav.Overview) {
          Req_Payload.isSelectionMade = !ApiCalls.LeftViewNotSelectedInSchool;
        }
        Req_Payload.termId = Date_Tab.selectedTermId;
        delete Req_Payload.schoolIds;
        delete Req_Payload.classId;
        delete Req_Payload.grade;
        // delete Req_Payload.schoolIds;
      } else if (Nav.district) {
        // delete Req_Payload.schoolIds;
        if (Nav.test_status) {
          let schoolidsis = GetSelectedSchoolIdsOf_Grade(
            Roster_Tab,
            Roster_Data.ActualGrades
          );
          Req_Payload.schoolIds = schoolidsis;
          Req_Payload.ids = [DistrictId];
          Req_Payload.context = "district";
        }
        delete Req_Payload.classId;
        delete Req_Payload.schoolId;
        // delete Req_Payload.grade;
        Req_Payload.rosterGrade = Req_Payload.grade;
        Req_Payload.termId = Date_Tab.selectedTermId;
      }
      if (!Nav.test_status) {
        delete Req_Payload.ids;
        delete Req_Payload.context;
      }
      
       /* This code required for Summaray test status drilldown starts   */
      const fromContext = Nav.district
            ? 'district'
            : Nav.school
                ? 'school'
                : Nav.student
                    ? 'student'
                    : 'class';
      if(!Nav.student && this.props.SummaryReports[`${fromContext}`].assessments.apiCalls.isTestStatusEnable ){
        Req_Payload.isTestStatusEnable = true;
      }
      /* This code required for Summaray test status drilldown  ends  */

      let StdIdsAreThere =
        Nav.student || !Req_Payload.isSelectionMade
          ? true
          : Req_Payload.studentIds.length > 0;
          if(Nav.school && !Nav.test_status){
            Req_Payload.studentIds =  studentIdsCond(Roster_Tab.StudentsList, Roster_Tab.StudentIds);
          }
      StdIdsAreThere || Nav.district
        ? this.props.Get_TestTabResults(
            AccessToken,
            Req_Payload,
            GetS_Strads_LineChart,
            SelectedMultipleStudents,
            Nav
          )
        : null;
    }

    /**
     * get date tab details when user makes changes in roster tab.
     */
    if (
      ApiCalls.getDateTabFromServer &&
      AccessToDateTab.includes(currentApplication)
    ) {
      // let AccessToken = this.props.LoginDetails.JWTToken;
      let { StudentIds, SelectedSchool, SelectedClass, selectedRosterGrade } =
        this.props.ContextHeader.Roster_Tab;
      let Nav = this.props.NavigationByHeaderSelection;
      let ActualStudents =
        this.props.UniversalSelecter.Roster_Data.ActualStudents;
      let Req_Payload = {
        schoolId: SelectedSchool.id,
        classId: SelectedClass.id,
        districtId: ContextHeader.DistrictId,
        isClass: Nav.class || Nav.student,
        isSchool: Nav.school,
        grade: selectedRosterGrade,
        isDistrict: Nav.district,
        studentIds:
          ActualStudents.length == StudentIds.length ? [] : StudentIds,
      };
      this.props.Get_DateTabResults(AccessToken, Req_Payload);
    }
  }
  ApplyFilter() {
    let Nav = this.props.NavigationByHeaderSelection;
    if (Nav.usageReport) {
      return;
    }
    let StdId = this.props.UniversalSelecter.SelectedStudentId;
    let SchoolId = this.props.UniversalSelecter.Selected_school_data.id;
    let ClassId = this.props.UniversalSelecter.Selected_class_data.id;
    let AccessToken = "";
    this.props.ApplyFilterOnRoasterTab(AccessToken, SchoolId, ClassId, StdId);
  }
  /**
   * Will Return  chevron_left when UniversalFilter Is Open else Return chevron_right
   */
  ReturnchevronArrow() {
    if (this.props.UniversalFilter === "") {
      return (
        <span className="float-right">
          <i className="material-icons">chevron_right</i>
          <i className="material-icons">chevron_right</i>
        </span>
      );
    } else {
      return (
        <span className="float-right">
          <i className="material-icons">chevron_left</i>
          <i className="material-icons">chevron_left</i>
        </span>
      );
    }
  }

  /**
   * Use to Close UNiversal FIlter.
   */
  CloseFilter() {
    this.props.CloseUniversalFilter("FromCLoseFIlter");
  }
  render() {
    const ReportingAccess = this.props.LoginDetails.ReportingAccessParam;
    let Nav = this.props.NavigationByHeaderSelection;
    // block for disable roaster starts if no data in District Summary Reports added in sprint_54
    if (
      Nav.usageReport &&
      process.env.BUUR_REMOVE_UNIVERSAL_SELECTOR === "true"
    ) {
      return <div />;
    }
    const { SummaryReports, ContextHeader, LoginDetails, DateTabReducer } =
      this.props;
    const { ReportingAccessParam } = LoginDetails;
    const { Date_Tab } = ContextHeader;
    const { DateTabComponents } = DateTabReducer;
    const { TermsListWithOutUTCFormat } = DateTabComponents;
    let OnlyORRData =
      !ReportingAccessParam.includes("eAR") &&
      ReportingAccessParam.includes("ORR");
    let fromContext = Nav.district
      ? "district"
      : Nav.school
      ? "school"
      : "class";
    let context_props = SummaryReports[`${fromContext}`].assessments;
    const { standardperformance } = JSON.parse(JSON.stringify(context_props));
    let summary_stand_perf_data_length =
      standardperformance !== undefined
        ? standardperformance.data != null &&
          standardperformance.data != undefined
          ? Object.keys(standardperformance.data).length
          : 0
        : 0;
    let GrayoutRoaster = false;
    if (
      !OnlyORRData &&
      (Nav.district || Nav.school || Nav.class) &&
      Nav.Summary_Reports
    ) {
      if (
        summary_stand_perf_data_length === 0 ||
        TermsListWithOutUTCFormat && TermsListWithOutUTCFormat[0] && Date_Tab.summaryReportsTerm.termId !=
          TermsListWithOutUTCFormat[0].termId
      ) {
        GrayoutRoaster = true;
      }
    }
    // !OnlyORRData && (Nav.district || Nav.school || Nav.class) &&

    //     Nav.Summary_Reports && (summary_stand_perf_data_length === 0 || Date_Tab.summaryReportsTerm.termId != TermsListWithOutUTCFormat[0].termId) ? true : false;
    // block for disable roaster ends if no data in District Summary Reports added in sprint_54
    let currentApplication = Nav.ORR ? "ORR" : "eAR";
    currentApplication = Nav.usageReport ? "usageReport" : currentApplication;
    return (
      <div
        className={
          this.props.StickyUniversalSelector && Nav.Summary_Reports
            ? "stickey_universal_selector universal-selector"
            : "universal-selector"
        }
      >
        <div className="col-sm-12 m-0 p-0 float-left">
          <div className="universal-menu">
            <div
              className={
                GrayoutRoaster
                  ? "universal-toggler ar_summary_roaster-universal-toggler"
                  : "universal-toggler"
              }
              onClick={() =>
                !GrayoutRoaster
                  ? this.props.UniversalFilter === ""
                    ? this.props.OpenUniversalFilter("roster")
                    : this.props.CloseUniversalFilter("rosterarrowdiv")
                  : null
              }
            >
              {this.ReturnchevronArrow()}
            </div>
            <ul className="m-0 p-0">
              {ReportingAccess.length > 0 &&
              AccessToRosterTab.includes(currentApplication) ? (
                <li
                  className={
                    this.props.UniversalFilter === "roster" ? "active-menu" : ""
                  }
                >
                  <div className="menu-item-block">
                    <div
                      className={
                        GrayoutRoaster
                          ? "menu-item ar_summary_roaster-menu-item"
                          : "menu-item"
                      }
                      onClick={() =>
                        !GrayoutRoaster
                          ? this.props.UniversalFilter === "roster"
                            ? this.props.CloseUniversalFilter("fromroastr")
                            : this.props.OpenUniversalFilter("roster")
                          : null
                      }
                    >
                      <div>
                        {Nav.Summary_Reports ? (
                          <img
                            src={RosterIcon}
                            className={
                              GrayoutRoaster
                                ? "icon_dimensions ar_summary-icon_dimensions"
                                : "icon_dimensions"
                            }
                            style={{ width: "20px" }}
                          />
                        ) : (
                          <img
                            src={RosterIcon}
                            className={
                              GrayoutRoaster
                                ? "icon_dimensions ar_summary-icon_dimensions"
                                : "icon_dimensions"
                            }
                          />
                        )}
                      </div>
                      {!GrayoutRoaster ? (
                        <span
                          className={
                            Nav.Summary_Reports
                              ? "menu-name ar-menu-name"
                              : "menu-name"
                          }
                        >
                          Roster
                        </span>
                      ) : null}
                      {!GrayoutRoaster ? (
                        this.props.UniversalFilter == "roster" ? null : (
                          <div className="bec_tooltip">
                            <div className="bec_tooltip_arrow"></div>
                            <div className="bec_tooltip_content">
                              Select Student, Class, Grade, etc.
                            </div>
                          </div>
                        )
                      ) : null}
                    </div>
                    <RosterComponent />
                  </div>
                </li>
              ) : null}
              {ReportingAccess.length &&
              AccessToTestTab.includes(currentApplication) &&
              !Nav.Summary_Reports &&
              !Nav.usageReport ? (
                <TestTab CloseFilter={this.CloseFilter} />
              ) : null}
              {ReportingAccess.length > 0 && !Nav.Summary_Reports ? (
                <li
                  className={
                    this.props.UniversalFilter === "date" ? "active-menu" : ""
                  }
                >
                  <div className="menu-item-block">
                    <div
                      className="menu-item"
                      onClick={() =>
                        this.props.UniversalFilter === "date"
                          ? this.props.CloseUniversalFilter("date")
                          : this.props.OpenUniversalFilter("date")
                      }
                    >
                      <div>
                        <img src={DateIcon} className="icon_dimensions" />
                      </div>
                      <span className="menu-name">Date</span>
                      {this.props.UniversalFilter == "date" ? null : (
                        <div className="bec_tooltip">
                          <div className="bec_tooltip_arrow"></div>
                          <div className="bec_tooltip_content">
                            Select Dates
                          </div>
                        </div>
                      )}
                    </div>
                    <DateTab />
                  </div>
                </li>
              ) : null}
            </ul>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  StudentReports,
  Reports,
  TestStatusReducer,
  DateTabReducer,
  SummaryReports,
  LastActiveUniversalProps,
}) => {
  const {
    UniversalFilter,
    UniversalSelecter,
    OpenMainmenu,
    ApiCalls,
    ContextHeader,
    StickyUniversalSelector,
    NavigationByHeaderSelection,
    currentTermID,
    assessmentLinkData,
  } = Universal;
  const { LoginDetails, Auth_Apis } = Authentication;
  const { S_ApiCalls, S_StandardPerformance_Overview } = StudentReports;
  const {
    Test_Scores_OverTime,
    ApiCalls_Reports,
    StudentsListTable,
    StandardPerformance_Overview,
    ToolTipData,
  } = Reports;
  return {
    UniversalFilter,
    UniversalSelecter,
    OpenMainmenu,
    ApiCalls,
    StickyUniversalSelector,
    NavigationByHeaderSelection,
    LoginDetails,
    ContextHeader,
    S_ApiCalls,
    Test_Scores_OverTime,
    ApiCalls_Reports,
    StudentsListTable,
    StandardPerformance_Overview,
    ToolTipData,
    S_StandardPerformance_Overview,
    TestStatusReducer,
    DateTabReducer,
    LastActiveUniversalProps,
    SummaryReports,
    Auth_Apis,
    currentTermID,
    assessmentLinkData,
  };
};
export default connect(mapStateToProps, {
  // Add Action Here
  OpenUniversalFilter,
  CloseUniversalFilter,
  GetStudentsListOnSchoolAndClassID,
  ApplyFilterOnRoasterTab,
  ChangePaginationBubble,
  GetClassListOnTeacher,
  Get_TestTabResults,
  Get_DateTabResults,
  Get_TestStatus_Roster_Grades,
  getInitialSchoolObjService,
})(UniversalFilter);