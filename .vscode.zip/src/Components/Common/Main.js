import React, { Component } from "react";
import { Link, Switch, Route, useHistory } from "react-router-dom";
// import Header from './Header';
import Footer from "./Footer";
import { connect } from "react-redux";
import { STANDALONE_MODE } from "../../Utils/globalVars";
import { createBrowserHistory } from "history";

// import { withRouter } from 'react-router';

import NoDataForOrr from "../../Utils/NoDataForORR/NoDataForORR";
import { AccessToKeyFooter } from "../../Utils/globalVars";

import { withRouter, browserHistory } from "react-router";
// import Dashboard from './Dashboard';
import MainFilter from "./MainFilter/MainFilter";

import c_ts_overview from "../class/c_ts_overview";
import c_sp_overview from "../class/c_sp_overview";

import c_sp_comparison from "../class/comparison/c_sp_comparison";
import c_ts_comparison from "../class/comparison/c_ts_comparison";
import c_st_analysis from "../class/singleTestAnalysis/singleTestAnalysis";
import c_test_status from "../class/c_teststatus";
//import c_sp_comparison_modal from '../class/c_sp_comparison_modal';

import c_sp_grouping from "../class/grouping/c_sp_grouping";
// import c_ts_grouping from '../class/c_ts_grouping';

import s_ts_overview from "../Student/S_ts_Overview";
import s_ts_comparison from "../Student/comparison/s_ts_comparison";
import s_sp_overview from "../Student/s_sp_overview";
import s_sp_comparison from "../Student/comparison/s_sp_comparison";
import s_st_analysis from "../Student/singleTestAnalysis/singleTestAnalysis";
import s_test_status from "../Student/s_teststatus";
/**
 * school related components.
 */

import sc_ts_overview from "../School/sc_ts_overview";
import sc_ts_comparison from "../School/comparison/sc_ts_comparison";
import sc_sp_overview from "../School/Sc_Sp_Overview";
import sc_sp_comparison from "../School/comparison/sc_sp_comparison";
import sc_st_analysis from "../School/singleTestAnalysis/singleTestAnalysis";
import sc_test_status from "../School/sc_teststatus";
/**
 * start Summary Component
 */
import St_Sp_Summary from "../Summary/s_sp_Summary";
import cs_Sp_Summary from "../Summary/cs_sp_Summary";
import SC_Sp_Summary from "../Summary/sc_sp_summary";
import D_Sp_Summary from "../Summary/D_sp_summary";

/**
 * End Summary Component
 */

/**
 * District related components.
 */
import summaryReportsScreen from "../District/summaryScreen/summaryScreen";
import d_ts_overview from "../District/d_ts_overview";
import d_ts_comparison from "../District/comparison/d_ts_comparison";
import d_sp_overview from "../District/d_sp_overview";
import d_sp_comparison from "../District/comparison/d_sp_comparison";
import d_st_analysis from "../District/singleTestAnalysis/singleTestAnalysis";
import d_test_status from "../District/d_test_status";
import NoDataFound from "../../Utils/No_Data_Found";
import StudentFluencyChart from "../ORR/S_FluencyComponents/S_Fluency_chart.jsx";
import DistrictRLPChart from "../District_ORR/Dist_RLPComponents/Dist_RLPChart.jsx";
import NoDataFound_ON_Selection from "../../Utils/NoDataForSelection/NoDataForSelection";
import Filter from "../ORR/FilterComponents/Filter";
// import ReadingLevelProgress from '../ORR/ReadingLevelProgressComponents/Reading_Level_Progress'
import ReadingHistory from "../ORR/ReadingHistoryComponents/Reading_History";
import ErrorAnalysis from "../ORR/ErrorAnalysisComponents/Error_Analysis.jsx";
import c_Reading_History from "../Class_ORR/C_RHOComponets/c_Reading_History.jsx";
import C_ErrorChart from "../Class_ORR/Class_Error_Analysis/class_error_chart.jsx";
import C_Reading_Behavior from "../Class_ORR/C_ReadingBehaviorComponents/C_RB.jsx";

import SchoolRLPChart from "../School_ORR/Sc_RLPComponents/Sc_RLPChart.jsx";
import School_Reading_History from "../School_ORR/School_RHOComponents/school_Reading_History.jsx";
import Sc_ErrorChart from "../School_ORR/School_Error_Analysis/school_error_chart.jsx";
import District_Reading_History from "../District_ORR/Dist_RHOComponents/District_Reading_History.jsx";
import S_ReadingLevelProgress from "../ORR/ReadingLevelProgressComponents/S_RLP.jsx";
import CFAMainChart from "../Class_ORR/FluencyComponents/Fluency_Main_Chart.jsx";
import SchoolFluencyChart from "../School_ORR/School_Fluency_Components/School_FA_Main.jsx";
import DistrictFluencyChart from "../District_ORR/District_FA_Components/District_FA_Components.jsx";
import SchoolRBContainer from "../School_ORR/School_RB_Components/School_RB_Container.jsx";
import RlpChart from "../Class_ORR/ChartComponents/RLP_Chart.jsx";
import StudentReadingBehaviorChart from "../ORR/S_ReadingBehaviorsComponent/Reading_Behavior_Chart.jsx";

import BuurContainer from "./../BuurContainer/index.jsx";

import "../../../public/css/style.css";
import "../../../public/css/bootstrap.min.css";

import UniversalSelector from "./UniversalFilter/UniversalFilter";
import "core-js";
import "regenerator-runtime/runtime";

import { GetLineChartDetailsofSelected_Standards } from "../../Redux_Actions/ReportsActions";
import scrollTop from "../../../public/images/scrollTop.svg";
import {
  Close_EnableMoreOptionsCH,
  SaveMonitorScreenWidth,
  GetInitialApplicationData,
  GetSummaryDefault,
  Get_Roster_Tab_Data,
  GetUserAccessableReports,
  Separate_Roster_Tab_Details,
  Get_DateTabResults,
  ClickStudentDataInfoIcon,
  ClickPdTestsInfoIcon,
  ClickPdDatesInfoIcon,
  StoreDataFromAssessment,
  SaveContextSelection,
} from "../../Redux_Actions/UniversalSelectorActions";
import SummaryTab from "../Chart_Summary/Summary.jsx";
import {
  CloseUniversalFilter,
  Get_Roster_GradesAndschools,
  Get_Roster_Classes,
  Get_Roster_Teachers_Students,
} from "../../Redux_Actions/UniversalSelectorActions_Secondary";
import {Get_ClassObject_WhichHas_Reports} from '../../Redux_Actions/UniversalRosterActions';
import LoadingScreen from "../../Utils/LoadingScreen/LoadingScreen";
import { Reset_state_in_all_reducers } from "../../Redux_Actions/AuthenticationAction";
import ORR_Home from "../ORR/ORR_Home";
import PastDistictTermBanner from "../../Utils/PastDistictTermBanner/PastDistictTermBanner";
import { callGet_ClassObject_WhichHas_Reports } from "../../services/universalSelector/Roster.service";

import { getCusrrentDistrictTerm, newDateHandling } from "../ReusableComponents/AllReusableFunctions_Two";


class Full extends Component {
  constructor(props) {
    super(props);
    this.ReportDivRef = {};
    this.onresize = this.onresize.bind(this);
    this.state = {
      theposition: 0,
      locationIsUpdated: false,
    };
    this.handleScroll = this.handleScroll.bind(this);
    this.ScrollClickHandler = this.ScrollClickHandler.bind(this);
  }

  componentWillUnmount() {
    this.props.Reset_state_in_all_reducers;
    window.removeEventListener("scroll", this.handleScroll);
  }

  handleScroll() {
    const winScroll =
      document.body.scrollTop || document.documentElement.scrollTop;

    if (
      (this.state.theposition > 80 && winScroll > 80) ||
      (this.state.theposition < 80 && winScroll < 80)
    ) {
      // No Need to set State as it won't need to change
    } else {
      this.setState({
        theposition: winScroll,
      });
    }
  }

  InitialApiCall() {
    this.props.Reset_state_in_all_reducers();
    let AccessToken;
    let selectedSchoolId;
    if (STANDALONE_MODE) {
      AccessToken = this.props.LoginDetails.JWTToken;
      selectedSchoolId = this.props.LoginDetails.schoolId;
      // this.props.Get_JWTToken_Autphentication(null, "superadmin", "password", "techsupport");
    } else {
      AccessToken =
        this.props.LoginDetailsFromIndex !== undefined
          ? this.props.LoginDetailsFromIndex.JWTToken
          : null;
      selectedSchoolId =
        this.props.LoginDetailsFromIndex !== undefined
          ? this.props.LoginDetailsFromIndex.selectedSchoolId
          : "";
    }
    this.props.GetUserAccessableReports(AccessToken, selectedSchoolId);
    window.addEventListener("resize", this.onresize);
    let ScreenWidth = window.screen.availWidth;
    this.props.SaveMonitorScreenWidth(ScreenWidth);
    this.props.SaveMonitorScreenWidth(ScreenWidth);
  }

  componentDidMount() {
    let CallingInitialLoad = false;

    let customHistory = createBrowserHistory();

    let QueryParams = customHistory.location.hash.split("?");
    // if (QueryParams[1] == undefined || QueryParams[1] == null) {
    //   QueryParams[1] = "ComponentCode=X53226&ComponentTitle=Unit%204%20Assessment%20(Gr.%20K)&DueDate=2021-07-31&Complete=11"
    // }

    if (QueryParams[1]) {
      let QueryParamIs = QueryParams[1].replace(/%20/gi, " ");

      let SplitEachParam = QueryParamIs.split("&");
      let DataFromAssessment = [];
      SplitEachParam &&
        SplitEachParam.map((item) => {
          let SplitEachParamItem = item.split("=");
          DataFromAssessment[SplitEachParamItem[0]] = SplitEachParamItem[1];
        });
      if (DataFromAssessment["ComponentCode"]) {
        this.props.StoreDataFromAssessment(DataFromAssessment);
      }
    }

    if (window.performance) {
      if (performance.navigation.type == 1) {
        let CurrentDateTime = new Date();
        let ApiTime =newDateHandling(this.props.Universal.DateTimeOf_DefaultApi);
        
        var seconds = (CurrentDateTime.getTime() - ApiTime.getTime()) / 1000;
        let DefaultApi = this.props.Universal.loadingScreenInUniversal;
        if (seconds > 301 || isNaN(seconds) || DefaultApi) {
          CallingInitialLoad = true;
          this.InitialApiCall();
        }
      } else {
        // alert("This page is not reloaded");
        CallingInitialLoad = true;
        this.InitialApiCall();
      }
    }

    window.onpopstate = () => {
      this._isMounted = true;

      if (
        this._isMounted &&
        (QueryParams[1] == undefined ||
          QueryParams[1] == null ||
          QueryParams[1] == "")
      ) {
        customHistory = createBrowserHistory();
        let PathArray = customHistory.location.hash.split("/");
        let CurrentNav = this.props.NavigationByHeaderSelection;
        if (PathArray.length > 3) {
          let First = CurrentNav.student
            ? "student"
            : CurrentNav.class
            ? "class"
            : CurrentNav.school
            ? "school"
            : CurrentNav.district
            ? "district"
            : "";
          let Second = CurrentNav.S_performance
            ? "standard_performance"
            : CurrentNav.T_scores
            ? "testscore"
            : CurrentNav.st_analysis
            ? "singleTestAnalysis"
            : CurrentNav.test_status
            ? "teststatus"
            : "";
          let Third = CurrentNav.Overview
            ? "overview"
            : CurrentNav.comparison
            ? "comparison"
            : CurrentNav.grouping
            ? "grouping"
            : CurrentNav.summary
            ? "summary"
            : "";
          if (
            First === PathArray[2] &&
            Second === PathArray[3] &&
            (Third === PathArray[4] ||
              PathArray[3] === "singleTestAnalysis" ||
              PathArray[3] === "teststatus")
          ) {
          } else if (
            PathArray[1] === "reporting" &&
            CurrentNav.Assessement &&
            PathArray[PathArray.length - 1] !== "summaryreports"
          ) {
            // alert(' window.location.replace 1 ')
            window.location.replace(document.referrer);
          }
        } else if (
          PathArray[1] === "reporting" &&
          PathArray.length == 2 &&
          !CallingInitialLoad &&
          CurrentNav.Summary_Reports) {
            const { pathname } = this.props.location;
            let summ_context = CurrentNav.district
            ? "district"
            : CurrentNav.school
            ? "school"
            : CurrentNav.class
            ? "class"
            : "student";

          if (pathname !== `/reporting/${summ_context}/summaryreports`) {
            this.props.history.push(`/reporting/${summ_context}/summaryreports`);
          }

        }
        else if (
          PathArray[1] === "reporting" &&
          PathArray.length == 2 &&
          !CallingInitialLoad &&
          (CurrentNav.Overview ||
            CurrentNav.comparison ||
            CurrentNav.grouping ||
            CurrentNav.summary) &&
          PathArray[PathArray.length - 1] !== "summaryreports"
        ) {
          // alert(' window.location.replace 2 ')
          window.location.replace(document.referrer);
        }
      }
    };

    window.addEventListener("scroll", this.handleScroll);
  }
  onresize(e) {
    //note i need to pass the event as an argument to the function
    let width = e.target.outerWidth;
    let UserScreenWidth = this.props.Universal.UserScreenWidth;
    let Class_STrand_HeaderCount =
      this.props.Reports.StandardPerformance_Overview.headerEnd -
      this.props.Reports.StandardPerformance_Overview.headerStart;
    if (
      (Class_STrand_HeaderCount == 4 && width > 1281) ||
      (Class_STrand_HeaderCount == 6 && width < 1281)
    ) {
      this.props.SaveMonitorScreenWidth(width);
    }
  }
  /**
   * To check Conditions
   */
  componentDidUpdate(nextProps) {
    const { pathname } = this.props.location;
    let { Universal, LastActiveUniversalProps } = this.props;
    const {
      ApiCalls,
      ContextHeader,
      NavigationByHeaderSelection,
      UniversalSelecter,
      currentTermID,
      loadingScreenInUniversal,
    } = Universal;

    callGet_ClassObject_WhichHas_Reports(this.props)
    let Nav = NavigationByHeaderSelection;

    const reportsAccess =
      this.props.Authentication.LoginDetails.ReportingAccessParam;

    let customHistory = createBrowserHistory();
    let PathArray = customHistory.location.hash.split("/");

    const isItReportingUrl =
      PathArray &&
      (PathArray[0] === "reporting" ||
        PathArray[1] === "reporting" ||
        PathArray[1] === "");

    const doesNotHaveAccessToAR = !reportsAccess.includes("eAR");

    const {
      DefaultApiSuccess,
      Done_RosterTab_Details_Setup,
      DefaultSummaryApiSuccess,
    } = ApiCalls;
    if (DefaultApiSuccess && Done_RosterTab_Details_Setup) {
      let assessmentLinkData = this.props.Universal.assessmentLinkData;
      if (
        assessmentLinkData &&
        assessmentLinkData &&
        assessmentLinkData["ComponentCode"] &&
        !Nav.test_status
      ) {
        this.props.SaveContextSelection("test_status");
      }
    }

    let SchoolApiActive =
      ApiCalls.loadingFor == "school" || ApiCalls.Get_Selected_School_Info;
    let context = Nav.district
      ? "district"
      : Nav.school
      ? "school"
      : Nav.class
      ? "class"
      : "student";
    if (Nav.usageReport) {
      pathname == "/reporting/usage"
        ? null
        : this.props.history.push("/reporting/usage");
    } else if (Nav.Summary_Reports && isItReportingUrl) {
      if (pathname !== `/reporting/${context}/summaryreports`) {
        // nextProps.history.push('/reporting/district/summaryreports');
        this.props.history.push(`/reporting/${context}/summaryreports`);
      }
    } else if (Nav.Assessement && isItReportingUrl) {
      if (Nav.class) {
        //-- Class View
        if (Nav.T_scores) {
          //-- Class+Test_Score View

          if (
            Nav.Overview &&
            pathname !== "/reporting/class/testscore/overview"
          ) {
            //-- Class+Test_Score+Overview View

            this.props.history.push("/reporting/class/testscore/overview");
          } else if (
            Nav.comparison &&
            pathname !== "/reporting/class/testscore/comparison"
          ) {
            //-- Class+Test_Score+Comparison View

            this.props.history.push("/reporting/class/testscore/comparison");
          }
        } else if (
          Nav.st_analysis &&
          pathname !== "/reporting/class/singleTestAnalysis"
        ) {
          //-- Class+Test_Score+Comparison View

          this.props.history.push("/reporting/class/singleTestAnalysis");
        } else if (
          Nav.test_status &&
          pathname !== "/reporting/class/teststatus"
        ) {
          this.props.history.push("/reporting/class/teststatus");
        } else if (Nav.S_performance) {
          //-- Class+StandardPerformance View
          if (
            Nav.Overview &&
            pathname !== "/reporting/class/standard_performance/overview"
          ) {
            //-- Class+StandardPerformance+Overview View

            this.props.history.push(
              "/reporting/class/standard_performance/overview"
            );
          } else if (
            Nav.comparison &&
            pathname !== "/reporting/class/standard_performance/comparison"
          ) {
            //-- Class+StandardPerformance+Comparison View

            this.props.history.push(
              "/reporting/class/standard_performance/comparison"
            );
          } else if (
            Nav.summary &&
            pathname !== "/reporting/class/standard_performance/summary"
          ) {
            this.props.history.push(
              "/reporting/class/standard_performance/summary"
            );
          } else if (
            Nav.grouping &&
            pathname !== "/reporting/class/standard_performance/grouping/popup"
          ) {
            //-- Class+StandardPerformance+Comparison View

            this.props.history.push(
              "/reporting/class/standard_performance/grouping/popup"
            );
          }
        }
      } else if (Nav.Assessement) {
        if (Nav.class) {
          //-- Class View
          if (Nav.T_scores) {
            //-- Class+Test_Score View
            if (
              Nav.Overview &&
              pathname !== "/reporting/class/testscore/overview"
            ) {
              //-- Class+Test_Score+Overview View
              this.props.history.push("/reporting/class/testscore/overview");
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/class/testscore/comparison"
            ) {
              //-- Class+Test_Score+Comparison View
              this.props.history.push("/reporting/class/testscore/comparison");
            }
          } else if (
            Nav.st_analysis &&
            pathname !== "/reporting/class/singleTestAnalysis"
          ) {
            //-- Class+Test_Score+Comparison View
            this.props.history.push("/reporting/class/singleTestAnalysis");
          } else if (
            Nav.test_status &&
            pathname !== "/reporting/class/teststatus"
          ) {
            this.props.history.push("/reporting/class/teststatus");
          } else if (Nav.S_performance) {
            //-- Class+StandardPerformance View
            if (
              Nav.Overview &&
              pathname !== "/reporting/class/standard_performance/overview"
            ) {
              //-- Class+StandardPerformance+Overview View
              this.props.history.push(
                "/reporting/class/standard_performance/overview"
              );
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/class/standard_performance/comparison"
            ) {
              //-- Class+StandardPerformance+Comparison View
              this.props.history.push(
                "/reporting/class/standard_performance/comparison"
              );
            } else if (
              Nav.summary &&
              pathname !== "/reporting/class/standard_performance/summary"
            ) {
              this.props.history.push(
                "/reporting/class/standard_performance/summary"
              );
            } else if (
              Nav.grouping &&
              pathname !==
                "/reporting/class/standard_performance/grouping/popup"
            ) {
              //-- Class+StandardPerformance+Comparison View
              this.props.history.push(
                "/reporting/class/standard_performance/grouping/popup"
              );
            }
          }
        } else if (Nav.school) {
          if (Nav.T_scores) {
            if (
              Nav.Overview &&
              pathname !== "/reporting/school/testscore/overview"
            ) {
              this.props.history.push("/reporting/school/testscore/overview");
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/school/testscore/comparison"
            ) {
              this.props.history.push("/reporting/school/testscore/comparison");
            }
          } else if (
            Nav.st_analysis &&
            pathname !== "/reporting/school/singleTestAnalysis"
          ) {
            //-- Class+Test_Score+Comparison View
            this.props.history.push("/reporting/school/singleTestAnalysis");
          } else if (
            Nav.test_status &&
            pathname !== "/reporting/school/teststatus"
          ) {
            this.props.history.push("/reporting/school/teststatus");
          } else if (Nav.S_performance) {
            if (
              Nav.Overview &&
              pathname !== "/reporting/school/standard_performance/overview"
            ) {
              this.props.history.push(
                "/reporting/school/standard_performance/overview"
              );
            } else if (
              Nav.summary &&
              pathname !== "/reporting/school/standard_performance/summary"
            ) {
              this.props.history.push(
                "/reporting/school/standard_performance/summary"
              );
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/school/standard_performance/comparison"
            ) {
              this.props.history.push(
                "/reporting/school/standard_performance/comparison"
              );
            }
          }
        } else if (Nav.district) {
          if (Nav.T_scores) {
            if (
              Nav.Overview &&
              pathname !== "/reporting/district/testscore/overview"
            ) {
              nextProps.history.push("/reporting/district/testscore/overview");
              this.props.history.push("/reporting/district/testscore/overview");
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/district/testscore/comparison"
            ) {
              nextProps.history.push(
                "/reporting/district/testscore/comparison"
              );
              this.props.history.push(
                "/reporting/district/testscore/comparison"
              );
            }
          } else if (
            Nav.st_analysis &&
            pathname !== "/reporting/district/singleTestAnalysis"
          ) {
            //-- Class+Test_Score+Comparison View
            nextProps.history.push("/reporting/district/singleTestAnalysis");
            this.props.history.push("/reporting/district/singleTestAnalysis");
          } else if (
            Nav.test_status &&
            pathname !== "/reporting/district/teststatus"
          ) {
            //-- Class+Test_Score+Comparison View
            nextProps.history.push("/reporting/district/teststatus");
            this.props.history.push("/reporting/district/teststatus");
          } else if (Nav.S_performance) {
            if (
              Nav.Overview &&
              pathname !== "/reporting/district/standard_performance/overview"
            ) {
              nextProps.history.push(
                "/reporting/district/standard_performance/overview"
              );
              this.props.history.push(
                "/reporting/district/standard_performance/overview"
              );
            } else if (
              Nav.summary &&
              pathname !== "/reporting/district/standard_performance/summary"
            ) {
              nextProps.history.push(
                "/reporting/district/standard_performance/summary"
              );
              this.props.history.push(
                "/reporting/district/standard_performance/summary"
              );
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/district/standard_performance/comparison"
            ) {
              nextProps.history.push(
                "/reporting/district/standard_performance/comparison"
              );
              this.props.history.push(
                "/reporting/district/standard_performance/comparison"
              );
            }
          }
        } else if (Nav.student) {
          if (Nav.T_scores) {
            if (
              Nav.Overview &&
              pathname !== "/reporting/student/testscore/overview"
            ) {
              this.props.history.push("/reporting/student/testscore/overview");
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/student/testscore/comparison"
            ) {
              this.props.history.push(
                "/reporting/student/testscore/comparison"
              );
            }
          } else if (
            Nav.st_analysis &&
            pathname !== "/reporting/student/singleTestAnalysis"
          ) {
            //-- Class+Test_Score+Comparison View
            this.props.history.push("/reporting/student/singleTestAnalysis");
          } else if (
            Nav.test_status &&
            pathname !== "/reporting/student/teststatus"
          ) {
            this.props.history.push("/reporting/student/teststatus");
          } else if (Nav.S_performance) {
            if (
              Nav.Overview &&
              pathname !== "/reporting/student/standard_performance/overview"
            ) {
              this.props.history.push(
                "/reporting/student/standard_performance/overview"
              );
            } else if (
              Nav.comparison &&
              pathname !== "/reporting/student/standard_performance/comparison"
            ) {
              this.props.history.push(
                "/reporting/student/standard_performance/comparison"
              );
            } else if (
              Nav.summary &&
              pathname !== "/reporting/student/standard_performance/summary"
            ) {
              this.props.history.push(
                "/reporting/student/standard_performance/summary"
              );
            }
          }
        }
      }
    } else if (
      Nav.ORR &&
      ApiCalls.Done_RosterTab_Details_Setup &&
      !SchoolApiActive &&
      isItReportingUrl
    ) {
      if (Nav.rlp) {
        pathname == `/reporting/${context}/orr/reading_level_progress`
          ? null
          : this.props.history.push(
              `/reporting/${context}/orr/reading_level_progress`
            );
      } else if (Nav.readingHistory) {
        pathname == `/reporting/${context}/orr/reading_history`
          ? null
          : this.props.history.push(
              `/reporting/${context}/orr/reading_history`
            );
      } else if (Nav.fluencyAnalysis) {
        pathname == `/reporting/${context}/orr/fluency_analysis`
          ? null
          : this.props.history.push(
              `/reporting/${context}/orr/fluency_analysis`
            );
      } else if (Nav.errorAnalysis) {
        pathname == `/reporting/${context}/orr/error_analysis`
          ? null
          : this.props.history.push(`/reporting/${context}/orr/error_analysis`);
      } else if (Nav.readingBehaviors) {
        pathname == `/reporting/${context}/orr/reading_behaviors`
          ? null
          : this.props.history.push(
              `/reporting/${context}/orr/reading_behaviors`
            );
      } else if (Nav.Summary_Tab) {
        pathname == `/reporting/${context}/summary`
          ? null
          : this.props.history.push(`/reporting/${context}/summary`);
      }
    } else if (Nav.Summary_Tab && isItReportingUrl) {
      pathname == `/reporting/${context}/summary`
        ? null
        : this.props.history.push("/reporting/student/summary");
    }
    /**
     * Call Api for Default reports Data
     */

    if (
      this.props.Auth_Apis.defaultApi ||
      ApiCalls.CallDefaultOn_District_Change
    ) {
      let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
      const { lazyLoad_eAR_Default_Api, defaultApi } = this.props.Auth_Apis;
      let ReqPaylod = {};
      let isTermIdsEqualAndNull = false;
      if (defaultApi) {
        ReqPaylod = {
          termId: null,
        };
      } else {
        ReqPaylod = ContextHeader.Date_Tab.selectedterm_Obj;
      }
      ReqPaylod.IS_ORR_ACCESSIBLE =
        this.props.Authentication.LoginDetails.ReportingAccessParam !==
          undefined ||
        this.props.Authentication.LoginDetails.ReportingAccessParam.length > 0
          ? this.props.Authentication.LoginDetails.ReportingAccessParam.includes(
              "ORR"
            )
          : false;
      ReqPaylod.schoolId = this.props.Authentication.LoginDetails.schoolId;

      ReqPaylod.currentTermId = currentTermID;

      /**
       * if we calling default API for the first time after reports load. then the term ID should be null.
       */
      if (lazyLoad_eAR_Default_Api) {
        ReqPaylod.termId = null;
        ReqPaylod.currentTermId = null;
      }

      let DateTabChanged = UniversalSelecter.Date.DateTabUpdated;
      if (ReqPaylod.currentTermId == ReqPaylod.termId) {
        isTermIdsEqualAndNull = true;
      }

      /**
       * eAR deafult api lazy loading sjould happend once roster details setup for summary after get summary default api success.
       */
      if (lazyLoad_eAR_Default_Api && !ApiCalls.Done_RosterTab_Details_Setup) {
      } else {
        this.props.GetInitialApplicationData(
          AccessToken,
          ReqPaylod,
          DateTabChanged,
          isTermIdsEqualAndNull,
          lazyLoad_eAR_Default_Api
        );
      }
    }
    if (
      ApiCalls.getDateTabFromServer_success &&
      this.props.Auth_Apis.getSummaryDefault
    ) {
      let { TermsListWithOutUTCFormat } =
        this.props.DateTabReducer.DateTabComponents;

      let currentTermIs;

      if (TermsListWithOutUTCFormat) {
        // TermsListWithOutUTCFormat.map((item) => {
        //   if (currentTermIs) {
        //     if (currentTermIs.termId < item.termId) {
        //       currentTermIs = item;
        //     }
        //   } else {
        //     currentTermIs = item;
        //   }
        // });
        currentTermIs = getCusrrentDistrictTerm(TermsListWithOutUTCFormat)
      }

      let req = {
        ...currentTermIs,
        isSummmaryInfo: true,
      };

      this.props.GetSummaryDefault(
        this.props.Authentication.LoginDetails.JWTToken,
        req
      );
    }

    /**
     * get roster tab details.
     */
    let { getSummaryDefault } = this.props.Auth_Apis;
    if (this.props.Auth_Apis.RosterApi && !getSummaryDefault) {
      let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
      let DistTerm = ContextHeader.Date_Tab.selectedterm_Obj;
      DistTerm = DistTerm == null || DistTerm == undefined ? {} : DistTerm;
      if (DistTerm.termId == undefined) {
        DistTerm = {
          termId: null,
        };
      }

      let { SelectedSchool, selectedRosterGrade } = Nav.Summary_Reports
        ? ContextHeader.Summary_Roster_Data
        : ContextHeader.Roster_Tab;
      let ReqPayload = {
        dateTerm: DistTerm,
        school: SelectedSchool,
        rosterGrade: selectedRosterGrade,
      };

      let IsDistrictAdmin =
        this.props.Authentication.LoginDetails.UserRole == "DISTRICT_ADMIN" &&
        !doesNotHaveAccessToAR;
      let NostrandsONInitialLoad = IsDistrictAdmin
        ? this.props.DistrictReducer.D_StandardPerformance_Overview
            .StandardPerformanceFilter.NodataInStrands
        : null;

      let { Date_TabFullDetails } = LastActiveUniversalProps;
      let DefaultTermObj = {};
      if (Array.isArray(Date_TabFullDetails)) {
        Date_TabFullDetails.map((item) => {
          if (item.termId == currentTermID) {
            DefaultTermObj = { ...item };
            ReqPayload.dateTerm = { ...item };
          }
        });
      }
      let Dist_StrandsGrades_Obj =
        this.props.DistrictReducer.D_StandardPerformance_Overview
          .StandardPerformanceFilter.TestGrade;
      this.props.Get_Roster_Tab_Data(
        AccessToken,
        ReqPayload,
        IsDistrictAdmin,
        NostrandsONInitialLoad,
        DefaultTermObj,
        Dist_StrandsGrades_Obj
      );
    }

    if (this.props.Auth_Apis.DatesApi) {
      let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
      this.props.Get_DateTabResults(AccessToken, {});
    }

    if (ApiCalls.getRoster_Grades_Schools) {
      let termIdOfD =
        currentTermID != null && currentTermID != "" ? currentTermID : null;
      let { SelectedDistrict } = Nav.Summary_Reports
        ? ContextHeader.Summary_Roster_Data
        : ContextHeader.Roster_Tab;
      let districtId = SelectedDistrict.id;
      if(districtId == undefined){
        districtId = ContextHeader.Default_districtID;
      }
     
      if(termIdOfD == null && this.props.DateTabReducer.Context_DateTab.SelectedDistrictTerm.termId != undefined){
        termIdOfD = this.props.DateTabReducer.Context_DateTab.SelectedDistrictTerm.termId;
      }
       let req = {
        districtId: districtId,
        termId: termIdOfD,
      };
      let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
      this.props.Get_Roster_GradesAndschools(AccessToken, req);
    }

    if (ApiCalls.getRoster_Classes) {
      let req = {
        districtId: ContextHeader.Roster_Tab.SelectedDistrict.id,
        termId: ContextHeader.Date_Tab.selectedTermId,
        schoolIds: UniversalSelecter.Roster_Data.SchoolIds,
        grade: UniversalSelecter.Roster_Data.SelectedGrade,
      };

      let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
      this.props.Get_Roster_Classes(AccessToken, req);
    }

    if (ApiCalls.getRoster_Student_Teachers) {
      let req = {
        districtId: ContextHeader.Roster_Tab.SelectedDistrict.id,
        termId: ContextHeader.Date_Tab.selectedTermId,
        classIds: UniversalSelecter.Roster_Data.ClassIds,
        grade: UniversalSelecter.Roster_Data.SelectedGrade,
      };

      let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
      this.props.Get_Roster_Teachers_Students(AccessToken, req);
    }

    this.AllApiCalls_OnStateUpdate();
    if (!loadingScreenInUniversal) {
      this.UniversalSelector_ApiCalls_AfterInitialLoad();
    }
  }

  componentDidCatch(error, info) {
    console.log(" error in  main ", error);
  }

  UniversalSelector_ApiCalls_AfterInitialLoad() {
    const AccessToken = this.props.Authentication.LoginDetails.JWTToken;
    let U_APis = this.props.Universal.ApiCalls;
    let Auth_APis = this.props.Auth_Apis;

    let DateTabUpdated =
      this.props.Universal.UniversalSelecter.Date.DateTabUpdated;
    let Accesssrepors =
      this.props.Authentication.LoginDetails.ReportingAccessParam;
    let UserRole = this.props.Universal.ContextHeader.User_Role;
    let NostrandsONInitialLoad =
      UserRole == "DISTRICT_ADMIN"
        ? this.props.DistrictReducer.D_StandardPerformance_Overview
            .StandardPerformanceFilter.NodataInStrands
        : UserRole == "SCHOOL_ADMIN"
        ? this.props.schoolReducer.Sc_StandardPerformance_Overview
            .StandardPerformanceFilter.NodataInStrands
        : this.props.Reports.StandardPerformance_Overview
            .StandardPerformanceFilter.NodataInStrands;
    /**
     * After Default success and roster tab success. store classes and students in different
     */

    let firstSeparateRoster =
      !DateTabUpdated &&
      U_APis.RosterTabApiSuccess &&
      U_APis.SeparateRosterDetails &&
      (U_APis.DefaultApiSuccess || U_APis.DefaultSummaryApiSuccess) &&
      U_APis.getDateTabFromServer_success;

    let secondSeparateRoster =
      (U_APis.DefaultApiSuccess || U_APis.DefaultSummaryApiSuccess) &&
      DateTabUpdated &&
      U_APis.SeparateRosterDetails;

    let thirdSeparateRoster =
      U_APis.RosterTabApiSuccess &&
      U_APis.SeparateRosterDetails &&
      (!U_APis.DefaultApiSuccess ||
        NoReportsForTheUser ||
        !U_APis.DefaultSummaryApiSuccess);

    if (firstSeparateRoster) {
      let DateTerms =
        this.props.Universal.ContextHeader.Date_Tab.DistrictTerms_New;
      let DefaulTermId =
        this.props.Universal.ContextHeader.Date_Tab.selectedTermId;

      let DefaultTermObj = {};

      if (Array.isArray(DateTerms)) {
        DateTerms.map((item) => {
          if (item.termId == DefaulTermId) {
            DefaultTermObj = { ...item };
          }
        });
      }

      if (Object.keys(DefaultTermObj).length == 0) {
        DefaultTermObj = DateTerms[0];
      }
      this.props.Separate_Roster_Tab_Details(
        NostrandsONInitialLoad,
        DefaultTermObj,
        Accesssrepors
      );
    }

    /**
     * if district term is changed
     */

    if (secondSeparateRoster) {
      let DefaultTermObj =
        this.props.Universal.ContextHeader.Date_Tab.selectedterm_Obj;
      this.props.Separate_Roster_Tab_Details(
        NostrandsONInitialLoad,
        DefaultTermObj,
        Accesssrepors
      );
    }

    let NoReportsForTheUser =
      this.props.Universal.NoData_For_Selection_Universal.NoReportsForTheUser;

    if (thirdSeparateRoster) {
      let DateTerms = this.props.LastActiveUniversalProps.Date_TabFullDetails;
      // let DefaulTermId = this.props.Universal.ContextHeader.Date_Tab.selectedTermId;

      if (Array.isArray(DateTerms)) {
        let DefaultTermObj = { ...DateTerms[0] };
        let NostrandsONInitialLoad_ = false;
        this.props.Separate_Roster_Tab_Details(
          NostrandsONInitialLoad_,
          DefaultTermObj,
          Accesssrepors
        );
      }
    }
  }

  /**
   * it will check to make api calls on state update.
   */
  AllApiCalls_OnStateUpdate() {
    let DisplayData = this.props.Universal.ContextHeader;
    let U_Selector = this.props.Universal.UniversalSelecter.TestTab;
    /*  If school and class is selected , will request for the test data of selected school & class */
    let Reports_APICall = this.props.Reports.ApiCalls_Reports;
    let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
    let Context_Header = this.props.Universal.ContextHeader;
  }

  ScrollClickHandler() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  render() {
    const { Auth_Apis, Authentication } = this.props;
    const { LoginDetails } = Authentication;
    const {
      ApiCalls,
      loadingScreenInUniversal,
      NoData_For_Selection_Universal,
    } = this.props.Universal;
    let U_APis = ApiCalls;
    let Univer_Apicall = ApiCalls;
    let screen_loading =
      loadingScreenInUniversal &&
      !Univer_Apicall.DefaultApiSuccess &&
      !U_APis.DefaultSummaryApiSuccess &&
      !Auth_Apis.lazyLoad_eAR_Default_Api
        ? true
        : false;

    let { DefaultTerm, SelectedDistrictTerm } =
      this.props.DateTabReducer.DateTabComponents;
    if (
      !screen_loading &&
      loadingScreenInUniversal &&
      DefaultTerm &&
      SelectedDistrictTerm &&
      SelectedDistrictTerm.termId !== DefaultTerm.termId
    ) {
      screen_loading = true;
    }

    if (screen_loading && LoginDetails.DisplayTechnicalError) {
      screen_loading = false;
    }

    const NoData_Or_Technical_Error =
      LoginDetails.DisplayNodata || LoginDetails.DisplayTechnicalError;

    let NodataForSelection = CheckNoDataForSelectionOptiosProp(this.props);

    let NoRosterTabDetails = NoData_For_Selection_Universal.NoRosterTabDetails;

    let ReportingAccess = this.props.LoginDetails.ReportingAccessParam;

    const userRole = LoginDetails.UserRole;

    let Nav = this.props.NavigationByHeaderSelection;
    const { pathname } = this.props.location;

    let SummaryReports_Reducer = this.props.SummaryReports;
    let NoSummaryReports = Check_Summary_Reports_Data(
      SummaryReports_Reducer,
      Nav
    );

    return (
      <div className="bec_reporting_main">
        {screen_loading ? (
          <div className="display-loading-main">
            <LoadingScreen />
          </div>
        ) : null}

        <div
          onClick={() => {
            if (this.props.Universal.UniversalFilter === "") {
              null;
            } else if (
              this.props.Universal.UniversalSelecter.Roster
                .StudentDataInfoIcon == "roster"
            ) {
              // this.props.ClickStudentDataInfoIcon("")
            } else {
              this.props.CloseUniversalFilter("OutSideUniversalClickRef");
            }
          }}
          className={
            this.props.Universal.UniversalFilter !== "" ? "back-drop" : ""
          }
        ></div>

        {/* <Header /> */}
        {/* {this.NodataFound()} */}

        {screen_loading ? null : ((NoData_Or_Technical_Error &&
            Nav.Assessement) ||
            this.props.NoaccessToReports ||
            this.props.Universal.NoData_For_Selection_Universal
              .Attention_School_and_District_msg) &&
          !Nav.usageReport ? (
          <NoDataFound NodataFound={LoginDetails.DisplayNodata} />
        ) : ((NodataForSelection &&
            (!Nav.Summary_Reports ||
              this.props.Universal.NoData_For_Selection_Universal
                .NodataInUniversalTab)) ||
            NoRosterTabDetails ||
            NoSummaryReports) &&
          !Nav.Summary_Reports &&
          this.props.Universal.NoData_For_Selection_Universal &&
          !Nav.usageReport ? (
          <NoDataFound_ON_Selection />
        ) : (
          <main ref={(node) => (this.ReportDivRef = node)}>
            <MainFilter />
            <div
              className={
                Nav.Assessement || Nav.ORR
                  ? "bec-body"
                  : "bec-body orr_bec_body_reset"
              }
            >
              {screen_loading ? null : (
                <div className="bec-body-inr">
                  {Nav.Assessement === true ? (
                    this.props.Universal.isPastDistrictTerm ? (
                      <PastDistictTermBanner
                        Nav={Nav}
                        UserRole={this.props.Universal.ContextHeader.User_Role}
                      />
                    ) : null
                  ) : null}
                  <UniversalSelector />
                  <Switch>
                    {/**

                     * All Class related Routes
                     */}
                    <Route
                      path="/reporting/usage"
                      name="usage"
                      component={BuurContainer}
                    />
                    <Route
                      path="/reporting/district/summaryreports"
                      name="district_summaryreports"
                      component={summaryReportsScreen}
                    />
                    <Route
                      path="/reporting/school/summaryreports"
                      name="school_summaryreports"
                      component={summaryReportsScreen}
                    />
                    <Route
                      path="/reporting/class/summaryreports"
                      name="class_summaryreports"
                      component={summaryReportsScreen}
                    />
                    <Route
                      path="/reporting/student/summaryreports"
                      name="student_summaryreports"
                      component={summaryReportsScreen}
                    />
                    <Route
                      path="/reporting/student/summary"
                      name="student_summary"
                      component={SummaryTab}
                    />
                    <Route
                      path="/reporting/class/summary"
                      name="class_summary"
                      component={SummaryTab}
                    />
                    <Route
                      path="/reporting/school/summary"
                      name="school_summary"
                      component={SummaryTab}
                    />
                    <Route
                      path="/reporting/district/summary"
                      name="district_summary"
                      component={SummaryTab}
                    />
                    <Route
                      path="/reporting/student/standard_performance/summary"
                      name="student_standards_summary"
                      component={St_Sp_Summary}
                    />
                    <Route
                      path="/reporting/class/standard_performance/summary"
                      name="Class_standards_summary"
                      component={cs_Sp_Summary}
                    />
                    <Route
                      path="/reporting/school/standard_performance/summary"
                      name="School_standards_summary"
                      component={SC_Sp_Summary}
                    />
                    <Route
                      path="/reporting/district/standard_performance/summary"
                      name="District_standards_summary"
                      component={D_Sp_Summary}
                    />

                    <Route
                      path="/reporting/class/testscore/overview"
                      name="class_TestScore_Overview"
                      component={c_ts_overview}
                    />
                    <Route
                      path="/reporting/class/standard_performance/overview"
                      name="class_TestScore_Overview"
                      component={c_sp_overview}
                    />
                    <Route
                      path="/reporting/class/singleTestAnalysis"
                      name="class_singleTestAnalysis"
                      component={c_st_analysis}
                    />
                    <Route
                      path="/reporting/class/teststatus"
                      name="class_Test_Status"
                      component={c_test_status}
                    />
                    <Route
                      path="/reporting/class/testScore/comparison"
                      name="class_TestScore_Overview"
                      component={c_ts_comparison}
                    />
                    <Route
                      path="/reporting/class/standard_performance/comparison"
                      name="class_TestScore_Overview"
                      component={c_sp_comparison}
                    />

                    {/* <Route path="/reporting/class/testscore/grouping" name="class_TestScore_Overview" component={c_ts_grouping} /> */}
                    <Route
                      path="/reporting/class/standard_performance/grouping"
                      name="class_TestScore_Overview"
                      component={c_sp_grouping}
                    />
                    {/* class orr routing */}
                    <Route
                      path="/reporting/class/orr/reading_level_progress"
                      name="reading_level_progress"
                      component={RlpChart}
                    />
                    <Route
                      path="/reporting/class/orr/reading_history"
                      name="reading_History"
                      component={c_Reading_History}
                    />
                    <Route
                      path="/reporting/class/orr/fluency_analysis"
                      name="fluency_Analysis"
                      component={CFAMainChart}
                    />
                    <Route
                      path="/reporting/class/orr/error_analysis"
                      name="error_Analysis"
                      component={C_ErrorChart}
                    />
                    <Route
                      path="/reporting/class/orr/reading_behaviors"
                      name="reading_Behaviors"
                      component={C_Reading_Behavior}
                    />
                    {/**
                     * All Student related Routes
                     */}
                    <Route
                      path="/reporting/student/testscore/overview"
                      name="Student_TestScore_Overview"
                      component={s_ts_overview}
                    />
                    <Route
                      path="/reporting/student/singleTestAnalysis"
                      name="student_singleTestAnalysis"
                      component={s_st_analysis}
                    />
                    <Route
                      path="/reporting/student/testscore/comparison"
                      name="Student_TestScore_Comparison"
                      component={s_ts_comparison}
                    />

                    <Route
                      path="/reporting/student/teststatus"
                      name="Student_Test_Status"
                      component={s_test_status}
                    />

                    <Route
                      path="/reporting/student/standard_performance/comparison"
                      name="Student_TestScore_Overview"
                      component={s_sp_comparison}
                    />
                    <Route
                      path="/reporting/student/standard_performance/overview"
                      name="Student_TestScore_Overview"
                      component={s_sp_overview}
                    />
                    {/* student orr routing */}
                    <Route
                      path="/reporting/student/orr/reading_level_progress"
                      name="reading_level_progress"
                      // component={DistrictRLPChart}
                      component={S_ReadingLevelProgress}
                    />
                    <Route
                      path="/reporting/student/orr/reading_history"
                      name="reading_History"
                      // component={District_Reading_History}
                      component={ReadingHistory}
                    />
                    <Route
                      path="/reporting/student/orr/fluency_analysis"
                      name="fluency_Analysis"
                      component={StudentFluencyChart}
                    />
                    <Route
                      path="/reporting/student/orr/error_analysis"
                      name="error_Analysis"
                      component={ErrorAnalysis}
                    />
                    <Route
                      path="/reporting/student/orr/reading_behaviors"
                      name="reading_Behaviors"
                      component={StudentReadingBehaviorChart}
                    />
                    {/**
                     * All School related Routes
                     */}
                    <Route
                      path="/reporting/school/testscore/overview"
                      name="School_TestScore_Overview"
                      component={sc_ts_overview}
                    />
                    <Route
                      path="/reporting/school/testscore/comparison"
                      name="School_TestScore_Overview"
                      component={sc_ts_comparison}
                    />
                    <Route
                      path="/reporting/school/standard_performance/overview"
                      name="School_TestScore_Overview"
                      component={sc_sp_overview}
                    />
                    <Route
                      path="/reporting/school/standard_performance/comparison"
                      name="School_TestScore_Overview"
                      component={sc_sp_comparison}
                    />
                    <Route
                      path="/reporting/school/singleTestAnalysis"
                      name="school_singleTestAnalysis"
                      component={sc_st_analysis}
                    />
                    <Route
                      path="/reporting/school/teststatus"
                      name="school_Test_Status"
                      component={sc_test_status}
                    />
                    {/* school orr routing */}
                    <Route
                      path="/reporting/ORR"
                      name="ORR_Reporting"
                      component={ORR_Home}
                    />

                    <Route
                      path="/reporting/school/orr/reading_level_progress"
                      name="reading_level_progress"
                      component={SchoolRLPChart}
                    />
                    <Route
                      path="/reporting/school/orr/reading_history"
                      name="reading_History"
                      component={School_Reading_History}
                    />
                    <Route
                      path="/reporting/school/orr/fluency_analysis"
                      name="fluency_Analysis"
                      component={SchoolFluencyChart}
                    />
                    <Route
                      path="/reporting/school/orr/error_analysis"
                      name="error_Analysis"
                      component={Sc_ErrorChart}
                    />
                    <Route
                      path="/reporting/school/orr/reading_behaviors"
                      name="reading_Behaviors"
                      component={SchoolRBContainer}
                    />

                    {/**
                     * All DIstrict Relates Routes
                     */}
                    <Route
                      path="/reporting/district/testscore/overview"
                      name="School_TestScore_Overview"
                      component={d_ts_overview}
                    />
                    <Route
                      path="/reporting/district/singleTestAnalysis"
                      name="district_singleTestAnalysis"
                      component={d_st_analysis}
                    />
                    <Route
                      path="/reporting/district/teststatus"
                      name="district_teststatus"
                      component={d_test_status}
                    />
                    <Route
                      path="/reporting/district/testscore/comparison"
                      name="School_TestScore_Overview"
                      component={d_ts_comparison}
                    />
                    <Route
                      path="/reporting/district/standard_performance/overview"
                      name="School_TestScore_Overview"
                      component={d_sp_overview}
                    />
                    <Route
                      path="/reporting/district/standard_performance/comparison"
                      name="School_TestScore_Overview"
                      component={d_sp_comparison}
                    />
                    {/* District orr routing */}
                    <Route
                      path="/reporting/district/orr/reading_level_progress"
                      name="reading_level_progress"
                      component={DistrictRLPChart}
                    />
                    <Route
                      path="/reporting/district/orr/reading_history"
                      name="reading_History"
                      component={District_Reading_History}
                    />
                    <Route
                      path="/reporting/district/orr/fluency_analysis"
                      name="fluency_Analysis"
                      component={DistrictFluencyChart}
                    />
                    <Route
                      path="/reporting/district/orr/error_analysis"
                      name="error_Analysis"
                      component={ErrorAnalysis}
                    />
                    <Route
                      path="/reporting/district/orr/reading_behaviors"
                      name="reading_Behaviors"
                      component={Filter}
                    />
                  </Switch>
                </div>
              )}
            </div>
          </main>
        )}
        {Nav.Assessement && this.state.theposition > 80 ? (
          <div
            className={
              this.props.FooterOpen
                ? "scrollTopBlock footerOpend"
                : "scrollTopBlock"
            }
            onClick={this.ScrollClickHandler}
          >
            <img src={scrollTop} />
          </div>
        ) : null}
        {NoData_Or_Technical_Error || screen_loading ? null : <Footer />}
      </div>
    );
  }
}

const mapStateToProps = ({
  Universal,
  Reports,
  Authentication,
  StudentReports,
  ClassGroupingReducer,
  schoolReducer,
  DistrictReducer,
  DateTabReducer,
  SingleTestAnalysis,
  TestStatusReducer,
  Summary,
  SummaryReports,
  LastActiveUniversalProps,
}) => {
  const { NavigationByHeaderSelection, FooterOpen, isPastDistrictTerm } =
    Universal;
  const { LoginDetails, Auth_Apis, NoaccessToReports } = Authentication;
  const { G_ApiCalls } = ClassGroupingReducer;

  return {
    LoginDetails,
    Auth_Apis,
    NavigationByHeaderSelection,
    NoaccessToReports,

    Universal,
    Reports,
    Authentication,
    StudentReports,
    ClassGroupingReducer,
    DistrictReducer,
    schoolReducer,
    DateTabReducer,
    SingleTestAnalysis,
    FooterOpen,
    TestStatusReducer,
    Summary,
    SummaryReports,
    isPastDistrictTerm,
    LastActiveUniversalProps,
  };
};

export default withRouter(
  connect(mapStateToProps, {
    CloseUniversalFilter,
    Close_EnableMoreOptionsCH,
    SaveMonitorScreenWidth,
    Get_Roster_GradesAndschools,
    Get_Roster_Classes,
    Get_Roster_Teachers_Students,
    GetInitialApplicationData,
    GetSummaryDefault,
    Get_Roster_Tab_Data,
    GetUserAccessableReports,
    GetLineChartDetailsofSelected_Standards,
    ClickStudentDataInfoIcon,
    ClickPdTestsInfoIcon,
    ClickPdDatesInfoIcon,
    Reset_state_in_all_reducers,
    Separate_Roster_Tab_Details,
    Get_DateTabResults,
    StoreDataFromAssessment,
    SaveContextSelection,
    Get_ClassObject_WhichHas_Reports
  })(Full)
);

function CheckNoDataForSelectionOptiosProp(completeprops) {
  let InStudent = completeprops.StudentReports.S_StandardPerformance_Overview;
  let InClass_Strands = completeprops.Reports.StandardPerformance_Overview;

  let InSC_Strands =
    completeprops.schoolReducer.Sc_StandardPerformance_Overview;
  let IN_DIST_STRANDS =
    completeprops.DistrictReducer.D_StandardPerformance_Overview;

  let InClassGraphData = completeprops.Reports.Test_Scores_OverTime;

  let U_NoData_Props = completeprops.Universal.NoData_For_Selection_Universal;

  let Nav = completeprops.Universal.NavigationByHeaderSelection;
  let U_Apicalls = completeprops.Universal.ApiCalls;

  if (Nav.ORR) {
    return false;
  }

  let Summary_Reducer = completeprops.Summary;
  let NoSummaryData = Check_Summary_Data(Summary_Reducer, Nav);

  /**
   * if no data in summary tab. will show coming soon
   */

  if (NoSummaryData && Nav.summary) {
    return NoSummaryData;
  }

  /**
   * For Single Test COming Soon Page
   */

  if (Nav.st_analysis) {
    let St_Props = completeprops.SingleTestAnalysis;
    let DataIsNotThere = Nav.student
      ? St_Props.student_TestAnalysis.noDataFound
      : Nav.class
      ? St_Props.class_TestAnalysis.noDataFound
      : Nav.school
      ? St_Props.school_TestAnalysis.noDataFound
      : St_Props.district_TestAnalysis.noDataFound;

    if (DataIsNotThere) {
      return DataIsNotThere;
    }
  }

  if (Nav.test_status) {
    let NoTests_TestStatus = Check_NoData_In_TestStatus_Tests(
      completeprops.TestStatusReducer,
      Nav
    );

    if (NoTests_TestStatus) {
      return NoTests_TestStatus;
    }
  }

  return (
    ((InClass_Strands && InClass_Strands.StandardPerformanceFilter && InClass_Strands.StandardPerformanceFilter.NodataInStrands &&
      Nav.S_performance &&
      Nav.class) ||
      (InSC_Strands && InSC_Strands.StandardPerformanceFilter && InSC_Strands.StandardPerformanceFilter.NodataInStrands &&
        Nav.S_performance &&
        Nav.school) ||
      (IN_DIST_STRANDS && IN_DIST_STRANDS.StandardPerformanceFilter && IN_DIST_STRANDS.StandardPerformanceFilter.NodataInStrands &&
        Nav.S_performance &&
        Nav.district) ||
      (InClassGraphData.NoGraphDetails && Nav.T_scores && Nav.class) ||
      U_NoData_Props.NodataInUniversalTab ||
      U_NoData_Props.NoReportsForTheUser ||
      (InStudent.StandardPerformanceFilter.NodataInStrands &&
        Nav.S_performance &&
        Nav.student &&
        !U_Apicalls.Get_Student_SP_Grade)) &&
    U_Apicalls.loadingFor !== "tests" &&
    U_Apicalls.loadingFor !== "datetab"
  );
}

export function Check_NoData_In_TestStatus_Tests(TestStatusReducer, Nav) {
  switch (true) {
    case Nav.student:
      return TestStatusReducer.Student.Apicalls.No_Tests_In_TestStatus;
    case Nav.class:
      return TestStatusReducer.Class.Apicalls.No_Tests_In_TestStatus;

    case Nav.school:
      return TestStatusReducer.School.Apicalls.No_Tests_In_TestStatus;

    case Nav.district:
      return TestStatusReducer.District.Apicalls.No_Tests_In_TestStatus;

    default:
      return false;
  }
}
/**
 * @returns {Boolean}  -- if data is not there returns true.
 */
export function Check_Summary_Reports_Data(stateData, Nav) {
  if (Nav.Summary_Reports) {
    switch (true) {
      case Nav.district:
        return (
          stateData.district &&
          stateData.district.assessments.apiCalls.showNoDataPopUp
        );

      case Nav.school:
        return (
          stateData.school &&
          stateData.school.assessments.apiCalls.showNoDataPopUp
        );

      case Nav.class:
        return (
          stateData.class &&
          stateData.class.assessments.apiCalls.showNoDataPopUp
        );

      case Nav.student:
        return (
          stateData.student &&
          stateData.student.assessments.apiCalls.showNoDataPopUp
        );

      default:
        return false;
    }
  } else return false;
}

export function Check_Summary_Data(Summary_Reducer, Nav) {
  if (Nav.summary) {
    switch (true) {
      case Nav.district:
        return Summary_Reducer.District.NodataAvailable;

      case Nav.school:
        return Summary_Reducer.School.NodataAvailable;

      case Nav.class:
        return Summary_Reducer.Class.NodataAvailable;

      case Nav.student:
        return Summary_Reducer.Student.NodataAvailable;

      default:
        return false;
    }
  } else return false;
}
