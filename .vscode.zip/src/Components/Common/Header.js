// import React, { Component } from 'react';

// import '../../../public/css/style.css';

// import Logo from '../../../public/images/default_profile_image.png';
// import { connect } from 'react-redux';

// import { MainMenuOpenOrClose } from '../../Redux_Actions/UniversalSelectorActions';

// class Header extends Component {

//   render() {
//     return (
//       <header className={this.props.OpenMainmenu ? "sticky-header active-main-menu" : "sticky-header"}>
//         <div className="header">
//           <div className="header-stick-container"
//             onMouseLeave={() => this.props.OpenMainmenu ? this.props.MainMenuOpenOrClose() : null}
//           >
//             <div className="header-container">
//               <a href="#">
//                 <div className="bu-logo" alt="Benchmark Universe Logo">
//                 </div>
//               </a>
//               <div className="far-right">
//                 <div className="text">
//                   <a href="#userProfile">
//                     <h2>InteraEdge  Demo Teacher </h2>
//                   </a>
//                   <div>
//                     <p className="">Sign Out</p>
//                   </div>
//                 </div>
//                 <a href="#userProfile">
//                   <img alt="User Icon" src={Logo} />
//                 </a>
//               </div>
//             </div>
//             <div
//               className="header-bottom">
//               <div className="left">
//                 <div className="menu-icon"
//                   onClick={() => {

//                     this.props.OpenMainmenu ? null : this.props.MainMenuOpenOrClose()
//                   }}
//                   style={{ cursor: 'pointer' }}>
//                 </div>
//                 <div>
//                   <p style={{ cursor: 'pointer' }}>Menu</p>
//                   <div className="divider"></div>
//                   <p>Reports</p>
//                 </div>
//               </div>
//               <div className="right">
//                 <a target="_blank"><i className="material-icons">help</i></a>
//               </div>
//             </div>
//           </div>
//         </div>
//       </header>
//     );
//   }
// }

// const mapStateToProps = ({ Universal }) => {

//   const { OpenMainmenu } = Universal;
//   return { OpenMainmenu };
// }

// export default connect(mapStateToProps, {
//   MainMenuOpenOrClose

// })(Header);
