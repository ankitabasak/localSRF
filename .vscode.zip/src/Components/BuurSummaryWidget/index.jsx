import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
  SetUsageReportsDistrictName
} from '../../Redux_Actions/UniversalSelectorActions';

const BUURSummaryWidget = React.lazy(() => import('bu-usage-reporting-ui/SummaryWidgetEntry'));

class BuurSummaryWidget extends Component {
  static composeUserProfileObject(login) {

    const jwt =
      (login.JWTToken !== null && login.JWTToken !== undefined) ? login.JWTToken : null;
    console.log(" window.App.model : & ^ & ^ &   ", window.App.model);
    const id = window.App.model.id;
    const role = (login.UserRole !== undefined) ? login.UserRole : null;
    const userName = window.App.model.attributes.username;
    const firstName = window.App.model.attributes.first_name;
    const lastName = window.App.model.attributes.last_name;
    return {
      jwt,
      id,
      role,
      userName,
      firstName,
      lastName,
    };
  }

  constructor(props) {
    super(props);
    // this.handleBuurCallback = this.handleBuurCallback.bind(this);
  }

  // handleBuurCallback(buurEvent) {
  //   console.log("buurEvent in Summary Widget && : : ", buurEvent);
  // }

  render() {

    console.log(" BUURSummaryWidget render : & * & *  :  ");
    // For passProps: get the list of props required for the widget and provide them
    const Nav = this.props.NavigationByHeaderSelection;
    const { Date_Tab, Summary_Roster_Data } = this.props.ContextHeader;
    const { SelectedDistrict, SchoolIds, ClassIds } = Summary_Roster_Data;
    let districtId = SelectedDistrict && SelectedDistrict.id
    const userProfile =
      BuurSummaryWidget.composeUserProfileObject(this.props.LoginDetails);
    let clsIds=[];
    let ScIds=[]
    let districIds =  districtId ? [districtId.toString()] : []

    ClassIds&& ClassIds.map(item=>{
      clsIds.push(item.toString());
    })

    SchoolIds&& SchoolIds.map(item=>{
      ScIds.push(item.toString());
    })
    const passProps = {
      // reportsCallback: this.handleBuurCallback,
      startDate: Date_Tab.Report_termStartDate,
      endDate: Date_Tab.Report_termEndDate,
      districtIds: districIds,
      schoolIds: ScIds,
      classIds: clsIds,
      cnType: Nav.district ? "DISTRICT" : Nav.school ? "SCHOOL" : "CLASS",
      userProfile,
    };

    console.log(" BUURSummaryWidget render2 : & * & *  :  ", passProps);
    return (
      <div className={"buur-summary-widget-container"}>
        <React.Suspense fallback={<p>Loading...</p>} >
          <BUURSummaryWidget {...passProps} />
        </React.Suspense>
      </div>
    );
  }
}

const mapStateToProps = ({ Universal, Authentication }) => {
  const { LoginDetails } = Authentication;
  const { ContextHeader, NavigationByHeaderSelection, usageReports } = Universal;
  return {
    LoginDetails,
    ContextHeader,
    NavigationByHeaderSelection,
    Universal,
    usageReports
  };
};

export default connect(mapStateToProps, {
  SetUsageReportsDistrictName
})(BuurSummaryWidget);
