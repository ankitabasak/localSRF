import React, { Component } from "react";
import { connect } from "react-redux";

import SummaryPage from "../../Utils/Summary/summaryReports";
import {
  GetIds_of_Each_Object_In_The_Array,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compare,
} from "../ReusableComponents/AllReusableFunctions";

import { GetSummarayData } from "../../Redux_Actions/SummaryActions";
import { get_District_GradeData } from "../../services/district.service";
import { getGradeListOfDistrict } from "../../Redux_Actions/District_Report_Actions";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";

class D_Sp_Summary extends Component {
  componentDidMount() {
    get_District_GradeData(this.props);
    this.getData();
    this.props.trackingUsage("assessmentreports_standardperformanceaverage:district");
  }
  componentDidUpdate() {
    get_District_GradeData(this.props);
    this.getData();
  }

  getData() {
    let shouldmakeApicall = this.props.ApiCalls.Get_District_sp_grades;
    let TestsApi =
      this.props.Universal.ApiCalls.loadingFor == "tests" ||
      this.props.Universal.ApiCalls.getTests;
    let Grades_Loader_In_Overview = this.props.ApiCalls.loadingOn_D_Sp_Grades;
    let GradeAPi = shouldmakeApicall || Grades_Loader_In_Overview;
    let Nav = this.props.NavigationByHeaderSelection;
    let OppsError = this.props.LoginDetails.DisplayTechnicalError;

    if (
      this.props.Summary.District.Apicalls.GetData &&
      !TestsApi &&
      !GradeAPi &&
      Nav.district &&
      Nav.summary &&
      !OppsError
    ) {
      let Token = this.props.Authentication.LoginDetails.JWTToken;
      let Context_Header = this.props.Universal.ContextHeader;
      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTestList = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );
      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;

      // let Compare_Std_Ids = SchoolStds == undefined || SchoolStds == null ? [] : Get_Ids_Of_Student_List(SchoolStds.filter(item => item.check));

      // if (Compare_Std_Ids.length == 0) {

      //   let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
      //   Compare_Std_Ids = GetStudentIdsFor_compare(Grades)

      // }

      let Grade =
        this.props.DistrictReducer.D_StandardPerformance_Overview
          .StandardPerformanceFilter.TestGrade.selectedTestgrade.grade;

      Grade = Grade == null || Grade == undefined ? "" : Grade;
      // let Grade = Context_Header.Roster_Tab.selectedRosterGrade;
      let Sc_Ids =
        Context_Header.Roster_Tab.SchoolIds.length ==
        Context_Header.Roster_Tab.schoolsList.length
          ? []
          : Context_Header.Roster_Tab.SchoolIds;
      let currentTermId = this.props.currentTermID;

      let Req_Payload = {
        // "classIds": Context_Header.Roster_Tab.ClassIds,
        schoolIds: Sc_Ids,
        grade: Grade,
        startDate: Context_Header.Date_Tab.Report_termStartDate,
        endDate: Context_Header.Date_Tab.Report_termEndDate,
        districtId: Context_Header.DistrictId,
        componentCodeList: SelectedTestList,
        rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
        termId: Context_Header.Date_Tab.selectedTermId,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
        // "studentIds": StdIds,
        // "compareStudentIds": Compare_Std_Ids
      };

      this.props.GetSummarayData(
        Token,
        Req_Payload,
        this.props.Universal.NavigationByHeaderSelection
      );
    }
  }

  render() {
    let TestDataAssessedForGrade =
      this.props.DistrictReducer.D_StandardPerformance_Overview
        .StandardPerformanceFilter.TestGrade.selectedTestgrade.grade;
    return (
      <SummaryPage
        Navigation={this.props.Universal.NavigationByHeaderSelection}
        SummaryDataProp={this.props.Summary.District}
        TestGrade={TestDataAssessedForGrade}
      />
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  Summary,
  DistrictReducer,
  LastActiveUniversalProps,DateTabReducer
}) => {
  const {
    ApiCalls,
    ContextHeader,
    UniversalSelecter,
    NavigationByHeaderSelection,
    currentTermID,
  } = Universal;
  const { LoginDetails } = Authentication;
  const { Context_DateTab } = DateTabReducer;
  return {
    Universal,
    Authentication,
    Summary,
    DistrictReducer,
    LastActiveUniversalProps,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    LoginDetails,
    NavigationByHeaderSelection,
    currentTermID,Context_DateTab
  };
};

const mapStateToDispatch = {
  GetSummarayData,
  getGradeListOfDistrict,
  trackingUsage
};

export default connect(mapStateToProps, mapStateToDispatch)(D_Sp_Summary);
