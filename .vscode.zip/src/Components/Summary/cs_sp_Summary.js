import React, { Component } from "react";
import { connect } from "react-redux";

import SummaryPage from "../../Utils/Summary/summaryReports";
import {
  GetIds_of_Each_Object_In_The_Array,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compare,
  GetStudentIdsFor_compareOfGrade,
  AllClassesList,
} from "../ReusableComponents/AllReusableFunctions";

import { GetSummarayData } from "../../Redux_Actions/SummaryActions";
import { getGradeListOfClass } from "../../Redux_Actions/ReportsActions";
import { Sp_OverView_Grades } from "../../services/class.service";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";
import { EnddateValues, StartdateValues } from "../../Utils/reUsableSnipets";

class CS_Sp_Summary extends Component {
  componentDidMount() {
    Sp_OverView_Grades(this.props);
    this.getData();
    this.props.trackingUsage("assessmentreports_standardperformanceaverage:class");
  }
  componentDidUpdate() {
    Sp_OverView_Grades(this.props);
    this.getData();
  }

  getData() {
    let DontCall_standardGradeApi =
      this.props.StandardPerformance_Overview.StandardPerformanceFilter
        .DontCall_standardGradeApi;
    let shouldmakeApicall =
      this.props.ApiCalls.Get_Class_SP_Grade &&
      !this.props.ApiCalls.Get_Class_Strands &&
      !DontCall_standardGradeApi;

    let Grades_Loader_In_Overview = this.props.ApiCalls.loadingOn_C_Sp_Grades;
    let GradeAPi = shouldmakeApicall || Grades_Loader_In_Overview;
    let TestsApi =
      this.props.ApiCalls.loadingFor == "tests" || this.props.ApiCalls.getTests;
    let SchoolDataApi =
      this.props.ApiCalls.loadingFor == "school" ||
      this.props.ApiCalls.Get_Selected_School_Info;
    let Nav = this.props.NavigationByHeaderSelection;

    let OppsError = this.props.LoginDetails.DisplayTechnicalError;

    if (
      this.props.Summary.Class.Apicalls.GetData &&
      !TestsApi &&
      !GradeAPi &&
      !SchoolDataApi &&
      Nav.class &&
      Nav.summary &&
      !OppsError
    ) {
      // api to get summary data
      let Token = this.props.LoginDetails.JWTToken;
      let Context_Header = this.props.ContextHeader;
      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTestList = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );

      let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
      let selectedGradeForCompare =
        Context_Header.Roster_Tab.selectedRosterGrade;
      let Compare_Std_Ids = GetStudentIdsFor_compareOfGrade(
        selectedGradeForCompare,
        Grades
      );

      const AllClassesList_ = AllClassesList(
        Context_Header.Roster_Tab.ClassList
      );
      // let Grade = this.props.Summary.Class.ReportFor_Grade;

      // if (Grade == "" || Grade == undefined || Grade == null) {
      let Grade =
        this.props.StandardPerformance_Overview.StandardPerformanceFilter
          .TestGrade.selectedTestgrade.grade;
      // }

      Compare_Std_Ids = [];
      let currentTermId = this.props.currentTermID;

    let classId = Context_Header.Roster_Tab.SelectedClass.id;
		let startDate = Context_Header.Date_Tab.Report_termStartDate;
		let endDate = Context_Header.Date_Tab.Report_termEndDate;
		let districtId = Context_Header.DistrictId;
		let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
		const { UniversalSelecter,Context_DateTab } = this.props;
	
		if (startDate == undefined || startDate == "") {
			startDate = StartdateValues(Context_DateTab);
		}
		if (endDate == undefined || endDate == "") {
			endDate = EnddateValues(Context_DateTab);
		}
		if (districtId == undefined) {
			districtId = Context_Header.Default_districtID;
		}
		if (schoolId == undefined) {
			schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
		}
	  if (classId == undefined) {
			classId = UniversalSelecter.Roster_Data.SelectedClass == "All"?UniversalSelecter.Roster_Data.ClassList[0] && UniversalSelecter.Roster_Data.ClassList[0].id:UniversalSelecter.Roster_Data.SelectedClass.id;
		}



      let Req_Payload = {
        classId: classId,
        schoolId: schoolId,
        classIds: AllClassesList_,
        grade: Grade,
        rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
        studentIds: Context_Header.Roster_Tab.StudentIds,
        // "studentId": Context_Header.Roster_Tab.SelectedStudent.id,
        startDate: startDate,
        endDate: endDate,
        districtId: districtId,
        componentCodeList: SelectedTestList,
        compareStudentIds: Compare_Std_Ids,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
      };

      Req_Payload.Grade !== undefined || Req_Payload.Grade !== null
        ? this.props.GetSummarayData(
            Token,
            Req_Payload,
            this.props.NavigationByHeaderSelection
          )
        : null;
    }
  }

  render() {
    let AssessedForGrade =
      this.props.StandardPerformance_Overview.StandardPerformanceFilter
        .TestGrade.selectedTestgrade;
    AssessedForGrade =
      AssessedForGrade !== undefined && AssessedForGrade !== null
        ? AssessedForGrade.grade
        : "";
    return (
      <SummaryPage
        Navigation={this.props.NavigationByHeaderSelection}
        SummaryDataProp={this.props.Summary.Class}
        TestGrade={AssessedForGrade}
      />
    );
  }
}

const mapStateToProps = ({
  Universal,
  Authentication,
  Summary,
  Reports,
  LastActiveUniversalProps,DateTabReducer
}) => {
  const { Class, StandardPerformance_Overview, ToolTipData, ApiCalls_Reports } =
    Reports;
  const { LoginDetails } = Authentication;
  const { Context_DateTab } = DateTabReducer;
  const {
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    currentTermID,
  } = Universal;
  return {
    Class,
    LoginDetails,
    ContextHeader,
    ApiCalls,
    ToolTipData,
    ApiCalls_Reports,
    StandardPerformance_Overview,
    UniversalSelecter,
    NavigationByHeaderSelection,
    Summary,
    LastActiveUniversalProps,
    currentTermID,Context_DateTab
  };
};

const mapStateToDispatch = {
  GetSummarayData,
  getGradeListOfClass,
  trackingUsage
};

export default connect(mapStateToProps, mapStateToDispatch)(CS_Sp_Summary);
