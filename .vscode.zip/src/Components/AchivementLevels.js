
import React, { Component } from 'react';
export default class AchivementLevels extends Component {
    constructor(props) {
        super(props)
    }
    render(){
        return (<ul> <li>
      <div className="footer-single-indicator">
        <div className="footer-key-bar red"></div>
      </div>
      <div className="footer-single-indicator-title indicator-title-red">Below {this.props.AchivementLevels && this.props.AchivementLevels[0]["label"]}%</div>
    </li>
    <li>
      <div className="footer-single-indicator">
        <div className="footer-key-bar orange"></div>
      </div>
      <div className="footer-single-indicator-title indicator-title-orange">{this.props.AchivementLevels && this.props.AchivementLevels[1]["label"]}%</div>
    </li>
    <li>
      <div className="footer-single-indicator">
        <div className="footer-key-bar yellow"></div>
      </div>
      <div className="footer-single-indicator-title indicator-title-yellow">{this.props.AchivementLevels && this.props.AchivementLevels[2]["label"]}%</div>
    </li>
    <li>
      <div className="footer-single-indicator">
        <div className="footer-key-bar green"></div>
      </div>
      <div className="footer-single-indicator-title indicator-title-green">{this.props.AchivementLevels && this.props.AchivementLevels[3].min?"\u2265 " :null}{this.props.AchivementLevels && this.props.AchivementLevels[3].min}%</div>
    </li>
    <li>
      <div className="footer-single-indicator">
        <div className="footer-key-bar grey"></div>
      </div>

      <div className="footer-single-indicator-title">
      No Data Available </div>

    </li>
  </ul>)
    }
}