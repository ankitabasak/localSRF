import React, { Component } from 'react';
import './drop-down.css';
import dropdown from '../../../public/images/ic_dropdown_arrow_down.svg';
import dropup from '../../../public/images/ic_dropdown_arrow_up.svg'


class Compare_Chart_Data extends Component {
    constructor(props) {
        super(props);
    }

    toggleDropDown() {
        this.props.toggleDropDown({ toggleData: !this.props.toggleData });
        this.props.toggleData && this.props.updateChartDetails(this.props.monthRangeObj)
    }

    updateMonthDetails(month, index) {
        var monthData = { monthName: month.monthName, index: index, checked: !month.checked }
        this.props.updateDetails(monthData);
    }

    selectedMonth(monthRange) {
        let monthCount = 0;
        let displayMsg = '';
        if (monthRange) {
            monthRange.forEach((item, index) => {
                if (item.checked) {
                    monthCount++;
                    if (monthCount === 1) {
                        displayMsg = item.monthName
                    }
                }
            })

            if (monthCount === monthRange.length || monthCount === 0) {
                displayMsg = "All"
            }
            if (monthCount > 1 && monthCount < monthRange.length) {
                displayMsg = "Custom" + " (" + (monthCount) + ")"
            }
            return displayMsg.length > 16 ? displayMsg.substr(0, 16) + '...' : displayMsg;
        }
    }

    updateAllMonths(selAll) {
        this.props.updateAllMonth({ selAll: !selAll })
    }

    render() {
        return (
            <React.Fragment>
                {!this.props.summaryFlag &&
                    <div className="drop-wrapper print-dw-05-20">
                        <span>Compare: </span>
                        <button className="cursor-pointer bor-radius-4" onClick={() => this.toggleDropDown(this.props.monthRangeObj)}>
                            {this.selectedMonth(this.props.monthRangeObj)}
                            <React.Fragment>{this.props.toggleData ? <span><img className="dropdown-icon" src={dropup} /></span> : <span><img className="dropdown-icon" src={dropdown} /></span>}</React.Fragment>
                        </button>
                        {this.props.toggleData &&
                            <div className="drop-inner-wrapper">
                                <ul>
                                    <li className="cursor-pointer"
                                        onClick={() => this.updateAllMonths(this.props.selAll)}>
                                        <input
                                            checked={this.props.selAll}
                                            value={this.props.selAll}
                                            type="checkbox" />
                                        <span className="checkmark"></span>
                                    All

                                </li>
                                </ul>

                                <ul>
                                    {
                                        this.props.monthRangeObj.map((month, idx) => {
                                            return <li className="cursor-pointer"
                                                onClick={() => this.updateMonthDetails(month, idx)}>
                                                <input
                                                    checked={month.checked}
                                                    value={month.checked}
                                                    type="checkbox" />
                                                <span className="checkmark"></span>
                                                {month.monthName}
                                            </li>
                                        })
                                    }
                                </ul>
                            </div>
                        }
                    </div>
                }</React.Fragment>
        )
    }
}

export default Compare_Chart_Data;