import React, { Component } from 'react';
import { connect } from 'react-redux';
import {
    Comparison_Popup
} from '../../../Redux_Actions/ComparisonActions';
import LoadingScreen from '../../../Utils/LoadingScreen/LoadingScreen';

import Std_Perf_ComparisonPopup from "../../../Utils/Comparison/Std_Perf_ComparisonPopup";
import Std_Perf_ComparisonPage from "../../../Utils/Comparison/Std_Perf_ComparisonPage";
import { Get_Compare_Strands, Get_CompareGrades, getOriginalCountInComparison } from '../../../services/compare.service';
import { getOriginalTestAssessmentMaxCountInComparison } from '../../../Redux_Actions/ComparisonActions';
import Compare_Comp_Apis from '../../../Utils/Comparison/Compare_Comp_Apis';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';
class c_sp_comparison extends Component {

    constructor(props) {
        super(props);
    }

    // componentDidMount() {
    //     Get_Compare_Strands(this.props);
    //     Get_CompareGrades(this.props);

    //     getOriginalCountInComparison(this.props);

    //     Sp_OverView_Grades(this.props);
    //     Sp_Overview_StrandsData(this.props);

    //     Sp_OverView_Grades_class(this.props);
    //     Get_Class_Sp_Overview(this.props);
    // }

    // componentDidUpdate() {

    //     Get_CompareGrades(this.props);
    //     Get_Class_Sp_Overview(this.props);
    //     Sp_Overview_StrandsData(this.props);

    //     Sp_OverView_Grades_class(this.props);
    //     Sp_OverView_Grades(this.props);

    //     Get_Compare_AssessedQuestions(this.props);
    //     Get_Compare_Strands(this.props);
    //     getOriginalCountInComparison(this.props);
    // }

componentDidMount(){
    this.props.trackingUsage("assessmentreports_standardperformancecomparison:class");
}

    render() {

        const classComparison = this.props.classComparison.Std_Comparison

        const popupFilter = classComparison.PopupFilter;
        let Nav = this.props.NavigationByHeaderSelection;
        let fromNavContext = Nav.class ? "class" : "student";
        return (
            <div>
                <Compare_Comp_Apis
                    comparisonData={classComparison}
                    fromContext={fromNavContext}
                    fromtab="std_performance"
                    popupData={popupFilter}
                />

                {popupFilter.openPopup && !this.props.CompareDeepLink_Enabled
                    // && (popupFilter.Strands_And_Standards.Original_List_temp.length != 0)
                    ? <Std_Perf_ComparisonPopup
                        comparisonData={classComparison}
                        fromContext={fromNavContext}
                        fromtab="std_performance"
                        popupData={popupFilter} /> : null}
                {(classComparison.ComparisonData.Operational_Data != null && !this.props.CompareDeepLink_Enabled) ||
                    popupFilter.C_SP_ApiCalls.loadingComparison ? <Std_Perf_ComparisonPage fromContext={fromNavContext} fromtab="std_performance" comparisonData={classComparison} /> :
                    null}
            </div>
        )
    }
}

const MapStateToProps = ({ Universal, Authentication, ComparisonReducer, Reports }) => {

    const { ContextHeader, NavigationByHeaderSelection,currentTermID } = Universal

    const { classComparison, CompareDeepLink_Enabled } = ComparisonReducer

    const { StandardPerformance_Overview } = Reports

    return {
        Universal, Authentication, ContextHeader, classComparison, NavigationByHeaderSelection, StandardPerformance_Overview
        , CompareDeepLink_Enabled,currentTermID
    }
}

const MapActionToProps = {
    Comparison_Popup,
    getOriginalTestAssessmentMaxCountInComparison,trackingUsage

}

export default connect(MapStateToProps, MapActionToProps)(c_sp_comparison);

// Custom functions to perform some actions

export function SelectedTestList(testsList) {

    let ComponentsList = [];
    testsList == undefined ? null : testsList.map((test, i) => {
        // if (test.productId == SelectedProductID) {
        ComponentsList.push(test.componentCode);
        //}
    })
    return ComponentsList;
}