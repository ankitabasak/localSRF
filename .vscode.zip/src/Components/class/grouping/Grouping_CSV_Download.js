import React, { Component } from 'react';
import { Reset_class_grouping_CSV_download } from '../../../Redux_Actions/ReportsActions';
import { CSVLink } from "react-csv";
import { connect } from "react-redux";

class Grouping_CSV_Download extends Component {
    constructor(props) {
        super(props);
        this.Reset_class_grouping_CSV_download = this.Reset_class_grouping_CSV_download.bind(this)
        // this.get_headers_of_CSV = this.get_headers_of_CSV.bind(this)
    }

    Reset_class_grouping_CSV_download() {

        if (this.props.TriggerGroupingCSVDownload) {
            setTimeout(() => {
                this.props.Reset_class_grouping_CSV_download()
            }, 1000)
        }
    }

    getUnique(csvData, comp) {

        const unique = csvData
            .map(e => e[comp])
            .map((e, i, final) => final.indexOf(e) === i && i)
            .filter(e => csvData[e]).map(e => csvData[e]);
        return unique;
    }


    get_headers_of_CSV(csvData) {

        let headersData = []
        let csvHeaders = [
            { label: "District Name", key: "districtName" },
            { label: "School Name", key: "schoolName" },
            { label: "Grade", key: "grade" },
            { label: "Teacher Name", key: "teacherNames" },
            { label: "Class SIS ID", key: "classSisId" },
            { label: "Class Name", key: "className" },
            { label: "Student SIS ID", key: "sisId" },
            { label: "Student Name", key: "studentName" },
            { label: "Group by", key: "groupingType" },
            { label: "Group Number", key: "groupNumber" }, // groupNumber
            { label: "Average % Score", key: "studentPercentage" },
            // Here we need to add Strands / Standards Push to Data
            // Here we need to add Student Moved From Group
        ];

        csvData.map((item, index) => {
            let SingleheaderData;
            for (let i = 0; i < item.strandOrStandardsObjectCount; i++) {
                SingleheaderData = {
                    standardAndStrandName: item['strandName_' + i + '_standardAndStrandName']
                }
                headersData.push(SingleheaderData)
            }
        })

        let dataFiltered = this.getUnique(headersData, 'standardAndStrandName')

        dataFiltered.map((strand_details, index) => {
            csvHeaders.push({ 'label': strand_details.standardAndStrandName, 'key': 'strandName_' + index + '_standardAndStrandAvg' })
        })
        csvHeaders.push({ 'label': 'Student Moved From', 'key': 'studentMovedFromGroup' })
        /**
         * strandName_0_noOfQuestions
         * strandName_0_standardAndStrandAvg
         * strandName_0_standardAndStrandName
         * strandName_0_standardShortValue
         */

        return csvHeaders;

    }

    render() {
        let csvGroupingHeaders = []
        let csvGroupingData = []
        const GroupingList = this.props.GroupPageData.GroupingList

        // This is CSV Data Logic that need to be pushed.

        this.props.GroupPageData.GroupingList.length !== null ? GroupingList.map((group, index) => {

            group.length > 0 ? group.map((studentLevel, index_studentLevel) => {

                let singleDataRow = ''
                singleDataRow = {
                    'districtName': studentLevel.districtName,
                    'schoolName': studentLevel.schoolName,
                    'grade': studentLevel.grade,
                    'teacherNames': studentLevel.teacherNames,
                    'classSisId': studentLevel.classSisId,
                    'className': studentLevel.className,
                    'studentName': studentLevel.firstName + ' ' + studentLevel.lastName,
                    'sisId': (studentLevel.sisId === null || studentLevel.sisId === "null") ? "" : studentLevel.sisId,
                    'groupingType': studentLevel.groupingType,
                    'groupNumber': parseInt(index) + 1,
                    'studentPercentage': studentLevel.studentPercentage,
                    'presentGroup': studentLevel.presentGroup,
                    'previousGroup': studentLevel.previousGroup,
                    'parentGroup': studentLevel.parentGroup,
                    'studentMovedFromGroup': (studentLevel.parentGroup !== studentLevel.presentGroup) && (studentLevel.presentGroup !== studentLevel.previousGroup) ? parseInt(studentLevel.previousGroup) + 1 : '',
                    'strandOrStandardsObjectCount': studentLevel.standardAndStrandVODetails.length
                }

                studentLevel.standardAndStrandVODetails.length > 0 ? studentLevel.standardAndStrandVODetails.map((strand_standardLevel, index_strand_or_standard) => {
                    Object.assign(singleDataRow, {
                        ['strandName_' + index_strand_or_standard + '_standardShortValue']: strand_standardLevel.standardShortValue,
                        ['strandName_' + index_strand_or_standard + '_noOfQuestions']: strand_standardLevel.noOfQuestions,
                        ['strandName_' + index_strand_or_standard + '_standardAndStrandAvg']: strand_standardLevel.standardAndStrandAvg,
                        ['strandName_' + index_strand_or_standard + '_standardAndStrandName']: strand_standardLevel.standardAndStrandName
                    })


                }) : null
                csvGroupingData.push(singleDataRow)
            }) : null

        }) : null


        csvGroupingHeaders = this.get_headers_of_CSV(csvGroupingData)


        setTimeout(() => {
            this.refs.groupCSV.link.click()
        }, 500)

        return (
            <CSVLink
                ref="groupCSV"
                textColor={'#333'}
                headers={csvGroupingHeaders}
                data={csvGroupingData}
                style={{ display: 'none' }}
                filename={"Group_CSV.csv"}>{this.Reset_class_grouping_CSV_download()}</CSVLink>
        );
    }
}

const mapStateToProps = ({ ClassGroupingReducer }) => {
    const { GroupingCSVDownload, GroupPage } = ClassGroupingReducer;
    return {
        GroupingCSVDownload, GroupPage
    };
};

export default connect(mapStateToProps, {
    Reset_class_grouping_CSV_download
})(Grouping_CSV_Download)