import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Scrollbars } from 'react-custom-scrollbars';
import { CloseGroupModal,MoveToGroupClicked} from '../../../Redux_Actions/ClassGroupingAction';
class MoveStudentGroup extends Component {
  constructor(props){
    super(props);
    this.state = {
      moveButton:false,
      selectedGroup:null
    }
   this.heighLightGroup = this.heighLightGroup.bind(this);
  }

//   componentDidMount() {
//     document.addEventListener('mousedown', (event) => {
//         if (event.target !== null && event.target !== undefined) {
//            this.closeGroupStudentModal();
//         }
//     }, false)
//  }

//  closeGroupStudentModal() {
//    this.props.CloseGroupModal('');
//  }
  heighLightGroup(GroupNumber){
    this.setState({
      moveButton:true,
      selectedGroup:GroupNumber
    });
  }

    render() { 
      const { ClassGroupingReducer, GroupIndex, StudentIndex, StudentName} = this.props;

      const GroupList = ClassGroupingReducer.GroupPage.GroupingList;

        return (
            <div className="bec_groups_move_student_popup_modal">
              <div className="bec_groups_move_student_popup_modal_inr">
                <div className="bec_groups_move_student_popup_modal_main">
                  <div className="bec_groups_move_student_popup_title">
                    Move <span>{StudentName}</span> from Group {GroupIndex+1} to:
                  </div>
                  <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={300}>
                  <div className="bec_groups_move_student_popup_modal_main_inr_groups">
                    <div className="bec_groups_move_student_popup_modal_main_inr_groups_main">
                    {GroupList.map((StudentNameArray,i) => (
                      i != GroupIndex ?

                      <div className={this.state.selectedGroup == i ? "bec_groups_move_student_popup_modal_main_inr_groups_single_row bec_groups_move_student_group_selected" : "bec_groups_move_student_popup_modal_main_inr_groups_single_row"}
                      onClick={() => this.heighLightGroup(i)}
                      >
                        <div className="bec_groups_move_student_popup_modal_main_inr_groups_single_row_group_name">
                        Group {i+ 1} <span>({StudentNameArray.length} Students)</span>
                        </div>
                        <div className="bec_groups_move_student_popup_modal_main_inr_groups_single_row_group_list">
                          <ul>
                        {StudentNameArray.map((Values,j)=>(
                                <li>
                                  <span className="bec_groups_move_student_popup_flag" style={(Values.presentGroup == Values.previousGroup) || (Values.presentGroup == Values.parentGroup) ? { visibility: 'hidden' } : { visibility: 'visible' }}>
                                    <i className="material-icons">flag</i>
                                  </span>
                                  <span className="bec_groups_move_student_popup_group_name">
                                    {Values.firstName + " " + Values.lastName}
                                  </span>
                                </li>
                        ))}</ul>
                        </div>
                      </div> : null
                      ))}
                    </div>
                  </div>
                  </Scrollbars>
                  <div className="bec_groups_move_student_popup_submit_actions">
                    <div className="bec_groups_move_student_popup_submit_actions_inr">
                      <div className="bec_groups_move_student_popup_submit_actions_cancel"
                      onClick={() => this.props.CloseGroupModal()}>
                        Cancel  
                      </div>
                      <div className="bec_groups_move_student_popup_submit_actions_apply">
                        <button className={this.state.moveButton?"bec_groups_move_student_popup_submit_actions_apply" : "btn bec_groups_move_student_submit_disable"}
                        onClick={() => this.props.MoveToGroupClicked(this.state.selectedGroup)}>
                          Move
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            );
    }
}

const MapStateToProps = ({ClassGroupingReducer})=>{
  return {
    ClassGroupingReducer
  }
}

export default connect(MapStateToProps,{
  CloseGroupModal, MoveToGroupClicked
})(MoveStudentGroup);