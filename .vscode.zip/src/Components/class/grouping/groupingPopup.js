import React, { Component } from 'react';
import editpopupIcon from '../../../../public/images/ic_grouping.svg';
import info_icon from '../../../../public/images/info_icon.svg';
import { Scrollbars } from 'react-custom-scrollbars';
import {
    CancelGroupPopUp,
    ClassGroupBy,
    ClassGroupPopUpDropDownToggle,
    GroupingCheckAllStrands,
    selectStandard,
    selectProduct,
    selectTaxonomy,
    selectGrade,
    selectQuestion,
    selectStrand, DoneInStrandsSelectionView,
    GetGrades_InGrouping, getTestAssessmentMaxCountInGrouping,
    Get_StandardPerformance_Details_In_Grouping,
    ChangeNumberOfGroups,
    ApplyGroupPopup,
    RemoveStradsFromSelectionList_ClickONSpan
} from '../../../Redux_Actions/ClassGroupingAction';
import ReactHtmlParser from 'react-html-parser';
import { connect } from 'react-redux';

import { checkTaxonomySetId } from '../../ReusableComponents/AllReusableFunctions';
import { EnddateFromDate_Tab, StartdateFromDate_Tab } from '../../../Utils/reUsableSnipets';
class GroupingPopup extends Component {

    constructor(props) {
        super(props);
    }

    componentWillMount() {
        this.GetStrands();
        this.GetGrades();
    }

    GetGrades() {
        let G_ApiCalls = this.props.ClassGroupingReducer.G_ApiCalls;
        if (G_ApiCalls.getGrades) {
            let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
            let SelectedProductID = this.props.ClassGroupingReducer.GroupProductTab.SelectedProductId;
            let Disply = this.props.Universal.ContextHeader;
            let ComponentsList = SelectedProductTestIds(this.props.Universal.UniversalSelecter.TestTab.SelectedTestList, SelectedProductID);
            const { Universal,Context_DateTab } = this.props;
            const { UniversalSelecter } = Universal;
            const { SelectedDistrictTerm } = Context_DateTab;
            let classId = Disply.Roster_Tab.SelectedClass.id;
            let startDate = Disply.Date_Tab.Report_termStartDate;
            let endDate = Disply.Date_Tab.Report_termEndDate;
            
            if (classId == undefined) {
                classId = UniversalSelecter.Roster_Data.SelectedClass == "All"?UniversalSelecter.Roster_Data.ClassList[0] && UniversalSelecter.Roster_Data.ClassList[0].id:UniversalSelecter.Roster_Data.SelectedClass.id;
            }
            if (startDate == undefined || startDate == "") {
                startDate = SelectedDistrictTerm.termStartDate;
            }
            if (endDate == undefined || endDate == "") {
                endDate = SelectedDistrictTerm.termEndDate;
            }
            let Req_Payload = {
                "classId": classId,
                "studentIds": Disply.Roster_Tab.StudentIds,
                "schoolId": Disply.Roster_Tab.SelectedSchool.id,
                "startDate": startDate,
                "endDate": endDate,
                "districtId": Disply.DistrictId,
                "componentCodeList": ComponentsList,
                "rosterGrade": Disply.Roster_Tab.selectedRosterGrade,
                "isPastDistrictTerm": Disply.Date_Tab.isPastDistrictTerm
            }
            // let Selected_Grade_In_Overview= this.props.Reports.StandardPerformance_Overview.StandardPerformanceFilter.TestGrade.selectedTestgrade
            this.props.GetGrades_InGrouping(AccessToken, Req_Payload);
        }
    }

    /**
     * initiate Api call to get strand details in grouping popup 
     */
    GetStrands() {
        let G_ApiCalls = this.props.ClassGroupingReducer.G_ApiCalls;
        let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
        let Disply = this.props.Universal.ContextHeader;

        let Nav = this.props.Universal.NavigationByHeaderSelection;
        /**
        * get strands  question after  success grade list success.
        */
        if (G_ApiCalls.getStrands && Nav.class) {
            let Req_Payload = ReqResponseToMakeApiCallInGroupsComponent(Disply, this.props.ClassGroupingReducer, this.props.Universal, 'strands',this.props.Context_DateTab)
            let GradeObj = this.props.ClassGroupingReducer.GroupGradeTab.SelectedGrade
            Req_Payload.grade = GradeObj == '' || GradeObj == null ? '' : GradeObj.grade;
            let SeelctedAssesed = this.props.ClassGroupingReducer.GroupAssesmentTab.SelectedAssessedQuestion;
            Req_Payload.assessedQuestionsNo = SeelctedAssesed == '' ? 1 : SeelctedAssesed;
            this.props.Get_StandardPerformance_Details_In_Grouping(AccessToken, Req_Payload)
        }
    }

    componentDidUpdate() {
        let G_ApiCalls = this.props.ClassGroupingReducer.G_ApiCalls;
        let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
        let Disply = this.props.Universal.ContextHeader;
        this.GetGrades();

        /**
         * get assessed question after  success grade list success.
         */
        if (G_ApiCalls.getassessed_Ques) {
            let Req_Payload = ReqResponseToMakeApiCallInGroupsComponent(Disply, this.props.ClassGroupingReducer, this.props.Universal, 'questions',this.props.Context_DateTab)
            this.props.getTestAssessmentMaxCountInGrouping(AccessToken, Req_Payload);
        }

        this.GetStrands();

    }

    CheckAllStrands(currentStatus) {
        this.props.GroupingCheckAllStrands(currentStatus);
    }

    dropDownSelection(fromWhichDropDown, currentStatus) {
        this.props.ClassGroupPopUpDropDownToggle(fromWhichDropDown, currentStatus);
    }
    handleSelectProduct(productId) {
        this.props.selectProduct(productId);
    }
    handleSelectTaxonomy(taxonomy) {
        this.props.selectTaxonomy(taxonomy);
    }

    handleSelectGrade(grade) {
        this.props.selectGrade(grade);
    }
    handleGroupByParam(selectedGroupByParam) {

        this.props.ClassGroupBy(selectedGroupByParam);
    }
    handleSelectQuestion(question) {
        this.props.selectQuestion(question);
    }
    handleCheck(selectedStandards, val) {
        return selectedStandards.some(item => val === item);
    }
    handleSelectStrand(selectedStrand) {
        this.props.selectStrand(selectedStrand)
    }
    hanldeSelectStandard(selectStandard) {
        this.props.selectStandard(selectStandard)
    }

    handleApplyButton() {
        let Disply = this.props.Universal.ContextHeader;
        let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
        let Req_Payload = ReqPayload_To_Get_groupingInformation(Disply, this.props.ClassGroupingReducer, this.props.Universal);
        this.props.ApplyGroupPopup(AccessToken, Req_Payload);
    }

    /**
     * 
     * @param {Object} GroupStrandsTab 
     * @returns {JSX Element}
     * if selected strands are more than 1 then will display this.
     */
    ReturnSeletedStrandNames(GroupStrandsTab) {
        if (GroupStrandsTab.SelectedStrands.length > 1) {
            return <div className="Beneath_Strands">
                {GroupStrandsTab.SelectedStrands.map((strand, i) => {
                    return <span key={i} >
                        <div className={`Beneath_Strands_item ${ReturnColorUnderStrandAvgBeneath(strand.strandAvg, this.props.AchivementLevels)}`}>
                            {strand.strandName}
                            <span className="cancelSTrandTypeUI" onClick={() => {
                                this.props.RemoveStradsFromSelectionList_ClickONSpan(strand)
                            }}>
                                X
                        </span>

                        </div></span>
                })}
            </div>

        }
    }

    render() {
        const {
            GroupTaxonomyTab, GroupGradeTab, GroupAssesmentTab, GroupStrandsTab, GroupTriggeringApiCalls, SelectedNumberOfGroups, ShowGroupApiCallLoading, ShowGroupLoading, openEditedGroupPopUp, openGroupPopUp, selectedGroupByParam
            , G_ApiCalls, AppliedChanges } = this.props.ClassGroupingReducer;
        let DisableApplyButtonValue = DisableApplyButton(this.props.ClassGroupingReducer);
        let Disable_DoneBtInStrads = DisableDoneInStrandsView(GroupStrandsTab, AppliedChanges);

        return (
            <div className="bec_groups_popup_modal">
                <div className="bec_groups_popup_modal_inr">
                    <div className="bec_groups_popup_modal_main">
                        {/* header */}
                        <div className="bec_groups_popup_modal_header">
                            <div className="bec_groups_popup_modal_header_text">
                                <span className="bec_groups_popup_modal_header_icon">
                                    <img src={editpopupIcon} />
                                </span>
                                Edit Groups
                        </div>
                        </div>
                        {/* header end */}
                        <div className="bec_groups_popup_modal_body">
                            <div className="bec_groups_popup_modal_body_inr">

                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_row_left_txt">
                                        <div className="bec_groups_popup_modal_row_label" style={{ width: '200px' }}> View :</div>
                                    </div>
                                    <div className="bec_groups_popup_modal_row_right" style={{ width: 300 }}>
                                        <div className="bec_groups_popup_modal_row_dropdown">

                                            <div className="bec_groups_popup_dropdown_main">
                                                <button
                                                    className="bec_groups_popup_dropdown_selector"
                                                    style={{ background: GroupTaxonomyTab.TaxonomiesList.length == 1 || GroupTaxonomyTab.SelectedTaxonomy == null || GroupTaxonomyTab.SelectedTaxonomy == undefined ? "white" : "" }}
                                                    onClick={
                                                        GroupTaxonomyTab.TaxonomiesList.length == 1 ? null : () => this.dropDownSelection('taxonomy', GroupTaxonomyTab.OpenGroupTaxonomyDropDown)
                                                    }>

                                                    {GroupTaxonomyTab.SelectedTaxonomy !== null && GroupTaxonomyTab.SelectedTaxonomy !== undefined ? GroupTaxonomyTab.TaxonomiesList.filter(taxonomy => {
                                                        return taxonomy == GroupTaxonomyTab.SelectedTaxonomy
                                                    })[0] : "View"}

                                                </button>
                                                <div className="bec_groups_popup_dropdown_selectorList" style={{ display: GroupTaxonomyTab.OpenGroupTaxonomyDropDown && GroupTaxonomyTab.TaxonomiesList.length > 1 ? 'block' : 'none' }}>
                                                    <ul>
                                                        {GroupTaxonomyTab.TaxonomiesList.map((taxonomy, i) =>
                                                            <li key={i} onClick={
                                                                taxonomy === GroupTaxonomyTab.SelectedTaxonomy ? null : () => this.handleSelectTaxonomy(taxonomy)
                                                            } className={taxonomy === GroupTaxonomyTab.SelectedTaxonomy ? "groupActiveDropdown" : ''} key={taxonomy}>{taxonomy}</li>
                                                        )}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_row_left_txt">
                                        <div className="bec_groups_popup_modal_row_label" style={{ width: '200px' }}> Test(s) assessed for : </div>
                                    </div>
                                    <div className="bec_groups_popup_modal_row_right" style={{ minWidth: '200px' }}>
                                        <div className="bec_groups_popup_modal_row_number_dropdown">
                                            {/* DropDown Goes here */}
                                            <div className="bec_groups_popup_dropdown_main">
                                                <button style={{ background: GroupGradeTab.GradeList.length == 1 ? "white" : "" }} className={GroupGradeTab.OpenGradeDropDown ? "bec_groups_popup_dropdown_selector bec_groups_popup_dropdown_selector_activated" : "bec_groups_popup_dropdown_selector"} onClick={
                                                    () => {
                                                        GroupGradeTab.GradeList.length == 1 ? null : this.dropDownSelection('grade', GroupGradeTab.OpenGradeDropDown)
                                                    }
                                                }>
                                                    {GroupGradeTab.SelectedGrade !== null && GroupGradeTab.SelectedGrade !== undefined ? convertGrade(GroupGradeTab.SelectedGrade.grade) : "Grade"}
                                                </button>
                                                <div className="bec_groups_popup_dropdown_selectorList questionDropDownOfGroupingTab" style={{ display: GroupGradeTab.OpenGradeDropDown ? 'block' : 'none' }}>
                                                    <ul style={{ textTransform: 'capitalize' }}>
                                                        {GroupGradeTab.GradeList.length > 0 ? GroupGradeTab.GradeList.map((gradeObj, index) => {

                                                            // let GradeArray = {...gradeObj.grade.split("_")};
                                                            return <li key={index} onClick={
                                                                (gradeObj.grade === GroupGradeTab.SelectedGrade.grade) ? null : () => this.handleSelectGrade(gradeObj)
                                                            } className={gradeObj.grade === GroupGradeTab.SelectedGrade.grade ? "groupActiveDropdown" : ''} >
                                                                <div className="groupingtab_single_dropdown_element">
                                                                    {convertGrade(gradeObj.grade)}
                                                                </div>
                                                            </li>
                                                        })
                                                            : null}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <span className="group-data-reload">
                                        {G_ApiCalls.loader_on_grade ?
                                            <i className="material-icons">autorenew</i>
                                            : null}
                                    </span>
                                </div>
                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_row_left_txt">
                                        <div className="bec_groups_popup_modal_row_label" style={{ minWidth: '200px', fontSize: 14 }}> Assessed with : </div>
                                    </div>
                                    <div className="bec_groups_popup_modal_row_middle" style={{ width: '200px', marginRight: 8 }}>
                                        <div className="bec_groups_popup_modal_row_dropdown">
                                            <div className="bec_groups_popup_modal_row_number_dropdown">
                                                {/* DropDown Goes here */}
                                                <div className="bec_groups_popup_dropdown_main">
                                                    <button className={GroupAssesmentTab.OpenGroupAssessmentDropDown ? "bec_groups_popup_dropdown_selector bec_groups_popup_dropdown_selector_activated" : "bec_groups_popup_dropdown_selector"} onClick={
                                                        () => this.dropDownSelection('question', GroupAssesmentTab.OpenGroupAssessmentDropDown)
                                                    }>
                                                        {GroupAssesmentTab.SelectedAssessedQuestion !== null ? GroupAssesmentTab.SelectedAssessedQuestion + "+ questions" : "Question"}
                                                    </button>
                                                    <div className="bec_groups_popup_dropdown_selectorList questionDropDownOfGroupingTab" style={{ display: GroupAssesmentTab.OpenGroupAssessmentDropDown ? 'block' : 'none' }}>
                                                        <ul style={{ textTransform: 'capitalize' }}>
                                                            {GroupAssesmentTab.QuestionList.map((question, index) =>
                                                                <li key={index} onClick={
                                                                    question === GroupAssesmentTab.SelectedAssessedQuestion ? null :
                                                                        () => this.handleSelectQuestion(question)
                                                                } className={question === GroupAssesmentTab.SelectedAssessedQuestion ? "groupActiveDropdown" : ''} >
                                                                    <div className="groupingtab_single_dropdown_element">
                                                                        {question + "+ questions"}
                                                                    </div>
                                                                </li>
                                                            )}
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <span className="group-data-reload">
                                        {G_ApiCalls.loader_on_assessed_que ?
                                            <i className="material-icons">autorenew</i>
                                            : null}
                                    </span>
                                </div>
                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_row_full_length">
                                        <b>Note: </b> Select multiple Strands to compare or select a single Strand to compare multiple Standards within that Strand
                            </div>
                                    <div className="bec_groups_popup_modal_row_inr">
                                        <div className="bec_groups_popup_modal_row_left_txt" >
                                            <div className="bec_groups_popup_modal_row_label" style={{ fontSize: 14 }}>Select Strands:</div>
                                        </div>
                                        <div className="bec_groups_popup_modal_row_middle" style={{ width: 382, marginRight: 8 }}>
                                            <div className="bec_groups_popup_modal_row_dropdown">
                                                {/* DropDown Goes here */}
                                                <div className="bec_groups_popup_dropdown_main">
                                                    <button className={
                                                        GroupStrandsTab.StrandsList.length == 1 ? "bec_groups_popup_dropdown_selector_disable" :
                                                            GroupStrandsTab.OpenGroupStrandsDropDown ? "bec_groups_popup_dropdown_selector bec_groups_popup_dropdown_strand_selector_activated" : "bec_groups_popup_dropdown_selector"}
                                                        onClick={
                                                            () => {
                                                                if (GroupStrandsTab.StrandsList.length > 1) {
                                                                    this.dropDownSelection('strands', GroupStrandsTab.OpenGroupStrandsDropDown)
                                                                }
                                                            }}>
                                                        {GroupStrandsTab.StrandSelection}
                                                    </button>
                                                    <div className="bec_groups_popup_dropdown_selectorList" style={{ display: GroupStrandsTab.OpenGroupStrandsDropDown ? 'block' : 'none' }}>
                                                        {/* dropdown start */}
                                                        <div className="bec_groups_popup_dropdown_container">
                                                            <div className="bec_groups_popup_dropdown_container_list">
                                                                <div className="bec_groups_popup_dropdown_list-inr">
                                                                    <ul>
                                                                        <li onClick={
                                                                            () => this.handleSelectStrand("All")
                                                                        }>
                                                                            <div className="bec_groups_popup_dropdownSingleitem">
                                                                                <div className="input-checkbox checkbox-lightBlue">
                                                                                    <input type="checkbox" checked={GroupStrandsTab.SelectAllStrands} />
                                                                                    <span className="checkbox" />
                                                                                </div>
                                                                                <span />
                                                                            </div>
                                                                            <div className="bec_groups_popup_dropdown_label bec_groups_popup_whiteColor">
                                                                                All
                                                                            </div>
                                                                        </li>
                                                                        {this.StrandsList(GroupStrandsTab)}
                                                                    </ul>
                                                                </div>
                                                                <div className="bec_groups_popup_dropdown-select-filter" style={{ borderTop: '1px solid #D6DBE5', padding: '10px 0px' }}>
                                                                    <div className="bec_groups_popup_dropdown_strands-btns">
                                                                        <div className="bec_groups_popup_dropdown_strands-cancel-btn float-left" onClick={
                                                                            () => this.dropDownSelection('strands', true)
                                                                        }>Cancel</div>
                                                                        <div className="bec_groups_popup_dropdown_strands_apply-btn float-right">
                                                                            <button
                                                                                className={Disable_DoneBtInStrads ? "btn disableFilter_grouping universal-selector-applyfilter" : "btn universal-selector-applyfilter"}
                                                                                disabled={Disable_DoneBtInStrads}
                                                                                onClick={() => this.props.DoneInStrandsSelectionView()}
                                                                            >Done</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <span className="group-data-reload">
                                            {G_ApiCalls.loader_on_strads ?
                                                <i className="material-icons">autorenew</i>
                                                : null}
                                        </span>
                                        <div className="bec_groups_popup_modal_row_right">
                                            <div className="bec_groups_popup_modal_row_label" style={{ fontSize: 14 }}> Selected: {GroupStrandsTab.SelectedStrands.length}/{GroupStrandsTab.StrandsList.length}</div>
                                        </div>
                                        {this.ReturnSeletedStrandNames(GroupStrandsTab)}
                                    </div>
                                    {this.props.ClassGroupingReducer.MaxStudentsCountForGroups < 3 ? <div className="bec_groups_popup_modal_row_full_length" style={{ color: "red", marginTop: "10px", marginBottom: "0" }}><b style={{ color: "red" }}>Note:</b> A group cannot be made with less than 2 students based on the selection(s) above.</div> : null}
                                </div>
                                {GroupStrandsTab.SelectedStrands.length == 1 ?
                                    <div className="bec_groups_popup_modal_row">
                                        <div className="bec_groups_popup_modal_row_strandsList_full_length">
                                            <div className="bec_groups_popup_modal_row_title">
                                                <div className="bec_groups_popup_modal_row_label">
                                                    Select Standards:
                                                    <div className="bec_groups_popup_modal_row_strand_right_checks">

                                                        <div className="bec_groups_popup_modal_row_strand_leftToggle_block">
                                                            <div className="bec_groupd_popup_checkall_buttons">
                                                                {/*  */}
                                                                <div class="bec_groups_popup_select_all" onClick={
                                                                    () => this.CheckAllStrands(GroupStrandsTab.StandardsView.SelectedAllStandards)
                                                                } >
                                                                    <div class="input-checkbox checkbox-lightBlue">
                                                                        <input type="checkbox" value="true" checked={GroupStrandsTab.StandardsView.SelectedAllStandards} />
                                                                        <span class="checkbox"></span>
                                                                    </div>
                                                                    <span>Select All</span>
                                                                </div>
                                                                {/*  */}
                                                            </div>
                                                        </div>
                                                        <div className="bec_groups_popup_modal_row_strand_leftToggle_block">
                                                            <div className="bec_groupd_popup_checkall_buttons">
                                                                {/*  */}
                                                                <div class="bec_groups_popup_select_all" onClick={
                                                                    () => this.dropDownSelection('hide-show', GroupStrandsTab.ShowStandardDescription)
                                                                } >
                                                                    <div class="input-checkbox checkbox-lightBlue">
                                                                        <input type="checkbox" value="true" checked={GroupStrandsTab.ShowStandardDescription} />
                                                                        <span class="checkbox"></span>
                                                                    </div>
                                                                    <span>Standards Description</span>
                                                                </div>
                                                                {/*  */}
                                                            </div>
                                                        </div>

                                                    </div>
                                                    {/* end of design update */}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="bec_groups_popup_modal_row_full_length" style={{ marginBottom: 0 }}>
                                            <div className={GroupStrandsTab.ShowStandardDescription ? "bec_groups_popup_modal_row_strand_list bec_groups_popup_modal_strand_list_description" : "bec_groups_popup_modal_row_strand_list"}>
                                                <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={97}>

                                                    <ul>
                                                        {this.ReturnSelectedStrand_StandardIds(GroupStrandsTab)}
                                                    </ul>

                                                </Scrollbars>
                                            </div>
                                        </div>
                                    </div>
                                    : null}
                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_row_left_txt">
                                        <div className="bec_groups_popup_modal_row_label"> Number of Groups</div>
                                    </div>
                                    <div className="bec_groups_popup_modal_row_middle">
                                        <div className="bec_groups_popup_modal_row_dropdown_no_of_groups">
                                            <div className="bec_groups_popup_modal_row_dropdown_increment">
                                                <i className="material-icons" style={SelectedNumberOfGroups > 1 ? { color: "#00539b" } : { color: "" }}
                                                    onClick={() => SelectedNumberOfGroups == 1 ? null : this.props.ChangeNumberOfGroups("remove")}
                                                >
                                                    remove_circle_outline
                                </i>
                                            </div>
                                            <div className="bec_groups_popup_modal_row_dropdown_fieldBox">
                                                <input type="text" value={SelectedNumberOfGroups} min="3" readOnly />
                                            </div>
                                            <div className="bec_groups_popup_modal_row_dropdown_increment">
                                                <i className="material-icons" style={SelectedNumberOfGroups < this.props.ClassGroupingReducer.MaxStudentsCountForGroups ? { color: "#00539b" } : { color: "" }}
                                                    onClick={() => SelectedNumberOfGroups < this.props.ClassGroupingReducer.MaxStudentsCountForGroups ? this.props.ChangeNumberOfGroups("add") : null}>
                                                    add_circle_outline
                                </i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_row_left_txt">
                                        <div className="bec_groups_popup_modal_row_label">
                                            <span>Group by </span>
                                            <span className="bec_groups_popup_modal_tooltip">
                                                <img src={info_icon} style={{ cursor: "pointer", marginLeft: "4px" }} />
                                                <div className="bec_groups_popup_modal_tooltip_main">
                                                    <span className="bec_groups_popup_modal_tooltip_arrow" />
                                                    <div className="bec_groups_popup_modal_tooltip_inr">
                                                        <div className="bec_groups_popup_modal_tooltip_title">
                                                            Group By
                                    </div>
                                                        <div className="bec_groups_popup_modal_tooltip_body">
                                                            <div className="bec_groups_popup_modal_tooltip_single_line">
                                                                <b>Cluster</b>: Students are grouped by common strengths and weaknesses on the selected standards. Groups are not necessarily equal size.
                                        </div>
                                                            <div className="bec_groups_popup_modal_tooltip_single_line">
                                                                <b>Average</b>: Groups of equal size are created based on students' average score across the selected standards.
                                        </div>
                                                            <div className="bec_groups_popup_modal_tooltip_single_line">
                                                                <b>High-Low</b>: Students with the highest and lowest overall average scores across the selected standards are grouped together.
                                        </div>
                                                            <div className="bec_groups_popup_modal_tooltip_single_line">
                                                                <b>Note:</b> All Grouping Strategies are based on the following average score calculation for each student/standard in the table below: (earned points/total points)*100</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </span>
                                        </div>
                                    </div>
                                    <div className="bec_groups_popup_modal_row_right">
                                        <div className="bec_groups_popup_modal_row_radio_buttons">
                                            <ul>
                                                <li className={selectedGroupByParam == 'CLUSTERING' ? "activeGroupPopupRadio" : null}
                                                    onClick={() => this.handleGroupByParam('CLUSTERING')}>
                                                    <span className="bec_groups_popup_modal_radio">
                                                        <div className="bec_groups_popup_modal_radio_inr" />
                                                    </span>
                                                    <span className="bec_groups_popup_modal_radio_label">
                                                        Cluster
                                    </span>
                                                </li>
                                                <li className={selectedGroupByParam == 'AVERAGE' ? "activeGroupPopupRadio" : null}
                                                    onClick={() => this.handleGroupByParam('AVERAGE')}>
                                                    <span className="bec_groups_popup_modal_radio" >
                                                        <div className="bec_groups_popup_modal_radio_inr" />
                                                    </span>
                                                    <span className="bec_groups_popup_modal_radio_label">
                                                        Average
                                    </span>
                                                </li>
                                                <li className={selectedGroupByParam == 'HIGH_LOW' ? "activeGroupPopupRadio" : null}
                                                    onClick={() => this.handleGroupByParam('HIGH_LOW')}>
                                                    <span className="bec_groups_popup_modal_radio">
                                                        <div className="bec_groups_popup_modal_radio_inr" />
                                                    </span>
                                                    <span className="bec_groups_popup_modal_radio_label">
                                                        High-Low
                                    </span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                {/* row end */}
                                {/* row */}
                                <div className="bec_groups_popup_modal_row">
                                    <div className="bec_groups_popup_modal_submit_block">
                                        <div className="bec_groups_popup_modal_cancel" onClick={() => {
                                            this.props.CancelGroupPopUp(this.props.ClassGroupingReducer.AppliedChanges)
                                        }
                                        }>Cancel</div>
                                        <div className="bec_groups_popup_modal_submit_button">
                                            <button className={DisableApplyButtonValue ? "disableFilter_grouping" : null} disabled={DisableApplyButtonValue}
                                                onClick={
                                                    DisableApplyButtonValue ? null : () => this.handleApplyButton()}>
                                                Apply
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                {/* row end */}
                            </div>
                        </div>
                    </div>
                </div>
            </div >
        );
    }
    /**
     * 
     * @param {Object} GroupStrandsTab 
     */
    StrandsList(GroupStrandsTab) {
        if (GroupStrandsTab.StrandsList.length !== 0) {
            return GroupStrandsTab.StrandsList.map((strand, index) => <li key={index} onClick={
                () => this.handleSelectStrand(strand)
            }>
                <div className="bec_groups_popup_dropdownSingleitem">
                    <div className="input-checkbox checkbox-lightBlue">
                        <input type="checkbox" value="" checked={strand.check} />
                        <span className="checkbox" />
                    </div>
                </div>
                <div className={`bec_groups_popup_dropdown_label ${ReturnColorBasedOnStrandAvg(strand.strandAvg, this.props.AchivementLevels)}`}>{strand.strandName}</div>
            </li >
            )
        } else return null;
    }
    /**
     * 
     * @param {Object} GroupStrandsTab
     * @returns {JSX} 
     * if user Selectes any one strand, then we whave to return all standard ids of that strand.
     */
    ReturnSelectedStrand_StandardIds(GroupStrandsTab) {
        return GroupStrandsTab.SelectedStrands[0].standards.map((standard) =>
            <li
                onClick={
                    () => this.hanldeSelectStandard(standard.standardId)
                }
                key={standard.standardId}
                className={standard.check ? "bec_group_strand_selected" : ""} >
                <div className={"bec_groups_popup_modal_row_strand_button " + standardViewColorBasedOnAVG(standard, this.props.AchivementLevels)}>
                    {standard.standardName}
                </div>
                <div className="bec_groups_popup_modal_row_strand_description">
                    {ReactHtmlParser(standard.standardDesc)}
                </div>
            </li>
        )
    }
}
const MapStateToProps = ({ ClassGroupingReducer, Universal, Authentication, Reports,DateTabReducer }) => {
    const { Context_DateTab } = DateTabReducer;
    const { AchivementLevels,currentTermID } = Universal
    return {
        ClassGroupingReducer, Universal, Authentication, Reports, AchivementLevels,currentTermID,Context_DateTab
    }
}
export default connect(MapStateToProps, {
    CancelGroupPopUp,
    ClassGroupBy,
    ClassGroupPopUpDropDownToggle,
    GroupingCheckAllStrands,
    selectStandard,
    selectProduct,
    selectTaxonomy,
    selectGrade,
    selectQuestion,
    selectStrand,
    ApplyGroupPopup,
    DoneInStrandsSelectionView,
    GetGrades_InGrouping, getTestAssessmentMaxCountInGrouping,
    Get_StandardPerformance_Details_In_Grouping,
    ChangeNumberOfGroups,
    RemoveStradsFromSelectionList_ClickONSpan
})(GroupingPopup);
export function SelectedProductTestIds(Tests_of_PresentClass, SelectedProductID) {
    let ComponentsList = [];
    Tests_of_PresentClass.map((test, i) => {
        // if (test.productId == SelectedProductID) {
        ComponentsList.push(test.componentCode);
        //}
    })
    return ComponentsList;
}
/**
 * 
 * @param {Object} standard 
 * @returns {String}
 * will return extended Class name based on standards avg.
 */
function standardViewColorBasedOnAVG(standard, achivementLevelData) {
    if (standard.standardAvg < achivementLevelData[0].max) {
        return "bec_groups_popup_modal_row_strand_red";
    } else if (standard.standardAvg < achivementLevelData[1].max) {
        return "bec_groups_popup_modal_row_strand_orange";
    } else if (standard.standardAvg < achivementLevelData[2].max) {
        return "bec_groups_popup_modal_row_strand_yellow";
    } else {
        return "bec_groups_popup_modal_row_strand_green";
    }
}
function ReturnColorUnderStrandAvgBeneath(strand, achivementLevelData) {
    if (strand < achivementLevelData[0].max) {
        return "bec_groups_popup_modal_row_strand_beneath_red";
    } else if (strand < achivementLevelData[1].max) {
        return "bec_groups_popup_modal_row_strand_beneath_orange";
    } else if (strand < achivementLevelData[2].max) {
        return "bec_groups_popup_modal_row_strand_beneath_yellow";
    } else {
        return "bec_groups_popup_modal_row_strand_beneath_green";
    }
}
/**
 * 
 * @param {Int32Array} StrandAvg 
 * Will Return CLass Name Based ON Strand Avg 
 */
function ReturnColorBasedOnStrandAvg(StrandAvg, achivementLevelData) {
    if (StrandAvg < achivementLevelData[0].max) {
        return "bec_groups_popup_redColor";
    } else if (StrandAvg < achivementLevelData[1].max) {
        return "bec_groups_popup_orangeColor";
    } else if (StrandAvg < achivementLevelData[2].max) {
        return "bec_groups_popup_yellowColor";
    } else {
        return "bec_groups_popup_greenColor";
    }
}
/**
 * 
 * @param {Object} ClassGroupingReducer 
 */
function DisableApplyButton(ClassGroupingReducer) {
    let Final = ClassGroupingReducer.AppliedChanges;
    let G_ApiCalls = ClassGroupingReducer.G_ApiCalls;
    let DisableButton = true;
    if (ClassGroupingReducer.MaxStudentsCountForGroups < 3) {
        return true
    }
    if (G_ApiCalls.loader_on_grade || G_ApiCalls.loader_on_assessed_que || G_ApiCalls.loader_on_strads) {
        return true
    }
    if (Final.selectedStrands_Final.length === ClassGroupingReducer.GroupStrandsTab.SelectedStrands.length) {
        if (ClassGroupingReducer.GroupStrandsTab.SelectedStrands.length == 1) {
            let SelectedStandards = Final.selectedStrands_Final[0].standards;
            let CurrentStandards = ClassGroupingReducer.GroupStrandsTab.SelectedStrands[0].standards;
            // let DisableButton = true;
            let StandardisNotChanged = false;
            for (var i = 0; i < SelectedStandards.length; i++) {
                let FinalStandard = SelectedStandards[i];
                for (var j = 0; j < CurrentStandards.length; j++) {
                    let CurrentStandard = CurrentStandards[j];
                    if (CurrentStandard.standardId == FinalStandard.standardId) {
                        if (CurrentStandard.check == FinalStandard.check) {
                            StandardisNotChanged = true
                        } else {
                            StandardisNotChanged = false
                        }
                    }
                }
                if (!StandardisNotChanged) {
                    break;
                }
            }
            if (!StandardisNotChanged) {
                DisableButton = false;
            }
        } else {
            // DisableButton = false;
            let SelectedStandards = Final.selectedStrands_Final;
            let CurrentStandards = ClassGroupingReducer.GroupStrandsTab.SelectedStrands;
            let StandardisChanged = false;
            for (var i = 0; i < SelectedStandards.length; i++) {
                let FinalStandard = SelectedStandards[i];


                let Finds = CurrentStandards.find(item => item.strandName == FinalStandard.strandName && item.check == FinalStandard.check);

                if (Finds == undefined) {
                    StandardisChanged = true;
                    break;
                }
            }
            if (StandardisChanged) {
                DisableButton = false;
            }
        }
    }
    else {
        DisableButton = false;
    }
    if (Final.Grade !== ClassGroupingReducer.GroupGradeTab.SelectedGrade ||
        Final.AssessedQuestion !== ClassGroupingReducer.GroupAssesmentTab.SelectedAssessedQuestion ||
        Final.NoOfGroups !== ClassGroupingReducer.SelectedNumberOfGroups || Final.GroupBy !== ClassGroupingReducer.selectedGroupByParam) {
        DisableButton = false
    }
    if (ClassGroupingReducer.GroupStrandsTab.SelectedStrands.length == 1) {
        if (ClassGroupingReducer.GroupStrandsTab.SelectedStrands[0].standards.filter(item => item.check).length == 0) {
            return DisableButton = true
        }
    }
    return DisableButton;
}
/**
 * 
 * @param {Object} Disply context rreducer prop Object.
 * @returns {Object} 
 */
export function ReqResponseToMakeApiCallInGroupsComponent(Disply, ClassGroupingReducer, Universal, from) {
    let GradeObj = ClassGroupingReducer.GroupGradeTab.SelectedGrade
    let SelectedGradeId = GradeObj == '' || GradeObj == null ? '' : GradeObj.grade;
    let SelectedProductID = ClassGroupingReducer.GroupProductTab.SelectedProductId;
    let ComponentsList = SelectedProductTestIds(Universal.UniversalSelecter.TestTab.SelectedTestList, SelectedProductID);
    let SelectedStudents = Disply.Roster_Tab.StudentIds;
    let currentTermId = Universal.currentTermID;
   
    let classId = Disply.Roster_Tab.SelectedClass.id;
    let startDate = Disply.Date_Tab.Report_termStartDate;
    let endDate = Disply.Date_Tab.Report_termEndDate;
    let districtId = Disply.DistrictId;
    let schoolId = Disply.Roster_Tab.SelectedSchool.id;

    const { UniversalSelecter } = Universal;
    if (classId == undefined) {
        classId = UniversalSelecter.Roster_Data.SelectedClass == "All"?UniversalSelecter.Roster_Data.ClassList[0] && UniversalSelecter.Roster_Data.ClassList[0].id:UniversalSelecter.Roster_Data.SelectedClass.id;
    }
    if (startDate == undefined || startDate == "") {
        startDate = StartdateFromDate_Tab(Disply.Date_Tab);
    }
    if (endDate == undefined || endDate == "") {
        endDate = EnddateFromDate_Tab(Disply.Date_Tab);
    }
    if (districtId == undefined) {
        districtId = Disply.Default_districtID;
    }
    if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
    }
    if (SelectedGradeId == undefined) {
        SelectedGradeId = ClassGroupingReducer.GroupGradeTab.GradeList[0].grade;
    }


    let Req_Payload = {
        "classId": classId,
        "schoolId": schoolId,
        "studentIds": SelectedStudents,
        "startDate": startDate,
        "endDate": endDate,
        "districtId": districtId,
        "componentCodeList": ComponentsList,
        "grade": SelectedGradeId,
        "rosterGrade": Disply.Roster_Tab.selectedRosterGrade,
        "isPastDistrictTerm": Disply.Date_Tab.isPastDistrictTerm,
        "currentTermId": currentTermId // datetab api response first alpha term_id
    }
    return Req_Payload
}
/**
 * 
 * @param {Object} Disply 
 * @param {Object} ClassGroupingReducer 
 * @param {Object} Universal 
 * 
 * @returns {Object}
 */
export function ReqPayload_To_Get_groupingInformation(Disply, ClassGroupingReducer, Universal) {
    let Req_Payload = ReqResponseToMakeApiCallInGroupsComponent(Disply, ClassGroupingReducer, Universal);
    let StandardsList = [];
    let selectedStandardsList = []
    let SelectedStrandsList = ClassGroupingReducer.GroupStrandsTab.SelectedStrands;
    if (SelectedStrandsList.length == 1) {
        SelectedStrandsList.map(strand => {
            strand.standards.map(standard => {
                if (standard.check) {
                    for (let ij = 0; ij < standard.nationalStdIds.length; ij++) {
                        StandardsList.push(standard.nationalStdIds[ij]);
                    }
                    selectedStandardsList.push(standard.standardId)
                }
            })
        })
    } else {
        SelectedStrandsList.map(strand => {
            strand.standards.map(standard => {
                for (let p = 0; p < standard.nationalStdIds.length; p++) {
                    StandardsList.push(standard.nationalStdIds[p]);
                }
                selectedStandardsList.push(standard.standardId)
            })
        })
    }
    StandardsList = [...new Set(StandardsList)]
    Req_Payload.standardIds = StandardsList;
    Req_Payload.selectedStandardsList = selectedStandardsList
    Req_Payload.assessedQuestionsNo = ClassGroupingReducer.GroupAssesmentTab.SelectedAssessedQuestion;
    Req_Payload.numOfGroups = ClassGroupingReducer.SelectedNumberOfGroups;
    Req_Payload.isGroupingStandard = SelectedStrandsList.length == 1;
    Req_Payload.groupingType = ClassGroupingReducer.selectedGroupByParam;
    Req_Payload.grade = ClassGroupingReducer.GroupGradeTab.SelectedGrade.grade;
    Req_Payload.setId = checkTaxonomySetId(ClassGroupingReducer.SetValues, ClassGroupingReducer.GroupTaxonomyTab.SelectedTaxonomy);

    // extra params that need to pass throught grouping
    const ContextHeaderParams = Universal.ContextHeader.Roster_Tab;
    Req_Payload.districtName = ContextHeaderParams.SelectedDistrict.name;
    Req_Payload.schoolName = ContextHeaderParams.SelectedSchool.name;
    Req_Payload.className = ContextHeaderParams.SelectedClass.name;
    Req_Payload.studentIds = ContextHeaderParams.StudentIds;

    return Req_Payload;
}
/**
 * 
 * @param {Object} GroupStrandsTab
 * @returns {Boolean} 
 */
function DisableDoneInStrandsView(GroupStrandsTab, AppliedChanges) {
    let SelectedStrands = GroupStrandsTab.StrandsList.filter(strands => strands.check);
    let StrandsAfterDone = GroupStrandsTab.Strands_After_Done.filter(item => item.check);
    if (SelectedStrands.length == 0) {
        return true;
    } else if ((StrandsAfterDone.length == SelectedStrands.length)) {
        let DisableButton = true;
        if (StrandsAfterDone.length == 1) {
            DisableButton = StrandsAfterDone[0].strandName == SelectedStrands[0].strandName
        } else {

            for (var Y_Not_i = 0; Y_Not_i < SelectedStrands.length; Y_Not_i++) {

                let STrandsIs = SelectedStrands[Y_Not_i];
                let Idx = StrandsAfterDone.some(srd => srd.strandName === STrandsIs.strandName)

                if (!Idx) {
                    DisableButton = false;
                    break;
                }
            }
        }
        return DisableButton;
    }
    else return false
}
function convertGrade(grade) {
    const value = grade.toString()
    const value2 = value.split("_")[1]
    return `Grade ${value2}`
}