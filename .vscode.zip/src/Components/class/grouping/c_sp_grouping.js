import React, { Component } from 'react';
import { connect } from 'react-redux';
import ConfigStore from '../../../Config_Setup/ReduxSetUp/ConfigStore';
import {
    GroupingPagedDisplay,
    EditClassGrouping,
    GroupPage_SS_Nav,
    GroupPageMoveStudent,
    ClassGroupBy,
    ApplyGroupPopup,
    onClickBubbleGrouping,
    SortGroupsBasedOnParam,
    moveStudentConfirmation,
    handlePaginationClick_Navigation
} from '../../../Redux_Actions/ClassGroupingAction';
import GroupingPopup, { ReqPayload_To_Get_groupingInformation } from './groupingPopup';
import { Scrollbars } from 'react-custom-scrollbars';

import LoadingScreen from '../../../Utils/LoadingScreen/LoadingScreen';
import { convertToNumberGrade } from './../../ReusableComponents/AllReusableFunctions';
import './c_sp_grouping.css';
import MoveStudentGroup from './moveStudentGroup';
import GroupingPagePrint from '../../ReusableComponents/PDFReports/GroupingPagePrint';
import '../../../../public/css/style.css';

import printIco from '../../../../public/images/ic_print_new.svg';

import bulb from '../../../../public/images/bulb.svg';
import IR_Bulb_Top from '../../../Utils/IR_Bulb_Top';
import { HANDLE_PAGINATION_CLICK_NAVIGATION } from '../../../Reducer_Action_Types/ClassGroupingTypes';
import { Nav_strands_Count_perPage_ } from '../../../Redux_Reducers/ComparisonReducer';
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

var SortedGroups = [];
var SortedGroupNumbers = [];
var BottomNumbers = [];
let NumberOfGroupsInPage = 2;
let LengthStrandAndStandards = 0;

class c_sp_grouping extends Component {

    constructor(props) {
        super(props);
        this.state = {
            // bubbleLeft: 0,
            // bubbleRight: 3
        }
        this.handlePageDisplay = this.handlePageDisplay.bind(this)
        this.MadeGroupsByParams = this.MadeGroupsByParams.bind(this)
    }

    componentDidMount(){
        this.props.trackingUsage("assessmentreports_standardperformancegrouping:class");
    }

    handleGroupByParam(selectedGroupByParam) {
        let Disply = this.props.Universal.ContextHeader;
        let AccessToken = this.props.Authentication.LoginDetails.JWTToken;
        let Req_Payload = ReqPayload_To_Get_groupingInformation(Disply, this.props.ClassGroupingReducer, this.props.Universal);
        Req_Payload.groupingType = selectedGroupByParam;
        this.props.ApplyGroupPopup(AccessToken, Req_Payload);
    }

    colorCodes(score) {
        let achivementLevelData = this.props.AchivementLevels
        switch (true) {
            case (score <= achivementLevelData[0].max):
                return "bec_group_multi_list_red";
            case (score <= achivementLevelData[1].max):
                return "bec_group_multi_list_orange";
            case (score <= achivementLevelData[2].max):
                return "bec_group_multi_list_yellow";
            case (score <= achivementLevelData[3].max):
                return "bec_group_multi_list_green"
            default:
                return "bec_group_multi_list_grey";
        }
    }

    handleMoveStudent(GroupIndex, StudentIndex, StudentName, studentId, stdObj) {
        this.props.GroupPageMoveStudent(GroupIndex, StudentIndex, StudentName, studentId, stdObj)
    }

    handleArrowClick(NavLeftCount, NavRightCount, NavType) {
        this.props.GroupPage_SS_Nav(NavLeftCount, NavRightCount, NavType);
    }

    //****** Pagination Logic ******/

    // handlePaginationClick(PageType) {
    //     if (PageType == "right") {
    //         this.setState({
    //             bubbleRight: this.state.bubbleRight + 1,
    //             bubbleLeft: this.state.bubbleLeft + 1
    //         })
    //     }
    //     else {
    //         this.setState({
    //             bubbleRight: this.state.bubbleRight - 1,
    //             bubbleLeft: this.state.bubbleLeft - 1
    //         })
    //     }

    // }

    onClickBubble(index) {
        this.props.onClickBubbleGrouping(index);
    }
    handlePageDisplay(pageNumber) {
        this.props.GroupingPagedDisplay(pageNumber)
    }
    //****** End ******/

    /**
     * 
     * @param {* String} ParamOnwhichScore 
     * @param {* String with 'ASC OR DSC'} orderOfSort 
     */
    handleSortingGroups(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort) {
        this.props.SortGroupsBasedOnParam(ParamOnwhichScore, Strand_Standard_type, Strand_Standard, orderOfSort)
    }

    sortGroup() {
        const { GroupPage } = this.props.ClassGroupingReducer;
        let grouplist = GroupPage.GroupingList;
        let a = 0;
        let b = NumberOfGroupsInPage;
        let TotalGroupNumber = [];
        SortedGroups = [];
        SortedGroupNumbers = [];
        BottomNumbers = [];
        let increasedValue = NumberOfGroupsInPage;
        let length = Math.ceil(grouplist.length / NumberOfGroupsInPage);

        let count = GroupPage.GroupingList.map((values, l) => (
            TotalGroupNumber.push(l)
        ));

        for (var i = 0; i < length; i++) {
            SortedGroups.push(grouplist.slice(a, b));
            SortedGroupNumbers.push(TotalGroupNumber.slice(a, b));
            a = a + NumberOfGroupsInPage;
            b = b + NumberOfGroupsInPage;
        }
        for (var i = 0; i < length; i++) {
            if (i == 0) {
                BottomNumbers.push(`1-${NumberOfGroupsInPage}`)
            } else {
                BottomNumbers.push(`${increasedValue + 1}-${increasedValue + NumberOfGroupsInPage}`);
                increasedValue = increasedValue + NumberOfGroupsInPage;
            }
        }
    }

    MadeGroupsByParams(array, key) {

        return array.reduce((result, currentValue) => {
            (result[currentValue[key]] = result[currentValue[key]] || []).push(
                currentValue
            );
            return result;
        }, []);
        // .filter(element => element.length >0)
    };

    render() {
        const { GroupPage, openGroupPopUp, selectedGroupByParam, GroupStrandsTab, G_ApiCalls, AppliedChanges } = this.props.ClassGroupingReducer;

        let { loader_on_apply_group_page } = G_ApiCalls
        loader_on_apply_group_page = loader_on_apply_group_page ||
            (this.props.ApiCalls.getTests || this.props.ApiCalls.loadingFor == "tests")
        const { LoginDetails } = this.props.Authentication;

        const Nav = this.props.Universal.NavigationByHeaderSelection

        const { MoveStudent, GroupingStrandOrStandard, GroupingList, sortOptions, pagination, GroupingPages, Pages_And_Count } = GroupPage

        const { currentPageNumber, countPerPage, totalPageCount, bubbleLeft,
            bubbleRight } = pagination

        const { MovedStudentFromGroupDetails } = MoveStudent

        const { NavLeftCount, NavRightCount } = GroupingStrandOrStandard

        const { selectedStrands_Final, SelectedStandards } = AppliedChanges

        const StrandsorStrandardsList = selectedStrands_Final;

        const TotalGroupingList = GroupingList;

        let Pagination = CalculatePagination_Bubble_Start_End(Pages_And_Count, pagination)

        let standardsList = []
        let ShowStrandsorStandards = []
        let ShowGroups = []
        let ShowGroupNumber = []

        let strands = StrandsorStrandardsList.slice(NavLeftCount, NavRightCount);
        SelectedStandards.length != 0 ? SelectedStandards.map((loop) =>
            (StrandsorStrandardsList.map((stan, i) => (
                stan.standards.map((stands) => (
                    loop == stands.standardId ? standardsList.push(stands) : null
                ))
            )))) : null

        ShowStrandsorStandards = StrandsorStrandardsList.length > 1 ? strands : standardsList.length > 0 ? standardsList.slice(NavLeftCount, NavRightCount) : null

        const { pageStart, pageEnd } = pageParamsForDisplay(currentPageNumber, countPerPage, Pages_And_Count)
        let totalBubbles = paginationUIDisplay(totalPageCount, countPerPage)
        let pageSlicedUIArray = pagedArrayForUIDisplay(totalBubbles, bubbleLeft, bubbleRight);


        let Pages_And_Count_ = Pages_And_Count.slice(bubbleLeft, bubbleRight)

        let currentPageData = GroupingPages.slice(pageStart, pageEnd);
        let CurrentPagBubbleData = Pages_And_Count[currentPageNumber - 1];
        CurrentPagBubbleData = CurrentPagBubbleData == undefined ? {} : CurrentPagBubbleData;
        let Group_indx_Start = CurrentPagBubbleData.Group_indx_Start;
        let Group_indx_End = CurrentPagBubbleData.Group_indx_End;

        currentPageData = GroupPage.GroupingList.length != 0 ?
            Pages_And_Count.length == 1 ? GroupPage.GroupingList :
                GroupPage.GroupingList.slice(Group_indx_Start, Group_indx_End) :
            [];

        // if (currentPageData.length > 0) {

        //     currentPageData.map((item, i) => {
        //         let Obj = { groupNo: Group_indx_Start + 1, stdArray: item };
        //         currentPageData[i] = Obj
        //     })

        // }


        // currentPageData = this.MadeGroupsByParams(currentPageData, 'presentGroup');


        MoveStudent.StudentMovedFlag ? SortedGroups.map((PageIndexArray, pageIndex) => {
            PageIndexArray.map((singleGroup) => {
                singleGroup.map(studentArray => {
                    if (studentArray.studentId == MovedStudentFromGroupDetails.StudentId) {
                        this.onClickBubble(pageIndex),
                            this.props.moveStudentConfirmation()
                    }
                })
            })
        }) : null;

        // let LengthStrandAndStandards = GroupPage.LengthStrandAndStandards

        let showArrows = StrandsorStrandardsList.length > 1 ? GroupPage.LengthStrandAndStandards > 5 ? true : false : GroupPage.LengthStrandAndStandards > Nav_strands_Count_perPage_ ? true : false

        //IR realted stup started

        let View = this.props.ClassGroupingReducer.GroupTaxonomyTab.SelectedTaxonomy ? this.props.ClassGroupingReducer.GroupTaxonomyTab.SelectedTaxonomy : "";
        const { SetValues } = this.props.ClassGroupingReducer ? this.props.ClassGroupingReducer : "";
        let Grade = AppliedChanges.Grade.grade ? convertToNumberGrade(AppliedChanges.Grade.grade) : "";

        let Set = Object.values(SetValues)
        let SetId = (Set.length > 0) ? Set.map(setvalues => {
            if (setvalues.taxonomy === View) {
                return setvalues.setId;
            }
        }) : "";
        let IR_StrandList = [];
        SetId = (SetId.length > 0) ? SetId.filter(function (element) {
            return element !== undefined;
        }) : SetId

        StrandsorStrandardsList.map(strand => {
            if (strand.check) {
                IR_StrandList.push(strand.strandName)
            }
        });
        IR_StrandList = IR_StrandList.map(function (e) { return SetId + "~" + e });

        let strandNames = (IR_StrandList.length > 0) ? IR_StrandList.join(",,") : [];
        let standardNames = (SelectedStandards.length > 0) ? SelectedStandards.join(",") : [];

        //IR realted stup ends

        return (
            <div>

                {openGroupPopUp && Nav.class ? <GroupingPopup /> : null}
                {MoveStudent.MoveStudentGroupPopup ?
                    <MoveStudentGroup
                        GroupIndex={MovedStudentFromGroupDetails.GroupIndex}
                        StudentIndex={MovedStudentFromGroupDetails.StudentIndex}
                        StudentName={MovedStudentFromGroupDetails.StudentName}
                        StudentId={MovedStudentFromGroupDetails.StudentId}
                        SortedGroups={SortedGroups}
                    />
                    : null}
                {GroupPage.GroupingList.length != 0 || loader_on_apply_group_page ?
                    <div className="bec_group_tab_main">
                        <div className="bec_group_tab_inr">
                            <div className="bec_group_tab_inr_main">
                                <div className="bec_group_tab_header_block">
                                    {/* bec_group_tab */}
                                    <div className="bec_group_tab_filter">
                                        <div className="bec_group_tab_filter_inr">
                                            <div className="bec_group_tab_group_label">
                                                <div className="bec_groups_tab_row_label">
                                                    <span>Group by </span>
                                                    <span className="bec_groups_tab_tooltip">
                                                        <i className="material-icons-outlined">
                                                            info
                                </i>
                                                        <div className="bec_groups_tab_tooltip_main">
                                                            <span className="bec_groups_tab_tooltip_arrow" />
                                                            <div className="bec_groups_tab_tooltip_inr">
                                                                <div className="bec_groups_tab_tooltip_title">
                                                                    Group By
                                    </div>
                                                                <div className="bec_groups_tab_tooltip_body">
                                                                    <div className="bec_groups_tab_tooltip_single_line">
                                                                        <b>Cluster</b>: Students are grouped by common strengths and weaknesses on the selected standards. Groups are not necessarily equal size.
                                    </div>
                                                                    <div className="bec_groups_tab_tooltip_single_line">
                                                                        <b>Average</b>: Groups of equal size are created based on students' average score across the selected standards.
                                    </div>
                                                                    <div className="bec_groups_tab_tooltip_single_line">
                                                                        <b>High-Low</b>: Students with the highest and lowest overall average scores across the selected standards are grouped together.
                                    </div>
                                                                    <div className="bec_groups__tab_tooltip_single_line">
                                                                        <b>Note:</b> All Grouping Strategies are based on the following average score calculation for each student/standard in the table below: (earned points/total points)*100</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="bec_group_tab_group_filter_thing">
                                                <div className="bec_groups_popup_modal_row_radio_buttons">
                                                    <ul>
                                                        <li className={AppliedChanges.GroupBy == 'CLUSTERING' ? "activeGroupPopupRadio" : null} 
                                                        onClick={() => AppliedChanges.GroupBy == 'CLUSTERING'? null: this.handleGroupByParam('CLUSTERING')}
                                                        >
                                                            <span className="bec_groups_popup_modal_radio">
                                                                <div className="bec_groups_popup_modal_radio_inr" />
                                                            </span>
                                                            <span className="bec_groups_popup_modal_radio_label">
                                                                Cluster
                                </span>
                                                        </li>
                                                        <li className={AppliedChanges.GroupBy == 'AVERAGE' ? "activeGroupPopupRadio" : null} 
                                                        onClick={() => AppliedChanges.GroupBy == 'AVERAGE' ? null:
                                                         this.handleGroupByParam('AVERAGE')}>
                                                            <span className="bec_groups_popup_modal_radio">
                                                                <div className="bec_groups_popup_modal_radio_inr" />
                                                            </span>
                                                            <span className="bec_groups_popup_modal_radio_label">
                                                                Average
                                </span>
                                                        </li>
                                                        <li className={AppliedChanges.GroupBy == 'HIGH_LOW' ? "activeGroupPopupRadio" : null}
                                                         onClick={() => AppliedChanges.GroupBy == 'HIGH_LOW' ? null: this.handleGroupByParam('HIGH_LOW')}>
                                                            <span className="bec_groups_popup_modal_radio">
                                                                <div className="bec_groups_popup_modal_radio_inr" />
                                                            </span>
                                                            <span className="bec_groups_popup_modal_radio_label">
                                                                High-Low
                                </span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* bec_group_header */}
                                    <div className="bec_group_tab_header_block_tools">
                                        <div className="bec_group_tab_header_block_edit_label" onClick={
                                            () =>
                                                loader_on_apply_group_page ? null : this.props.EditClassGrouping()
                                        }>
                                            <span >
                                                <i className="material-icons" style={{ color: '#00539b' }}>
                                                    create
                            </i>
                                            </span>
                                            <span>Edit Groups</span>
                                        </div>
                                        {/* <div className="bec_group_tab_header_block_print_label"> */}
                                        <span className="print_pdf_icon" style={{ float: 'right' }}>
                                            {loader_on_apply_group_page ? <span className="printIcon"><img src={printIco} width="21" /></span> : <GroupingPagePrint
                                                StrandsorStrandardsList={StrandsorStrandardsList}
                                                standardsList={standardsList}
                                                ShowStrandsorStandards={ShowStrandsorStandards}
                                                TotalGroupingList={TotalGroupingList}
                                                HeaderDetails={this.props.ContextHeader}
                                                AppliedChanges={AppliedChanges.GroupBy}
                                                sortOptions={sortOptions}
                                            />}
                                        </span>
                                        {/* </div> */}
                                    </div>
                                </div>
                                {/* bec_group_multi_list */}
                                <div className="bec_group_multi_list">
                                    <div className="bec_group_multi_list_inr">

                                        {loader_on_apply_group_page ? <LoadingScreen /> :

                                            <div className="bec_group_multi_list_main">
                                                {/* header */}
                                                <div className="bec_group_multi_list_header">
                                                    <div className="bec_group_multi_list_header_label">
                                                        <span style={{ float: "left" }}>
                                                            {StrandsorStrandardsList.length > 1 ? "Strands" : StrandsorStrandardsList.length != 0 ? StrandsorStrandardsList[0].strandName : null}
                                                        </span>

                                                        <IR_Bulb_Top ir_bulb_icon={LoginDetails.ReportingAccessParam} view={SetId} grade={Grade} strand={strandNames} standard={standardNames} />
                                                    </div>
                                                    <div className={GroupingStrandOrStandard.NavLeftCount == 0 ? "bec_group_multi_list_header_left_arrow bec_group_multi_list_header_arrow_disable" : "bec_group_multi_list_header_left_arrow bec_group_multi_list_header_arrow_enable"}>
                                                        <i className="material-icons" style={{ cursor: 'pointer', visibility: showArrows ? "visible" : "hidden" }}
                                                            onClick={GroupingStrandOrStandard.NavLeftCount > 0 ? () => this.handleArrowClick(GroupingStrandOrStandard.NavLeftCount, GroupingStrandOrStandard.NavRightCount, 'left') : null}
                                                        > chevron_left </i>
                                                    </div>
                                                    <div className="bec_group_multi_list_header_strands_list">
                                                        {StrandsorStrandardsList.length > 1 ? ShowStrandsorStandards.map((value) => (
                                                            <div className="bec_group_multi_list_header_strands_single">
                                                                {value.strandName}
                                                            </div>
                                                        )) : ShowStrandsorStandards.map((value, i) => (
                                                            // value.standards.map((names) => (
                                                            <div key={i} className="bec_group_multi_list_header_strands_single">

                                                                <span class="bec_groups_tab_tooltip">
                                                                    {value.standardName}
                                                                    <div class="bec_groups_tab_tooltip_main_descr">
                                                                        <span class="bec_groups_tab_tooltip_arrow_desc"></span>
                                                                        <div class="bec_groups_tab_tooltip_inr">

                                                                            <div class="bec_groups_tab_tooltip_body">
                                                                                <div class="bec_groups_tab_tooltip_single_line">
                                                                                    <div className="bec_groups_tab_tooltip_single_line_head">{value.standardId}</div>
                                                                                    {value.standardDef == null || value.standardDef === "" || value.standardDef === "null" ? null : <div className="bec_groups_tab_tooltip_single_line_head">{value.standardDef}</div>}
                                                                                    <b>{value.standardShortValue}</b>: {value.standardDesc}
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </span>

                                                            </div>
                                                            //  ))
                                                        ))}

                                                    </div>
                                                    <div className={GroupingStrandOrStandard.NavRightCount < GroupPage.LengthStrandAndStandards ? "bec_group_multi_list_header_left_arrow bec_group_multi_list_header_arrow_enable" : "bec_group_multi_list_header_left_arrow bec_group_multi_list_header_arrow_disable"}>
                                                        <i className="material-icons" style={{ cursor: 'pointer', visibility: showArrows ? "visible" : "hidden" }}
                                                            onClick={GroupingStrandOrStandard.NavRightCount < GroupPage.LengthStrandAndStandards ? () => this.handleArrowClick(GroupingStrandOrStandard.NavLeftCount, GroupingStrandOrStandard.NavRightCount, 'right') : null}
                                                        > chevron_right </i>
                                                    </div>
                                                </div>
                                                <div className="bec_group_multi_list_sub_header">
                                                    <div className="bec_group_multi_list_sub_header_label">
                                                        <span className="bec_group_multi_list_sub_header_label_title">Groups({GroupPage.GroupingList.length}) / Students({GroupPage.TotalNumberOfStudents})</span>
                                                        <span className="bec_group_multi_list_toggler">
                                                            <span
                                                                className={sortOptions.ParamOnwhichScore == "lastName" && sortOptions.orderOfSort == "ASC" ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top"}
                                                                onClick={
                                                                    () => this.handleSortingGroups("lastName", StrandsorStrandardsList.length > 1 ? "strands" : "standards", 'nomatter', "ASC")
                                                                }>
                                                                <i className="material-icons">
                                                                    expand_less
                                        </i>
                                                            </span>
                                                            <span
                                                                className={sortOptions.ParamOnwhichScore == "lastName" && sortOptions.orderOfSort == "DSC" ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom"}
                                                                onClick={
                                                                    () => this.handleSortingGroups("lastName", StrandsorStrandardsList.length > 1 ? "strands" : "standards", 'nomatter', "DSC")
                                                                }>
                                                                <i className="material-icons">
                                                                    expand_more
                                        </i>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div className="bec_group_multi_list_sub_header_avg_score">
                                                        <span className="bec_group_multi_list_sub_header_avg_score_label">
                                                            Average % Score
                                    <span>
                                                                (based on selections)
                                    </span>
                                                        </span>
                                                        <span className="bec_group_multi_list_toggler">
                                                            <span
                                                                className={sortOptions.ParamOnwhichScore == "studentPercentage" && sortOptions.orderOfSort == "ASC" ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top"}
                                                                onClick={
                                                                    () => this.handleSortingGroups("studentPercentage", "nomatter", 'nomatter', "ASC")
                                                                }>
                                                                <i className="material-icons">
                                                                    expand_less
                                            </i>
                                                            </span>
                                                            <span
                                                                className={sortOptions.ParamOnwhichScore == "studentPercentage" && sortOptions.orderOfSort == "DSC" ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom"}
                                                                onClick={
                                                                    () => this.handleSortingGroups("studentPercentage", "nomatter", 'nomatter', "DSC")
                                                                }>
                                                                <i className="material-icons">
                                                                    expand_more
                                            </i>
                                                            </span>
                                                        </span>
                                                    </div>
                                                    <div className="bec_group_multi_list_sub_header_strands_list">
                                                        {StrandsorStrandardsList.length > 1 ? ShowStrandsorStandards.map((value, i) => (

                                                            <div key={i} className="bec_group_multi_list_sub_header_strands_single">
                                                                <div className="bec_group_multi_list_sub_header_strands_single_sort">
                                                                    <span className="bec_group_multi_list_toggler">
                                                                        <span className={sortOptions.Strand_Standard == value.strandName && sortOptions.orderOfSort == "ASC" ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top"}
                                                                            onClick={
                                                                                () => this.handleSortingGroups("standardAndStrandAvg", "strands", value.strandName, "ASC")
                                                                            }>
                                                                            <i className="material-icons">
                                                                                expand_less
                                                </i>
                                                                        </span>
                                                                        <span
                                                                            className={sortOptions.Strand_Standard == value.strandName && sortOptions.orderOfSort == "DSC" ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom"}
                                                                            onClick={
                                                                                () => this.handleSortingGroups("standardAndStrandAvg", "strands", value.strandName, "DSC")
                                                                            }>
                                                                            <i className="material-icons">
                                                                                expand_more
                                                </i>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        )) : ShowStrandsorStandards.map((value, i) => (
                                                            // value.standards.map((names) => (

                                                            <div key={i} className="bec_group_multi_list_sub_header_strands_single">
                                                                <div className="bec_group_multi_list_sub_header_strands_single_sort">
                                                                    <span className="bec_group_multi_list_toggler">
                                                                        <span
                                                                            className={sortOptions.Strand_Standard == value.standardId && sortOptions.orderOfSort == "ASC" ? "bec_group_multi_list_toggler_top active_group_sort" : "bec_group_multi_list_toggler_top"}
                                                                            onClick={
                                                                                () => this.handleSortingGroups("standardAndStrandAvg", "standards", value.standardId, "ASC")
                                                                            }>
                                                                            <i className="material-icons">
                                                                                expand_less
                                                    </i>
                                                                        </span>
                                                                        <span
                                                                            className={sortOptions.Strand_Standard == value.standardId && sortOptions.orderOfSort == "DSC" ? "bec_group_multi_list_toggler_bottom active_group_sort" : "bec_group_multi_list_toggler_bottom"}
                                                                            onClick={
                                                                                () => this.handleSortingGroups("standardAndStrandAvg", "standards", value.standardId, "DSC")
                                                                            }>
                                                                            <i className="material-icons">
                                                                                expand_more
                                                    </i>
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>


                                                            //  ))
                                                        ))}
                                                    </div>
                                                </div>
                                                {/* header end */}
                                                {/* body */}
                                                <div className="bec_group_multi_list_body">
                                                    {/* <Scrollbars autoHeight autoHeightMin={0} autoHeightMax={450}> */}
                                                    {/* Single Group */}
                                                    {currentPageData.map((StudentNameArray, i) => {
                                                        // let indx = i +1;
                                                        // indx = indx == 0 ? 1 : indx;
                                                        // let StudentNameArray = item.stdArray == undefined ? []: ;
                                                        let groupNo = Group_indx_Start + i + 1;
                                                        return <div className="bec_group_multi_list_Single_group">
                                                            <div className="bec_group_multi_list_Single_group_header">
                                                                Group {groupNo} <span>({StudentNameArray.length} Students)</span>
                                                            </div>
                                                            <div className="bec_group_multi_list_Single_group_body">
                                                                {
                                                                    StudentNameArray.map((Values, j) => (
                                                                        <div key={j} className={
                                                                            Values.studentId == MovedStudentFromGroupDetails.StudentId && (Values.presentGroup !== Values.previousGroup) ? "bec_group_multi_list_Single_group_body_row StudentHightlightClass" : "bec_group_multi_list_Single_group_body_row"
                                                                        } >
                                                                            <div className="bec_group_multi_list_Single_group_body_row_student_name">
                                                                                <span className="bec_group_multi_list_Single_group_body_row_student_flag_status" style={(Values.presentGroup == Values.previousGroup) || (Values.presentGroup == Values.parentGroup) ? { visibility: 'hidden' } : { visibility: 'visible' }}>
                                                                                    <i className="material-icons">flag</i>
                                                                                    <div class="bec_groups_tab_tooltip_strand_score_main_descr" style={{ left: '-8px' }}>
                                                                                        <span class="bec_groups_tab_tooltip_strand_score_arrow_desc" style={{ visibility: "visible", bottom: "-18px", left: "14px" }}></span>
                                                                                        <div class="bec_groups_tab_tooltip_strand_score_inr">
                                                                                            <div class="bec_groups_tab_tooltip_strand_score_body">
                                                                                                <div class="bec_groups_tab_tooltip_strand_score_single_line">
                                                                                                    Student Moved From {Values.parentGroup + 1} Group
                                                                                        </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </span>
                                                                                <span className="bec_group_multi_list_Single_group_body_row_student_name_Name">
                                                                                    {Values.firstName + " " + Values.lastName}</span>
                                                                                {GroupingPages.length > 1 && TotalGroupingList.length > 1 ? <span className="bec_group_multi_list_Single_group_body_row_student_swap"
                                                                                    onClick={() => this.handleMoveStudent(groupNo - 1, j, Values.firstName + " " + Values.lastName, Values.studentId, Values)}>
                                                                                    <i className="material-icons">swap_vert</i>
                                                                                    <div class="bec_groups_tab_tooltip_strand_score_main_descr" style={{ left: '-8px' }}>
                                                                                        <span class="bec_groups_tab_tooltip_strand_score_arrow_desc" style={{ visibility: "visible", bottom: "-18px", left: "14px" }}></span>
                                                                                        <div class="bec_groups_tab_tooltip_strand_score_inr">
                                                                                            <div class="bec_groups_tab_tooltip_strand_score_body">
                                                                                                <div class="bec_groups_tab_tooltip_strand_score_single_line">
                                                                                                    Move student to a different group.
                                                                                        </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </span> : null}
                                                                            </div>

                                                                            <div className="bec_group_multi_list_Single_group_body_row_avg_score">

                                                                                <span className={this.colorCodes(Values.studentPercentage)}>
                                                                                    {Values.studentPercentage}</span>

                                                                            </div>

                                                                            <div className="bec_group_multi_list_Single_group_body_row_strand_score_list">
                                                                                {StrandsorStrandardsList.length > 1

                                                                                    ? ShowStrandsorStandards.map((loop, index) => (
                                                                                        Values.standardAndStrandVODetails.map((strands, k) => (
                                                                                            loop.strandName == strands.standardAndStrandName ? (<div key={k} className="bec_group_multi_list_Single_group_body_row_strand_score">
                                                                                                <div className="bec_group_single_score_inr_middle">
                                                                                                    <span className={strands.standardAndStrandAvg != null ? this.colorCodes(strands.standardAndStrandAvg) : "bec_group_multi_list_grey"}>
                                                                                                        <div class="bec_groups_tab_tooltip_strand_score">
                                                                                                            {strands.standardAndStrandAvg != null ? strands.standardAndStrandAvg : '-'}
                                                                                                            <div class="bec_groups_tab_tooltip_strand_score_main_descr"
                                                                                                                style={
                                                                                                                    index >= 2 ? strands.standardAndStrandAvg != null ? { left: "-180px" } : { left: "-80px", minWidth: '110px' } : null}>
                                                                                                                <span class="bec_groups_tab_tooltip_strand_score_arrow_desc"
                                                                                                                    style={
                                                                                                                        index >= 2 ? strands.standardAndStrandAvg != null ? { left: "182px" } : { left: "82px" } : null}
                                                                                                                ></span>
                                                                                                                <div class="bec_groups_tab_tooltip_strand_score_inr">

                                                                                                                    <div class="bec_groups_tab_tooltip_strand_score_body">
                                                                                                                        <div class="bec_groups_tab_tooltip_strand_score_single_line">
                                                                                                                            {strands.standardAndStrandAvg != null ? `Number of Questions Assessed:${strands.noOfQuestions}` : 'No Data Available'}
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </span>
                                                                                                </div>
                                                                                            </div>) : null))))

                                                                                    : ShowStrandsorStandards.map((loop, index) => (
                                                                                        Values.standardAndStrandVODetails.map((strands, k) => (
                                                                                            loop.standardId == strands.standardAndStrandName ?
                                                                                                (<div key={k} className="bec_group_multi_list_Single_group_body_row_strand_score">
                                                                                                    <div className="bec_group_single_score_inr_middle">
                                                                                                        <span className={strands.standardAndStrandAvg != null ? this.colorCodes(strands.standardAndStrandAvg) : "bec_group_multi_list_grey"}>
                                                                                                            <div class="bec_groups_tab_tooltip_strand_score">
                                                                                                                {strands.standardAndStrandAvg != null ? strands.standardAndStrandAvg : '-'}
                                                                                                                <div class="bec_groups_tab_tooltip_strand_score_main_descr"
                                                                                                                    style={
                                                                                                                        index >= 2 ? strands.standardAndStrandAvg != null ? { left: "-180px" } : { left: "-80px", minWidth: '110px' } : null}>
                                                                                                                    <span class="bec_groups_tab_tooltip_strand_score_arrow_desc"
                                                                                                                        style={
                                                                                                                            index >= 2 ? strands.standardAndStrandAvg != null ? { left: "182px" } : { left: "82px" } : null}
                                                                                                                    ></span>
                                                                                                                    <div class="bec_groups_tab_tooltip_strand_score_inr">

                                                                                                                        <div class="bec_groups_tab_tooltip_strand_score_body">
                                                                                                                            <div class="bec_groups_tab_tooltip_strand_score_single_line">
                                                                                                                                {strands.standardAndStrandAvg != null ? `Number of Questions Assessed:${strands.noOfQuestions}` : 'No Data Available'}
                                                                                                                            </div>
                                                                                                                        </div>
                                                                                                                    </div>
                                                                                                                </div>
                                                                                                            </div>

                                                                                                        </span>
                                                                                                    </div>
                                                                                                </div>) : null
                                                                                        ))
                                                                                    ))
                                                                                }
                                                                            </div>
                                                                            <div className="bec_group_multi_list_Single_group_body_row_strand_score">
                                                                            </div>
                                                                        </div>

                                                                    ))}
                                                            </div>
                                                        </div>
                                                    })}

                                                    {/* Single Group End */}
                                                    {/* </Scrollbars> */}
                                                </div>

                                                {/* body end */}
                                            </div>
                                        }
                                    </div>
                                </div>
                            </div>

                            {/* Pagination Starts here */}
                            {loader_on_apply_group_page ? null : <div className="PaginationBlock"
                                style={totalBubbles.length > 1 ? { visibility: 'visible' } : { visibility: 'hidden' }}
                            >

                                <div className="GroupingPagePaginationBlock mx-auto" style={{ width: '430px' }}>
                                    <span
                                        className={bubbleLeft <= 0 ? "scroll-left float-left scroll-disable " : "scroll-left float-left scroll-active "}
                                        style={totalBubbles.length > 3 ? { visibility: 'visible' } : { visibility: 'hidden' }}
                                        onClick={() => {
                                            bubbleLeft <= 0 ? null :
                                                this.props.handlePaginationClick_Navigation("left")
                                        }}>
                                        <i className="material-icons">chevron_left</i>
                                    </span>

                                    <div style={{ float: 'left', maxWidth: '300px', width: '100%' }}>
                                        <div className="table-and-graph-pagination-inr" >
                                            <ul className="page-circle-list">
                                                {pageSlicedUIArray.map((singleBubble, i) => (
                                                    <li
                                                        className={pagination.currentPageNumber == (singleBubble.number + 1) ? "activeLi" : ""}
                                                        onClick={() => pagination.currentPageNumber != (singleBubble.number + 1) ? this.handlePageDisplay(singleBubble.number + 1) : null}>
                                                        <span>
                                                            {singleBubble.number}
                                                        </span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                        <div style={{ display: 'flex', margin: '0 auto', alignItems: 'center', width: '300px' }}>
                                            <ul className="page-numbers-list">
                                                {pageSlicedUIArray.map((singleBubble, i) => (
                                                    <li
                                                        style={{ width: "60px" }}
                                                        className={i == 0 || i == 2 ? "text-center" : "text-left"}
                                                    >
                                                        <span className="page-numbers">
                                                            {/* {singleBubble.bottomNumbers} */}
                                                            {returnBubbleCount(Pages_And_Count_, i)}
                                                        </span>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>

                                    <span
                                        className={bubbleRight >= totalBubbles.length ? "scroll-right float-right scroll-disable " : "scroll-right float-right scroll-active "}
                                        style={totalBubbles.length > 3 ? { visibility: 'visible' } : { visibility: 'hidden' }}
                                        onClick={() => bubbleRight >= totalBubbles.length ? null :
                                            this.props.handlePaginationClick_Navigation("right")
                                        }
                                    >
                                        <i className="material-icons">chevron_right</i>
                                    </span>

                                </div>
                            </div>}
                            {/* Pagination Starts here */}

                        </div>
                    </div> : null}

            </div>
        );
    }
}

const MapStateToProps = ({ ClassGroupingReducer, Universal, Authentication }) => {
    const { ContextHeader, ApiCalls, AchivementLevels } = Universal;
    // const {G_ApiCalls} = 
    return {
        ClassGroupingReducer, Universal, Authentication, ContextHeader, ApiCalls, AchivementLevels
    }
}

export default connect(MapStateToProps, {
    GroupingPagedDisplay,
    EditClassGrouping,
    GroupPage_SS_Nav,
    GroupPageMoveStudent,
    ClassGroupBy,
    ApplyGroupPopup,
    onClickBubbleGrouping,
    SortGroupsBasedOnParam,
    moveStudentConfirmation,
    handlePaginationClick_Navigation,
    trackingUsage
})(c_sp_grouping);
export function pagedArrayForUIDisplay(totalBubbles, UIStartDisplay, UIEndtDisplay) {

    let PageUIArray = totalBubbles.slice(UIStartDisplay, UIEndtDisplay)

    return PageUIArray

}


function returnBubbleCount(Arr, inx) {

    function ReturnValid(obj) {
        return obj == undefined || obj == null ? {} : obj
    }
    let Current = Arr[inx];

    if (Current == undefined || Current == null) {
        return ''
    } else {
        Current.start = Current.start == 0 ? 1 : Current.start;
        return Current.start + ' - ' + Current.end;
    }

    // let Current = ReturnValid(Arr[inx]);
    // let prev = ReturnValid(Arr[inx - 1]);
    // let Next = ReturnValid(Arr[inx + 1]);
    // if (inx == 0) {
    //     return "0 - " + Current.stds
    // } else if (Current !== undefined) {
    //     return (prev.stds + 1) + " - " + (prev.stds + Current.stds);
    // } else return null

}

export function pageParamsForDisplay(currentPageNumber, countPerPage, Pages_And_Count) {
    let pageStart = 0;
    let pageEnd = 0;

    let Current = Pages_And_Count[currentPageNumber - 1];
    if (Current == undefined || Current == null) {
        return {
            pageStart,
            pageEnd
        }
    } else {
        pageStart = Current.start;
        pageEnd = Current.end
        return {
            pageStart,
            pageEnd
        }
    }

    if (currentPageNumber == 1) {
        pageStart = 0
        pageEnd = countPerPage
    } else {
        pageStart = (currentPageNumber - 1) * countPerPage
        pageEnd = (currentPageNumber - 1) * countPerPage + countPerPage
    }
    return {
        pageStart,
        pageEnd
    };
}

export function paginationUIDisplay(totalPageCount, countPerPage) {
    let totalBubbles = [];
    for (let index = 0; index < totalPageCount; index++) {
        let numberValue = index
        let numberStartValue;
        let numberEndValue

        if (index == 0) {
            numberStartValue = (numberValue + 1).toString()
            numberEndValue = (numberValue + countPerPage).toString()
        } else {
            numberStartValue = (numberValue * countPerPage + 1).toString()
            numberEndValue = (numberValue * countPerPage + countPerPage).toString()
        }

        let sinleBubble = {
            "number": numberValue,
            "bottomNumbers": numberStartValue + " - " + numberEndValue
        }
        totalBubbles.push(sinleBubble)
    }
    return totalBubbles;
}

function CalculatePagination_Bubble_Start_End(Pages_And_Count, pagination) {

    let FirstStart = 0, FirstEnd = 0, SecondStart = 0, SecondEnd = 0, ThirdStart = 0, ThirdEnd = 0;




}