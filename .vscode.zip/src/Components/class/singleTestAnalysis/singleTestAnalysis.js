import React, { Component } from 'react';
import { connect } from 'react-redux';

import ST_analysisPage from "../../../Utils/st_analysis/ST_analysisPage";
import { trackingUsage } from '../../../Redux_Actions/AuthenticationAction';

class c_st_analysis extends Component {
    componentDidMount(){
        this.props.trackingUsage("assessmentreports_singletestanalysis:class");
    }
    render() { 
        let singleTestAnalysisData = this.props.class_TestAnalysis
        let fromContext = 'class'
        return (
            <ST_analysisPage fromContext={fromContext} singleTestData={singleTestAnalysisData} /> 
        );
    }
}

const mapStateToProps = ({ Universal, Authentication, SingleTestAnalysis }) => {

    const { class_TestAnalysis } = SingleTestAnalysis

    return {
        Universal, Authentication, class_TestAnalysis
    }
}

const mapStateToDispatch = {
trackingUsage
}

export default connect(mapStateToProps,mapStateToDispatch)(c_st_analysis);
