import React, { Component } from "react";
import Chart from "../../Utils/LineChart/LineChart";
import ChartPagination from "../../Utils/LineChart/LineChartPagination";
import OverviewDetailHeader from "../TestScore/OverView/OverviewDetail/OverviewDetailHeader";
import OverviewDetailStudentList from "../TestScore/OverView/OverviewDetail/OverviewDetailStudentList";
import {
  Get_Class_TestScores_Over_Time,
  OpenOrCloseNoteIn_TS_OT,
  CheckCompareTabs,
  EnableOrDisableLineColorIn_LC,
  Get_Class_TestScores_Details,
} from "../../Redux_Actions/ReportsActions";
import {
  ParamsForStudentsListTable,
  LineChartInput_Params,
  GetIds_of_Each_Object_In_The_Array,
  RemoveDuplicateObjectsFromArray,
  AllClassesList,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compare,
  convertUTCDateToLocalDate,
} from "./../ReusableComponents/AllReusableFunctions";
import CompareCheckBoxes from "../../Utils/CompareCheckBoxes";
import { connect } from "react-redux";
import "./ClassMain.css";
import LoadingScreen from "../../Utils/LoadingScreen/LoadingScreen";
import TestScoreDetailListPDF from "../../Utils/PrintPDF/TestScoreDetailListPDF";
import printIco from "../../../public/images/ic_print_new.svg";
import info_icon from "../../../public/images/info_icon.svg";
import TestScoreOverTimePDF from "../../Utils/PrintPDF/TestScoreOverTimePDF";
import {
  ACHIEVEMENT_LEVELS_ENABLE,
  Disable_AutoSelect_TS_Overview_LeftView,
  DISPLAY_LOCAL_TIME_IN_UI,
} from "../../Utils/globalVars";
import Make_A_Selection_Msg from "../../Utils/Make_A_Selection";
import { trackingUsage } from "../../Redux_Actions/AuthenticationAction";
import { EnddateValues, StartdateValues } from "../../Utils/reUsableSnipets";
class c_ts_overview extends Component {
  constructor(props) {
    super(props);
    (this.InfoTooltipPopUp = {}),
      (this.i_span_tooltip_ref = {}),
      (this.state = {
        studentsData: [],
      });
    this.handleClickOutside_info = this.handleClickOutside_info.bind(this);
    this.SelectCompareOption = this.SelectCompareOption.bind(this);
    this.ClickOnLabelName = this.ClickOnLabelName.bind(this);
  }

  /**
   * Enable this when we need to show Info Icon At Test Scores Over Time.
   */
  componentDidMount() {
    this.Apicalls(this.props.ApiCalls.Get_Class_TestScores);

    document.addEventListener("mousedown", this.handleClickOutside_info);
    this.props.trackingUsage("assessmentreports_testscoresoverview:class");
  }

  componentWillUnmount() {
    document.removeEventListener("mousedown", this.handleClickOutside_info);
  }

  /**
   *
   * @param {Object} event
   * triggers when click on outside of info div At Test Scores Over Time Info Icon.
   */

  handleClickOutside_info(event) {
    if (event.target == null || event.target == undefined) {
      // this.handleMouseOut(this.props.ToolTipData);
    } else if (this.props.Test_Scores_OverTime.OpenInfoNote) {
      if (
        this.InfoTooltipPopUp !== null &&
        this.InfoTooltipPopUp !== undefined
      ) {
        let isitemexists = this.InfoTooltipPopUp.contains(event.target);
        let is_IExist = this.i_span_tooltip_ref.contains(event.target);
        let ToolTipsRefsExists;
        if (
          (isitemexists == undefined ||
            isitemexists == null ||
            isitemexists == false) &&
          (is_IExist == undefined || is_IExist == null || is_IExist == false)
        ) {
          // this.setState({ show_P_Overtime_Info: false })
          this.props.OpenOrCloseNoteIn_TS_OT(false, "T_Scores");
        }
      }
    }
  }

  /**
   *
   * @param {String} SelectedOption
   * this will trigger when  option is selected from CompareCheckBoxes.js component.
   */
  SelectCompareOption(SelectedOption, Check) {
    let SchoolData = this.props.Test_Scores_OverTime.Actual_School_LC_List;
    let SchoolDataChecked = this.props.Test_Scores_OverTime.checkSchool;
    let DistrictData = this.props.Test_Scores_OverTime.Actual_District_LC_List;
    let DistrictDataChecked = this.props.Test_Scores_OverTime.checkDistrict;
    // if (SelectedOption == 'School') {
    // SchoolData.length > 1 ? this.props.CheckCompareTabs('School',Check) : this.Apicalls(true,true,false);
    this.props.CheckCompareTabs(SelectedOption, Check);
    //   // this.props.CheckCompareTabs('School', Check);
    //    } else if (SelectedOption == 'District') {
    //   let DistrictData = this.props.Test_Scores_OverTime.Actual_District_LC_List;
    //   // this.props.CheckCompareTabs('District', Check);
    //   DistrictData.length > 1 ? this.props.CheckCompareTabs('District', Check) : this.Apicalls(true,false,true);
    //   this.props.CheckCompareTabs('District', Check)
    //  }
  }

  /**
   * when user click on checbox comp label, then it will execute
   */
  ClickOnLabelName(labelName, checkOrUncheck) {
    this.props.EnableOrDisableLineColorIn_LC(labelName, checkOrUncheck);
  }

  /**
   *
   * @param {Boolean} shoulddoApiCall
   * @paaram {Boolean} isSchool ,
   * @param {Boolean} isDistrict
   * if param is true then will make api call to
   */
  Apicalls(shoulddoApiCall, isSchool, isDistrict) {
    if (shoulddoApiCall) {
      let AccessToken = this.props.LoginDetails.JWTToken;
      let Context_Header = this.props.ContextHeader;
      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTests = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );
      if(SelectedTests == undefined || SelectedTests.length == 0){
        Selected_List = this.props.UniversalSelecter.TestTab.TestList.filter(item => item.check)
        SelectedTests = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
    }
      let SelectedStudents = Context_Header.Roster_Tab.StudentIds;

      let Dist_id = Context_Header.Roster_Tab.SelectedDistrict.id;

      Dist_id =
        Dist_id == undefined || Dist_id == null
          ? Context_Header.Default_districtID
          : Dist_id;
      const AllClassesList_ = AllClassesList(
        Context_Header.Roster_Tab.ClassList
      );

      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      let Compare_Std_Ids =
        SchoolStds == undefined || SchoolStds == null
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));

      if (Compare_Std_Ids.length == 0) {
        let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }
      let currentTermId = this.props.currentTermID;

      const { UniversalSelecter,Context_DateTab } = this.props;
      let classId = Context_Header.Roster_Tab.SelectedClass.id;
      let startDate = Context_Header.Date_Tab.Report_termStartDate;
      let endDate = Context_Header.Date_Tab.Report_termEndDate;
      let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
  
      if (classId == undefined) {
        classId = UniversalSelecter.Roster_Data.SelectedClass.id;
      }
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(Context_DateTab);
      }
  
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      let Req_Payload = {
        studentIds: SelectedStudents,
        classId: classId,
        classIds: AllClassesList_,
        schoolId: schoolId,
        componentCodeList: SelectedTests,
        districtId: Dist_id,
        startDate: startDate,
        endDate: endDate,
        // "grade": Context_Header.selectedRosterGrade,
        isClass: true,
        isSchool: true,
        isDistrict: true,
        compareStudentIds: Compare_Std_Ids,
        rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
        isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id,
        isCustomAchievements: ACHIEVEMENT_LEVELS_ENABLE,
      };
      let Enableload = true;
      Req_Payload.districtId == "" ||
      Req_Payload.districtId == null ||
      Req_Payload.schoolId == "" ||
      Req_Payload.schoolId == null ||
      Req_Payload.classId == "" ||
      Req_Payload.classId == null
        ? null
        : Context_Header.TestTab.TestList !== undefined &&
          Context_Header.TestTab.TestList.length > 0
        ? this.props.Get_Class_TestScores_Over_Time(
            AccessToken,
            Req_Payload,
            Enableload
          )
        : null;
    }
  }
  componentDidUpdate() {
    this.Apicalls(this.props.ApiCalls.Get_Class_TestScores);

    this.GetRightSideData();
  }

  /**
   * when user select any test from c_ts_overview component will make this api call to get test details
   */
  GetRightSideData() {
    if (
      this.props.ApiCalls_Reports.get_TS_Details &&
      !this.props.ApiCalls.Get_Class_TestScores
    ) {
      let Test;

      let listlength =
        this.props.Test_Scores_OverTime.ActualLineChartList.length;

      if (
        this.props.ToolTipData.tooltipData === null ||
        this.props.ToolTipData.tooltipData === undefined
      ) {
        Test =
          this.props.Test_Scores_OverTime.ActualLineChartList[listlength - 1];
      } else {
        Test = this.props.ToolTipData.tooltipData;
      }

      let ClassStrandsObject = this.props.StandardPerformance_Overview;
      let ContextHeader = this.props.ContextHeader;
      let Token = this.props.LoginDetails.JWTToken;
      const AllClassesList_ = AllClassesList(
        ContextHeader.Roster_Tab.ClassList
      );

      let SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      let Compare_Std_Ids =
        SchoolStds == undefined || SchoolStds == null
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));

      if (Compare_Std_Ids.length == 0) {
        let Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }
      let currentTermId = this.props.currentTermID;

      let classId = ContextHeader.Roster_Tab.SelectedClass.id;
      let startDate = ContextHeader.Date_Tab.Report_termStartDate;
      let endDate = ContextHeader.Date_Tab.Report_termEndDate;
      let districtId = ContextHeader.DistrictId;
      let schoolId = ContextHeader.Roster_Tab.SelectedSchool.id;
      const { UniversalSelecter,Context_DateTab } = this.props;
    
      if (startDate == undefined || startDate == "") {
        startDate = StartdateValues(Context_DateTab);
      }
      if (endDate == undefined || endDate == "") {
        endDate = EnddateValues(Context_DateTab);
      }
      if (districtId == undefined) {
        districtId = ContextHeader.Default_districtID;
      }
      if (schoolId == undefined) {
        schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
      }
      
      if (classId == undefined) {
        classId = UniversalSelecter.Roster_Data.SelectedClass.id;
      }
  


      let Req_Payload = {
        studentIds: ContextHeader.Roster_Tab.StudentIds,
        classId: classId,
        classIds: AllClassesList_,
        grade: ContextHeader.Roster_Tab.selectedRosterGrade,
        schoolId: schoolId,
        startDate: startDate,
        endDate: endDate,
        componentCode: Test.componentCode,
        districtId: ContextHeader.DistrictId,
        rosterGrade: ContextHeader.Roster_Tab.selectedRosterGrade,
        isClass: true,
        isSchool: true,
        isDistrict: true,
        compareStudentIds: Compare_Std_Ids,
        isPastDistrictTerm: ContextHeader.Date_Tab.isPastDistrictTerm,
        currentTermId: currentTermId, // datetab api response first alpha term_id
        isCustomAchievements: ACHIEVEMENT_LEVELS_ENABLE,
      };
      let enableLoading = true;
      let dontPersistforStudent = true;
      this.props.Get_Class_TestScores_Details(
        Token,
        Req_Payload,
        Test,
        enableLoading,
        dontPersistforStudent
      );
    }
  }

  render() {
    let Test_Scores_Details = this.props.StudentsListTable.ActualList;
    //took values from c_sp_overview
    let GraphPagination =
      this.props.StandardPerformance_Overview.LineChart_Pagination;
    let PerformanceFilter =
      this.props.StandardPerformance_Overview.StandardPerformanceFilter;
    let selectedTestAssessment;
    let selectedTestGrade;
    selectedTestAssessment =
      PerformanceFilter.TestAssessment.selectedTestAssessment;
    selectedTestGrade =
      PerformanceFilter.TestGrade.selectedTestgrade == "" ||
      PerformanceFilter.TestGrade.selectedTestgrade == null
        ? ""
        : PerformanceFilter.TestGrade.selectedTestgrade.grade;
    let ActualListForGraph = JSON.parse(
      JSON.stringify(
        this.props.StandardPerformance_Overview.ActualLineChartData
      )
    );
    // let Pagination_Start = GraphPagination.Chart_Page_Count_Start;
    // let Pagination_End = GraphPagination.Chart_Page_Count_End;
    let ToolTipData =
      this.props.StandardPerformance_Overview.Strands_ToolTipData;
    let StrandReducer = this.props.StandardPerformance_Overview;
    let TotalQuestions = ActualListForGraph.reduce(
      (initial, item) => initial + parseInt(item.totalQuestions),
      0
    );
    let Standard_performance_details = this.props.StandardPerformance_Overview;
    // let LastChecked_CB = Standard_performance_details.lastSelectedCheckBox
    /* const { XAxis_Params, YAxis_Params, DatatPointParams, tooltipParams, data,
          margin, width, height, Ipadwidth, Ipadheight
      } = LineChartInput_Params(ActualListForGraph, Pagination_Start, Pagination_End, 'c_sp_overview')*/
    let ClassChecked = false; // for class instance we no need this so by default we are sending false.
    // let SchoolChecked = Standard_performance_details.checkSchool;
    //let DistrictChecked = Standard_performance_details.checkDistrict;

    //took values from c_sp_overview ends

    //API modified changes
    if (Test_Scores_Details.studentTestScoreList != undefined) {
      Test_Scores_Details = Test_Scores_Details.studentTestScoreList;
    }

    let {
      lessthan40Studentcount,
      l40width,
      l40to59Studentcount,
      l40to59width,
      l60to79Studentcount,
      l60to79width,
      l80Studentcount,
      g80width,
      totalStudentCount,
      totalAverageScore,
      testName,
      submittedStartDate,
      submittedEndDate,
      sortedValue,
    } = ParamsForStudentsListTable(
      Test_Scores_Details.testScoreList,
      this.props.StudentsListTable.SortedArray,
      this.props.NavigationByHeaderSelection,
      this.props.AchivementLevels
    );

    let Std_List =
      Test_Scores_Details.testScoreList == undefined ||
      Test_Scores_Details.testScoreList == null
        ? []
        : JSON.parse(JSON.stringify(Test_Scores_Details.testScoreList));
    let Distinct_StdCount = RemoveDuplicateObjectsFromArray(
      Std_List,
      "studentId"
    ).length;

    let Ts_Score_Redux_Props = this.props.Test_Scores_OverTime;
    let Array = JSON.parse(
      JSON.stringify(Ts_Score_Redux_Props.ActualLineChartList)
    );
    let Compare_School_List = [...Ts_Score_Redux_Props.Actual_School_LC_List];
    let Compare_District_List = [
      ...Ts_Score_Redux_Props.Actual_District_LC_List,
    ];
    let Pagination_Start =
      this.props.LineChart_Pagination.Chart_Page_Count_Start;
    let Pagination_End = this.props.LineChart_Pagination.Chart_Page_Count_End;
    let ApiClassReports = this.props.ApiCalls_Reports;
    const {
      XAxis_Params,
      YAxis_Params,
      DatatPointParams,
      tooltipParams,
      data,
      margin,
      width,
      height,
      Ipadwidth,
      Ipadheight,
      dataset_2,
      dataset_3,
    } = LineChartInput_Params(
      Array,
      Pagination_Start,
      Pagination_End,
      "c_ts_overview",
      Compare_School_List,
      Compare_District_List
    );

    testName = this.props.Test_Scores_OverTime.SelectedTestData.testName;
    const selectedTest_submitStart =
      DISPLAY_LOCAL_TIME_IN_UI === true
        ? this.props.Test_Scores_OverTime.SelectedTestData.submitStart !==
          undefined
          ? convertUTCDateToLocalDate(
              this.props.Test_Scores_OverTime.SelectedTestData.submitStart,
              this.props.Test_Scores_OverTime.SelectedTestData.submitStartTime
            )
          : this.props.Test_Scores_OverTime.SelectedTestData.submitStart
        : this.props.Test_Scores_OverTime.SelectedTestData.submitStart;

    const selectedTest_submitEnd =
      DISPLAY_LOCAL_TIME_IN_UI === true
        ? this.props.Test_Scores_OverTime.SelectedTestData.submitEnd !==
          undefined
          ? convertUTCDateToLocalDate(
              this.props.Test_Scores_OverTime.SelectedTestData.submitEnd,
              this.props.Test_Scores_OverTime.SelectedTestData.submitEndTime
            )
          : this.props.Test_Scores_OverTime.SelectedTestData.submitEnd
        : this.props.Test_Scores_OverTime.SelectedTestData.submitEnd;

    const Compare_School = [...dataset_2];
    const Compare_District = [...dataset_3];
    const SchoolChecked = Ts_Score_Redux_Props.checkSchool;
    const DistrictChecked = Ts_Score_Redux_Props.checkDistrict;
    const LastChecked_CB = Ts_Score_Redux_Props.lastSelectedCheckBox;
    const DataToDisplayForStudentsList =
      this.props.StudentsListTable.ActualList.testScoreList;

    let loaderStatus = false;

    if (
      ApiClassReports.loading_LC_students ||
      ApiClassReports.loading_on_TS_LC
    ) {
      loaderStatus = true;
    } else {
      loaderStatus = false;
    }

    // All related to PDF
    let HeaderDetailsForPrint = this.props.ContextHeader;
    let TestDetailsForPrint = {
      testName,
      submittedStartDate,
      submittedEndDate,
    };
    let CompareOptionsForPrint = {
      TS_Overtime: this.props.Test_Scores_OverTime,
      LastChecked_CB: LastChecked_CB,
    };
    let MetaDataForPrint = {
      totalListCount: totalStudentCount,
      totalAverageScore: totalAverageScore,
      sortedValue: sortedValue,
      l40: lessthan40Studentcount,
      l40width: l40width,
      g40tol59: l40to59Studentcount,
      l40to59width: l40to59width,
      g60tol79: l60to79Studentcount,
      l60to79width: l60to79width,
      g80: l80Studentcount,
      g80width: g80width,
      Pagination_Start,
      Pagination_End,
    };
    // End of PDF Stuff

    let screenLoading =
      ApiClassReports.loading_on_TS_LC ||
      EnableLoaderOrNot(
        this.props.ApiCalls,
        this.props.NavigationByHeaderSelection
      );
    let NoTestSelectedInGraph =
      (testName == undefined || testName == null) &&
      !ApiClassReports.get_TS_Details &&
      !ApiClassReports.loading_on_TS_LC &&
      Disable_AutoSelect_TS_Overview_LeftView;

    return (
      <div className="class_main">
        <div className="class_main_center">
          <div className="class_main_inr">
            <CompareCheckBoxes
              Navselection={this.props.NavigationByHeaderSelection.class}
              CheckeThis={this.SelectCompareOption}
              ClickOnLabel={this.ClickOnLabelName}
              TS_Overtime={this.props.Test_Scores_OverTime}
              lastcheckedlabel={LastChecked_CB}
              loaderStatus={loaderStatus}
            />
            <div className="class_left_block" style={{ position: "relative" }}>
              <div className="class_widget_title test_score_overtime">
                <span className="float-left">
                  Test Scores Over Time
                  <span style={{ float: "right", padding: "0px" }}>
                    <span
                      onClick={() =>
                        this.props.OpenOrCloseNoteIn_TS_OT(true, "T_Scores")
                      }
                      className="infoIconBlock overrightinfostyle"
                      style={{ padding: "0px" }}
                    >
                      <span
                        ref={(refs) =>
                          refs == null ? null : (this.i_span_tooltip_ref = refs)
                        }
                      >
                        <img
                          src={info_icon}
                          style={{ marginLeft: "3px", cursor: "pointer" }}
                        />
                      </span>
                      {Ts_Score_Redux_Props.OpenInfoNote ? (
                        <div className="infoIconTooltipBlock_TS">
                          <div
                            ref={(InfoTooltipPopUp) =>
                              InfoTooltipPopUp !== null
                                ? (this.InfoTooltipPopUp = InfoTooltipPopUp)
                                : null
                            }
                            className="infoIconTooltipBlockInr"
                          >
                            <span
                              className="infoIconTooltipBlockArrow_TS"
                              style={{ padding: "0px" }}
                            ></span>
                            <b>Note:</b> The average score listed in the line
                            graph below is calculated from all data available
                            for each assessment based on the context selected.
                            It does not assume the cohort of students remains
                            the same across the assessments listed.
                          </div>
                        </div>
                      ) : null}
                    </span>

                    {!screenLoading ? (
                      <span className="float-left" style={{ padding: "0px" }}>
                        <TestScoreOverTimePDF
                          data={data}
                          XAxis_Params={XAxis_Params}
                          Pagination={GraphPagination}
                          selectedTestAssessment={selectedTestAssessment}
                          selectedTestGrade={selectedTestGrade}
                          YAxis_Params={YAxis_Params}
                          DataSetParam={DatatPointParams}
                          TooltipParams={tooltipParams}
                          ToolTipData={this.props.ToolTipData}
                          ClassChecked={ClassChecked}
                          SchoolChecked={SchoolChecked}
                          DistrictChecked={DistrictChecked}
                          LastChecked_CB={LastChecked_CB}
                          Navselection={
                            this.props.NavigationByHeaderSelection.class
                          } //this.props.nav
                          TS_Overtime={this.props.Test_Scores_OverTime}
                          CheckeThis={this.SelectCompareOption}
                          ClickOnLabel={this.ClickOnLabelName}
                          totalAverageScore={StrandReducer.selectedStandarAvg}
                          totalQuestions={TotalQuestions}
                          standardName={
                            StrandReducer.StrandNameOfSelectedStandard
                          }
                          strandName={
                            StrandReducer.selectedstandardObject == null
                              ? null
                              : StrandReducer.selectedstandardObject.standardDef
                          }
                          strandDetailsDesc={
                            StrandReducer.selectedstandardObject == null
                              ? null
                              : StrandReducer.selectedstandardObject
                                  .standardName
                          }
                          strandDescription={
                            StrandReducer.selectedstandardObject == null
                              ? null
                              : StrandReducer.selectedstandardObject
                                  .standardDesc
                          }
                        />
                      </span>
                    ) : null}
                  </span>
                </span>
              </div>
              <div>
                {screenLoading ? (
                  <LoadingScreen />
                ) : (
                  <div style={{ width: "100%", float: "left" }}>
                    <div style={{ width: "100%", float: "left" }}>
                      <Chart
                        margin={margin}
                        width={
                          this.props.UserScreenWidth < 1230 ? Ipadwidth : width
                        }
                        height={
                          this.props.UserScreenWidth < 1230
                            ? Ipadheight
                            : height
                        }
                        data={data}
                        Compare_School={Compare_School}
                        Compare_District={Compare_District}
                        XAxis_Params={XAxis_Params}
                        YAxis_Params={YAxis_Params}
                        DataSetParam={DatatPointParams}
                        SchoolChecked={SchoolChecked}
                        DistrictChecked={DistrictChecked}
                        LastChecked_CB={LastChecked_CB}
                        ToolTipData={this.props.ToolTipData}
                        TooltipParams={tooltipParams}
                        // data2={data2} data3={data3}
                      />
                    </div>
                    {this.props.LineChart_Pagination.Chart_TotalBubbles > 1 ? (
                      <ChartPagination
                        pagination={this.props.LineChart_Pagination}
                      />
                    ) : null}
                    <div
                      className="Test_names_label"
                      style={{ float: "left", paddingTop: 15 }}
                    >
                      Test Names
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="centre_line"></div>
            <div className="class_right_block" style={{ position: "relative" }}>
              <div className="class_widget_title">
                <span className="float-right">
                  Test Score Detail
                  {/* <span className="testScorePrint" style={{float:'left'}}><img src={printIco} style={{width:'24'}} /></span> */}
                  {!ApiClassReports.loading_LC_students &&
                  this.props.NavigationByHeaderSelection.T_scores ? (
                    <TestScoreDetailListPDF
                      Header={HeaderDetailsForPrint}
                      TestDetails={TestDetailsForPrint}
                      CompareOptions={CompareOptionsForPrint}
                      MetaData={MetaDataForPrint}
                      sortedArrayData={this.props.StudentsListTable.SortedArray}
                      ActualList={this.props.StudentsListTable.ActualList}
                      Data={this.props.StudentsListTable}
                      DataToDisplay={DataToDisplayForStudentsList}
                      PaginationData={this.props.Pagination_For_Remaining}
                      fromComp="c_ts_overview"
                    />
                  ) : (
                    <span className="testScorePrint" style={{ float: "left" }}>
                      <img src={printIco} style={{ width: "24" }} />
                    </span>
                  )}
                </span>
              </div>
              {NoTestSelectedInGraph ? (
                <Make_A_Selection_Msg message="Make a selection in the graph to see details." />
              ) : ApiClassReports.loading_LC_students == false &&
                !screenLoading ? (
                <div className="standard-widget-class_level">
                  <OverviewDetailHeader
                    fromComp="c_ts_overview"
                    checkSchool={this.props.Test_Scores_OverTime.checkSchool}
                    checkDistrict={
                      this.props.Test_Scores_OverTime.checkDistrict
                    }
                    Data={this.props.StudentsListTable}
                    ActualList={this.props.StudentsListTable.ActualList}
                    l40={lessthan40Studentcount}
                    l40width={l40width}
                    g40tol59={l40to59Studentcount}
                    l40to59width={l40to59width}
                    g60tol79={l60to79Studentcount}
                    l60to79width={l60to79width}
                    g80={l80Studentcount}
                    g80width={g80width}
                    Distinct_StdCount={Distinct_StdCount}
                    studentTotalC={totalStudentCount}
                    averagescore={totalAverageScore}
                    testName={testName}
                    startDate={selectedTest_submitStart}
                    endDate={selectedTest_submitEnd}
                  />

                  <OverviewDetailStudentList
                    totalstudentcount={totalStudentCount}
                    studentsdata={Test_Scores_Details}
                    sortedValue={sortedValue}
                    Data={this.props.StudentsListTable}
                    pagination={this.props.Pagination_For_Remaining}
                    DataToDisplay={DataToDisplayForStudentsList}
                    sortedArrayData={this.props.StudentsListTable.SortedArray}
                  />
                </div>
              ) : (
                <LoadingScreen />
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Reports,
  Universal,
  Authentication,
  LastActiveUniversalProps,DateTabReducer
}) => {
  const {
    Test_Scores_OverTime,
    LineChart_Pagination,
    StudentsListTable,
    Pagination_For_Remaining,
    ToolTipData,
    ApiCalls_Reports,
    StandardPerformance_Overview,
  } = Reports;
  const { LoginDetails, UserScreenWidth } = Authentication;
  const {
    AchivementLevels,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    currentTermID,
  } = Universal;
  const { Context_DateTab } = DateTabReducer;
  return {
    Test_Scores_OverTime,
    LineChart_Pagination,
    LoginDetails,
    AchivementLevels,
    ContextHeader,
    ApiCalls,
    UniversalSelecter,
    NavigationByHeaderSelection,
    UserScreenWidth,
    StudentsListTable,
    Pagination_For_Remaining,
    ToolTipData,
    ApiCalls_Reports,
    StandardPerformance_Overview,
    LastActiveUniversalProps,
    currentTermID,Context_DateTab
  };
};

export default connect(mapStateToProps, {
  Get_Class_TestScores_Over_Time,
  OpenOrCloseNoteIn_TS_OT,
  CheckCompareTabs,
  EnableOrDisableLineColorIn_LC,
  Get_Class_TestScores_Details,
  trackingUsage
})(c_ts_overview);

/**
 *
 * @param {Object} ApiCalls
 * @param {Object} Nav
 * @returns {Boolean}
 */

function EnableLoaderOrNot(ApiCalls, Nav) {
  if (Nav.class) {
    return (
      (ApiCalls.loadingFor == "datetab" || ApiCalls.loadingFor == "tests") &&
      ApiCalls.get_C_TS_Graph_Alias
    );
  } else return false;
}
