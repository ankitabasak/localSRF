import React, { Component } from 'react';

class c_ts_grouping extends Component {
    render() {

        return (
            <div className="text-center">
                <h1> Place Holder For Class_TestScore_Grouping  </h1>
            </div>
        );
    }
}

export default c_ts_grouping;
