import React, { Component } from 'react';

// var LineChart = require("react-chartjs").Line;
import './OverviewDetails.css';

var data = {
    rows: [
        {
            'id': '1',
            'distributorName': 'Wing',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '2,00,000'
        },
        {
            'id': '2',
            'distributorName': 'Whitney',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '2,00,000'

        },
        {
            'id': '3',
            'distributorName': 'Hilel',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '2,00,000'
        },
        {
            'id': '4',
            'distributorName': 'Alea',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '2,00,000'

        },

        {
            'id': '5',
            'distributorName': 'Prashanth',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '6',
            'distributorName': 'Mahesh',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '7',
            'distributorName': 'Sreeja',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '8',
            'distributorName': 'Raj kumar',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '9',
            'distributorName': 'Avinash',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '10',
            'distributorName': 'Pavan',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '11',
            'distributorName': 'rajesh',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '12',
            'distributorName': 'Aparna',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        },
        {
            'id': '13',
            'distributorName': 'Ajay',
            'distributorMobileNo': '9440556452',
            'date': '27/03/2018 13:08:55',
            'amount': '1,00,000'

        }

    ]

}


class TestScoreOtGraph extends React.Component {
    options() {
        sortIndicator: true;
        hideSizePerPage: true;
        paginationSize: 3;
        hidePageListOnlyOnePage: true;
        clearSearch: true;
        // alwaysShowAllBtns: false;
        // withFirstAndLast: false
    }

    render() {
        return (
            <div >
                {/* <BootstrapTable data={data.rows} version="4" striped hover pagination search options={this.options}>
                    <TableHeaderColumn isKey dataField="distributorName" dataSort>distributorName</TableHeaderColumn>
                    <TableHeaderColumn dataField="distributorMobileNo" dataSort >distributorMobileNo</TableHeaderColumn>
                    <TableHeaderColumn dataField="amount" dataSort >amount</TableHeaderColumn>
                    <TableHeaderColumn dataField="date" dataSort>date</TableHeaderColumn>
                </BootstrapTable> */}
            </div>
        )
    }

}


export default TestScoreOtGraph;

