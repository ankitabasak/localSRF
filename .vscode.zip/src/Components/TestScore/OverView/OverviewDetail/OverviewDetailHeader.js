import React, { Component } from 'react';
import '../../../../../public/css/style.css';
import { connect } from 'react-redux';
import PrintList from '../../../ReusableComponents/PDFReports/PrintList';

import { SaveSorted_OrderOverViewStudentList } from '../../../../Redux_Actions/ReportsActions';
import { SaveSorted_OrderOverViewSchoolsList } from '../../../../Redux_Actions/District_Report_Actions'
let cssPropValue = "";
class OverviewDetailHeader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            all: "active_progress",
            l40: "",
            g40to59: "",
            g60tol79: "",
            l80: ""
        };
    }
    /**
     * 
     * @param {string} minvalue 
     * @param {string} maxvalue 
     * @param {string} colorvalue 
     * @param {Array} ActualList 
     */
    Sort_List_Data(minvalue, maxvalue, colorvalue, arr) {

        let Nav = this.props.NavigationByHeaderSelection;
        let ActualList = JSON.parse(JSON.stringify(arr));

        let ArrayList;

        if (Nav.district) {
            ArrayList = ActualList;
            // if (ActualList.testScoreList == undefined) {
            //     ArrayList = ActualList;
            // } else {
            //     ArrayList = ActualList.testScoreList;
            // }
        } else {

            // if (ActualList.testScoreList !== undefined && ActualList.testScoreList !== null) {
            //     ArrayList = ActualList.testScoreList;
            // } else 
            if (ActualList.studentTestScoreList == undefined) {
                ArrayList = ActualList;
            } else {
                ArrayList = ActualList.studentTestScoreList;
            }
        }

        let SortedArray = [];

        if (ArrayList.length > 1 || ArrayList.length == undefined) {

            if (Nav.T_scores) {

                let SortedArray_ = ArrayList.testScoreList.filter(item => {
                    let Score;
                    if (Nav.district) {
                        Score = item.schoolScore
                    } else if (Nav.school) {
                        Score = item.classScore
                        // Score = item.testScore
                    } else {
                        Score = item.testScore
                    }

                    return (Score > minvalue || Score == minvalue) && (Score < maxvalue || Score == maxvalue)
                }
                );

                ArrayList.testScoreList = SortedArray_
                SortedArray = ArrayList;

            } else {

                SortedArray = ArrayList.filter(item => {
                    let Score;
                    if (Nav.district) {
                        Score = item.schoolScore
                    } else if (Nav.school) {
                        Score = item.classScore
                    } else {
                        Score = item.testScore
                    }
                    return (Score > minvalue || Score == minvalue) && (Score < maxvalue || Score == maxvalue)
                }
                );
            }
        } else {

            SortedArray = ArrayList
        }

        let MainSortedArray = SortedArray;

        // if (Nav.school && Nav.T_scores) {

        //     ActualList.testScoreList = SortedArray

        //     MainSortedArray = ActualList;

        // }

        if (Nav.district) {

            this.props.SaveSorted_OrderOverViewSchoolsList(MainSortedArray, ArrayList, minvalue, maxvalue, colorvalue, Nav);

        } else {

            this.props.SaveSorted_OrderOverViewStudentList(MainSortedArray, ArrayList, minvalue, maxvalue, colorvalue, Nav);
        }
    }


    // Ellipsis for names and test Names

    TestNameTooltipDisplay(testName) {

        let TestNameResult = null;

        if (testName !== null && testName !== undefined) {
            testName.length > 22 ? TestNameResult =
                <div className="bec_tooltip">
                    <div className="bec_tooltip_arrow"></div>
                    <div className="bec_tooltip_content">
                        {testName}
                    </div>
                </div> : null;
        }

        return TestNameResult;

    }
    Ellipsis(value) {
        if (value === undefined || value === null || value === "") {
            return value;
        } else if (value.length > 22) {
            return value.slice(0, 22) + "...";
        } else return value;
    }

    /**
    * 
    * @param value - Count of the studentcount who falls into the band range
    * @param testName - Total Count of the students
    * @returns calValue -- width required for the band {JSX element}
    */

    calculatewidth(value, totalcount) {
        let ScreenWidth = window.screen.availWidth;
        let totalwidth;
        if (ScreenWidth < 1100) {
            totalwidth = 188;
        } else {
            totalwidth = 252;
        }
        let calValue = (value * 100) / totalcount;
        calValue = (totalwidth * calValue) / 100;
        calValue = 48 + calValue;
        return calValue;
    }


    /**
     * 
     * @param {string} fromComp -- component name from where we are calling this Header Details. 
     * @param {string}  testName -- Selected Test Name
     * @param {string}  T_startDate -- Selected Test startDate
     * @param {string}   T_endDate -- Selected Test endDate
     * @returns {JSX element}
     */
    TestNameAndOtherView(fromComp, testName, T_startDate, T_endDate) {

        if (fromComp === 'c_ts_overview' || fromComp === 'sc_ts_overview' || fromComp == 'd_ts_overview') {
            return <div className="class_test_overview_table_header">
                <div className="class_test_overview_table_header_left">
                    {this.Ellipsis(testName)}
                    {this.TestNameTooltipDisplay(testName)}
                </div>
                <div className="class_test_overview_table_header_right">
                    <span>Submitted: {T_startDate == T_endDate ? T_startDate : T_startDate + '- ' + T_endDate}</span>

                </div>
                {/* <PrintButton id={"singlePage"} label={"Print student list"} />
                <div id="react-no-print">
                    <SinglePage id={"singlePage"} /> 
                </div> */}
            </div>
        } else {
            return null;
        }
    }

    render() {
        let TS_Details = this.props.Data;
        let ActualList = this.props.ActualList;
        let Nav = this.props.NavigationByHeaderSelection;

        let DistrictBand;
        let SchoolBand;
        let totalstudentcount_district;
        let totalstudentcount_school;

        let SelectedTestData = Nav.district ? this.props.D_Test_Scores_OverTime :
            Nav.school ? this.props.Sc_Test_Scores_OverTime : this.props.Test_Scores_OverTime;

        let AchivementLevels= this.props.AchivementLevels;
        let averageScore;
        if (SelectedTestData.SelectedTestData != undefined) {
            if (Nav.student) {
                averageScore = SelectedTestData.SelectedTestData.testScore;
            } else if (Nav.class) {
                averageScore = SelectedTestData.SelectedTestData.classScore;
            } else if (Nav.school) {
                averageScore = SelectedTestData.SelectedTestData.schoolScore;
            } else {
                averageScore = SelectedTestData.SelectedTestData.districtScore;
            }

        }
        if (ActualList.districtBand != null) {
            DistrictBand = ActualList.districtBand;
   
            totalstudentcount_district = DistrictBand[AchivementLevels[0]["key"]] + DistrictBand[AchivementLevels[1]["key"]] + DistrictBand[AchivementLevels[2]["key"]] + DistrictBand[AchivementLevels[3]["key"]];
        }
        if (ActualList.schoolBand != null) {
            SchoolBand = ActualList.schoolBand;
            totalstudentcount_school = SchoolBand[AchivementLevels[0]["key"]] + SchoolBand[AchivementLevels[1]["key"]] + SchoolBand[AchivementLevels[2]["key"]] + SchoolBand[AchivementLevels[3]["key"]];
        } else {
            SchoolBand = {}
        };
        
        let From_Comp = this.props.fromComp;

        return (
            <div className="class_test_overview_table text-left">
                <div className="class_test_overview_table_inr">
                    {this.TestNameAndOtherView(From_Comp, this.props.testName, this.props.startDate, this.props.endDate)}
                    {/* <div className="class_test_overview_table_header">
                        <div className="class_test_overview_table_header_left">
                            {this.props.testName}
                        </div>
                        <div className="class_test_overview_table_header_right">
                            <span>Submitted: {this.props.startDate} - {this.props.endDate}</span>
                        </div>
                    </div> */}
                    {/* District Average Score */}
                    {this.props.checkDistrict == false || this.props.checkDistrict == undefined || DistrictBand == null ? null : <div className="class_test_overview_table_progress_bar">
                        {From_Comp === 'c_ts_overview' || From_Comp === 'sc_ts_overview' ?
                            <div className="class_test_overview_table_progress_bar_title">
                                District Average Scores: {DistrictBand.districtAvg}% based on {totalstudentcount_district} results</div> : null
                        }
                        <div className="class_test_overview_table_progress_bar_list">
                            <ul>
                                <li style={{ width: this.calculatewidth(DistrictBand[AchivementLevels[0]["key"]], totalstudentcount_district) }}>
                                    <span className="progress-number red">{DistrictBand[AchivementLevels[0]["key"]]}</span>

                                </li>
                                <li style={{ width: this.calculatewidth(DistrictBand[AchivementLevels[1]["key"]], totalstudentcount_district) }}>
                                    <span className="progress-number orange">{DistrictBand[AchivementLevels[1]["key"]]}</span>

                                </li>
                                <li style={{ width: this.calculatewidth(DistrictBand[AchivementLevels[2]["key"]], totalstudentcount_district) }}>
                                    <span className="progress-number yellow">{DistrictBand[AchivementLevels[2]["key"]]}</span>

                                </li>
                                <li style={{ width: this.calculatewidth(DistrictBand[AchivementLevels[3]["key"]], totalstudentcount_district) }}>
                                    <span className="progress-number green">{DistrictBand[AchivementLevels[3]["key"]]}</span>

                                </li>
                            </ul>
                        </div>
                    </div>}

                    {/* School Average Score */}
                    {SchoolBand == null || this.props.checkSchool == false || this.props.checkSchool == undefined ? null : (!Nav.school)?<div className="class_test_overview_table_progress_bar some_testclassname">
                        {From_Comp === 'c_ts_overview' || From_Comp === 'sc_ts_overview' ?
                            <div className="class_test_overview_table_progress_bar_title">
                                School Average Scores: {SchoolBand.schoolAvg}% based on {SchoolBand.schoolResult} results</div> : null
                        }
                        <div className="class_test_overview_table_progress_bar_list">
                            <ul>
                                <li style={{ width: this.calculatewidth(SchoolBand[AchivementLevels[0]["key"]], totalstudentcount_school) }}>
                                    <span className="progress-number red">{SchoolBand[AchivementLevels[0]["key"]]}</span>

                                </li>
                                <li style={{ width: this.calculatewidth(SchoolBand[AchivementLevels[1]["key"]], totalstudentcount_school) }}>
                                    <span className="progress-number orange">{SchoolBand[AchivementLevels[1]["key"]]}</span>

                                </li>
                                <li style={{ width: this.calculatewidth(SchoolBand[AchivementLevels[2]["key"]], totalstudentcount_school) }}>
                                    <span className="progress-number yellow">{SchoolBand[AchivementLevels[2]["key"]]}</span>

                                </li>
                                <li style={{ width: this.calculatewidth(SchoolBand[AchivementLevels[3]["key"]], totalstudentcount_school) }}>
                                    <span className="progress-number green">{SchoolBand[AchivementLevels[3]["key"]]}</span>

                                </li>
                            </ul>
                        </div>
                    </div>:null}

                    {/* Class Average Score */}
                    <div className="class_test_overview_table_progress_bar">
                        {From_Comp === 'c_ts_overview' || From_Comp === 'sc_ts_overview' || From_Comp == 'd_ts_overview' ?
                            <div className="class_test_overview_table_progress_bar_title">
                                {From_Comp == 'd_ts_overview' ? 'District' : From_Comp === 'sc_ts_overview' ? 'School' : 'Class'} Average Scores: {averageScore}% based on {(From_Comp === 'sc_ts_overview') || (From_Comp == 'd_ts_overview') ? TS_Details.ActualList.studentCount : this.props.Distinct_StdCount == undefined ? this.props.studentTotalC
                                    : this.props.Distinct_StdCount} results</div> : null
                        }
                        <div className="class_test_overview_table_progress_bar_list">
                            <ul>
                                <li className={TS_Details.ActiveHeaderColumn == 'all' ? "active_progress" : ""} style={{ width: 48 }}
                                    onClick={() => {
                                        TS_Details.MaxValue == 100 && TS_Details.MinValue == 0 ? null :
                                            this.Sort_List_Data(0, 100, 'all', ActualList)
                                    }}
                                >
                                    <span className="progress-number grey" style={{ 'cursor': 'pointer' }}>{this.props.studentTotalC}</span>
                                    <span className="progress-text">All</span>
                                </li>
                                <li className={TS_Details.ActiveHeaderColumn == 'l40' ? "active_progress" : ""} style={{ width: this.props.l40width }} onClick={() => {
                                    if (this.props.l40 != 0) {
                                        TS_Details.MinValue == 0 && TS_Details.MaxValue == AchivementLevels[0]['max'] ? null : this.Sort_List_Data(AchivementLevels[0]['min'], AchivementLevels[0]['max'], 'l40', ActualList)
                                    }
                                }}>
                                    <span className="progress-number red" style={{ 'cursor': this.props.l40 === 0 ? 'default' : 'pointer' }}>{this.props.l40}</span>
                            <span className="progress-text">&lt; {AchivementLevels[0]["label"]}%</span>
                                </li>
                                <li className={TS_Details.ActiveHeaderColumn == 'g59' ? "active_progress" : ""} style={{ width: this.props.l40to59width }}
                                    onClick={() => {
                                        if (this.props.g40tol59 != 0) {
                                            TS_Details.MinValue == AchivementLevels[1]['min'] && TS_Details.MaxValue == AchivementLevels[1]['max'] ? null : this.Sort_List_Data(AchivementLevels[1]['min'], AchivementLevels[1]['max'], 'g59', ActualList)
                                        }
                                    }}>
                                    <span className="progress-number orange" style={{ 'cursor': this.props.g40tol59 === 0 ? 'default' : 'pointer' }}>{this.props.g40tol59}</span>
                                    <span className="progress-text">{AchivementLevels[1]["label"]}%</span>
                                </li>
                                <li className={TS_Details.ActiveHeaderColumn == 'g79' ? "active_progress" : ""} style={{ width: this.props.l60to79width }}
                                    onClick={() => {
                                        if (this.props.g60tol79 != 0) {
                                            TS_Details.MinValue == AchivementLevels[2]['min'] && TS_Details.MaxValue == AchivementLevels[2]['max'] ? null : this.Sort_List_Data(AchivementLevels[2]['min'], AchivementLevels[2]['max'], 'g79', ActualList)
                                        }
                                    }}>
                                    <span className="progress-number yellow" style={{ 'cursor': this.props.g60tol79 === 0 ? 'default' : 'pointer' }}>{this.props.g60tol79}</span>
                                    <span className="progress-text">{AchivementLevels[2]["label"]}%</span>
                                </li>
                                <li className={TS_Details.ActiveHeaderColumn == 'l80' ? "active_progress" : ""} style={{ width: this.props.g80width }}
                                    onClick={() => {
                                        if (this.props.g80 != 0) {
                                            TS_Details.MinValue == AchivementLevels[3]['min'] && TS_Details.MaxValue == AchivementLevels[3]['max'] ? null : this.Sort_List_Data(AchivementLevels[3]['min'], AchivementLevels[3]['max'], 'l80', ActualList)
                                        }
                                    }}>
                                    <span className="progress-number green" style={{ 'cursor': this.props.g80 === 0 ? 'default' : 'pointer' }}>{this.props.g80}</span>
                                    <span className="progress-text">&ge; {AchivementLevels[3]["label"]}%</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div >
        )
    }
}

// export default OverviewDetailHeader;

const mapStateToProps = ({ Universal, Reports, schoolReducer, DistrictReducer }) => {

    const { AchivementLevels,NavigationByHeaderSelection } = Universal
    const { Class, Pagination_For_Remaining, ApiCalls_Reports, StudentsListTable,
        StrandNameOfSelectedStandard, Test_Scores_OverTime } = Reports;

    const { Sc_Test_Scores_OverTime } = schoolReducer

    const { D_Test_Scores_OverTime } = DistrictReducer

    return {
        Class, Pagination_For_Remaining, ApiCalls_Reports, StudentsListTable,
        AchivementLevels,NavigationByHeaderSelection, StrandNameOfSelectedStandard, Test_Scores_OverTime,
        D_Test_Scores_OverTime, Sc_Test_Scores_OverTime
    };
}

export default connect(mapStateToProps, {
    SaveSorted_OrderOverViewStudentList,
    SaveSorted_OrderOverViewSchoolsList
})(OverviewDetailHeader);

/**
 * 
 * @param {Object} Nav
 * based on current context will return score to be consider for filter. 
 */
function ReturnScoreBasedOnNav(Nav, item) {

    if (Nav.district) {
        return item.schoolScore
    } else {
        return item.testScore
    }
}