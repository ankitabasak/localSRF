import React, { PureComponent } from 'react';
import '../../../../../public/css/style.css';
import Component from 'react-quill';
import { connect } from 'react-redux';
import { convertUTCDateToLocalDate, SortArray, SortArrayTestScore } from '../../../ReusableComponents/AllReusableFunctions'

import PaginationForRemaining from '../../../../Utils/PaginationForRemaining';
import { GetCompleteStudentReport, GetCompleteClassReport, NavigateTo_School_Reports_On_SchoolSelection_from_List } from '../../../../Redux_Actions/UniversalSelectorActions';

import { SaveSorted_OverViewStudentList } from '../../../../Redux_Actions/ReportsActions';
import { Pointer } from 'highcharts';
import { DISPLAY_LOCAL_TIME_IN_UI } from '../../../../Utils/globalVars';
import { trackingUsage } from '../../../../Redux_Actions/AuthenticationAction';

const TestScoreBgColor = (testscore, AchivementLevels) => {
    if (testscore <= AchivementLevels[0]['max']) {
        return "student-list-grade red"
    } else if (testscore <= AchivementLevels[1]['max']) {
        return "student-list-grade orange"
    } else if (testscore <= AchivementLevels[2]['max']) {
        return "student-list-grade yellow"
    } else if (testscore <= AchivementLevels[3]['max']) {
        return "student-list-grade green"
    }
}

class OverviewDetailStudentList extends PureComponent {
    // constructor(props) {
    //     super(props);
    // }
    /**
     * 
     * @param {string} column  -- Column name which is enable to sort
     * @param {string} sortType -- asc/desc
     * @param {Array} ArrayList -- Apply sorting on this array
     */

    componentDidMount(){
        let { NavigationByHeaderSelection } = this.props;
        if(!NavigationByHeaderSelection.S_performance){
            let context = "district";
            if (NavigationByHeaderSelection.school) {
            context = "school";
            } else if (NavigationByHeaderSelection.class) {
            context = "class";
            }
            this.props.trackingUsage(`assessmentreports_testscoredetail:${context}`);
        }
        
        }

    SortList(column, sortType, ArrayList) {

        let CurrentNav = this.props.NavigationByHeaderSelection;
        if (CurrentNav.school && column == 'lastName') {
            column = 'className';
        } else if (CurrentNav.school && column == 'testScore') {
            column = 'classScore';
        } else if (CurrentNav.district && column == 'lastName') {
            column = 'schoolName';
        } else if (CurrentNav.school && column == 'Date Submitted') {
            column = 'endDate';
        } else if (CurrentNav.school && column == 'studentPectgComplete') {
            column = 'studentPectgComplete';
        } else if (CurrentNav.district && column == '% Students Complete') {
            column = 'studentPectgComplete';
        }
        let SortedArray = [];
        if (ArrayList.length != 0) {
            if (column == "testScore" || column == "totalQuestions" || column == "classScore") {
                SortedArray = SortArrayTestScore(ArrayList, column, sortType);
            } else {
                SortedArray = SortArray(ArrayList, column, sortType);
            }

            this.props.SaveSorted_OverViewStudentList(SortedArray, column, sortType, CurrentNav)
        }
    }
    /**
     * @param {Array}  ArrayToDisplay -- List To Display .
     * @param {Array} stdArray --Complete List
     * @param { Object } Data --  Test_Scores_Details Redux Params.
     * @param {Object } Pagination -- Pagination Object Details .
     * @returns { JSX Elements } -- if the list is not empty will return data otherwise 
     * returns span element which contsina NoData Available  message
     */
    TestScoreDetailsHeaderAndData(ArrayToDisplay_, Data, Pagination, stdArray, students_classes_schools_length) {
        if (ArrayToDisplay_.length == 0) {
            return <span style={{ marginTop: 20 }}>No Data Available</span>
        } else {
            let Nav = this.props.NavigationByHeaderSelection;
            let ActualClassList = this.props.ContextHeader.Roster_Tab.ClassList;
            let ActualSchoolList = this.props.ContextHeader.Roster_Tab.SchoolIds;
            let Roster_Tab = this.props.ContextHeader.Roster_Tab;
            let ArrayToDisplay = ArrayToDisplay_
            let Pagination_count = Nav.district ? ArrayToDisplay.length : Pagination.totalPagesCount
            // let ArrayToDisplay = ArrayToDisplay_.filter(item => {

            //     let Score = Nav.class ? item.testScore : Nav.school ? item.classScore : item.schoolScore;

            //     return Score !== null

            // });
            return <div>
                <div className="student-list-header">
                    <div className="student-list-col">
                        <span className={(Data.Sorting_Column === 'schoolName') ? LineUnderTheActiveFilteringFiled(Data, "schoolName", Data.Sorting_Type) : (Data.Sorting_Column === 'className') ? LineUnderTheActiveFilteringFiled(Data, "className", Data.Sorting_Type) : LineUnderTheActiveFilteringFiled(Data, "lastName", Data.Sorting_Type)}>{Nav.class ? "Students" :
                            Nav.school ? "Classes" : "Schools"} ({Nav.district ? students_classes_schools_length + '/' + ActualSchoolList.length : Nav.school ? students_classes_schools_length + '/' + Roster_Tab.ClassIds.length : students_classes_schools_length + '/' + Roster_Tab.StudentIds.length})
                            {Nav.district ? <div className="standard_perfomance_list_head_tooltip" style={{ left: 0 }}>
                                <span className="body_left" style={{ left: 43 }}></span>
                                <span className="body_right">
                                    <span className="standard_perfomance_list_head_tooltip_Definition">
                                        Schools Assessed Online/Schools {Nav.district && (Roster_Tab.SchoolIds.length !== Roster_Tab.schoolsList.length) ? "Selected" : "Rostered"}
                                    </span>
                                </span>
                            </div> : null}
                            {Nav.school ? <div className="standard_perfomance_list_head_tooltip" style={{ left: 0 }}>
                                <span className="body_left" style={{ left: 43 }}></span>
                                <span className="body_right">
                                    <span className="standard_perfomance_list_head_tooltip_Definition">
                                        Classes Assessed Online/Classes {Nav.school && (Roster_Tab.ClassIds.length !== Roster_Tab.ClassList.length) ? "Selected" : "Rostered"}
                                    </span>
                                </span>
                            </div> : null}
                            {Nav.class ? <div className="standard_perfomance_list_head_tooltip" style={{ left: 0 }}>
                                <span className="body_left" style={{ left: 43 }}></span>
                                <span className="body_right">
                                    <span className="standard_perfomance_list_head_tooltip_Definition">
                                        Students Assessed Online/Students {Nav.class && (Roster_Tab.StudentIds.length !== Roster_Tab.StudentsList.length) ? "Selected" : "Rostered"}
                                    </span>
                                </span>
                            </div> : null}

                        </span>
                        <span className="togglers">
                            <i
                                style={{ cursor: "pointer" }}
                                className={(Data.Sorting_Column === 'lastName' || Data.Sorting_Column === 'className' || Data.Sorting_Column === 'schoolName') ?
                                    Data.Sorting_Type === 'desc' ?
                                        "material-icons blueColor" : "material-icons" : "material-icons"}
                                onClick={() =>
                                    Data.Sorting_Column == "lastName" && Data.Sorting_Type == "desc" ? null :
                                        this.SortList('lastName', 'desc', stdArray)}
                            >expand_more</i>
                            <i
                                style={{ cursor: "pointer" }}
                                className={(Data.Sorting_Column === 'lastName' || Data.Sorting_Column === 'className' || Data.Sorting_Column === 'schoolName') ? Data.Sorting_Type === 'asc' ?
                                    "material-icons blueColor" : "material-icons" : "material-icons"}
                                onClick={() =>
                                    Data.Sorting_Column == "lastName" && Data.Sorting_Type == "asc" ? null :
                                        this.SortList('lastName', 'asc', stdArray)}
                            >expand_less</i>
                        </span>
                    </div>
                    {this.ReturnColumnBasedOnCurrentNav(Data, Nav, stdArray)}
                    {this.ReturnColumnForSchoolReport(Data, Nav, stdArray)}
                    <div className="student-list-col">
                        {Data.Sorting_Column === 'classScore'
                        } <span className={(Data.Sorting_Column === 'schoolScore') ? LineUnderTheActiveFilteringFiled(Data, "schoolScore", Data.Sorting_Type) : (Data.Sorting_Column === 'classScore') ? LineUnderTheActiveFilteringFiled(Data, "classScore", Data.Sorting_Type) : LineUnderTheActiveFilteringFiled(Data, "testScore", Data.Sorting_Type)}>Score</span><span className="togglers">
                            <i style={{ cursor: "pointer" }} className={(Data.Sorting_Column === 'testScore' || Data.Sorting_Column === 'classScore' || Data.Sorting_Column === 'schoolScore') && Data.Sorting_Type === 'desc' ?
                                "material-icons blueColor" : "material-icons"}
                                onClick={() =>
                                    (Data.Sorting_Column == "testScore" || Data.Sorting_Column == "schoolScore") && Data.Sorting_Type == "desc" ? null :
                                        this.SortList(Nav.district ? 'schoolScore' : 'testScore', 'desc', stdArray)}
                            >expand_more</i>
                            <i style={{ cursor: "pointer" }} className={(Data.Sorting_Column === 'testScore' || Data.Sorting_Column === 'classScore' || Data.Sorting_Column === 'schoolScore') && Data.Sorting_Type === 'asc' ?
                                "material-icons blueColor" : "material-icons"}
                                onClick={() =>
                                    (Data.Sorting_Column == "testScore" || Data.Sorting_Column == "schoolScore") && Data.Sorting_Type == "asc" ? null :
                                        this.SortList(Nav.district ? 'schoolScore' : 'testScore', 'asc', stdArray)}
                            >expand_less</i> </span>
                    </div>
                </div>
                <div className="student-list-body" style={{ cursor: "Pointer" }}>


                    {this.ReturnList(ArrayToDisplay, Nav)}

                    {
                        Pagination_count > 0 ? <PaginationForRemaining
                            from="StdListOfGraphSelection"
                            Pagination={Pagination}
                            paginationbubbleCount={Pagination_count}
                        /> : null
                    }
                </div >
            </div >
        }
    }

    ReturnList(ArrayToDisplay, Nav) {
        return ArrayToDisplay.map((item, index) => {

            let Name = Nav.class ? item.studentName : Nav.school ? item.className : item.schoolName;
            let EndDate_Or_Ques = Nav.S_performance ? item.totalQuestions : (DISPLAY_LOCAL_TIME_IN_UI ? convertUTCDateToLocalDate(item.endDate, item.endTime) : item.endDate);
            let Score = Nav.class ? item.testScore : Nav.school ? item.classScore : item.schoolScore

            let Sc_Or_DIst_Sp = (Nav.S_performance && Nav.school) || (Nav.S_performance && Nav.district);

            // if (Score !== null) {

            return <div className="student-list-row" key={index}>
                <div className="student-list-col"
                    onClick={() => this.On_Item_Selection(item, Nav)}
                > {Name}</div >

                <div className="student-list-col">
                    {EndDate_Or_Ques}</div>
                {
                    (Nav.school || Nav.district) && Nav.S_performance ? <div className="student-list-col">
                        {item.studentPectgComplete}</div> : null
                }
                <div className="student-list-col">
                    <span className={TestScoreBgColor(Score, this.props.AchivementLevels)}>
                        {Score}</span>
                </div>
            </div>
            // }

        })

    }

    /**
     *
    * @param {Object} SelectedItem --selected Student Details
            * when user clicks on the item of the list, it will navigate to appropriate reports.
            *
            */
    On_Item_Selection(SelectedItem, Nav) {

        /**
         * On Student Click of class instance.
         */

        if (Nav.class) {
            let selectedStuden = {
                "id": SelectedItem.studentId,
                "name": SelectedItem.studentName,
            }

            let S_P_Reducer = this.props.StandardPerformance_Overview
            let SelectedStrand = S_P_Reducer.StrandNameOfSelectedStandard;
            let SelectedStandard = S_P_Reducer.selectedstandardObject;
            let CurrentDataForStudentId = this.props.ContextHeader.presentDataForStudentId;
            this.props.GetCompleteStudentReport(selectedStuden, SelectedStrand, SelectedStandard, CurrentDataForStudentId);

        } else if (Nav.school) {

            let SP_Reducer = this.props.Sc_StandardPerformance_Overview;
            // let SelectedStrand = SP_Reducer.StrandNameOfSelectedStandard;
            // let SelectedStandard = SP_Reducer.selectedstandardObject;
            let PresentSchool = this.props.ContextHeader.Roster_Tab.SelectedSchool;

            let SelectedClass = {
                districtId: PresentSchool.districtId,
                //gradeLevel: "grade_4",
                id: SelectedItem.classId,
                name: SelectedItem.className,
                schoolId: PresentSchool.id
            };
            let CurrentClass_Grade = this.props.StandardPerformance_Overview.StandardPerformanceFilter.TestGrade.selectedTestgrade;
            this.props.GetCompleteClassReport(SelectedClass, SP_Reducer, CurrentClass_Grade);
        } else if (Nav.district) {

            let SP_Reducer = this.props.D_StandardPerformance_Overview;

            let SelectedSchool = {
                id: SelectedItem.schoolId,
                name: SelectedItem.schoolName
            };
            // let ActiveGrade= this.props.D_StandardPerformance_Overview
            this.props.NavigateTo_School_Reports_On_SchoolSelection_from_List(SelectedSchool, SP_Reducer);


        }
    }
    /**
     *
    * @param {Object} Data
    * @param {Object} Nav  -- Navigation related param's
    * @param {Array} ActualArray -- Array which is using to display records
            */

    ReturnColumnBasedOnCurrentNav(Data, Nav, ActualArray) {

        let Field = Nav.S_performance ? "totalQuestions" : "Date Submitted"

        return <div className="student-list-col">
            <span className={LineUnderTheActiveFilteringFiled(Data, Field, Data.Sorting_Type)}>
                {Field == 'totalQuestions' ? "No. of Qns" : Field}

            </span><span className="togglers">
                <i style={{ cursor: "pointer" }}
                    className={Data.Sorting_Column === Field && Data.Sorting_Type === 'desc' ?
                        "material-icons blueColor" : "material-icons"}
                    onClick={() =>
                        Data.Sorting_Column == Field && Data.Sorting_Type == "desc" ? null :
                            this.SortList(Field, 'desc', ActualArray)}
                >expand_more</i>
                <i style={{ cursor: "pointer" }} className={Data.Sorting_Column === Field && Data.Sorting_Type === 'asc' ?
                    "material-icons blueColor" : "material-icons"}
                    onClick={() =>
                        Data.Sorting_Column == Field && Data.Sorting_Type == "asc" ? null :
                            this.SortList(Field, 'asc', ActualArray)}

                > expand_less</i> </span>
        </div>
    }
    /**
    *
    * @param {Object} Data
    * @param {Object} Nav  -- Navigation related param's
    * @param {Array} ActualArray -- Array which is using to display records
    *
    * This will appear when user in school report.
    */
    ReturnColumnForSchoolReport(Data, Nav, ActualArray) {

        if (Nav.S_performance && (Nav.school || Nav.district)) {
            let Field = "% Students Complete";
            return <div className="student-list-col">
                <span className={(Data.Sorting_Column === "studentPectgComplete") ? LineUnderTheActiveFilteringFiled(Data, "studentPectgComplete", Data.Sorting_Type) : LineUnderTheActiveFilteringFiled(Data, Field, Data.Sorting_Type)} style={{ width: 74, float: 'left' }}>
                    {Field}

                    <div className="standard_perfomance_list_head_tooltip" style={{ left: 0 }}>
                        <span className="body_left" style={{ left: 43 }}></span>
                        <span className="body_right">
                            <span className="standard_perfomance_list_head_tooltip_Definition">
                                Students Assessed Online/Students Rostered.
                            </span>
                        </span>
                    </div>

                </span><span className="togglers">
                    <i style={{ cursor: "pointer" }}
                        className={(Data.Sorting_Column === Field || Data.Sorting_Column === "studentPectgComplete") && Data.Sorting_Type === 'desc' ?
                            "material-icons blueColor" : "material-icons"}
                        onClick={() =>
                            Data.Sorting_Column == Field && Data.Sorting_Type == "desc" ? null :
                                this.SortList(Field, 'desc', ActualArray)}
                    >expand_more</i>
                    <i style={{ cursor: "pointer" }} className={(Data.Sorting_Column === Field || Data.Sorting_Column === "studentPectgComplete") && Data.Sorting_Type === 'asc' ?
                        "material-icons blueColor" : "material-icons"}
                        onClick={() =>
                            Data.Sorting_Column == Field && Data.Sorting_Type == "asc" ? null :
                                this.SortList(Field, 'asc', ActualArray)}

                    > expand_less</i> </span>
            </div>
        } else return null
    }

    render() {
        const Data = this.props.Data;
        const Pagination = this.props.pagination;
        let ActualArray = this.props.DataToDisplay == undefined ? [] : this.props.DataToDisplay;
        let Nav = this.props.NavigationByHeaderSelection;

        //API Modified changes
        if (ActualArray.studentTestScoreList != undefined) {
            ActualArray = ActualArray.studentTestScoreList;
        }
        let sortedArray = Data.SortedArray

        const sortedArrayToDisplay = ActualArray.slice(Pagination.countStart, Pagination.countEnd);
        let testscores_length = ActualArray.length;
        let ArrayToDisplay = ActualArray.slice(Pagination.countStart, Pagination.countEnd);

        if (sortedArray != undefined) {

            if (this.props.Data.ActiveHeaderColumn != "all") {
                // if (Nav.class && Nav.T_scores || Nav.district && Nav.T_scores || Nav.school && Nav.T_scores || Nav.student && Nav.T_scores ||
                //     sortedArray.testScoreList !== undefined) {
                //     sortedArray = sortedArray.testScoreList;
                // }

                if (sortedArray.testScoreList !== undefined) {
                    sortedArray = sortedArray.testScoreList;
                }
                testscores_length = sortedArray.length;
                ArrayToDisplay = sortedArray.slice(Pagination.countStart, Pagination.countEnd);

            }
        }
        let classValueForTable = Nav.school ? "col-sm-12 float-left m-0 p-0 class_test_overview_table_list class_list_from_school_context" : "col-sm-12 float-left m-0 p-0 class_test_overview_table_list"

        return (
            <div className={classValueForTable}>
                <div className="student-list-table">
                    <div className="student-list-table-main float-left">
                        <div className="student-list-table">

                            {this.TestScoreDetailsHeaderAndData(ArrayToDisplay, Data, Pagination, ActualArray, testscores_length)}

                        </div>
                    </div>
                </div>
            </div >
        )
    }
}

const mapStateToProps = ({ Authentication, Universal, Reports, schoolReducer, DistrictReducer }) => {
    const { LoginDetails } = Authentication;
    const { AchivementLevels, ContextHeader, NavigationByHeaderSelection, UniversalSelecter } = Universal;
    const { Test_Scores_OverTime, ApiCalls_Reports, StudentsListTable,
        StandardPerformance_Overview } = Reports;

    const { Sc_StandardPerformance_Overview } = schoolReducer;

    const { D_StandardPerformance_Overview } = DistrictReducer;

    return {
        AchivementLevels, LoginDetails, ContextHeader, Test_Scores_OverTime,
        ApiCalls_Reports, StudentsListTable, NavigationByHeaderSelection, UniversalSelecter,
        StandardPerformance_Overview, Sc_StandardPerformance_Overview,
        D_StandardPerformance_Overview
    };
}

export default connect(mapStateToProps, {
    SaveSorted_OverViewStudentList,
    GetCompleteStudentReport, GetCompleteClassReport,
    NavigateTo_School_Reports_On_SchoolSelection_from_List,trackingUsage
})(OverviewDetailStudentList);
/**
 *
* @param {Object} Data  --
* @param {String} columnName  -- Table Column Name
* @param {String} SortType  -- Asc/Desc order
    */
function LineUnderTheActiveFilteringFiled(Data, columnName, SortType) {

    return Data.Sorting_Column == columnName && Data.Sorting_Type == SortType ? "student-list-col-head-name active-student-list-col-head-name" :
        "student-list-col-head-name"

}