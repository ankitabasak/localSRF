import React, { Component, PureComponent } from "react";
import "../../../public/css/style.css";
import { connect } from "react-redux";
import {
  SortArray,
  GetIds_of_Each_Object_In_The_Array,
  AllClassesList,
  Get_Ids_Of_Student_List,
  GetStudentIdsFor_compare,
  getClassAndSchoolListOfStudentData,
} from "../ReusableComponents/AllReusableFunctions";
import ReactHtmlParser from "react-html-parser";
import {
  MoveHeaderIn_Strands_Table,
  GetStudentsListOfstandardOrStrandId,
  GetLineChartDetailsofSelected_Standards,
  toggleClickOnStandardPerformanceFilter,
  Set_StandardPerformanceFilter,
} from "../../Redux_Actions/ReportsActions";
import {
  GetClassDetailsOf_SelectedStrands,
  GetLineChartDetailsofSelected_Standards_OfSchool,
} from "../../Redux_Actions/School_Report_Actions";
import {
  GetSchoolDetailsOf_SelectedStrands,
  GetLineChartDetailsofSelected_Standards_In_District_Report,
} from "../../Redux_Actions/District_Report_Actions";
// import {} from '../../Redux_Actions/UniversalSelectorActions';
import {
  GetLineChartDetailsof_Student_Standards,
  MoveHeaderIn_Students_Strands_Table,
} from "../../Redux_Actions/Student_ReportsAction";
import LoadingScreen from "../../Utils/LoadingScreen/LoadingScreen";
import { isRegExp } from "util";
import { getexact_standard_avg_on_class_student_persist } from "../Common/MainFilter/MainFilter";
import { TeachersList_From_Roster_Details } from "../../Redux_Reducers/U_reducer_functions_to_returnSate";
class Strands_Assessment extends PureComponent {
  constructor(props) {
    super(props);
    this.StradsColumnsList = [];
    this.Stra_Taxonomy_Refs = {};
    this.Stra_Assessed_Refs = {};
    this.Stra_Grades_Refs = {};
    this.state = {
      StrandsRangeArray: [
        {
          id: 4,
          start:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[3]["min"],
          end:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[3]["max"],
          label:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[3]["label"],
        },
        {
          id: 3,
          start:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[2]["min"],
          end:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[2]["max"],
          label:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[2]["label"],
        },
        {
          id: 2,
          start:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[1]["min"],
          end:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[1]["max"],
          label:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[1]["label"],
        },
        {
          id: 1,
          start:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[0]["min"],
          end:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[0]["max"],
          label:
            this.props.AchivementLevels &&
            this.props.AchivementLevels[0]["label"],
        },
      ],
      ActiveSort: "desc",
    };
  }

  componentDidMount() {
    document.addEventListener(
      "mousedown",
      (event) => {
        if (event.target !== null && event.target !== undefined) {
          let Nav = this.props.NavigationByHeaderSelection;

          let test_tab = Nav.class
            ? this.props.stranddetails.StandardPerformanceFilter
            : Nav.school
            ? this.props.Sc_StandardPerformance_Overview
                .StandardPerformanceFilter
            : Nav.district
            ? this.props.D_StandardPerformance_Overview
                .StandardPerformanceFilter
            : this.props.S_StandardPerformance_Overview
                .StandardPerformanceFilter;

          let NavigationForStdFilter = Nav.class
            ? "class"
            : Nav.school
            ? "school"
            : Nav.district
            ? "district"
            : "student";

          if (test_tab.TestAssessment.OpenCloseTestAssessment) {
            if (!this.Stra_Assessed_Refs.contains(event.target)) {
              this.OpenToggleFilterDropDown(
                NavigationForStdFilter,
                "assessment",
                test_tab.TestAssessment.OpenCloseTestAssessment
              );
            }
          } else if (test_tab.TestGrade.OpenCloseTestGrade) {
            if (!this.Stra_Grades_Refs.contains(event.target)) {
              // let NavigationForStdFilter = Nav.class ? 'class' : 'student';
              // this.OpenToggleFilterDropDown(NavigationForStdFilter, "assessment", test_tab.TestAssessment.OpenCloseTestAssessment)
              this.OpenToggleFilterDropDown(
                NavigationForStdFilter,
                "grade",
                test_tab.TestGrade.OpenCloseTestGrade
              );
            }
          } else if (test_tab.Taxonomy.OpenCloseTaxonomy) {
            if (!this.Stra_Taxonomy_Refs.contains(event.target)) {
              // let NavigationForStdFilter = Nav.class ? 'class' : 'student';
              // this.OpenToggleFilterDropDown(NavigationForStdFilter, "assessment", test_tab.TestAssessment.OpenCloseTestAssessment)
              this.OpenToggleFilterDropDown(
                NavigationForStdFilter,
                "taxonomy",
                test_tab.Taxonomy.OpenCloseTaxonomy
              );
            }
          }
        }
      },
      false
    );
  }

  componentWillUnmount() {
    // document.removeEventListener('mousedown', () => { this.props.SetOptionContextHeader(false) }, false)
  }
  /**
   *
   * @param {int} HeaderColumnsCount
   * @param {int} HeaderStart
   *  @param {int}HeaderEnd
   * @returns {string}
   * -- Width of each column will be returned.
   */
  HeadercolumnWidth(HeaderColumnsCount, HeaderStart, HeaderEnd) {
    let totalstrandsCount = HeaderEnd - HeaderStart;
    let removedWidth = totalstrandsCount * 2;

    if (this.props.UserScreenWidth < 1230) {
      if (totalstrandsCount == 4) {
        return (400 - removedWidth) / HeaderColumnsCount;
      } else {
        return (400 - removedWidth) / HeaderColumnsCount;
      }
    } else {
      if (totalstrandsCount == 4) {
        return (600 - removedWidth) / HeaderColumnsCount;
      } else return (600 - removedWidth) / HeaderColumnsCount;
    }
  }
  /**
   *
   * @param {String} strandName --strand name
   * @returns {JSX element/null} -- if the name lenggth is exceed some limit then this will display on hover.
   */
  StrandsTooltipDisplay(strandName) {
    let strandNameResult = null;
    if (strandName !== null && strandName !== undefined) {
      strandName.length > 28
        ? (strandNameResult = (
            <div className="bec_tooltip">
              <div className="bec_tooltip_arrow"></div>
              <div className="bec_tooltip_content">{strandName}</div>
            </div>
          ))
        : null;
    }
    return strandNameResult;
  }

  /**
     * 
     * @param {Object} prevprop -- previous props data 
     * @param {state} nextstate --react component state if you are using.
     * @returns {Boolean} true/false -- return is mandatory. 
     * 
     * if true component will render. 
     * if false component will not render. 
    //  */
  // shouldComponentUpdate(prevprop, nextstate) {
  //     let Nav = this.props.NavigationByHeaderSelection;
  //     let NextState = Nav.class ? this.props.StandardPerformance_Overview :
  //         this.props.S_StandardPerformance_Overview
  //     let PrevState = prevprop.S_StandardPerformance_Overview
  //     let shouldrender = PrevState.StrandNameOfSelectedStandard == NextState.StrandNameOfSelectedStandard && PrevState.selectedStrandId == NextState.selectedStrandId &&
  //         PrevState.ActualList == NextState.ActualList;

  //     return !shouldrender
  // }

  /**
   *
   * @param {String} value -- strand name
   * @returns {String} -- if string lenggth is exceed some number, it will return string will Ellipsis else return as it is.
   */
  StrandsEllipsis(value) {
    if (value === undefined || value === null || value === "") {
      return value;
    } else if (value.length > 28) {
      return value.slice(0, 28) + "...";
    } else return value;
  }

  StandardEllipsis(value) {
    if (value === undefined || value === null || value === "") {
      return value;
    } else if (value.length > 8) {
      return value.slice(0, 8) + "...";
    } else return value;
  }

  /**
   *
   * @param {Object} strand -- Selected Strand Details
   * @param {Array} StrandsList  --Array which contains selected strand.
   *
   */
  OnHeaderSelection(strand, StrandsList) {
    let Token = this.props.LoginDetails.JWTToken;
    let Context_Header = this.props.ContextHeader;
    let Nav = this.props.NavigationByHeaderSelection;
    let strandardsarray = GetIds_of_Each_Object_In_The_Array(
      StrandsList,
      strand.strandName,
      "strands_table"
    );

    let AllTestsSelected = this.props.UniversalSelecter.TestTab.selectAllTests;
    let SelectedTestIds = GetIds_of_Each_Object_In_The_Array(
      this.props.UniversalSelecter.TestTab.SelectedTestList,
      "componentCode",
      "test_tab"
    );
    // let ActualStudents = Context_Header.LastApplyiedMultiStudentsList;

    let SelectedStudents = Context_Header.Roster_Tab.StudentIds;

    let selectedTestAssessment =
      this.props.stranddetails.StandardPerformanceFilter.TestAssessment
        .selectedTestAssessment;
    selectedTestAssessment =
      selectedTestAssessment == "" ? 1 : selectedTestAssessment;

    let GradeObj =
      this.props.stranddetails.StandardPerformanceFilter.TestGrade
        .selectedTestgrade;
    let Grade = GradeObj !== "" && GradeObj !== null ? GradeObj.grade : "";

    let C_Roster = Context_Header.Roster_Tab;
    let SchoolStds;
    let Compare_Std_Ids;
    let Grades;

    if (Nav.district == false) {
      SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      Compare_Std_Ids =
        SchoolStds == undefined || SchoolStds == null
          ? []
          : Get_Ids_Of_Student_List(SchoolStds.filter((item) => item.check));
      if (SchoolStds.length == 0) {
        Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }
    }

    // let comparestdIdss = Get_Ids_Of_Student_List(Context_Header.Roster_Tab.)
    let currentTermId = this.props.currentTermID;
    const { UniversalSelecter,Context_DateTab } = this.props;
		const { SelectedDistrictTerm } = Context_DateTab;
		let classId = C_Roster.SelectedClass.id;
		let startDate = Context_Header.Date_Tab.Report_termStartDate;
		let endDate = Context_Header.Date_Tab.Report_termEndDate;
    let districtId = Context_Header.DistrictId;
		let schoolId = C_Roster.SelectedSchool.id;
		let studentId = Context_Header.Roster_Tab.SelectedStudent.id;

		if (classId == undefined) {
			classId = UniversalSelecter.Roster_Data.SelectedClass.id;
		}
		if (startDate == undefined || startDate == "") {
			startDate = SelectedDistrictTerm.termStartDate;
		}
		if (endDate == undefined || endDate == "") {
			endDate = SelectedDistrictTerm.termEndDate;
		}
    if (districtId == undefined) {
			districtId = Context_Header.Default_districtID;
		}
		if (schoolId == undefined) {
			schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
		}
		if (studentId == undefined) {
			studentId = UniversalSelecter.Roster_Data.SelectedStudent.id;
		}
    const { stranddetails } = this.props;
    const GradeValues = stranddetails.StandardPerformanceFilter.TestGrade;
		if ((Grade == undefined || Grade == "") && GradeValues && GradeValues.TestGradeList && GradeValues.TestGradeList[0]) {
      Grade = GradeValues.TestGradeList[0].grade;
		}
    let ReqPayload = {
      classId: classId,
      schoolId: schoolId,
      districtId: districtId,
      startDate: startDate,
      endDate: endDate,
      standardIds: strandardsarray,
      grade: Grade, // remove or modify later
      rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
      componentCodeList: SelectedTestIds,
      isClass: true,
      isDistrict: true,
      isSchool: true,
      studentId: C_Roster.SelectedStudent.id,
      studentIds: SelectedStudents,
      classIds: C_Roster.ClassIds,
      assessedQuestionsNo: selectedTestAssessment,
      compareStudentIds: !Nav.district ? Compare_Std_Ids : [],
      isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
      currentTermId: currentTermId, // datetab api response first alpha term_id
    };

    let selectedTaxonomy;
    let Sel_Ass_Ques;

    /**
     * We should send student id's to get student detail not to get linechart data,
     * line chart list will return based on component code.
     */
    let Enableloading = true;
    if (Nav.class) {
      // delete ReqPayload.studentIds;
      const AllClassesList_ = AllClassesList(
        Context_Header.Roster_Tab.ClassList
      );
      ReqPayload.classIds = AllClassesList_;
      // delete ReqPayload.schoolIds;

      let updateinStudent =
        this.props.NoData_For_Selection_Universal.NoDataFor_Default_Student;

      selectedTaxonomy =
        this.props.StandardPerformance_Overview.StandardPerformanceFilter
          .Taxonomy.selectedTaxonomy;
      Sel_Ass_Ques =
        this.props.StandardPerformance_Overview.StandardPerformanceFilter
          .TestAssessment.selectedTestAssessment;

      this.props.GetStudentsListOfstandardOrStrandId(
        Token,
        ReqPayload,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading,
        updateinStudent,
        selectedTaxonomy,
        Sel_Ass_Ques
      );
      let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));
      this.props.GetLineChartDetailsofSelected_Standards(
        Token,
        ReqPayloadData,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading
      );
    } else if (Nav.student) {
      // ReqPayload.studentIds = [];
      // ReqPayload.studentId = Context_Header.Roster_Tab.StudentIds[0];
      const AllClassesList_ = AllClassesList(
        Context_Header.Roster_Tab.ClassList
      );
      const AllStudentsList = AllClassesList(
        Context_Header.Roster_Tab.StudentsList
      );

      let clsids =
        Context_Header.Roster_Tab.StudentData_cls_ids.length ==
        Context_Header.Roster_Tab.StudentData_cls.length
          ? []
          : Context_Header.Roster_Tab.StudentData_cls_ids;
      // clsids = clsids.length == 0 ? C_Roster.ClassIds : clsids;

      ReqPayload.studentIds = AllStudentsList;
      // ReqPayload.classIds = AllClassesList_
      ReqPayload.classIds = clsids;
      // delete ReqPayload.studentIds;
      // delete ReqPayload.schoolIds;
      let Sel_Taxonomy =
        this.props.stranddetails.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;
      let Sel_Ques =
        this.props.stranddetails.StandardPerformanceFilter.TestAssessment
          .selectedTestAssessment;

      const { stdDataSelectedClassIds, stdDataSelectedSchoolIds } =
        getClassAndSchoolListOfStudentData(Context_Header.Roster_Tab);
      ReqPayload.stdDataSelectedClassIds = stdDataSelectedClassIds;
      ReqPayload.stdDataSelectedSchoolIds = stdDataSelectedSchoolIds;

      this.props.GetLineChartDetailsof_Student_Standards(
        Token,
        ReqPayload,
        strand.strandId,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
    } else if (Nav.school) {
      // let ClassList = Context_Header.Roster_Tab.ClassIds
      // ReqPayload.classIds = ClassList;
      // delete ReqPayload.studentIds;
      // delete ReqPayload.schoolIds;
      ReqPayload.termId = Context_Header.Date_Tab.selectedTermId;
      let updateinClass = false;
      let Sel_Taxonomy =
        this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter
          .Taxonomy.selectedTaxonomy;
      let Sel_Ques =
        this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter
          .TestAssessment.selectedTestAssessment;
      this.props.GetClassDetailsOf_SelectedStrands(
        Token,
        ReqPayload,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
      let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));
      this.props.GetLineChartDetailsofSelected_Standards_OfSchool(
        Token,
        ReqPayloadData,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading
      );
    } else {
      let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));
      let ApplyiedRosterData = Context_Header.Roster_Tab;

      let updateinClass = false;
      delete ReqPayloadData.classId;
      delete ReqPayloadData.schoolId;
      // delete ReqPayloadData.studentIds;
      delete ReqPayloadData.isClass;
      delete ReqPayloadData.isDistrict;
      delete ReqPayloadData.isSchool;

      ReqPayloadData.rosterGrade =
        Context_Header.Roster_Tab.selectedRosterGrade;
      ReqPayloadData.termId = Context_Header.Date_Tab.selectedTermId;

      let Selected_List = Context_Header.TestTab.TestList.filter(
        (item) => item.check
      );
      let SelectedTestList = GetIds_of_Each_Object_In_The_Array(
        Selected_List,
        "component",
        "test_tab"
      );

      ReqPayloadData.componentCodeList = SelectedTestList;

      let Sc_Ids =
        ApplyiedRosterData.SchoolIds.length ==
        ApplyiedRosterData.schoolsList.length
          ? []
          : ApplyiedRosterData.SchoolIds;

      ReqPayloadData.schoolIds = Sc_Ids;

      let Sel_Taxonomy =
        this.props.stranddetails.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;
      let Sel_Ques =
        this.props.stranddetails.StandardPerformanceFilter.TestAssessment
          .selectedTestAssessment;

      this.props.GetSchoolDetailsOf_SelectedStrands(
        Token,
        ReqPayloadData,
        strand.strandId,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
      this.props.GetLineChartDetailsofSelected_Standards_In_District_Report(
        Token,
        ReqPayloadData,
        "",
        strand.strandAvg,
        strand.strandName,
        null,
        Enableloading
      );
    }
  }
  /**
   * @param {object} standardParent -- stand of selected strandard
   * @param {object} standard  --selected Standard
   */
  OnStandardSelection(standard, standardParent) {
    let Token = this.props.LoginDetails.JWTToken;
    let Context_Header = this.props.ContextHeader;
    let Nav = this.props.NavigationByHeaderSelection;
    // let AllTestsSelected = this.props.UniversalSelecter.TestTab.selectAllTests;

    let SelectedTestsList = Context_Header.TestTab.TestList.filter(
      (item) => item.check
    );

    let SelectedTestIds = GetIds_of_Each_Object_In_The_Array(
      SelectedTestsList,
      "componentCode",
      "test_tab"
    );

    // let ActualStudents = Context_Header.LastApplyiedMultiStudentsList;
    let SelectedStudents =
      // ActualStudents.length == Context_Header.SelectedMultipleStudents.length ? [] :
      Context_Header.Roster_Tab.StudentIds;

    let selectedTestAssessment =
      this.props.stranddetails.StandardPerformanceFilter.TestAssessment
        .selectedTestAssessment;
    selectedTestAssessment =
      selectedTestAssessment == "" ? 1 : selectedTestAssessment;

    let GradeObj =
      this.props.stranddetails.StandardPerformanceFilter.TestGrade
        .selectedTestgrade;
    let Grade = GradeObj !== "" && GradeObj !== null ? GradeObj.grade : "";
    let SchoolStds;
    let Compare_Std_Ids;
    let Grades;
    if (Nav.district == false) {
      SchoolStds =
        this.props.LastActiveUniversalProps.School_Report.StudentList;
      Compare_Std_Ids = Get_Ids_Of_Student_List(
        SchoolStds.filter((item) => item.check)
      );
      if (SchoolStds.length == 0) {
        Grades = this.props.ContextHeader.Roster_Tab.GradesList;
        Compare_Std_Ids = GetStudentIdsFor_compare(Grades);
      }
    }
    let currentTermId = this.props.currentTermID;

    const { UniversalSelecter,Context_DateTab } = this.props;
		const { SelectedDistrictTerm } = Context_DateTab;
		let classId = Context_Header.Roster_Tab.SelectedClass.id;
		let startDate = Context_Header.Date_Tab.Report_termStartDate;
		let endDate = Context_Header.Date_Tab.Report_termEndDate;
    let districtId = Context_Header.DistrictId;
		let schoolId = Context_Header.Roster_Tab.SelectedSchool.id;
		let studentId = Context_Header.Roster_Tab.SelectedStudent.id;

		if (classId == undefined) {
			classId = UniversalSelecter.Roster_Data.SelectedClass.id;
		}
		if (startDate == undefined || startDate == "") {
			startDate = SelectedDistrictTerm.termStartDate;
		}
		if (endDate == undefined || endDate == "") {
			endDate = SelectedDistrictTerm.termEndDate;
		}
    if (districtId == undefined) {
			districtId = Context_Header.Default_districtID;
		}
		if (schoolId == undefined) {
			schoolId = UniversalSelecter.Roster_Data.SelectedSchool.id;
		}
		if (studentId == undefined) {
			studentId = UniversalSelecter.Roster_Data.SelectedStudent.id;
		}
    const { stranddetails } = this.props;
    const GradeValues = stranddetails.StandardPerformanceFilter.TestGrade;
		if ((Grade == undefined || Grade == "") && GradeValues && GradeValues.TestGradeList && GradeValues.TestGradeList[0]) {
      Grade = GradeValues.TestGradeList[0].grade;
		}
    let ReqPayload = {
      classId: classId,
      schoolId: schoolId,
      districtId: districtId,
      startDate: startDate,
      endDate: endDate,
      rosterGrade: Context_Header.Roster_Tab.selectedRosterGrade,
      standardIds:
        standard.nationalStdIds != undefined
          ? standard.nationalStdIds
          : [standard.standardId],
      grade: Grade, // remove or modify later
      componentCodeList: SelectedTestIds,
      studentIds: SelectedStudents,
      classIds: Context_Header.Roster_Tab.ClassIds,
      studentId: studentId,
      isClass: true,
      isDistrict: true,
      isSchool: true,
      assessedQuestionsNo: selectedTestAssessment,
      compareStudentIds: !Nav.district ? Compare_Std_Ids : [],
      isPastDistrictTerm: Context_Header.Date_Tab.isPastDistrictTerm,
      currentTermId: currentTermId, // datetab api response first alpha term_id
    };

    let selectedTaxonomy;
    let Sel_Ass_Ques;

    let Enableloading = true;
    if (Nav.class) {
      let Strand_List =
        this.props.S_StandardPerformance_Overview.ActualList.strands;
      let standardDetails;
      // = getexact_standard_avg_on_class_student_persist(Strand_List, standardParent.strandName, standard);
      let StudentStandard;
      // = standardDetails.UpdatedselectedStandard
      let StudentstrandAvg;
      //  = standardDetails.strandAvg;

      let updateinStudent =
        !this.props.NoData_For_Selection_Universal.NoDataFor_Default_Student;
      delete ReqPayload.studentId;
      const AllClassesList_ = AllClassesList(
        Context_Header.Roster_Tab.ClassList
      );
      ReqPayload.classIds = AllClassesList_;

      selectedTaxonomy =
        this.props.StandardPerformance_Overview.StandardPerformanceFilter
          .Taxonomy.selectedTaxonomy;
      Sel_Ass_Ques =
        this.props.StandardPerformance_Overview.StandardPerformanceFilter
          .TestAssessment.selectedTestAssessment;

      this.props.GetStudentsListOfstandardOrStrandId(
        Token,
        ReqPayload,
        standard.standardId,
        standard.standardAvg,
        standardParent.strandName,
        standard,
        Enableloading,
        updateinStudent,
        selectedTaxonomy,
        Sel_Ass_Ques
      );
      let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));
      this.props.GetLineChartDetailsofSelected_Standards(
        Token,
        ReqPayloadData,
        standard.standardId,
        standard.standardAvg,
        standardParent.strandName,
        standard,
        Enableloading
      );
    } else if (Nav.student) {
      let Strand_List =
        this.props.StandardPerformance_Overview.ActualList.strands;
      // delete ReqPayload.classIds;
      Strand_List = Strand_List == undefined ? [] : Strand_List;
      let standardDetails =
        Strand_List.length > 0
          ? getexact_standard_avg_on_class_student_persist(
              Strand_List,
              standardParent.strandName,
              standard
            )
          : null;
      let ClassStandard =
        standardDetails == null ? "" : standardDetails.UpdatedselectedStandard;
      let ClassstrandAvg =
        standardDetails == null ? "" : standardDetails.strandAvg;

      let updateinClass = true;
      const AllStudentsListOfClass = AllClassesList(
        Context_Header.Roster_Tab.StudentsList
      );
      let clsids =
        Context_Header.Roster_Tab.StudentData_cls_ids.length ==
        Context_Header.Roster_Tab.StudentData_cls.length
          ? []
          : Context_Header.Roster_Tab.StudentData_cls_ids;
      // clsids = clsids.length == 0 ? Context_Header.Roster_Tab.ClassIds : clsids;

      const { stdDataSelectedClassIds, stdDataSelectedSchoolIds } =
        getClassAndSchoolListOfStudentData(Context_Header.Roster_Tab);
      ReqPayload.stdDataSelectedClassIds = stdDataSelectedClassIds;
      ReqPayload.stdDataSelectedSchoolIds = stdDataSelectedSchoolIds;

      ReqPayload.classIds = clsids;
      ReqPayload.studentIds = AllStudentsListOfClass;

      let Sel_Taxonomy =
        this.props.stranddetails.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;
      let Sel_Ques =
        this.props.stranddetails.StandardPerformanceFilter.TestAssessment
          .selectedTestAssessment;

      this.props.GetLineChartDetailsof_Student_Standards(
        Token,
        ReqPayload,
        "",
        standard.standardId,
        standard.standardAvg,
        standardParent.strandName,
        standard,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
    } else if (Nav.school) {
      // let ClassList = Context_Header.Roster_Tab.ClassIds
      // ReqPayload.classIds = ClassList;
      ReqPayload.termId = Context_Header.Date_Tab.selectedTermId;
      let updateinClass = false;
      let Sel_Taxonomy =
        this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter
          .Taxonomy.selectedTaxonomy;
      let Sel_Ques =
        this.props.Sc_StandardPerformance_Overview.StandardPerformanceFilter
          .TestAssessment.selectedTestAssessment;

      this.props.GetClassDetailsOf_SelectedStrands(
        Token,
        ReqPayload,
        standard.standardId,
        standard.standardAvg,
        standardParent.strandName,
        standard,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
      let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));
      this.props.GetLineChartDetailsofSelected_Standards_OfSchool(
        Token,
        ReqPayloadData,
        standard.standardId,
        standard.standardAvg,
        standardParent.strandName,
        standard,
        Enableloading
      );
    } else {
      let ReqPayloadData = JSON.parse(JSON.stringify(ReqPayload));

      let updateinClass = false;
      delete ReqPayloadData.classId;
      delete ReqPayloadData.schoolId;
      // delete ReqPayloadData.studentIds;
      // delete ReqPayloadData.studentIds;
      //delete ReqPayloadData.rosterGrade;
      delete ReqPayloadData.isClass;
      delete ReqPayloadData.isDistrict;
      delete ReqPayloadData.isSchool;

      // let Selected_List = Context_Header.Tests_of_PresentClass.filter(item => item.check)
      // let SelectedTestList = GetIds_of_Each_Object_In_The_Array(Selected_List, 'component', 'test_tab');
      // ReqPayloadData.componentCodeList = SelectedTestList;

      let Sc_Ids =
        Context_Header.Roster_Tab.SchoolIds.length ==
        Context_Header.Roster_Tab.schoolsList.length
          ? []
          : Context_Header.Roster_Tab.SchoolIds;

      ReqPayloadData.schoolIds = Sc_Ids;
      ReqPayloadData.termId = Context_Header.Date_Tab.selectedTermId;
      let Sel_Taxonomy =
        this.props.stranddetails.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;
      let Sel_Ques =
        this.props.stranddetails.StandardPerformanceFilter.TestAssessment
          .selectedTestAssessment;

      ReqPayloadData.termId = Context_Header.Date_Tab.selectedTermId;

      this.props.GetSchoolDetailsOf_SelectedStrands(
        Token,
        ReqPayloadData,
        "",
        standard.standardId,
        standard.standardAvg,
        standardParent.strandName,
        standard,
        Enableloading,
        Sel_Taxonomy,
        Sel_Ques
      );
      this.props.GetLineChartDetailsofSelected_Standards_In_District_Report(
        Token,
        ReqPayloadData,
        "",
        standard.standardId,
        standardParent.strandAvg,
        standardParent.strandName,
        standard,
        Enableloading
      );
    }
  }

  /**
   *
   * @param {object} HeaderDisplay - fetching the strands from the StandardPerformance API
   * @param {object} StrandsReducerObject
   * @return {JSX elements}
   *
   */
  fetchHeaders(HeaderDisplay, StrandsReducerObject) {
    let SP_OverView = StrandsReducerObject;
    let HeaderStart = StrandsReducerObject.headerStart;
    let HeaderEnd = StrandsReducerObject.headerEnd;
    // let StrandsList = StrandsReducerObject.ActualList.strands
    return HeaderDisplay !== undefined
      ? HeaderDisplay.map((object, i) => (
          <div
            key={i}
            style={{
              width: this.HeadercolumnWidth(
                HeaderDisplay.length,
                HeaderStart,
                HeaderEnd
              ),
            }}
            className="overview-table-col"
            key={i}
          >
            <div className="overview-table-innr-grd-col-head-guard">
              <div
                onClick={() => {
                  StrandsReducerObject.StrandNameOfSelectedStandard ==
                    object.strandName &&
                  StrandsReducerObject.selectedstandardObject == null
                    ? null
                    : this.OnHeaderSelection(object, HeaderDisplay);
                }}
                className={
                  "overview-table-col-inr-grd " +
                  HeaderColour(object, SP_OverView, this.props.AchivementLevels)
                }
              >
                {this.StrandsEllipsis(object.strandName)}{" "}
                {this.StrandsTooltipDisplay(object.strandName)}
              </div>

              {object.strandAvg <= this.props.AchivementLevels[0]["max"] ? (
                <div className="overview-table-col-indicator redBg"></div>
              ) : null}
              {object.strandAvg >= this.props.AchivementLevels[1]["min"] &&
              object.strandAvg <= this.props.AchivementLevels[1]["max"] ? (
                <div className="overview-table-col-indicator orangeBg"></div>
              ) : null}
              {object.strandAvg >= this.props.AchivementLevels[2]["min"] &&
              object.strandAvg <= this.props.AchivementLevels[2]["max"] ? (
                <div className="overview-table-col-indicator yellowBg"></div>
              ) : null}
              {object.strandAvg >= this.props.AchivementLevels[3]["min"] ? (
                <div className="overview-table-col-indicator greenBg"></div>
              ) : null}
            </div>
          </div>
        ))
      : null;
  }

  fetchAverages(HeaderDisplay, StrandsReducerObject) {
    let HeaderStart = StrandsReducerObject.headerStart;
    let HeaderEnd = StrandsReducerObject.headerEnd;
    return HeaderDisplay !== undefined
      ? HeaderDisplay.map((strand, i) => (
          <div
            key={i}
            style={{
              width: this.HeadercolumnWidth(
                HeaderDisplay.length,
                HeaderStart,
                HeaderEnd
              ),
            }}
            className="overview-table-col"
          >
            {" "}
            Avg. {strand.strandAvg}%{" "}
          </div>
        ))
      : null;
  }
  Sort_StrandsRangeArray(sortType) {
    let SortedArray = SortArray(this.state.StrandsRangeArray, "id", sortType);
    this.setState({ StrandsRangeArray: SortedArray, ActiveSort: sortType });
  }

  /**
   *
   * @param {string} standardId --
   * @returns {string} background color
   */
  BackGroundColorForStandard(standardId, selectedSrandsDetails) {
    // let selectedSrandsDetails = this.props.StandardPerformance_Overview;
    if (selectedSrandsDetails.selectedStandardId == standardId) {
      let { standRange, standsBarColor } = AchivementLevelsColorsLabels(
        selectedSrandsDetails.selectedStandarAvg,
        this.props.AchivementLevels
      );
      return standsBarColor;
    }
  }

  /**
   * @param {Object} standardParent
   * @param {Object } StrandsRangeitem
   * @param {Object} standard
   * @returns {JSX elements} will return li element .
   */
  ReturnStandardsLiTag(
    StrandsRangeitem,
    standard,
    standardParent,
    selectedSrandsDetails,
    col_index
  ) {
    let strands = this.props.stranddetails.ActualList.strands;
    return Valuebetween(
      parseInt(standard.standardAvg),
      StrandsRangeitem.start,
      StrandsRangeitem.end
    ) ? (
      <li
        onClick={() => {
          selectedSrandsDetails.selectedStandardId == standard.standardId
            ? null
            : this.OnStandardSelection(standard, standardParent);
        }}
        className={
          this.BackGroundColorForStandard(
            standard.standardId,
            selectedSrandsDetails
          ) != null
            ? this.BackGroundColorForStandard(
                standard.standardId,
                selectedSrandsDetails
              )
            : ""
        }
      >
        {" "}
        <span>{this.StandardEllipsis(standard.standardName)}</span>
        <div
          className="standard_perfom_tooltip"
          style={
            strands.length == 1
              ? { left: "25%" }
              : strands.length == 2
              ? { left: "10%" }
              : strands.length == 3
              ? { left: "-18%" }
              : strands.length == 4
              ? { left: "10%" }
              : col_index == 0 || col_index == 1 || col_index == 2
              ? { left: 0 }
              : { right: 0 }
          }
        >
          <span
            className="body_left"
            style={
              strands.length == 1
                ? { left: "46%" }
                : strands.length == 2
                ? { left: "40%" }
                : strands.length == 3
                ? { left: "48%" }
                : strands.length == 4
                ? { left: "20%" }
                : col_index == 0 || col_index == 1 || col_index == 2
                ? { left: 43 }
                : { right: 43 }
            }
          ></span>
          <span className="body_right">
            <span className="strand_Definition">
              {standardParent.strandName}
            </span>
            {standard.standardDef == null ||
            standard.standardDef === "" ||
            standard.standardDef === "null" ? null : (
              <span className="standard_sub_Definition">
                {standard.standardDef}
              </span>
            )}
            <span className="strand_Description">
              <b>{standard.standardName} :</b>{" "}
              {ReactHtmlParser(standard.standardDesc)}
            </span>
          </span>
        </div>
      </li>
    ) : null;
  }
  /**
   *
   * @param {Object} StrandsRangeitem
   * @param {Array} StrandsTableBody --strands DAta
   * @param {Object} strand
   * @returns
   */
  ReturnSortedStandardsList(
    StrandsRangeitem,
    strand,
    selectedSrandsDetails,
    col_index,
    StrandsTableBody
  ) {
    // if (strand.standards !== undefined && strand.standards !== null) {

    if (strand.standards !== undefined && strand.standards !== null) {
      let Sorted_strand = SortArray(
        strand.standards,
        "standardAvg",
        this.state.ActiveSort
      );
      let CurrentTaxonomy =
        this.props.stranddetails.StandardPerformanceFilter.Taxonomy
          .selectedTaxonomy;
      // Sorted_strand = Sorted_strand.filter(strand => strand.taxonomy == CurrentTaxonomy);
      let CurrentRageVal_IsThere = Sorted_strand.find((item) => {
        return (
          StrandsRangeitem.end >= parseInt(item.standardAvg) &&
          StrandsRangeitem.start <= parseInt(item.standardAvg)
        );
      });

      /**
       * if no item is there with in the range , will return <li> tag
       * if CurrentRageVal_IsThere is undefined  means there is no value with in the range (ex: 40>,50-69 etc..)
       */
      if (CurrentRageVal_IsThere !== undefined) {
        return Sorted_strand.map((standard, i) => {
          return this.ReturnStandardsLiTag(
            StrandsRangeitem,
            standard,
            strand,
            selectedSrandsDetails,
            col_index
          );
        });
      } else {
        return <li className="StandardsNotAvailable">&nbsp;</li>;
      }
    } else return <li className="StandardsNotAvailable">&nbsp;</li>;
  }

  /**
   *
   * @param {int} StrandsRangeitem -- Strands Progress Bar Range
   * @param {Array} HeaderDisplay
   * @param {colour code} standsBarColor
   * @param {object} StrandsTableBody --strans Table
   * @returns {JSX elements}
   */
  ReturnInnerStrandards(
    StrandsRangeitem,
    HeaderDisplay,
    standsBarColor,
    selectedSrandsDetails,
    StrandsTableBody
  ) {
    return HeaderDisplay.map((item, i) => {
      return (
        <div key={i} className="overview-table-col">
          <ul>
            {this.ReturnSortedStandardsList(
              StrandsRangeitem,
              item,
              selectedSrandsDetails,
              i,
              StrandsTableBody
            )}
          </ul>
        </div>
      );
    });
  }
  /**
   * @param {Array}  HeaderDisplay -- Strands List To Display
   * @param {Object} selectedSrandsDetails --which contains all reducer details of Strands
   * @param {Array} HeaderDisplay --strands Array
   * @returns {JSX elements}
   * Strands Main Body View
   */
  StrandsTableBody(HeaderDisplay, selectedSrandsDetails, AchivementLevels) {
    return this.state.StrandsRangeArray.map((item, idx) => {
      let { standRange, standsBarColor } = AchivementLevelsColorsLabels(
        item.end,
        AchivementLevels
      );
      return (
        <div className="overview-table-row" key={idx}>
          <div className="overview-table-col">
            <span> {standRange} </span>
          </div>
          <div className={"overview-table-col " + standsBarColor}>
            <div className="performance-indicator"> &nbsp; </div>
          </div>
          {this.ReturnInnerStrandards(
            item,
            HeaderDisplay,
            standsBarColor,
            selectedSrandsDetails
          )}
        </div>
      );
    });
  }
  /**
   *
   * @param {string} motion  -- MOving Direction
   */
  MoveHeader(motion) {
    let Nav = this.props.NavigationByHeaderSelection;

    if (Nav.class || Nav.school || Nav.district) {
      let FromClass = Nav;

      this.props.MoveHeaderIn_Strands_Table(motion, FromClass);
    } else if (Nav.student) {
      this.props.MoveHeaderIn_Students_Strands_Table(motion);
    }
  }

  // standard performance filter block

  OpenToggleFilterDropDown(fromWhere, fromWhichDropdown, status) {
    this.props.toggleClickOnStandardPerformanceFilter(
      fromWhere,
      fromWhichDropdown,
      status
    );
  }
  selectToggleFilterDropDown(fromWhere, fromWhichDropdown, filterSelectedData) {
    this.props.Set_StandardPerformanceFilter(
      fromWhere,
      fromWhichDropdown,
      filterSelectedData
    );
  }

  // standard performance filter block
  tooptipDisplay(tooltipName) {
    let contextTooltip = null;
    if (tooltipName !== null && tooltipName !== undefined) {
      tooltipName.length > 20
        ? (contextTooltip = (
            <div className="bec_tooltip">
              <div className="bec_tooltip_arrow"></div>
              <div className="bec_tooltip_content">{tooltipName}</div>
            </div>
          ))
        : null;
    }

    return contextTooltip;
  }
  /**
   * will return Ui Based ON Conditions
   * @param {Object} TestAssessedQuestion
   * @param {Object} TestGrade
   * @param {Object} NavigationForStdFilter
   * @param {Array} testAssessedQuestionList
   * @returns {JSX}
   */
  TestGradeView(
    TestGrade,
    TestAssessedQuestion,
    NavigationForStdFilter,
    testAssessedQuestionList,
    Taxonomy
  ) {
    return (
      <div className="standard-access-grid">
        <div className="standard-access-grid-inr">
          {/* Taxonomy UI */}

          {Taxonomy.TaxonomyList.length > 0 ? (
            <div className="standard-grid-filter-view">
              <div className="standard-grid-filter-view-label">View : </div>
              <div
                className="standard-grid-filter-view-filter-block"
                ref={(ref) =>
                  ref !== null ? (this.Stra_Taxonomy_Refs = ref) : null
                }
              >
                <button
                  onClick={() =>
                    this.OpenToggleFilterDropDown(
                      NavigationForStdFilter,
                      "taxonomy",
                      Taxonomy.OpenCloseTaxonomy
                    )
                  }
                  className={
                    Taxonomy.OpenCloseTaxonomy &&
                    Taxonomy.TaxonomyList.length > 1
                      ? "standard-grid-filter-view-filter-activated"
                      : null
                  }
                  style={{
                    background:
                      Taxonomy.TaxonomyList.length === 1 ? "#fff" : null,
                  }}
                >
                  {dropDownEllipsis(Taxonomy.selectedTaxonomy)}
                  {this.tooptipDisplay(Taxonomy.selectedTaxonomy)}
                </button>
                {Taxonomy.OpenCloseTaxonomy &&
                Taxonomy.TaxonomyList.length > 1 ? (
                  <div
                    className="standard-grid-filter-view-filter-block-inr"
                    ref={(node) => (this.Stra_Taxonomy_Refs = node)}
                  >
                    <div className="standard-grid-filter-view-filter-block-inr-main">
                      <ul className="standard-grid-filter-ui-dropdown-list">
                        {Taxonomy.TaxonomyList.map((single_taxonomy, idx) => (
                          <li
                            key={idx}
                            onClick={() => {
                              if (
                                single_taxonomy == Taxonomy.selectedTaxonomy
                              ) {
                                return null;
                              } else {
                                this.selectToggleFilterDropDown(
                                  NavigationForStdFilter,
                                  "taxonomy",
                                  single_taxonomy
                                ); //grade
                              }
                            }}
                            className={
                              single_taxonomy == Taxonomy.selectedTaxonomy
                                ? "activeStandardFilter"
                                : null
                            }
                          >
                            <div className="standard-grid-filter-single-item">
                              {dropDownEllipsis(single_taxonomy)}
                              {this.tooptipDisplay(single_taxonomy)}
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
          ) : null}

          {/* Taxonomy UI */}

          {/* Grade Filter Dropdown */}
          {TestGrade.TestGradeList.length > 1 ? (
            <div className="standard-grid-filter-view">
              <div
                className="standard-grid-filter-view-label"
                style={{ position: "relative" }}
              >
                Test(s) assessed for:
                <div
                  className="test_assessedFor_perfom_tooltip"
                  style={{ left: "-2%" }}
                >
                  <span className="body_left" style={{ left: "3%" }}></span>
                  <span className="body_right">
                    <span className="strand_Description">
                      Access to student test data outside of grade level.
                    </span>
                  </span>
                </div>
              </div>
              <div
                className="standard-grid-filter-view-filter-block"
                ref={(ref) => (this.Stra_Grades_Refs = ref)}
              >
                <button
                  onClick={() =>
                    TestGrade.TestGradeList.length > 1
                      ? this.OpenToggleFilterDropDown(
                          NavigationForStdFilter,
                          "grade",
                          TestGrade.OpenCloseTestGrade
                        )
                      : null
                  }
                  className={
                    TestGrade.OpenCloseTestGrade
                      ? "standard-grid-filter-view-filter-activated"
                      : null
                  }
                  style={{
                    background:
                      TestGrade.TestGradeList.length == 1 ? "#fff" : null,
                  }}
                >
                  {TestGrade.selectedTestgrade !== "" &&
                  TestGrade.selectedTestgrade !== undefined
                    ? convertGrade(TestGrade.selectedTestgrade.grade)
                    : "Grade"}
                </button>
                {TestGrade.OpenCloseTestGrade &&
                TestGrade.TestGradeList.length > 1 ? (
                  <div
                    className="standard-grid-filter-view-filter-block-inr"
                    // ref={(node) => this.Stra_Grades_Refs = node}
                  >
                    <div className="standard-grid-filter-view-filter-block-inr-main">
                      <ul className="standard-grid-filter-ui-dropdown-list">
                        {TestGrade.TestGradeList.map((LoopGrade, i) => {
                          return (
                            <li
                              key={i}
                              className={
                                TestGrade.selectedTestgrade.grade ==
                                LoopGrade.grade
                                  ? "activeStandardFilter"
                                  : null
                              }
                              onClick={() => {
                                if (
                                  LoopGrade.grade ==
                                  TestGrade.selectedTestgrade.grade
                                ) {
                                  return null;
                                } else {
                                  this.selectToggleFilterDropDown(
                                    NavigationForStdFilter,
                                    "grade",
                                    LoopGrade
                                  ); //grade
                                }
                              }}
                            >
                              <div className="standard-grid-filter-single-item">
                                {LoopGrade.grade.split("_")[1] === 10
                                  ? "Grade 10+"
                                  : convertGrade(LoopGrade.grade)}
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                ) : null}
                {/* end of dropd down */}
              </div>
            </div>
          ) : null}

          {/* Grade Filter Dropdown End */}

          {/* Assessed Question Filter Dropdown */}

          {TestAssessedQuestion.MaxTestAssessmentCount > 1 ? (
            <div className="standard-grid-filter-view">
              <div className="standard-grid-filter-view-label">
                Assessed with:{" "}
              </div>
              <div
                className="standard-grid-filter-view-filter-block"
                ref={(ref) =>
                  ref !== null ? (this.Stra_Assessed_Refs = ref) : null
                }
              >
                <button
                  onClick={
                    testAssessedQuestionList.length > 1
                      ? () =>
                          this.OpenToggleFilterDropDown(
                            NavigationForStdFilter,
                            "assessment",
                            TestAssessedQuestion.OpenCloseTestAssessment
                          )
                      : null
                  }
                  className={
                    TestAssessedQuestion.OpenCloseTestAssessment
                      ? "standard-grid-filter-view-filter-activated"
                      : null
                  }
                  style={{
                    background:
                      testAssessedQuestionList.length === 1 ? "#fff" : null,
                  }}
                >
                  {TestAssessedQuestion.selectedTestAssessment + "+ questions"}
                </button>
                {TestAssessedQuestion.OpenCloseTestAssessment &&
                testAssessedQuestionList.length > 1 ? (
                  <div
                    className="standard-grid-filter-view-filter-block-inr"
                    ref={(node) => (this.Stra_Assessed_Refs = node)}
                  >
                    <div className="standard-grid-filter-view-filter-block-inr-main">
                      <ul className="standard-grid-filter-ui-dropdown-list">
                        {testAssessedQuestionList.map((questionNumber, i) => {
                          return (
                            <li
                              key={i}
                              className={
                                TestAssessedQuestion.selectedTestAssessment ==
                                questionNumber
                                  ? "activeStandardFilter"
                                  : null
                              }
                              onClick={() =>
                                TestAssessedQuestion.selectedTestAssessment ==
                                questionNumber
                                  ? null
                                  : this.selectToggleFilterDropDown(
                                      NavigationForStdFilter,
                                      "assessment",
                                      questionNumber
                                    )
                              }
                            >
                              <div className="standard-grid-filter-single-item">
                                {questionNumber + "+ questions"}
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                ) : null}
                {/* end of dropd down */}
              </div>
            </div>
          ) : null}

          {/* End of Assessed Question Filter    Dropdown */}
        </div>
      </div>
    );
  }

  render() {
    let Standards = this.props.stranddetails.ActualList.strands;

    let StrandsReducerObject = this.props.stranddetails;
    let start = this.props.stranddetails.headerStart;
    let end = this.props.stranddetails.headerEnd;
    this.StradsColumnsList = [];
    let HeaderColumnCount = end - start;
    let HeaderListlength = Standards !== undefined ? Standards.length : 0;
    let showArrows =
      this.props.UserScreenWidth > 1230
        ? HeaderListlength > 6
          ? true
          : false
        : HeaderListlength > 4
        ? true
        : false;

    let HeaderDisplay =
      Standards !== undefined ? Standards.slice(start, end) : Standards;
    let ApiCallReports = this.props.Apicalls;
    // let U_Apis = this.props.U_Apis == undefined ? {} : this.props.U_Apis
    let Nav = this.props.NavigationByHeaderSelection;
    let NavigationForStdFilter = Nav.class
      ? "class"
      : Nav.school
      ? "school"
      : Nav.district
      ? "district"
      : "student";
    // let ClassApiCallReports = this.props.ApiCalls_Reports;

    let standardFilter = this.props.stranddetails.StandardPerformanceFilter;

    let TestGrade = standardFilter.TestGrade; // [0,1,2,3];//
    let TestAssessedQuestion = standardFilter.TestAssessment;
    let testAssessedQuestionList = [];
    for (var p = 1; p <= TestAssessedQuestion.MaxTestAssessmentCount; p++) {
      testAssessedQuestionList.push(p);
    }

    let Taxonomy = standardFilter.Taxonomy;
    if (ApiCallReports.loading_on_strands_table == undefined) {
      ApiCallReports.loading_on_strands_table = false;
    }
    // let StrandsTableBody = Standards;
    // TestGrade.TestGradeList = [0,1,2,3]; // we have to delete this for now

    return (ApiCallReports.loading_on_strands_table && Nav.student) ||
      this.props.ApiCalls.loadingFor == "tests" ||
      (this.props.ApiCalls.loadingFor == "grade" &&
        this.props.UniversalFilter !== "roster") ||
      (ApiCallReports.loading_Strands_table &&
        (Nav.class || Nav.school || Nav.district)) ||
      this.props.stranddetails.ActualList.length == 0 ||
      enableLoaderOnGetTests_Dates_Grades_OfContext(this.props.ApiCalls, Nav) ||
      ApiCallReports.get_Sp_Assessed_Ques ? (
      <LoadingScreen />
    ) : (
      <div className="bec-standards-overview-left-fullwidth">
        {/* Start Test grade Dropdown */}

        {this.TestGradeView(
          TestGrade,
          TestAssessedQuestion,
          NavigationForStdFilter,
          testAssessedQuestionList,
          Taxonomy
        )}

        {/* End test Grade DropDown */}

        <div
          className="standard-overview-table"
          style={{ position: "relative" }}
        >
          {/* Should be added here */}
          {/* {(ApiCallReports.loading_on_strands_table && Nav.student) || this.props.ApiCalls.loadingFor == "tests" ||
                        (this.props.ApiCalls.loadingFor == "grade" && this.props.UniversalFilter !== "roster") ||
                        (ApiCallReports.loading_Strands_table && (Nav.class || Nav.school || Nav.district)) ||
                        this.props.stranddetails.ActualList.length == 0 || enableLoaderOnGetTests_Dates_Grades_OfContext(this.props.ApiCalls, Nav) ?
                        <LoadingScreen /> : */}
          <div className="standard-overview-table-inr">
            <div className="standard-overview">
              <div className="overview-table-left">
                <div className="overview-table-left-outer">
                  <div className="overview-table-left-inner text-rotate">
                    Achievement Level
                  </div>
                </div>
              </div>
              <div className="overview-table-right">
                <div className="overview-table-main">
                  <div className="overview-table-header">
                    <div
                      className="overview-table-bar"
                      // style={{ width: HeaderColumnCount < 5 ? '70%' : '100%' }}
                    >
                      <div className="overview-table-col"> &nbsp; </div>
                      <div
                        className="overview-table-col data-middle-aligner text-left"
                        style={{ width: "20px", height: "88px" }}
                      >
                        <span
                          className={
                            start == 0
                              ? "scroll-left scroll-disable"
                              : "scroll-left scroll-active"
                          }
                        >
                          <i
                            className="material-icons"
                            style={{
                              cursor: "Pointer",
                              visibility: showArrows ? "visible" : "hidden",
                            }}
                            onClick={() =>
                              start == 0 ? null : this.MoveHeader("left")
                            }
                          >
                            {" "}
                            chevron_left{" "}
                          </i>
                        </span>
                      </div>
                      {this.fetchHeaders(HeaderDisplay, StrandsReducerObject)}

                      <div
                        className="overview-table-col data-middle-aligner text-right"
                        style={{ width: "20px", height: "88px" }}
                      >
                        <span
                          className={
                            end == HeaderListlength || HeaderListlength < end
                              ? "scroll-left scroll-disable"
                              : "scroll-left scroll-active"
                          }
                        >
                          <i
                            className="material-icons"
                            style={{
                              cursor: "Pointer",
                              visibility: showArrows ? "visible" : "hidden",
                            }}
                            onClick={() =>
                              end == HeaderListlength || HeaderListlength < end
                                ? null
                                : this.MoveHeader("right")
                            }
                          >
                            {" "}
                            chevron_right{" "}
                          </i>
                        </span>
                      </div>
                    </div>
                    <div className="overview-table-bar avarage-bar">
                      <div className="overview-table-col"> &nbsp; </div>
                      <div className="overview-table-col text-left">
                        <span
                          className={
                            this.state.ActiveSort == "desc"
                              ? "greenColor"
                              : "redColor"
                          }
                        >
                          <i
                            className="material-icons"
                            style={{ cursor: "pointer" }}
                            onClick={() => this.Sort_StrandsRangeArray("desc")}
                          >
                            {" "}
                            arrow_drop_up{" "}
                          </i>
                        </span>
                        <span
                          className={
                            this.state.ActiveSort == "asc"
                              ? "greenColor"
                              : "redColor"
                          }
                        >
                          <i
                            className="material-icons"
                            style={{ cursor: "pointer" }}
                            onClick={() => this.Sort_StrandsRangeArray("asc")}
                          >
                            {" "}
                            arrow_drop_down{" "}
                          </i>
                        </span>
                      </div>
                      {this.fetchAverages(HeaderDisplay, StrandsReducerObject)}
                    </div>
                  </div>
                  <div
                    className="overview-table-body"
                    // style={{ width: HeaderColumnCount < 5 ? '70%' : '100%' }}
                  >
                    {HeaderDisplay !== undefined && HeaderDisplay !== null
                      ? this.StrandsTableBody(
                          HeaderDisplay,
                          StrandsReducerObject,
                          this.props.AchivementLevels
                        )
                      : null}
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* } */}
        </div>
      </div>
    );
  }
}

const mapStateToProps = ({
  Authentication,
  Reports,
  StudentReports,
  Universal,
  schoolReducer,
  DistrictReducer,
  LastActiveUniversalProps,DateTabReducer
}) => {
  const { LoginDetails } = Authentication;
  const { Class, StandardPerformance_Overview, ApiCalls_Reports } = Reports;
  const { S_StandardPerformance_Overview, S_ApiCalls } = StudentReports;
  const {
    AchivementLevels,
    ContextHeader,
    NavigationByHeaderSelection,
    UniversalSelecter,
    UserScreenWidth,
    NoData_For_Selection_Universal,
    ApiCalls,
    UniversalFilter,
    currentTermID,
  } = Universal;
  const { Context_DateTab } = DateTabReducer;
  const { Sc_StandardPerformance_Overview, Sc_ApiCalls } = schoolReducer;
  const { D_ApiCalls, D_StandardPerformance_Overview } = DistrictReducer;

  return {
    AchivementLevels,
    Class,
    LoginDetails,
    StandardPerformance_Overview,
    ApiCalls_Reports,
    ContextHeader,
    NavigationByHeaderSelection,
    S_StandardPerformance_Overview,
    S_ApiCalls,
    UniversalSelecter,
    UserScreenWidth,
    NoData_For_Selection_Universal,
    ApiCalls,
    Sc_StandardPerformance_Overview,
    Sc_ApiCalls,
    D_ApiCalls,
    D_StandardPerformance_Overview,
    ApiCalls,
    LastActiveUniversalProps,
    UniversalFilter,
    currentTermID,
    Context_DateTab
  };
};
export default connect(mapStateToProps, {
  MoveHeaderIn_Strands_Table,
  GetStudentsListOfstandardOrStrandId,
  GetLineChartDetailsofSelected_Standards,
  // toggleClickOnTestDropDown,
  // toggleClickOnTestAssessedDropDown,
  // selectedTestAssessedDropDownStandardPerformance,
  // selectedTestDropDownStandardPerformance,
  toggleClickOnStandardPerformanceFilter,
  Set_StandardPerformanceFilter,
  GetLineChartDetailsof_Student_Standards,
  MoveHeaderIn_Students_Strands_Table,

  GetClassDetailsOf_SelectedStrands,
  GetLineChartDetailsofSelected_Standards_OfSchool,
  GetSchoolDetailsOf_SelectedStrands,
  GetLineChartDetailsofSelected_Standards_In_District_Report,
})(Strands_Assessment);

/**
 *
 * @param {Object} item
 * @returns {String}
 * returns the range of Strandareds Progress Bar Name.
 */
function RowValue(item) {
  let standRange, standsBarColor;
  if (item == "39" || item < "39") {
    standRange = "\u003C" + " " + "40%";
    standsBarColor = "redBg";
    return { standRange, standsBarColor };
  } else if (item == "59" || item < "59") {
    standRange = "40-59%";
    standsBarColor = "orangeBg";
    return { standRange, standsBarColor };
  } else if (item == "79" || item < "79") {
    standRange = "60-79%";
    standsBarColor = "yellowBg";
    return { standRange, standsBarColor };
  } else if (item == "100" || item < 100) {
    standRange = "\u2265" + " " + "80%";
    standsBarColor = "greenBg";
    return { standRange, standsBarColor };
  } else {
    standRange = "";
    standsBarColor = "";
    return { standRange, standsBarColor };
  }
}
/**
 *
 * @param {Object} item
 * @returns {String}
 * returns the range of Strandareds Progress Bar Name.
 */
function AchivementLevelsColorsLabels(item, AchivementLevels) {
  let standRange, standsBarColor;
  if (item == AchivementLevels[0]["max"] || item < AchivementLevels[0]["max"]) {
    standRange = "\u003C" + " " + AchivementLevels[0]["label"] + "%";
    standsBarColor = "redBg";
    return { standRange, standsBarColor };
  } else if (
    item == AchivementLevels[1]["max"] ||
    item < AchivementLevels[1]["max"]
  ) {
    standRange = AchivementLevels[1]["label"] + "%";
    standsBarColor = "orangeBg";
    return { standRange, standsBarColor };
  } else if (
    item == AchivementLevels[2]["max"] ||
    item < AchivementLevels[2]["max"]
  ) {
    standRange = AchivementLevels[2]["label"] + "%";
    standsBarColor = "yellowBg";
    return { standRange, standsBarColor };
  } else if (
    item == AchivementLevels[3]["max"] ||
    item < AchivementLevels[3]["max"]
  ) {
    standRange = "\u2265" + " " + AchivementLevels[3]["label"] + "%";
    standsBarColor = "greenBg";
    return { standRange, standsBarColor };
  } else {
    standRange = "";
    standsBarColor = "";
    return { standRange, standsBarColor };
  }
}
/**
 *
 * @param {int} value
 * @param {int} min
 * @param {int} max
 * @returns {Boolean}
 * if value is with in the range -- true
 * else -- false
 */
function Valuebetween(value, min, max) {
  return value >= min && value <= max;
}

/**
 *
 * @param {Object} strand  -- Strand Header Details
 * @param {Object} SP_Overview --Standard Performance Overview Details.
 * @returns {String} -- will return background.
 */
function HeaderColour(strand, SP_Overview, AchivementLevels) {
  // if (SP_Overview.selectedStandardId !== ''|| SP_Overview.selectedStandardId !== undefined||SP_Overview.selectedStandardId !== null) {
  //     return "";
  // } else
  if (
    strand.strandName == SP_Overview.StrandNameOfSelectedStandard &&
    SP_Overview.selectedStandardId === ""
  ) {
    return strand.strandAvg <= AchivementLevels[0]["max"]
      ? "redBg"
      : strand.strandAvg <= AchivementLevels[1]["max"]
      ? "orangeBg"
      : strand.strandAvg <= AchivementLevels[2]["max"]
      ? "yellowBg"
      : strand.strandAvg <= AchivementLevels[3]["max"]
      ? " greenBg"
      : "";
  }
}

/**
 *
 * @param {string} value  --value to display on context header.
 * @returns {string}  -- if string exceeds certain length ellipsis will be applied.
 */
function dropDownEllipsis(value) {
  if (value === undefined || value === null || value === "") {
    return value;
  } else if (value.length > 20) {
    return value.slice(0, 20) + "...";
  } else return value;
}

/**
 *
 * @param {Object} ApiCalls
 * @param {Object} Nav
 * @returns {Boolean}
 */
function enableLoaderOnGetTests_Dates_Grades_OfContext(ApiCalls, Nav) {
  // if (Nav.class) {

  //     return ApiCalls.get_C_Grades_Alias

  // } else {
  return false;
  // }
}

function convertGrade(grade) {
  const value = grade.toString();
  const value2 = value.split("_")[1];
  return `Grade ${value2}`;
}
