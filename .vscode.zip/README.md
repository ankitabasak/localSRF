# socrates-reporting-frontend
ReactJS frontend app for eAssessments Reporting

## Requirements
For development, you will only need Node.js installed on your environement.
And please use the appropriate [Editorconfig](http://editorconfig.org/) plugin for your Editor (not mandatory).

### Node
[Node](http://nodejs.org/) is really easy to install & now include [NPM](https://npmjs.org/).
You should be able to run the following command after the installation procedure
below.

    $ node --version
    v11.2.0

    $ npm --version
    6.4.1

#### Node installation on MacOS

You will need to use a Terminal. On OS X, you can find the default terminal in
`/Applications/Utilities/Terminal.app`.

Please install [Homebrew](http://brew.sh/) if it's not already done with the following command.

    $ ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)"

If everything when fine, you should run
    brew install node

#### Node installation on Linux
    sudo apt-get install python-software-properties
    sudo add-apt-repository ppa:chris-lea/node.js
    sudo apt-get update
    sudo apt-get install nodejs

#### Node installation on Windows

Just go on [official Node.js website](http://nodejs.org/) & grab the installer.
Also, be sure to have `git` available in your PATH, `npm` might need it.

## Install
    $ git clone https://github.com/benchmarkeducation/socrates-reporting-frontend.git
    $ cd socrates-reporting-frontend
    $ npm install

## Start
    $ npm start
    
## Build for release
    $ npm run build
   
## Update sources
Some packages usages might change so you should run `npm prune` & `npm install` often.
A common way to update is by doing
    $ git pull
    $ npm prune
    $ npm install

To run those 3 commands you can just do
    $ npm run pull
    

---

## Languages & tools

### HTML
- Plain HTML for some templating.

### CSS
- [SCSS](https://sass-lang.com/) is CSS compiler used for generating Dynamic CSS.

### JavaScript
- [React](http://facebook.github.io/react) is used for UI.

# Deployment to AWS S3
   
   Under socrates-reporting-frontend/.circleci/ the config.yaml has the script for CI/CD on AWS S3 bucket.
 
   Project code checked in to the repositry is first built/. Resulting artifact (contents of build folder) is pushed to S3        bucket.
	
   A CICD trigger has been enabled on the GIT repo. The branch to which the code is being merged to is very important in     	deciding which environment the code will be deployed to. For example if you merge code to "develop" branch the CICD 	    	pipeline will deploy to the AWS DEV environment.
   
## .env files (Added 9/12/19)

Since we have different environment deployments occurring, the CI script has been updated to pull the correct .env values depending on which branch is being deployed. This is possible due to having multiple .env files in the root of the repository. As of today, these files are expected by CI.

- .env.ar-develop
- .env.orr-develop

An .env.ar-sandbox has been added so that the sandbox environment can have seperate deployment parameters. For local development you can copy the configurations you want into a .env file.

**DO NOT DELETE THESE FILES.**


# Delete / Create tag for the release to staging or production

git tag --delete <tagname>
git push origin :refs/tags/<tagname>

git tag <tagname>
git push origin <tagname>


# Standalone Mode
In order to get the Login screen to display, a new env variable has been set up called STANDALONE_MODE. When this value is set to true it will enable to Login screen to be displayed. The route for the login screen will be /. If this value is false or not in the env, and a user goes to the Login route, it will redirect them to the Main.js file which will then handle which page the user should see. If you a passing in the JWTToken versus using the Login screen this value should be set to false.

## MicroFrontend set up utilizing webpack 5 Module Federation
This app has been updated to allow for developing this application as a microfrontend. To learn more about Module Federation [click here](https://module-federation.github.io/blog/get-started) .

### Development environment set up
In order to for module federation to work within the application, the .env.development file needs to be updated **BEFORE** you build the application.

The `BASE_URL` field needs to be updated with url this application in your development environment. This is required in order for when modules are being imported by other apps, the code knows to look for the files at this host vs the launching applications host.

If being used in Benchmark provided dockers, the development envs are pre populated with the set up urls. The only things that needs to be changed is the `%%urlinfix%%` value in the url. This value should be replaced with the developers personal prefix with a dash in front.

```
BASE_URL=https://reporting%%urlinfix%%.benchmarkuniverse.com

changed to 

BASE_URL=https://reporting-jdoe.benchmarkuniverse.com
```

### How to add new modules to be federated

1. Open webpack.config.js
2. Look for the Module Federation option in the plugins setting.
3. Look for the `exposes` key.
4. In this key, you will add the new module you want to federate. It must follow the following pattern.
    ```
   {
      ...,
      './<name to import module as>': '<path to module>'
   }
   ```
   The key of the module must have `./` in front of it, as per Module Federation rules.

Once this is set up the next time you build the application, this module will be federated and other webpack 5 enabled apps will be able to import the module.

### How to use modules from other applications
In order, to use modules from other apps, two things needs to happen.

#### Adding the federated module to the app
 add a reference to the url for the module federartion entry file. This is done by adding a `remotes` key to the Module Federartion plugin configuration object. The value for the `remotes` key is an object. The pattern for the items in the array are follow as such:
In this key, you will add the new module you want to federate. It must follow the following pattern.
```
{
...,
'./<name to import module as>': '<name specified in the federated application>@<the url to the federated app>'
}

Example
remotes: {
    'bu-usage-reporting-ui': 'bu_usage_reporting_ui@https://usage.example.com/remoteEntry.js',
        }
```

In order to allow for easy changing of urls, the urls should be set up within the .env. When setting up the code to use this new url, you will do the following.

```javascript
{
  'bu-usage-reporting-ui': 'bu_usage_reporting_ui@' + process.env.<KEY IN ENV> + '/remoteEntry.js'
}

Working example
{
  'bu-usage-reporting-ui': 'bu_usage_reporting_ui@' + process.env.BUUR_URL + '/remoteEntry.js'
}
```


#### Using modules from the federated app
Once the remote has been set up, the module can be imported. The importing of the module should occur in an async manner. React provides some utilities that make this easier.

To import the component, you can follow this syntax 
```javascript
const Module = React.lazy(() => import('<key of import>/<module to import'));

Example
const BUURApp = React.lazy(() => import('bu-usage-reporting-ui/App'));
```

Since the module is being loaded asynchronously, React allows for use a utilly component for loading of asynchronous components. 

```javascript
    <React.Suspense fallback={<p>Loading BUUR</p>} >
```

The fallback component is what is displayed until the component is loaded and rendered.
