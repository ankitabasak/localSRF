// Local development Url

// APP_ENV=development
// #ATLANTIS_HOST=https://atlantis-api.cf:8080/api/v1/auth/create-token
// ATLANTIS_HOST=http://18.234.241.108:8080/api/v1/auth/create-token
// #BASE_MICROSERVICE_URL=https://buapi-staging.benchmarkuniverse.com/api/v1/
// #BASE_MICROSERVICE_URL=http://localhost:5020/api/v1/
// BASE_MICROSERVICE_URL=http://3.209.211.220:5020/api/v1/
// ACCESSIBLE_REPORTS=http://18.234.241.108:8080/api/v1/user/skus
// ORR_REPORTING_MICROSERVICE_URL = https://cors-anywhere.herokuapp.com/http://3.209.211.220:8060/api/v1/
// PROXY_URL = https://cors-anywhere.herokuapp.com/
// LMS2_BASE_URL=/#:
// STANDALONE_MODE=true

// Staging Url added by kevin

// APP_ENV=development
// ATLANTIS_HOST=https://atlantis-api.cf:8080/api/v1/auth/create-token
// BASE_MICROSERVICE_URL=https://buapi-staging.benchmarkuniverse.com/api/v1/
// ACCESSIBLE_REPORTS=https://atlantis-staging.benchmarkuniverse.com/api/v1/user/skus
// LMS2_BASE_URL=/#
// ORR_REPORTING_MICROSERVICE_URL = https://orrreporting-staging.benchmarkuniverse.com:5020/api/v1/
// PROXY_URL =
